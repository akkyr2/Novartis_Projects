import boto3
import json
from config import settings
from typing import *
from langchain_aws import ChatBedrock


class BedrockClient:
    def __init__(self):
        self.client = boto3.client(
            "bedrock-runtime",
            region_name=settings.aws_region
        )
    
        self.text_model_id = settings.model_id
        self.embedding_model_id = settings.embedding_model_id
        
        # High-level LangChain LLM
        self.llm = ChatBedrock(
                model=self.text_model_id,
                region_name=settings.aws_region,
                model_kwargs={
                    "temperature": 0.1,
                    "max_tokens": 2056,
                },
            )

    def invoke(self, body: dict):
        response = self.client.invoke_model(
            modelId=self.text_model_id,
            body=json.dumps(body)
        )
        return json.loads(response["body"].read())
    
    # For Titan Embeddings
    def vectorize_with_titan(self, text: str) -> List[float]:
        payload = {
            "inputText": text
        }

        response = self.client.invoke_model(
            modelId=self.embedding_model_id,
            body=json.dumps(payload),
            accept="application/json",
            contentType="application/json",
        )

        response_body = json.loads(response["body"].read())
        return response_body["embedding"]
    
    def llm_fn(self, prompt, model_id=settings.model_id):
        from utils.llm_utils import extract_text_from_bedrock_response
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "temperature": 0.1,
            "system": prompt,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }
            ]
        }
        response = self.client.invoke_model(
            modelId=model_id,
            body=json.dumps(body)
        )
        response_body = response["body"].read().decode("utf-8")
        return extract_text_from_bedrock_response(response_body)

    # High-level LLM call (for agents) using ChatBedrock
    def generate(self, prompt: str) -> str:
        response = self.llm.invoke(prompt)
        return response.content

    # Returns the raw LangChain response object so callers can use .content
    def generate_json(self, prompt: str):
        return self.llm.invoke(prompt)
