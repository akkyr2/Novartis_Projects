import json

def extract_text_from_bedrock_response(response_body_str):
    payload = json.loads(response_body_str)
    content_blocks = payload.get("content", [])
    text_parts = []

    for block in content_blocks:
        if block.get("type") == "text":
            text_parts.append(block.get("text", ""))

    return "\n".join(text_parts).strip()

def parse_llm_json(text):
    text = text.strip()

    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) >= 3:
            text = "\n".join(lines[1:-1]).strip()

    return json.loads(text)

def normalize_llm_output(llm_json, source_type):
    llm_json = llm_json or {}

    llm_json.setdefault("source_type", source_type)
    llm_json.setdefault("clean_text", "")
    llm_json.setdefault("summary", "")
    llm_json.setdefault("action_items", [])
    llm_json.setdefault("blockers", [])
    llm_json.setdefault("decisions", [])
    llm_json.setdefault("entities", {})
    llm_json.setdefault("metadata", {})
    llm_json.setdefault("flags", {})
    llm_json.setdefault("uncertainties", [])

    llm_json["entities"].setdefault("projects", [])
    llm_json["entities"].setdefault("tickets", [])
    llm_json["entities"].setdefault("people", [])
    llm_json["entities"].setdefault("dates", [])
    llm_json["entities"].setdefault("systems", [])
    llm_json["entities"].setdefault("organizations", [])

    llm_json["metadata"].setdefault("title", "")
    llm_json["metadata"].setdefault("subject", "")
    llm_json["metadata"].setdefault("sender", "")
    llm_json["metadata"].setdefault("people", []),
    llm_json["metadata"].setdefault("recipients", [])
    llm_json["metadata"].setdefault("participants", [])
    llm_json["metadata"].setdefault("thread_id", "")
    llm_json["metadata"].setdefault("message_id", "")
    llm_json["metadata"].setdefault("meeting_id", "")
    llm_json["metadata"].setdefault("channel_name", "")
    llm_json["metadata"].setdefault("team_name", "")
    llm_json["metadata"].setdefault("event_timestamp", "")
    llm_json["metadata"].setdefault("language", "en")

    llm_json["flags"].setdefault("has_action_items", len(llm_json["action_items"]) > 0)
    llm_json["flags"].setdefault("has_blockers", len(llm_json["blockers"]) > 0)
    llm_json["flags"].setdefault("has_decisions", len(llm_json["decisions"]) > 0)
    llm_json["flags"].setdefault("is_status_update", False)
    llm_json["flags"].setdefault("is_escalation", False)

    return llm_json


def parse_llm_json(text):
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) >= 3:
            text = "\n".join(lines[1:-1]).strip()
    return json.loads(text)


def run_llm_adjudication(prompt):
    from utils.bedrock_client import BedrockClient
    _bedrock = BedrockClient()
    return _bedrock.generate(prompt)


def clean_llm_output(text: str) -> str:
    import re
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    if text.lower().startswith("json"):
        text = text[4:].strip()
    return text.strip()