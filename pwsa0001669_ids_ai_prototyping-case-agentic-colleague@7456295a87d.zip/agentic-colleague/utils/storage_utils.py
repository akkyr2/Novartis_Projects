import os
import boto3
import json
from botocore.exceptions import ClientError
s3 = boto3.client("s3")


def build_output_key(path: str, prefix_folder: str) -> str:
    filename = os.path.splitext(os.path.basename(path))[0]
    return f"{prefix_folder}cleaned_json/{filename}.json"


def check_s3_object_exists(bucket: str, key: str) -> bool:
    print(f"bucket - {bucket}\nkey={key} this is inside the check_s3_func")
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            return False
        else:
            # Unexpected error → re-raise
            raise


def upload_json_to_s3(bucket: str, key: str, data: dict, skip_if_exists: bool = True):
    """
    Upload JSON to S3 with optional overwrite protection
    """
    # ✅ Check existence
    if skip_if_exists and check_s3_object_exists(bucket, key):
        print(f"⏭️ Skipping (already exists): s3://{bucket}/{key}")
        return {
            "status": "skipped",
            "s3_path": f"s3://{bucket}/{key}"
        }

    # ✅ Upload
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(data, indent=2).encode("utf-8"),
        ContentType="application/json"
    )

    print(f"✅ Uploaded: s3://{bucket}/{key}")

    return {
        "status": "uploaded",
        "s3_path": f"s3://{bucket}/{key}"
    }