parser_prompt_template = """
Parse the following user input into structured JSON.

User input:
<user_input>

Return JSON with exactly these fields:
{
  "intent": "retrieve|update|delete|create|unknown",
  "project_id": null,
  "project_name": null,
  "work_item_id": null,
  "title": null,
  "description": null,
  "reporter": null,
  "assignee": null,
  "status": null,
  "priority": null,
  "due_date": null,
  "blocker": null,
  "dependency": null,
  "issue": null,
  "summary": null,
  "retrieval_query": null,
  "clarification_needed": false,
  "clarification_question": null
}
"""

parser_prompt = """
You are a structured data parser for a scrum-master work item assistant.

Your job is to parse a user's message into a normalized JSON object.

Extract only information that is explicitly stated or strongly implied.
Do not invent missing facts.
If a value is unknown, return null.

Classify intent into one of:
- create
- update
- retrieve
- delete
- unknown

Normalize status into one of:
- todo
- in_progress
- blocked
- completed

Normalize priority into one of:
- low
- medium
- high

If the user is asking a question about a project or work item, use intent = retrieve.

If the request is ambiguous and cannot be safely tied to a single work item or project, set:
- clarification_needed = true
- clarification_question = a short question to ask the user

Always return valid JSON only.
Do not include markdown.
Do not include explanation text.
"""

def build_adjudication_prompt(intent_result, work_item_rows, evidence_rows):
    user_text="\n".join(intent_result["chat_history"])
    payload = {
        "user_claim": user_text,
        "parsed_intent": intent_result,
        "structured_work_items": compress_work_items_for_llm(work_item_rows),
        "historical_evidence": compress_evidence_for_llm(evidence_rows)
    }

    prompt = f"""
You are a scrum master assistant evaluating a user's requested work-item update.

Your task:
- Compare the user's request against the structured work item records and retrieved historical evidence.
- Determine the most likely target work item, if one exists.
- Identify which fields the user wants changed.
- Prefer being helpful and action-oriented rather than overly rejecting updates.
- If the user clearly requests a change to a task, assignee, due date, status, summary, or similar field, treat that as a valid proposed update even if historical evidence differs.
- Use the historical evidence to explain conflicts, risks, or inconsistencies, not to automatically block the user's request.
- Only choose needs_clarification if the target work item or intended field change is too ambiguous.
- If a matching item is found and the requested change is clear, prepare an updated version of the item.
- If historical evidence conflicts with the user's request, prefer confirm_overwrite instead of reject_update.
- Do not assume the user is always correct.
- Do not assume the historical records are always correct either.
- Base your judgment on specificity, consistency, recency if visible, corroboration across sources, and whether the user's request is explicit.

Return ONLY valid JSON with this schema:
{{
  "decision": "apply_directly" | "confirm_overwrite" | "needs_clarification" | "no_matching_item",
  "should_update": true | false,
  "confirmation_required": true | false,
  "user_signal_strength": "weak" | "medium" | "strong",
  "historical_signal_strength": "weak" | "medium" | "strong",
  "confidence": 0.0,
  "affected_fields": [],
  "reasoning_summary": [],
  "current_state_summary": {{}},
  "proposed_state_summary": {{}},
  "selected_work_item_id": "",
  "previous_item": {{}},
  "updated_item": {{}},
  "conflict_summary": [],
  "next_action": ""
}}

Rules:
- reasoning_summary must be concise, factual, and explainable.
- Do not reveal hidden chain of thought.
- Use only evidence from the provided context.
- If the user's update request is explicit and a matching work item is found, prefer apply_directly or confirm_overwrite.
- If historical evidence differs, summarize the conflict and prefer confirm_overwrite.
- If the request is ambiguous about which item to change, use needs_clarification.
- If no matching work item exists, use no_matching_item.
- previous_item must contain the selected original work item when available.
- updated_item must contain the same item with the user's requested changes applied when possible.
- Preserve unchanged fields in updated_item.
- affected_fields should list only the fields that changed.

Context:
{json.dumps(payload, indent=2, default=str)}
"""
    return prompt


def build_create_adjudication_prompt(intent_result, proposed_item, candidate_info):
    user_text="\n".join(intent_result["chat_history"])
    payload = {
        "user_request": user_text,
        "parsed_intent": intent_result,
        "proposed_work_item": proposed_item,
        "structured_candidates": candidate_info.get("structured_candidates", [])[:5],
        "semantic_candidates": candidate_info.get("semantic_candidates", [])[:5]
    }

    prompt = f"""
You are evaluating whether a user is trying to create a genuinely new work item or a duplicate of an existing one.

Your task:
- Review the proposed work item.
- Compare it against existing structured and semantically similar candidates.
- Decide whether this should be treated as:
  - a new work item,
  - a possible duplicate needing clarification,
  - an overwrite request,
  - or a request that should be ignored because the existing task should remain unchanged.

Return ONLY valid JSON with this schema:
{{
  "decision": "create_new" | "possible_duplicate" | "overwrite_existing" | "ignore_new_request" | "needs_clarification",
  "should_create": true | false,
  "confidence": 0.0,
  "reasoning_summary": [],
  "selected_existing_work_item_id": null,
  "candidate_duplicate_ids": [],
  "proposed_state_summary": {{}},
  "current_state_summary": {{}},
  "clarification_question": "",
  "next_action": ""
}}

Rules:
- Be concise and factual.
- Do not reveal hidden chain of thought.
- If the proposed item strongly overlaps with an existing item, prefer possible_duplicate or overwrite_existing.
- If it is clearly distinct, prefer create_new.
- If the user intent to overwrite is not explicit, do not assume overwrite_existing unless the request clearly indicates replacement.
- If evidence is mixed, prefer needs_clarification.

Context:
{json.dumps(payload, indent=2, default=str)}
"""
    return prompt