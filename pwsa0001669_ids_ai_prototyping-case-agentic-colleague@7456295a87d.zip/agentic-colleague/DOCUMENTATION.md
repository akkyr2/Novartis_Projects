﻿# Agentic Colleague — Technical Documentation

> **Version:** 2.0 (PoC)
> **Stack:** Python · FastAPI · LangGraph · AWS Bedrock · AWS OpenSearch Serverless · AWS DynamoDB
> **Last Updated:** May 2026
> **Active Entry Point:** `final_agent/main.py` (3028 lines)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Repository Structure](#2-repository-structure)
3. [Architecture Summary](#3-architecture-summary)
4. [Configuration & Environment](#4-configuration--environment)
5. [Dependencies](#5-dependencies)
6. [Backend — FastAPI Server](#6-backend--fastapi-server)
7. [Document Ingestion Pipeline](#7-document-ingestion-pipeline)
8. [AWS Services](#8-aws-services)
9. [Frontend](#9-frontend)
10. [Utility Modules](#10-utility-modules)
11. [Library Modules](#11-library-modules)
12. [Evaluation Pipeline](#12-evaluation-pipeline)
13. [Deployment (Docker)](#13-deployment-docker)
14. [Miscellaneous Scripts](#14-miscellaneous-scripts)
15. [Data Flow Diagrams](#15-data-flow-diagrams)
16. [Error Handling](#16-error-handling)
17. [Known Limitations & Future Work](#17-known-limitations--future-work)

---

## 1. Overview

**Agentic Colleague** is a conversational AI assistant for project teams. It ingests internal collaboration content (meeting transcripts, emails, Teams chats) into a semantic vector store, and supports natural-language retrieval, task creation, and task updates via a chat interface and Kanban board.

### Key Capabilities

| Capability | Description |
|---|---|
| **Retrieve** | Natural language Q&A over projects, tasks, decisions, blockers |
| **Create** | Add new work items via chat |
| **Update** | Modify work items (status, assignee, due date) via chat or drag-and-drop |
| **Ingest** | Upload DOCX/images; auto-extract structured project signals |
| **Kanban Board** | Real-time board with filters, drag-and-drop, card delete, card expand |

---

## 2. Repository Structure

```
agentic-colleague/
├── .env                             # Environment variables (not committed)
├── .gitignore
├── config.py                        # Pydantic settings (loaded from .env)
├── logger.py                        # setup_logger() helper
├── main.py                          # Dev/non-final entry point
├── user_upload_complete.py          # Standalone upload utility
├── requirements.txt                 # Dev dependencies
├── DOCUMENTATION.md                 # This file
├── README.md
│
├── agents/                          # Non-final modular agent components
│   ├── agent.py, clarify.py, create.py, decision.py
│   ├── inference.py, retrieve.py, state.py, update.py
│   └── __init__.py
│
├── final_agent/                     # ✅ ACTIVE — production entry point
│   ├── main.py                      # FastAPI + LangGraph (3028 lines)
│   ├── eval.py                      # Evaluation harness
│   ├── eval_logs.txt                # Append-only evaluation log
│   ├── requirements.txt             # Production Python dependencies
│   ├── Dockerfile                   # Python 3.12-slim, port 7007
│   ├── agentic_colleague_test_cases(in).csv
│   ├── user_uploads_from_UI/        # Local storage for uploaded files
│   └── static/
│       ├── index.html               # Kanban board
│       ├── chat.html                # Chat interface
│       ├── upload.html              # Document upload
│       ├── script.js                # Shared frontend logic (~1054 lines)
│       ├── style.css                # 4-theme styles
│       ├── Expanded-Logo-Dark-1.png # App logo
│       └── novartis-logo2.png       # Novartis branding
│
├── libs/
│   ├── cleaning_agent.py            # LLM document cleaner (CleaningAgent)
│   ├── dynamodb_client.py           # DynamoDB helper + work item search
│   ├── opensearch_client.py         # OpenSearch KNN search + indexing
│   ├── transform_agent.py           # cleaned_json → work_evidence record
│   ├── user_upload_agent.py         # File extraction (DOCX/image/S3)
│   └── __init__.py
│
├── utils/
│   ├── agent_prompts.py             # LLM prompt templates
│   ├── bedrock_client.py            # BedrockClient class
│   ├── data_ingestion_prompts.py    # Cleaning prompts + BASE_SCHEMA_TEXT
│   ├── image_utils.py               # Base64 image encoding
│   ├── llm_utils.py                 # JSON parsing, normalisation
│   ├── storage_utils.py             # S3 upload/download helpers
│   └── __init__.py
│
└── misc/
    ├── create_indices_v2.ipynb      # Bulk OpenSearch index creation
    ├── delete_from_dynamodb.py      # Bulk delete by source_type
    └── kanban.ipynb                 # Kanban data exploration
```

---

## 3. Architecture Summary

```
User Browser
    │
    ├── GET    /tasks     → DynamoDB scan → Kanban board
    ├── DELETE /tasks     → DynamoDB delete_item
    ├── POST   /agent     → LangGraph StateGraph → Claude → HTML answer
    └── POST   /upload    → Extract → Clean → Embed → OpenSearch + DynamoDB
                                      │
                           ┌──────────▼──────────┐
                           │   LangGraph Nodes    │
                           │  decision_node       │
                           │  inference_node      │
                           │  create_node         │
                           │  update_node         │
                           │  clarify_node        │
                           └──────────┬──────────┘
                                      │
                 ┌────────────────────┼─────────────────────┐
                 ▼                    ▼                      ▼
          AWS Bedrock          AWS OpenSearch          AWS DynamoDB
          (Claude Sonnet 4.5   (work_evidence          (WorkItems +
           + Titan Embed v2)    KNN index)              KanbanTasks_Draft)
```

---

## 4. Configuration & Environment

**File:** `config.py` — Pydantic `BaseSettings`, loaded from `.env` via `python-dotenv`.

```python
class Settings(BaseSettings):
    log_level: str = "INFO"
    aws_region: str
    bucket_name: str          # S3 bucket: ids-aini-prototype-ai-analytics
    prefix_folder: str
    s3_loader: str
    bedrock_loader: str
    model_id: str             # us.anthropic.claude-sonnet-4-5-20250929-v1:0
    embedding_model_id: str   # amazon.titan-embed-text-v2:0
    EMBEDDING_DIMENTION: int  # 1024
    service: str              # aoss
    host: str                 # OpenSearch endpoint URL
    headers: dict
    index_name: str           # work_evidence
    work_items: str           # AgenticColleague_WorkItems
    class Config:
        env_file = ".env"
        extra = "ignore"
```

A single global `settings = Settings()` instance is imported throughout the codebase.

---

## 5. Dependencies

### `final_agent/requirements.txt`

| Package | Purpose |
|---|---|
| `fastapi` | REST API server |
| `uvicorn` | ASGI server |
| `langgraph` | LangGraph state machine |
| `langchain` + `langchain_aws` | LLM chains + ChatBedrock integration |
| `boto3` | AWS SDK (DynamoDB, Bedrock, S3) |
| `requests-aws4auth` | SigV4 auth for OpenSearch |
| `python-docx` | DOCX text extraction |
| `pandas` | Work item DataFrame operations |
| `scikit-learn` | Cosine similarity for vector ranking |
| `Markdown` | LLM markdown → HTML |
| `python-multipart` | Multipart file upload support |
| `pydantic-settings` + `python-dotenv` | `.env` config loading |

### Frontend (CDN)

`pdf.js`, `mammoth.js`, `xlsx.js` for file preview in upload UI.

---

## 6. Backend — FastAPI Server

**File:** `final_agent/main.py`

Serves REST API + static files (`app.mount("/static", StaticFiles(...))`). Root `/` → `static/index.html`. Uses `CORSMiddleware`.

### 6.1 API Endpoints

| Method | Path | Description |
|---|---|---|
| `GET` | `/` | Serves `static/index.html` |
| `GET` | `/tasks` | All Kanban cards from `AgenticColleague_KanbanTasks_Draft` |
| `DELETE` | `/tasks` | Delete card by `pk` + `sk` query params |
| `POST` | `/agent` | LangGraph chat endpoint |
| `POST` | `/upload` | Document ingestion |

#### `GET /tasks`
Scans `AgenticColleague_KanbanTasks_Draft`. Converts DynamoDB `Decimal` to `int`/`float`. Returns array of task objects including `PK`, `SK`, `project_name`, `task`, `assigned_to`, `due_date`, `status`.

#### `DELETE /tasks`
Query params: `pk`, `sk`. Calls `table.delete_item(Key={"PK": pk, "SK": sk})`. Returns `{"status":"deleted","PK":...,"SK":...}` or HTTP 500.

#### `POST /agent`

**Request:**
```json
{ "chat_history": ["..."], "clarification_received": false, "result_payload": {} }
```

**Response (normal):**
```json
{ "response": "<html>", "result_payload": {}, "clarification_needed": false }
```

**Response (clarification needed):**
```json
{ "response": "<p>Found task X... Shall I apply? (yes/no)</p>", "result_payload": {...}, "clarification_needed": true }
```

> Frontend reads `data.answer || data.response` (both key names used historically).

Logic:
1. Builds `GraphState`, invokes `build_graph()`
2. Non-blocking eval logged to `eval_logs.txt`
3. If `clarification_needed`: extracts question from `clarification_question` → `fr["answer"]` → `fr["next_action"]` → generic fallback, wraps in `<p>`
4. Otherwise: `markdown.markdown(final_response, extensions=['tables', 'fenced_code'])` → returns HTML

#### `POST /upload`

Form data: `files` (UploadFile list), `categories` (label list), `force_reindex` (default `"false"`).

Mapped source types: `"Meeting Transcript"` → `meeting_transcript`, `"Team Chat"` → `teams_chat`, `"Outlook"` → `email`.

Pipeline: save → extract text → clean with LLM → embed with Titan → index OpenSearch → write WorkItems → write KanbanTasks_Draft.

### 6.2 LangGraph State Machine

```python
class GraphState(TypedDict, total=False):
    user_input: str; user_id: str; session_id: str
    chat_history: List[str]; result_payload: dict
    workspace_id: str; project_id: str; project_name: str
    reporter: str; assignee: str; assignees: List[str]; intent: str
    work_item_id: str; title: str; description: str; status: str
    priority: str; due_date: str; lifecycle_state: str; is_deleted: bool
    blocker: str; dependency: str; issue: str; summary: str; decision: str; action: str
    retrieval_query: str; retrieval_plan: Dict[str, Any]
    work_items_results: List[Dict[str, Any]]; work_evidence_results: List[Dict[str, Any]]
    retrieval_results: Any; resolved_work_item_id: str
    resolution_confidence: float; conflict_flag: bool; conflict_reason: str
    clarification_needed: bool; clarification_question: str; clarification_received: bool
    decision_type: str; decision_reason: str; action_plan: List[Dict[str, Any]]
    final_response: str
```

**Graph routing:**
```
START → decision_node
    retrieve/unknown → inference_node → END
    create           → create_node → clarify_node → END (pass 2 back to create_node)
    update           → update_node → clarify_node → END (pass 2 back to update_node)
```

### 6.3 Graph Nodes

#### `decision_node`
- Parses intent via Claude + `parser_prompt` from `utils/agent_prompts.py`
- Extracts: `intent`, `project_name`, `retrieval_query`, `assignee`, `title`, `status`, `due_date`
- Enriches short queries (≤ 4 words)
- Fetches context via `handle_retrieve_intent()` (OpenSearch KNN + DynamoDB keyword)
- Routes: `retrieve`/`unknown` → inference, `create` → create_node, `update` → update_node

#### `inference_node`
- Claude synthesises answer from retrieved context
- Enforces: 1-sentence summary, max 5 bullets, max 5 table rows, no filler
- Returns markdown (converted to HTML by `/agent` endpoint)

#### `create_node`
**Pass 1:** `handle_create_intent_with_llm()` → proposed item → `clarify_node`
**Pass 2 (after "yes"):** `index_document()` → `apply_confirmed_update_dynamodb()` (WorkItems) → `kanban_table.put_item()` (KanbanTasks_Draft) → `"Successfully Created!"`

#### `update_node`
**Pass 1 — Dual search:**
1. `handle_update_intent_with_llm()` against `AgenticColleague_WorkItems`
2. If `updated_item is None`: full scan of `AgenticColleague_KanbanTasks_Draft`, fuzzy match by title (substring + word overlap) + assignee, threshold score ≥ 2
3. Extracts new status from state fields or regex on `user_text`
4. Sets `kanban_only=True` when matched via fallback
5. Sanitises `Decimal`/`NaN`/`Inf` via `_san()` before LangGraph state storage

**Pass 2 — Apply:**
- `kanban_only=False`: update OpenSearch + WorkItems + KanbanTasks_Draft
- `kanban_only=True`: skip OpenSearch + WorkItems; `put_item` on original `PK`/`SK` in KanbanTasks_Draft
- Guard: if `updated_item` still `None` → returns friendly "couldn't find task" message

#### `clarify_node`
Human-readable confirmation, e.g.:
> *"I found the task **"X"** assigned to **Y** in **Z** and will update its status to **in progress**. Shall I apply? (yes / no)"*

- If `updated_item is None` and `mode == "update_review"` → returns error to END directly
- Falls back to LLM-generated question if task/status unknown
- All field access via `.get()` — no crashes

### 6.4 Retrieval Pipeline

`handle_retrieve_intent(intent_result, table_name)`:
1. Extract + enrich query
2. KNN search OpenSearch `work_evidence` (k=10, Titan v2 1024-dim)
3. DynamoDB keyword search `AgenticColleague_WorkItems` (case variants)
4. Merge → return `{mode, decision_trace, retrieved_evidence, work_item_matches, answer}`

### 6.5 Helper Functions

| Function | Description |
|---|---|
| `compress_work_items_for_llm(rows, max_rows=5)` | Trims to 5 rows before LLM call |
| `apply_confirmed_update_dynamodb(item, table_name)` | Writes item to DynamoDB table |
| `confirmed_updated_item_to_work_evidence_record(...)` | Builds work_evidence doc for OpenSearch |
| `clean_nan(obj)` | Recursively replaces NaN/Inf/Decimal for JSON serialisation |

---

## 7. Document Ingestion Pipeline

### 7.1 UserUploadAgent (`libs/user_upload_agent.py`)

| Function / Method | Description |
|---|---|
| `extract_text_from_docx_bytes(bytes)` | DOCX extraction from raw bytes |
| `extract_text_from_docx_file(path)` | DOCX extraction from disk |
| `read_file_from_s3(bucket, key)` | Reads bytes from S3 |
| `UserUploadAgent.process_file(path)` | Dispatches by extension (.docx / .png .jpg .jpeg .webp) |
| `UserUploadAgent.process_s3_file(bucket, key)` | S3 version of process_file |
| `_extract_from_image(path)` | Claude Vision OCR from file path |
| `_extract_from_image_bytes(bytes, ext)` | Claude Vision OCR from bytes |

### 7.2 CleaningAgent (`libs/cleaning_agent.py`)

```python
result = CleaningAgent().clean(raw_text, source_type="meeting_transcript")
```

- Selects `SYSTEM_PROMPTS[source_type]`, invokes Claude (`max_tokens=8192`)
- Parses with `parse_llm_json()`, normalises with `normalize_llm_output()`
- Returns structured dict or `{"status":"error",...}` on parse failure
- Additional statics: `clean_llm_output(text)`, `pretty_print_adjudication(result)`

### 7.3 TransformAgent (`libs/transform_agent.py`)

`cleaned_json_to_work_evidence_record(cleaned_json, workspace_id, ...)` — builds full `work_evidence` dict for OpenSearch.

Helpers: `normalize_date_for_opensearch()`, `utc_now_iso()`, `_as_list()`, `_dedupe_preserve_order()`, `_drop_none()`

### 7.4 Supported Source Types

| UI Label | `source_type` Key |
|---|---|
| Meeting Transcript | `meeting_transcript` |
| Outlook | `email` |
| Team Chat | `teams_chat` |

### 7.5 Extracted JSON Schema (defined in `utils/data_ingestion_prompts.py`)

Key fields: `source_type`, `clean_text`, `summary`, `action_items[]` (description, owner, due_date, status, evidence), `blockers[]`, `decisions[]`, `entities{}` (projects, tickets, people, dates, systems, organizations), `metadata{}` (title, subject, sender, recipients, participants, channel_name, team_name, event_timestamp, language), `flags{}` (has_action_items, has_blockers, has_decisions, is_status_update, is_escalation), `uncertainties[]`

---

## 8. AWS Services

### 8.1 AWS Bedrock (`utils/bedrock_client.py`)

**`BedrockClient` class:**

| Method | Description |
|---|---|
| `invoke(body)` | Raw Bedrock API call, returns parsed JSON |
| `vectorize_with_titan(text)` | Returns 1024-dim float vector |
| `llm_fn(prompt, model_id)` | Raw API Claude call, returns extracted text |
| `generate(prompt)` | LangChain `ChatBedrock.invoke()`, returns `response.content` |

Config: `temperature=0.1`, `max_tokens=2056`

| Model | Purpose |
|---|---|
| `us.anthropic.claude-sonnet-4-5-20250929-v1:0` | All LLM tasks |
| `amazon.titan-embed-text-v2:0` | Embeddings (1024-dim) |

### 8.2 AWS OpenSearch Serverless (`libs/opensearch_client.py`)

- Index: `work_evidence` | Auth: SigV4 (`requests-aws4auth`) from boto3 session credentials
- Key fields: `embedding` (knn_vector 1024), `clean_text`, `summary`, `action_items_detected`, `decisions_detected`, `source_type`, `source_uri`, `project_name`, `ingested_at`
- Helper: `normalize_date_for_opensearch(value)` → ISO date string

> ⚠️ **Production:** OpenSearch writes return 403 (IAM/AOSS policy not configured for EC2 role). Fails silently — does not crash the app.

### 8.3 AWS DynamoDB

#### `AgenticColleague_WorkItems` — source of truth
PK: `PROJECT#{project_name}` · SK: `TASK#{work_item_id}`  
Searched in `update_node` pass 1. Written on confirmed create/update.

#### `AgenticColleague_KanbanTasks_Draft` — UI source
PK: `PROJECT#{project_name}` · SK: `TASK#{work_item_id}`  
Source for `GET /tasks`. Written on every create/update/upload. Scanned in `update_node` fallback.

Display fields: `project_name`, `task`, `assigned_to`, `due_date`, `status`, `source_type`, `source_uri`

**`kanban_only=True` write strategy:** When a task is found only in KanbanTasks_Draft, the confirmation branch writes directly using the original `PK`/`SK` from the matched card, preserving all existing fields and only updating `status`.

---

## 9. Frontend

All files in `final_agent/static/`, served by FastAPI.

### 9.1 Pages & Assets

| File | URL | Description |
|---|---|---|
| `index.html` | `/` | Kanban board — To Do / In Progress / Done, auto-refresh every **5s** |
| `chat.html` | `/static/chat.html` | Chat interface |
| `upload.html` | `/static/upload.html` | Document upload with progress bar |
| `Expanded-Logo-Dark-1.png` | `/static/...` | App logo |
| `novartis-logo2.png` | `/static/...` | Novartis branding |

**Sidebar nav (all pages):**
- 📋 **Task Board** *(formerly Kanban)*
- 📄 **Knowledge Feed** *(formerly Document Upload)*
- 💬 **Ask AC** *(formerly Chat)*

**Kanban features:** search bar, assignee filter, project filter, drag-and-drop, card delete (hover → ✕), card expand modal, skeleton loaders, toast notifications, assignee avatars.

### 9.2 Theming System

4 themes via swatches in sidebar footer, persisted to `localStorage('theme')`.

| `data-theme` | Description |
|---|---|
| `dark` | Default — deep purple/violet |
| `ocean` | Dark navy + cyan |
| `forest` | Dark green + emerald |
| `warm` | Warm beige/amber |

`applyTheme(theme)` → `document.documentElement.setAttribute('data-theme', theme)`. All colours are CSS custom properties per `[data-theme]` block.

### 9.3 script.js — Key Functions

| Function | Description |
|---|---|
| `initKanban()` | Kanban page entry — `fetchAndRenderTasks()` + 5s auto-refresh |
| `fetchAndRenderTasks()` | `GET ./tasks` → `allTasks` → `populateFilters()` → `renderBoard()` → toast if count changed |
| `renderBoard(tasks)` | Renders `{todo, inProgress, done}` into 3 columns |
| `createCard(task, statusClass)` | Returns card HTML (avatar, delete btn, draggable) |
| `showSkeletons()` | Shimmer placeholder cards while loading |
| `populateFilters(data)` | Fills assignee + project dropdowns from `allTasks` |
| `applyFilters()` | Filters + re-renders by search text / assignee / project |
| `initDragAndDrop()` | `dragstart`/`drop` → `POST ./agent` with auto-confirm |
| `initCardClick()` | Card click → `showCardModal()`; delete btn → `DELETE ./tasks` |
| `showCardModal(task)` | Full-detail overlay for a card |
| `initTheme()` | Reads `localStorage('theme')` → `applyTheme()` |
| `applyTheme(theme)` | Sets `data-theme`, persists, updates swatch `.active` state |
| `initUpload()` | File selection, preview, progress bar, `POST ./upload` |
| `renderFiles()` | Renders selected file preview list |
| `initChat()` | Chat page entry — restores state, re-fires pending requests |
| `sendMessage()` | Input → save pending → `POST ../agent` → render response |
| `firePendingRequest(body)` | Shared fetch helper (on load + visibility change) |
| `appendMessage(text, sender, persist, typewriter)` | `isHtml()` → render HTML or `renderMarkdown()` |
| `isHtml(text)` | Returns true if text contains HTML tags |
| `applyThemeToHtml(html)` | Injects `.md-table` class onto `<table>` tags |
| `renderMarkdown(text)` | Plain-text markdown → HTML fallback |
| `showTyping()` / `removeTyping()` | 3-dot animated typing indicator |
| `showToast(msg, type, duration)` | Floating toast (success/info/warning/error) |
| `askSuggestion(btn)` | Sidebar chip → fill input → `sendMessage()` |
| `useQuickPrompt(btn)` | Welcome panel chip → fill input → `sendMessage()` |
| `clearChat()` | Clears all chat state from memory + localStorage |
| `saveState()` | Persists all chat state to localStorage |
| `disableInput()` / `enableInput()` | Toggles input + send button disabled state |
| `hideWelcome()` | Removes welcome panel on first message |

### 9.4 Chat Persistence & Tab-Switch Resilience

All chat state in `localStorage`:

| Key | Description |
|---|---|
| `chatHistory` | User messages in current turn |
| `chatMessages` | All rendered `{text, sender}` for re-display |
| `resultPayload` | Agent result payload for multi-turn |
| `clarificationNeeded` / `clarificationReceived` | Confirmation flow state |
| `chatPendingRequest` | Request body saved before fetch, cleared on response |
| `theme` | Active theme name |

**beforeunload:** sets `isNavigatingAway=true`, aborts fetch via `AbortController` → prevents false error messages on page navigation.

**visibilitychange:** on tab return, if `chatMessages.length` differs from localStorage → re-renders all messages. If `chatPendingRequest` exists → re-fires fetch.

### 9.5 Markdown & HTML Rendering Pipeline

```
Backend: markdown.markdown(final_response, extensions=['tables','fenced_code']) → HTML

Frontend:
    isHtml(text)
        true  → applyThemeToHtml(html)  (inject .md-table onto <table>)
                bubble.innerHTML = html
        false → renderMarkdown(text)    (plain-text fallback)
```

`.md-table` in `style.css`: gradient header, hover rows, rounded corners, theme-aware.

### 9.6 Drag-and-Drop

```
drop event
    → message: "set status to in progress — task: 'X', assignee: Y, project: Z"
    → POST ./agent { clarification_received: false }
    → if clarification_needed: auto-confirm POST ./agent { clarification_received: true }
    → showToast("✅ moved to In Progress")
    → fetchAndRenderTasks() after 1500ms
```

Status phrases: Done → `"mark it done"` | In Progress → `"set status to in progress"` | To Do → `"set status to to do"`

---

## 10. Utility Modules

### `utils/agent_prompts.py`
- `parser_prompt_template` — template with `<user_input>` placeholder
- `parser_prompt` — full system prompt; normalises intent to `create/update/retrieve/delete/unknown` and status to `todo/in_progress/blocked/completed`

### `utils/data_ingestion_prompts.py`
- `BASE_SCHEMA_TEXT` — required JSON output schema injected into all cleaning prompts
- `SYSTEM_PROMPTS` dict — keys: `meeting_transcript`, `email`, `teams_chat`

### `utils/bedrock_client.py`
`BedrockClient` class — see §8.1.

### `utils/llm_utils.py`

| Function | Description |
|---|---|
| `extract_text_from_bedrock_response(str)` | Extracts text blocks from Bedrock API response |
| `parse_llm_json(text)` | Strips ` ```json ` fences, parses JSON |
| `normalize_llm_output(llm_json, source_type)` | Fills all required schema fields with defaults |
| `run_llm_adjudication(prompt)` | Creates `BedrockClient`, calls `generate()` |

### `utils/image_utils.py`
- `encode_image_to_base64(image_path)` → base64 string for Claude Vision

### `utils/storage_utils.py`

| Function | Description |
|---|---|
| `build_output_key(path, prefix_folder)` | Builds S3 output key for cleaned JSON |
| `check_s3_object_exists(bucket, key)` | `head_object` check → bool |
| `upload_json_to_s3(bucket, key, data, skip_if_exists)` | Uploads JSON with overwrite protection |

### `logger.py`
`setup_logger(name)` — configures `basicConfig` from `settings.log_level`, returns named logger.

---

## 11. Library Modules

### `libs/cleaning_agent.py`
`CleaningAgent` — see §7.2.

### `libs/user_upload_agent.py`
`UserUploadAgent` + standalone helpers — see §7.1.

### `libs/transform_agent.py`
`cleaned_json_to_work_evidence_record()` + date/list helpers — see §7.3.

### `libs/dynamodb_client.py`
`DynamoDB` class + `search_work_items_from_intent_result()`:
- Queries by `PK = PROJECT#{project_name}` if project known; otherwise full table scan
- Filters by `work_item_id`, `title`, `assignee` using `pandas` DataFrame
- Uses `cosine_similarity` (scikit-learn) for vector-based ranking

### `libs/opensearch_client.py`
Standalone OpenSearch functions: KNN search, document indexing, index management, `normalize_date_for_opensearch()`. Uses `requests-aws4auth` SigV4.

---

## 12. Evaluation Pipeline

**Files:** `final_agent/eval.py`, `final_agent/eval_logs.txt`, `final_agent/agentic_colleague_test_cases(in).csv`

Runs non-blocking on every `/agent` request. Failures caught silently.

| Function | Description |
|---|---|
| `load_records()` | Reads test cases from local CSV |
| `load_records_from_s3()` | Reads from S3: `ids-aini-prototype-ai-analytics/Agentic-Colleague-synthetic/agentic_colleague_test_cases(in).csv` |
| `evaluation(bedrock, model_id, user_query, ai_response, eval_records)` | Claude-as-judge evaluation, logs to `eval_logs.txt` |

**CSV columns:** `Question`, `Expected Answer (Summary)`, `Evaluation Criteria`  
**Eval model:** `us.anthropic.claude-sonnet-4-5-20250929-v1:0`

---

## 13. Deployment (Docker)

**File:** `final_agent/Dockerfile`

- Base: `python:3.12-slim`
- Port: **7007**
- Corporate proxy: `http://proxy-usvn.aws.novartis.net:3128`
- Bedrock endpoints excluded from proxy in `no_proxy`
- Start: `uvicorn main:app --host 0.0.0.0 --port 7007`

**Rebuild & redeploy (on EC2):**
```bash
docker stop agentic_col ; docker rm agentic_col
docker build -t agentic_col:v20 .
docker run -d --name agentic_col -p 7007:7007 agentic_col:v20
```

---

## 14. Miscellaneous Scripts

### `misc/delete_from_dynamodb.py`
`delete_items_by_source_type(table_name, source_type_value, dry_run=True)` — bulk deletes DynamoDB items matching a `source_type` value. Supports dry-run. Handles pagination.

### `misc/create_indices_v2.ipynb`
Notebook for bulk OpenSearch `work_evidence` index creation.

### `misc/kanban.ipynb`
Notebook for DynamoDB Kanban data exploration.

---

## 15. Data Flow Diagrams

### Chat — Retrieve
```
POST /agent → decision_node (parse intent) → handle_retrieve_intent()
    → knn_search (OpenSearch k=10) + DynamoDB keyword search
    → inference_node (Claude, max 5 bullets, max 5 rows)
    → markdown.markdown() → HTML response
```

### Chat — Update (KanbanDraft task)
```
"move Final testing... to in progress"
→ update_node pass 1
    → WorkItems search → nothing
    → KanbanTasks_Draft fallback scan → fuzzy match (score≥2) → kanban_only=True
→ clarify_node → "Found task... update to in progress. Apply? (yes/no)"
→ User: "yes"
→ update_node pass 2 (kanban_only=True)
    → skip OpenSearch + WorkItems
    → put_item on original PK/SK with new status
→ "✅ updated to in progress"
→ Kanban auto-refreshes in 5s
```

### Document Upload
```
POST /upload
→ UserUploadAgent.process_file() → raw text
→ CleaningAgent.clean() → structured JSON (action_items, decisions, blockers, entities)
→ cleaned_json_to_work_evidence_record() → work_evidence doc
→ vectorize_with_titan() → 1024-dim embedding
→ index_document() → OpenSearch (may 403 in prod)
→ apply_confirmed_update_dynamodb() → WorkItems
→ kanban_table.put_item() → KanbanTasks_Draft
```

### Drag-and-Drop
```
drag card to column
→ POST ./agent { "set status to in progress — task: 'X'..." }
→ update_node → KanbanTasks_Draft fallback if needed
→ auto-confirm → put_item with new status
→ fetchAndRenderTasks() after 1500ms
```

---

## 16. Error Handling

| Location | Scenario | Handling |
|---|---|---|
| `decision_node` | LLM parse fails | Routes to `inference_node` with empty context |
| `update_node` pass 1 | WorkItems returns nothing | KanbanTasks_Draft fallback scan |
| `update_node` pass 1 | Fallback scan fails | `except` catches + logs; `updated_item` stays None |
| `update_node` pass 2 | `updated_item` is None | Guard → friendly "couldn't find task" message |
| `update_node` | Decimal/NaN in state | `_san()` recursive sanitiser before `Command(update=...)` |
| `clarify_node` | `updated_item` None + mode=update_review | Returns error to END, skips confirmation loop |
| `/agent` | Graph execution error | try/except → `"Sorry, something went wrong..."` + traceback |
| `/agent` | Clarification question missing | Multi-level fallback → generic message |
| `evaluation` | Any failure | Non-blocking try/except, logged to `eval_logs.txt` |
| `inference_node` | `final_response` is None | `final_response or ""` guard |
| `/upload` | Processing failure | try/except → error message in response JSON |
| `firePendingRequest` | Fetch fails | `AbortError`/`isNavigatingAway` silences nav errors; genuine errors show user message |
| `index_document` | OpenSearch 403 | Returns `{"status_code":403,...}` — logged, does not crash |

---

## 17. Known Limitations & Future Work

| Area | Status | Notes |
|---|---|---|
| Chat update — KanbanDraft tasks | ✅ Fixed | Fallback scan + `kanban_only` flag |
| clarify_node raw JSON to user | ✅ Fixed | Rewritten to human-readable messages |
| NoneType crash in update_node | ✅ Fixed | Guard on `updated_item` in confirmation branch |
| Double-brace `{{` crash | ✅ Fixed | `{{` → `{` in Command call |
| Markdown table rendering | ✅ Fixed | `isHtml()` + `applyThemeToHtml()` pipeline |
| Card delete | ✅ Implemented | `DELETE /tasks` + hover ✕ button |
| Kanban filters | ✅ Implemented | Search + assignee + project |
| 4-theme system | ✅ Implemented | Swatch picker + localStorage persistence |
| Upload progress bar | ✅ Implemented | `uploadProgressWrap` in upload.html |
| Skeleton loaders + toasts | ✅ Implemented | Shimmer cards + floating notifications |
| Assignee avatars | ✅ Implemented | Coloured initials badge |
| OpenSearch in production | ⚠️ 403 blocked | Fix IAM/AOSS policy for EC2 instance role |
| File formats | ⚠️ Partial | Only DOCX + images; add PDF, .eml, .txt, .msg |
| Query quality | ⚠️ Partial | Short query enrichment is heuristic-based |
| Auth | ❌ Not implemented | No login — add SSO/Azure AD |
| Document chunking | ❌ Not implemented | Long docs indexed as single vectors |
| Async evaluation | ❌ Not implemented | Runs inline per request; move to async job |
| Bulk ingestion | ❌ Not implemented | One-at-a-time; add batch CSV/S3 import |

---

*Documentation generated from full source scan — `final_agent/main.py` (3028 lines), `final_agent/eval.py`, `final_agent/Dockerfile`, `final_agent/static/` (script.js, style.css, index.html, chat.html, upload.html), `libs/` (cleaning_agent, dynamodb_client, opensearch_client, transform_agent, user_upload_agent), `utils/` (agent_prompts, bedrock_client, data_ingestion_prompts, image_utils, llm_utils, storage_utils), `config.py`, `logger.py`, `misc/`*
