# this agent helps to process file (docx/png) that the user uploads from the frontend

from utils.bedrock_client import BedrockClient
from utils.image_utils import encode_image_to_base64
from docx import Document
from io import BytesIO
import boto3
import os

def extract_text_from_docx_bytes(file_bytes: bytes) -> str:
    """Extracts plain text content from a DOCX file provided as raw bytes."""
    doc = Document(BytesIO(file_bytes))
    return "\n".join([p.text for p in doc.paragraphs])


def extract_text_from_docx_file(file_path: str) -> str:
    """Reads a DOCX file from disk and returns all paragraph text as a single string."""
    doc = Document(file_path)
    return "\n".join([p.text for p in doc.paragraphs])

# in case S3 files are used

def read_file_from_s3(bucket_name: str, key: str) -> bytes:
    s3 = boto3.client("s3")
    response = s3.get_object(Bucket=bucket_name, Key=key)
    return response["Body"].read()

class UserUploadAgent:
    def __init__(self):
        self.client = BedrockClient()

    def process_file(self, file_path: str) -> str:
        """
        Handles local files (image or docx)
        """
        extension = os.path.splitext(file_path)[1].lower()

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return self._extract_from_image(file_path)

        elif extension == ".docx":
            return extract_text_from_docx_file(file_path)

        else:
            raise ValueError(f"Unsupported file type: {extension}")

    def process_s3_file(self, bucket: str, key: str) -> str:
        """
        Handles files coming from S3
        """
        extension = os.path.splitext(key)[1].lower()

        file_bytes = read_file_from_s3(bucket, key)

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return self._extract_from_image_bytes(file_bytes, extension)

        elif extension == ".docx":
            return extract_text_from_docx_bytes(file_bytes)

        else:
            raise ValueError(f"Unsupported file type: {extension}")

    # -------------------------------
    # IMAGE HANDLING
    # -------------------------------

    def _extract_from_image(self, file_path: str) -> str:
        image_base64 = encode_image_to_base64(file_path)
        return self._call_claude(image_base64, "image/png")

    def _extract_from_image_bytes(self, file_bytes: bytes, ext: str) -> str:
        import base64
        image_base64 = base64.b64encode(file_bytes).decode("utf-8")

        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(ext, "image/png")

        return self._call_claude(image_base64, media_type)

    def _call_claude(self, image_base64: str, media_type: str) -> str:
        """This function is used to call claude 4.5 sonnet to process images"""
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_base64,
                            },
                        },
                        {
                            "type": "text",
                            "text": "Extract all text from this image. Preserve formatting."
                        }
                    ],
                }
            ],
        }

        response = self.client.invoke(body)
        return response["content"][0]["text"]