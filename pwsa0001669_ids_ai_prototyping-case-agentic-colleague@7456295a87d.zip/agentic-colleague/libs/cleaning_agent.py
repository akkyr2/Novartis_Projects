import json
from utils.bedrock_client import BedrockClient
from utils.data_ingestion_prompts import SYSTEM_PROMPTS
from utils.llm_utils import (
    extract_text_from_bedrock_response,
    parse_llm_json,
    normalize_llm_output,
)

class CleaningAgent:
    def __init__(self):
        self.client = BedrockClient()

    def clean(self, content: str, source_type: str) -> dict:
        """Processes raw content using LLM prompts and returns normalized structured output."""
        if source_type not in SYSTEM_PROMPTS:
            raise ValueError(f"Unsupported source_type: {source_type}")

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 8192,
            "temperature": 0.1,
            "system": SYSTEM_PROMPTS[source_type],
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": content}],
                }
            ],
        }

        response = self.client.invoke(body)
        generated_text = response["content"][0]["text"]

        try:
            parsed = parse_llm_json(generated_text)
            normalized = normalize_llm_output(parsed, source_type)
            return normalized

        except Exception as e:
            return {
                "status": "error",
                "message": f"Parsing failed: {str(e)}",
                "raw_output": generated_text[:1000],  # debug safe
            }

    
    def clean_llm_output(text: str) -> str:
        """Cleans LLM output by removing markdown/code blocks and formatting artifacts."""
        text = text.strip()

        # Remove ```json ... ``` or ``` ... ```
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)

        # Remove leading 'json' if present
        if text.lower().startswith("json"):
            text = text[4:].strip()

        return text.strip()
        
    def pretty_print_adjudication(result):
        """Prints adjudication results in a structured, human-readable format."""
        mode = result.get("mode", "unknown")
        print(f"\nMODE: {mode}")

        adjudication = result.get("adjudication", {})

        if not adjudication:
            print("\nANSWER:")
            answer = result.get("answer", "")
            if isinstance(answer, str):
                print(answer.replace("\\n", "\n"))
            else:
                print(json.dumps(answer, indent=2, default=str))

            retrieved_evidence = result.get("retrieved_evidence", [])
            work_item_matches = result.get("work_item_matches", [])

            if retrieved_evidence:
                print(f"\nRETRIEVED EVIDENCE COUNT: {len(retrieved_evidence)}")

            if work_item_matches:
                print(f"\nWORK ITEM MATCH COUNT: {len(work_item_matches)}")

            return

        if "update" in mode:
            print("\nDECISION:", adjudication.get("decision"))
            print("SHOULD UPDATE:", adjudication.get("should_update"))
            print("CONFIDENCE:", adjudication.get("confidence"))
            print("USER SIGNAL:", adjudication.get("user_signal_strength"))
            print("HISTORICAL SIGNAL:", adjudication.get("historical_signal_strength"))

            print("\nAFFECTED FIELDS:")
            affected_fields = adjudication.get("affected_fields", [])
            if affected_fields:
                for field in affected_fields:
                    print("-", field)
            else:
                print("- None")

            print("\nREASONING SUMMARY:")
            reasoning_summary = adjudication.get("reasoning_summary", [])
            if reasoning_summary:
                for line in reasoning_summary:
                    print("-", line)
            else:
                print("- None")

            print("\nCURRENT STATE SUMMARY:")
            print(json.dumps(adjudication.get("current_state_summary", {}), indent=2, default=str))

            print("\nPROPOSED STATE SUMMARY:")
            print(json.dumps(adjudication.get("proposed_state_summary", {}), indent=2, default=str))

            print("\nNEXT ACTION:")
            print(adjudication.get("next_action"))

        elif "create" in mode:
            print("\nDECISION:", adjudication.get("decision"))
            print("SHOULD CREATE:", adjudication.get("should_create"))
            print("CONFIDENCE:", adjudication.get("confidence"))

            print("\nREASONING SUMMARY:")
            reasoning_summary = adjudication.get("reasoning_summary", [])
            if reasoning_summary:
                for line in reasoning_summary:
                    print("-", line)
            else:
                print("- None")

            print("\nSELECTED EXISTING WORK ITEM ID:")
            print(adjudication.get("selected_existing_work_item_id"))

            print("\nCANDIDATE DUPLICATE IDS:")
            duplicate_ids = adjudication.get("candidate_duplicate_ids", [])
            if duplicate_ids:
                for item in duplicate_ids:
                    print("-", item)
            else:
                print("- None")

            print("\nPROPOSED STATE SUMMARY:")
            print(json.dumps(adjudication.get("proposed_state_summary", {}), indent=2, default=str))

            print("\nCURRENT STATE SUMMARY:")
            print(json.dumps(adjudication.get("current_state_summary", {}), indent=2, default=str))

            print("\nCLARIFICATION QUESTION:")
            print(adjudication.get("clarification_question"))

            print("\nNEXT ACTION:")
            print(adjudication.get("next_action"))

            proposed_item = result.get("proposed_item")
            if proposed_item:
                print("\nPROPOSED ITEM:")
                print(json.dumps(proposed_item, indent=2, default=str))

            candidate_info = result.get("candidate_info", {})
            if candidate_info:
                structured_candidates = candidate_info.get("structured_candidates", [])
                semantic_candidates = candidate_info.get("semantic_candidates", [])

                print(f"\nSTRUCTURED CANDIDATES COUNT: {len(structured_candidates)}")
                for idx, candidate in enumerate(structured_candidates[:3], start=1):
                    print(f"\nSTRUCTURED CANDIDATE {idx}:")
                    print(json.dumps(candidate, indent=2, default=str))

                print(f"\nSEMANTIC CANDIDATES COUNT: {len(semantic_candidates)}")
                for idx, candidate in enumerate(semantic_candidates[:3], start=1):
                    print(f"\nSEMANTIC CANDIDATE {idx}:")
                    print(json.dumps(candidate, indent=2, default=str))

        else:
            print("\nADJUDICATION:")
            print(json.dumps(adjudication, indent=2, default=str))

        answer = result.get("answer")
        if answer:
            print("\nANSWER:")
            if isinstance(answer, str):
                print(answer.replace("\\n", "\n"))
            else:
                print(json.dumps(answer, indent=2, default=str))

        work_item_matches = result.get("work_item_matches", [])
        if work_item_matches:
            print(f"\nWORK ITEM MATCH COUNT: {len(work_item_matches)}")

        retrieved_evidence = result.get("retrieved_evidence", [])
        if retrieved_evidence:
            print(f"\nRETRIEVED EVIDENCE COUNT: {len(retrieved_evidence)}")