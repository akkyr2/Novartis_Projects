from config import settings
import boto3
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from utils.bedrock_client import BedrockClient

bedrock = BedrockClient()

class DynamoDB:
    def __init__(self, region_name="us-east-1"):
        self.dynamodb = boto3.resource("dynamodb", region_name=region_name)
    
        self.work_items = settings.work_items
    
    def search_work_items_from_intent_result(
        intent_result,
        table_name=settings.work_items,
        ):
        """Retrieves and filters work items from DynamoDB based on intent attributes."""
        table = dynamodb_resource.Table(table_name)
        items = []

        project_name = (intent_result or {}).get("project_name")
        work_item_id = (intent_result or {}).get("work_item_id")
        title = (intent_result or {}).get("title")
        assignee = (intent_result or {}).get("assignee")

        if project_name:
            response = table.query(
                KeyConditionExpression=Key("PK").eq(f"PROJECT#{project_name}")
            )
            items.extend(response.get("Items", []))

            while "LastEvaluatedKey" in response:
                response = table.query(
                    KeyConditionExpression=Key("PK").eq(f"PROJECT#{project_name}"),
                    ExclusiveStartKey=response["LastEvaluatedKey"],
                )
                items.extend(response.get("Items", []))
        else:
            response = table.scan()
            items.extend(response.get("Items", []))

            while "LastEvaluatedKey" in response:
                response = table.scan(
                    ExclusiveStartKey=response["LastEvaluatedKey"]
                )
                items.extend(response.get("Items", []))

        df = pd.DataFrame(items)

        if df.empty:
            return df

        for col in ["work_item_id", "project_name", "task", "assignee"]:
            if col not in df.columns:
                df[col] = ""

        if work_item_id:
            df = df[df["work_item_id"].astype(str) == str(work_item_id)]

        if project_name:
            df = df[df["project_name"].fillna("").str.lower() == str(project_name).lower()]

        if title:
            df = df[df["task"].fillna("").str.lower().str.contains(str(title).lower(), na=False)]

        if assignee:
            df = df[df["assignee"].fillna("").str.lower().str.contains(str(assignee).lower(), na=False)]

        return df

    # this function is used for retreiving existing work items (in order to avoid duplicates in the create node)
    def find_structured_create_candidates_dynamodb(
        proposed_item,
        table_name=settings.work_items,
        top_k=5,
    ):
        """Finds work items using keyword retrieval"""
        project_name = (proposed_item.get("project_name") or "").strip()
        assignee = (proposed_item.get("assignee") or "").strip().lower()
        task = (proposed_item.get("task") or "").strip().lower()

        work_items_df = search_work_items_dynamodb_like_pandas(
            table_name=table_name,
            project_name=project_name if project_name else None,
            work_item_id=None,
            title=None,
            assignee=None,
        )

        if work_items_df.empty:
            return []

        df = work_items_df.copy()

        if project_name:
            df = df[df["project_name"].fillna("").str.lower() == project_name.lower()]

        candidates = []

        for _, row in df.iterrows():
            row_task = str(row.get("task", "")).strip().lower()
            row_assignee = str(row.get("assignee", "")).strip().lower()

            score = 0
            reasons = []

            if assignee and row_assignee == assignee:
                score += 2
                reasons.append("same assignee")

            if task and row_task == task:
                score += 5
                reasons.append("exact same task")

            elif task and row_task and (task in row_task or row_task in task):
                score += 3
                reasons.append("task text overlap")

            if proposed_item.get("due_date") is not None and row.get("due_date") is not None:
                try:
                    p_date = pd.to_datetime(proposed_item["due_date"]).date()
                    r_date = pd.to_datetime(row["due_date"]).date()
                    if p_date == r_date:
                        score += 2
                        reasons.append("same due date")
                except Exception:
                    pass

            if score > 0:
                candidates.append({
                    "match_score": score,
                    "match_reasons": reasons,
                    "row": row.to_dict(),
                })

        candidates = sorted(candidates, key=lambda x: x["match_score"], reverse=True)
        return candidates[:top_k]
    


    def find_semantic_create_candidates_dynamodb(
        proposed_item,
        table_name=settings.work_items,
        top_k=5,
    ):
        """Finds work items using semantic retrieval"""
        project_name = (proposed_item.get("project_name") or "").strip()

        work_items_df = search_work_items_dynamodb_like_pandas(
            table_name=table_name,
            project_name=project_name if project_name else None,
            work_item_id=None,
            title=None,
            assignee=None,
        )

        if work_items_df.empty:
            return []

        proposed_text = make_work_item_text(proposed_item)
        proposed_emb = np.array(vectorize_with_titan(proposed_text)).reshape(1, -1)

        texts = []
        rows = []

        for _, row in work_items_df.iterrows():
            texts.append(make_work_item_text(row.to_dict()))
            rows.append(row.to_dict())

        if not texts:
            return []

        embeddings = np.array([vectorize_with_titan(text) for text in texts])

        sims = cosine_similarity(proposed_emb, embeddings)[0]

        ranked = sorted(
            [
                {"similarity": float(sim), "row": row}
                for sim, row in zip(sims, rows)
            ],
            key=lambda x: x["similarity"],
            reverse=True,
        )

        return ranked[:top_k]


    # combining both from the above
    def gather_create_candidates(proposed_item, work_items_df, embed_fn=bedrock.vectorize_with_titan):
        """Gathers both structured and semantic work items retrieved - useful to find any duplicate work items"""
        structured = find_structured_create_candidates(work_items_df, proposed_item, top_k=10)

        semantic = []
        if embed_fn is not None and len(work_items_df) > 0:
            semantic = find_semantic_create_candidates(proposed_item)

        return {
            "structured_candidates": structured,
            "semantic_candidates": semantic
        }

    # creating a work_item record
    def make_work_item_text(row):
        """Creates work item records to upload to dynamodb"""
        if hasattr(item, "to_dict"):
            item = item.to_dict()

        item = item or {}

        return "\n".join([
            f"Project: {item.get('project_name', '')}",
            f"Task: {item.get('task', '')}",
            f"Assignee: {item.get('assignee', '')}",
            f"Status: {item.get('status', '')}",
            f"Due date: {item.get('due_date', '')}",
            f"Summary: {item.get('summary', '')}",
            f"Evidence: {item.get('task_evidence', '')}",
        ])
    

    def search_work_items(work_items_df, project_name=None, work_item_id=None, title=None, assignee=None):
        df = work_items_df.copy()

        if work_item_id:
            df = df[df["work_item_id"].astype(str) == str(work_item_id)]

        if project_name:
            df = df[df["project_name"].fillna("").str.lower() == project_name.lower()]

        if title:
            df = df[df["task"].fillna("").str.lower().str.contains(title.lower(), na=False)]

        if assignee:
            df = df[df["assignee"].fillna("").str.lower().str.contains(assignee.lower(), na=False)]

        return df

    def retrieve_work_items_df_from_intent_result(
        intent_result,
        table_name=settings.work_items,
    ):
        """This function retrieves the dynamodb data given inputs from the user or document - project_name, work_item_id, title, assignee, etc."""
        table = dynamodb_resource.Table(table_name)
        items = []

        # intent_result = intent_result or {}

        project_name = intent_result.get("project_name")
        work_item_id = intent_result.get("work_item_id")
        title = intent_result.get("title")
        assignee = intent_result.get("assignee")

        if project_name:
            response = table.query(
                KeyConditionExpression=Key("PK").eq(f"PROJECT#{project_name}")
            )
            items.extend(response.get("Items", []))

            while "LastEvaluatedKey" in response:
                response = table.query(
                    KeyConditionExpression=Key("PK").eq(f"PROJECT#{project_name}"),
                    ExclusiveStartKey=response["LastEvaluatedKey"],
                )
                items.extend(response.get("Items", []))
        else:
            response = table.scan()
            items.extend(response.get("Items", []))

            while "LastEvaluatedKey" in response:
                response = table.scan(
                    ExclusiveStartKey=response["LastEvaluatedKey"]
                )
                items.extend(response.get("Items", []))

        df = pd.DataFrame(items)

        if df.empty:
            return pd.DataFrame(columns=[
                "work_item_id", "evidence_id", "source_uri", "source_type",
                "project_name", "task", "assignee", "due_date", "status",
                "task_evidence", "event_timestamp", "summary"
            ])

        for col in [
            "work_item_id", "evidence_id", "source_uri", "source_type",
            "project_name", "task", "assignee", "due_date", "status",
            "task_evidence", "event_timestamp", "summary"
        ]:
            if col not in df.columns:
                df[col] = ""

        if work_item_id:
            df = df[df["work_item_id"].astype(str) == str(work_item_id)]

        if project_name:
            df = df[df["project_name"].fillna("").str.lower() == str(project_name).lower()]

        if title:
            df = df[df["task"].fillna("").str.lower().str.contains(str(title).lower(), na=False)]

        if assignee:
            df = df[df["assignee"].fillna("").str.lower().str.contains(str(assignee).lower(), na=False)]

        return df.reset_index(drop=True)

    def compress_work_items_for_llm(work_item_rows, max_rows=5):
        rows = work_item_rows[:max_rows]
        compressed = []

        for row in rows:
            compressed.append({
                "work_item_id": row.get("work_item_id"),
                "project_name": row.get("project_name"),
                "task": row.get("task"),
                "assignee": row.get("assignee"),
                "due_date": str(row.get("due_date")) if row.get("due_date") is not None else None,
                "status": row.get("status"),
                "summary": row.get("summary")
            })

        return compressed

    def build_proposed_item_for_matching(intent_result):
        """This function is used to create a proposed item dictionary - can be found as a result of the 
        "handle_intent_with_llm functions" """
        user_text="\n".join(intent_result["chat_history"])
        return {
            "project_name": intent_result.get("project_name"),
            "task": intent_result.get("title") or intent_result.get("task") or intent_result.get("summary") or user_text,
            "assignee": intent_result.get("assignee"),
            "due_date": intent_result.get("due_date"),
            "status": intent_result.get("status"),
            "summary": intent_result.get("summary") or intent_result.get("description") or user_text
        }

    def resolve_selected_work_item_hybrid(intent_result, table_name=settings.work_items, top_k=5):

        """This function matches the proposed item built above with the structured & semantic candidates"""
        user_text="\n".join(intent_result["chat_history"])
        work_items_df = retrieve_work_items_df_from_intent_result(
            intent_result=intent_result,
            table_name=table_name,
        )
        
        work_item_id = intent_result.get("work_item_id")

        if work_item_id:
            exact = work_items_df[
                work_items_df["work_item_id"].astype(str) == str(work_item_id)
            ]
            if not exact.empty:
                row = exact.iloc[0].to_dict()
                return {
                    "selected_item": row,
                    "resolution_method": "exact_work_item_id",
                    "confidence": 1.0,
                    "candidates": [{"row": row, "final_score": 1.0}]
                }

        proposed_item = build_proposed_item_for_matching(intent_result)

        structured_candidates = find_structured_create_candidates(
            table_name=settings.work_items,
            proposed_item=proposed_item,
            top_k=top_k
        )

        semantic_candidates = find_semantic_create_candidates(
            proposed_item=proposed_item,
            table_name=settings.work_items,
            top_k=top_k
        )

        structured_map = {}
        for item in structured_candidates:
            row = item["row"]
            wid = str(row.get("work_item_id"))
            structured_map[wid] = item

        semantic_map = {}
        for item in semantic_candidates:
            row = item["row"]
            wid = str(row.get("work_item_id"))
            semantic_map[wid] = item

        all_ids = set(structured_map.keys()) | set(semantic_map.keys())
        combined = []

        for wid in all_ids:
            s_score = structured_map.get(wid, {}).get("match_score", 0)
            sim_score = semantic_map.get(wid, {}).get("similarity", 0.0)

            row = None
            if wid in structured_map:
                row = structured_map[wid]["row"]
            elif wid in semantic_map:
                row = semantic_map[wid]["row"]

            final_score = (0.6 * sim_score) + (0.4 * min(s_score / 10.0, 1.0))

            combined.append({
                "work_item_id": wid,
                "row": row,
                "structured_score": s_score,
                "semantic_similarity": sim_score,
                "final_score": final_score,
                "match_reasons": structured_map.get(wid, {}).get("match_reasons", [])
            })

        combined = sorted(combined, key=lambda x: x["final_score"], reverse=True)

        if not combined:
            return {
                "selected_item": None,
                "resolution_method": "no_match",
                "confidence": 0.0,
                "candidates": []
            }

        best = combined[0]
        confidence = best["final_score"]

        if len(combined) > 1:
            gap = best["final_score"] - combined[1]["final_score"]
        else:
            gap = best["final_score"]

        if confidence < 0.55 or gap < 0.08:
            return {
                "selected_item": None,
                "resolution_method": "ambiguous",
                "confidence": confidence,
                "candidates": combined[:top_k]
            }

        return {
            "selected_item": best["row"],
            "resolution_method": "hybrid_structured_semantic",
            "confidence": confidence,
            "candidates": combined[:top_k]
        }

    def gather_update_context(intent_result, table_name=settings.work_items, n_results=5):

        """Combined vectordb + semantic work_items + keyword work_items.
        semantic work_items are the work_items retrieved from the dynamodb SEMANTICALLY
        keyword work_items are the work_Items retrieved using KEYWORD search"""

        user_text="\n".join(intent_result["chat_history"])
        work_items_df = retrieve_work_items_df_from_intent_result(
            intent_result=intent_result,
            table_name=table_name,
        )
        
        project_name = intent_result.get("project_name")
        title = intent_result.get("title")
        assignee = intent_result.get("assignee")
        work_item_id = intent_result.get("work_item_id")

        work_item_matches = search_work_items(
            work_items_df,
            project_name=project_name,
            work_item_id=work_item_id,
            title=title,
            assignee=assignee
        )

        query_parts = [
            user_text,
            intent_result.get("retrieval_query"),
            project_name,
            title,
            intent_result.get("description"),
            intent_result.get("status"),
            assignee,
            str(intent_result.get("due_date")) if intent_result.get("due_date") else None,
            intent_result.get("summary")
        ]
        query_text = " ".join([x for x in query_parts if x])

        search_raw = knn_search_work_evidence(query_text=query_text,)
        evidence = format_search_results(search_raw)

        return {
            "user_text": user_text,
            "intent_result": intent_result,
            "work_item_matches": work_item_matches.to_dict(orient="records"),
            "evidence": evidence
        }

    def gather_create_candidates(proposed_item, table_name=settings.work_items, embed_fn=bedrock.vectorize_with_titan):
        work_items_df = retrieve_work_items_df_from_intent_result(
            intent_result=proposed_item,
            table_name=table_name,
        )
        
        structured = find_structured_create_candidates(table_name=work_items, proposed_item=proposed_item, top_k=10)

        semantic = []
        if embed_fn is not None and len(work_items_df) > 0:
            semantic = find_semantic_create_candidates(proposed_item)

        return {
            "structured_candidates": structured,
            "semantic_candidates": semantic
        }
    
    def build_proposed_work_item(intent_result):
        user_text="\n".join(intent_result["chat_history"])
        return {
            "work_item_id": f"WI_{uuid.uuid4().hex[:10]}",
            "evidence_id": None,
            "source_uri": "user_chat",
            "source_type": "chat",
            "project_name": intent_result.get("project_name"),
            "task": intent_result.get("title") or intent_result.get("summary"),
            "assignee": intent_result.get("assignee"),
            "due_date": intent_result.get("due_date"),
            "status": intent_result.get("status") or "To Do",
            "task_evidence": user_text,
            "event_timestamp": datetime.utcnow().isoformat(),
            "summary": intent_result.get("summary") or intent_result.get("description")
        }
    
    def apply_confirmed_update_dynamodb(
        updated_item,
        table_name=settings.work_items,
        ):
        """This functions uploads the updated item/created item into the dynamodb. 
        Use this fucntion when you want to add a new work_item into the dynamodb.
        Note: updated item must be in a compatible work_item record format."""

        if not updated_item:
            return None
    
        project_name = updated_item.get("project_name")
        work_item_id = updated_item.get("work_item_id")
    
        if not project_name:
            raise ValueError("updated_item must contain project_name")
    
        if not work_item_id:
            raise ValueError("updated_item must contain work_item_id")
    
        table = dynamodb_resource.Table(table_name)
    
        pk = f"PROJECT#{project_name}"
        sk = f"TASK#{work_item_id}"
    
        update_values = {
            "evidence_id": updated_item.get("evidence_id"),
            "source_uri": updated_item.get("source_uri"),
            "source_type": updated_item.get("source_type"),
            "project_name": updated_item.get("project_name"),
            "task": updated_item.get("task"),
            "assignee": updated_item.get("assignee"),
            "due_date": updated_item.get("due_date"),
            "status": updated_item.get("status"),
            "task_evidence": updated_item.get("task_evidence"),
            "event_timestamp": updated_item.get("event_timestamp"),
            "summary": updated_item.get("summary"),
            "updated_at": utc_now_iso(),
        }
    
        update_values = {k: v for k, v in update_values.items() if v is not None}
    
        update_expression_parts = []
        expression_attribute_names = {}
        expression_attribute_values = {}
 
        for idx, (field, value) in enumerate(update_values.items()):
            name_key = f"#f{idx}"
            value_key = f":v{idx}"
            update_expression_parts.append(f"{name_key} = {value_key}")
            expression_attribute_names[name_key] = field
            expression_attribute_values[value_key] = value
    
        update_expression = "SET " + ", ".join(update_expression_parts)
    
        response = table.update_item(
            Key={
                "PK": pk,
                "SK": sk,
            },
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values,
            ReturnValues="ALL_NEW",
        )
    
        return response.get("Attributes")