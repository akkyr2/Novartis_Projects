from config import settings
import copy
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
import boto3
from io import BytesIO
from docx import Document
import random
import requests
from requests_aws4auth import AWS4Auth
from utils.bedrock_client import BedrockClient

host = settings.host
index_name = settings.index_name
headers = settings.headers
region = settings.aws_region
service = settings.service
bedrock = BedrockClient()

session = boto3.Session()
credentials = session.get_credentials()
awsauth = AWS4Auth(
    credentials.access_key,
    credentials.secret_key,
    region,
    service,
    session_token=credentials.token
)


def normalize_date_for_opensearch(value):
    if not value:
        return None

    value = str(value).strip()
    if not value:
        return None

    # already ISO-like
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.date().isoformat()
        except ValueError:
            pass

    # common natural language dates
    for fmt in ("%B %d, %Y", "%b %d, %Y"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.date().isoformat()
        except ValueError:
            pass

    # unsupported fuzzy dates like "early June 2026"
    return None

def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _dedupe_preserve_order(values):
    seen = set()
    result = []
    for v in values:
        if v is None:
            continue
        v = str(v).strip()
        if not v:
            continue
        if v not in seen:
            seen.add(v)
            result.append(v)
    return result


def _drop_none(d):
    return {k: v for k, v in d.items() if v is not None}


def index_document(doc, index_name=index_name, host=host, headers=headers):

    """This function is used to add data (from user uploads, chat updates and chat creates work items) into the vectordb index"""

    url = f"{host}/{index_name}/_doc"
    response = requests.post(
        url,
        auth=awsauth,
        headers=headers,
        data=json.dumps(doc)
    )

    return {
        "status_code": response.status_code,
        "text": response.text
    }

def knn_search_work_evidence(
    query_text: str,
    host=host,
    awsauth=awsauth,
    embed_text_fn=bedrock.vectorize_with_titan,
    k: int = 5
):
    """This function is the main (most important) retrieval supporting function to retrieve data from the vectordb"""
    query_vector = embed_text_fn(query_text)

    query_body = {
        "size": k,
        "query": {
            "knn": {
                "vector_embedding": {
                    "vector": query_vector,
                    "k": k
                }
            }
        },
        "_source": [
            "summary",
            "clean_text",
            "embedding_text",
            "source_uri",
            "source_type",
            "metadata"
        ]
    }

    response = requests.post(
        f"{host}/work_evidence/_search",
        auth=awsauth,
        headers={"Content-Type": "application/json"},
        json=query_body,
    )
    if response.status_code != 200:
        return []

    response_json = response.json()
    hits = response_json.get("hits", {}).get("hits", [])

    results = []
    for hit in hits:
        source = hit.get("_source", {})
        results.append({
            "score": hit.get("_score"),
            "summary": source.get("summary", ""),
            "clean_text": source.get("clean_text", ""),
            "embedding_text": source.get("embedding_text", ""),
            "source_uri": source.get("source_uri", ""),
            "source_type": source.get("source_type", ""),
            "metadata": source.get("metadata", {}),
        })

    return results

def format_search_results(results_list):
    """Formats the flat dict list returned by knn_search_work_evidence into a
    consistent structure for downstream use. Each item in results_list is a
    dict with keys: score, summary, clean_text, source_uri, source_type, metadata."""
    formatted = []

    for hit in results_list:
        if not isinstance(hit, dict):
            continue
        meta = hit.get("metadata") or {}
        # Prefer clean_text (full email/doc body) over summary for richer context
        document = hit.get("clean_text") or hit.get("summary") or ""
        formatted.append({
            "evidence_id": meta.get("message_id") or meta.get("source_uri") or hit.get("source_uri", ""),
            "document": document,
            "summary": hit.get("summary", ""),
            "source_uri": hit.get("source_uri", ""),
            "source_type": hit.get("source_type", ""),
            "score": hit.get("score"),
            "metadata": meta,
        })

    return formatted

def compress_evidence_for_llm(evidence_records, max_items=5, max_chars=500):
    compressed = []

    for ev in evidence_records[:max_items]:
        compressed.append({
            "evidence_id": ev.get("evidence_id"),
            "source_type": (ev.get("metadata") or {}).get("source_type"),
            "source_uri": (ev.get("metadata") or {}).get("source_uri"),
            "project_names": (ev.get("metadata") or {}).get("project_names"),
            "snippet": (ev.get("document") or "")[:max_chars]
        })

    return compressed


def confirmed_updated_item_to_work_evidence_record(
    user_text,
    intent_result,
    adjudication,
    previous_item,
    updated_item,
    user_confirmation,
    workspace_id,
    project_id=None,
    source_uri="user_chat",
    embedding_fn=None,
):

    """Creates a work evidence record to store into vectordb. Must match the index of the vectordb"""
    if not user_confirmation:
        raise ValueError("This function should only be used for confirmed updates.")

    intent_result = intent_result or {}
    adjudication = adjudication or {}
    previous_item = previous_item or {}
    updated_item = updated_item or {}

    evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()

    resolved_project_id = (
        project_id
        or updated_item.get("project_id")
        or previous_item.get("project_id")
        or intent_result.get("project_id")
    )

    linked_work_item_ids = _dedupe_preserve_order([
        previous_item.get("work_item_id"),
        updated_item.get("work_item_id"),
        intent_result.get("work_item_id"),
        adjudication.get("selected_work_item_id"),
    ])

    project_names = _dedupe_preserve_order([
        previous_item.get("project_name"),
        updated_item.get("project_name"),
        intent_result.get("project_name"),
    ])

    normalized_dates = _dedupe_preserve_order([
        normalize_date_for_opensearch(previous_item.get("due_date")),
        normalize_date_for_opensearch(updated_item.get("due_date")),
        normalize_date_for_opensearch(intent_result.get("due_date")),
    ])

    people = _dedupe_preserve_order([
        previous_item.get("assignee"),
        updated_item.get("assignee"),
        intent_result.get("assignee"),
        intent_result.get("reporter"),
    ])

    event_payload = {
        "event_type": "update_request_confirmed",
        "user_text": user_text,
        "intent_result": intent_result,
        "adjudication": adjudication,
        "previous_item": previous_item,
        "updated_item": updated_item,
        "user_confirmation": user_confirmation,
    }

    raw_text = json.dumps(event_payload, default=str, ensure_ascii=False)

    previous_task = str(previous_item.get("task") or previous_item.get("title") or "")
    updated_task = str(updated_item.get("task") or updated_item.get("title") or "")
    previous_status = str(previous_item.get("status") or "")
    updated_status = str(updated_item.get("status") or "")
    previous_assignee = str(previous_item.get("assignee") or previous_item.get("owner") or "")
    updated_assignee = str(updated_item.get("assignee") or updated_item.get("owner") or "")
    previous_due_date = normalize_date_for_opensearch(previous_item.get("due_date"))
    updated_due_date = normalize_date_for_opensearch(updated_item.get("due_date"))

    affected_fields = adjudication.get("affected_fields") or []
    affected_fields = [str(x) for x in affected_fields if x]

    summary_parts = [
        "User confirmed an update to an existing work item."
    ]
    if updated_task:
        summary_parts.append(f"Updated task: {updated_task}.")
    if updated_status:
        summary_parts.append(f"New status: {updated_status}.")
    if updated_assignee:
        summary_parts.append(f"Assignee: {updated_assignee}.")
    if updated_due_date:
        summary_parts.append(f"Due date: {updated_due_date}.")
    summary = " ".join(summary_parts)

    clean_text_parts = [
        "User confirmed an update to a work item.",
        f"User text: {user_text}",
        f"Project: {', '.join(project_names)}" if project_names else "",
        f"Work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Previous item: {json.dumps(previous_item, default=str, ensure_ascii=False)}",
        f"Updated item: {json.dumps(updated_item, default=str, ensure_ascii=False)}",
        f"Adjudication summary: {adjudication.get('reasoning_summary', '')}" if adjudication.get("reasoning_summary") else "",
        f"Affected fields: {', '.join(affected_fields)}" if affected_fields else "",
    ]
    clean_text = "\n".join(part for part in clean_text_parts if part)

    embedding_text_parts = [
        "Confirmed work item update",
        str(user_text or ""),
        f"Project names: {', '.join(project_names)}" if project_names else "",
        f"Linked work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Previous task: {previous_task}" if previous_task else "",
        f"Updated task: {updated_task}" if updated_task else "",
        f"Previous status: {previous_status}" if previous_status else "",
        f"Updated status: {updated_status}" if updated_status else "",
        f"Previous assignee: {previous_assignee}" if previous_assignee else "",
        f"Updated assignee: {updated_assignee}" if updated_assignee else "",
        f"Previous due date: {previous_due_date}" if previous_due_date else "",
        f"Updated due date: {updated_due_date}" if updated_due_date else "",
        f"Reasoning summary: {adjudication.get('reasoning_summary')}" if adjudication.get("reasoning_summary") else "",
        f"Conflict summary: {adjudication.get('conflict_summary')}" if adjudication.get("conflict_summary") else "",
        f"Proposed state: {adjudication.get('proposed_state_summary')}" if adjudication.get("proposed_state_summary") else "",
    ]
    embedding_text = "\n".join(part for part in embedding_text_parts if part)

    updated_due_date_for_action = normalize_date_for_opensearch(updated_item.get("due_date"))

    action_items_detected = [
        _drop_none({
            "title": updated_task or "Updated work item",
            "description": str(
                updated_item.get("summary")
                or updated_item.get("task_evidence")
                or updated_task
                or "Confirmed update to work item"
            ),
            "owner": updated_assignee if updated_assignee else None,
            "due_date": updated_due_date_for_action,
            "status": updated_status if updated_status else None,
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    decision_text_parts = [
        "User confirmed update to existing work item"
    ]
    if affected_fields:
        decision_text_parts.append(f"Affected fields: {', '.join(affected_fields)}")
    if adjudication.get("reasoning_summary"):
        decision_text_parts.append(str(adjudication.get("reasoning_summary")))

    decisions_detected = [
        _drop_none({
            "decision": ". ".join(decision_text_parts),
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    doc = {
        "evidence_id": evidence_id,
        "workspace_id": str(workspace_id),
        "project_id": str(resolved_project_id) if resolved_project_id is not None else "",
        "source_type": "chat_update_handler",
        "source_uri": str(source_uri),
        "raw_text": raw_text,
        "clean_text": clean_text,
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": linked_work_item_ids,
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": normalized_dates,
        "metadata": {
            "source_uri": str(source_uri),
            "entities": {
                "dates": normalized_dates,
                "organizations": [],
                "people": people,
                "projects": project_names,
                "systems": [],
                "tickets": linked_work_item_ids,
            }
        },
        "created_at": now,
        "updated_at": now,
    }

    if embedding_fn is not None:
        vector_embedding = embedding_fn(embedding_text)

        if hasattr(vector_embedding, "tolist"):
            vector_embedding = vector_embedding.tolist()

        if not isinstance(vector_embedding, list):
            raise ValueError(f"Embedding function must return a list, got {type(vector_embedding)}")

        if len(vector_embedding) != 1024:
            raise ValueError(f"Expected vector_embedding length 1024, got {len(vector_embedding)}")

        doc["vector_embedding"] = vector_embedding

    return doc


def confirmed_created_item_to_work_evidence_record(
    user_text,
    intent_result,
    adjudication,
    proposed_item,
    workspace_id,
    project_id=None,
    source_uri="user_chat",
    embedding_fn=None,
):
    """proposed item that the user confirms to create in the backend is formatted in this function to add into the index
    Use this function to create an "update_doc. Check update node for understanding why this function is used."""

    intent_result = intent_result or {}
    adjudication = adjudication or {}
    proposed_item = proposed_item or {}

    evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()

    resolved_project_id = (
        project_id
        or proposed_item.get("project_id")
        or intent_result.get("project_id")
    )

    resolved_source_type = (
        proposed_item.get("source_type")
        or "chat_create_handler"
    )

    linked_work_item_ids = _dedupe_preserve_order([
        proposed_item.get("work_item_id"),
        intent_result.get("work_item_id"),
    ])

    project_names = _dedupe_preserve_order([
        proposed_item.get("project_name"),
        intent_result.get("project_name"),
    ])

    normalized_dates = _dedupe_preserve_order([
        normalize_date_for_opensearch(proposed_item.get("due_date")),
        normalize_date_for_opensearch(intent_result.get("due_date")),
    ])

    people = _dedupe_preserve_order([
        proposed_item.get("assignee"),
        proposed_item.get("owner"),
        intent_result.get("assignee"),
        intent_result.get("reporter"),
    ])

    event_payload = {
        "event_type": "create_request",
        "user_text": user_text,
        "intent_result": intent_result,
        "proposed_item": proposed_item,
        "adjudication": adjudication,
    }

    raw_text = json.dumps(event_payload, default=str, ensure_ascii=False)

    proposed_task = str(
        proposed_item.get("task")
        or proposed_item.get("title")
        or ""
    )
    proposed_status = str(proposed_item.get("status") or "")
    proposed_assignee = str(
        proposed_item.get("assignee")
        or proposed_item.get("owner")
        or ""
    )
    proposed_due_date = normalize_date_for_opensearch(proposed_item.get("due_date"))

    affected_fields = adjudication.get("affected_fields") or []
    affected_fields = [str(x) for x in affected_fields if x]

    summary_parts = [
        "User requested creation of a new work item."
    ]
    if proposed_task:
        summary_parts.append(f"Task: {proposed_task}.")
    if proposed_status:
        summary_parts.append(f"Status: {proposed_status}.")
    if proposed_assignee:
        summary_parts.append(f"Assignee: {proposed_assignee}.")
    if proposed_due_date:
        summary_parts.append(f"Due date: {proposed_due_date}.")
    summary = " ".join(summary_parts)

    clean_text_parts = [
        "User requested creation of a new work item.",
        f"User text: {user_text}",
        f"Project: {', '.join(project_names)}" if project_names else "",
        f"Work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Proposed item: {json.dumps(proposed_item, default=str, ensure_ascii=False)}",
        f"Adjudication summary: {adjudication.get('reasoning_summary', '')}" if adjudication.get("reasoning_summary") else "",
        f"Affected fields: {', '.join(affected_fields)}" if affected_fields else "",
    ]
    clean_text = "\n".join(part for part in clean_text_parts if part)

    embedding_text_parts = [
        "Create work item request",
        str(user_text or ""),
        f"Project names: {', '.join(project_names)}" if project_names else "",
        f"Linked work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Proposed task: {proposed_task}" if proposed_task else "",
        f"Proposed status: {proposed_status}" if proposed_status else "",
        f"Proposed assignee: {proposed_assignee}" if proposed_assignee else "",
        f"Proposed due date: {proposed_due_date}" if proposed_due_date else "",
        f"Intent summary: {intent_result.get('summary')}" if intent_result.get("summary") else "",
        f"Reasoning summary: {adjudication.get('reasoning_summary')}" if adjudication.get("reasoning_summary") else "",
        f"Proposed state: {adjudication.get('proposed_state_summary')}" if adjudication.get("proposed_state_summary") else "",
    ]
    embedding_text = "\n".join(part for part in embedding_text_parts if part)

    action_items_detected = [
        _drop_none({
            "title": proposed_task or "New work item",
            "description": str(
                proposed_item.get("summary")
                or proposed_item.get("task_evidence")
                or proposed_item.get("description")
                or proposed_task
                or "Requested new work item"
            ),
            "owner": proposed_assignee if proposed_assignee else None,
            "due_date": proposed_due_date,
            "status": proposed_status if proposed_status else None,
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    decisions_detected = [
        _drop_none({
            "decision": str(
                adjudication.get("decision")
                or "User requested creation of a new work item"
            ),
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    doc = {
        "evidence_id": evidence_id,
        "workspace_id": str(workspace_id),
        "project_id": str(resolved_project_id) if resolved_project_id is not None else "",
        "source_type": str(resolved_source_type),
        "source_uri": str(source_uri),
        "raw_text": raw_text,
        "clean_text": clean_text,
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": linked_work_item_ids,
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": normalized_dates,
        "metadata": {
            "source_uri": str(source_uri),
            "entities": {
                "dates": normalized_dates,
                "organizations": [],
                "people": people,
                "projects": project_names,
                "systems": [],
                "tickets": linked_work_item_ids,
            }
        },
        "created_at": now,
        "updated_at": now,
    }

    if embedding_fn is not None:
        vector_embedding = embedding_fn(embedding_text)

        if hasattr(vector_embedding, "tolist"):
            vector_embedding = vector_embedding.tolist()

        if not isinstance(vector_embedding, list):
            raise ValueError(f"Embedding function must return a list, got {type(vector_embedding)}")

        if len(vector_embedding) != 1024:
            raise ValueError(f"Expected vector_embedding length 1024, got {len(vector_embedding)}")

        doc["vector_embedding"] = vector_embedding

    return doc
