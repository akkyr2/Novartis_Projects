from libs.dynamodb_client import DynamoDB
from libs.opensearch_client import knn_search_work_evidence, format_search_results
from agents.state import GraphState
from config import settings
from langgraph.types import Command
dynamo = DynamoDB()

def handle_retrieve_intent(intent_result, table_name=settings.work_items, answer_fn=None):
    
    """
    Handles retrieval requests by querying both structured work items (DynamoDB)
    and unstructured evidence (OpenSearch), then synthesizes a response.

    Returns a dictionary containing retrieved matches, supporting evidence,
    and a final answer (either generated or fallback).
    """

    project_name = intent_result.get("project_name", "")
    retrieval_query = intent_result.get("retrieval_query") or project_name or intent_result.get("title")

    work_items_df = dynamo.retrieve_work_items_df_from_intent_result(
        intent_result=intent_result,
        table_name=table_name,
    )

    decision_trace = [
        "Detected retrieve intent",
        f"Querying work_evidence for: {retrieval_query}"
    ]

    search_raw = knn_search_work_evidence(query_text=retrieval_query)
 
    evidence = format_search_results(search_raw)
    decision_trace.append(f"Retrieved {len(evidence)} evidence records from work_evidence")

    work_item_matches = dynamo.search_work_items(
        work_items_df,
        project_name=project_name,
        work_item_id=intent_result.get('work_item_id',''),
        title=intent_result.get('title', ''),
        assignee=intent_result.get('assignee','')
    )

    decision_trace.append(f"Matched {len(work_item_matches)} rows in work_items")

    if answer_fn:
        answer = answer_fn(retrieval_query, evidence, work_item_matches)
    else:
        if evidence:
            # Build a readable context block from top results
            parts = []
            for i, ev in enumerate(evidence[:3], 1):
                source = ev.get("source_uri") or ev.get("source_type") or "unknown source"
                doc = ev.get("document") or ev.get("summary") or ""
                if doc:
                    parts.append(f"[{i}] ({source})\n{doc}")
            answer = "\n\n".join(parts) if parts else "No relevant evidence found."
        else:
            answer = "No relevant evidence found."

    # Also format work item matches as readable text
    work_item_text = ""
    records = work_item_matches.to_dict(orient="records")
    if records:
        lines = []
        for row in records[:5]:
            lines.append(
                f"- Task: {row.get('task','')} | Assignee: {row.get('assignee','')} "
                f"| Status: {row.get('status','')} | Due: {row.get('due_date','')}"
            )
        work_item_text = "\n".join(lines)

    return {
        "mode": "retrieve",
        "decision_trace": decision_trace,
        "retrieved_evidence": evidence,
        "work_item_matches": records,
        "answer": answer,
        "work_item_text": work_item_text,
    }