from libs.dynamodb_client import DynamoDB
from utils.agent_prompts import build_adjudication_prompt
from utils.llm_utils import parse_llm_json, run_llm_adjudication
from libs.opensearch_client import confirmed_updated_item_to_work_evidence_record, index_document
from agents.state import GraphState
from config import settings
from langgraph.types import Command
from langgraph.graph import END
from utils.bedrock_client import BedrockClient
from datetime import datetime
dynamodb = DynamoDB()
bedrock = BedrockClient()


def build_updated_item_from_intent(previous_item, intent_result, user_text=None):
    """
    Creates an updated version of a work item by applying user intent changes.

    Compares previous and new values, updates modified fields,
    and returns both the updated item and list of changed fields.
    """

    user_text="\n".join(intent_result["chat_history"])
    if not previous_item:
        return None, []

    updated_item = dict(previous_item)
    changed_fields = []

    field_map = {
        "project_name": "project_name",
        "title": "task",
        "assignee": "assignee",
        "due_date": "due_date",
        "status": "status",
        "summary": "summary",
        "description": "summary"
    }

    for intent_key, item_key in field_map.items():
        new_value = intent_result.get(intent_key)
        if new_value is not None and str(new_value).strip() != "":
            old_value = previous_item.get(item_key)
            if str(old_value) != str(new_value):
                updated_item[item_key] = new_value
                changed_fields.append(item_key)

    updated_item["source_type"] = "user_input"
    changed_fields.append("source_type")

    updated_item["source_uri"] = "chat"
    changed_fields.append("source_uri")

    updated_item["event_timestamp"] = datetime.utcnow().isoformat()
    changed_fields.append("event_timestamp")

    if user_text:
        updated_item["task_evidence"] = user_text
        changed_fields.append("task_evidence")

    return updated_item, sorted(list(set(changed_fields)))


def handle_update_intent_with_llm(
    state,
    table_name=settings.work_items
):
    """
    Uses LLM-based adjudication to evaluate update requests by combining
    user intent, retrieved context, and historical evidence.

    Produces a decision object, updated item candidates, and next-step guidance.
    """

    context = dynamodb.gather_update_context(
        intent_result=state,
        table_name=settings.work_items,
        n_results=5
    )

    prompt = build_adjudication_prompt(
        intent_result=context["intent_result"],
        work_item_rows=context["work_item_matches"],
        evidence_rows=context["evidence"]
    )

    raw_llm_output = run_llm_adjudication(prompt)
    adjudication = parse_llm_json(raw_llm_output)

    resolution = dynamodb.resolve_selected_work_item_hybrid(
        intent_result=state,
        table_name=settings.work_items,
        top_k=5
        )

    previous_item = resolution.get("selected_item")

    updated_item = None
    changed_fields = []

    if previous_item is not None:
        updated_item, changed_fields = build_updated_item_from_intent(previous_item, state)

    if updated_item is not None:
        adjudication["previous_item"] = previous_item
        adjudication["updated_item"] = updated_item
        adjudication["affected_fields"] = changed_fields or adjudication.get("affected_fields", [])

        if adjudication.get("decision") == "apply_directly":
            adjudication["next_action"] = (
                "A matching work item was found and the requested changes were prepared. "
                "You can apply this update."
            )
        elif adjudication.get("decision") == "confirm_overwrite":
            adjudication["next_action"] = (
                "A matching work item was found and an updated version has been prepared. "
                "Historical evidence differs from the user request. Please confirm whether to overwrite the current item."
            )

    return {
        "mode": "update_review",
        "intent_result": state,
        "work_item_matches": context["work_item_matches"],
        "retrieved_evidence": context["evidence"],
        "adjudication": adjudication,
        "previous_item": previous_item,
        "updated_item": updated_item,
        "answer": adjudication.get("next_action", "No recommendation returned.")
    }


def update_node(state: GraphState) -> Command:
    """
    LangGraph node handling update flow: either runs adjudication step
    or commits confirmed updates to both OpenSearch and DynamoDB.

    Returns a Command object directing graph execution and carrying final response.
    """

    user_text="\n".join(state.get('chat_history', []))
    clarification_received=state.get("clarification_received", False)
    clarification_needed=state.get("clarification_needed", False)
    result_payload=state.get("result_payload", {})

    if not clarification_received or (clarification_received and clarification_needed):
        result = handle_update_intent_with_llm(
                state=state,
                table_name=settings.work_items
            )

    else:
        update_doc = confirmed_updated_item_to_work_evidence_record(user_text=user_text,
            intent_result=result_payload.get("intent_result"),
            adjudication=result_payload.get("adjudication"),
            previous_item=result_payload.get("previous_item"),
            updated_item=result_payload.get("updated_item"),
            user_confirmation=True,
            workspace_id="default-workspace",
            project_id="",
            source_uri="user_chat",
            embedding_fn=bedrock.vectorize_with_titan
            )
        response = index_document(doc=update_doc)
        dynamo_response = dynamodb.apply_confirmed_update_dynamodb(result_payload.get("updated_item"))
        print(f"Result of Updating the Opensearch index: {response['status_code']}\n{response['text']}")
        print(f"Result of Updating the Dynamo Db: {dynamo_response}\n")
        result="Succesfully Updated!"
    
    return Command(
        update={"final_response": result},
        goto=END
    )