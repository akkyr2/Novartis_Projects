from typing import TypedDict, List, Optional, Literal,Any, Dict

from langgraph.graph import StateGraph, END
from langgraph.types import Command
from langchain_aws import ChatBedrock

import json
import copy
import hashlib
import math
import re
from datetime import datetime, timezone
import boto3
from io import BytesIO
import random
import requests
from requests_aws4auth import AWS4Auth
import pandas as pd
from boto3.dynamodb.conditions import Key
import uuid
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

class GraphState(TypedDict, total=False):
    
    """
        Central state object passed across nodes in the LangGraph workflow.

        Stores user input, extracted intent fields, retrieval results,
        decision signals, and final response to coordinate multi-step agent execution.
    """

    user_input: str
    user_id: str
    session_id: str
    chat_history: List[str]
    result_payload: dict
    
    workspace_id: str
    project_id: str
    project_name: str

    reporter: str
    assignee: str
    assignees: List[str]

    intent: str

    work_item_id: str
    title: str
    description: str
    status: str
    priority: str
    due_date: str
    lifecycle_state: str
    is_deleted: bool

    blocker: str
    dependency: str
    issue: str
    summary: str
    decision: str
    action: str

    retrieval_query: str
    retrieval_plan: Dict[str, Any]
    work_items_results: List[Dict[str, Any]]
    work_evidence_results: List[Dict[str, Any]]
    retrieval_results: str

    resolved_work_item_id: str
    resolution_confidence: float
    conflict_flag: bool
    conflict_reason: str
    clarification_needed: bool
    clarification_question: str
    clarification_received: bool

    decision_type: str
    decision_reason: str
    action_plan: List[Dict[str, Any]]
    final_response: str