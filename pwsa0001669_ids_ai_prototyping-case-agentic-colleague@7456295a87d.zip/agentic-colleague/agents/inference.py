from utils.bedrock_client import BedrockClient
from langgraph.graph import StateGraph, END
from langgraph.types import Command
from agents.state import GraphState

bedrock = BedrockClient()

def inference_node(state: GraphState) -> Command:
    context = state.get("retrieval_results") or "No relevant information found."
    user_text = "\n".join(state.get("chat_history", []))

    prompt = f"""You are a helpful project assistant. Answer the user's question using ONLY the context below.
If the context does not contain the answer, say so clearly — do not make up information.

User question: {user_text}

Context:
{context}

Provide a clear, concise answer."""

    response = bedrock.generate(prompt)

    return Command(
        update={"final_response": response},
        goto=END
    )