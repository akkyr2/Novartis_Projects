from libs.dynamodb_client import DynamoDB
from utils.agent_prompts import build_create_adjudication_prompt
from utils.llm_utils import parse_llm_json
from libs.opensearch_client import confirmed_created_item_to_work_evidence_record, index_document
from langgraph.graph import StateGraph, END
from langgraph.types import Command
from agents.state import GraphState
from config import settings
from utils.bedrock_client import BedrockClient
dynamodb = DynamoDB()
bedrock = BedrockClient()

def handle_create_intent_with_llm(
    state,
    table_name=settings.work_items
):
    
    """
    Prepares and evaluates a create request using LLM-based adjudication.

    Builds a proposed work item, checks for potential duplicates (structured + semantic),
    and returns a decision payload guiding whether to proceed with creation.
    """

    proposed_item = dynamodb.build_proposed_work_item(state)

    candidate_info = dynamodb.gather_create_candidates(
        proposed_item=proposed_item
    )

    prompt = build_create_adjudication_prompt(
        intent_result=state,
        proposed_item=proposed_item,
        candidate_info=candidate_info
    )

    raw_llm_output = bedrock.generate(prompt)
    adjudication = parse_llm_json(raw_llm_output)

    return {
        "mode": "create_review",
        "intent_result": state,
        "proposed_item": proposed_item,
        "candidate_info": candidate_info,
        "adjudication": adjudication,
        "answer": adjudication.get("next_action", "No recommendation returned."),
        "llm_prompt": prompt,
        "llm_raw_output": raw_llm_output
    }


def create_node(state: GraphState) -> Command:
    
    """
    LangGraph node for handling create workflows.

    Executes a two-phase flow: first performs LLM-based validation and duplicate checks,
    then upon user confirmation, persists the new work item to OpenSearch and DynamoDB.
    """

    user_text="\n".join(state.get('chat_history', []))
    clarification_received=state.get("clarification_received", False)
    clarification_needed=state.get("clarification_needed", False)
    result_payload=state.get("result_payload", {})
    # first invocation
    if not clarification_received or (clarification_received and clarification_needed):
        result = handle_create_intent_with_llm(
                state=state,
                table_name=settings.work_items
                )

    # second invocation
    else:
        create_doc = confirmed_created_item_to_work_evidence_record(user_text=user_text,
            intent_result=result_payload.get("intent_result"),
            adjudication=result_payload.get("adjudication"),
            proposed_item=result_payload.get("proposed_item"),
            workspace_id="default-workspace",
            project_id="",
            source_uri="user_chat",
            embedding_fn=bedrock.vectorize_with_titan)
            
        response = index_document(doc=create_doc)
        dynamo_response = dynamodb.apply_confirmed_update_dynamodb(result_payload["proposed_item"])
        print(f"Result of Updating the Opensearch index: {response['status_code']}\n")
        print(f"Result of Updating the Dynamo Db: {dynamo_response}\n")
        result="Succesfully Created!"
    return Command(
        update={"final_response": result},
        goto=END
    )