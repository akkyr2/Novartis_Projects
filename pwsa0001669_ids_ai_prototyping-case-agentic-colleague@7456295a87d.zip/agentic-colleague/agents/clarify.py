from langgraph.graph import StateGraph, END
from langgraph.types import Command
from agents.state import GraphState

def clarify_node(state: GraphState) -> Command:

    
    """
    Handles ambiguity in user intent by requesting additional clarification.

    Sets clarification flags in the state and routes execution back to the user,
    ensuring downstream nodes only proceed when sufficient information is available.
    """

    question = "Can you clarify your request?"

    return Command(
        update={"clarification_question": question,"clarification_received": False, "clarification_needed":True},
        goto=END
    )