from agents.retrieve import handle_retrieve_intent
from utils.bedrock_client import BedrockClient
from agents.state import GraphState
from langgraph.types import Command
bedrock = BedrockClient()

def decision_node(state: GraphState) -> Command:
    
    """
    Entry routing node that parses user input into structured intent and directs workflow execution.

    Uses LLM-based parsing to extract intent and entities, optionally triggers clarification,
    and routes to retrieve, create, or update nodes based on interpreted intent.
    """

    user_text="\n".join(state["chat_history"])

    parser_prompt = f"""
        Parse the following user input into structured JSON.

        Return ONLY JSON. No explanation. No markdown.

        Intent classification rules:
        - Use "retrieve" when the user is asking a question, looking up information, mentioning a project/person/topic, or the input is a short phrase like a project name.
        - Use "create" only when the user clearly wants to add a new item.
        - Use "update" only when the user clearly wants to change an existing item.
        - Default to "retrieve" when intent is ambiguous — do NOT use "unknown" unless completely impossible to classify.

        User input:
        {user_text}

        Return JSON with exactly these fields:
        {{
        "intent": "retrieve|update|delete|create|unknown",
        "project_id": null,
        "project_name": null,
        "work_item_id": null,
        "title": null,
        "description": null,
        "reporter": null,
        "assignee": null,
        "status": null,
        "priority": null,
        "due_date": null,
        "blocker": null,
        "dependency": null,
        "issue": null,
        "summary": null,
        "retrieval_query": null,
        "clarification_needed": false,
        "clarification_question": null
        }}
        """
    cleaned_response = clean_llm_output(bedrock.generate_json(parser_prompt).content)
    try:
        parsed_response_dict = json.loads(cleaned_response)
        intent = parsed_response_dict["intent"]

        # ── Enrich retrieval_query: fall back to full user text so short
        #    inputs like "project apollo" still produce a meaningful KNN search
        if not parsed_response_dict.get("retrieval_query"):
            parsed_response_dict["retrieval_query"] = (
                parsed_response_dict.get("project_name")
                or parsed_response_dict.get("title")
                or parsed_response_dict.get("summary")
                or user_text
            )

        context=handle_retrieve_intent(
            parsed_response_dict,
            table_name=work_items,
        )
                         
        # Routing logic

        if state.get("clarification_received"):
            clarification_response = bedrock.generate_json(f"""Is more clarification needed from the user to answer the user's query
        or is the context provided enough to answer, also take into consideration the user's intent, Answer only in YES or NO.\n
        User Query: {user_text}\n Context: {context}\n User intent: {intent}\n
        Answer only in YES or NO. DO NOT give any explaination""").content
            if "YES" in clarification_response:
                clarification_needed=True
            else:
                clarification_needed=False
            if clarification_needed:
                return Command(
                    update={
                        **parsed_response_dict,
                        "chathistory" :user_text,
                        "clarification_needed": True
                    },
                    goto="clarify"
                )
            else:
                if intent == "create":
                    return Command(update={**parsed_response_dict,"clarification_needed":False,"clarification_received":True}, goto="create")
                else:
                    return Command(update={**parsed_response_dict,"clarification_needed":False,"clarification_received":True}, goto="update")
        else: 
            if intent == "retrieve" or intent == "unknown":
                # Build a clean readable string for the LLM — avoids noise from the full dict
                evidence_text = context.get("answer", "")
                work_item_text = context.get("work_item_text", "")
                retrieval_results = evidence_text
                if work_item_text:
                    retrieval_results += "\n\nWork Items:\n" + work_item_text
                return Command(
                    update={
                        **parsed_response_dict,
                        "clarification_needed": False,
                        "retrieval_results": retrieval_results or "No relevant information found."
                    },
                    goto="inference"
                )

            elif intent == "create":
                return Command(update={**parsed_response_dict}, goto="create")

            else:  # update / delete
                return Command(update={**parsed_response_dict}, goto="update")

    except Exception as e:
        return f"issue in parsing json {e}"