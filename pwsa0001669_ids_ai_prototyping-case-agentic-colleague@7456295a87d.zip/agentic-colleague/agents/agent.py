from agents.clarify import clarify_node
from agents.decision import decision_node
from agents.update import update_node
from agents.create import create_node
from agents.inference import inference_node
from langgraph.graph import StateGraph, END
from langgraph.types import Command
from agents.state import GraphState

def build_graph():
    builder = StateGraph(GraphState)

    # Add nodes
    builder.add_node("decision", decision_node)
    builder.add_node("inference", inference_node)
    builder.add_node("create", create_node)
    builder.add_node("update", update_node)
    builder.add_node("clarify", clarify_node)
    # # add edges
    # builder.add_edge(START,"decision")
    # builder.add_edge("decision",END)
    
    builder.set_entry_point("decision")

    # Compile
    return builder.compile()