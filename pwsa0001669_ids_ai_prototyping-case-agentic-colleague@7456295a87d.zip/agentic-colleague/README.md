**Project structure**
```bash
agentic-colleague/
│
├── libs/
│   ├── dynamodb_client.py        # Handles structured storage, retrieval, and similarity matching using DynamoDB
│   ├── opensearch_client.py      # Manages vector indexing, KNN search, and evidence retrieval in OpenSearch
│   ├── cleaning_agent.py         # Uses LLM to normalize and structure raw input data
│   └── user_upload_agent.py      # Processes user-uploaded files (DOCX/images, S3 ingestion)
│
├── utils/
│   ├── bedrock_client.py         # Wrapper for AWS Bedrock LLM + embeddings
│   ├── llm_utils.py              # Parsing, cleaning, and formatting LLM responses
│   ├── agent_prompts.py          # Prompt templates for create/update adjudication
│   ├── data_ingestion_prompts.py # Prompt templates for ingestion/cleaning tasks
│   ├── image_utils.py            # Image preprocessing and encoding utilities
│   └── storage_utils.py          # Generic data storage helpers
│
├── agents/
│   ├── state.py                  # Central GraphState definition shared across all nodes
│   ├── decision.py               # Entry node: parses intent and routes execution
│   ├── retrieve.py               # Retrieves structured + semantic context
│   ├── inference.py              # Generates final response from retrieved context
│   ├── create.py                 # Handles create workflow (LLM adjudication + persistence)
│   ├── update.py                 # Handles update workflow (LLM adjudication + confirmation)
│   └── clarify.py (implicit)     # Clarification node for resolving ambiguity in user intent
│
├── main.py                       # Local orchestration entrypoint (LangGraph workflow definition)
│
└── final_agent/                  # Production deployment package
    ├── main.py                   # Deployed inference entrypoint used in Docker container
    ├── eval.py                   # Evaluation and testing scripts
    └── Dockerfile                # Container definition for deployment
```

**Architecture Overview**

agents/ → Orchestration layer (LangGraph nodes)

libs/ → Data + storage + transformation layer

utils/ → Shared helpers (LLM, prompts, preprocessing)

final_agent/ → Production-ready deployment bundle

**High level execution flow**
```bash
User Input
   ↓
decision.py (intent parsing)
   ↓
[retrieve | create | update | clarify]
   ↓
(optional) inference.py
   ↓
Final Response
```


**Miscelleneous files (stored in misc)**

- kanban.ipynb - contains code that I used to create a kanban board from the existing s3 files
- created_indices.ipynb - contains the code I used to create vectordb work indices
- delete_from_dynamodb.py - contains code that can be used in the future inside a delete_node that we do not have currently

**Deployment steps**
How to deploy the app:

1. Find agentic-colleague folder inside the projects folder in the ec2
2. Enter the folder named "final_agent"
3. docker build in case there is not an existing docker
4. docker run
5. update default.conf
6. restart nginx incase you get an error on the startup of nginx

**Link of the deployed application**
https://idsprotowork.dev.aws.novartis.net/agentic_colleague/

**Capabilities of the application so far**:

1. The chatbot has the capability to search the vectordb (work_evidence) in AWS Opensearch serverless.
2. The chatbot has the capability to search work items from the dynamodb using keyword search as well as semantic search. This is useful for future when users add items to the kanban board, but doesn't necessary have supporting vectordb evidence.
3. The chatbot can update an existing item if it can retrieve it accurately. Most times we have found that it was able to retrieve items with high accuracy.
4. The chatbot can create new items. The function - apply_confirmed_update_dynamodb is used to add this new item into the dynamodb which updates in real-time.

**Improvements/enhancements for developers**

1. Search can be more intelligent by further enhancing the function - knn_search_work_evidence. Enhancement of this search can be improved but was not explored yet.
2. Updation of items require a structure with necessary fields that a user MUST provide such as project name, assignee, task, due date, etc. These fields are stored in the agent state memory, but not strictly or explicitly implemented. (The chatbot does not ask to provide missing fields).
3. Creation of items also require a structure with necessary fields that a user MUST provide.
4. eval.py contains evaluation to measure - relevancy, faithfullness and completeness. This evaluation uses an LLM as a judge. Evaluation pipeline can be further enhanced by measuring relevant searches are retrieved from the vectordb and dynamodb. Increasing recall here (relevant retrieved/all relevant).
5. No monitoring/governance metrics/pipeline in place.