"""
Quick fix for two tasks in DynamoDB:
1. 'Finalize field materials with approved messaging' → Rachel Kim / Noventra IPST / 2026-05-01 / At Risk
2. 'Build POC v0.5 core features' → status = pending (moves to To Do)
"""
import boto3

dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
table = dynamodb.Table("AgenticColleague_KanbanTasks_Draft")

# Scan all items
items = []
response = table.scan()
items.extend(response.get("Items", []))
while "LastEvaluatedKey" in response:
    response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
    items.extend(response.get("Items", []))

FIXES = [
    {
        "keyword": "finalize field materials with approved messaging",
        "updates": {
            ":a": "Rachel Kim",
            ":p": "Noventra IPST",
            ":d": "2026-05-01",
            ":s": "At Risk",
        },
        "expression": "SET assigned_to = :a, project_name = :p, due_date = :d, #st = :s",
    },
    {
        "keyword": "build poc v0.5 core features",
        "updates": {
            ":s": "pending",
        },
        "expression": "SET #st = :s",
    },
]

for fix in FIXES:
    keyword = fix["keyword"]
    matches = [i for i in items if keyword in (i.get("task") or "").lower()]
    if not matches:
        print(f"❌ Not found: {keyword}")
        continue
    for item in matches:
        pk, sk = item["PK"], item["SK"]
        print(f"Found: PK={pk}  SK={sk}  status={item.get('status')}  assigned={item.get('assigned_to')}")
        table.update_item(
            Key={"PK": pk, "SK": sk},
            UpdateExpression=fix["expression"],
            ExpressionAttributeNames={"#st": "status"},
            ExpressionAttributeValues=fix["updates"],
        )
        print(f"✅ Fixed: {keyword}")

