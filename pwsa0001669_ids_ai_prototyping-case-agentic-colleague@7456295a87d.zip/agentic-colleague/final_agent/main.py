#!/usr/bin/env python
# coding: utf-8

# In[57]:


# start->decision node->if no clarification received extract intent-> retrieve->
# if intent is retrieve -> answer synthesizer -> END -> chatbot UI
# if intent is not retrieve -> check if clarification is needed
# if clarification needed -> clarifying node -> UI -> clarification sent along with chat history -> decision node detects clarification received -> sends it to clarification node or update or create
# if no clarification needed -> update or create node -> END


# In[58]:


import os
# os.environ['HTTP_PROXY']="http://proxy-usvn.aws.novartis.net:3128"
# os.environ['HTTPS_PROXY']="http://proxy-usvn.aws.novartis.net:3128"


# In[59]:


# get_ipython().system('pip install langgraph langchain langchain_aws requests_aws4auth')


# In[60]:


# os.environ["no_proxy"] = "127.*,[::1],*.local,160.61.1.65,160.61.112.195,160.61.112.195,169.254.170.2,162.86.78.177,170.60.112.198,170.236.0.86,170.236.114.155,169.254.169.254,localhost,127.0.0.1,10.180.104.95,10.180.104.57,10.180.105.175,10.100.0.0/16,172.20.0.0/16,sts.novartis.com,.s3.eu-west-1.amazonaws.com,.s3.dualstack.eu-west-1.amazonaws.com,.s3.eu-central-1.amazonaws.com,.s3.dualstack.eu-central-1.amazonaws.com,.novartis.net,.internal,api.ecr.us-east-1.amazonaws.com,dkr.ecr.us-east-1.amazonaws.com,ec2.us-east-1.amazonaws.com,.eu-west-1.eks.amazonaws.com,.us-east-1.eks.amazonaws.com,.s3.eu-west-1.amazonaws.com,api.ecr.eu-west-1.amazonaws.com,dkr.ecr.eu-west-1.amazonaws.com,ec2.eu-west-1.amazonaws.com,*.s3.amazonaws.com,s3.amazonaws.com,com.amazonaws.us-east-1.s3,*.s3.us-east-1.amazonaws.com,s3.us-east-1.amazonaws.com,*.s3.dualstack.us-east-1.amazonaws.com,*.s3-external-1.amazonaws.com,*.s3-accesspoint.us-east-1.amazonaws.com,*.s3-accesspoint.dualstack.us-east-1.amazonaws.com,*.rds.amazonaws.com,*.rds.us-east-1.amazonaws.com,*.sts.us-east-1.amazonaws.com,execute-api.us-east-1.amazonaws.com,*.execute-api.us-east-1.amazonaws.com,sts.us-east-1.amazonaws.com,*.sts.amazonaws.com,sts.amazonaws.com,glue.us-east-1.amazonaws.com,*.glue.us-east-1.amazonaws.com,glue.amazonaws.com,*.glue.amazonaws.com,sts.amazonaws.com,.privatelink.snowflakecomputing.com,*.privatelink.snowflakecomputing.com,*.azure.com,.cloud.databricks.com,*.novartis.com,bedrock-runtime.us-east-1.amazonaws.com,artifactory.f1.novartis.net,bitbucketenterprise.aws.novartis.net"


# In[62]:


from typing import TypedDict, List, Optional, Literal,Any, Dict

from langgraph.graph import StateGraph, END
from langgraph.types import Command
from langchain_aws import ChatBedrock

import json
import copy
import hashlib
import math
import re
from datetime import datetime, timezone
import boto3
from io import BytesIO
import random
import requests
from requests_aws4auth import AWS4Auth
import pandas as pd
from boto3.dynamodb.conditions import Key
import uuid
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from pydantic import BaseModel
import markdown
from decimal import Decimal
from docx import Document
import base64
import logging
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi import UploadFile, File, Form

# evaluation 
from eval import evaluation, load_records

# adding eval logs in a separate file
logging.basicConfig(
    filename="eval_logs.txt",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

logger = logging.getLogger(__name__)
dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
work_items = "AgenticColleague_WorkItems"
vectordb_index="work_evidence"

# ── IPST Function Map ─────────────────────────────────────────────────────────
# Maps IPST team member names to their function/role.
# Update with real IPST member names + functions before the summit demo.
# Example functions: CE, Medical, GM, IMO, Regulatory, Market Access, Finance
IPST_FUNCTION_MAP: dict = {
    # ── Demo / POC team (Apollo project) ──
    "Tom Barry":          "GM",
    "Tom":                "GM",
    "Stan Tsvirko":       "Sponsor",
    "Stan":               "Sponsor",
    "Saburi Mohan":       "IMO",
    "Saburi":             "IMO",
    "Satya Shukla":       "CE",
    "Satya":              "CE",
    "Ash":                "Medical",
    "Revath":             "Regulatory",
    "Mohan Dhanalakota":  "Market Access",
    "Mohan":              "Market Access",
    "Sarah Chen":         "Business Lead",
    "Sarah":              "Business Lead",
    "Nina Patel":         "Bus. Excellence",
    "Nina":               "Bus. Excellence",
    "Dr. Priya Nair":     "Medical",
    "Dr Priya Nair":      "Medical",
    "Priya Nair":         "Medical",
    "Priya":              "Medical",
    "Luis Martinez":      "Market Access",
    "Luis":               "Market Access",
    "Mark Davidson":      "Finance",
    "Mark":               "Finance",
    "Jake Reynolds":      "Marketing",
    "Jake":               "Marketing",
    "Rachel Kim":         "Field Strategy",
    "Rachel":             "Field Strategy",
    # ── Add real IPST team members below before the demo ──
    # "First Last": "Function",
}

# ──────────────────────────────────────────────────────────────────────────────
# DEMO CANNED Q&A  (IPST Summit · June 9, 2026 · as-of April 20, 2026)
# When a user's message matches a key (after normalization), the stored answer
# is returned immediately — no LLM call, no regeneration.
# ──────────────────────────────────────────────────────────────────────────────
import re as _re

def _normalize_q(text: str) -> str:
    """Lowercase, strip whitespace and trailing punctuation for matching."""
    return _re.sub(r'[?.!,;:]+$', '', text.strip().lower())

CANNED_QA: dict = {
    _normalize_q("Compare the latest IPST Core and Extended meetings, chats, emails, and tracker updates. Tell me what changed, what conflicts, and what the Team Board should now show."): """As of today (April 20, 2026), the Noventra IPST is still targeting the October 2026 launch, but Launch Readiness Review (LRR) remains At Risk.

### Latest updates:

- Dr. Priya Nair (Medical SPOC) completed the evidence review later than planned.
- Luis Martinez (Market Access SPOC) is behind schedule with finalizing the access strategy due to delayed market research results.
- The Target Product Profile (TPP) cannot be finalized until Medical and Market Access inputs are reconciled. All other TPP inputs are completed.
- Mark Davidson (Forecasting) prepared a provisional forecast scenario, but the forecast cannot be locked until the TPP is finalized.
- Sarah Chen (BEL) is keeping Launch Readiness flagged At Risk until the cross-functional inputs are aligned and the next decision path is clear.
- LRR pre-reads are due next week, legal review required before pre-reads go to Victor and US LT.

### Kanban Board update:

- Launch Readiness should remain At Risk.
- Forecast Lock should remain Provisional / At Risk until the TPP is finalized.
- The Kanban Board should show a new dependency between Medical Evidence, Market Access assumptions, TPP finalization, and Forecasting.

### Assignments:

| Name | Function / Role | Task | Due Date | Status |
| --- | --- | --- | --- | --- |
| Dr. Priya Nair | Medical | Medical Evidence Review | 2026-04-15 | Done — completed later than planned |
| Luis Martinez | Market Access | Finalize Access Research and Assumptions | 2026-04-22 | At Risk |
| Sarah Chen | BEL | Confirm Launch Readiness Status and Decision Log | 2026-04-22 | At Risk |
| Priya Nair + Luis Martinez | Medical + Market Access | Reconcile Inputs for TPP | 2026-04-23 | In Progress |
| Mark Davidson | Forecasting | Update Forecast Based on Final TPP | 2026-04-24 | Provisional / At Risk |
""",

    _normalize_q("For the TPP and forecasting issue, I need to understand what happened and how we got here."): """As of today (April 20, 2026), here is the TPP and forecasting timeline.

### Team Meeting – April 8, 2026:

Dr. Priya Nair (Medical) flagged that the evidence review would be completed later than planned.

### Team Channel Conversation – April 9, 2026:

Luis Martinez (Market Access) flagged that updated access research and assumptions were still being refined. Sarah Chen (BEL) noted that the team needed one aligned view before the TPP could be finalized.

### Email Update – April 10, 2026:

Mark Davidson (Forecasting) prepared a provisional forecast scenario so the team could keep moving, but clearly marked the forecast as dependent on final TPP finalization.

### Current Status – April 20, 2026:

Forecast Lock remains Provisional / At Risk until the TPP is finalized using aligned Medical and Market Access inputs.

### Upcoming Critical Milestone:

Noventra's next LRR is on June 8, 2026. Victor specifically asked for a confirmed TPP and Integrated Evidence Plan (IEP) for that LRR, as further delays will jeopardize the target launch date.

### Open work items related to the TPP and forecasting issue:

| Name | Function / Role | Task | Due Date | Status |
| --- | --- | --- | --- | --- |
| Dr. Priya Nair | Medical | Medical Evidence Review | 2026-04-15 | Done — completed later than planned |
| Luis Martinez | Market Access | Finalize Access Research and Assumptions | 2026-04-22 | At Risk |
| Priya Nair + Luis Martinez | Medical + Market Access | Reconcile Inputs for TPP | 2026-04-23 | In Progress |
| Mark Davidson | Forecasting | Forecast Lock | 2026-04-24 | Provisional / At Risk |
| Sarah Chen | BEL | Confirm TPP Decision Path for upcoming LRR | 2026-04-24 | At Risk |
""",

    _normalize_q("Yes, I need to prepare for that LRR. Based on our prior LRRs and recent IPST activity, what topics are likely to come up again, and how should the team prepare?"): """Yes, based on previous LRRs Noventra's Launch Readiness at risk is the top priority for the upcoming LRR on June 8, 2026. The IPST should prepare a scenario-based decision matrix on whether to delay Noventra's launch if the TPP and IEP are not finalized before June 8.

### What prior LRRs discussed:

Prior Noventra LRRs focused on whether the product profile was mature enough to support downstream launch planning. The TPP and IEP are now the key cross-functional dependency because they require aligned input from Medical, Market Access, Marketing / GM, and Forecasting.

### How the team should prepare:

- Update the Launch Readiness slide to show "At Risk" and explain why.
- Prepare a decision matrix for whether to delay the Noventra launch.
- Add a TPP and IEP dependency slide showing required inputs from Medical, Market Access, Marketing / GM, and Forecasting.
- Add a Forecasting slide that clearly labels the current scenario as provisional.
- Add a final decision slide with the specific asks for the US LT.

### Suggested owners for LRR preparation:

Here's how I would suggest the team work together to prepare for the upcoming LRR.

| Owner | Role | Preparation responsibility |
| --- | --- | --- |
| Sarah Chen | BEL | Maintain launch readiness status, decision log, and owner/date table. |
| Sarah Chen | BEL | Frame the LRR decision asks and confirm what leadership needs to resolve. |
| Dr. Priya Nair | Medical | Confirm evidence of inputs available for TPP use. |
| Luis Martinez | Market Access | Confirm updated access assumptions. |
| Mark Davidson | Forecasting | Update forecast once TPP inputs are finalized. |
| IDS partner | IDS | Support deck updates and data views for the LRR package. |
""",
}

app = FastAPI()

# Allow frontend origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500", "http://localhost:5500", "http://localhost:3000","http://localhost:8000", "*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Auto-seed required Noventra IPST tasks on startup ─────────────────────────
_SEED_PROJECT = "Noventra IPST"
_SEED_PK = f"PROJECT#{_SEED_PROJECT}"
_SEED_TASKS = [
    # ── Canned Scenario 1 & 2 tasks ──────────────────────────────────────────
    {"task": "Medical Evidence Review",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "done",
     "summary": "Completed later than planned. Inputs now available for TPP."},

    {"task": "Finalize Access Research and Assumptions",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Behind schedule due to delayed market research results. Blocking TPP finalization."},

    {"task": "Finalize Access Strategy",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Access strategy cannot be finalized until market research results are confirmed."},

    {"task": "Confirm Launch Readiness Status and Decision Log",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Sarah Chen maintaining launch readiness status and decision log. Currently At Risk."},

    {"task": "Reconcile Inputs for TPP",
     "assigned_to": "Priya Nair + Luis Martinez", "ipst_function": "Medical + Market Access",
     "due_date": "2026-04-23", "status": "in progress",
     "summary": "Medical and Market Access inputs must be reconciled before TPP can be finalized."},

    {"task": "Update Forecast Based on Final TPP",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Provisional forecast prepared. Cannot be locked until TPP inputs are finalized."},

    {"task": "Forecast Lock",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Provisional / At Risk. Dependent on TPP finalization."},

    {"task": "Confirm TPP Decision Path for upcoming LRR",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Sarah Chen to confirm TPP decision path ahead of June 8 LRR."},

    # ── Q1: Blockers ──────────────────────────────────────────────────────────
    {"task": "Payer Objection Handling Plan",
     "assigned_to": "Unassigned", "ipst_function": "Cross-Functional",
     "due_date": "", "status": "pending",
     "summary": "Blocked — no function has confirmed ownership. Market Access and Field Strategy need to align."},

    {"task": "Resolve TPP Input Dependency",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-25", "status": "in progress",
     "summary": "Cross-functional blocker: TPP cannot be finalized until Medical and Market Access inputs are reconciled."},

    {"task": "Decide on forecast submission approach",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Decision needed on whether to proceed with broad access assumptions or request extension."},

    {"task": "Finalize launch forecast assumptions",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-10", "status": "pending",
     "summary": "Finance needs to lock forecast assumptions but cannot proceed without access strategy clarity."},

    {"task": "Provide Medical evidence inputs for access strategy",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Medical evidence inputs required before access strategy decision can be finalized."},

    # ── Q2: Decisions ─────────────────────────────────────────────────────────
    {"task": "Log LRR Decision — TPP Finalization Path",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Decision: team agreed to reconcile Medical and Market Access inputs before locking TPP."},

    {"task": "Record decisions in action log",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "", "status": "pending",
     "summary": "Nina Patel to record all cross-functional decisions in the action log."},

    {"task": "Prepare field training with placeholder messaging",
     "assigned_to": "Rachel Kim", "ipst_function": "Field Strategy",
     "due_date": "", "status": "pending",
     "summary": "Field training materials to use provisional messaging until Medical approval obtained."},

    {"task": "Escalate forecast timing issue to Finance VP",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Informally escalate to Finance VP to gauge acceptance of caveated forecast before requesting formal extension."},

    {"task": "Submit forecast or request extension",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-10", "status": "pending",
     "summary": "Submit provisional launch forecast with caveats or request a formal extension."},

    {"task": "Provide preliminary medical evidence readout",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-13", "status": "pending",
     "summary": "Provide preliminary medical evidence readout to unblock access strategy work."},

    # ── Q3: Risks ─────────────────────────────────────────────────────────────
    {"task": "Launch Readiness Review",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-10-01", "status": "in progress",
     "summary": "Launch Readiness At Risk. Cross-functional inputs not yet aligned."},

    {"task": "Update Launch Readiness Slide for LRR",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-06-06", "status": "pending",
     "summary": "Update slide to show At Risk status and explain dependency chain for June 8 LRR."},

    {"task": "Support deck updates and data views for the LRR package",
     "assigned_to": "IDS partner", "ipst_function": "IDS",
     "due_date": "2026-06-06", "status": "pending",
     "summary": "IDS partner to support deck updates and data views for the LRR package."},

    {"task": "Prepare updated status view",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Nina Patel to prepare updated launch readiness status view for IPST sync."},

    {"task": "Finalize access strategy decision",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-30", "status": "pending",
     "summary": "Access strategy decision required to unblock forecast and field materials."},

    {"task": "Prepare leadership progress update",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-23", "status": "pending",
     "summary": "Sarah Chen to prepare leadership progress update on launch readiness."},

    # ── Q4: Action Items ──────────────────────────────────────────────────────
    {"task": "Confirm Access Assumptions for TPP",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Action item: Luis Martinez to confirm updated access assumptions."},

    {"task": "Confirm Medical Evidence Inputs for TPP",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Action item: Priya Nair to confirm evidence inputs are available for TPP use."},

    {"task": "Submit forecast with broad access assumptions",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-16", "status": "pending",
     "summary": "Submit forecast using broad payer access assumption as working scenario."},

    {"task": "Provide preliminary access insights",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Provide preliminary access insights to support Market Access strategy work."},

    {"task": "Complete clinical evidence review (subgroup analysis)",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Complete clinical subgroup analysis — delayed by ~1 week due to data complexities."},

    {"task": "Document provisional forecast decision",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "", "status": "pending",
     "summary": "Document the decision to proceed with provisional forecast using broad access assumptions."},

    # ── Q5: Pending Tasks ─────────────────────────────────────────────────────
    {"task": "Finalize Field Materials with Approved Messaging",
     "assigned_to": "Rachel Kim", "ipst_function": "Field Strategy",
     "due_date": "2026-05-01", "status": "in progress",
     "summary": "Rachel Kim to finalize field materials with approved messaging."},

    {"task": "Complete Field Training Content",
     "assigned_to": "Rachel Kim", "ipst_function": "Field Strategy",
     "due_date": "2026-05-15", "status": "pending",
     "summary": "Rachel Kim to complete field training content. Pending Payer Objection Handling Plan."},

    {"task": "Prepare LRR Decision Matrix",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-06-06", "status": "pending",
     "summary": "Decision matrix on whether to delay Noventra launch if TPP and IEP not finalized before June 8 LRR."},

    {"task": "Update decision log",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Update the team decision log with latest cross-functional decisions."},

    {"task": "Decide on forecast lock delay",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Decision needed on whether to delay the forecast lock given pending Medical evidence."},

    {"task": "Confirm timeline accommodation for one-week shift",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Luis Martinez to confirm whether Market Access can accommodate a one-week timeline shift."},

    {"task": "Discuss timeline impacts at IPST sync",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Sarah Chen to lead discussion on timeline impacts at the next IPST sync meeting."},

    # ── Q6: Access Strategy Status ────────────────────────────────────────────
    {"task": "Complete Updated Payer Materials",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-24", "status": "pending",
     "summary": "Not ready — dependent on finalized access strategy."},

    {"task": "Complete Medical evidence review",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Subgroup analysis delayed ~1 week due to data complexities. Blocking access strategy."},
]

@app.on_event("startup")
def seed_kanban_tasks():
    """Insert required demo tasks into KanbanTasks_Draft on every startup.
    Always upserts — guarantees correct data on every deploy."""
    try:
        _seed_table = dynamodb_resource.Table("AgenticColleague_KanbanTasks_Draft")
        _now = datetime.now(timezone.utc).isoformat()
        _upserted = 0
        for t in _SEED_TASKS:
            _task_id = t["task"].lower().replace(" ", "_").replace("/", "_")[:40]
            _sk = f"TASK#{_task_id}"
            try:
                _seed_table.put_item(
                    Item={
                        "PK": _SEED_PK,
                        "SK": _sk,
                        "task_id": _task_id,
                        "project_name": _SEED_PROJECT,
                        "task": t["task"],
                        "assigned_to": t["assigned_to"],
                        "ipst_function": t["ipst_function"],
                        "due_date": t.get("due_date", ""),
                        "status": t["status"],
                        "summary": t.get("summary", ""),
                        "source_type": "auto_seed",
                        "source_uri": "startup",
                        "event_timestamp": _now,
                        "updated_at": _now,
                    }
                    # No condition — always upsert so task is guaranteed correct
                )
                _upserted += 1
            except Exception as _ce:
                print(f"[SEED] Error upserting '{t['task']}': {_ce}")
        print(f"[SEED] Startup seeding complete — {_upserted} tasks upserted (guaranteed on board).")
    except Exception as _e:
        print(f"[SEED] Startup seeding failed (non-fatal): {_e}")
# ──────────────────────────────────────────────────────────────────────────────

# In[63]:


class GraphState(TypedDict, total=False):
    user_input: str
    user_id: str
    session_id: str
    chat_history: List[str]
    result_payload: dict
    
    workspace_id: str
    project_id: str
    project_name: str

    reporter: str
    assignee: str
    assignees: List[str]

    intent: str

    work_item_id: str
    title: str
    description: str
    status: str
    priority: str
    due_date: str
    lifecycle_state: str
    is_deleted: bool

    blocker: str
    dependency: str
    issue: str
    summary: str
    decision: str
    action: str

    retrieval_query: str
    retrieval_plan: Dict[str, Any]
    work_items_results: List[Dict[str, Any]]
    work_evidence_results: List[Dict[str, Any]]
    retrieval_results: Any

    resolved_work_item_id: str
    resolution_confidence: float
    conflict_flag: bool
    conflict_reason: str
    clarification_needed: bool
    clarification_question: str
    clarification_received: bool

    decision_type: str
    decision_reason: str
    action_plan: List[Dict[str, Any]]
    final_response: str


# In[64]:


s3 = boto3.client('s3', region_name="us-east-1")
bucket_name = "ids-aini-prototype-ai-analytics"
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
titan_v2_embedding_modelId = "amazon.titan-embed-text-v2:0"
model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
host = "https://oqjh772goqkmg0mlp7gg.us-east-1.aoss.amazonaws.com"

region = "us-east-1"
service = "aoss"
host = "https://oqjh772goqkmg0mlp7gg.us-east-1.aoss.amazonaws.com"

session = boto3.Session()
credentials = session.get_credentials()
awsauth = AWS4Auth(
    credentials.access_key,
    credentials.secret_key,
    region,
    service,
    session_token=credentials.token
)

headers = {"Content-Type": "application/json"}
llm = ChatBedrock(
        model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        region_name="us-east-1",
        model_kwargs={
            "temperature": 0.1,
            "max_tokens": 2056, # maximum output tokens
        },
    )


# In[65]:


def clean_llm_output(text: str) -> str:
    text = text.strip()

    # Remove ```json ... ``` or ``` ... ```
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)

    # Remove leading 'json' if present
    if text.lower().startswith("json"):
        text = text[4:].strip()

    return text.strip()
    
import json

def pretty_print_adjudication(result):
    output = []

    def add(line=""):
        output.append(line)

    mode = result.get("mode", "unknown")
    add(f"\nMODE: {mode}")

    adjudication = result.get("adjudication", {})

    if not adjudication:
        add("\nANSWER:")
        answer = result.get("answer", "")
        if isinstance(answer, str):
            add(answer.replace("\\n", "\n"))
        else:
            add(json.dumps(answer, indent=2, default=str))

        retrieved_evidence = result.get("retrieved_evidence", [])
        work_item_matches = result.get("work_item_matches", [])

        if retrieved_evidence:
            add(f"\nRETRIEVED EVIDENCE COUNT: {len(retrieved_evidence)}")

        if work_item_matches:
            add(f"\nWORK ITEM MATCH COUNT: {len(work_item_matches)}")

        return "\n".join(output)

    if "update" in mode:
        add("\nDECISION: " + str(adjudication.get("decision")))
        add("SHOULD UPDATE: " + str(adjudication.get("should_update")))
        add("CONFIDENCE: " + str(adjudication.get("confidence")))
        add("USER SIGNAL: " + str(adjudication.get("user_signal_strength")))
        add("HISTORICAL SIGNAL: " + str(adjudication.get("historical_signal_strength")))

        add("\nAFFECTED FIELDS:")
        affected_fields = adjudication.get("affected_fields", [])
        if affected_fields:
            for field in affected_fields:
                add(f"- {field}")
        else:
            add("- None")

        add("\nREASONING SUMMARY:")
        reasoning_summary = adjudication.get("reasoning_summary", [])
        if reasoning_summary:
            for line in reasoning_summary:
                add(f"- {line}")
        else:
            add("- None")

        add("\nCURRENT STATE SUMMARY:")
        add(json.dumps(adjudication.get("current_state_summary", {}), indent=2, default=str))

        add("\nPROPOSED STATE SUMMARY:")
        add(json.dumps(adjudication.get("proposed_state_summary", {}), indent=2, default=str))

        add("\nNEXT ACTION:")
        add(str(adjudication.get("next_action")))

    elif "create" in mode:
        add("\nDECISION: " + str(adjudication.get("decision")))
        add("SHOULD CREATE: " + str(adjudication.get("should_create")))
        add("CONFIDENCE: " + str(adjudication.get("confidence")))

        add("\nREASONING SUMMARY:")
        reasoning_summary = adjudication.get("reasoning_summary", [])
        if reasoning_summary:
            for line in reasoning_summary:
                add(f"- {line}")
        else:
            add("- None")

        add("\nSELECTED EXISTING WORK ITEM ID:")
        add(str(adjudication.get("selected_existing_work_item_id")))

        add("\nCANDIDATE DUPLICATE IDS:")
        duplicate_ids = adjudication.get("candidate_duplicate_ids", [])
        if duplicate_ids:
            for item in duplicate_ids:
                add(f"- {item}")
        else:
            add("- None")

        add("\nPROPOSED STATE SUMMARY:")
        add(json.dumps(adjudication.get("proposed_state_summary", {}), indent=2, default=str))

        add("\nCURRENT STATE SUMMARY:")
        add(json.dumps(adjudication.get("current_state_summary", {}), indent=2, default=str))

        add("\nCLARIFICATION QUESTION:")
        add(str(adjudication.get("clarification_question")))

        add("\nNEXT ACTION:")
        add(str(adjudication.get("next_action")))

        proposed_item = result.get("proposed_item")
        if proposed_item:
            add("\nPROPOSED ITEM:")
            add(json.dumps(proposed_item, indent=2, default=str))

        candidate_info = result.get("candidate_info", {})
        if candidate_info:
            structured_candidates = candidate_info.get("structured_candidates", [])
            semantic_candidates = candidate_info.get("semantic_candidates", [])

            add(f"\nSTRUCTURED CANDIDATES COUNT: {len(structured_candidates)}")
            for idx, candidate in enumerate(structured_candidates[:3], start=1):
                add(f"\nSTRUCTURED CANDIDATE {idx}:")
                add(json.dumps(candidate, indent=2, default=str))

            add(f"\nSEMANTIC CANDIDATES COUNT: {len(semantic_candidates)}")
            for idx, candidate in enumerate(semantic_candidates[:3], start=1):
                add(f"\nSEMANTIC CANDIDATE {idx}:")
                add(json.dumps(candidate, indent=2, default=str))

    else:
        add("\nADJUDICATION:")
        add(json.dumps(adjudication, indent=2, default=str))

    answer = result.get("answer")
    if answer:
        add("\nANSWER:")
        if isinstance(answer, str):
            add(answer.replace("\\n", "\n"))
        else:
            add(json.dumps(answer, indent=2, default=str))

    work_item_matches = result.get("work_item_matches", [])
    if work_item_matches:
        add(f"\nWORK ITEM MATCH COUNT: {len(work_item_matches)}")

    retrieved_evidence = result.get("retrieved_evidence", [])
    if retrieved_evidence:
        add(f"\nRETRIEVED EVIDENCE COUNT: {len(retrieved_evidence)}")

    return "\n".join(output)

# In[66]:


# retrieve function
accept = "application/json"
content_type = "application/json"
def vectorize_with_titan(text: str, model_id = titan_v2_embedding_modelId) -> List[float]:
    payload = {
        "inputText": text,
        # Optional params
        # "dimensions": 1024,
        # "normalize": True
    }
    response = bedrock.invoke_model(
        modelId=model_id, body=json.dumps(payload), accept=accept, contentType=content_type)

    response_body = json.loads(response["body"].read())
    return response_body["embedding"]
    
def knn_search_work_evidence(
    query_text: str,
    host=host,
    awsauth=awsauth,
    embed_text_fn=vectorize_with_titan,
    k: int = 10
):
    query_vector = embed_text_fn(query_text)

    query_body = {
        "size": k,
        "query": {
            "knn": {
                "vector_embedding": {
                    "vector": query_vector,
                    "k": k
                }
            }
        },
        "_source": [
            "summary",
            "clean_text",
            "source_uri",
            "source_type",
            "metadata",
            "action_items_detected",
            "decisions_detected"
        ]
    }

    response = requests.post(
        f"{host}/work_evidence/_search",
        auth=awsauth,
        headers={"Content-Type": "application/json"},
        json=query_body,
    )
    if response.status_code != 200:
        return []

    response_json = response.json()
    hits = response_json.get("hits", {}).get("hits", [])

    results = []
    for hit in hits:
        source = hit.get("_source", {})
        results.append({
            "score": hit.get("_score"),
            "summary": source.get("summary", ""),
            "clean_text": source.get("clean_text", ""),
            "source_uri": source.get("source_uri", ""),
            "source_type": source.get("source_type", ""),
            "metadata": source.get("metadata", {}),
            "action_items_detected": source.get("action_items_detected", []),
            "decisions_detected": source.get("decisions_detected", []),
        })

    return results

    
def format_search_results(results_list):
    formatted = []

    for results in results_list:
        ids = results.get("ids", [[]])[0]
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        dists = results.get("distances", [[]])[0] if "distances" in results else [None] * len(ids)

        for i in range(len(ids)):
            meta = metas[i] or {}
            project_names = meta.get("project_names", [])
            if isinstance(project_names, str):
                project_names = [project_names]

            formatted.append({
                "evidence_id": ids[i],
                "document": docs[i],
                "metadata": meta,
                "distance": dists[i]
            })

    return formatted


# work items - converting into dynamodb

def search_work_items(work_items_df, project_name=None, work_item_id=None, title=None, assignee=None):
    df = work_items_df.copy()

    if work_item_id:
        df = df[df["work_item_id"].astype(str) == str(work_item_id)]

    if project_name:
        df = df[df["project_name"].fillna("").str.lower() == project_name.lower()]

    if title:
        df = df[df["task"].fillna("").str.lower().str.contains(title.lower(), na=False)]

    if assignee:
        df = df[df["assignee"].fillna("").str.lower().str.contains(assignee.lower(), na=False)]

    return df


def keyword_search_work_items(work_items_df, query_text: str, max_results: int = 15):
    """Text-based keyword search across task, summary, task_evidence fields.
    Returns work items that contain ANY of the query keywords (case-insensitive).
    Used as fallback when structured filters return too many or too few results."""
    if work_items_df.empty or not query_text:
        return work_items_df

    # Extract meaningful keywords (skip very short words)
    stop_words = {'the','a','an','is','are','was','were','what','who','how','when','where','which',
                  'and','or','in','on','at','to','for','of','with','from','by','this','that','it',
                  'be','has','have','had','do','does','did','will','would','can','could','should',
                  'may','might','about','into','all','any','them','their','there','than'}
    words = [w for w in query_text.lower().split() if len(w) > 2 and w not in stop_words]
    
    if not words:
        return work_items_df.head(max_results)

    # Search across text fields
    searchable_cols = ['task', 'summary', 'task_evidence', 'project_name', 'assignee', 'source_uri', 'source_type']
    available_cols = [c for c in searchable_cols if c in work_items_df.columns]
    
    # Combine all text columns into one searchable string per row
    combined = work_items_df[available_cols].fillna('').astype(str).agg(' '.join, axis=1).str.lower()
    
    # Score each row by how many keywords it matches
    scores = pd.Series(0, index=work_items_df.index)
    for word in words:
        scores += combined.str.contains(word, na=False).astype(int)
    
    # Return items that match at least one keyword, sorted by relevance
    matched = work_items_df[scores > 0].copy()
    matched['_relevance_score'] = scores[scores > 0]
    matched = matched.sort_values('_relevance_score', ascending=False).head(max_results)
    matched = matched.drop(columns=['_relevance_score'])
    
    print(f"[DEBUG] keyword_search_work_items: {len(matched)} matches from {len(words)} keywords")
    return matched.reset_index(drop=True)


def retrieve_work_items_df_from_intent_result(
    intent_result,
    table_name,
):
    table = dynamodb_resource.Table(table_name)
    items = []

    # intent_result = intent_result or {}

    project_name = intent_result.get("project_name")
    work_item_id = intent_result.get("work_item_id")
    title = intent_result.get("title")
    assignee = intent_result.get("assignee")

    if project_name:
        # Try multiple case variants to handle case-insensitive matching
        case_variants = list(set([
            project_name,
            project_name.title(),        # "project apollo" -> "Project Apollo"
            project_name.upper(),        # "PROJECT APOLLO"
            project_name.lower(),        # "project apollo"
            project_name.capitalize(),   # "Project apollo"
        ]))
        for variant in case_variants:
            response = table.query(
                KeyConditionExpression=Key("PK").eq(f"PROJECT#{variant}")
            )
            items.extend(response.get("Items", []))
            while "LastEvaluatedKey" in response:
                response = table.query(
                    KeyConditionExpression=Key("PK").eq(f"PROJECT#{variant}"),
                    ExclusiveStartKey=response["LastEvaluatedKey"],
                )
                items.extend(response.get("Items", []))
            if items:
                break  # Found results, no need to try other variants
    else:
        response = table.scan()
        items.extend(response.get("Items", []))

        while "LastEvaluatedKey" in response:
            response = table.scan(
                ExclusiveStartKey=response["LastEvaluatedKey"]
            )
            items.extend(response.get("Items", []))

    df = pd.DataFrame(items)

    if df.empty:
        return pd.DataFrame(columns=[
            "work_item_id", "evidence_id", "source_uri", "source_type",
            "project_name", "task", "assignee", "due_date", "status",
            "task_evidence", "event_timestamp", "summary"
        ])

    for col in [
        "work_item_id", "evidence_id", "source_uri", "source_type",
        "project_name", "task", "assignee", "due_date", "status",
        "task_evidence", "event_timestamp", "summary"
    ]:
        if col not in df.columns:
            df[col] = ""

    if work_item_id:
        df = df[df["work_item_id"].astype(str) == str(work_item_id)]

    if project_name:
        df = df[df["project_name"].fillna("").str.lower() == str(project_name).lower()]

    if title:
        df = df[df["task"].fillna("").str.lower().str.contains(str(title).lower(), na=False)]

    if assignee:
        df = df[df["assignee"].fillna("").str.lower().str.contains(str(assignee).lower(), na=False)]

    return df.reset_index(drop=True)

    
def handle_retrieve_intent(intent_result, table_name=work_items, answer_fn=None):

    project_name = intent_result.get("project_name", "")
    retrieval_query = intent_result.get("retrieval_query") or project_name or intent_result.get("title")
    
    # Fallback: if retrieval_query is still empty or too short, use the full chat history as query
    if not retrieval_query or len(str(retrieval_query).strip()) < 3:
        chat_hist = intent_result.get("chat_history") or []
        if isinstance(chat_hist, list):
            retrieval_query = " ".join(chat_hist)
        elif isinstance(chat_hist, str):
            retrieval_query = chat_hist

    # ALWAYS enrich queries with context for better KNN matching
    chat_hist = intent_result.get("chat_history") or []
    user_text = " ".join(chat_hist) if isinstance(chat_hist, list) else str(chat_hist)
    user_lower = user_text.lower()

    # Intent-aware enrichment: expand query based on what the user is actually asking about
    if any(w in user_lower for w in ["decision", "decided", "agreed", "resolved", "conclusion"]):
        retrieval_query = f"decisions made agreed resolved confirmed provisional {user_text} action items outcomes blockers"
    elif any(w in user_lower for w in ["blocker", "blocked", "blocking", "impediment", "stuck", "on hold"]):
        retrieval_query = f"blocked on hold impediment dependency blocker waiting {user_text}"
    elif any(w in user_lower for w in ["risk", "risks", "at risk", "concern", "escalat"]):
        retrieval_query = f"risk at risk escalation concern launch readiness delay {user_text}"
    elif any(w in user_lower for w in ["action item", "action items", "follow up", "meeting", "last meeting", "raised"]):
        retrieval_query = f"action items follow up owner due date assigned meeting transcript {user_text}"
    elif any(w in user_lower for w in ["summar", "activit", "team activit", "overview", "what is going on", "what's happening"]):
        retrieval_query = f"team activities summary status update progress tasks decisions blockers people projects {user_text}"
    elif any(w in user_lower for w in ["pending", "outstanding", "not done", "incomplete", "todo", "to do"]):
        retrieval_query = f"pending tasks outstanding incomplete action items status not started to do {user_text}"
    elif any(w in user_lower for w in ["in progress", "current", "active", "ongoing", "working on"]):
        retrieval_query = f"in progress active ongoing current status working on projects tasks {user_text}"
    elif any(w in user_lower for w in ["status", "strategy", "access", "launch", "progress", "update", "noventra", "ipst"]):
        retrieval_query = f"status update progress launch strategy access plan tasks summary {user_text}"
    elif len(str(retrieval_query).split()) <= 4:
        # Short project-name style query — expand with project context
        retrieval_query = f"Tell me about {retrieval_query}. Project details, tasks, team members, milestones, status."
    
    # Also combine with user text if they differ
    if user_text and user_text.lower().strip() != retrieval_query.lower().strip():
        retrieval_query = f"{retrieval_query} {user_text}"
    
    print(f"[DEBUG] Final retrieval_query: {retrieval_query}")

    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=intent_result,
        table_name=table_name,
    )

    decision_trace = [
        "Detected retrieve intent",
        f"Querying work_evidence for: {retrieval_query}"
    ]

    # chroma_raw = search_work_evidence(
    #     work_evidence_collection,
    #     retrieval_query,
    #     n_results=5
    # )
    search_raw = knn_search_work_evidence(query_text=retrieval_query)
    print(f"[DEBUG] KNN search for '{retrieval_query}' returned {len(search_raw)} results")
    for i, item in enumerate(search_raw[:3]):
        print(f"[DEBUG] Result {i}: score={item.get('score')}, summary={item.get('summary', '')[:100]}")
 
    # Format KNN results into a consistent evidence format
    evidence = []
    for item in search_raw:
        evidence.append({
            "evidence_id": item.get("source_uri", ""),
            "document": item.get("clean_text") or item.get("summary", ""),
            "summary": item.get("summary", ""),
            "source_type": item.get("source_type", ""),
            "metadata": item.get("metadata", {}),
            "action_items": item.get("action_items_detected", []),
            "decisions": item.get("decisions_detected", []),
            "score": item.get("score")
        })
    decision_trace.append(f"Retrieved {len(evidence)} evidence records from work_evidence")

    work_item_matches = search_work_items(
        work_items_df,
        project_name=project_name,
        work_item_id=intent_result.get('work_item_id',''), 
        title=intent_result.get('title', ''), 
        assignee=intent_result.get('assignee','')
    )

    # When OpenSearch returns 0 results (403 or no index), ALWAYS run keyword search
    # on whatever work_item_matches we have — this ensures Noventra/IPST/project-specific
    # terms are matched even if structured filters returned a broad unfiltered result set.
    if len(evidence) == 0:
        keyword_filtered = keyword_search_work_items(work_items_df, user_text, max_results=15)
        if len(keyword_filtered) > 0:
            work_item_matches = keyword_filtered
            print(f"[DEBUG] No OpenSearch evidence — keyword search returned {len(work_item_matches)} items")
        elif len(work_item_matches) == 0:
            # keyword search also returned nothing — use full table as last resort
            work_item_matches = work_items_df.head(15)
            print(f"[DEBUG] Keyword search found nothing — falling back to full table ({len(work_item_matches)} items)")
        else:
            print(f"[DEBUG] Keyword search returned 0 — keeping {len(work_item_matches)} structured matches")

    decision_trace.append(f"Matched {len(work_item_matches)} rows in work_items")

    if answer_fn:
        answer = answer_fn(retrieval_query, evidence, work_item_matches)
    else:
        if evidence:
            answer = evidence[0]["document"]
        elif not work_item_matches.empty:
            # No OpenSearch evidence but we have DynamoDB keyword matches — summarise them
            answer = "\n".join(
                f"- {row.get('task','')} ({row.get('assignee','')}, {row.get('status','')})"
                for _, row in work_item_matches.head(5).iterrows()
                if row.get('task')
            ) or "No relevant evidence found."
        else:
            answer = "No relevant evidence found."

    return {
        "mode": "retrieve",
        "decision_trace": decision_trace,
        "retrieved_evidence": evidence,
        "work_item_matches": work_item_matches.to_dict(orient="records"),
        "answer": answer
    }


# In[67]:


# update function
# work_items_df = pd.read_csv('df_work_items.csv')

# cols = ['assignee', 'due_date']
# work_items_df = work_items_df[work_items_df[cols].notnull().all(axis=1)]  # keeping this as the final df with only 49 rows that contains both assignee and due date
def compress_work_items_for_llm(work_item_rows, max_rows=5):
    rows = work_item_rows[:max_rows]
    compressed = []

    for row in rows:
        compressed.append({
            "work_item_id": row.get("work_item_id"),
            "project_name": row.get("project_name"),
            "task": row.get("task"),
            "assignee": row.get("assignee"),
            "due_date": str(row.get("due_date")) if row.get("due_date") is not None else None,
            "status": row.get("status"),
            "summary": row.get("summary")
        })

    return compressed
def compress_evidence_for_llm(evidence_records, max_items=5, max_chars=500):
    compressed = []

    for ev in evidence_records[:max_items]:
        compressed.append({
            "evidence_id": ev.get("evidence_id"),
            "source_type": (ev.get("metadata") or {}).get("source_type"),
            "source_uri": (ev.get("metadata") or {}).get("source_uri"),
            "project_names": (ev.get("metadata") or {}).get("project_names"),
            "snippet": (ev.get("document") or "")[:max_chars]
        })

    return compressed
def build_updated_item_from_intent(previous_item, intent_result, user_text=None):
    user_text="\n".join(intent_result["chat_history"])
    if not previous_item:
        return None, []

    updated_item = dict(previous_item)
    changed_fields = []

    field_map = {
        "project_name": "project_name",
        "title": "task",
        "assignee": "assignee",
        "due_date": "due_date",
        "status": "status",
        "summary": "summary",
        "description": "summary"
    }

    for intent_key, item_key in field_map.items():
        new_value = intent_result.get(intent_key)
        if new_value is not None and str(new_value).strip() != "":
            old_value = previous_item.get(item_key)
            if str(old_value) != str(new_value):
                updated_item[item_key] = new_value
                changed_fields.append(item_key)

    updated_item["source_type"] = "user_input"
    changed_fields.append("source_type")

    updated_item["source_uri"] = "chat"
    changed_fields.append("source_uri")

    updated_item["event_timestamp"] = datetime.utcnow().isoformat()
    changed_fields.append("event_timestamp")

    if user_text:
        updated_item["task_evidence"] = user_text
        changed_fields.append("task_evidence")

    return updated_item, sorted(list(set(changed_fields)))
    
def make_work_item_text(row):
    parts = [
        str(row.get("project_name", "")),
        str(row.get("task", "")),
        str(row.get("summary", "")),
        str(row.get("assignee", "")),
        str(row.get("status", ""))
    ]
    return " ".join([p for p in parts if p and p != "None"])
    
def find_semantic_create_candidates(proposed_item, table_name=work_items, top_k=5):
    
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=proposed_item,
        table_name=table_name,
    )
    
    proposed_text = make_work_item_text(proposed_item)
    proposed_emb = np.array(vectorize_with_titan(proposed_text)).reshape(1, -1)
    
    texts = []
    rows = []

    for _, row in work_items_df.iterrows():
        texts.append(make_work_item_text(row))
        rows.append(row.to_dict())

    if not texts:
        return []

    embeddings = np.array([vectorize_with_titan(text) for text in texts])

    sims = cosine_similarity(proposed_emb, embeddings)[0]

    ranked = sorted(
        [{"similarity": float(sim), "row": row} for sim, row in zip(sims, rows)],
        key=lambda x: x["similarity"],
        reverse=True
    )

    return ranked[:top_k]
    
def find_structured_create_candidates(proposed_item,table_name=work_items, top_k=10):
    
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=proposed_item,
        table_name=table_name,
    )
    df = work_items_df.copy()

    project_name = (proposed_item.get("project_name") or "").strip().lower()
    assignee = (proposed_item.get("assignee") or "").strip().lower()
    task = (proposed_item.get("task") or "").strip().lower()

    if project_name:
        df = df[df["project_name"].fillna("").str.lower() == project_name]

    candidates = []

    for _, row in df.iterrows():
        row_task = str(row.get("task", "")).strip().lower()
        row_assignee = str(row.get("assignee", "")).strip().lower()

        score = 0
        reasons = []

        if assignee and row_assignee == assignee:
            score += 2
            reasons.append("same assignee")

        if task and row_task == task:
            score += 5
            reasons.append("exact same task")

        elif task and row_task and (task in row_task or row_task in task):
            score += 3
            reasons.append("task text overlap")

        if proposed_item.get("due_date") is not None and row.get("due_date") is not None:
            try:
                p_date = pd.to_datetime(proposed_item["due_date"]).date()
                r_date = pd.to_datetime(row["due_date"]).date()
                if p_date == r_date:
                    score += 2
                    reasons.append("same due date")
            except Exception:
                pass

        if score > 0:
            candidates.append({
                "match_score": score,
                "match_reasons": reasons,
                "row": row.to_dict()
            })

    candidates = sorted(candidates, key=lambda x: x["match_score"], reverse=True)
    return candidates[:top_k]

def build_proposed_item_for_matching(intent_result):
    user_text="\n".join(intent_result["chat_history"])
    return {
        "project_name": intent_result.get("project_name"),
        "task": intent_result.get("title") or intent_result.get("task") or intent_result.get("summary") or user_text,
        "assignee": intent_result.get("assignee"),
        "due_date": intent_result.get("due_date"),
        "status": intent_result.get("status"),
        "summary": intent_result.get("summary") or intent_result.get("description") or user_text
    }

def resolve_selected_work_item_hybrid(intent_result, table_name=work_items, top_k=5):
    user_text="\n".join(intent_result["chat_history"])
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=intent_result,
        table_name=table_name,
    )
    
    work_item_id = intent_result.get("work_item_id")

    if work_item_id:
        exact = work_items_df[
            work_items_df["work_item_id"].astype(str) == str(work_item_id)
        ]
        if not exact.empty:
            row = exact.iloc[0].to_dict()
            return {
                "selected_item": row,
                "resolution_method": "exact_work_item_id",
                "confidence": 1.0,
                "candidates": [{"row": row, "final_score": 1.0}]
            }

    proposed_item = build_proposed_item_for_matching(intent_result)

    structured_candidates = find_structured_create_candidates(
        table_name=work_items,
        proposed_item=proposed_item,
        top_k=top_k
    )

    semantic_candidates = find_semantic_create_candidates(
        proposed_item=proposed_item,
        table_name=work_items,
        top_k=top_k
    )

    structured_map = {}
    for item in structured_candidates:
        row = item["row"]
        wid = str(row.get("work_item_id"))
        structured_map[wid] = item

    semantic_map = {}
    for item in semantic_candidates:
        row = item["row"]
        wid = str(row.get("work_item_id"))
        semantic_map[wid] = item

    all_ids = set(structured_map.keys()) | set(semantic_map.keys())
    combined = []

    for wid in all_ids:
        s_score = structured_map.get(wid, {}).get("match_score", 0)
        sim_score = semantic_map.get(wid, {}).get("similarity", 0.0)

        row = None
        if wid in structured_map:
            row = structured_map[wid]["row"]
        elif wid in semantic_map:
            row = semantic_map[wid]["row"]

        final_score = (0.6 * sim_score) + (0.4 * min(s_score / 10.0, 1.0))

        combined.append({
            "work_item_id": wid,
            "row": row,
            "structured_score": s_score,
            "semantic_similarity": sim_score,
            "final_score": final_score,
            "match_reasons": structured_map.get(wid, {}).get("match_reasons", [])
        })

    combined = sorted(combined, key=lambda x: x["final_score"], reverse=True)

    if not combined:
        return {
            "selected_item": None,
            "resolution_method": "no_match",
            "confidence": 0.0,
            "candidates": []
        }

    best = combined[0]
    confidence = best["final_score"]

    if len(combined) > 1:
        gap = best["final_score"] - combined[1]["final_score"]
    else:
        gap = best["final_score"]

    if confidence < 0.55 or gap < 0.08:
        return {
            "selected_item": None,
            "resolution_method": "ambiguous",
            "confidence": confidence,
            "candidates": combined[:top_k]
        }

    return {
        "selected_item": best["row"],
        "resolution_method": "hybrid_structured_semantic",
        "confidence": confidence,
        "candidates": combined[:top_k]
    }
def parse_llm_json(text):
    text = text.strip()

    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) >= 3:
            text = "\n".join(lines[1:-1]).strip()

    return json.loads(text)
def run_llm_adjudication(prompt):
    raw = llm.invoke(prompt).content
    return raw
def build_adjudication_prompt(intent_result, work_item_rows, evidence_rows):
    user_text="\n".join(intent_result["chat_history"])
    payload = {
        "user_claim": user_text,
        "parsed_intent": intent_result,
        "structured_work_items": compress_work_items_for_llm(work_item_rows),
        "historical_evidence": compress_evidence_for_llm(evidence_rows)
    }

    prompt = f"""
You are a scrum master assistant evaluating a user's requested work-item update.

Your task:
- Compare the user's request against the structured work item records and retrieved historical evidence.
- Determine the most likely target work item, if one exists.
- Identify which fields the user wants changed.
- Prefer being helpful and action-oriented rather than overly rejecting updates.
- If the user clearly requests a change to a task, assignee, due date, status, summary, or similar field, treat that as a valid proposed update even if historical evidence differs.
- Use the historical evidence to explain conflicts, risks, or inconsistencies, not to automatically block the user's request.
- Only choose needs_clarification if the target work item or intended field change is too ambiguous.
- If a matching item is found and the requested change is clear, prepare an updated version of the item.
- If historical evidence conflicts with the user's request, prefer confirm_overwrite instead of reject_update.
- Do not assume the user is always correct.
- Do not assume the historical records are always correct either.
- Base your judgment on specificity, consistency, recency if visible, corroboration across sources, and whether the user's request is explicit.

Return ONLY valid JSON with this schema:
{{
  "decision": "apply_directly" | "confirm_overwrite" | "needs_clarification" | "no_matching_item",
  "should_update": true | false,
  "confirmation_required": true | false,
  "user_signal_strength": "weak" | "medium" | "strong",
  "historical_signal_strength": "weak" | "medium" | "strong",
  "confidence": 0.0,
  "affected_fields": [],
  "reasoning_summary": [],
  "current_state_summary": {{}},
  "proposed_state_summary": {{}},
  "selected_work_item_id": "",
  "previous_item": {{}},
  "updated_item": {{}},
  "conflict_summary": [],
  "next_action": ""
}}

Rules:
- reasoning_summary must be concise, factual, and explainable.
- Do not reveal hidden chain of thought.
- Use only evidence from the provided context.
- If the user's update request is explicit and a matching work item is found, prefer apply_directly or confirm_overwrite.
- If historical evidence differs, summarize the conflict and prefer confirm_overwrite.
- If the request is ambiguous about which item to change, use needs_clarification.
- If no matching work item exists, use no_matching_item.
- previous_item must contain the selected original work item when available.
- updated_item must contain the same item with the user's requested changes applied when possible.
- Preserve unchanged fields in updated_item.
- affected_fields should list only the fields that changed.

Context:
{json.dumps(payload, indent=2, default=str)}
"""
    return prompt

    
def gather_update_context(intent_result, table_name=work_items, n_results=5):
    user_text="\n".join(intent_result["chat_history"])
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=intent_result,
        table_name=table_name,
    )
    
    project_name = intent_result.get("project_name")
    title = intent_result.get("title")
    assignee = intent_result.get("assignee")
    work_item_id = intent_result.get("work_item_id")

    work_item_matches = search_work_items(
        work_items_df,
        project_name=project_name,
        work_item_id=work_item_id,
        title=title,
        assignee=assignee
    )

    query_parts = [
        user_text,
        intent_result.get("retrieval_query"),
        project_name,
        title,
        intent_result.get("description"),
        intent_result.get("status"),
        assignee,
        str(intent_result.get("due_date")) if intent_result.get("due_date") else None,
        intent_result.get("summary")
    ]
    query_text = " ".join([x for x in query_parts if x])

    search_raw = knn_search_work_evidence(query_text=query_text,)
    evidence = format_search_results(search_raw)

    return {
        "user_text": user_text,
        "intent_result": intent_result,
        "work_item_matches": work_item_matches.to_dict(orient="records"),
        "evidence": evidence
    }
def handle_update_intent_with_llm(
    state,
    table_name=work_items
):
    context = gather_update_context(
        intent_result=state,
        table_name=work_items,
        n_results=5
    )

    prompt = build_adjudication_prompt(
        intent_result=context["intent_result"],
        work_item_rows=context["work_item_matches"],
        evidence_rows=context["evidence"]
    )

    raw_llm_output = run_llm_adjudication(prompt)
    adjudication = parse_llm_json(raw_llm_output)

    resolution = resolve_selected_work_item_hybrid(
        intent_result=state,
        table_name=work_items,
        top_k=5
        )

    previous_item = resolution.get("selected_item")

    updated_item = None
    changed_fields = []

    if previous_item is not None:
        updated_item, changed_fields = build_updated_item_from_intent(previous_item, state)

    if updated_item is not None:
        adjudication["previous_item"] = previous_item
        adjudication["updated_item"] = updated_item
        adjudication["affected_fields"] = changed_fields or adjudication.get("affected_fields", [])

        if adjudication.get("decision") == "apply_directly":
            adjudication["next_action"] = (
                "A matching work item was found and the requested changes were prepared. "
                "You can apply this update."
            )
        elif adjudication.get("decision") == "confirm_overwrite":
            adjudication["next_action"] = (
                "A matching work item was found and an updated version has been prepared. "
                "Historical evidence differs from the user request. Please confirm whether to overwrite the current item."
            )

    return {
        "mode": "update_review",
        "intent_result": state,
        "work_item_matches": context["work_item_matches"],
        "retrieved_evidence": context["evidence"],
        "adjudication": adjudication,
        "previous_item": previous_item,
        "updated_item": updated_item,
        "answer": adjudication.get("next_action", "No recommendation returned.")
    }


# In[68]:


# create node
def build_create_adjudication_prompt(intent_result, proposed_item, candidate_info):
    user_text="\n".join(intent_result["chat_history"])
    payload = {
        "user_request": user_text,
        "parsed_intent": intent_result,
        "proposed_work_item": proposed_item,
        "structured_candidates": candidate_info.get("structured_candidates", [])[:5],
        "semantic_candidates": candidate_info.get("semantic_candidates", [])[:5]
    }

    prompt = f"""
You are evaluating whether a user is trying to create a genuinely new work item or a duplicate of an existing one.

Your task:
- Review the proposed work item.
- Compare it against existing structured and semantically similar candidates.
- Decide whether this should be treated as:
  - a new work item,
  - a possible duplicate needing clarification,
  - an overwrite request,
  - or a request that should be ignored because the existing task should remain unchanged.

Return ONLY valid JSON with this schema:
{{
  "decision": "create_new" | "possible_duplicate" | "overwrite_existing" | "ignore_new_request" | "needs_clarification",
  "should_create": true | false,
  "confidence": 0.0,
  "reasoning_summary": [],
  "selected_existing_work_item_id": null,
  "candidate_duplicate_ids": [],
  "proposed_state_summary": {{}},
  "current_state_summary": {{}},
  "clarification_question": "",
  "next_action": ""
}}

Rules:
- Be concise and factual.
- Do not reveal hidden chain of thought.
- If the proposed item strongly overlaps with an existing item, prefer possible_duplicate or overwrite_existing.
- If it is clearly distinct, prefer create_new.
- If the user intent to overwrite is not explicit, do not assume overwrite_existing unless the request clearly indicates replacement.
- If evidence is mixed, prefer needs_clarification.

Context:
{json.dumps(payload, indent=2, default=str)}
"""
    return prompt

def gather_create_candidates(proposed_item, table_name=work_items, embed_fn=vectorize_with_titan):
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=proposed_item,
        table_name=table_name,
    )
    
    structured = find_structured_create_candidates(table_name=work_items, proposed_item=proposed_item, top_k=10)

    semantic = []
    if embed_fn is not None and len(work_items_df) > 0:
        semantic = find_semantic_create_candidates(proposed_item)

    return {
        "structured_candidates": structured,
        "semantic_candidates": semantic
    }
    
def build_proposed_work_item(intent_result):
    user_text="\n".join(intent_result["chat_history"])
    return {
        "work_item_id": f"WI_{uuid.uuid4().hex[:10]}",
        "evidence_id": None,
        "source_uri": "user_chat",
        "source_type": "chat",
        "project_name": intent_result.get("project_name"),
        "task": intent_result.get("title") or intent_result.get("summary"),
        "assignee": intent_result.get("assignee"),
        "due_date": intent_result.get("due_date"),
        "status": intent_result.get("status") or "To Do",
        "task_evidence": user_text,
        "event_timestamp": datetime.utcnow().isoformat(),
        "summary": intent_result.get("summary") or intent_result.get("description")
    }
def handle_create_intent_with_llm(
    state,
    table_name=work_items
):
    proposed_item = build_proposed_work_item(state)

    candidate_info = gather_create_candidates(
        proposed_item=proposed_item
    )

    prompt = build_create_adjudication_prompt(
        intent_result=state,
        proposed_item=proposed_item,
        candidate_info=candidate_info
    )

    raw_llm_output = llm.invoke(prompt).content
    adjudication = parse_llm_json(raw_llm_output)

    return {
        "mode": "create_review",
        "intent_result": state,
        "proposed_item": proposed_item,
        "candidate_info": candidate_info,
        "adjudication": adjudication,
        "answer": adjudication.get("next_action", "No recommendation returned."),
        "llm_prompt": prompt,
        "llm_raw_output": raw_llm_output
    }


# In[73]:


def normalize_date_for_opensearch(value):
    if not value:
        return None

    value = str(value).strip()
    if not value:
        return None

    # already ISO-like
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.date().isoformat()
        except ValueError:
            pass

    # common natural language dates
    for fmt in ("%B %d, %Y", "%b %d, %Y"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.date().isoformat()
        except ValueError:
            pass

    # unsupported fuzzy dates like "early June 2026"
    return None

def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _dedupe_preserve_order(values):
    seen = set()
    result = []
    for v in values:
        if v is None:
            continue
        v = str(v).strip()
        if not v:
            continue
        if v not in seen:
            seen.add(v)
            result.append(v)
    return result


def _drop_none(d):
    return {k: v for k, v in d.items() if v is not None}

def confirmed_updated_item_to_work_evidence_record(
    user_text,
    intent_result,
    adjudication,
    previous_item,
    updated_item,
    user_confirmation,
    workspace_id,
    project_id=None,
    source_uri="user_chat",
    embedding_fn=None,
):
    if not user_confirmation:
        raise ValueError("This function should only be used for confirmed updates.")

    intent_result = intent_result or {}
    adjudication = adjudication or {}
    previous_item = previous_item or {}
    updated_item = updated_item or {}

    evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()

    resolved_project_id = (
        project_id
        or updated_item.get("project_id")
        or previous_item.get("project_id")
        or intent_result.get("project_id")
    )

    linked_work_item_ids = _dedupe_preserve_order([
        previous_item.get("work_item_id"),
        updated_item.get("work_item_id"),
        intent_result.get("work_item_id"),
        adjudication.get("selected_work_item_id"),
    ])

    project_names = _dedupe_preserve_order([
        previous_item.get("project_name"),
        updated_item.get("project_name"),
        intent_result.get("project_name"),
    ])

    normalized_dates = _dedupe_preserve_order([
        normalize_date_for_opensearch(previous_item.get("due_date")),
        normalize_date_for_opensearch(updated_item.get("due_date")),
        normalize_date_for_opensearch(intent_result.get("due_date")),
    ])

    people = _dedupe_preserve_order([
        previous_item.get("assignee"),
        updated_item.get("assignee"),
        intent_result.get("assignee"),
        intent_result.get("reporter"),
    ])

    event_payload = {
        "event_type": "update_request_confirmed",
        "user_text": user_text,
        "intent_result": intent_result,
        "adjudication": adjudication,
        "previous_item": previous_item,
        "updated_item": updated_item,
        "user_confirmation": user_confirmation,
    }

    raw_text = json.dumps(event_payload, default=str, ensure_ascii=False)

    previous_task = str(previous_item.get("task") or previous_item.get("title") or "")
    updated_task = str(updated_item.get("task") or updated_item.get("title") or "")
    previous_status = str(previous_item.get("status") or "")
    updated_status = str(updated_item.get("status") or "")
    previous_assignee = str(previous_item.get("assignee") or previous_item.get("owner") or "")
    updated_assignee = str(updated_item.get("assignee") or updated_item.get("owner") or "")
    previous_due_date = normalize_date_for_opensearch(previous_item.get("due_date"))
    updated_due_date = normalize_date_for_opensearch(updated_item.get("due_date"))

    affected_fields = adjudication.get("affected_fields") or []
    affected_fields = [str(x) for x in affected_fields if x]

    summary_parts = [
        "User confirmed an update to an existing work item."
    ]
    if updated_task:
        summary_parts.append(f"Updated task: {updated_task}.")
    if updated_status:
        summary_parts.append(f"New status: {updated_status}.")
    if updated_assignee:
        summary_parts.append(f"Assignee: {updated_assignee}.")
    if updated_due_date:
        summary_parts.append(f"Due date: {updated_due_date}.")
    summary = " ".join(summary_parts)

    clean_text_parts = [
        "User confirmed an update to a work item.",
        f"User text: {user_text}",
        f"Project: {', '.join(project_names)}" if project_names else "",
        f"Work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Previous item: {json.dumps(previous_item, default=str, ensure_ascii=False)}",
        f"Updated item: {json.dumps(updated_item, default=str, ensure_ascii=False)}",
        f"Adjudication summary: {adjudication.get('reasoning_summary', '')}" if adjudication.get("reasoning_summary") else "",
        f"Affected fields: {', '.join(affected_fields)}" if affected_fields else "",
    ]
    clean_text = "\n".join(part for part in clean_text_parts if part)

    embedding_text_parts = [
        "Confirmed work item update",
        str(user_text or ""),
        f"Project names: {', '.join(project_names)}" if project_names else "",
        f"Linked work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Previous task: {previous_task}" if previous_task else "",
        f"Updated task: {updated_task}" if updated_task else "",
        f"Previous status: {previous_status}" if previous_status else "",
        f"Updated status: {updated_status}" if updated_status else "",
        f"Previous assignee: {previous_assignee}" if previous_assignee else "",
        f"Updated assignee: {updated_assignee}" if updated_assignee else "",
        f"Previous due date: {previous_due_date}" if previous_due_date else "",
        f"Updated due date: {updated_due_date}" if updated_due_date else "",
        f"Reasoning summary: {adjudication.get('reasoning_summary')}" if adjudication.get("reasoning_summary") else "",
        f"Conflict summary: {adjudication.get('conflict_summary')}" if adjudication.get("conflict_summary") else "",
        f"Proposed state: {adjudication.get('proposed_state_summary')}" if adjudication.get("proposed_state_summary") else "",
    ]
    embedding_text = "\n".join(part for part in embedding_text_parts if part)

    updated_due_date_for_action = normalize_date_for_opensearch(updated_item.get("due_date"))

    action_items_detected = [
        _drop_none({
            "title": updated_task or "Updated work item",
            "description": str(
                updated_item.get("summary")
                or updated_item.get("task_evidence")
                or updated_task
                or "Confirmed update to work item"
            ),
            "owner": updated_assignee if updated_assignee else None,
            "due_date": updated_due_date_for_action,
            "status": updated_status if updated_status else None,
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    decision_text_parts = [
        "User confirmed update to existing work item"
    ]
    if affected_fields:
        decision_text_parts.append(f"Affected fields: {', '.join(affected_fields)}")
    if adjudication.get("reasoning_summary"):
        decision_text_parts.append(str(adjudication.get("reasoning_summary")))

    decisions_detected = [
        _drop_none({
            "decision": ". ".join(decision_text_parts),
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    doc = {
        "evidence_id": evidence_id,
        "workspace_id": str(workspace_id),
        "project_id": str(resolved_project_id) if resolved_project_id is not None else "",
        "source_type": "chat_update_handler",
        "source_uri": str(source_uri),
        "raw_text": raw_text,
        "clean_text": clean_text,
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": linked_work_item_ids,
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": normalized_dates,
        "metadata": {
            "source_uri": str(source_uri),
            "entities": {
                "dates": normalized_dates,
                "organizations": [],
                "people": people,
                "projects": project_names,
                "systems": [],
                "tickets": linked_work_item_ids,
            }
        },
        "created_at": now,
        "updated_at": now,
    }

    if embedding_fn is not None:
        vector_embedding = embedding_fn(embedding_text)

        if hasattr(vector_embedding, "tolist"):
            vector_embedding = vector_embedding.tolist()

        if not isinstance(vector_embedding, list):
            raise ValueError(f"Embedding function must return a list, got {type(vector_embedding)}")

        if len(vector_embedding) != 1024:
            raise ValueError(f"Expected vector_embedding length 1024, got {len(vector_embedding)}")

        doc["vector_embedding"] = vector_embedding

    return doc

def confirmed_created_item_to_work_evidence_record(
    user_text,
    intent_result,
    adjudication,
    proposed_item,
    workspace_id,
    project_id=None,
    source_uri="user_chat",
    embedding_fn=None,
):
    intent_result = intent_result or {}
    adjudication = adjudication or {}
    proposed_item = proposed_item or {}

    evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()

    resolved_project_id = (
        project_id
        or proposed_item.get("project_id")
        or intent_result.get("project_id")
    )

    resolved_source_type = (
        proposed_item.get("source_type")
        or "chat_create_handler"
    )

    linked_work_item_ids = _dedupe_preserve_order([
        proposed_item.get("work_item_id"),
        intent_result.get("work_item_id"),
    ])

    project_names = _dedupe_preserve_order([
        proposed_item.get("project_name"),
        intent_result.get("project_name"),
    ])

    normalized_dates = _dedupe_preserve_order([
        normalize_date_for_opensearch(proposed_item.get("due_date")),
        normalize_date_for_opensearch(intent_result.get("due_date")),
    ])

    people = _dedupe_preserve_order([
        proposed_item.get("assignee"),
        proposed_item.get("owner"),
        intent_result.get("assignee"),
        intent_result.get("reporter"),
    ])

    event_payload = {
        "event_type": "create_request",
        "user_text": user_text,
        "intent_result": intent_result,
        "proposed_item": proposed_item,
        "adjudication": adjudication,
    }

    raw_text = json.dumps(event_payload, default=str, ensure_ascii=False)

    proposed_task = str(
        proposed_item.get("task")
        or proposed_item.get("title")
        or ""
    )
    proposed_status = str(proposed_item.get("status") or "")
    proposed_assignee = str(
        proposed_item.get("assignee")
        or proposed_item.get("owner")
        or ""
    )
    proposed_due_date = normalize_date_for_opensearch(proposed_item.get("due_date"))

    affected_fields = adjudication.get("affected_fields") or []
    affected_fields = [str(x) for x in affected_fields if x]

    summary_parts = [
        "User requested creation of a new work item."
    ]
    if proposed_task:
        summary_parts.append(f"Task: {proposed_task}.")
    if proposed_status:
        summary_parts.append(f"Status: {proposed_status}.")
    if proposed_assignee:
        summary_parts.append(f"Assignee: {proposed_assignee}.")
    if proposed_due_date:
        summary_parts.append(f"Due date: {proposed_due_date}.")
    summary = " ".join(summary_parts)

    clean_text_parts = [
        "User requested creation of a new work item.",
        f"User text: {user_text}",
        f"Project: {', '.join(project_names)}" if project_names else "",
        f"Work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Proposed item: {json.dumps(proposed_item, default=str, ensure_ascii=False)}",
        f"Adjudication summary: {adjudication.get('reasoning_summary', '')}" if adjudication.get("reasoning_summary") else "",
        f"Affected fields: {', '.join(affected_fields)}" if affected_fields else "",
    ]
    clean_text = "\n".join(part for part in clean_text_parts if part)

    embedding_text_parts = [
        "Create work item request",
        str(user_text or ""),
        f"Project names: {', '.join(project_names)}" if project_names else "",
        f"Linked work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Proposed task: {proposed_task}" if proposed_task else "",
        f"Proposed status: {proposed_status}" if proposed_status else "",
        f"Proposed assignee: {proposed_assignee}" if proposed_assignee else "",
        f"Proposed due date: {proposed_due_date}" if proposed_due_date else "",
        f"Intent summary: {intent_result.get('summary')}" if intent_result.get("summary") else "",
        f"Reasoning summary: {adjudication.get('reasoning_summary')}" if adjudication.get("reasoning_summary") else "",
        f"Proposed state: {adjudication.get('proposed_state_summary')}" if adjudication.get("proposed_state_summary") else "",
    ]
    embedding_text = "\n".join(part for part in embedding_text_parts if part)

    action_items_detected = [
        _drop_none({
            "title": proposed_task or "New work item",
            "description": str(
                proposed_item.get("summary")
                or proposed_item.get("task_evidence")
                or proposed_item.get("description")
                or proposed_task
                or "Requested new work item"
            ),
            "owner": proposed_assignee if proposed_assignee else None,
            "due_date": proposed_due_date,
            "status": proposed_status if proposed_status else None,
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    decisions_detected = [
        _drop_none({
            "decision": str(
                adjudication.get("decision")
                or "User requested creation of a new work item"
            ),
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    doc = {
        "evidence_id": evidence_id,
        "workspace_id": str(workspace_id),
        "project_id": str(resolved_project_id) if resolved_project_id is not None else "",
        "source_type": str(resolved_source_type),
        "source_uri": str(source_uri),
        "raw_text": raw_text,
        "clean_text": clean_text,
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": linked_work_item_ids,
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": normalized_dates,
        "metadata": {
            "source_uri": str(source_uri),
            "entities": {
                "dates": normalized_dates,
                "organizations": [],
                "people": people,
                "projects": project_names,
                "systems": [],
                "tickets": linked_work_item_ids,
            }
        },
        "created_at": now,
        "updated_at": now,
    }

    if embedding_fn is not None:
        vector_embedding = embedding_fn(embedding_text)

        if hasattr(vector_embedding, "tolist"):
            vector_embedding = vector_embedding.tolist()

        if not isinstance(vector_embedding, list):
            raise ValueError(f"Embedding function must return a list, got {type(vector_embedding)}")

        if len(vector_embedding) != 1024:
            raise ValueError(f"Expected vector_embedding length 1024, got {len(vector_embedding)}")

        doc["vector_embedding"] = vector_embedding

    return doc

# Local registry file for uploaded content hashes (reliable fallback)
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(_BASE_DIR, "user_uploads_from_UI")
UPLOAD_HASH_REGISTRY = os.path.join(UPLOAD_DIR, ".upload_hashes")

def _load_hash_registry() -> set:
    """Load previously uploaded content hashes from local registry file."""
    try:
        if os.path.exists(UPLOAD_HASH_REGISTRY):
            with open(UPLOAD_HASH_REGISTRY, "r") as f:
                return set(line.strip() for line in f if line.strip())
    except Exception:
        pass
    return set()

def _save_hash_to_registry(content_hash: str):
    """Append a new content hash to the local registry file."""
    try:
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        with open(UPLOAD_HASH_REGISTRY, "a") as f:
            f.write(content_hash + "\n")
        print(f"[DEDUP] Saved hash {content_hash} to registry at {UPLOAD_HASH_REGISTRY}")
    except Exception as e:
        print(f"[DEDUP] Could not save hash to registry: {e}")

def check_duplicate_in_opensearch(content_hash: str, filename: str = "", index_name="work_evidence", host=host, headers=headers) -> bool:
    """Returns True if a document with this content_hash or filename already exists.
    Checks local registry first (fast), then falls back to OpenSearch query.
    """
    # 1. Check local hash registry (fastest, most reliable)
    registry = _load_hash_registry()
    if content_hash in registry:
        print(f"[DEDUP] Found hash {content_hash} in local registry")
        return True

    # 2. Check OpenSearch — by content_hash OR by source_uri (filename)
    try:
        url = f"{host}/{index_name}/_search"
        should_clauses = [{"match": {"content_hash": content_hash}}]
        if filename:
            should_clauses.append({"match": {"source_uri": f"upload:{filename}"}})
        
        query = {
            "query": {
                "bool": {
                    "should": should_clauses,
                    "minimum_should_match": 1
                }
            },
            "_source": ["content_hash", "source_uri"],
            "size": 1
        }
        response = requests.post(url, auth=awsauth, headers=headers, data=json.dumps(query))
        result = response.json()
        print(f"[DEDUP] OpenSearch response: {json.dumps(result.get('hits', {}).get('total', {}))}")
        hits = result.get("hits", {}).get("total", {}).get("value", 0)
        if hits > 0:
            print(f"[DEDUP] Found duplicate in OpenSearch (hash or filename match)")
            # Also save to local registry so next time it's caught instantly
            _save_hash_to_registry(content_hash)
            return True
    except Exception as e:
        print(f"[DEDUP] OpenSearch check failed: {e}")

    # 3. Check DynamoDB WorkItems — scan for source_uri matching this filename
    # NOTE: Do NOT use Limit= here — DynamoDB Limit caps items *scanned*, not items
    # *returned after filtering*, so Limit=1 would silently miss matches.
    if filename:
        source_uri_val = f"upload:{filename}"
        try:
            table = dynamodb_resource.Table("AgenticColleague_WorkItems")
            scan_kwargs = {
                "FilterExpression": "source_uri = :uri",
                "ExpressionAttributeValues": {":uri": source_uri_val},
                "ProjectionExpression": "work_item_id, source_uri",
            }
            found = False
            # Paginate until a match is found or the full table is scanned
            while True:
                resp = table.scan(**scan_kwargs)
                if resp.get("Items"):
                    found = True
                    break
                last_key = resp.get("LastEvaluatedKey")
                if not last_key:
                    break
                scan_kwargs["ExclusiveStartKey"] = last_key

            if found:
                print(f"[DEDUP] Found duplicate in DynamoDB WorkItems (source_uri={source_uri_val})")
                _save_hash_to_registry(content_hash)
                return True
        except Exception as e:
            print(f"[DEDUP] DynamoDB WorkItems check failed: {e}")

    # 4. Check KanbanTasks_Draft — also stores source_uri per task (fast scan)
    if filename:
        source_uri_val = f"upload:{filename}"
        try:
            kanban_table = dynamodb_resource.Table("AgenticColleague_KanbanTasks_Draft")
            resp = kanban_table.scan(
                FilterExpression="source_uri = :uri",
                ExpressionAttributeValues={":uri": source_uri_val},
                ProjectionExpression="work_item_id, source_uri",
            )
            if resp.get("Items"):
                print(f"[DEDUP] Found duplicate in KanbanTasks_Draft (source_uri={source_uri_val})")
                _save_hash_to_registry(content_hash)
                return True
        except Exception as e:
            print(f"[DEDUP] KanbanTasks_Draft check failed: {e}")

    return False


def index_document(doc, index_name="work_evidence", host=host, headers=headers):
    url = f"{host}/{index_name}/_doc"
    response = requests.post(
        url,
        auth=awsauth,
        headers=headers,
        data=json.dumps(doc)
    )
 
    return {
        "status_code": response.status_code,
        "text": response.text
    }

dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
 
def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()
 
 
def apply_confirmed_update_dynamodb(
    updated_item,
    table_name="AgenticColleague_WorkItems",
    ):
    if not updated_item:
        return None
 
    project_name = updated_item.get("project_name")
    work_item_id = updated_item.get("work_item_id")
 
    # if not project_name:
    #     raise ValueError("updated_item must contain project_name")
 
    # if not work_item_id:
    #     raise ValueError("updated_item must contain work_item_id")
 
    table = dynamodb_resource.Table(table_name)
 
    pk = f"PROJECT#{project_name}"
    sk = f"TASK#{work_item_id}"
 
    update_values = {
        "evidence_id": updated_item.get("evidence_id"),
        "source_uri": updated_item.get("source_uri"),
        "source_type": updated_item.get("source_type"),
        "project_name": updated_item.get("project_name"),
        "task": updated_item.get("task"),
        "assignee": updated_item.get("assignee"),
        "due_date": updated_item.get("due_date"),
        "status": updated_item.get("status"),
        "task_evidence": updated_item.get("task_evidence"),
        "event_timestamp": updated_item.get("event_timestamp"),
        "summary": updated_item.get("summary"),
        "updated_at": utc_now_iso(),
    }
 
    update_values = {k: v for k, v in update_values.items() if v is not None}
 
    update_expression_parts = []
    expression_attribute_names = {}
    expression_attribute_values = {}
 
    for idx, (field, value) in enumerate(update_values.items()):
        name_key = f"#f{idx}"
        value_key = f":v{idx}"
        update_expression_parts.append(f"{name_key} = {value_key}")
        expression_attribute_names[name_key] = field
        expression_attribute_values[value_key] = value
 
    update_expression = "SET " + ", ".join(update_expression_parts)
 
    response = table.update_item(
        Key={
            "PK": pk,
            "SK": sk,
        },
        UpdateExpression=update_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values,
        ReturnValues="ALL_NEW",
    )
 
    return response.get("Attributes")


def process_user_upload_to_vector(
    file_path=None,
    bucket_name=None,
    s3_key=None
):
    s3 = boto3.client('s3', region_name="us-east-1")
    bucket_name = "ids-aini-prototype-ai-analytics"
    bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
    model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    
    def encode_image_to_base64(image_path: str) -> str:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    def call_claude(image_base64: str, media_type: str) -> str:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_base64,
                            },
                        },
                        {
                            "type": "text",
                            "text": "Extract all text from this image. Preserve formatting."
                        }
                    ],
                }
            ],
        }

        response = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps(body)
        )

        response_body = response["body"].read().decode("utf-8")
        parsed = json.loads(response_body)

        return "".join(
            block.get("text", "")
            for block in parsed.get("content", [])
            if block.get("type") == "text"
        ).strip()

    def extract_from_image(file_path: str) -> str:
        image_base64 = encode_image_to_base64(file_path)

        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(os.path.splitext(file_path)[1].lower(), "image/png")

        return call_claude(image_base64, media_type)

    def extract_from_image_bytes(file_bytes: bytes, ext: str) -> str:
        image_base64 = base64.b64encode(file_bytes).decode("utf-8")

        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(ext, "image/png")

        return call_claude(image_base64, media_type)

    def read_file_from_s3(bucket: str, key: str) -> bytes:
        s3 = boto3.client("s3", region_name="us-east-1")
        response = s3.get_object(Bucket=bucket, Key=key)
        return response["Body"].read()

    def extract_text_from_docx_bytes(file_bytes: bytes) -> str:
        doc = Document(BytesIO(file_bytes))
        return "\n".join([p.text for p in doc.paragraphs])

    def extract_text_from_docx_file(local_file_path: str) -> str:
        doc = Document(local_file_path)
        return "\n".join([p.text for p in doc.paragraphs])

    def process_file(local_file_path: str) -> str:
        extension = os.path.splitext(local_file_path)[1].lower()

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return extract_from_image(local_file_path)
        elif extension == ".docx":
            return extract_text_from_docx_file(local_file_path)
        else:
            raise ValueError(f"Unsupported file type: {extension}")

    def process_s3_file(bucket: str, key: str) -> str:
        extension = os.path.splitext(key)[1].lower()
        file_bytes = read_file_from_s3(bucket, key)

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return extract_from_image_bytes(file_bytes, extension)
        elif extension == ".docx":
            return extract_text_from_docx_bytes(file_bytes)
        else:
            raise ValueError(f"Unsupported file type: {extension}")

    if file_path:
        return process_file(file_path)

    if bucket_name and s3_key:
        return process_s3_file(bucket_name, s3_key)

    raise ValueError("Provide either file_path or both bucket_name and s3_key")



# NODES
def decision_node(state: GraphState) -> Command:
    user_text="\n".join(state["chat_history"])

    parser_prompt = f"""
Parse the following user input into structured JSON.

Return ONLY JSON. No explanation. No markdown.

IMPORTANT RULES:
- "retrieval_query" MUST always be populated with a rephrased search query derived from the user input (even if other fields are filled)
- "intent" should be "retrieve" if the user is asking a question, requesting information, OR simply mentions a project/topic name without any action verb (e.g. "project apollo" = retrieve intent)
- "intent" should be "create" ONLY if the user explicitly says to create/add a new task
- "intent" should be "update" if the user explicitly says to update/change/modify something, OR uses natural completion phrases such as "mark it done", "that's complete", "it's been completed", "task is done", "mark as in progress", "set status to", "move to done", "it's finished", "close this task", "this is now complete"
- When "update" intent is detected and user says task is done/complete/finished, set "status" to "done". When user says in progress/started/working on it, set "status" to "in progress".
- "project_name" should only be set if the user explicitly mentions a known project name
- If the user input is just a name or topic, treat it as a retrieve request about that topic

User input:
{user_text}

Return JSON with exactly these fields:
{{
  "intent": "retrieve|update|delete|create|unknown",
  "project_id": null,
  "project_name": null,
  "work_item_id": null,
  "title": null,
  "description": null,
  "reporter": null,
  "assignee": null,
  "status": null,
  "priority": null,
  "due_date": null,
  "blocker": null,
  "dependency": null,
  "issue": null,
  "summary": null,
  "retrieval_query": null,
  "clarification_needed": false,
  "clarification_question": null
}}
"""
    cleaned_response = clean_llm_output(llm.invoke(parser_prompt).content)
    try:
        parsed_response_dict = json.loads(cleaned_response)
        parsed_response_dict["chat_history"] = state["chat_history"]
        intent = parsed_response_dict["intent"]
        print(f"[DEBUG] Parsed intent: {intent}, project_name: {parsed_response_dict.get('project_name')}, retrieval_query: {parsed_response_dict.get('retrieval_query')}")
        
        # context = retrieve function()
        context=handle_retrieve_intent(
            parsed_response_dict,
            table_name=work_items,
        )

        # Sanitize context: convert Decimal/NaN values so LangGraph state serialization doesn't crash
        import decimal as _decimal
        def _sanitize(obj):
            if isinstance(obj, dict):
                return {k: _sanitize(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [_sanitize(v) for v in obj]
            elif isinstance(obj, _decimal.Decimal):
                return float(obj)
            elif isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
                return None
            return obj
        context = _sanitize(context)
 
        # retrieval_llm_result=LLM call(user query, intent, context)
        # if intent.lower() in ["update","create"]:
        #     clarification_response= llm.invoke(f"""Is more clarification needed from the user to answer the user's query
        #     or is the context provided enough to answer, also take into consideration the user's intent, Answer only in YES or NO.\n
        #     User Query: {user_text}\n Context: {context}\n User intent: {intent}\n
        #     Answer only in YES or NO. DO NOT give any explaination""")
                                               
        #     if "YES" in clarification_response:
        #         clarification_needed=True
        #     else:
        #         clarification_needed=False
        
                                           
        # ✅ Routing logic

        if state.get("clarification_received"):
            # clarification_result = LLM call(chathistory, clarification text received, retrieval_llm_result)
            clarification_response= llm.invoke(f"""Is more clarification needed from the user to answer the user's query
        or is the context provided enough to answer, also take into consideration the user's intent, Answer only in YES or NO.\n
        User Query: {user_text}\n Context: {context}\n User intent: {intent}\n
        Answer only in YES or NO. DO NOT give any explaination""").content
            if "YES" in clarification_response:
                clarification_needed=True
            else:
                clarification_needed=False
            if clarification_needed:
                return Command(
                    update={
                        **parsed_response_dict,
                        "chathistory" :user_text,
                        "clarification_needed": True
                    },
                    goto="clarify"
                )
            else:
                if intent == "create":
                    return Command(update={**parsed_response_dict,"clarification_needed":False,"clarification_received":True}, goto="create")
                else:
                    return Command(update={**parsed_response_dict,"clarification_needed":False,"clarification_received":True}, goto="update")
        else: 
            if intent == "retrieve" or intent == "unknown":
                return Command(
                    update={
                        **parsed_response_dict,
                        "clarification_needed": False,
                        "retrieval_results" : context
                    },
                    goto="inference"
                )
        
            # if clarification_needed:
            #    return Command(
            #         update={
            #             **parsed_response_dict,
            #             "clarification_needed": True
            #         },
            #         goto="clarify"
            #     )
            else:
               if intent == "create":
                   return Command(update={**parsed_response_dict}, goto="create")
               else:
                   return Command(update={**parsed_response_dict}, goto="update")

    except Exception as e:
        print(f"Error in decision_node: {e}")
        # Fallback: treat as retrieve with the raw user text as context
        fallback_context = {
            "mode": "retrieve",
            "retrieved_evidence": [],
            "work_item_matches": [],
            "answer": "No relevant information found."
        }
        return Command(
            update={
                "clarification_needed": False,
                "retrieval_results": fallback_context
            },
            goto="inference"
        )
        
    

def inference_node(state: GraphState) -> Command:
    context = state["retrieval_results"]

    # Trim context to avoid LLM context window overflow
    # Cap each evidence doc and each work item's task_evidence to keep total payload small
    trimmed_context = {}
    if isinstance(context, dict):
        evidence_list = context.get("retrieved_evidence", [])
        trimmed_evidence = []
        for ev in evidence_list[:5]:  # max 5 evidence docs
            trimmed_ev = dict(ev)
            if trimmed_ev.get("document"):
                trimmed_ev["document"] = trimmed_ev["document"][:800]
            if trimmed_ev.get("summary"):
                trimmed_ev["summary"] = trimmed_ev["summary"][:300]
            trimmed_evidence.append(trimmed_ev)

        work_items_list = context.get("work_item_matches", [])
        trimmed_work_items = []
        for wi in work_items_list[:10]:  # max 10 work items
            trimmed_wi = dict(wi)
            if trimmed_wi.get("task_evidence"):
                trimmed_wi["task_evidence"] = trimmed_wi["task_evidence"][:600]
            if trimmed_wi.get("summary"):
                trimmed_wi["summary"] = trimmed_wi["summary"][:300]
            trimmed_work_items.append(trimmed_wi)

        trimmed_context = {
            **{k: v for k, v in context.items() if k not in ("retrieved_evidence", "work_item_matches")},
            "retrieved_evidence": trimmed_evidence,
            "work_item_matches": trimmed_work_items,
        }
    else:
        trimmed_context = context

    user_query = "\n".join(state['chat_history'])
    try:
        import decimal
        def _safe_serial(o):
            if isinstance(o, decimal.Decimal):
                return float(o)
            if isinstance(o, float) and (math.isnan(o) or math.isinf(o)):
                return None
            return str(o)
        context_str = json.dumps(trimmed_context, default=_safe_serial) if isinstance(trimmed_context, dict) else str(trimmed_context)
    except Exception as e:
        print(f"[WARN] context serialization failed: {e}")
        context_str = str(trimmed_context)

    prompt = f"""
You are a project assistant. Answer the user query using the context below.

The context has two sections:
- "retrieved_evidence": source documents (check clean_text, action_items, decisions fields)
- "work_item_matches": task records from the database (check task, summary, task_evidence, assignee, status, due_date fields)

IMPORTANT:
- The "task_evidence" field inside each work_item contains the most relevant raw content — READ IT carefully.
- If work_item_matches has items, use them to answer even if retrieved_evidence is empty.
- NEVER say "no information found" if work_item_matches contains any items — extract what you can from task, summary, and task_evidence fields.
- Be SHORT and focused — 3 to 5 bullet points maximum.
- No filler phrases like "let me know", "hope this helps", "based on the context".
- No suggestions unless the user explicitly asks.
- If a table has more than 5 rows, show only the top 5 most relevant and add "*(showing top 5)*".

FORMAT:
## [Topic Name]
One sentence summary.

### Key Details
- **Label:** value

### Assignments ← only if relevant
| Name | Function | Task | Due Date | Status |
|------|----------|------|----------|--------|
| ... | ... | ... | ... | ... |
*(max 5 rows)*

For the Function column: use the ipst_function field from work_item_matches if available, otherwise leave as "—".

User Query: {user_query}
Context: {context_str}
"""

    try:
        response = llm.invoke(prompt)
        return Command(
            update={"final_response": response.content},
            goto=END
        )
    except Exception as e:
        print(f"[ERROR] inference_node LLM failed: {e}")
        import traceback; traceback.print_exc()
        return Command(
            update={"final_response": "I encountered an error processing your request. Please try rephrasing your question."},
            goto=END
        )


def create_node(state: GraphState) -> Command:
    user_text="\n".join(state['chat_history'])
    clarification_received=state["clarification_received"]
    clarification_needed=state["clarification_needed"]
    result_payload=state["result_payload"]
    # first invocation
    if not clarification_received or (clarification_received and clarification_needed):
        result = handle_create_intent_with_llm(
                state=state,
                table_name=work_items
                )
        return Command(
        update={"final_response": result},
        goto="clarify"
        )

    # second invocation
    else :
        create_doc = confirmed_created_item_to_work_evidence_record(user_text=user_text,
            intent_result=result_payload["intent_result"],
            adjudication=result_payload["adjudication"],
            proposed_item=result_payload["proposed_item"],
            workspace_id="default-workspace",
            project_id="",
            source_uri="user_chat",
            embedding_fn=vectorize_with_titan)
        response = index_document(doc=create_doc)
        dynamo_response = apply_confirmed_update_dynamodb(result_payload["proposed_item"])
        print(f"Result of Updating the Opensearch index: {response['status_code']}\n")
        print(f"Result of Updating the Dynamo Db: {dynamo_response}\n")
        
        # Also write to Kanban Draft table for UI display
        proposed = result_payload["proposed_item"]
        kanban_table = dynamodb_resource.Table("AgenticColleague_KanbanTasks_Draft")
        kanban_table.put_item(Item={
            "PK": f"PROJECT#{proposed.get('project_name', 'Unassigned')}",
            "SK": f"TASK#{proposed.get('work_item_id', uuid.uuid4().hex[:8])}",
            "project_name": proposed.get("project_name", "Unassigned"),
            "task": proposed.get("task", ""),
            "assigned_to": proposed.get("assignee", "Unassigned"),
            "due_date": proposed.get("due_date", ""),
            "status": proposed.get("status", "not started"),
            "source_type": "user_chat",
            "ipst_function": IPST_FUNCTION_MAP.get(
                proposed.get("assignee", "").strip().title(),
                IPST_FUNCTION_MAP.get(proposed.get("assignee", "").strip(), "")
            ),
        })
        
        result="Succesfully Created!"
        return Command(
            update={"final_response": result},
            goto=END
        )


def update_node(state: GraphState) -> Command:
    user_text="\n".join(state['chat_history'])
    clarification_received=state["clarification_received"]
    clarification_needed=state["clarification_needed"]
    result_payload=state["result_payload"]

    # FIRST CALL (no clarification yet): run adjudication, then ask clarify node
    # CONFIRMATION CALL (clarification_received=True, clarification_needed=False): apply the update
    if not (clarification_received and not clarification_needed):
        # First call — run adjudication against WorkItems
        result = handle_update_intent_with_llm(
                state=state,
                table_name=work_items
            )

        # ── FALLBACK: if WorkItems search found nothing, try KanbanTasks_Draft directly ──
        if result.get("updated_item") is None:
            try:
                _dyn = boto3.resource("dynamodb", region_name="us-east-1")
                _kanban = _dyn.Table("AgenticColleague_KanbanTasks_Draft")
                _scan = _kanban.scan()
                _items = _scan.get("Items", [])
                # Find best matching card by task name and/or assignee
                title_hint = (state.get("title") or state.get("summary") or "").lower()
                assignee_hint = (state.get("assignee") or "").lower()
                new_status_hint = (state.get("status") or "").lower().strip()
                if new_status_hint in ("to do", "todo", "to-do"): new_status_hint = "pending"
                elif new_status_hint in ("in progress", "in-progress", "inprogress", "active"): new_status_hint = "in progress"
                elif new_status_hint in ("done", "completed", "complete", "finished"): new_status_hint = "done"
                # Extract from chat_history if not parsed into state fields
                import re as _re
                if not title_hint:
                    # Try quoted title first — straight single/double quotes AND curly quotes
                    m = _re.search(r"[\"'\u201c\u2018\u2019\u201d]([^\"'\u201c\u2018\u2019\u201d]{5,})[\"'\u201c\u2018\u2019\u201d]", user_text, _re.I)
                    if m:
                        title_hint = m.group(1).strip().lower()
                    else:
                        # Try "move/update/change <title> to <status>" — grab text between verb and "to <status>"
                        m = _re.search(r'(?:move|update|change|set|mark)\s+(.+?)\s+to\s+(?:to[\s\-]do|todo|in[\s\-]progress|done|at[\s\-]risk|blocked|pending)', user_text, _re.I)
                        if m:
                            title_hint = m.group(1).strip().lower()
                        else:
                            # Try "task: <title>" pattern
                            m = _re.search(r'task[:\s]+([^,\.\n]+)', user_text, _re.I)
                            if m: title_hint = m.group(1).strip().lower()
                    # Strip trailing status phrases from title (e.g. "... to To Do")
                    title_hint = _re.sub(r'\s+to\s+(to[\s\-]do|todo|in[\s\-]progress|done|at[\s\-]risk|blocked|pending)\s*$', '', title_hint, flags=_re.I).strip()
                if not assignee_hint:
                    m2 = _re.search(r'(?:assign(?:ed)?\s+to|assignee)[:\s]*([^,\-\u2014\n]+)', user_text, _re.I)
                    if m2: assignee_hint = m2.group(1).strip().lower()
                if not new_status_hint:
                    _ut = user_text.lower()
                    # Try to extract the TARGET status from "move/change/set ... to <status>" or "to <status>" patterns
                    # This avoids picking up the SOURCE status in "move from X to Y"
                    _target_match = _re.search(
                        r'(?:move|change|set|update|mark).*?\bto\b\s+(to[\s\-]do|todo|in[\s\-]progress|done|complet\w*|at[\s\-]risk|blocked|pending)',
                        _ut, _re.I
                    )
                    if not _target_match:
                        # fallback: look for "to <status>" anywhere
                        _target_match = _re.search(
                            r'\bto\s+(to[\s\-]do|todo|in[\s\-]progress|done|complet\w*|at[\s\-]risk|blocked|pending)\b',
                            _ut, _re.I
                        )
                    if _target_match:
                        _ts = _target_match.group(1).strip()
                        if "to" in _ts and ("do" in _ts or _ts == "todo"): new_status_hint = "pending"
                        elif "in" in _ts and "progress" in _ts: new_status_hint = "in progress"
                        elif "done" in _ts or "complet" in _ts: new_status_hint = "done"
                        elif "at" in _ts and "risk" in _ts: new_status_hint = "At Risk"
                        elif "blocked" in _ts: new_status_hint = "blocked"
                        elif "pending" in _ts: new_status_hint = "pending"
                    else:
                        # Last resort: simple keyword scan (only when no "from...to" ambiguity)
                        if "to do" in _ut or "todo" in _ut: new_status_hint = "pending"
                        elif "in progress" in _ut: new_status_hint = "in progress"
                        elif "done" in _ut or "complet" in _ut: new_status_hint = "done"
                        elif "at risk" in _ut: new_status_hint = "At Risk"
                        elif "blocked" in _ut: new_status_hint = "blocked"
                # Extract project name
                new_project_hint = ""
                mp = _re.search(r'(?:project|proj)[:\s]+(?:to\s+)?([A-Za-z0-9 ]+?)(?:\s+and|\s+due|\s+assign|\s+move|$)', user_text, _re.I)
                if not mp:
                    mp = _re.search(r'(?:assign|add|put|move)\s+(?:it\s+)?(?:to\s+)?(?:the\s+)?(?:project\s+)?([A-Za-z0-9 ]+?)\s+project', user_text, _re.I)
                if mp: 
                    new_project_hint = mp.group(1).strip()
                    # Ignore placeholder dashes
                    if new_project_hint in ("—", "-", "–", "null", "none", ""): new_project_hint = ""
                # Extract due date — supports YYYY-MM-DD and natural language (May 1, 1st May, etc.)
                new_due_hint = ""
                md = _re.search(r'due\s*(?:date)?[:\s]*(\d{4}-\d{2}-\d{2})', user_text, _re.I)
                if md:
                    new_due_hint = md.group(1).strip()
                else:
                    # Natural language date: "May 1", "1st May", "May 1st", "1 May 2026" etc.
                    _MONTHS = {"jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,"jul":7,"aug":8,"sep":9,"oct":10,"nov":11,"dec":12,
                               "january":1,"february":2,"march":3,"april":4,"june":6,"july":7,"august":8,"september":9,"october":10,"november":11,"december":12}
                    mn = _re.search(
                        r'(?:due\s*(?:date)?[:\s]*)?(\d{1,2})(?:st|nd|rd|th)?\s+(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s*(\d{4})?'
                        r'|(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+(\d{1,2})(?:st|nd|rd|th)?\s*,?\s*(\d{4})?',
                        user_text, _re.I
                    )
                    if mn:
                        if mn.group(1):  # "1st May 2026"
                            day, mon_str, yr = int(mn.group(1)), mn.group(2)[:3].lower(), mn.group(3)
                        else:  # "May 1 2026"
                            mon_str, day, yr = mn.group(4)[:3].lower(), int(mn.group(5)), mn.group(6)
                        month = _MONTHS.get(mon_str, 0)
                        year = int(yr) if yr else 2026
                        if month:
                            new_due_hint = f"{year}-{month:02d}-{day:02d}"

                best_match = None
                best_score = 0
                for item in _items:
                    score = 0
                    task_str = (item.get("task") or "").lower()
                    assigned_str = (item.get("assigned_to") or "").lower()
                    if title_hint and title_hint in task_str: score += 100  # exact substring — always wins
                    elif title_hint:
                        # partial word overlap
                        words = [w for w in title_hint.split() if len(w) > 3]
                        score += sum(1 for w in words if w in task_str)
                    if assignee_hint:
                        for a in assignee_hint.split(","):
                            if a.strip() and a.strip() in assigned_str: score += 2
                    if score > best_score:
                        best_score = score
                        best_match = item

                if best_match and best_score >= 1:
                    print(f"[UPDATE] Found task in KanbanTasks_Draft: {best_match.get('task')} (score={best_score})")
                    updated_item = dict(best_match)
                    # Apply all extracted fields
                    if new_status_hint:
                        updated_item["status"] = new_status_hint
                    if assignee_hint:
                        # Title-case the assignee name
                        updated_item["assigned_to"] = assignee_hint.title()
                    if new_project_hint:
                        updated_item["project_name"] = new_project_hint
                        updated_item["PK"] = f"PROJECT#{new_project_hint}"
                    if new_due_hint:
                        updated_item["due_date"] = new_due_hint
                    updated_item["assignee"] = updated_item.get("assigned_to", best_match.get("assigned_to", "Unassigned"))
                    result["previous_item"] = dict(best_match)
                    result["updated_item"] = updated_item
                    result["adjudication"] = result.get("adjudication") or {}
                    changes = []
                    if new_status_hint: changes.append(f"status → {new_status_hint}")
                    if assignee_hint: changes.append(f"assigned to → {assignee_hint.title()}")
                    if new_project_hint: changes.append(f"project → {new_project_hint}")
                    if new_due_hint: changes.append(f"due date → {new_due_hint}")
                    result["adjudication"]["next_action"] = (
                        f"Found task \"{best_match.get('task')}\" and will update: {', '.join(changes) or 'status'}."
                    )
                    result["kanban_only"] = True
            except Exception as _e:
                print(f"[UPDATE] KanbanTasks_Draft fallback failed: {_e}")

        # Sanitize Decimal/NaN before storing in LangGraph state
        import decimal as _dec
        def _san(o):
            if isinstance(o, dict): return {k: _san(v) for k, v in o.items()}
            if isinstance(o, list): return [_san(v) for v in o]
            if isinstance(o, _dec.Decimal): return float(o)
            if isinstance(o, float) and (math.isnan(o) or math.isinf(o)): return None
            return o
        result = _san(result)
        return Command(
        update={"final_response": result},
        goto="clarify"
        )

    else:  # clarification_received=True AND clarification_needed=False → apply the update
        updated = result_payload.get("updated_item") if result_payload else None
        previous = result_payload.get("previous_item") if result_payload else None

        # Guard: if task was never found, return a friendly message instead of crashing
        if not updated:
            task_hint = ""
            if result_payload and result_payload.get("intent_result"):
                task_hint = result_payload["intent_result"].get("title") or result_payload["intent_result"].get("summary") or ""
            msg = f"I couldn't find a matching task{' for \"' + task_hint + '\"' if task_hint else ''} in the system. Please check the task name or assignee and try again."
            return Command(update={"final_response": msg}, goto=END)

        kanban_only = result_payload.get("kanban_only", False) if result_payload else False

        if not kanban_only:
            update_doc = confirmed_updated_item_to_work_evidence_record(user_text=user_text,
                intent_result=result_payload["intent_result"],
                adjudication=result_payload["adjudication"],
                previous_item=previous,
                updated_item=updated,
                user_confirmation=True,
                workspace_id="default-workspace",
                project_id="",
                source_uri="user_chat",
                embedding_fn=vectorize_with_titan
                )
            response = index_document(doc=update_doc)
            dynamo_response = apply_confirmed_update_dynamodb(updated)
            print(f"Result of Updating the Opensearch index: {response['status_code']}\n{response['text']}")
            print(f"Result of Updating the Dynamo Db: {dynamo_response}\n")
        else:
            print("[UPDATE] kanban_only=True — skipping WorkItems/OpenSearch write")

        # Update Kanban Draft table for UI display
        work_item_id = updated.get("work_item_id") or ""
        project_name = updated.get("project_name") or "Unassigned"
        new_status = updated.get("status") or "pending"
        # Normalize status at write time — ensure clean values stored in DynamoDB
        _ns = new_status.lower().strip()
        if _ns in ("to do", "todo", "to-do"): new_status = "pending"
        elif _ns in ("in progress", "in-progress", "inprogress", "active"): new_status = "in progress"
        elif _ns in ("done", "completed", "complete", "finished"): new_status = "done"
        kanban_table = dynamodb_resource.Table("AgenticColleague_KanbanTasks_Draft")
        if kanban_only:
            # Use the original PK/SK from the matched KanbanTasks_Draft item
            orig_pk = (result_payload.get("previous_item") or {}).get("PK") or f"PROJECT#{(result_payload.get('previous_item') or {}).get('project_name','Unassigned')}"
            pk = updated.get("PK") or f"PROJECT#{project_name}"
            sk = updated.get("SK") or (f"TASK#{work_item_id}" if work_item_id else None)
            if pk and sk:
                kanban_item = dict(updated)
                kanban_item["status"] = new_status
                kanban_item["assigned_to"] = updated.get("assigned_to") or updated.get("assignee", "Unassigned")
                kanban_table.put_item(Item=kanban_item)
                print(f"[UPDATE] KanbanTasks_Draft updated PK={pk} SK={sk} status={new_status}")
                # If project changed, delete the old PK item to avoid stale card on board
                if orig_pk and orig_pk != pk:
                    try:
                        kanban_table.delete_item(Key={"PK": orig_pk, "SK": sk})
                        print(f"[UPDATE] Deleted old KanbanTasks_Draft item PK={orig_pk} SK={sk}")
                    except Exception as _de:
                        print(f"[UPDATE] Could not delete old item: {_de}")
            else:
                print(f"[UPDATE] kanban_only but no PK/SK on updated_item — Kanban not updated")
        elif work_item_id:
            kanban_table.put_item(Item={
                "PK": f"PROJECT#{project_name}",
                "SK": f"TASK#{work_item_id}",
                "work_item_id": work_item_id,
                "project_name": project_name,
                "task": updated.get("task", ""),
                "assigned_to": updated.get("assigned_to") or updated.get("assignee", "Unassigned"),
                "due_date": updated.get("due_date", ""),
                "status": new_status,
                "source_type": "user_chat",
                "source_uri": "chat",
                "ipst_function": IPST_FUNCTION_MAP.get(
                    (updated.get("assignee") or updated.get("assigned_to", "")).strip().title(),
                    IPST_FUNCTION_MAP.get(
                        (updated.get("assignee") or updated.get("assigned_to", "")).strip(), ""
                    )
                ),
            })
            print(f"[UPDATE] Kanban card {work_item_id} updated to status={new_status}")
        else:
            # ── FALLBACK: no work_item_id but we have the task name — scan KanbanTasks_Draft and update matching row ──
            task_name_hint = (updated.get("task") or "").lower().strip()
            if task_name_hint:
                try:
                    _scan = kanban_table.scan()
                    _all = _scan.get("Items", [])
                    while "LastEvaluatedKey" in _scan:
                        _scan = kanban_table.scan(ExclusiveStartKey=_scan["LastEvaluatedKey"])
                        _all.extend(_scan.get("Items", []))
                    _match = next((i for i in _all if task_name_hint in (i.get("task") or "").lower()), None)
                    if _match:
                        kanban_item = dict(_match)
                        kanban_item["status"] = new_status
                        kanban_item["project_name"] = project_name
                        kanban_item["PK"] = f"PROJECT#{project_name}"
                        kanban_item["assigned_to"] = updated.get("assigned_to") or updated.get("assignee") or _match.get("assigned_to", "Unassigned")
                        if updated.get("due_date"): kanban_item["due_date"] = updated["due_date"]
                        # Write to new PK
                        kanban_table.put_item(Item=kanban_item)
                        # Delete old item if PK changed
                        if _match.get("PK") and _match["PK"] != kanban_item["PK"]:
                            kanban_table.delete_item(Key={"PK": _match["PK"], "SK": _match["SK"]})
                        print(f"[UPDATE] Kanban fallback updated task '{_match.get('task')}' PK={kanban_item['PK']} SK={kanban_item['SK']}")
                    else:
                        print(f"[UPDATE] Kanban fallback — no match found for '{task_name_hint}'")
                except Exception as _fe:
                    print(f"[UPDATE] Kanban fallback failed: {_fe}")
            else:
                print(f"[UPDATE] No work_item_id and no task name — Kanban not updated")

        task_name = updated.get("task", "the task")
        changes_made = []
        if updated.get("status"): changes_made.append(f"status → **{updated['status']}**")
        if updated.get("assigned_to") and updated["assigned_to"] != "Unassigned": changes_made.append(f"assigned to → **{updated['assigned_to']}**")
        if updated.get("project_name"): changes_made.append(f"project → **{updated['project_name']}**")
        if updated.get("due_date"): changes_made.append(f"due date → **{updated['due_date']}**")
        result = f"✅ **{task_name}** has been updated: {', '.join(changes_made)}. The Team Board will reflect this shortly."
        return Command(update={"final_response": result}, goto=END)


def clarify_node(state: GraphState) -> Command:
    user_text = "\n".join(state.get("chat_history", []))
    intent = state.get("intent", "unknown")

    # Extract context from final_response (set by update_node / create_node)
    fr = state.get("final_response") or {}
    adjudication = {}
    updated_item = None
    previous_item = None
    if isinstance(fr, dict):
        adjudication   = fr.get("adjudication") or {}
        updated_item   = fr.get("updated_item")
        previous_item  = fr.get("previous_item")

    # If task was not found at all, tell the user directly — no point asking for confirmation
    if updated_item is None and isinstance(fr, dict) and fr.get("mode") == "update_review":
        title_hint = ""
        ir = fr.get("intent_result") or {}
        title_hint = ir.get("title") or ir.get("summary") or ir.get("assignee") or ""
        msg = (f"I couldn't find a task matching \"{title_hint}\" in the system. "
               f"Please double-check the task name or assignee and try again.") if title_hint else \
              "I couldn't find a matching task. Please provide more details about the task name, assignee or project."
        return Command(
            update={"clarification_question": msg, "clarification_received": False, "clarification_needed": False},
            goto=END
        )

    # Build confirmation message from adjudication
    next_action = adjudication.get("next_action", "") if adjudication else ""
    task_name = (updated_item or {}).get("task", "") or ""
    assignee  = (updated_item or {}).get("assignee", "") or ""
    new_status = (updated_item or {}).get("status", "") or ""
    project   = (updated_item or {}).get("project_name", "") or ""

    if task_name and new_status:
        question = (f"I found the task **\"{task_name}\"**"
                    + (f" assigned to **{assignee}**" if assignee else "")
                    + (f" in **{project}**" if project else "")
                    + f" and will update its status to **{new_status}**."
                    + " Shall I apply this change? (yes / no)")
    elif next_action and not isinstance(next_action, dict):
        question = str(next_action) + " Shall I apply this change? (yes / no)"
    else:
        # Fallback — use LLM for a specific clarifying question
        try:
            clarify_prompt = f"""You are a helpful assistant. The user sent:
\"{user_text}\"
Ask ONE short clarifying question to identify which task they want to update."""
            question = llm.invoke(clarify_prompt).content.strip()
        except Exception:
            question = "Could you clarify which task you'd like to update? Please provide the task name and assignee."

    return Command(
        update={"clarification_question": question, "clarification_received": False, "clarification_needed": True},
        goto=END
    )

    if understood_parts:
        understood_str = ", ".join(understood_parts)
        question = (
            f"I understood {understood_str} — but I need a bit more detail to proceed. "
            f"Could you clarify what exactly you'd like me to do?"
        )
    else:
        # Fallback — use LLM to generate a specific question based on the user's message
        try:
            clarify_prompt = f"""You are a helpful assistant. The user sent this message:
"{user_text}"

You need more information to fulfil the request. Ask ONE short, specific clarifying question.
Do not repeat the user's message. Do not explain yourself. Just ask the question."""
            question = llm.invoke(clarify_prompt).content.strip()
        except Exception:
            question = "Could you clarify your request? For example, which task or project are you referring to?"

    return Command(
        update={"clarification_question": question, "clarification_received": False, "clarification_needed": True},
        goto=END
    )


# In[75]:


def build_graph():
    builder = StateGraph(GraphState)
    
    # Add nodes
    builder.add_node("decision", decision_node)
    builder.add_node("inference", inference_node)
    builder.add_node("create", create_node)
    builder.add_node("update", update_node)
    builder.add_node("clarify", clarify_node)
    # # add edges
    # builder.add_edge(START,"decision")
    # builder.add_edge("decision",END)
    
    builder.set_entry_point("decision")

    # Compile
    return builder.compile()


# In[82]:
class ChatRequest(BaseModel):
    chat_history: List[str]
    clarification_received: bool
    result_payload:dict

def clean_nan(obj):
    if isinstance(obj, dict):
        return {k: clean_nan(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan(v) for v in obj]
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
    return obj

def safe_json_dumps(obj):
    """JSON serializer that handles Decimal, NaN, and other non-serializable types from DynamoDB."""
    import decimal
    def default_fn(o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        return str(o)
    try:
        # First clean NaN/Inf floats
        cleaned = clean_nan(obj)
        return json.dumps(cleaned, default=default_fn)
    except Exception:
        return json.dumps(str(obj))

# In[19]:
# @app.get("/")
# def serve_index():
#     return FileResponse("index.html")
    
# @app.get("/style.css")
# def serve_css():
#     return FileResponse("style.css")

# @app.get("/script.js")
# def serve_js():
#     return FileResponse("script.js")

@app.post("/agent")
def agent(req: ChatRequest):
    try:
        chat_history = req.chat_history
        clarification_received = req.clarification_received
        result_payload=req.result_payload

        # ── Canned Q&A check ────────────────────────────────────────────────
        if chat_history:
            latest_msg = chat_history[-1] if isinstance(chat_history[-1], str) else str(chat_history[-1])
            _key = _normalize_q(latest_msg)
            if _key in CANNED_QA:
                import time as _time
                _time.sleep(4.5)
                _html = markdown.markdown(CANNED_QA[_key], extensions=['tables', 'fenced_code'])
                return {"response": _html, "result_payload": {}, "clarification_needed": False}
        # ────────────────────────────────────────────────────────────────────

        initial_state={
            "chat_history" : chat_history,
            "final_response": None,
            "clarification_received": clarification_received,
            "clarification_needed" :False,
            "result_payload":result_payload
        }
        app_graph=build_graph()
        result = app_graph.invoke(initial_state)

        # checking below for the evaluation
        try:
            records = load_records()
            latest_user_query = initial_state['chat_history'][-1]
            llm_response = result['final_response']

            evaluation_response = evaluation(bedrock=bedrock,
                                             model_id=model_id,
                                             user_query=latest_user_query,
                                             ai_response=llm_response,
                                             eval_records=records)
            logger.info("Evaluation results")
            print(f"Evaluation_result: {json.dumps(evaluation_response)}")
            logger.info(f"user_query: {latest_user_query}")
            logger.info(f"response: {llm_response}")
            logger.info(f"evaluation_result: {json.dumps(evaluation_response)}")
            print("Evaluation completed and results stored in eval_logs.txt")
        except Exception as eval_err:
            print(f"Evaluation skipped (non-critical): {eval_err}")
        
        if result["clarification_needed"]:
            # Send the clarification question to the user, not the raw adjudication dict
            clarification_q = result.get("clarification_question") or ""
            if not clarification_q and result.get("final_response"):
                # update/create nodes store the question inside final_response["answer"]
                fr = result["final_response"]
                if isinstance(fr, dict):
                    clarification_q = fr.get("answer") or fr.get("next_action") or fr.get("clarification_question") or ""
                elif isinstance(fr, str):
                    clarification_q = fr
            if not clarification_q:
                clarification_q = "Could you clarify your request? Please provide more details."
            return {
                "response": f"<p>{clarification_q}</p>",
                "result_payload": clean_nan(result["final_response"]),
                "clarification_needed": True
            }
        else:
            fr = result["final_response"]
            # final_response can sometimes be a dict (from update/create nodes) — extract text safely
            if isinstance(fr, dict):
                fr = fr.get("answer") or fr.get("message") or fr.get("next_action") or json.dumps(fr, default=str)
            fr = str(fr) if fr else "No response generated."
            return {
                "response": markdown.markdown(fr, extensions=['tables', 'fenced_code']),
                "result_payload": {},
                "clarification_needed": result["clarification_needed"]
            }
    except Exception as e:
        print(f"Error in /agent endpoint: {e}")
        import traceback
        traceback.print_exc()
        return {
            "response": "<p>Sorry, something went wrong while processing your request. Please try rephrasing your question.</p>",
            "result_payload": {},
            "clarification_needed": False
        }


@app.post("/upload")
async def upload_files(
    files: List[UploadFile] = File(...),
    categories: List[str] = Form(...),
    force_reindex: str = Form(default="false")
):
    try:
        processed = 0
        skipped = 0
        force = force_reindex.lower() == "true"

        # Map UI category labels to source_type keys used by CleaningAgent
        category_to_source_type = {
            "Meeting Transcript": "meeting_transcript",
            "Team Chat": "teams_chat",
            "Outlook": "email",
        }

        for file, category in zip(files, categories):
            contents = await file.read()

            # Deduplication: skip if same file content was already indexed
            # (unless force_reindex is set — e.g. to rebuild with richer task_evidence)
            content_hash = hashlib.md5(contents).hexdigest()
            if not force:
                print(f"[DEDUP] Checking file={file.filename} hash={content_hash} registry={UPLOAD_HASH_REGISTRY}")
                if check_duplicate_in_opensearch(content_hash, filename=file.filename):
                    print(f"[DEDUP] Skipping {file.filename} — already indexed (hash={content_hash})")
                    skipped += 1
                    continue
            else:
                print(f"[DEDUP] Force re-index enabled — skipping dedup check for {file.filename}")

            # Save file locally
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            file_path = os.path.join(UPLOAD_DIR, file.filename)
            with open(file_path, "wb") as f:
                f.write(contents)

            # Step 1: Extract text from file
            text = process_user_upload_to_vector(file_path=file_path)
            print(f"Extracted text from {file.filename}: {text[:200]}")

            if not isinstance(text, str) or not text.strip():
                raise Exception(f"Error processing file: {file.filename}")

            # Step 2: Clean & structure the text using LLM (CleaningAgent logic)
            source_type = category_to_source_type.get(category, "email")

            cleaning_prompt = f"""You are a document processing assistant. Parse the following {source_type} content into structured JSON.

Return ONLY valid JSON with these fields:
{{
  "source_type": "{source_type}",
  "clean_text": "<cleaned version of the content>",
  "summary": "<2-3 sentence summary>",
  "action_items": [{{"title": "", "description": "", "owner": "", "due_date": "", "status": "pending"}}],
  "decisions": [{{"description": "", "confidence": 0.9}}],
  "entities": {{
    "projects": [],
    "tickets": [],
    "people": [],
    "dates": [],
    "systems": [],
    "organizations": []
  }},
  "metadata": {{}}
}}

Content:
{text}
"""
            try:
                cleaned_response = llm.invoke(cleaning_prompt).content
                cleaned_json = json.loads(clean_llm_output(cleaned_response))
            except Exception as e:
                print(f"LLM cleaning failed for {file.filename}: {e}")
                cleaned_json = {
                    "source_type": source_type,
                    "clean_text": text,
                    "summary": text[:300],
                    "action_items": [],
                    "decisions": [],
                    "entities": {"projects": [], "people": [], "dates": [], "tickets": [], "systems": [], "organizations": []},
                    "metadata": {}
                }

            # Step 3: Transform into OpenSearch work_evidence document
            evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
            now = datetime.now(timezone.utc).isoformat()

            clean_text = cleaned_json.get("clean_text", text)
            summary = cleaned_json.get("summary", text[:300])
            entities = cleaned_json.get("entities", {})
            action_items = cleaned_json.get("action_items", [])
            decisions = cleaned_json.get("decisions", [])

            people = entities.get("people", [])
            projects = entities.get("projects", [])
            dates = entities.get("dates", [])

            embedding_text = f"{clean_text}\n{summary}\nProjects: {', '.join(projects)}\nPeople: {', '.join(people)}"

            # content_hash already computed above for dedup check — reuse it here

            work_evidence_doc = {
                "evidence_id": evidence_id,
                "workspace_id": "default-workspace",
                "project_id": "",
                "source_type": source_type,
                "source_uri": f"upload:{file.filename}",
                "content_hash": content_hash,
                "raw_text": json.dumps(cleaned_json, default=str),
                "clean_text": clean_text,
                "summary": summary,
                "embedding_text": embedding_text,
                "linked_work_item_ids": [],
                "action_items_detected": action_items,
                "decisions_detected": decisions,
                "dates_detected": dates,
                "metadata": {
                    "source_uri": f"upload:{file.filename}",
                    "entities": entities
                },
                "created_at": now,
                "updated_at": now,
                "vector_embedding": vectorize_with_titan(embedding_text)
            }

            # Step 4: Index into OpenSearch (work_evidence)
            index_response = index_document(doc=work_evidence_doc)
            print(f"Indexed {file.filename} into OpenSearch: {index_response['status_code']}")

            # Save hash to local registry so future duplicate uploads are caught immediately
            _save_hash_to_registry(content_hash)

            # Step 5: Create work items in DynamoDB for each action item (shows on Kanban)
            action_items = cleaned_json.get("action_items", [])
            projects = cleaned_json.get("entities", {}).get("projects", [])
            project_name = projects[0] if projects else "Unassigned"

            # If force re-index, delete old WorkItems and KanbanTasks for this file first
            # so we don't end up with duplicate cards
            if force:
                try:
                    source_uri_val = f"upload:{file.filename}"
                    wi_table = dynamodb_resource.Table("AgenticColleague_WorkItems")
                    kanban_table_del = dynamodb_resource.Table("AgenticColleague_KanbanTasks_Draft")
                    # Scan WorkItems for this source_uri and delete them
                    scan_kwargs = {
                        "FilterExpression": "source_uri = :uri",
                        "ExpressionAttributeValues": {":uri": source_uri_val},
                        "ProjectionExpression": "PK, SK",
                    }
                    while True:
                        resp = wi_table.scan(**scan_kwargs)
                        for item in resp.get("Items", []):
                            wi_table.delete_item(Key={"PK": item["PK"], "SK": item["SK"]})
                        last_key = resp.get("LastEvaluatedKey")
                        if not last_key:
                            break
                        scan_kwargs["ExclusiveStartKey"] = last_key
                    # Scan KanbanTasks_Draft for this source_uri and delete them
                    scan_kwargs2 = {
                        "FilterExpression": "source_uri = :uri",
                        "ExpressionAttributeValues": {":uri": source_uri_val},
                        "ProjectionExpression": "PK, SK",
                    }
                    while True:
                        resp2 = kanban_table_del.scan(**scan_kwargs2)
                        for item in resp2.get("Items", []):
                            kanban_table_del.delete_item(Key={"PK": item["PK"], "SK": item["SK"]})
                        last_key2 = resp2.get("LastEvaluatedKey")
                        if not last_key2:
                            break
                        scan_kwargs2["ExclusiveStartKey"] = last_key2
                    print(f"[FORCE] Deleted old WorkItems and KanbanTasks for {file.filename}")
                except Exception as del_err:
                    print(f"[FORCE] Could not delete old items for {file.filename}: {del_err}")

            for action_item in action_items:
                if not action_item.get("title") and not action_item.get("description"):
                    continue

                work_item_id = f"WI_{uuid.uuid4().hex[:8]}"
                new_item = {
                    "work_item_id": work_item_id,
                    "project_name": project_name,
                    "task": action_item.get("title") or action_item.get("description", ""),
                    "assignee": action_item.get("owner") or "Unassigned",
                    "due_date": action_item.get("due_date") or "",
                    "status": action_item.get("status") or "pending",
                    "source_type": source_type,
                    "source_uri": f"upload:{file.filename}",
                    "summary": f"{action_item.get('description') or action_item.get('title', '')} | Doc: {summary[:300]}",
                    "event_timestamp": datetime.now(timezone.utc).isoformat(),
                    "evidence_id": work_evidence_doc.get("evidence_id", ""),
                    "task_evidence": f"{summary}\n\n{text[:1200]}",
                }

                # Write to AgenticColleague_WorkItems
                apply_confirmed_update_dynamodb(new_item, table_name="AgenticColleague_WorkItems")

                # Also write to KanbanTasks_Draft for Kanban board display
                kanban_table = dynamodb_resource.Table("AgenticColleague_KanbanTasks_Draft")
                kanban_table.put_item(Item={
                    "PK": f"PROJECT#{project_name}",
                    "SK": f"TASK#{work_item_id}",
                    "work_item_id": work_item_id,
                    "project_name": project_name,
                    "task": new_item["task"],
                    "assigned_to": new_item["assignee"],
                    "due_date": new_item["due_date"],
                    "status": new_item["status"],
                    "source_type": source_type,
                })
                print(f"Created Kanban task: {new_item['task']} -> {new_item['assignee']}")

            processed += 1

        if processed == 0 and skipped > 0:
            return {"response": f"⚠️ All {skipped} file(s) were already uploaded previously and skipped to avoid duplicates."}
        elif skipped > 0:
            return {"response": f"✅ Processed {processed} file(s) successfully. ⚠️ {skipped} file(s) skipped (already uploaded)."}
        elif processed > 0:
            return {"response": f"✅ Successfully processed and indexed {processed} file(s). Work items added to Kanban."}
        else:
            return {"response": "No files were processed."}

    except Exception as e:
        print(f"Error in /upload endpoint: {e}")
        import traceback
        traceback.print_exc()
        return {"response": f"Upload failed: {str(e)}"}

    


@app.get("/tasks")
def get_tasks():

    def decimal_to_json(obj):
        """Convert DynamoDB Decimal to int/float for JSON serialization."""
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return obj

    # DynamoDB resource
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table("AgenticColleague_KanbanTasks_Draft")

    """Get all Kanban tasks from DynamoDB with full pagination."""
    items = []
    response = table.scan()
    items.extend(response.get("Items", []))
    # Paginate through all pages
    while "LastEvaluatedKey" in response:
        response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
        items.extend(response.get("Items", []))

    # Fix Decimal serialization
    clean_items = json.loads(json.dumps(items, default=decimal_to_json))

    # ── Deduplicate by (task name + project name), keep the most recently updated item ──
    seen: dict = {}
    for item in clean_items:
        task_key = (
            (item.get("task") or "").strip().lower(),
            (item.get("project_name") or "").strip().lower(),
        )
        if task_key not in seen:
            seen[task_key] = item
        else:
            # Prefer the item with a newer event_timestamp or updated_at
            existing = seen[task_key]
            new_ts  = item.get("updated_at") or item.get("event_timestamp") or ""
            prev_ts = existing.get("updated_at") or existing.get("event_timestamp") or ""
            if str(new_ts) > str(prev_ts):
                seen[task_key] = item

    deduped_items = list(seen.values())

    # ── Only show tasks relevant to the demo (Noventra IPST) ──
    # These are the tasks referenced by the canned Q&A and Try Asking questions.
    DEMO_KEYWORDS = ["noventra", "ipst"]
    demo_items = [
        item for item in deduped_items
        if any(k in (item.get("project_name") or "").lower() for k in DEMO_KEYWORDS)
    ]
    # Fallback: if no Noventra IPST tasks found (e.g. fresh DB), show all deduped up to 50
    final_items = demo_items if demo_items else deduped_items[:50]

    print(f"[TASKS] Returning {len(final_items)} Noventra IPST tasks (deduped from {len(clean_items)} total)")
    return final_items


@app.delete("/tasks")
def delete_task(pk: str, sk: str):
    """Delete a Kanban card by its DynamoDB PK and SK."""
    try:
        dynamodb_del = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb_del.Table("AgenticColleague_KanbanTasks_Draft")
        table.delete_item(Key={"PK": pk, "SK": sk})
        print(f"[DELETE] Removed Kanban card PK={pk} SK={sk}")
        return {"status": "deleted", "PK": pk, "SK": sk}
    except Exception as e:
        print(f"[DELETE] Failed to delete card PK={pk} SK={sk}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def serve_index():
    return FileResponse("static/index.html")

