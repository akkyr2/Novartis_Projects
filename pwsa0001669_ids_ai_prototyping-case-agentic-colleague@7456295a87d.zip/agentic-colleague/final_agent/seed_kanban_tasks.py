"""
seed_kanban_tasks.py
─────────────────────
Run this script once (with valid AWS credentials) to ensure all tasks
referenced in the canned Q&A answers exist in AgenticColleague_KanbanTasks_Draft.

It uses put_item with a condition so it ONLY inserts if the item does not
already exist — it will NEVER overwrite an existing task.

Usage:
    python seed_kanban_tasks.py
"""

import boto3
from datetime import datetime, timezone
from botocore.exceptions import ClientError

TABLE = "AgenticColleague_KanbanTasks_Draft"
PROJECT = "Noventra IPST"
PK = f"PROJECT#{PROJECT}"

dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
table = dynamodb.Table(TABLE)

def now_iso():
    return datetime.now(timezone.utc).isoformat()

# ── All tasks referenced in canned Q&A Scenarios 1, 2 and Try Asking responses ──
REQUIRED_TASKS = [
    {
        "task": "Medical Evidence Review",
        "assigned_to": "Dr. Priya Nair",
        "ipst_function": "Medical",
        "due_date": "2026-04-15",
        "status": "done",
        "priority": "high",
        "summary": "Dr. Priya Nair completed the medical evidence review later than planned.",
    },
    {
        "task": "Finalize Access Research and Assumptions",
        "assigned_to": "Luis Martinez",
        "ipst_function": "Market Access",
        "due_date": "2026-04-22",
        "status": "in progress",
        "priority": "high",
        "summary": "Luis Martinez is behind schedule finalizing access research and assumptions due to delayed market research results.",
    },
    {
        "task": "Confirm Launch Readiness Status and Decision Log",
        "assigned_to": "Sarah Chen",
        "ipst_function": "BEL",
        "due_date": "2026-04-22",
        "status": "in progress",
        "priority": "high",
        "summary": "Sarah Chen to confirm launch readiness status and maintain decision log.",
    },
    {
        "task": "Reconcile Inputs for TPP",
        "assigned_to": "Priya Nair + Luis Martinez",
        "ipst_function": "Medical + Market Access",
        "due_date": "2026-04-23",
        "status": "in progress",
        "priority": "high",
        "summary": "Dr. Priya Nair and Luis Martinez to reconcile Medical and Market Access inputs for the Target Product Profile.",
    },
    {
        "task": "Update Forecast Based on Final TPP",
        "assigned_to": "Mark Davidson",
        "ipst_function": "Forecasting",
        "due_date": "2026-04-24",
        "status": "in progress",
        "priority": "high",
        "summary": "Mark Davidson to update forecast once TPP inputs are finalized.",
    },
    {
        "task": "Forecast Lock",
        "assigned_to": "Mark Davidson",
        "ipst_function": "Forecasting",
        "due_date": "2026-04-24",
        "status": "in progress",
        "priority": "high",
        "summary": "Forecast Lock remains Provisional / At Risk until the TPP is finalized.",
    },
    {
        "task": "Confirm TPP Decision Path for upcoming MBR",
        "assigned_to": "Sarah Chen",
        "ipst_function": "BEL",
        "due_date": "2026-04-24",
        "status": "in progress",
        "priority": "high",
        "summary": "Sarah Chen to confirm TPP decision path ahead of the June 8 MBR.",
    },
    {
        "task": "Finalize Field Materials with Approved Messaging",
        "assigned_to": "Rachel Kim",
        "ipst_function": "Field Strategy",
        "due_date": "2026-05-01",
        "status": "in progress",
        "priority": "medium",
        "summary": "Rachel Kim to finalize field materials with approved messaging.",
    },
    {
        "task": "Complete Field Training Content",
        "assigned_to": "Rachel Kim",
        "ipst_function": "Field Strategy",
        "due_date": "2026-05-15",
        "status": "pending",
        "priority": "medium",
        "summary": "Rachel Kim to complete field training content.",
    },
    {
        "task": "Launch Readiness Review",
        "assigned_to": "Sarah Chen",
        "ipst_function": "BEL",
        "due_date": "2026-10-01",
        "status": "in progress",
        "priority": "high",
        "summary": "Overall launch readiness remains At Risk until cross-functional inputs are aligned.",
    },
]

inserted = 0
skipped = 0

for t in REQUIRED_TASKS:
    task_id = t["task"].lower().replace(" ", "_").replace("/", "_")[:40]
    sk = f"TASK#{task_id}"

    item = {
        "PK": PK,
        "SK": sk,
        "task_id": task_id,
        "project_name": PROJECT,
        "task": t["task"],
        "assigned_to": t["assigned_to"],
        "ipst_function": t["ipst_function"],
        "due_date": t["due_date"],
        "status": t["status"],
        "priority": t.get("priority", "medium"),
        "summary": t.get("summary", ""),
        "source_type": "seed_script",
        "source_uri": "seed_kanban_tasks.py",
        "event_timestamp": now_iso(),
        "updated_at": now_iso(),
    }

    try:
        # Only insert if item does NOT already exist (condition on PK+SK)
        table.put_item(
            Item=item,
            ConditionExpression="attribute_not_exists(PK) AND attribute_not_exists(SK)",
        )
        print(f"  ✅ Inserted: {t['task']}")
        inserted += 1
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            print(f"  ⏭  Already exists: {t['task']}")
            skipped += 1
        else:
            print(f"  ❌ Error inserting '{t['task']}': {e}")

print(f"\nDone. {inserted} inserted, {skipped} already existed.")
