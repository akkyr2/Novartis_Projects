"""
Run this script once to generate a .docx task update file.
Then upload the generated file via the UI's Upload tab.
"""
from docx import Document
import os

doc = Document()

doc.add_heading("Task Update – Noventra IPST", level=1)

doc.add_paragraph(
    "The following task has been confirmed and should be updated on the Team Board."
)

table = doc.add_table(rows=7, cols=2)
table.style = "Table Grid"

rows = [
    ("Task",       "Finalize field materials with approved messaging"),
    ("Project",    "Noventra IPST"),
    ("Assigned to","Rachel Kim"),
    ("Function",   "Field Strategy"),
    ("Status",     "pending"),
    ("Due Date",   "2026-05-01"),
    ("Priority",   "High"),
]

for i, (label, value) in enumerate(rows):
    table.rows[i].cells[0].text = label
    table.rows[i].cells[1].text = value

doc.add_paragraph("")
doc.add_paragraph(
    "Action: Please update the kanban board to reflect the due date 2026-05-01 "
    "and assign this task to Rachel Kim under project Noventra IPST with status pending."
)

out_path = os.path.join(os.path.dirname(__file__), "task_finalize_field_materials.docx")
doc.save(out_path)
print(f"Created: {out_path}")
