// ===================================================================
// IPST FUNCTION MAP — maps team member names to their IPST function/role
// Update with real IPST member names + functions before the summit demo
// Example functions: CE, Medical, GM, IMO, Regulatory, Market Access, Finance
// ===================================================================
const IPST_FUNCTION_MAP = {
  // ── Demo / POC team (Apollo project) ──
  "Tom Barry":          "GM",
  "Tom":                "GM",
  "Stan Tsvirko":       "Sponsor",
  "Stan":               "Sponsor",
  "Saburi Mohan":       "IMO",
  "Saburi":             "IMO",
  "Satya Shukla":       "CE",
  "Satya":              "CE",
  "Ash":                "Medical",
  "Revath":             "Regulatory",
  "Mohan Dhanalakota":  "Market Access",
  "Mohan":              "Market Access",
  "Sarah Chen":         "BEL",
  "Sarah":              "BEL",
  "Nina Patel":         "Bus. Excellence",
  "Nina":               "Bus. Excellence",
  "Dr. Priya Nair":     "Medical",
  "Dr Priya Nair":      "Medical",
  "Priya Nair":         "Medical",
  "Priya":              "Medical",
  "Luis Martinez":      "Market Access",
  "Luis":               "Market Access",
  "Mark Davidson":      "Forecasting",
  "Mark":               "Forecasting",
  "Priya Nair + Luis Martinez": "Medical + Market Access",
  "Jake Reynolds":      "Marketing",
  "Jake":               "Marketing",
  "Rachel Kim":         "Field Strategy",
  "Rachel":             "Field Strategy",
  "IDS partner":        "IDS",
  // ── Add your real IPST team members below before the demo ──
  // "First Last": "Function",
};

// Global task store — shared between Kanban and Chat pages
let allTasks = [];

// ===== Detect current page and run appropriate logic =====
const currentPage = window.location.pathname.split("/").pop() || "index.html";

if (currentPage === "index.html" || currentPage === "") {
  initKanban();
} else if (currentPage === "upload.html") {
  initUpload();
} else if (currentPage === "chat.html") {
  initChat();
}


// ===================================================================
// KANBAN PAGE
// ===================================================================
function initKanban() {

  // --- Static data (commented out - now fetching from API) ---
  /*
  const tasks = {
    todo: [
      { title: "API Integration", project: "proj‑1", assignee: "Vivek", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Rahul", date: "15 Apr" },
    ],
    inProgress: [
      { title: "Dashboard UI", project: "proj‑2", assignee: "Aman", date: "10 Apr" },
      { title: "Authentication api", project: "proj‑2", assignee: "Ujjawal", date: "30 Apr" },
    ],
    done: [
      { title: "Login Module", project: "proj‑1", assignee: "Rahul", date: "05 Apr" },
    ]
  };
  */

  function getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);
  }

  function getAvatarColor(name) {
    let hash = 0;
    for (let i = 0; i < (name||'').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    const hue = Math.abs(hash % 360);
    return `hsl(${hue}, 55%, 42%)`;
  }

  // allTasks is declared globally above

  function createCard(task, statusClass) {
    const rawAssignee = (task.assigned_to || '').trim();
    const isUnassigned = !rawAssignee || ['unassigned', 'tbd', 'none', 'n/a', ''].includes(rawAssignee.toLowerCase());
    const displayName = isUnassigned ? 'Unassigned' : rawAssignee;
    const initials = isUnassigned ? '?' : getInitials(rawAssignee);
    const color = isUnassigned ? '#666' : getAvatarColor(rawAssignee);
    const id = task.task_id || (task.task + rawAssignee).replace(/\s/g,'');
    const pk = encodeURIComponent(task.PK || `PROJECT#${task.project_name}`);
    const sk = encodeURIComponent(task.SK || `TASK#${id}`);
    // Resolve IPST function for this card's owner
    const fn = (!isUnassigned && (task.ipst_function || lookupIpstFunction(rawAssignee))) || '';
    const fnBadge = fn ? `<span class="func-badge" title="IPST Function">${fn}</span>` : '';
    const tbdClass = isUnassigned ? ' tbd-assignee' : '';
    // Overdue / due-soon colouring
    let dateClass = '';
    if (task.due_date && !['done','completed','complete','finished','closed'].includes((task.status||'').toLowerCase().trim())) {
      const due = new Date(task.due_date); due.setHours(0,0,0,0);
      const today = new Date(); today.setHours(0,0,0,0);
      const diff = Math.round((due - today) / 86400000);
      if (diff < 0) dateClass = ' date-overdue';
      else if (diff <= 3) dateClass = ' date-soon';
    }
    return `
      <div class="kanban-card ${statusClass}" draggable="true" data-task-id="${escapeHtml(id)}" data-task='${JSON.stringify(task).replace(/'/g,"&#39;")}'>  
        <button class="card-delete-btn" title="Delete task" data-pk="${pk}" data-sk="${sk}" onclick="event.stopPropagation()">&times;</button>
        <span class="kanban-project-pill">${task.project_name}</span>
        <h4>${task.task}</h4>
        <div class="kanban-footer">
          <span class="assignee-avatar${tbdClass}" style="background:${color}">${initials}</span>
          <span class="assignee-name${tbdClass}">${displayName}${fnBadge}</span>
          <span class="date${dateClass}">${task.due_date || ""}</span>
        </div>
      </div>
    `;
  }  // Show skeleton cards while loading
  function showSkeletons() {
    const skel = `<div class="kanban-card-skeleton"><div class="skel-line skel-short"></div><div class="skel-line skel-long"></div><div class="skel-line skel-mid"></div></div>`.repeat(3);
    document.getElementById('todoCards').innerHTML = skel;
    document.getElementById('progressCards').innerHTML = skel;
    document.getElementById('doneCards').innerHTML = skel;
  }
  showSkeletons();

  // ── Topbar ticker ──
  const _ticker = document.getElementById('topbarTicker');
  const _phrase1 = 'Tasks extracted from your Microsoft 365 team materials';
  let _tickerTaskCount = null;
  let _tickerInterval = null;
  let _tickerPhase = 0;

  function _typewrite(el, text, cb) {
    el.textContent = '';
    el.classList.remove('ticker-out', 'ticker-in');
    el.classList.add('ticker-visible');
    let i = 0;
    const iv = setInterval(() => {
      el.textContent = text.slice(0, ++i);
      if (i >= text.length) { clearInterval(iv); if (cb) setTimeout(cb, 2200); }
    }, 28);
  }

  function _tickerShow(text) {
    if (!_ticker) return;
    _ticker.classList.add('ticker-out');
    _ticker.classList.remove('ticker-visible');
    setTimeout(() => {
      _ticker.textContent = text;
      _ticker.classList.remove('ticker-out');
      _ticker.classList.add('ticker-in');
      requestAnimationFrame(() => requestAnimationFrame(() => {
        _ticker.classList.remove('ticker-in');
        _ticker.classList.add('ticker-visible');
      }));
    }, 420);
  }

  function _startTickerCycle() {
    if (_tickerInterval) clearInterval(_tickerInterval);
    _tickerInterval = setInterval(() => {
      if (_tickerTaskCount === null) return;
      _tickerPhase = 1 - _tickerPhase;
      const text = _tickerPhase === 0
        ? _phrase1
        : `${_tickerTaskCount} task${_tickerTaskCount !== 1 ? 's' : ''} · auto-refreshes every 10s`;
      _tickerShow(text);
    }, 4000);
  }

  if (_ticker) {
    _ticker.classList.add('ticker-in');
    requestAnimationFrame(() => requestAnimationFrame(() => _typewrite(_ticker, _phrase1, () => _startTickerCycle())));
  }

  function renderBoard(tasks) {
    document.getElementById("todoCount").textContent = tasks.todo.length;
    document.getElementById("progressCount").textContent = tasks.inProgress.length;
    document.getElementById("doneCount").textContent = tasks.done.length;
    const total = tasks.todo.length + tasks.inProgress.length + tasks.done.length;
    _tickerTaskCount = total;

    const emptyHtml = `<div class="kanban-empty">No tasks yet</div>`;
    document.getElementById("todoCards").innerHTML =
      tasks.todo.length ? tasks.todo.map(t => createCard(t, "status-pending")).join("") : emptyHtml;
    document.getElementById("progressCards").innerHTML =
      tasks.inProgress.length ? tasks.inProgress.map(t => createCard(t, "status-progress")).join("") : emptyHtml;
    document.getElementById("doneCards").innerHTML =
      tasks.done.length ? tasks.done.map(t => createCard(t, "status-done")).join("") : emptyHtml;

    // Re-attach drag & click listeners
    initDragAndDrop();
    initCardClick();
  }

  // ── Search / Filter ──
  const searchInput = document.getElementById('kanbanSearch');
  const filterAssignee = document.getElementById('kanbanFilterAssignee');
  const filterProject = document.getElementById('kanbanFilterProject');

  function applyFilters() {
    const q = (searchInput?.value || '').toLowerCase();
    const assignee = (filterAssignee?.value || '').toLowerCase();
    const project = (filterProject?.value || '').toLowerCase();
    const filtered = allTasks.filter(t => {
      if (q && !t.task.toLowerCase().includes(q) && !(t.assigned_to||'').toLowerCase().includes(q) && !(t.project_name||'').toLowerCase().includes(q)) return false;
      if (assignee && (t.assigned_to||'').toLowerCase() !== assignee) return false;
      if (project && (t.project_name||'').toLowerCase() !== project) return false;
      return true;
    });
    const tasks = { todo: [], inProgress: [], done: [] };
    filtered.forEach(item => {
      const status = (item.status || '').toLowerCase().trim();
      if (['done','completed','complete','finished','closed'].includes(status)) tasks.done.push(item);
      else if (['in progress','in_progress','inprogress','active','ongoing','started'].includes(status)) tasks.inProgress.push(item);
      else tasks.todo.push(item);
    });
    renderBoard(tasks);
  }
  if (searchInput) searchInput.addEventListener('input', applyFilters);
  if (filterAssignee) filterAssignee.addEventListener('change', applyFilters);
  if (filterProject) filterProject.addEventListener('change', applyFilters);

  // Track whether the project filter has been set by the user
  let _projectFilterUserSet = false;
  if (filterProject) {
    filterProject.addEventListener('change', () => { _projectFilterUserSet = true; });
  }

  function populateFilters(data) {
    // Normalise to Title Case and deduplicate case-insensitively
    function toTitleCase(s) {
      return s.trim().replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
    }
    function normDedup(arr) {
      const seen = new Map();
      arr.filter(Boolean).forEach(v => {
        const key = v.trim().toLowerCase();
        if (!seen.has(key)) seen.set(key, toTitleCase(v));
      });
      return [...seen.values()].sort();
    }
    const assignees = normDedup(data.map(t => t.assigned_to));
    const projects  = normDedup(data.map(t => t.project_name));
    if (filterAssignee) {
      const cur = (filterAssignee.value || '').toLowerCase();
      filterAssignee.innerHTML = '<option value="">All Assignees</option>' + assignees.map(a => `<option value="${a.toLowerCase()}">${a}</option>`).join('');
      [...filterAssignee.options].forEach(o => { if (o.value === cur) filterAssignee.value = o.value; });
    }
    if (filterProject) {
      const cur = (filterProject.value || '').toLowerCase();
      filterProject.innerHTML = '<option value="">All Projects</option>' + projects.map(p => `<option value="${p.toLowerCase()}">${p}</option>`).join('');
      // Restore previous selection OR default to Noventra IPST on first load
      if (cur) {
        [...filterProject.options].forEach(o => { if (o.value === cur) filterProject.value = o.value; });
      } else if (!_projectFilterUserSet) {
        // Auto-select Noventra IPST — but NOT when navigating from a chat link (?highlight)
        // so the highlighted card is always visible regardless of project
        const hasHighlight = new URLSearchParams(window.location.search).get('highlight');
        if (!hasHighlight) {
          const noventraOpt = [...filterProject.options].find(o => o.value.includes('noventra'));
          if (noventraOpt) { filterProject.value = noventraOpt.value; }
        }
      }
    }
  }

  // ── Drag & Drop ──
  function initDragAndDrop() {
    const cards = document.querySelectorAll('.kanban-card[draggable]');
    const columns = document.querySelectorAll('.kanban-cards-scroll');

    cards.forEach(card => {
      card.addEventListener('dragstart', e => {
        card.classList.add('dragging');
        e.dataTransfer.setData('text/plain', card.dataset.taskId);
        e.dataTransfer.effectAllowed = 'move';
      });
      card.addEventListener('dragend', () => card.classList.remove('dragging'));
    });

    columns.forEach(col => {
      col.addEventListener('dragover', e => { e.preventDefault(); col.classList.add('drag-over'); });
      col.addEventListener('dragleave', () => col.classList.remove('drag-over'));
      col.addEventListener('drop', e => {
        e.preventDefault();
        col.classList.remove('drag-over');
        const taskId = e.dataTransfer.getData('text/plain');
        // Determine new status from column
        let newStatus = 'To Do';
        if (col.id === 'progressCards') newStatus = 'In Progress';
        else if (col.id === 'doneCards') newStatus = 'Done';
        // Find task and update via chat API
        const task = allTasks.find(t => (t.task_id || (t.task + t.assigned_to).replace(/\s/g,'')) === taskId);
        if (task && (task.status || '').toLowerCase().trim() !== newStatus.toLowerCase()) {
          showToast(`Moving "${task.task}" \u2192 ${newStatus}...`, 'info', 2500);
          // Build a message that clearly triggers update intent in the decision node
          const statusPhrase = newStatus === 'Done' ? 'mark it done'
            : newStatus === 'In Progress' ? 'set status to in progress'
            : 'set status to to do';
          const dragMsg = `${statusPhrase} — task: "${task.task}", assignee: ${task.assigned_to}, project: ${task.project_name}`;
          fetch('./agent', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_history: [dragMsg],
              clarification_received: false,
              result_payload: {}
            })
          })
          .then(r => r.json())
          .then(data => {
            if (data.clarification_needed) {
              // Auto-confirm: send 'yes' with the payload from first call
              return fetch('./agent', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  chat_history: [dragMsg, 'yes'],
                  clarification_received: true,
                  result_payload: { ...data.result_payload, clarification_needed: false }
                })
              }).then(r => r.json());
            }
            // Agent applied update directly (no clarification needed)
            return data;
          })
          .then(finalData => {
            if (finalData && finalData.clarification_needed) {
              // Shouldn't happen but guard anyway
              showToast(`Update pending — please confirm in Chat`, 'warning');
            } else {
              showToast(`\u2705 "${task.task}" moved to ${newStatus}`, 'success');
            }
            setTimeout(fetchAndRenderTasks, 1500);
          })
          .catch(() => showToast('Failed to update task — try via Chat instead', 'error'));
        }
      });
    });
  }

  // ── Card Click → Expand Modal ──
  function initCardClick() {
    document.querySelectorAll('.kanban-card[data-task]').forEach(card => {
      card.addEventListener('click', e => {
        if (e.target.closest('.assignee-avatar') || e.target.closest('.card-delete-btn')) return;
        try {
          const task = JSON.parse(card.dataset.task);
          showCardModal(task);
        } catch(err) {}
      });
    });

    // Delete button
    document.querySelectorAll('.card-delete-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const card = btn.closest('.kanban-card');
        const taskName = card.querySelector('h4')?.textContent || 'this task';
        if (!confirm(`Delete "${taskName}" from the board?`)) return;
        const pk = decodeURIComponent(btn.dataset.pk);
        const sk = decodeURIComponent(btn.dataset.sk);
        fetch(`./tasks?pk=${encodeURIComponent(pk)}&sk=${encodeURIComponent(sk)}`, { method: 'DELETE' })
          .then(r => r.json())
          .then(() => {
            card.style.transition = 'opacity .3s, transform .3s';
            card.style.opacity = '0';
            card.style.transform = 'scale(.85)';
            setTimeout(() => { card.remove(); fetchAndRenderTasks(); }, 320);
            showToast(`🗑️ "${taskName}" deleted`, 'info');
          })
          .catch(() => showToast('Failed to delete task', 'error'));
      });
    });
  }

  function showCardModal(task) {
    const overlay = document.createElement('div');
    overlay.className = 'card-modal-overlay';
    const fn = task.ipst_function || lookupIpstFunction(task.assigned_to || '');
    const assignee = task.assigned_to && !['unassigned','tbd','none','n/a'].includes((task.assigned_to||'').toLowerCase())
      ? task.assigned_to : '<span style="opacity:.6;font-style:italic">Unassigned</span>';
    overlay.innerHTML = `
      <div class="card-modal" style="position:relative;">
        <button class="modal-close" title="Close (Esc)">&times;</button>
        <h3>${task.task}</h3>
        <div class="modal-grid">
          <span class="modal-label">Project</span>      <span class="modal-value">${task.project_name || '—'}</span>
          <span class="modal-label">Assigned to</span>  <span class="modal-value">${assignee}</span>
          <span class="modal-label">Function</span>     <span class="modal-value">${fn ? `<span class="func-badge">${fn}</span>` : '<span style="opacity:.4">—</span>'}</span>
          <span class="modal-label">Status</span>       <span class="modal-value">${task.status || '—'}</span>
          <span class="modal-label">Due date</span>     <span class="modal-value">${task.due_date || '—'}</span>
          <span class="modal-label">Priority</span>     <span class="modal-value">${task.priority || '—'}</span>
          ${task.description ? `<span class="modal-label">Description</span><span class="modal-value">${task.description}</span>` : ''}
        </div>
        <div class="modal-esc-hint">Press Esc or click outside to close</div>
      </div>
    `;
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    overlay.querySelector('.modal-close').addEventListener('click', () => overlay.remove());
    document.addEventListener('keydown', function escHandler(e) {
      if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', escHandler); }
    });
    document.body.appendChild(overlay);
  }

  let lastTaskCount = -1;

  // ── Highlight a card when navigated from a chat link ──
  function checkHighlight() {
    const params = new URLSearchParams(window.location.search);
    const highlight = params.get('highlight');
    if (!highlight) return;
    const lower        = highlight.toLowerCase().trim();
    const assigneeHint = (params.get('assignee') || '').toLowerCase().trim();
    const statusHint   = (params.get('status')   || '').toLowerCase().trim();

    // Map status hint to the column id it should be in
    const DONE_STATUSES = ['done','completed','complete','finished','closed'];
    const PROG_STATUSES = ['in progress','in_progress','inprogress','active','ongoing','started'];
    let expectedCol = null;
    if (statusHint) {
      if (DONE_STATUSES.some(s => statusHint.startsWith(s))) expectedCol = 'doneCards';
      else if (PROG_STATUSES.some(s => statusHint.startsWith(s))) expectedCol = 'progressCards';
      else expectedCol = 'todoCards'; // at risk, not ready, blocked, provisional, pending → todo
    }

    let found = null;
    let bestScore = -1;
    document.querySelectorAll('.kanban-card').forEach(card => {
      const title    = (card.querySelector('h4')?.textContent || '').trim().toLowerCase();
      const assignee = (card.querySelector('.assignee-name')?.textContent || '').trim().toLowerCase();
      const colId    = card.closest('.kanban-cards-scroll')?.id || '';

      // Score title match
      let score = -1;
      if (title === lower) score = 100;
      else if (title.includes(lower) || lower.includes(title)) score = 50;
      else {
        const titleWords = new Set(title.split(/\s+/));
        const overlap = lower.split(/\s+/).filter(w => w.length > 2 && titleWords.has(w)).length;
        if (overlap > 0) score = overlap;
      }
      if (score < 0) return;

      // Boost: assignee matches (skip generic unassigned)
      const isGenericAssignee = ['unassigned','tbd','none','n/a',''].includes(assigneeHint);
      if (assigneeHint && !isGenericAssignee) {
        const hintWords = assigneeHint.split(/\s+/).filter(w => w.length > 1);
        const matchCount = hintWords.filter(w => assignee.includes(w)).length;
        if (matchCount > 0) score += 200 * matchCount; // +200 per matched name word (first + last = +400)
      }
      // Boost: card is in the expected status column
      if (expectedCol && colId === expectedCol) {
        score += 500;
      }

      if (score > bestScore) { bestScore = score; found = card; }
    });
    if (found && bestScore >= 0) {
      found.classList.add('card-highlight');
      found.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => found.classList.remove('card-highlight'), 8000);
    } else if (highlight) {
      // Card not found — show a toast so user knows board is open but task wasn't matched
      showToast(`Task "${highlight.length > 40 ? highlight.slice(0,40)+'…' : highlight}" not found on board`, 'info', 5000);
    }
  }

  function fetchAndRenderTasks() {
    fetch("./tasks")
      .then(res => res.json())
      .then(data => {
        allTasks = data;
        populateFilters(data);

        // If filters active, use them
        const q = (searchInput?.value || '').toLowerCase();
        const assignee = filterAssignee?.value || '';
        const project = filterProject?.value || '';
        const _hlParam = new URLSearchParams(window.location.search).get('highlight');
        if (q || assignee || project) {
          applyFilters();
          // Still run highlight after filter renders if navigating from chat
          if (_hlParam && lastTaskCount < 0) {
            lastTaskCount = data.length;
            let _hlTries = 0;
            function _tryHlFiltered() {
              _hlTries++;
              checkHighlight();
              if (_hlTries < 8 && !document.querySelector('.card-highlight')) setTimeout(_tryHlFiltered, 400);
            }
            setTimeout(_tryHlFiltered, 300);
          }
        }
        else {
          const tasks = { todo: [], inProgress: [], done: [] };
          data.forEach(item => {
            const status = (item.status || "").toLowerCase().trim();
            if (["done", "completed", "complete", "finished", "closed"].includes(status)) {
              tasks.done.push(item);
            } else if (["in progress", "in_progress", "inprogress", "active", "ongoing", "started"].includes(status)) {
              tasks.inProgress.push(item);
            } else {
              tasks.todo.push(item);
            }
          });
          // Toast on task count change (after first load)
          if (lastTaskCount >= 0 && data.length !== lastTaskCount) {
            showToast(`Board updated — ${data.length} tasks`, 'info');
          }
          const isFirstLoad = lastTaskCount < 0;
          lastTaskCount = data.length;
          renderBoard(tasks);
          // On the very first load, scroll to highlighted card if URL has ?highlight=
          if (isFirstLoad) {
            // Retry checkHighlight until a matching card is found (board render may lag)
            let _hlTries = 0;
            function _tryHighlight() {
              _hlTries++;
              const params = new URLSearchParams(window.location.search);
              if (!params.get('highlight')) return;
              checkHighlight();
              // If no card highlighted yet and still early, retry
              if (_hlTries < 8 && !document.querySelector('.card-highlight')) {
                setTimeout(_tryHighlight, 400);
              }
            }
            setTimeout(_tryHighlight, 300);
          }
        }
      })
      .catch(err => {
        console.error("Failed to fetch tasks from API:", err);
      });
  }

  // Fetch immediately on page load
  fetchAndRenderTasks();

  // Auto-refresh every 10 seconds
  setInterval(fetchAndRenderTasks, 10000);
}


// ===================================================================
// UPLOAD PAGE
// ===================================================================
function initUpload() {
  let selectedFiles = [];

  const fileInput = document.getElementById("fileInput");
  const fileCards = document.getElementById("fileCards");
  const dropPlaceholder = document.getElementById("dropPlaceholder");
  const fileCategorySelect = document.getElementById("fileCategory");

  fileInput.addEventListener("change", (e) => {
    const category = fileCategorySelect.value;
    if (!category) {
      alert("Please select Doc Type first");
      fileInput.value = "";
      return;
    }
    for (let file of e.target.files) {
      selectedFiles.push({ file, category });
    }
    fileCategorySelect.value = "";
    fileInput.value = "";
    renderFiles();
  });

  // Expose globally for onclick handlers
  window.removeFile = function(index) {
    selectedFiles.splice(index, 1);
    renderFiles();
  };

  window.uploadAllFiles = function() {
    if (selectedFiles.length === 0) {
      alert("No files selected");
      return;
    }
    const formData = new FormData();
    selectedFiles.forEach((item) => {
      formData.append("files", item.file);
      formData.append("categories", item.category);
    });
    const forceCheckbox = document.getElementById("forceReindex");
    const forceReindex = forceCheckbox && forceCheckbox.checked;
    if (forceReindex) formData.append("force_reindex", "true");

    const uploadBtn = document.getElementById("uploadBtn");
    const statusBanner = document.getElementById("uploadStatus");
    const progressWrap = document.getElementById("uploadProgressWrap");
    const progressBar = document.getElementById("uploadProgressBar");
    if (uploadBtn) { uploadBtn.disabled = true; uploadBtn.textContent = "Uploading…"; }
    if (statusBanner) { statusBanner.style.display = "none"; }
    if (progressWrap) { progressWrap.classList.add("active"); }
    if (progressBar) { progressBar.style.width = "15%"; }

    // Simulate progress while waiting
    let fakeProgress = 15;
    const progressInterval = setInterval(() => {
      fakeProgress = Math.min(fakeProgress + Math.random() * 12, 85);
      if (progressBar) progressBar.style.width = fakeProgress + "%";
    }, 600);

    fetch("../upload", { method: "POST", body: formData })
      .then(res => res.json())
      .then((data) => {
        clearInterval(progressInterval);
        if (progressBar) progressBar.style.width = "100%";
        setTimeout(() => { if (progressWrap) progressWrap.classList.remove("active"); }, 800);
        const msg = (data.response || "");
        const isDuplicate = msg.includes("already uploaded") || msg.includes("skipped");
        const isFailed = msg.toLowerCase().includes("failed") || msg.toLowerCase().includes("error");

        if (statusBanner) {
          statusBanner.style.display = "block";
          statusBanner.textContent = msg || "Upload complete.";
          if (isDuplicate && !msg.includes("✅")) {
            // All files were duplicates
            statusBanner.style.background = "rgba(251,191,36,0.15)";
            statusBanner.style.border = "1px solid rgba(251,191,36,0.5)";
            statusBanner.style.color = "#fbbf24";
          } else if (isFailed) {
            statusBanner.style.background = "rgba(239,68,68,0.15)";
            statusBanner.style.border = "1px solid rgba(239,68,68,0.4)";
            statusBanner.style.color = "#f87171";
          } else {
            // Success (possibly with some skipped)
            statusBanner.style.background = "rgba(34,197,94,0.12)";
            statusBanner.style.border = "1px solid rgba(34,197,94,0.4)";
            statusBanner.style.color = "#4ade80";
          }
        }

        if (!isFailed) {
          selectedFiles = [];
          renderFiles();
        }
      })
      .catch(err => {
        console.error(err);
        clearInterval(progressInterval);
        if (progressWrap) progressWrap.classList.remove("active");
        showToast('Upload failed — please try again', 'error');
        if (statusBanner) {
          statusBanner.style.display = "block";
          statusBanner.textContent = "❌ Upload failed — please try again.";
          statusBanner.style.background = "rgba(239,68,68,0.15)";
          statusBanner.style.border = "1px solid rgba(239,68,68,0.4)";
          statusBanner.style.color = "#f87171";
        }
      })
      .finally(() => {
        if (uploadBtn) { uploadBtn.disabled = false; uploadBtn.textContent = "Upload All"; }
      });
  };

  function renderFiles() {
    fileCards.innerHTML = "";
    if (selectedFiles.length === 0) {
      dropPlaceholder.style.display = "block";
    } else {
      dropPlaceholder.style.display = "none";
    }
    selectedFiles.forEach((item, index) => {
      const card = document.createElement("div");
      card.className = "file-card";
      card.innerHTML = `
        <div class="file-card-content" id="content-${index}">Loading...</div>
        <div class="file-card-meta">
          <span class="file-card-category">${item.category}</span>
          <span class="file-card-size">${formatSize(item.file.size)}</span>
        </div>
        <div class="file-card-header">
          <span class="file-card-name">${item.file.name}</span>
          <button class="remove-btn" onclick="removeFile(${index})">✕</button>
        </div>
      `;
      fileCards.appendChild(card);
      loadFileContent(item.file, index);
    });
  }

  function loadFileContent(file, index) {
    const contentDiv = document.getElementById(`content-${index}`);
    const type = file.type;
    const name = file.name.toLowerCase();

    if (type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (e) => { contentDiv.innerHTML = `<img src="${e.target.result}" alt="${file.name}" />`; };
      reader.readAsDataURL(file);

    } else if (type === "application/pdf" || name.endsWith(".pdf")) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const pdf = await pdfjsLib.getDocument({ data: e.target.result }).promise;
          const page = await pdf.getPage(1);
          const viewport = page.getViewport({ scale: 0.8 });
          const canvas = document.createElement("canvas");
          canvas.width = viewport.width;
          canvas.height = viewport.height;
          canvas.style.width = "100%";
          canvas.style.borderRadius = "6px";
          const ctx = canvas.getContext("2d");
          await page.render({ canvasContext: ctx, viewport }).promise;
          contentDiv.innerHTML = "";
          contentDiv.appendChild(canvas);
          if (pdf.numPages > 1) {
            contentDiv.innerHTML += `<span class="file-type-label" style="display:block;margin-top:4px;">Page 1 of ${pdf.numPages}</span>`;
          }
        } catch { contentDiv.innerHTML = `<span class="file-type-label">📄 PDF (preview failed)</span>`; }
      };
      reader.readAsArrayBuffer(file);

    } else if (type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || name.endsWith(".docx")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        mammoth.convertToHtml({ arrayBuffer: e.target.result })
          .then((result) => {
            const preview = result.value.length > 1000 ? result.value.substring(0, 1000) + "..." : result.value;
            contentDiv.innerHTML = `<div class="docx-preview">${preview}</div>`;
          })
          .catch(() => { contentDiv.innerHTML = `<span class="file-type-label">📄 Word (preview failed)</span>`; });
      };
      reader.readAsArrayBuffer(file);

    } else if (name.endsWith(".doc")) {
      contentDiv.innerHTML = `<span class="file-type-label">📄 Word (.doc) — preview not supported</span>`;

    } else if (type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || type === "application/vnd.ms-excel" || name.endsWith(".xlsx") || name.endsWith(".xls")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const workbook = XLSX.read(e.target.result, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
          const rows = jsonData.slice(0, 10);
          let html = `<table class="xlsx-preview"><tbody>`;
          rows.forEach((row, i) => {
            html += `<tr>`;
            row.forEach((cell) => { html += i === 0 ? `<th>${escapeHtml(String(cell ?? ""))}</th>` : `<td>${escapeHtml(String(cell ?? ""))}</td>`; });
            html += `</tr>`;
          });
          html += `</tbody></table>`;
          if (jsonData.length > 10) html += `<span class="file-type-label">...${jsonData.length - 10} more rows</span>`;
          contentDiv.innerHTML = html;
        } catch { contentDiv.innerHTML = `<span class="file-type-label">📊 Excel (preview failed)</span>`; }
      };
      reader.readAsArrayBuffer(file);

    } else if (type.startsWith("video/")) {
      const reader = new FileReader();
      reader.onload = (e) => { contentDiv.innerHTML = `<video src="${e.target.result}" controls class="video-preview"></video>`; };
      reader.readAsDataURL(file);

    } else if (type.startsWith("audio/")) {
      const reader = new FileReader();
      reader.onload = (e) => { contentDiv.innerHTML = `<audio src="${e.target.result}" controls class="audio-preview"></audio>`; };
      reader.readAsDataURL(file);

    } else if (type.startsWith("text/") || type === "application/json" || type === "application/xml" || name.endsWith(".csv")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        const preview = text.length > 500 ? text.substring(0, 500) + "..." : text;
        contentDiv.innerHTML = `<pre>${escapeHtml(preview)}</pre>`;
      };
      reader.readAsText(file);

    } else {
      contentDiv.innerHTML = `<span class="file-type-label">📎 ${file.type || "Unknown"} — no preview</span>`;
    }
  }
}


// ===================================================================
// CHAT PAGE
// ===================================================================
function initChat() {
  const chatMessages = document.getElementById("chatMessages");
  const chatInput = document.getElementById("chatInput");

  // ── Pre-load tasks so postProcessBotMessage can build accurate board links ──
  fetch('./tasks').then(r => r.json()).then(data => {
    allTasks = data;
    // Re-process any bot bubbles already rendered (e.g. canned responses that came back
    // before tasks were fetched, or messages restored from localStorage)
    document.querySelectorAll('.msg-bubble--bot').forEach(bubble => postProcessBotMessage(bubble));
  }).catch(() => {});

  // ── State ──
  let chatHistory           = JSON.parse(localStorage.getItem("chatHistory") || "[]");
  let resultPayload         = JSON.parse(localStorage.getItem("resultPayload") || "{}");
  let clarificationNeeded   = JSON.parse(localStorage.getItem("clarificationNeeded") || "false");
  let clarificationReceived = JSON.parse(localStorage.getItem("clarificationReceived") || "false");
  let savedMessages         = JSON.parse(localStorage.getItem("chatMessages") || "[]");
  let requestInFlight       = false;
  let abortController       = null;
  let isNavigatingAway      = false;   // set true on beforeunload — silences ANY fetch error

  // ── Auto-resize textarea ──
  if (chatInput) {
    chatInput.addEventListener("input", () => {
      chatInput.style.height = "auto";
      chatInput.style.height = Math.min(chatInput.scrollHeight, 140) + "px";
    });
    chatInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });
  }

  // ── On navigation away: flag it + abort the fetch ──
  // Browser can kill fetch with TypeError("Failed to fetch") OR AbortError
  // depending on timing. The flag catches both cases.
  window.addEventListener("beforeunload", () => {
    isNavigatingAway = true;
    if (abortController) abortController.abort("navigation");
  });

  // ── State flag: suppress scroll during bulk message restore ──
  let isRestoring = false;

  // ── Restore saved messages — strip any stale error messages before restoring ──
  const ERROR_TEXT = "Something went wrong. Please try again.";
  savedMessages = savedMessages.filter(m => m.text !== ERROR_TEXT);
  localStorage.setItem("chatMessages", JSON.stringify(savedMessages));

  if (savedMessages.length > 0) {
    hideWelcome();
    isRestoring = true;
    savedMessages.forEach(msg => appendMessage(msg.text, msg.sender, false));
    isRestoring = false;
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  // ── Re-sync on tab return — only re-render if messages were added from another window ──
  let savedScrollTop = 0;
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      // Save scroll position when leaving tab
      savedScrollTop = chatMessages.scrollTop;
    } else if (document.visibilityState === "visible") {
      const fresh = JSON.parse(localStorage.getItem("chatMessages") || "[]");
      if (fresh.length > savedMessages.length) {
        // New messages added from another window — re-render silently
        savedMessages = fresh;
        chatMessages.innerHTML = "";
        isRestoring = true;
        savedMessages.forEach(msg => appendMessage(msg.text, msg.sender, false));
        isRestoring = false;
        chatMessages.scrollTop = chatMessages.scrollHeight;
      } else {
        // Same messages — just restore exact scroll position, no re-render
        chatMessages.scrollTop = savedScrollTop;
      }
    }
  });

  // ── Fire a request (shared by send + re-fire on load) ──
  function firePendingRequest(requestBody) {
    if (requestInFlight) return;
    requestInFlight = true;
    disableInput();
    showTyping();
    abortController = new AbortController();
    fetch("../agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody),
      signal: abortController.signal
    })
      .then(res => {
        // Read raw text first so we never lose the body
        return res.text().then(rawText => ({ ok: res.ok, status: res.status, rawText }));
      })
      .then(({ ok, status, rawText }) => {
        removeTyping();
        if (isNavigatingAway) return;
        localStorage.removeItem("chatPendingRequest");
        let data;
        try { data = JSON.parse(rawText); }
        catch (e) {
          console.error("Non-JSON response from /agent ("+status+"):", rawText.slice(0,300));
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        if (!ok) {
          console.error("Error response from /agent:", status, data);
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        const botAnswer = data.answer || data.response || "Sorry, I couldn't find an answer."
        appendMessage(botAnswer, "bot", true, true);
        resultPayload       = data.result_payload;
        clarificationNeeded = data.clarification_needed;
        saveState();
      })
      .catch(err => {
        removeTyping();
        if (isNavigatingAway || err.name === "AbortError") return;
        localStorage.removeItem("chatPendingRequest");
        console.error("firePendingRequest error:", err.name, err.message);
        appendMessage("Something went wrong. Please try again.", "bot", false);
      })
      .finally(() => {
        requestInFlight = false;
        enableInput();
      });
  }

  // ── On load: re-fire any pending request after a short delay so page is fully ready ──
  const pendingOnLoad = localStorage.getItem("chatPendingRequest");
  if (pendingOnLoad) {
    try {
      const req = JSON.parse(pendingOnLoad);
      setTimeout(() => firePendingRequest(req), 400);
    } catch (e) {
      localStorage.removeItem("chatPendingRequest");
    }
  }

  function saveState() {
    localStorage.setItem("chatHistory",          JSON.stringify(chatHistory));
    localStorage.setItem("resultPayload",         JSON.stringify(resultPayload));
    localStorage.setItem("clarificationNeeded",   JSON.stringify(clarificationNeeded));
    localStorage.setItem("clarificationReceived", JSON.stringify(clarificationReceived));
    localStorage.setItem("chatMessages",          JSON.stringify(savedMessages));
  }

  function disableInput() {
    if (chatInput) chatInput.disabled = true;
    const sendBtn = document.getElementById("sendBtn");
    if (sendBtn) sendBtn.disabled = true;
  }

  function enableInput() {
    if (chatInput) chatInput.disabled = false;
    const sendBtn = document.getElementById("sendBtn");
    if (sendBtn) sendBtn.disabled = false;
    if (chatInput) chatInput.focus();
  }

  function hideWelcome() {
    const w = document.getElementById("chatWelcome");
    if (w) w.remove();
  }

  window.sendMessage = function() {
    if (!chatInput) return;
    const text = chatInput.value.trim();
    if (!text) return;

    hideWelcome();
    appendMessage(text, "user");
    chatInput.value = "";
    chatInput.style.height = "auto";
    requestInFlight = true;
    disableInput();
    showTyping();

    if (clarificationNeeded) {
      clarificationReceived = true;
      // Must clear clarification_needed in the payload so update_node
      // takes the "apply update" branch, not the "re-ask" branch
      clarificationNeeded = false;
    } else {
      chatHistory = [];
      clarificationReceived = false;
    }
    chatHistory.push(text);
    saveState();

    // When sending a confirmation, strip clarification_needed from result_payload too
    const payloadToSend = resultPayload
      ? { ...resultPayload, clarification_needed: false }
      : resultPayload;
    const requestBody = { chat_history: chatHistory, clarification_received: clarificationReceived, result_payload: payloadToSend };
    localStorage.setItem("chatPendingRequest", JSON.stringify(requestBody));

    abortController = new AbortController();
    fetch("../agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody),
      signal: abortController.signal
    })
      .then(res => {
        return res.text().then(rawText => ({ ok: res.ok, status: res.status, rawText }));
      })
      .then(({ ok, status, rawText }) => {
        removeTyping();
        if (isNavigatingAway) return;
        localStorage.removeItem("chatPendingRequest");
        let data;
        try { data = JSON.parse(rawText); }
        catch (e) {
          console.error("Non-JSON response from /agent ("+status+"):", rawText.slice(0,300));
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        if (!ok) {
          console.error("Error response from /agent:", status, data);
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        const botAnswer = data.answer || data.response || "Sorry, I couldn't find an answer.";
        appendMessage(botAnswer, "bot", true, true);
        resultPayload       = data.result_payload;
        clarificationNeeded = data.clarification_needed;
        saveState();
      })
      .catch(err => {
        removeTyping();
        if (isNavigatingAway || err.name === "AbortError") return;
        localStorage.removeItem("chatPendingRequest");
        console.error("sendMessage error:", err.name, err.message);
        appendMessage("Something went wrong. Please try again.", "bot", false);
      })
      .finally(() => {
        requestInFlight = false;
        enableInput();
      });
  };

  // ── Suggestion chips (sidebar) ──
  window.askSuggestion = function(btn) {
    const text = btn.textContent.trim();
    if (!text || !chatInput) return;
    chatInput.value = text;
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 140) + "px";
    sendMessage();
  };

  // ── Welcome panel quick chips ──
  window.useQuickPrompt = function(btn) {
    const text = btn.textContent.trim();
    if (!text || !chatInput) return;
    chatInput.value = text;
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 140) + "px";
    sendMessage();
  };

  // ── Clear chat ──
  window.clearChat = function() {
    chatHistory = [];
    resultPayload = {};
    clarificationNeeded = false;
    clarificationReceived = false;
    savedMessages = [];
    ["chatHistory","resultPayload","clarificationNeeded","clarificationReceived","chatMessages","chatPendingRequest"]
      .forEach(k => localStorage.removeItem(k));
    chatMessages.innerHTML = `
      <div class="chat-welcome" id="chatWelcome">
        <div class="chat-welcome-icon">🤖</div>
        <h3>What would you like to know?</h3>
        <p>I can answer questions about your uploaded documents, track tasks, and help you find key information.</p>
        <div class="chat-quick-actions">
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">Who is working on Project Apollo?</button>
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">What are the blockers on the Noventra launch?</button>
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">What decisions were made in the last meeting?</button>
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">What tasks are still pending?</button>
        </div>
      </div>`;
  };

  // ── Append message (with optional typewriter for bot) ──
  let _lastUserRow = null;
  function scrollToShowQuestion() {
    if (_lastUserRow && !isRestoring) {
      requestAnimationFrame(() => {
        _lastUserRow.scrollIntoView({ behavior: 'instant', block: 'start' });
      });
    } else if (!isRestoring) {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }

  function appendMessage(text, sender, persist = true, typewriter = false) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const isUser = sender === "user";

    const row = document.createElement("div");
    row.className = `msg-row ${isUser ? "msg-row--user" : "msg-row--bot"}`;

    const avatar = document.createElement("div");
    avatar.className = `msg-avatar ${isUser ? "msg-avatar--user" : "msg-avatar--bot"}`;
    avatar.textContent = isUser ? "You" : "AI";

    const stack = document.createElement("div");
    stack.className = "msg-stack";

    const meta = document.createElement("div");
    meta.className = "msg-meta";
    meta.textContent = (isUser ? "You" : "Agentic Colleague") + " · " + timeStr;

    const bubble = document.createElement("div");
    bubble.className = `msg-bubble ${isUser ? "msg-bubble--user" : "msg-bubble--bot"}`;

    if (isUser) {
      bubble.textContent = text;
      if (!isRestoring) _lastUserRow = row;
    } else if (typewriter) {
      bubble.innerHTML = "";
      stack.appendChild(meta);
      stack.appendChild(bubble);
      row.appendChild(avatar);
      row.appendChild(stack);
      chatMessages.appendChild(row);
      if (isHtml(text)) {
        bubble.innerHTML = applyThemeToHtml(text);
        scrollToShowQuestion();
        if (!isRestoring) {
          setTimeout(() => {
            postProcessBotMessage(bubble);
            scrollToShowQuestion();
            const idx = savedMessages.length - 1;
            if (idx >= 0 && savedMessages[idx].sender === 'bot') {
              savedMessages[idx].text = bubble.innerHTML;
              localStorage.setItem('chatMessages', JSON.stringify(savedMessages));
            }
          }, 0);
        }
      } else {
        typewriterEffect(bubble, text);
      }
      if (persist) savedMessages.push({ text, sender });
      return;
    } else {
      bubble.innerHTML = isHtml(text) ? applyThemeToHtml(text) : renderMarkdown(text);
      if (!isRestoring) {
        setTimeout(() => {
          postProcessBotMessage(bubble);
          scrollToShowQuestion();
          const idx = savedMessages.length - 1;
          if (idx >= 0 && savedMessages[idx].sender === 'bot') {
            savedMessages[idx].text = bubble.innerHTML;
            localStorage.setItem('chatMessages', JSON.stringify(savedMessages));
          }
        }, 0);
      }
    }

    stack.appendChild(meta);
    stack.appendChild(bubble);
    if (isUser) {
      row.appendChild(stack);
      row.appendChild(avatar);
    } else {
      row.appendChild(avatar);
      row.appendChild(stack);
    }
    chatMessages.appendChild(row);
    if (!isRestoring) {
      if (isUser) {
        // Scroll so the question appears at the top — response will appear below it
        requestAnimationFrame(() => row.scrollIntoView({ behavior: 'instant', block: 'start' }));
      }
      else scrollToShowQuestion();
    }

    if (persist) savedMessages.push({ text, sender });
  }

  // ── Detect if text is already HTML (from backend markdown.markdown()) ──
  function isHtml(text) {
    return /<(p|h[1-6]|ul|ol|li|table|thead|tbody|tr|td|th|strong|em|code|pre|br|div)[\s>]/i.test(text);
  }

  // ── Inject md-table class into backend <table> tags so CSS styles apply ──
  function applyThemeToHtml(html) {
    // Add md-table to tables that don't have it yet (handles both with/without existing class)
    return html
      .replace(/<table([^>]*class="([^"]*)")([^>]*)>/gi, (m, p1, cls, p3) =>
        cls.includes('md-table') ? m : `<table${p1.replace(cls, cls + ' md-table')}${p3}>`
      )
      .replace(/<table(?![^>]*class=)([^>]*)>/gi, '<table class="md-table"$1>');
  }

  // ── Markdown renderer (lightweight) ──
  function renderMarkdown(text) {
    if (!text) return '';
    let html = text;

    // Code blocks (protect from other transforms)
    const codeBlocks = [];
    html = html.replace(/```([\s\S]*?)```/g, (_, code) => {
      codeBlocks.push(`<pre><code>${code}</code></pre>`);
      return `%%CODE${codeBlocks.length - 1}%%`;
    });

    // Tables — must run before line-break conversion
    html = html.replace(/((?:^\|.+\|\s*\n?)+)/gm, (match) => {
      const rows = match.trim().split('\n').filter(r => r.trim());
      // Filter separator rows like |---|---|
      const dataRows = rows.filter(r => !/^\|[\s:\-|]+\|$/.test(r.trim()));
      if (dataRows.length < 1) return match;
      const parseRow = r => r.replace(/^\||\|$/g, '').split('|').map(c => c.trim());
      const [header, ...body] = dataRows;
      const ths = parseRow(header).map(h => `<th>${h}</th>`).join('');
      const trs = body.map(r => `<tr>${parseRow(r).map(c => `<td>${c}</td>`).join('')}</tr>`).join('');
      return `<table class="md-table"><thead><tr>${ths}</tr></thead><tbody>${trs}</tbody></table>`;
    });

    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    // Bold
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    // Italic
    html = html.replace(/(?<![*])\*([^*]+)\*(?![*])/g, '<em>$1</em>');
    // Headers
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    // Unordered lists
    html = html.replace(/^[-•*] (.+)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>[\s\S]*?<\/li>\n?)+/g, m => `<ul>${m}</ul>`);
    // Ordered lists
    html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');
    // Line breaks (skip inside block elements already converted)
    html = html.replace(/(?<!<\/table>)(?<!<\/ul>)(?<!<\/h[23]>)\n/g, '<br>');
    // Clean up extra <br> after block elements
    html = html.replace(/(<\/table>|<\/ul>|<\/h[23]>|<\/pre>)<br>/g, '$1');
    // Remove <br> tags immediately before a table (gap before table fix)
    html = html.replace(/(<br>\s*)+(<table)/g, '$2');
    // Remove leading <br> tags at the very start
    html = html.replace(/^(<br>\s*)+/, '');
    // Restore code blocks
    html = html.replace(/%%CODE(\d+)%%/g, (_, i) => codeBlocks[+i]);
    return html;
  }

  // ── Typewriter effect ──
  function typewriterEffect(bubble, fullText) {
    const speed = 8;
    const chunkSize = 3;
    let index = 0;
    bubble.classList.add("typing-response");
    bubble.innerHTML = "";

    function tick() {
      index = Math.min(index + chunkSize, fullText.length);
      const visible = fullText.slice(0, index);
      bubble.innerHTML = escapeHtml(visible).replace(/\n/g, "<br>");
      // Keep question visible at top while response grows below it
      scrollToShowQuestion();
      if (index < fullText.length) {
        setTimeout(tick, speed);
      } else {
        bubble.classList.remove("typing-response");
        bubble.innerHTML = renderMarkdown(fullText);
        setTimeout(() => {
          postProcessBotMessage(bubble);
          scrollToShowQuestion();
          const idx = savedMessages.length - 1;
          if (idx >= 0 && savedMessages[idx].sender === 'bot') {
            savedMessages[idx].text = bubble.innerHTML;
            localStorage.setItem('chatMessages', JSON.stringify(savedMessages));
          }
        }, 0);
        scrollToShowQuestion();
      }
    }
    tick();
  }

  function showTyping() {
    const row = document.createElement("div");
    row.className = "msg-row msg-row--bot";
    row.id = "typingIndicator";
    row.innerHTML = `
      <div class="msg-avatar msg-avatar--bot">AI</div>
      <div class="msg-stack">
        <div class="msg-meta">Agentic Colleague</div>
        <div class="msg-bubble msg-bubble--bot">
          <div class="typing-dots"><span></span><span></span><span></span></div>
        </div>
      </div>`;
    chatMessages.appendChild(row);
    scrollToShowQuestion();
  }

  function removeTyping() {
    const t = document.getElementById("typingIndicator");
    if (t) t.remove();
  }
}


// ===================================================================
// SHARED UTILITIES
// ===================================================================
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// ── IPST function lookup ──
// Tries (in order): exact → strip prefix (Dr./Mr./Ms.) → first-name → partial contains
function lookupIpstFunction(name) {
  if (!name) return '';
  const raw = name.trim();

  // 1. Exact match
  if (IPST_FUNCTION_MAP[raw]) return IPST_FUNCTION_MAP[raw];

  const lower = raw.toLowerCase();

  // 2. Case-insensitive exact
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    if (k.trim().toLowerCase() === lower) return v;
  }

  // 3. Strip honorific prefix (Dr., Mr., Ms., Prof.) and retry
  const stripped = lower.replace(/^(dr\.?|mr\.?|ms\.?|mrs\.?|prof\.?)\s+/i, '').trim();
  if (stripped !== lower) {
    for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
      if (k.trim().toLowerCase() === stripped) return v;
    }
  }

  // 4. First-name match (first word of the cell vs first word of map key)
  const firstName = lower.split(/\s+/)[0];
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    if (k.trim().toLowerCase().split(/\s+/)[0] === firstName) return v;
  }

  // 5. Partial contains — map key appears anywhere inside cell text
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    const kl = k.trim().toLowerCase();
    if (kl.length > 3 && lower.includes(kl)) return v;
  }

  // 6. Cell text appears inside a map key
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    const kl = k.trim().toLowerCase();
    if (lower.length > 3 && kl.includes(lower)) return v;
  }

  return '';
}

// ── Post-process a bot message bubble ──
// 1. Makes task names in assignment tables clickable (→ Kanban highlight)
// 2. Injects a Function column based on IPST_FUNCTION_MAP if not already present
function postProcessBotMessage(bubble) {
  if (!bubble) return;
  // Query all tables — also add md-table class to any that slipped through
  bubble.querySelectorAll('table').forEach(t => t.classList.add('md-table'));
  const tables = bubble.querySelectorAll('table');
  tables.forEach(table => {
    const headerRow = table.querySelector('thead tr');
    if (!headerRow) return;
    const ths = Array.from(headerRow.querySelectorAll('th'));
    const headers = ths.map(th => th.textContent.trim().toLowerCase());

    const nameIdx = headers.findIndex(h => ['name','assignee','assigned to','owner'].includes(h));
    const taskIdx = headers.findIndex(h => ['task','action item','action items','description','item','preparation responsibility','responsibility','work item'].includes(h));
    const funcIdx = headers.findIndex(h => ['function','func','role','ipst function','function / role'].includes(h));

    // ── Scenario 3 MBR prep table — skip task links (preparation responsibility column) ──
    const isMbrPrepTable = headers.includes('preparation responsibility');

    // ── Inject Function column if there's a Name/Assignee col and no Function col ──
    // Also fill in empty/dash cells if Function column already exists
    if (nameIdx !== -1) {
      if (funcIdx === -1) {
        // Column missing — inject it
        const funcTh = document.createElement('th');
        funcTh.textContent = 'Function';
        const insertAfter = ths[nameIdx + 1] || null;
        if (insertAfter) headerRow.insertBefore(funcTh, insertAfter);
        else headerRow.appendChild(funcTh);

        table.querySelectorAll('tbody tr').forEach(row => {
          const cells = row.querySelectorAll('td');
          const nameVal = nameIdx < cells.length ? cells[nameIdx].textContent.trim() : '';
          const fn = lookupIpstFunction(nameVal);
          const funcTd = document.createElement('td');
          funcTd.innerHTML = fn
            ? `<span class="function-badge">${fn}</span>`
            : '<span style="opacity:.4">—</span>';
          const insertAfterTd = cells[nameIdx + 1] || null;
          if (insertAfterTd) row.insertBefore(funcTd, insertAfterTd);
          else row.appendChild(funcTd);
        });
      } else {
        // Column exists — overwrite with badge if we have a lookup result for this name
        // Always overwrite: our map is authoritative regardless of what the LLM put in the cell
        table.querySelectorAll('tbody tr').forEach(row => {
          const cells = row.querySelectorAll('td');
          if (funcIdx >= cells.length) return;
          const nameVal = nameIdx < cells.length ? cells[nameIdx].textContent.trim() : '';
          const fn = lookupIpstFunction(nameVal);
          if (fn) {
            cells[funcIdx].innerHTML = `<span class="function-badge">${fn}</span>`;
          } else {
            // No match — render a muted dash so it looks clean
            const existing = cells[funcIdx].textContent.trim();
            if (!existing || /^[-–—\s]*$/.test(existing)) {
              cells[funcIdx].innerHTML = '<span style="opacity:.4">—</span>';
            }
          }
        });
      }
    }

    // ── Make task name cells clickable links to the Kanban board ──
    if (taskIdx !== -1) {
      const isInStatic = window.location.pathname.includes('/static/');
      const kanbanBase = isInStatic ? '../' : './';
      table.querySelectorAll('tbody tr').forEach(row => {
        const cells = row.querySelectorAll('td');
        if (taskIdx >= cells.length) return;
        const cell = cells[taskIdx];
        
        // Skip if already processed
        if (cell.querySelector('a.chat-task-link')) return;
        
        const taskName = cell.textContent.trim();
        if (!taskName || ['—', '-', '...'].includes(taskName)) return;

        // ── Look up real task data from allTasks for accurate highlight params ──
        let realAssignee = '', realStatus = '';
        if (allTasks && allTasks.length > 0) {
          const tLower = taskName.toLowerCase();
          // Score each task: exact match > contains > word overlap
          let bestMatch = null, bestScore = -1;
          allTasks.forEach(t => {
            const tStr = (t.task || '').toLowerCase();
            let sc = 0;
            if (tStr === tLower) sc = 100;
            else if (tStr.includes(tLower) || tLower.includes(tStr)) sc = 50;
            else {
              const words = tLower.split(/\s+/).filter(w => w.length > 3);
              sc = words.filter(w => tStr.includes(w)).length;
            }
            if (sc > bestScore) { bestScore = sc; bestMatch = t; }
          });
          if (bestMatch && bestScore > 0) {
            realAssignee = bestMatch.assigned_to || '';
            realStatus   = bestMatch.status || '';
          }
        }

        // Fall back to what the table says if lookup found nothing
        if (!realAssignee && nameIdx !== -1 && nameIdx < cells.length)
          realAssignee = cells[nameIdx].textContent.trim();
        if (!realStatus) {
          const statusIdx = Array.from(table.querySelectorAll('thead th')).findIndex(th => ['status','state'].includes(th.textContent.trim().toLowerCase()));
          if (statusIdx !== -1 && statusIdx < cells.length) realStatus = cells[statusIdx].textContent.trim();
        }

        const genericAssignee = ['unassigned','tbd','none','n/a','—','-',''].includes((realAssignee||'').toLowerCase().trim());
        const assigneeParam = (!genericAssignee && realAssignee) ? `&assignee=${encodeURIComponent(realAssignee)}` : '';
        const statusParam   = realStatus ? `&status=${encodeURIComponent(realStatus)}` : '';
        cell.innerHTML =
          `<a class="chat-task-link" href="${kanbanBase}?highlight=${encodeURIComponent(taskName)}${assigneeParam}${statusParam}" target="_blank" title="Open on Team Board">${taskName} <span class="link-icon">📋</span></a>`;
      });
    }

  });
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1048576).toFixed(1) + " MB";
}

// ── Toast Notification System ──
function showToast(message, type = 'success', duration = 4000) {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span class="toast-msg">${message}</span>`;
  container.appendChild(toast);
  // Trigger enter animation
  requestAnimationFrame(() => toast.classList.add('toast--visible'));
  setTimeout(() => {
    toast.classList.remove('toast--visible');
    toast.classList.add('toast--exit');
    setTimeout(() => toast.remove(), 350);
  }, duration);
}

// ── Theme Swatch Picker (4 themes) ──
(function initTheme() {
  const saved = localStorage.getItem('theme') || 'dark';
  applyTheme(saved);

  document.addEventListener('click', e => {
    const swatch = e.target.closest('.theme-swatch');
    if (!swatch) return;
    const theme = swatch.dataset.theme;
    if (theme) applyTheme(theme);
  });

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    document.querySelectorAll('.theme-swatch').forEach(s => {
      s.classList.toggle('active', s.dataset.theme === theme);
    });
  }
})();
