import logging
import json
import pandas as pd
import io
import boto3
from io import BytesIO
from typing import Any, Dict, List
import json
from typing import Any, Dict, List

logging.basicConfig(
    filename="eval_logs.txt",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

logger = logging.getLogger(__name__)

s3 = boto3.client('s3', region_name="us-east-1")
bucket_name = "ids-aini-prototype-ai-analytics"
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"

# read the eval file from s3
def extract_text_from_bedrock_response(response_body_str):
    payload = json.loads(response_body_str)
    content_blocks = payload.get("content", [])
    text_parts = []

    for block in content_blocks:
        if block.get("type") == "text":
            text_parts.append(block.get("text", ""))

    return "\n".join(text_parts).strip()

def parse_llm_json(text):
    text = text.strip()

    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) >= 3:
            text = "\n".join(lines[1:-1]).strip()

    return json.loads(text)
    
def load_records_from_s3():
    eval_dataset_key = "Agentic-Colleague-synthetic/agentic_colleague_test_cases(in).csv"  # hard coding this key
    response = s3.get_object(Bucket=bucket_name, Key=eval_dataset_key)
    df = pd.read_csv(io.BytesIO(response['Body'].read()))
    records = []
    for _, row in df.iterrows():
        records.append({
            "question": row["Question"],
            "expected_answer": row["Expected Answer (Summary)"],
            "evaluation_critera": row["Evaluation Criteria"],
            "combined_text": f"Question: {row['Question']}\nExpected answer: {row['Expected Answer (Summary)']}\nEvaluation criteria: {row['Evaluation Criteria']}"
        })
    return records
    
def load_records():
    
    df = pd.read_csv("agentic_colleague_test_cases(in).csv")
    records = []
    for _, row in df.iterrows():
        records.append({
            "question": row["Question"],
            "expected_answer": row["Expected Answer (Summary)"],
            "evaluation_critera": row["Evaluation Criteria"],
            "combined_text": f"Question: {row['Question']}\nExpected answer: {row['Expected Answer (Summary)']}\nEvaluation criteria: {row['Evaluation Criteria']}"
        })
    return records


def evaluation(bedrock, model_id, user_query, ai_response, eval_records):
    JUDGE_SYSTEM_PROMPT = """
    You are an evaluator judging the quality of an AI response.

    You will be given:
    - a user query
    - a candidate response
    - a small set of reference examples

    Your job is to score the candidate response using these metrics:

    1. relevance: Does the response address the user query?
    2. correctness: Is the response consistent with the reference examples and free of major factual errors?
    3. completeness: Does the response cover the important parts of the user query?

    Scoring scale:
    - 1 = very poor
    - 2 = poor
    - 3 = acceptable
    - 4 = good
    - 5 = excellent

    Return ONLY valid JSON with this exact schema:
    {
      "relevance": <int 1-5>,
      "correctness": <int 1-5>,
      "completeness": <int 1-5>,
      "overall_score": <float>,
      "pass": <true or false>,
      "reason": "<short explanation>"
    }

    Rules:
    - Return exactly one JSON object.
    - Do not include markdown.
    - Do not include code fences.
    - Do not include any text before or after the JSON.
    - Use the reference examples as guidance, not as a requirement for exact wording.
    - Penalize responses that are off-topic, incorrect, or missing key details.
    - Keep reason concise.
    """.strip()

    def build_judge_user_eval_prompt(
        query_text: str,
        response: str,
        retrieved_records: List[Dict[str, Any]]
    ) -> str:
        references_text = "\n\n".join(
            [
                f"Reference {i + 1}:\n"
                f"Question: {record.get('question', '')}\n"
                f"Expected answer: {record.get('expected_answer', '')}"
                for i, record in enumerate(retrieved_records)
            ]
        )

        return f"""
User query:
{query_text}

Candidate response:
{response}

Reference examples:
{references_text}
""".strip()

    def invoke_bedrock_judge(
        bedrock,
        model_id: str,
        query_text: str,
        response: str,
        retrieved_records: List[Dict[str, Any]],
        max_tokens: int = 1000,
        temperature: float = 0.0
    ) -> Dict[str, Any]:
        user_prompt = build_judge_user_eval_prompt(
            query_text=query_text,
            response=response,
            retrieved_records=retrieved_records
        )

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": JUDGE_SYSTEM_PROMPT,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": user_prompt
                        }
                    ]
                }
            ]
        }

        response_obj = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps(body)
        )

        response_body = response_obj["body"].read().decode("utf-8")

        parsed_body = extract_text_from_bedrock_response(response_body)
        result = parse_llm_json(parsed_body)

        required_keys = [
            "relevance",
            "correctness",
            "completeness",
            "overall_score",
            "pass",
            "reason"
        ]
        missing = [k for k in required_keys if k not in result]
        if missing:
            raise ValueError(f"Missing keys in judge output: {missing}")

        return result

    def compute_overall_score(relevance: int, correctness: int, completeness: int) -> float:
        return round((relevance + correctness + completeness) / 3.0, 2)

    def apply_pass_rule(result: Dict[str, Any]) -> Dict[str, Any]:
        result["overall_score"] = compute_overall_score(
            result["relevance"],
            result["correctness"],
            result["completeness"]
        )
        result["pass"] = (
            result["relevance"] >= 4 and
            result["correctness"] >= 4 and
            result["completeness"] >= 3
        )
        return result

    def evaluate_response_with_bedrock(
        bedrock,
        model_id,
        query_text,
        response,
        retrieved_records
    ) -> Dict[str, Any]:
        result = invoke_bedrock_judge(
            bedrock=bedrock,
            model_id=model_id,
            query_text=query_text,
            response=response,
            retrieved_records=retrieved_records
        )

        return apply_pass_rule(result)

    return evaluate_response_with_bedrock(
        bedrock=bedrock,
        model_id=model_id,
        query_text=user_query,
        response=ai_response,
        retrieved_records=eval_records
    )


# example usage
# result = evaluation(
#     bedrock=bedrock,
#     model_id=model_id,
#     user_query=question,
#     ai_response = final_response,
#     eval_records = records
# )


# logger.info(f"user_query: {question}")
# logger.info(f"response: {final_response}")
# logger.info(f"evaluation_result: {json.dumps(result)}")