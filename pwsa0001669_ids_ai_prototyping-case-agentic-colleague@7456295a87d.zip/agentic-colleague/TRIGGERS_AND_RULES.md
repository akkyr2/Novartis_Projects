# Agentic Colleague — Triggers & Rules Reference

> **Source**: Derived from `check/20260428_Agentic_Colleague_Questionnarie_with Responses (2).xlsx`, Sheet 2 — "Triggers and Rules"
>
> **Status Legend**: ✅ Implemented | ⚠️ Partial / POC limitation | ❌ Not implemented

---

## Table of Contents

1. [Section A — Ingestion Triggers](#section-a--ingestion-triggers)
2. [Section B — Structured-Memory Update Triggers](#section-b--structured-memory-update-triggers)
3. [Section C — Work-State / Kanban Triggers](#section-c--work-state--kanban-triggers)
4. [Rules](#rules)

---

## Section A — Ingestion Triggers

These triggers fire when new source material arrives in the system. All source types reach the backend through the **Document Upload UI** (`/upload`) — no live polling or webhook integration exists in the current prototype.

| # | Trigger | Status | Code Location |
|---|---------|--------|---------------|
| A-1 | New meeting transcript uploaded | ✅ | `final_agent/main.py:2747` (`POST /upload`), category mapped at `:2760` (`"Meeting Transcript" → "meeting_transcript"`) |
| A-2 | New Teams channel message uploaded | ✅ | `final_agent/main.py:2747`, category mapped at `:2761` (`"Team Chat" → "teams_chat"`) |
| A-3 | New Teams chat message uploaded | ✅ | `final_agent/main.py:2747`, same `"teams_chat"` branch at `:2761` |
| A-4 | New email / Outlook message uploaded | ✅ | `final_agent/main.py:2747`, category mapped at `:2762` (`"Outlook" → "email"`) |
| A-5 | New file added (any category) | ✅ | `final_agent/main.py:2747` — any supported MIME type triggers ingestion pipeline |
| A-6 | Existing file updated / re-indexed | ✅ | `final_agent/main.py:2751` (`force_reindex: str = Form(default="false")`), evaluated at `:2756` (`force = force_reindex.lower() == "true"`); force-reindex path at `:2769`, `:2778`, `:2888` |
| A-7 | New seed / reference content manually added | ✅ | `final_agent/main.py:2747` — same upload pipeline; category selected by user at upload time |
| A-8 | User requests refresh / rescan | ✅ | **Passive**: `final_agent/static/script.js:317` (`setInterval(fetchAndRenderTasks, 5000)` — Kanban auto-refreshes every 5 s). **Active re-index**: `force_reindex=true` param at `final_agent/main.py:2751` |
| A-9 | User sends chat message → agent pipeline | ✅ | `final_agent/main.py:2679` (`POST /agent`); routes into `decision_node` at `:2073` |

> **Note**: Live system polling (Teams Graph API, Outlook connector) is **out of scope** for this POC. All ingestion is manual via the Upload UI.

---

## Section B — Structured-Memory Update Triggers

These triggers fire once ingested content is parsed by the `CleaningAgent`, causing records to be written or updated in **DynamoDB** (`AgenticColleague_Tasks` / `AgenticColleague_KanbanTasks_Draft`) and **OpenSearch** (work-evidence index).

| # | Trigger | Status | Code Location |
|---|---------|--------|---------------|
| B-1 | New decision detected in source | ✅ | `CleaningAgent` extracts `decisions[]`; stored to OpenSearch field `decisions_detected` at `final_agent/main.py:391`, `:418`. Retrieved via `knn_search_work_evidence` at `:365`, `:646` |
| B-2 | New action item detected in source | ✅ | `CleaningAgent` extracts `action_items[]`; stored to `action_items_detected` at `:390`, `:417`. Work item row created via `create_node` at `:2322` |
| B-3 | New owner assignment detected | ✅ | `assigned_to` field extracted from source and stored in DynamoDB item. Updated via `update_node` at `:2374` |
| B-4 | Explicit status change detected | ✅ | `status` field managed through `update_node` (`:2374`). Status transitions (e.g., `in_progress` → `done`) applied directly or via adjudication |
| B-5 | New blocker detected in source | ✅ | `CleaningAgent` extracts `blockers[]`; `blocker` field in `GraphState` at `:126`. Retrieval query enriched with "blockers" keyword at `:606` |
| B-6 | New dependency detected | ✅ | `dependency` field in `GraphState` at `:127`. Stored as part of work-item record |
| B-7 | New open issue detected | ✅ | Covered by `blockers[]` schema in `CleaningAgent`; issues stored similarly to blockers (`:606`) |
| B-8 | Explicit resolution / closure detected | ✅ | Status set to `done` or `completed` via `update_node` (`:2374`) when source indicates closure |
| B-9 | Source conflicts with existing memory | ✅ | `conflict_flag: bool` at `:141`, `conflict_reason: str` at `:142`. Adjudication prompt at `:1039`, `:1046`, `:1067`, `:1068`. `confirm_overwrite` branch executed at `:1167`; user-facing message produced at `:1168–1171` |
| B-10 | User provides new information via chat | ✅ | `POST /agent` (`:2679`) → `decision_node` (`:2073`) detects `create` intent → `create_node` (`:2322`). `source_uri` set to `"user_chat"` in evidence record; stored at `:387–415` |
| B-11 | User corrects / overrides existing record via chat | ✅ | `decision_node` (`:2073`) detects `update` intent → adjudication → `clarify_node` (`:2533`) if ambiguous. `clarification_needed: bool` in `GraphState` at `:143`; cleared on confirm at `script.js:722` |

> **Source provenance**: Every record stores `source_uri` and `source_type` (`final_agent/main.py:387–415`) so the origin of each update is always traceable.

---

## Section C — Work-State / Kanban Triggers

These triggers govern transitions on the Kanban board (`AgenticColleague_KanbanTasks_Draft`).

| # | Trigger | Status | Code Location |
|---|---------|--------|---------------|
| C-1 | New action item → new work item on board | ✅ | Upload pipeline → `create_node` (`:2322`) → `kanban_table.put_item()` writes to `KanbanTasks_Draft` |
| C-2 | Source changes item status (stage) | ✅ | `update_node` (`:2374`) updates `status` field in both DynamoDB tables |
| C-3 | Source assigns / reassigns ownership | ✅ | `assigned_to` field updated via `update_node` (`:2374`) |
| C-4 | Item blocked / unblocked | ⚠️ | `blocker` field stored in `GraphState` (`:126`) and DynamoDB, but **no dedicated "Blocked" Kanban column** exists in this POC |
| C-5 | Dependency relationship recorded | ✅ | `dependency` field stored in `GraphState` (`:127`) and work-item record |
| C-6 | Item completed / closed | ✅ | `status` → `done` via `update_node` (`:2374`); Kanban card moves to "Done" column |
| C-7 | User adds / updates / assigns / moves / closes via chat | ✅ | `POST /agent` (`:2679`) → `decision_node` (`:2073`) routes to `create_node` (`:2322`) or `update_node` (`:2374`) based on detected intent |
| C-8 | Chat context implies work-state change (implicit) | ✅ | `decision_node` (`:2073`) uses LLM inference to detect implicit intent (e.g., "we wrapped that up" → `update` with `status=done`) |

**Kanban refresh mechanism:**

| Event | Mechanism | Code Location |
|-------|-----------|---------------|
| Drag-and-drop column change | `initDragAndDrop()` calls `PATCH /tasks/{id}` then `fetchAndRenderTasks()` | `script.js:145`, `:211` |
| Auto-poll (every 5 s) | `setInterval(fetchAndRenderTasks, 5000)` | `script.js:317` |
| On page load | `fetchAndRenderTasks()` called once | `script.js:314` |
| After chat sends a message | `fetchAndRenderTasks()` called in `sendMessage` callback | `script.js:707` |

---

## Rules

> **Rule 2 is excluded** from this document per project scope.

### Rule 1 — Act only on clear signals; ask when ambiguous

**Intent**: The system should apply changes directly when the intent is unambiguous. It must ask the user for clarification rather than guess.

**Status**: ✅ Implemented

| Condition | Decision value | Code Location |
|-----------|---------------|---------------|
| Intent is clear, item found, no conflict | `apply_directly` | `final_agent/main.py:1046`, `:1067`, `:1162` |
| Intent is clear but evidence conflicts | `confirm_overwrite` | `final_agent/main.py:1039`, `:1067`, `:1068`, `:1167` |
| Intent is ambiguous (which item?) | `needs_clarification` | `final_agent/main.py:1037`, `:1069`, `:1046` |
| No matching item exists | `no_matching_item` | `final_agent/main.py:1046`, `:1070` |

Adjudication prompt (update path): `final_agent/main.py:1030–1075`
Adjudication prompt (create path — deduplication): `final_agent/main.py:1213`, decision values: `create_new | possible_duplicate | overwrite_existing | ignore_new_request | needs_clarification`

---

### Rule 3 — Never autonomously resolve a conflict; surface it to the user

**Intent**: When two pieces of evidence disagree, the system must surface the conflict and ask the user to confirm before overwriting.

**Status**: ✅ Implemented

- `conflict_flag: bool` in `GraphState` — `final_agent/main.py:141`
- `conflict_reason: str` in `GraphState` — `final_agent/main.py:142`
- Adjudication rule: `"prefer confirm_overwrite instead of reject_update"` — `final_agent/main.py:1039`
- `confirm_overwrite` branch fires user-facing message: `"Historical evidence differs from the user request. Please confirm..."` — `final_agent/main.py:1167–1171`
- `resolution_confidence: float` tracked in `GraphState` — `final_agent/main.py:140`
- `resolution_method: "ambiguous"` used when system cannot decide — `final_agent/main.py:995`

---

### Rule 4 — No autonomous outbound chasing / reminders

**Intent**: The agent must not send proactive nudges, reminders, or notifications to team members.

**Status**: ✅ Compliant (by omission)

No reminder-dispatch, notification-send, or proactive-message logic exists anywhere in `final_agent/main.py` or `final_agent/static/script.js`. The agent is strictly reactive — it only responds to user-initiated messages or upload events.

---

### Rule 5 — Project-scoped context only; no external data sources

**Intent**: The system operates solely on content uploaded to the project. It must not reach out to external APIs, web search, or live system feeds.

**Status**: ✅ Compliant

- All content enters via `POST /upload` (`final_agent/main.py:2747`)
- All retrieval is from project's own OpenSearch index (`knn_search_work_evidence` at `:365`) and DynamoDB tables
- No external HTTP calls to Teams Graph API, Outlook, Jira, or web search in the codebase

---

### Rule 6 — Chat is the primary interaction surface

**Intent**: All create / update / query / clarify operations must be accessible through the chat interface.

**Status**: ✅ Implemented

- Every operation routes through `POST /agent` (`final_agent/main.py:2679`) → `decision_node` (`:2073`)
- Chat UI: `final_agent/static/chat.html` + `final_agent/static/script.js`
- `sendMessage` function: `script.js:707`
- Clarification flow (chat-based confirm/deny): `script.js:722`, `:768`

---

### Rule 7 — Surface ambiguity; ask one focused question at a time

**Intent**: When the system cannot resolve an ambiguity, it must ask the user a single, focused clarifying question rather than proceeding or asking multiple questions.

**Status**: ✅ Implemented

- `needs_clarification` decision in adjudication prompt: `final_agent/main.py:1037`, `:1069`
- `clarification_needed: bool` in `GraphState`: `final_agent/main.py:143`
- `clarify_node` handles clarification loop: `final_agent/main.py:2533`
- Frontend detects `clarification_needed` flag and presents yes/no confirm buttons: `script.js:189`, `:654`, `:722`, `:768`

---

### Rule 8 — Preserve all structured fields; do not silently drop data

**Intent**: Every field in a work item (title, owner, status, blocker, dependency, source, dates) must be preserved through updates. A partial update must not erase unmentioned fields.

**Status**: ✅ Implemented

- Full field set defined in `GraphState`: `final_agent/main.py:100–160` (title, description, assigned_to, status, blocker, dependency, resolution_confidence, conflict_flag, conflict_reason, clarification_needed, …)
- Source provenance always stored: `source_uri`, `source_type` — `final_agent/main.py:387–415`
- `update_node` (`:2374`) performs selective field updates (only fields present in the parsed update are changed; others are left intact)

---

### Rule 9 — Do not overwrite a stronger signal with a weaker one

**Intent**: If existing evidence for a field is based on a strong source (e.g., an explicit decision in a meeting transcript) and a new, weaker signal contradicts it, the system must prefer `confirm_overwrite` rather than silently applying the change.

**Status**: ✅ Implemented

- Adjudication rule: `"If historical evidence conflicts with the user's request, prefer confirm_overwrite instead of reject_update"` — `final_agent/main.py:1039`
- `resolution_confidence: float` in `GraphState` tracks signal strength — `final_agent/main.py:140`
- Deduplication adjudication (create path): prefers `overwrite_existing` only when new evidence is clearly stronger; falls back to `needs_clarification` when mixed — `final_agent/main.py:1228–1231`

---

### Rule 10 — Prototype owns the workboard; no integration with external task managers

**Intent**: The system manages its own prototype Kanban board. It must not write to or sync with Jira, Azure DevOps, Microsoft Planner, or any external task tracker.

**Status**: ✅ Compliant

- All work items written exclusively to `AgenticColleague_KanbanTasks_Draft` and `AgenticColleague_Tasks` DynamoDB tables
- Kanban board served from `final_agent/static/index.html`; state fetched from `GET /tasks` (`final_agent/main.py:2985`)
- No external task-tracker API calls anywhere in the codebase

---

## Summary Table

| # | Name | Status | Primary Code Pointer |
|---|------|--------|----------------------|
| A-1 | Meeting transcript ingestion | ✅ | `main.py:2747`, `:2760` |
| A-2 | Teams channel message ingestion | ✅ | `main.py:2747`, `:2761` |
| A-3 | Teams chat message ingestion | ✅ | `main.py:2747`, `:2761` |
| A-4 | Email / Outlook ingestion | ✅ | `main.py:2747`, `:2762` |
| A-5 | New file ingestion | ✅ | `main.py:2747` |
| A-6 | Force re-index of updated file | ✅ | `main.py:2751`, `:2756` |
| A-7 | Seed / reference content ingestion | ✅ | `main.py:2747` |
| A-8 | Refresh / rescan | ✅ | `script.js:317`, `main.py:2751` |
| A-9 | Chat message → agent pipeline | ✅ | `main.py:2679`, `:2073` |
| B-1 | Decision detected | ✅ | `main.py:391`, `:418`, `:646` |
| B-2 | Action item detected | ✅ | `main.py:390`, `:417`, `:2322` |
| B-3 | Owner assignment detected | ✅ | `main.py:2374` |
| B-4 | Status change detected | ✅ | `main.py:2374` |
| B-5 | Blocker detected | ✅ | `main.py:126`, `:606` |
| B-6 | Dependency detected | ✅ | `main.py:127` |
| B-7 | Open issue detected | ✅ | `main.py:606` |
| B-8 | Resolution / closure detected | ✅ | `main.py:2374` |
| B-9 | Source conflicts existing memory | ✅ | `main.py:141`, `:142`, `:1167` |
| B-10 | User provides new info via chat | ✅ | `main.py:2679`, `:2322` |
| B-11 | User corrects record via chat | ✅ | `main.py:2533`, `script.js:722` |
| C-1 | New action item → Kanban card | ✅ | `main.py:2322` |
| C-2 | Source changes item stage | ✅ | `main.py:2374` |
| C-3 | Owner assigned / reassigned | ✅ | `main.py:2374` |
| C-4 | Item blocked / unblocked | ⚠️ | `main.py:126` (field only; no Blocked column) |
| C-5 | Dependency recorded | ✅ | `main.py:127` |
| C-6 | Item completed / closed | ✅ | `main.py:2374` |
| C-7 | User chat → Kanban change | ✅ | `main.py:2679`, `:2073`, `:2322`, `:2374` |
| C-8 | Implicit chat context → stage change | ✅ | `main.py:2073` |
| Rule 1 | Clear-signal-only action | ✅ | `main.py:1046`, `:1162` |
| Rule 3 | No autonomous conflict resolution | ✅ | `main.py:141`, `:1167` |
| Rule 4 | No outbound reminders | ✅ | (by omission) |
| Rule 5 | Project-scoped context only | ✅ | `main.py:2747`, `:365` |
| Rule 6 | Chat-first interaction | ✅ | `main.py:2679`, `script.js:707` |
| Rule 7 | Surface ambiguity (one question) | ✅ | `main.py:2533`, `script.js:654` |
| Rule 8 | Preserve all structured fields | ✅ | `main.py:100–160`, `:387–415` |
| Rule 9 | Don't overwrite strong with weak | ✅ | `main.py:140`, `:1039` |
| Rule 10 | Prototype-owned workboard only | ✅ | `main.py:2985` |
