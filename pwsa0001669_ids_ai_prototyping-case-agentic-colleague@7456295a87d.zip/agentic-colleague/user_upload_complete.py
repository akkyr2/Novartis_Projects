from docx import Document
from io import BytesIO
import boto3
import os
import base64
import json

s3 = boto3.client('s3')
bucket_name = "ids-aini-prototype-ai-analytics"
bedrock = boto3.client("bedrock-runtime")
model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"

def process_user_upload_to_vector(
    bedrock,
    model_id,
    file_path=None,
    bucket_name=None,
    s3_key=None
):
    def encode_image_to_base64(image_path: str) -> str:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    def call_claude(image_base64: str, media_type: str) -> str:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_base64,
                            },
                        },
                        {
                            "type": "text",
                            "text": "Extract all text from this image. Preserve formatting."
                        }
                    ],
                }
            ],
        }

        response = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps(body)
        )

        response_body = response["body"].read().decode("utf-8")
        parsed = json.loads(response_body)

        return "".join(
            block.get("text", "")
            for block in parsed.get("content", [])
            if block.get("type") == "text"
        ).strip()

    def extract_from_image(file_path: str) -> str:
        image_base64 = encode_image_to_base64(file_path)

        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(os.path.splitext(file_path)[1].lower(), "image/png")

        return call_claude(image_base64, media_type)

    def extract_from_image_bytes(file_bytes: bytes, ext: str) -> str:
        image_base64 = base64.b64encode(file_bytes).decode("utf-8")

        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(ext, "image/png")

        return call_claude(image_base64, media_type)

    def read_file_from_s3(bucket: str, key: str) -> bytes:
        s3 = boto3.client("s3")
        response = s3.get_object(Bucket=bucket, Key=key)
        return response["Body"].read()

    def extract_text_from_docx_bytes(file_bytes: bytes) -> str:
        doc = Document(BytesIO(file_bytes))
        return "\n".join([p.text for p in doc.paragraphs])

    def extract_text_from_docx_file(local_file_path: str) -> str:
        doc = Document(local_file_path)
        return "\n".join([p.text for p in doc.paragraphs])

    def process_file(local_file_path: str) -> str:
        extension = os.path.splitext(local_file_path)[1].lower()

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return extract_from_image(local_file_path)
        elif extension == ".docx":
            return extract_text_from_docx_file(local_file_path)
        else:
            raise ValueError(f"Unsupported file type: {extension}")

    def process_s3_file(bucket: str, key: str) -> str:
        extension = os.path.splitext(key)[1].lower()
        file_bytes = read_file_from_s3(bucket, key)

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return extract_from_image_bytes(file_bytes, extension)
        elif extension == ".docx":
            return extract_text_from_docx_bytes(file_bytes)
        else:
            raise ValueError(f"Unsupported file type: {extension}")

    if file_path:
        return process_file(file_path)

    if bucket_name and s3_key:
        return process_s3_file(bucket_name, s3_key)

    raise ValueError("Provide either file_path or both bucket_name and s3_key")


# usage
text = process_user_upload_to_vector(
    bedrock=bedrock,
    model_id=model_id,
    file_path="user_uploads_from_UI/Prototype Review & Scenario Planning.docx",
)

if isinstance(text, str) and text is not None:
    print("Successfully read from the file")

