from logger import setup_logger
from utils.bedrock_client import BedrockClient
from libs.user_upload_agent import UserUploadAgent
from libs.cleaning_agent import CleaningAgent
from libs.transform_agent import cleaned_json_to_work_evidence_record, confirmed_updated_item_to_work_evidence_record, confirmed_created_item_to_work_evidence_record
from libs.opensearch_client import index_document
from utils.storage_utils import upload_json_to_s3, build_output_key
import boto3
from utils.llm_utils import *
from config import settings
from agents.agent import build_graph
from libs.dynamodb_client import DynamoDB
from utils.llm_utils import *

logger = setup_logger(__name__)
logger.info("App started")

dynamodb = DynamoDB()

def main():
    bucket_name = settings.bucket_name
    prefix_folder = settings.prefix_folder
    upload_agent = UserUploadAgent()
    cleaning_agent = CleaningAgent()
    bedrock = BedrockClient()
    # user_uploaded_file = "user_uploads_from_UI/Prototype Review & Scenario Planning.docx"


    # Step 1: extract text
    extracted_text = upload_agent.process_file(user_uploaded_file)
    logger.info(f"Extracted text from {user_uploaded_file}.")

    # Step 2: clean + structure
    result = cleaning_agent.clean(
            content=extracted_text,
            source_type="user_upload"
        )
    
    # Step 3: Uploading the cleaned file into S3
    # upload_result = upload_json_to_s3(
    #     bucket=bucket_name,
    #     key=build_output_key(path=user_uploaded_file, prefix_folder=prefix_folder),
    #     data=result,
    #     skip_if_exists=True
    #     )
    # logger.info(f"File={user_uploaded_file} | cleaned ✅ | upload_status={upload_result['status']} | s3={upload_result['s3_path']}")

    logger.info("Creating a work evidence record")

    # Step 4: Uploading this cleaned_json into Opensearch serverless Vectordb
    doc = cleaned_json_to_work_evidence_record(
        cleaned_json=result,
        workspace_id="default-workspace",
        project_id="",
        source_uri="user_upload",
        linked_work_item_ids=[],
        embedding_fn=bedrock.vectorize_with_titan)
    
    response = index_document(doc=doc)
    logger.info(f"Result of Opensearch refresh with the user uploaded document: {response['status_code']}\nResponse text: {response['text']}")

    logger.info("Creating a work item record")

    # just for now checking the result of intent_result from the below function: 
    user_text = "What is the deadline for the beta release?"

    def build_intent_result_dict(doc, user_text):

        parser_prompt = f"""
            Parse the following user input into structured JSON.

            Return ONLY JSON. No explanation. No markdown.

            User input:
            {user_text}

            Return JSON with exactly these fields:
            {{
            "intent": "retrieve|update|delete|create|unknown",
            "project_id": null,
            "project_name": null,
            "work_item_id": null,
            "title": null,
            "description": null,
            "reporter": null,
            "assignee": null,
            "status": null,
            "priority": null,
            "due_date": null,
            "blocker": null,
            "dependency": null,
            "issue": null,
            "summary": null,
            "retrieval_query": null,
            "clarification_needed": false,
            "clarification_question": null
            }}
            """
        cleaned_response = clean_llm_output(bedrock.generate_json(parser_prompt).content)
        return json.loads(cleaned_response)

    intent_result = build_intent_result_dict(doc=result, user_text=user_text)
    proposed_item = dynamodb.build_proposed_work_item(state)
    dynamo_response = dynamodb.apply_confirmed_update_dynamodb(proposed_item)
    logger.info(f"Result of Updating the Dynamo Db with the user uploaded document: {dynamo_response}\n")
        

    initial_state = {
        "chat_history": [
            "What is the deadline for the beta release?"
        ],
        "final_response": None,
        "clarification_received": False,
        "clarification_needed": False,
        "result_payload": result_payload["final_response"],
    }

    with open('data.json', 'w') as f:
        json.dump(result, f, indent=4)


if __name__ == "__main__":
    main()