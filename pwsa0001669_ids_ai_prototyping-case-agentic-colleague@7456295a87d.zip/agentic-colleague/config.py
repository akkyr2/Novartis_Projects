from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    log_level: str = "INFO"
    aws_region: str
    bucket_name: str
    prefix_folder: str
    s3_loader: str
    bedrock_loader: str

    # bedrock
    model_id: str
    embedding_model_id: str
    EMBEDDING_DIMENTION: int

    # opensearch serverless
    service: str
    host: str
    headers: dict
    index_name: str

    # dynamodb 
    work_items: str

    class Config:
        env_file = ".env"
        extra = "ignore"


# Create ONE global settings object
settings = Settings()