import boto3
from boto3.dynamodb.conditions import Key
dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
work_items = "AgenticColleague_WorkItems"

import boto3
from boto3.dynamodb.conditions import Attr

def delete_items_by_source_type(
    table_name: str,
    source_type_value: str,
    source_type_field: str = "source_type",
    pk_field: str = "PK",
    sk_field: str = "SK",
    dry_run: bool = True,
):
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(table_name)

    scan_kwargs = {
        "FilterExpression": Attr(source_type_field).eq(source_type_value)
    }

    items_to_delete = []
    response = table.scan(**scan_kwargs)

    while True:
        for item in response.get("Items", []):
            items_to_delete.append({
                pk_field: item[pk_field],
                sk_field: item[sk_field],
                source_type_field: item.get(source_type_field)
            })

        if "LastEvaluatedKey" not in response:
            break

        response = table.scan(
            **scan_kwargs,
            ExclusiveStartKey=response["LastEvaluatedKey"]
        )

    print(f"Found {len(items_to_delete)} items where {source_type_field} == {source_type_value}")

    for x in items_to_delete[:20]:
        print(x)

    if dry_run:
        print("Dry run only. No items deleted.")
        return items_to_delete

    with table.batch_writer() as batch:
        for item in items_to_delete:
            batch.delete_item(
                Key={
                    pk_field: item[pk_field],
                    sk_field: item[sk_field]
                }
            )

    print(f"Deleted {len(items_to_delete)} items.")
    return items_to_delete


# Example:
delete_items_by_source_type(
    table_name="AgenticColleague_WorkItems",
    source_type_value="chat",
    source_type_field="source_type",
    pk_field="PK",
    sk_field="SK",
    dry_run=True
)

# After review, run again with dry_run=False

delete_items_by_source_type(
    table_name="AgenticColleague_WorkItems",
    source_type_value="chat",
    source_type_field="source_type",
    pk_field="PK",
    sk_field="SK",
    dry_run=False
)