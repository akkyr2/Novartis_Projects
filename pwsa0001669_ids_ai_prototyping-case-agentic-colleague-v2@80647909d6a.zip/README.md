# Agentic Colleague

> **Version:** 2.0 (Refactored)  
> **Stack:** Python · FastAPI · LangGraph · AWS Bedrock · AWS OpenSearch Serverless · AWS DynamoDB  
> **Last Updated:** August 2026

An AI-powered team assistant that ingests internal collaboration content (meeting transcripts, emails, Teams chats), extracts structured project signals, and supports natural-language retrieval, task creation, and task updates via a chat interface and Kanban board.

---

## Table of Contents

1. [Overview](#overview)
2. [Key Capabilities](#key-capabilities)
3. [What's New in v2.0](#whats-new-in-v20)
4. [Project Structure](#project-structure)
4. [Architecture](#architecture)
5. [Prerequisites](#prerequisites)
6. [Installation & Setup](#installation--setup)
7. [Running the Application](#running-the-application)
8. [API Endpoints](#api-endpoints)
9. [LangGraph Agent Workflow](#langgraph-agent-workflow)
10. [Batch Data Ingestion Pipeline](#batch-data-ingestion-pipeline)
11. [Pipeline Scheduler (Automated Runs)](#pipeline-scheduler-automated-runs)
12. [AWS Services](#aws-services)
13. [Frontend](#frontend)
14. [Project Onboarding Dashboard](#project-onboarding-dashboard)
15. [Evaluation Pipeline](#evaluation-pipeline)
16. [Configuration](#configuration)
17. [Troubleshooting](#troubleshooting)
18. [Future Improvements](#future-improvements)

---

## Overview

**Agentic Colleague** is a conversational AI assistant for project teams. It:

- Ingests documents from S3 (meeting transcripts, emails, Teams chats)
- Extracts structured data (action items, decisions, blockers, entities)
- Stores embeddings in OpenSearch for semantic search
- Maintains work items in DynamoDB for structured queries
- Provides a real-time Kanban board with drag-and-drop
- Supports natural language chat for retrieval, creation, and updates

### Deployed Application URL
```
https://idsprotowork.dev.aws.novartis.net/agentic_colleague_v2/
```

---

## Key Capabilities

| Capability | Description |
|------------|-------------|
| **Retrieve** | Natural language Q&A over projects, tasks, decisions, blockers |
| **Create** | Add new work items via chat |
| **Update** | Modify work items (status, assignee, due date) via chat or drag-and-drop |
| **Ingest** | Upload DOCX/images; auto-extract structured project signals |
| **Kanban Board** | Real-time board with filters, drag-and-drop, card delete, card expand |

---

## What's New in v2.0

### Major Code Refactoring
- **Reduced codebase** from ~6924 lines to ~3060 lines in `main.py`
- **Backup created:** `main_v1.py` preserves the original implementation
- **27 organized sections** with clear documentation headers

### Generic Project Detection
- Removed all hardcoded IPST-specific patterns
- `_generate_project_variants()` now works for ANY project naming convention
- Fuzzy matching against DynamoDB projects table

### Enhanced Intent Parsing
- LLM extracts `assignee` field for retrieve queries
- Example: "tasks assigned to Pawan" → filters results by assignee
- ReAct-style prompt with clear extraction examples

### Status Column Mapping
| Status Column | Statuses Included |
|---------------|-------------------|
| **To Do** | Not Started, Open, Pending, Backlog, New, Planned |
| **In Progress** | In Progress, Active, Working, Started, Ongoing |
| **Done** | Done, Completed, Closed, Resolved, Finished |

### OpenSearch Changes
- **KNN disabled** - index field not configured as `knn_vector` type
- Using **text-only search** with project boosting instead

### Chat Response Improvements
- **HTML table display** for action items (standardized tabular format)
- **Clickable task links** navigate to Kanban board with highlighting
- URL format: `../?highlight=TITLE&assignee=NAME&status=STATUS`

---

## Project Structure

```
agentic-colleague-v2/
│
├── main.py                              # FastAPI app with LangGraph agent (~3060 lines, refactored)
├── main_v1.py                           # Backup of original main.py (~6924 lines)
├── eval.py                              # Evaluation module (LLM-as-judge)
├── config.py                            # Pydantic settings (loaded from .env)
├── .env                                 # Environment variables
├── requirements.txt                     # Python dependencies
├── Dockerfile                           # Docker container for deployment
├── .gitignore                           # Git ignore rules
├── agentic_colleague_test_cases(in).csv # Evaluation test cases
│
├── batch_data_ingestion/                # S3 ingestion & verification scripts
│   ├── __init__.py
│   ├── batch_s3_ingestion.py            # Main batch ingestion pipeline
│   ├── verify_opensearch.py             # OpenSearch verification
│   ├── verify_workitems.py              # WorkItems DynamoDB verification
│   ├── cleanup_duplicates.py            # Duplicate record cleanup
│   ├── check_projects.py                # Project name utility
│   ├── lambda_handler.py                # AWS Lambda entry point
│   └── README.md                        # Pipeline documentation
│
├── libs/                                # Shared library modules
│   ├── __init__.py
│   ├── cleaning_agent.py                # LLM document cleaner
│   ├── dynamodb_client.py               # DynamoDB helper + work item search
│   ├── opensearch_client.py             # OpenSearch KNN search + indexing
│   ├── transform_agent.py               # cleaned_json → work_evidence record
│   ├── user_upload_agent.py             # File extraction (DOCX/image/S3)
│
├── project_seeding/                 # Project management service
│   ├── __init__.py
│   ├── projects_service.py          # CRUD operations for Projects DynamoDB
│   └── test_projects_table.py       # Unit tests
│
├── transcript_pipeline/             # Teams transcript extraction
│   ├── __init__.py
│   ├── main_v2.py                   # Transcript fetch pipeline (Graph API)
│   ├── main_chat.py                 # Meeting chat extraction pipeline
│   ├── config.py                    # Pipeline configuration
│   └── verify/                      # Verification scripts
│
├── pipeline_scheduler/              # Automated pipeline scheduling
│   ├── __init__.py
│   ├── pipelines.py                 # Pipeline types and configurations
│   ├── run.py                       # Combined runner (scheduler + worker)
│   ├── scheduler.py                 # APScheduler-based cron trigger
│   ├── unified_pipeline.py          # Pipeline orchestration by type
│   ├── worker.py                    # Queue processor with file locking
│   └── README.md                    # Detailed scheduler documentation
│
├── utils/                               # Utility modules
│   ├── __init__.py
│   ├── agent_prompts.py                 # LLM prompt templates
│   ├── bedrock_client.py                # BedrockClient class (LLM + embeddings)
│   ├── data_ingestion_prompts.py        # Cleaning prompts + schema
│   ├── image_utils.py                   # Base64 image encoding
│   ├── llm_utils.py                     # JSON parsing, normalisation
│   └── storage_utils.py                 # S3 upload/download helpers
│
├── static/                              # Frontend files
│   ├── index.html                       # Team Board (Kanban)
│   ├── chat.html                        # Ask Colleague (Chat interface)
│   ├── upload.html                      # Team Hub (Document upload)
│   ├── style.css                        # 4-theme styles
│   ├── script.js                        # Shared frontend logic (~1540 lines)
│   ├── Expanded-Logo-Dark-1.png         # App logo
│   └── novartis-logo2.png               # Novartis branding
│
└── user_uploads_from_UI/                # Runtime storage for uploaded files
```

---

## Architecture

```
User Browser
    │
    ├── GET    /           → Serves Kanban board (static/index.html)
    ├── GET    /tasks      → DynamoDB scan → Kanban cards JSON
    ├── DELETE /tasks      → DynamoDB delete_item
    ├── POST   /agent      → LangGraph StateGraph → Claude → HTML response
    └── POST   /upload     → Extract → Clean → Embed → OpenSearch + DynamoDB
                                       │
                            ┌──────────▼──────────┐
                            │   LangGraph Nodes   │
                            │  decision_node      │
                            │  inference_node     │
                            │  create_node        │
                            │  update_node        │
                            │  clarify_node       │
                            └──────────┬──────────┘
                                       │
                  ┌────────────────────┼─────────────────────┐
                  ▼                    ▼                     ▼
           AWS Bedrock          AWS OpenSearch         AWS DynamoDB
           (Claude Sonnet       (work_evidence         (WorkItems -
            + Titan Embed)       KNN index)             single table)
```

### High-Level Execution Flow

```
User Input
    ↓
decision_node (intent parsing via Claude)
    ↓
[retrieve | create | update | clarify]
    ↓
(optional) inference_node
    ↓
Final Response → HTML
```

---

## Prerequisites

### Software Requirements

| Requirement | Version |
|-------------|---------|
| Python | 3.12+ |
| Docker | Latest (for container deployment) |
| AWS CLI | Configured with valid credentials |

### AWS Services Required

| Service | Resource | Purpose |
|---------|----------|----------|
| **S3** | `ids-aini-prototype-ai-analytics` | Source files & storage |
| **Bedrock** | Claude Sonnet 4.5, Titan Embed v2 | LLM + Embeddings |
| **OpenSearch Serverless** | `work_evidence_test` index | Vector storage |
| **DynamoDB** | `AgenticColleague_WorkItems_Test` | Work items & Kanban UI source |

---

## Installation & Setup

### Step 1: Clone/Navigate to the Project

```powershell
cd "c:\Users\MANEPA1\OneDrive - Novartis Pharma AG\Documents\agentic-colleague\agentic-colleague-v2"
```

### Step 2: Create Virtual Environment

```powershell
# Create virtual environment
python -m venv venv

# Activate virtual environment (Windows PowerShell)
.\venv\Scripts\Activate.ps1

# For Command Prompt use:
# .\venv\Scripts\activate.bat

# For Linux/Mac use:
# source venv/bin/activate
```

### Step 3: Install Dependencies

```powershell
pip install -r requirements.txt
```

### Step 4: Verify AWS Credentials

```powershell
# Check AWS identity
aws sts get-caller-identity

# Test S3 access
aws s3 ls s3://ids-aini-prototype-ai-analytics/Agentic-Colleague-synthetic/
```

### Step 5: Verify Environment Variables

Ensure `.env` file exists with all required variables:

```env
# Application logs
LOG_LEVEL=INFO

# AWS Configuration
aws_region = "us-east-1"
s3_loader = "s3"
bedrock_loader = "bedrock-runtime"
bucket_name = "ids-aini-prototype-ai-analytics"
prefix_folder = "Agentic-Colleague-synthetic/"

# OpenSearch Serverless
service = "aoss"
host = "https://oqjh772goqkmg0mlp7gg.us-east-1.aoss.amazonaws.com"
headers = {"Content-Type": "application/json"}
index_name = "work_evidence_test"

# Bedrock Models
embedding_model_id = "amazon.titan-embed-text-v2:0"
model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
EMBEDDING_DIMENTION = 1024

# DynamoDB
work_items = "AgenticColleague_WorkItems_Test"
```

---

## Running the Application

### Option 1: Python Virtual Environment (Local Development)

```powershell
# Navigate to project folder
cd "c:\Users\MANEPA1\OneDrive - Novartis Pharma AG\Documents\agentic-colleague\agentic-colleague-v2"

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Run the application
uvicorn main:app --host 0.0.0.0 --port 7007 --reload
```

### Option 2: Docker Deployment (Local Testing)

```powershell
# Navigate to project folder
cd "c:\Users\MANEPA1\OneDrive - Novartis Pharma AG\Documents\agentic-colleague\agentic-colleague-v2"

# Build the Docker image
docker build -t agentic-colleague .

# Run the Docker container
docker run -d -p 7007:7007 --name agentic-colleague-app agentic-colleague

# Check if container is running
docker ps

# View logs
docker logs -f agentic-colleague-app

# Stop and remove container
docker stop agentic-colleague-app
docker rm agentic-colleague-app
```

### Access the Application

| Page | URL |
|------|-----|
| **Team Board (Kanban)** | http://localhost:7007/ |
| **Ask Colleague (Chat)** | http://localhost:7007/static/chat.html |
| **Team Hub (Upload)** | http://localhost:7007/static/upload.html |

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/` | Serves `static/index.html` (Kanban board) |
| `GET` | `/tasks` | Returns all Kanban cards from DynamoDB |
| `DELETE` | `/tasks?pk=...&sk=...` | Deletes a Kanban card by PK and SK |
| `POST` | `/agent` | LangGraph chat endpoint |
| `POST` | `/upload` | Document ingestion endpoint |

### POST /agent

**Request:**
```json
{
  "chat_history": ["What tasks are blocked?"],
  "clarification_received": false,
  "result_payload": {}
}
```

**Response (normal):**
```json
{
  "response": "<html>...",
  "result_payload": {},
  "clarification_needed": false
}
```

**Response (clarification needed):**
```json
{
  "response": "<p>I found task \"X\"... Shall I apply? (yes/no)</p>",
  "result_payload": {...},
  "clarification_needed": true
}
```

### POST /upload

**Form Data:**
- `files`: List of uploaded files (UploadFile)
- `categories`: List of category labels
- `force_reindex`: "true" or "false" (skip deduplication)

**Category Mapping:**
| UI Label | `source_type` |
|----------|---------------|
| Meeting Transcript | `meeting_transcript` |
| Team Chat | `teams_chat` |
| Outlook | `email` |

---

## LangGraph Agent Workflow

### Graph State

```python
class GraphState(TypedDict, total=False):
    user_input: str
    chat_history: List[str]
    intent: str                    # retrieve | create | update | unknown
    project_name: str
    assignee: str
    title: str
    status: str
    due_date: str
    retrieval_query: str
    retrieval_results: Any
    clarification_needed: bool
    clarification_question: str
    clarification_received: bool
    final_response: str
    # ... and more fields
```

### Graph Nodes

| Node | Function | Routes To |
|------|----------|-----------|
| `decision_node` | Parses intent, enriches query, fetches context | inference / create / update |
| `inference_node` | Synthesizes answer from retrieved context | END |
| `create_node` | Handles new work item creation | clarify → END |
| `update_node` | Handles work item updates | clarify → END |
| `clarify_node` | Generates confirmation question | END |

### Routing Logic

```
START → decision_node
    intent=retrieve/unknown → inference_node → END
    intent=create → create_node → clarify_node → END (pass 2 back to create_node)
    intent=update → update_node → clarify_node → END (pass 2 back to update_node)
```

---

## Batch Data Ingestion Pipeline

The batch data ingestion system processes documents from S3 and indexes them to OpenSearch and DynamoDB.

> **Detailed documentation:** See `batch_data_ingestion/README.md` for complete CLI commands and API details.

### Pipelines Overview

| Pipeline | Source | S3 Path | Source Type |
|----------|--------|---------|-------------|
| **Transcript** | Meeting transcripts | `meetings/transcripts/` | `meeting_transcript` |
| **Chat** | Meeting chats | `meetings/chats/` | `meeting_chat` |

### Triggering Pipelines

#### Option 1: UI Dashboard (Recommended)

Access the **Project Onboarding Dashboard** at:
```
http://localhost:7007/static/onboarding.html
```

The UI provides:
- **Data Pipeline panel** - Run transcript fetch + ingestion
- **Chat Pipeline panel** - Run chat fetch + ingestion
- Visual step indicators and progress tracking
- Configurable options (Incremental/Full, Dry Run, Skip Indexed)

#### Option 2: FastAPI Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/batch/transcript/run` | Run transcript batch ingestion |
| `POST` | `/batch/chat/run` | Run chat batch ingestion |

```bash
# Run transcript batch ingestion
curl -X POST http://localhost:7007/batch/transcript/run \
  -H "Content-Type: application/json" \
  -d '{"dry_run": false, "skip_existing": true}'
```

#### Option 3: CLI Commands

```powershell
# Activate virtual environment
cd "c:\Users\MANEPA1\OneDrive - Novartis Pharma AG\Documents\agentic-colleague\agentic-colleague-v2"
.\venv\Scripts\Activate.ps1

# Transcript pipeline
python -m batch_data_ingestion.transcript.ingestion
python -m batch_data_ingestion.transcript.ingestion --dry-run --limit 5

# Chat pipeline
python -m batch_data_ingestion.chat.ingestion
python -m batch_data_ingestion.chat.ingestion --dry-run --limit 5

# Verification
python -m batch_data_ingestion.transcript.verify
python -m batch_data_ingestion.chat.verify
```

### Scripts Overview

| Script | Purpose |
|--------|----------|
| `batch_s3_ingestion.py` | Main batch ingestion from S3 |
| `verify_opensearch.py` | Query & verify OpenSearch records |
| `verify_workitems.py` | Query & verify WorkItems table |
| `cleanup_duplicates.py` | Find and remove duplicates |
| `lambda_handler.py` | AWS Lambda entry point |

### Running Batch Ingestion

```powershell
# Activate virtual environment
cd "c:\Users\MANEPA1\OneDrive - Novartis Pharma AG\Documents\agentic-colleague\agentic-colleague-v2"
.\venv\Scripts\Activate.ps1

# Process all files in a folder
python -m batch_data_ingestion.batch_s3_ingestion --folder transcripts/

# Process with limit
python -m batch_data_ingestion.batch_s3_ingestion --folder Outlook_emails/ --limit 5

# Dry run (no database writes)
python -m batch_data_ingestion.batch_s3_ingestion --folder transcripts/ --dry-run

# Verbose mode
python -m batch_data_ingestion.batch_s3_ingestion --folder transcripts/ --verbose --limit 1

# Force re-index (skip deduplication)
python -m batch_data_ingestion.batch_s3_ingestion --folder Team_Channels/ --no-skip-existing
```

### S3 Folder to Source Type Mapping

| S3 Folder | `source_type` |
|-----------|---------------|
| `transcripts/` | `meeting_transcript` |
| `Transcribe_Data/` | `meeting_transcript` |
| `Outlook_emails/` | `email` |
| `Teams_Chat/` | `teams_chat` |
| `Team_Channels/` | `teams_channel_post` |

### Running Verification Scripts

```powershell
# OpenSearch verification
python -m batch_data_ingestion.verify_opensearch
python -m batch_data_ingestion.verify_opensearch --source-type meeting_transcript
python -m batch_data_ingestion.verify_opensearch --project "Noventra IPST"
python -m batch_data_ingestion.verify_opensearch --search "launch readiness"
python -m batch_data_ingestion.verify_opensearch --stats
python -m batch_data_ingestion.verify_opensearch --all --export opensearch_backup.json

# WorkItems verification
python -m batch_data_ingestion.verify_workitems
python -m batch_data_ingestion.verify_workitems --project "Graph API"
python -m batch_data_ingestion.verify_workitems --assignee "Tom Barry"
python -m batch_data_ingestion.verify_workitems --status "in progress"
python -m batch_data_ingestion.verify_workitems --list-projects

# Cleanup duplicates
python -m batch_data_ingestion.cleanup_duplicates
python -m batch_data_ingestion.cleanup_duplicates --dry-run
```

---

## Pipeline Scheduler (Automated Runs)

The **Pipeline Scheduler** provides automated job scheduling for running data pipelines at regular intervals.

> **Detailed documentation:** See `pipeline_scheduler/README.md` for complete CLI commands and configuration.

### Features

| Feature | Description |
|---------|-------------|
| **Multi-Pipeline Support** | Run `transcript`, `chat`, or `all` pipelines |
| **Scheduled Execution** | Automatically runs pipelines every minute (configurable) |
| **Queue Mechanism** | Jobs queue up if previous job is still running |
| **File-Based Locking** | Prevents concurrent executions that could corrupt data |
| **Graceful Shutdown** | Finishes current job before stopping |

### Quick Start

```powershell
# Navigate to project root
cd "c:\Users\MANEPA1\OneDrive - Novartis Pharma AG\Documents\agentic-colleague\agentic-colleague-v2"
.\venv\Scripts\Activate.ps1

# Run scheduler + worker (default: transcript pipeline, every 1 minute)
python -m pipeline_scheduler.run

# Run with custom interval (every 5 minutes)
python -m pipeline_scheduler.run --interval 5

# Run all pipelines (transcript + chat)
python -m pipeline_scheduler.run --pipeline all

# Run chat pipeline only
python -m pipeline_scheduler.run --pipeline chat

# Check status
python -m pipeline_scheduler.run --status

# Submit a manual job
python -m pipeline_scheduler.run --submit --pipeline transcript
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PIPELINE_ENABLED` | `true` | Enable/disable scheduled runs |
| `PIPELINE_TYPE` | `transcript` | Pipeline type: `transcript`, `chat`, `all` |
| `PIPELINE_INTERVAL_MINUTES` | `1` | Minutes between triggers |
| `PIPELINE_TRANSCRIPT_MODE` | `incremental` | `incremental` or `full` |
| `PIPELINE_MAX_QUEUE_SIZE` | `5` | Max jobs in queue |

### Running with Docker

```powershell
# Build and start (API + Scheduler)
docker-compose up --build

# View scheduler logs
docker-compose logs -f scheduler

# Check status inside container
docker exec scheduler python -m pipeline_scheduler.run --status
```

---

## AWS Services

### AWS Bedrock

| Model | Model ID | Purpose |
|-------|----------|---------|
| Claude Sonnet 4.5 | `us.anthropic.claude-sonnet-4-5-20250929-v1:0` | All LLM tasks |
| Titan Embed v2 | `amazon.titan-embed-text-v2:0` | Embeddings (1024-dim) |

### AWS OpenSearch Serverless

- **Collection:** `agentic-colleague-synth-draft`
- **Index:** `work_evidence` (production) / `work_evidence_test` (testing)
- **Auth:** SigV4 via `requests-aws4auth`
- **Search Mode:** Text-only (KNN disabled - index field not configured as knn_vector)
- **Key Fields:** `clean_text`, `summary`, `action_items_detected`, `source_type`, `source_uri`, `project_name`

> **Note:** KNN vector search is disabled because the OpenSearch index field is not configured as `knn_vector` type.

### AWS DynamoDB

| Table | PK | SK | Purpose |
|-------|----|----|----------|
| `AgenticColleague_WorkItems_Test` | `PROJECT#{project_name}` | `TASK#{work_item_id}` | Single source of truth for work items & Kanban UI |

---

## Frontend

### Pages

| File | URL | Description |
|------|-----|-------------|
| `index.html` | `/` | Team Board (Kanban) |
| `chat.html` | `/static/chat.html` | Ask Colleague (Chat) |
| `upload.html` | `/static/upload.html` | Team Hub (Document Upload) |

### Features

- **Kanban Board:** 3 columns (To Do, In Progress, Done), drag-and-drop, auto-refresh every 5s
- **Search & Filter:** Search bar, assignee filter, project filter
- **Card Actions:** Click to expand, hover to delete, drag to change status
- **4 Themes:** Dark, Ocean, Forest, Warm (persisted in localStorage)
- **Chat Interface:**
  - Multi-turn conversation with markdown rendering
  - **HTML table display** for action items (standardized tabular format)
  - **Clickable task links** navigate to Kanban board with highlighting
  - Typing indicator during LLM processing
- **Upload:** File preview, category selection, progress bar

### Task Highlighting

When clicking a task link in chat, the URL includes query parameters:
```
../?highlight=TASK_TITLE&assignee=NAME&status=STATUS
```

The Kanban board (`index.html`) reads these parameters via `checkHighlight()` and:
1. Scrolls to the matching task card
2. Highlights it with a pulsing animation
3. Clears the highlight after 3 seconds

---

## Project Onboarding Dashboard

The **Project Onboarding** page (`/static/onboarding.html`) provides a unified UI for project management and data pipeline execution.

### Accessing the Dashboard

| Page | URL |
|------|-----|
| **Project Onboarding** | http://localhost:7007/static/onboarding.html |

### Features

#### 1. Project Management (Left Panel)

| Feature | Description |
|---------|-------------|
| **Create Project** | Add new projects with name and description |
| **Edit Project** | Update project name/description via modal |
| **Delete Project** | Remove projects with confirmation dialog |
| **Toggle Status** | Activate/deactivate projects (Active/Inactive toggle) |
| **Refresh List** | Reload projects from DynamoDB |

**Projects Table Columns:**
- Project Name
- Description
- Status (Active/Inactive toggle)
- Files (count)
- Created (timestamp)
- Actions (Edit/Delete buttons)

#### 2. Data Pipeline (Right Panel - Transcripts)

Runs a **2-step unified pipeline** for meeting transcripts:

| Step | Description | API Endpoint |
|------|-------------|--------------|
| **Step 1: Transcripts** | Fetch Teams transcripts → S3 | `POST /transcript/run` |
| **Step 2: Ingestion** | Index documents → OpenSearch | `POST /batch/transcript/run` |

**Pipeline Options:**
| Option | Description |
|--------|-------------|
| **Mode** | Incremental (new only) or Full (all) |
| **Retry Failed** | Re-process previously failed transcripts |
| **Skip Indexed** | Skip already indexed documents |
| **Dry Run** | Preview mode - no actual writes |

#### 3. Chat Pipeline (Right Panel - Meeting Chats)

Runs a **2-step pipeline** for Teams meeting chats:

| Step | Description | API Endpoint |
|------|-------------|--------------|
| **Step 1: Chats** | Fetch Teams meeting chats → S3 | `POST /chat/run` |
| **Step 2: Ingestion** | Index chat documents → OpenSearch | `POST /batch/chat/run` |

### Projects API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/projects` | List all projects |
| `POST` | `/projects` | Create a new project |
| `GET` | `/projects/{project_id}` | Get project details |
| `PUT` | `/projects/{project_id}` | Update project (name, description, status) |
| `DELETE` | `/projects/{project_id}` | Delete a project |

### Pipeline API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/transcript/config` | Get transcript pipeline config |
| `POST` | `/transcript/run` | Run transcript fetch pipeline |
| `GET` | `/batch/transcript/config` | Get batch ingestion config |
| `POST` | `/batch/transcript/run` | Run transcript batch ingestion |
| `GET` | `/batch/chat/config` | Get chat batch config |
| `POST` | `/batch/chat/run` | Run chat batch ingestion |

### Backend Module: `project_seeding/`

```
project_seeding/
├── __init__.py
├── projects_service.py     # CRUD operations for Projects DynamoDB table
└── test_projects_table.py  # Unit tests
```

**DynamoDB Table:** `AgenticColleague_Projects_Test`
- **PK:** `PROJECT#{project_id}`
- **SK:** `METADATA`
- **GSI:** `GSI1-ProjectName-Index` (for lookups by name)

---

## Evaluation Pipeline

The evaluation module (`eval.py`) uses LLM-as-judge to measure:

| Metric | Description |
|--------|-------------|
| **Relevance** | Does the response address the user query? |
| **Correctness** | Is the response consistent with reference examples? |
| **Completeness** | Does the response cover important parts? |

Evaluation runs non-blocking on every `/agent` request. Results are logged to `eval_logs.txt`.

---

## Configuration

### `config.py`

```python
class Settings(BaseSettings):
    log_level: str = "INFO"
    aws_region: str
    bucket_name: str
    model_id: str
    embedding_model_id: str
    EMBEDDING_DIMENTION: int
    service: str
    host: str
    headers: dict
    index_name: str
    work_items: str

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
```

---

## Troubleshooting

### Common Issues

| Issue | Solution |
|-------|----------|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` |
| AWS credential errors | Run `aws configure` or check IAM permissions |
| OpenSearch 403 | Check IAM/AOSS policy for EC2 role |
| OpenSearch KNN errors | KNN is disabled - use text search only |
| Port 7007 in use | Use `--port 8000` or kill existing process |
| Docker build fails | Check proxy settings in Dockerfile |
| Task links not working | Ensure URL uses `../?` prefix from `/static/chat.html` |
| Assignee filter returns all | Check LLM extracts `assignee` field correctly |
| Status column not displaying | Check `get_status_column()` mapping in main.py |

### Useful Commands

```powershell
# Check Python version
python --version

# Check installed packages
pip list

# Check AWS identity
aws sts get-caller-identity

# Test DynamoDB access
aws dynamodb list-tables --region us-east-1

# Check running Docker containers
docker ps -a

# View Docker logs
docker logs agentic-colleague-app
```

---

## Future Improvements

1. ~~**Enhanced Search:** Improve `knn_search_work_evidence` for better semantic matching~~ → Using text-only search (KNN disabled)
2. **Required Fields:** Enforce required fields for create/update operations
3. **Monitoring:** Add CloudWatch metrics and dashboards
4. **Delete Operation:** Implement delete node for removing work items via chat
5. **Multi-tenant:** Add workspace/project isolation
6. **Real-time Updates:** WebSocket for live Kanban updates
7. **Re-enable KNN:** Configure OpenSearch index with proper `knn_vector` field type

---

## EC2 Deployment Steps

1. SSH into the EC2 instance
2. Navigate to the project folder: `cd /projects/agentic-colleague`
3. Pull latest changes: `git pull`
4. Build Docker image: `docker build -t agentic-colleague .`
5. Stop existing container: `docker stop <container_id>`
6. Run new container: `docker run -d -p 7007:7007 agentic-colleague`
7. Update nginx config: `sudo vim /etc/nginx/conf.d/default.conf`
8. Restart nginx: `sudo systemctl restart nginx`

---

## License

Internal use only - Novartis Pharma AG
