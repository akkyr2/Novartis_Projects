#!/usr/bin/env python
# coding: utf-8

# In[57]:


# start->decision node->if no clarification received extract intent-> retrieve->
# if intent is retrieve -> answer synthesizer -> END -> chatbot UI
# if intent is not retrieve -> check if clarification is needed
# if clarification needed -> clarifying node -> UI -> clarification sent along with chat history -> decision node detects clarification received -> sends it to clarification node or update or create
# if no clarification needed -> update or create node -> END


# In[58]:


import os
# os.environ['HTTP_PROXY']="http://proxy-usvn.aws.novartis.net:3128"
# os.environ['HTTPS_PROXY']="http://proxy-usvn.aws.novartis.net:3128"


# In[59]:


# get_ipython().system('pip install langgraph langchain langchain_aws requests_aws4auth')


# In[60]:


# os.environ["no_proxy"] = "127.*,[::1],*.local,160.61.1.65,160.61.112.195,160.61.112.195,169.254.170.2,162.86.78.177,170.60.112.198,170.236.0.86,170.236.114.155,169.254.169.254,localhost,127.0.0.1,10.180.104.95,10.180.104.57,10.180.105.175,10.100.0.0/16,172.20.0.0/16,sts.novartis.com,.s3.eu-west-1.amazonaws.com,.s3.dualstack.eu-west-1.amazonaws.com,.s3.eu-central-1.amazonaws.com,.s3.dualstack.eu-central-1.amazonaws.com,.novartis.net,.internal,api.ecr.us-east-1.amazonaws.com,dkr.ecr.us-east-1.amazonaws.com,ec2.us-east-1.amazonaws.com,.eu-west-1.eks.amazonaws.com,.us-east-1.eks.amazonaws.com,.s3.eu-west-1.amazonaws.com,api.ecr.eu-west-1.amazonaws.com,dkr.ecr.eu-west-1.amazonaws.com,ec2.eu-west-1.amazonaws.com,*.s3.amazonaws.com,s3.amazonaws.com,com.amazonaws.us-east-1.s3,*.s3.us-east-1.amazonaws.com,s3.us-east-1.amazonaws.com,*.s3.dualstack.us-east-1.amazonaws.com,*.s3-external-1.amazonaws.com,*.s3-accesspoint.us-east-1.amazonaws.com,*.s3-accesspoint.dualstack.us-east-1.amazonaws.com,*.rds.amazonaws.com,*.rds.us-east-1.amazonaws.com,*.sts.us-east-1.amazonaws.com,execute-api.us-east-1.amazonaws.com,*.execute-api.us-east-1.amazonaws.com,sts.us-east-1.amazonaws.com,*.sts.amazonaws.com,sts.amazonaws.com,glue.us-east-1.amazonaws.com,*.glue.us-east-1.amazonaws.com,glue.amazonaws.com,*.glue.amazonaws.com,sts.amazonaws.com,.privatelink.snowflakecomputing.com,*.privatelink.snowflakecomputing.com,*.azure.com,.cloud.databricks.com,*.novartis.com,bedrock-runtime.us-east-1.amazonaws.com,artifactory.f1.novartis.net,bitbucketenterprise.aws.novartis.net"


# In[62]:


from typing import TypedDict, List, Optional, Literal,Any, Dict

from langgraph.graph import StateGraph, END
from langgraph.types import Command
from langchain_aws import ChatBedrock

import json
import copy
import hashlib
import math
import re
from datetime import datetime, timezone
import boto3
from io import BytesIO
import random
import requests
from requests_aws4auth import AWS4Auth
import pandas as pd
from boto3.dynamodb.conditions import Key
import uuid
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from pydantic import BaseModel
import markdown
from decimal import Decimal
from docx import Document
import base64
import logging
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi import UploadFile, File, Form

# evaluation 
from eval import evaluation, load_records

# adding eval logs in a separate file
logging.basicConfig(
    filename="eval_logs.txt",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

logger = logging.getLogger(__name__)
dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
work_items = "AgenticColleague_WorkItems_Test"  # Testing environment - single source of truth for all work items
vectordb_index = "work_evidence_test"  # Testing environment

# ── IPST Function Map ─────────────────────────────────────────────────────────
# Maps IPST team member names to their function/role.
# Update with real IPST member names + functions before the summit demo.
# Example functions: CE, Medical, GM, IMO, Regulatory, Market Access, Finance
IPST_FUNCTION_MAP: dict = {
    # ── Demo / POC team (Apollo project) ──
    "Tom Barry":          "GM",
    "Tom":                "GM",
    "Stan Tsvirko":       "Sponsor",
    "Stan":               "Sponsor",
    "Saburi Mohan":       "IMO",
    "Saburi":             "IMO",
    "Satya Shukla":       "CE",
    "Satya":              "CE",
    "Ash":                "Medical",
    "Revath":             "Regulatory",
    "Mohan Dhanalakota":  "Market Access",
    "Mohan":              "Market Access",
    "Sarah Chen":         "Business Lead",
    "Sarah":              "Business Lead",
    "Nina Patel":         "Bus. Excellence",
    "Nina":               "Bus. Excellence",
    "Dr. Priya Nair":     "Medical",
    "Dr Priya Nair":      "Medical",
    "Priya Nair":         "Medical",
    "Priya":              "Medical",
    "Luis Martinez":      "Market Access",
    "Luis":               "Market Access",
    "Mark Davidson":      "Finance",
    "Mark":               "Finance",
    "Jake Reynolds":      "Marketing",
    "Jake":               "Marketing",
    "Rachel Kim":         "Field Strategy",
    "Rachel":             "Field Strategy",
    # ── Add real IPST team members below before the demo ──
    # "First Last": "Function",
}

# ──────────────────────────────────────────────────────────────────────────────
# DEMO CANNED Q&A  (IPST Summit · June 9, 2026 · as-of April 20, 2026)
# When a user's message matches a key (after normalization), the stored answer
# is returned immediately — no LLM call, no regeneration.
# ──────────────────────────────────────────────────────────────────────────────
import re as _re

def _normalize_q(text: str) -> str:
    """Lowercase, strip whitespace and trailing punctuation for matching."""
    return _re.sub(r'[?.!,;:]+$', '', text.strip().lower())

CANNED_QA: dict = {
    _normalize_q("Compare the latest IPST Core and Extended meetings, chats, emails, and tracker updates. Tell me what changed, what conflicts, and what the Team Board should now show."): """As of today (April 20, 2026), the Noventra IPST is still targeting the October 2026 launch, but Launch Readiness Review (LRR) remains At Risk.

### Latest updates:

- Dr. Priya Nair (Medical SPOC) completed the evidence review later than planned.
- Luis Martinez (Market Access SPOC) is behind schedule with finalizing the access strategy due to delayed market research results.
- The Target Product Profile (TPP) cannot be finalized until Medical and Market Access inputs are reconciled. All other TPP inputs are completed.
- Mark Davidson (Forecasting) prepared a provisional forecast scenario, but the forecast cannot be locked until the TPP is finalized.
- Sarah Chen (BEL) is keeping Launch Readiness flagged At Risk until the cross-functional inputs are aligned and the next decision path is clear.
- LRR pre-reads are due next week, legal review required before pre-reads go to Victor and US LT.

### Kanban Board update:

- Launch Readiness should remain At Risk.
- Forecast Lock should remain Provisional / At Risk until the TPP is finalized.
- The Kanban Board should show a new dependency between Medical Evidence, Market Access assumptions, TPP finalization, and Forecasting.

### Assignments:

| Name | Function / Role | Task | Due Date | Status |
| --- | --- | --- | --- | --- |
| Dr. Priya Nair | Medical | Medical Evidence Review | 2026-04-15 | Done — completed later than planned |
| Luis Martinez | Market Access | Finalize Access Research and Assumptions | 2026-04-22 | At Risk |
| Sarah Chen | BEL | Confirm Launch Readiness Status and Decision Log | 2026-04-22 | At Risk |
| Priya Nair + Luis Martinez | Medical + Market Access | Reconcile Inputs for TPP | 2026-04-23 | In Progress |
| Mark Davidson | Forecasting | Update Forecast Based on Final TPP | 2026-04-24 | Provisional / At Risk |
""",

    _normalize_q("For the TPP and forecasting issue, I need to understand what happened and how we got here."): """As of today (April 20, 2026), here is the TPP and forecasting timeline.

### Team Meeting – April 8, 2026:

Dr. Priya Nair (Medical) flagged that the evidence review would be completed later than planned.

### Team Channel Conversation – April 9, 2026:

Luis Martinez (Market Access) flagged that updated access research and assumptions were still being refined. Sarah Chen (BEL) noted that the team needed one aligned view before the TPP could be finalized.

### Email Update – April 10, 2026:

Mark Davidson (Forecasting) prepared a provisional forecast scenario so the team could keep moving, but clearly marked the forecast as dependent on final TPP finalization.

### Current Status – April 20, 2026:

Forecast Lock remains Provisional / At Risk until the TPP is finalized using aligned Medical and Market Access inputs.

### Upcoming Critical Milestone:

Noventra's next LRR is on June 8, 2026. Victor specifically asked for a confirmed TPP and Integrated Evidence Plan (IEP) for that LRR, as further delays will jeopardize the target launch date.

### Open work items related to the TPP and forecasting issue:

| Name | Function / Role | Task | Due Date | Status |
| --- | --- | --- | --- | --- |
| Dr. Priya Nair | Medical | Medical Evidence Review | 2026-04-15 | Done — completed later than planned |
| Luis Martinez | Market Access | Finalize Access Research and Assumptions | 2026-04-22 | At Risk |
| Priya Nair + Luis Martinez | Medical + Market Access | Reconcile Inputs for TPP | 2026-04-23 | In Progress |
| Mark Davidson | Forecasting | Forecast Lock | 2026-04-24 | Provisional / At Risk |
| Sarah Chen | BEL | Confirm TPP Decision Path for upcoming LRR | 2026-04-24 | At Risk |
""",

    _normalize_q("Yes, I need to prepare for that LRR. Based on our prior LRRs and recent IPST activity, what topics are likely to come up again, and how should the team prepare?"): """Yes, based on previous LRRs Noventra's Launch Readiness at risk is the top priority for the upcoming LRR on June 8, 2026. The IPST should prepare a scenario-based decision matrix on whether to delay Noventra's launch if the TPP and IEP are not finalized before June 8.

### What prior LRRs discussed:

Prior Noventra LRRs focused on whether the product profile was mature enough to support downstream launch planning. The TPP and IEP are now the key cross-functional dependency because they require aligned input from Medical, Market Access, Marketing / GM, and Forecasting.

### How the team should prepare:

- Update the Launch Readiness slide to show "At Risk" and explain why.
- Prepare a decision matrix for whether to delay the Noventra launch.
- Add a TPP and IEP dependency slide showing required inputs from Medical, Market Access, Marketing / GM, and Forecasting.
- Add a Forecasting slide that clearly labels the current scenario as provisional.
- Add a final decision slide with the specific asks for the US LT.

### Suggested owners for LRR preparation:

Here's how I would suggest the team work together to prepare for the upcoming LRR.

| Owner | Role | Preparation responsibility |
| --- | --- | --- |
| Sarah Chen | BEL | Maintain launch readiness status, decision log, and owner/date table. |
| Sarah Chen | BEL | Frame the LRR decision asks and confirm what leadership needs to resolve. |
| Dr. Priya Nair | Medical | Confirm evidence of inputs available for TPP use. |
| Luis Martinez | Market Access | Confirm updated access assumptions. |
| Mark Davidson | Forecasting | Update forecast once TPP inputs are finalized. |
| IDS partner | IDS | Support deck updates and data views for the LRR package. |
""",
}

# ============================================================================
# FASTAPI APP CONFIGURATION (with SageMaker/Proxy Support)
# ============================================================================
# When running behind a reverse proxy (like AWS SageMaker), we need to configure
# the root_path so that Swagger UI can correctly locate the OpenAPI schema.
# The root_path is determined from the X-Forwarded-Prefix header or environment.
# ============================================================================

def get_root_path() -> str:
    """
    Determine the root path for the FastAPI app.
    This is needed when running behind a proxy like AWS SageMaker.
    """
    # Check for environment variable override
    root_path = os.environ.get("ROOT_PATH", "")
    if root_path:
        return root_path
    
    # For SageMaker Code Editor, the path pattern is: /codeeditor/default/ports/{port}
    # This will be handled by the middleware below
    return ""

app = FastAPI(
    title="Agentic Colleague API",
    description="API for Agentic Colleague - Work Item Management and Batch Data Ingestion",
    version="1.0.0",
    root_path=get_root_path(),
    # Ensure OpenAPI schema is served correctly behind proxy
    openapi_url="/openapi.json",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Middleware to handle proxy headers and set root_path dynamically
@app.middleware("http")
async def add_root_path_from_headers(request, call_next):
    """
    Middleware to dynamically set root_path from proxy headers.
    This handles AWS SageMaker's X-Forwarded-Prefix header.
    """
    # Get forwarded prefix from headers (SageMaker sends this)
    forwarded_prefix = request.headers.get("x-forwarded-prefix", "")
    
    # Also check for the full path prefix pattern
    if not forwarded_prefix:
        # Try to extract from the host/path for SageMaker pattern
        forwarded_host = request.headers.get("x-forwarded-host", "")
        if "sagemaker" in forwarded_host.lower():
            # SageMaker detected - the scope root_path should handle it
            pass
    
    response = await call_next(request)
    return response

# Allow frontend origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500", "http://localhost:5500", "http://localhost:3000","http://localhost:8000", "*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Auto-seed required Noventra IPST tasks on startup ─────────────────────────
_SEED_PROJECT = "Noventra IPST"
_SEED_PK = f"PROJECT#{_SEED_PROJECT}"
_SEED_TASKS = [
    # ── Canned Scenario 1 & 2 tasks ──────────────────────────────────────────
    {"task": "Medical Evidence Review",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "done",
     "summary": "Completed later than planned. Inputs now available for TPP."},

    {"task": "Finalize Access Research and Assumptions",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Behind schedule due to delayed market research results. Blocking TPP finalization."},

    {"task": "Finalize Access Strategy",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Access strategy cannot be finalized until market research results are confirmed."},

    {"task": "Confirm Launch Readiness Status and Decision Log",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Sarah Chen maintaining launch readiness status and decision log. Currently At Risk."},

    {"task": "Reconcile Inputs for TPP",
     "assigned_to": "Priya Nair + Luis Martinez", "ipst_function": "Medical + Market Access",
     "due_date": "2026-04-23", "status": "in progress",
     "summary": "Medical and Market Access inputs must be reconciled before TPP can be finalized."},

    {"task": "Update Forecast Based on Final TPP",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Provisional forecast prepared. Cannot be locked until TPP inputs are finalized."},

    {"task": "Forecast Lock",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Provisional / At Risk. Dependent on TPP finalization."},

    {"task": "Confirm TPP Decision Path for upcoming LRR",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Sarah Chen to confirm TPP decision path ahead of June 8 LRR."},

    # ── Q1: Blockers ──────────────────────────────────────────────────────────
    {"task": "Payer Objection Handling Plan",
     "assigned_to": "Unassigned", "ipst_function": "Cross-Functional",
     "due_date": "", "status": "pending",
     "summary": "Blocked — no function has confirmed ownership. Market Access and Field Strategy need to align."},

    {"task": "Resolve TPP Input Dependency",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-25", "status": "in progress",
     "summary": "Cross-functional blocker: TPP cannot be finalized until Medical and Market Access inputs are reconciled."},

    {"task": "Decide on forecast submission approach",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Decision needed on whether to proceed with broad access assumptions or request extension."},

    {"task": "Finalize launch forecast assumptions",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-10", "status": "pending",
     "summary": "Finance needs to lock forecast assumptions but cannot proceed without access strategy clarity."},

    {"task": "Provide Medical evidence inputs for access strategy",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Medical evidence inputs required before access strategy decision can be finalized."},

    # ── Q2: Decisions ─────────────────────────────────────────────────────────
    {"task": "Log LRR Decision — TPP Finalization Path",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-24", "status": "in progress",
     "summary": "Decision: team agreed to reconcile Medical and Market Access inputs before locking TPP."},

    {"task": "Record decisions in action log",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "", "status": "pending",
     "summary": "Nina Patel to record all cross-functional decisions in the action log."},

    {"task": "Prepare field training with placeholder messaging",
     "assigned_to": "Rachel Kim", "ipst_function": "Field Strategy",
     "due_date": "", "status": "pending",
     "summary": "Field training materials to use provisional messaging until Medical approval obtained."},

    {"task": "Escalate forecast timing issue to Finance VP",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Informally escalate to Finance VP to gauge acceptance of caveated forecast before requesting formal extension."},

    {"task": "Submit forecast or request extension",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-10", "status": "pending",
     "summary": "Submit provisional launch forecast with caveats or request a formal extension."},

    {"task": "Provide preliminary medical evidence readout",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-13", "status": "pending",
     "summary": "Provide preliminary medical evidence readout to unblock access strategy work."},

    # ── Q3: Risks ─────────────────────────────────────────────────────────────
    {"task": "Launch Readiness Review",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-10-01", "status": "in progress",
     "summary": "Launch Readiness At Risk. Cross-functional inputs not yet aligned."},

    {"task": "Update Launch Readiness Slide for LRR",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-06-06", "status": "pending",
     "summary": "Update slide to show At Risk status and explain dependency chain for June 8 LRR."},

    {"task": "Support deck updates and data views for the LRR package",
     "assigned_to": "IDS partner", "ipst_function": "IDS",
     "due_date": "2026-06-06", "status": "pending",
     "summary": "IDS partner to support deck updates and data views for the LRR package."},

    {"task": "Prepare updated status view",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Nina Patel to prepare updated launch readiness status view for IPST sync."},

    {"task": "Finalize access strategy decision",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-30", "status": "pending",
     "summary": "Access strategy decision required to unblock forecast and field materials."},

    {"task": "Prepare leadership progress update",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-23", "status": "pending",
     "summary": "Sarah Chen to prepare leadership progress update on launch readiness."},

    # ── Q4: Action Items ──────────────────────────────────────────────────────
    {"task": "Confirm Access Assumptions for TPP",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Action item: Luis Martinez to confirm updated access assumptions."},

    {"task": "Confirm Medical Evidence Inputs for TPP",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-22", "status": "in progress",
     "summary": "Action item: Priya Nair to confirm evidence inputs are available for TPP use."},

    {"task": "Submit forecast with broad access assumptions",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-16", "status": "pending",
     "summary": "Submit forecast using broad payer access assumption as working scenario."},

    {"task": "Provide preliminary access insights",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Provide preliminary access insights to support Market Access strategy work."},

    {"task": "Complete clinical evidence review (subgroup analysis)",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Complete clinical subgroup analysis — delayed by ~1 week due to data complexities."},

    {"task": "Document provisional forecast decision",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "", "status": "pending",
     "summary": "Document the decision to proceed with provisional forecast using broad access assumptions."},

    # ── Q5: Pending Tasks ─────────────────────────────────────────────────────
    {"task": "Finalize Field Materials with Approved Messaging",
     "assigned_to": "Rachel Kim", "ipst_function": "Field Strategy",
     "due_date": "2026-05-01", "status": "in progress",
     "summary": "Rachel Kim to finalize field materials with approved messaging."},

    {"task": "Complete Field Training Content",
     "assigned_to": "Rachel Kim", "ipst_function": "Field Strategy",
     "due_date": "2026-05-15", "status": "pending",
     "summary": "Rachel Kim to complete field training content. Pending Payer Objection Handling Plan."},

    {"task": "Prepare LRR Decision Matrix",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-06-06", "status": "pending",
     "summary": "Decision matrix on whether to delay Noventra launch if TPP and IEP not finalized before June 8 LRR."},

    {"task": "Update decision log",
     "assigned_to": "Nina Patel", "ipst_function": "Bus. Excellence",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Update the team decision log with latest cross-functional decisions."},

    {"task": "Decide on forecast lock delay",
     "assigned_to": "Mark Davidson", "ipst_function": "Forecasting",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Decision needed on whether to delay the forecast lock given pending Medical evidence."},

    {"task": "Confirm timeline accommodation for one-week shift",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Luis Martinez to confirm whether Market Access can accommodate a one-week timeline shift."},

    {"task": "Discuss timeline impacts at IPST sync",
     "assigned_to": "Sarah Chen", "ipst_function": "BEL",
     "due_date": "2026-04-09", "status": "pending",
     "summary": "Sarah Chen to lead discussion on timeline impacts at the next IPST sync meeting."},

    # ── Q6: Access Strategy Status ────────────────────────────────────────────
    {"task": "Complete Updated Payer Materials",
     "assigned_to": "Luis Martinez", "ipst_function": "Market Access",
     "due_date": "2026-04-24", "status": "pending",
     "summary": "Not ready — dependent on finalized access strategy."},

    {"task": "Complete Medical evidence review",
     "assigned_to": "Dr. Priya Nair", "ipst_function": "Medical",
     "due_date": "2026-04-15", "status": "pending",
     "summary": "Subgroup analysis delayed ~1 week due to data complexities. Blocking access strategy."},
]

# ── DISABLED: Hardcoded seed tasks - now loading 100% from DynamoDB ─────────
# To re-enable demo seeding, uncomment the @app.on_event block below.
# 
# @app.on_event("startup")
# def seed_kanban_tasks():
#     """Insert required demo tasks into KanbanTasks_Draft on every startup.
#     Always upserts — guarantees correct data on every deploy."""
#     try:
#         _seed_table = dynamodb_resource.Table("AgenticColleague_KanbanTasks_Test")
#         _now = datetime.now(timezone.utc).isoformat()
#         _upserted = 0
#         for t in _SEED_TASKS:
#             _task_id = t["task"].lower().replace(" ", "_").replace("/", "_")[:40]
#             _sk = f"TASK#{_task_id}"
#             try:
#                 _seed_table.put_item(
#                     Item={
#                         "PK": _SEED_PK,
#                         "SK": _sk,
#                         "task_id": _task_id,
#                         "project_name": _SEED_PROJECT,
#                         "task": t["task"],
#                         "assigned_to": t["assigned_to"],
#                         "ipst_function": t["ipst_function"],
#                         "due_date": t.get("due_date", ""),
#                         "status": t["status"],
#                         "summary": t.get("summary", ""),
#                         "source_type": "auto_seed",
#                         "source_uri": "startup",
#                         "event_timestamp": _now,
#                         "updated_at": _now,
#                     }
#                     # No condition — always upsert so task is guaranteed correct
#                 )
#                 _upserted += 1
#             except Exception as _ce:
#                 print(f"[SEED] Error upserting '{t['task']}': {_ce}")
#         print(f"[SEED] Startup seeding complete — {_upserted} tasks upserted (guaranteed on board).")
#     except Exception as _e:
#         print(f"[SEED] Startup seeding failed (non-fatal): {_e}")
# ──────────────────────────────────────────────────────────────────────────────

# In[63]:


class GraphState(TypedDict, total=False):
    user_input: str
    user_id: str
    session_id: str
    chat_history: List[str]
    result_payload: dict
    
    workspace_id: str
    project_id: str
    project_name: str

    reporter: str
    assignee: str
    assignees: List[str]

    intent: str

    work_item_id: str
    title: str
    description: str
    status: str
    priority: str
    due_date: str
    lifecycle_state: str
    is_deleted: bool

    blocker: str
    dependency: str
    issue: str
    summary: str
    decision: str
    action: str

    retrieval_query: str
    retrieval_plan: Dict[str, Any]
    work_items_results: List[Dict[str, Any]]
    work_evidence_results: List[Dict[str, Any]]
    retrieval_results: Any

    resolved_work_item_id: str
    resolution_confidence: float
    conflict_flag: bool
    conflict_reason: str
    clarification_needed: bool
    clarification_question: str
    clarification_received: bool

    decision_type: str
    decision_reason: str
    action_plan: List[Dict[str, Any]]
    final_response: str


# In[64]:


s3 = boto3.client('s3', region_name="us-east-1")
bucket_name = "ids-aini-prototype-ai-analytics"
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
titan_v2_embedding_modelId = "amazon.titan-embed-text-v2:0"
model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
host = "https://oqjh772goqkmg0mlp7gg.us-east-1.aoss.amazonaws.com"

region = "us-east-1"
service = "aoss"
host = "https://oqjh772goqkmg0mlp7gg.us-east-1.aoss.amazonaws.com"


def get_fresh_awsauth():
    """
    Get fresh AWS4Auth credentials for OpenSearch Serverless.
    This function creates new credentials each time it's called,
    preventing 403 errors caused by expired session tokens.
    
    AWS temporary credentials expire (typically 1-12 hours), so we must
    refresh them before each OpenSearch request rather than using
    static credentials created at module import time.
    """
    session = boto3.Session()
    credentials = session.get_credentials()
    return AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        region,
        service,
        session_token=credentials.token
    )

headers = {"Content-Type": "application/json"}
llm = ChatBedrock(
        model="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        region_name="us-east-1",
        model_kwargs={
            "temperature": 0.1,
            "max_tokens": 2056, # maximum output tokens
        },
    )


# In[65]:


def clean_llm_output(text: str) -> str:
    text = text.strip()

    # Remove ```json ... ``` or ``` ... ```
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)

    # Remove leading 'json' if present
    if text.lower().startswith("json"):
        text = text[4:].strip()

    return text.strip()
    
import json

def pretty_print_adjudication(result):
    output = []

    def add(line=""):
        output.append(line)

    mode = result.get("mode", "unknown")
    add(f"\nMODE: {mode}")

    adjudication = result.get("adjudication", {})

    if not adjudication:
        add("\nANSWER:")
        answer = result.get("answer", "")
        if isinstance(answer, str):
            add(answer.replace("\\n", "\n"))
        else:
            add(json.dumps(answer, indent=2, default=str))

        retrieved_evidence = result.get("retrieved_evidence", [])
        work_item_matches = result.get("work_item_matches", [])

        if retrieved_evidence:
            add(f"\nRETRIEVED EVIDENCE COUNT: {len(retrieved_evidence)}")

        if work_item_matches:
            add(f"\nWORK ITEM MATCH COUNT: {len(work_item_matches)}")

        return "\n".join(output)

    if "update" in mode:
        add("\nDECISION: " + str(adjudication.get("decision")))
        add("SHOULD UPDATE: " + str(adjudication.get("should_update")))
        add("CONFIDENCE: " + str(adjudication.get("confidence")))
        add("USER SIGNAL: " + str(adjudication.get("user_signal_strength")))
        add("HISTORICAL SIGNAL: " + str(adjudication.get("historical_signal_strength")))

        add("\nAFFECTED FIELDS:")
        affected_fields = adjudication.get("affected_fields", [])
        if affected_fields:
            for field in affected_fields:
                add(f"- {field}")
        else:
            add("- None")

        add("\nREASONING SUMMARY:")
        reasoning_summary = adjudication.get("reasoning_summary", [])
        if reasoning_summary:
            for line in reasoning_summary:
                add(f"- {line}")
        else:
            add("- None")

        add("\nCURRENT STATE SUMMARY:")
        add(json.dumps(adjudication.get("current_state_summary", {}), indent=2, default=str))

        add("\nPROPOSED STATE SUMMARY:")
        add(json.dumps(adjudication.get("proposed_state_summary", {}), indent=2, default=str))

        add("\nNEXT ACTION:")
        add(str(adjudication.get("next_action")))

    elif "create" in mode:
        add("\nDECISION: " + str(adjudication.get("decision")))
        add("SHOULD CREATE: " + str(adjudication.get("should_create")))
        add("CONFIDENCE: " + str(adjudication.get("confidence")))

        add("\nREASONING SUMMARY:")
        reasoning_summary = adjudication.get("reasoning_summary", [])
        if reasoning_summary:
            for line in reasoning_summary:
                add(f"- {line}")
        else:
            add("- None")

        add("\nSELECTED EXISTING WORK ITEM ID:")
        add(str(adjudication.get("selected_existing_work_item_id")))

        add("\nCANDIDATE DUPLICATE IDS:")
        duplicate_ids = adjudication.get("candidate_duplicate_ids", [])
        if duplicate_ids:
            for item in duplicate_ids:
                add(f"- {item}")
        else:
            add("- None")

        add("\nPROPOSED STATE SUMMARY:")
        add(json.dumps(adjudication.get("proposed_state_summary", {}), indent=2, default=str))

        add("\nCURRENT STATE SUMMARY:")
        add(json.dumps(adjudication.get("current_state_summary", {}), indent=2, default=str))

        add("\nCLARIFICATION QUESTION:")
        add(str(adjudication.get("clarification_question")))

        add("\nNEXT ACTION:")
        add(str(adjudication.get("next_action")))

        proposed_item = result.get("proposed_item")
        if proposed_item:
            add("\nPROPOSED ITEM:")
            add(json.dumps(proposed_item, indent=2, default=str))

        candidate_info = result.get("candidate_info", {})
        if candidate_info:
            structured_candidates = candidate_info.get("structured_candidates", [])
            semantic_candidates = candidate_info.get("semantic_candidates", [])

            add(f"\nSTRUCTURED CANDIDATES COUNT: {len(structured_candidates)}")
            for idx, candidate in enumerate(structured_candidates[:3], start=1):
                add(f"\nSTRUCTURED CANDIDATE {idx}:")
                add(json.dumps(candidate, indent=2, default=str))

            add(f"\nSEMANTIC CANDIDATES COUNT: {len(semantic_candidates)}")
            for idx, candidate in enumerate(semantic_candidates[:3], start=1):
                add(f"\nSEMANTIC CANDIDATE {idx}:")
                add(json.dumps(candidate, indent=2, default=str))

    else:
        add("\nADJUDICATION:")
        add(json.dumps(adjudication, indent=2, default=str))

    answer = result.get("answer")
    if answer:
        add("\nANSWER:")
        if isinstance(answer, str):
            add(answer.replace("\\n", "\n"))
        else:
            add(json.dumps(answer, indent=2, default=str))

    work_item_matches = result.get("work_item_matches", [])
    if work_item_matches:
        add(f"\nWORK ITEM MATCH COUNT: {len(work_item_matches)}")

    retrieved_evidence = result.get("retrieved_evidence", [])
    if retrieved_evidence:
        add(f"\nRETRIEVED EVIDENCE COUNT: {len(retrieved_evidence)}")

    return "\n".join(output)

# In[66]:


# retrieve function
accept = "application/json"
content_type = "application/json"
def vectorize_with_titan(text: str, model_id = titan_v2_embedding_modelId) -> List[float]:
    payload = {
        "inputText": text,
        # Optional params
        # "dimensions": 1024,
        # "normalize": True
    }
    response = bedrock.invoke_model(
        modelId=model_id, body=json.dumps(payload), accept=accept, contentType=content_type)

    response_body = json.loads(response["body"].read())
    return response_body["embedding"]
    
def knn_search_work_evidence(
    query_text: str,
    host=host,
    awsauth=None,  # Will get fresh credentials if None
    embed_text_fn=vectorize_with_titan,
    k: int = 10
):
    # Get fresh credentials to avoid 403 errors from expired tokens
    if awsauth is None:
        awsauth = get_fresh_awsauth()
    
    query_vector = embed_text_fn(query_text)

    query_body = {
        "size": k,
        "query": {
            "knn": {
                "vector_embedding": {
                    "vector": query_vector,
                    "k": k
                }
            }
        },
        "_source": [
            "summary",
            "clean_text",
            "source_uri",
            "source_type",
            "metadata",
            "action_items_detected",
            "decisions_detected"
        ]
    }

    response = requests.post(
        f"{host}/{vectordb_index}/_search",  # Uses test index
        auth=awsauth,
        headers={"Content-Type": "application/json"},
        json=query_body,
    )
    if response.status_code != 200:
        return []

    response_json = response.json()
    hits = response_json.get("hits", {}).get("hits", [])

    results = []
    for hit in hits:
        source = hit.get("_source", {})
        results.append({
            "score": hit.get("_score"),
            "summary": source.get("summary", ""),
            "clean_text": source.get("clean_text", ""),
            "source_uri": source.get("source_uri", ""),
            "source_type": source.get("source_type", ""),
            "metadata": source.get("metadata", {}),
            "action_items_detected": source.get("action_items_detected", []),
            "decisions_detected": source.get("decisions_detected", []),
        })

    return results

    
def format_search_results(results_list):
    formatted = []

    for results in results_list:
        ids = results.get("ids", [[]])[0]
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        dists = results.get("distances", [[]])[0] if "distances" in results else [None] * len(ids)

        for i in range(len(ids)):
            meta = metas[i] or {}
            project_names = meta.get("project_names", [])
            if isinstance(project_names, str):
                project_names = [project_names]

            formatted.append({
                "evidence_id": ids[i],
                "document": docs[i],
                "metadata": meta,
                "distance": dists[i]
            })

    return formatted


# work items - converting into dynamodb

def search_work_items(work_items_df, project_name=None, work_item_id=None, title=None, assignee=None):
    df = work_items_df.copy()

    if work_item_id:
        df = df[df["work_item_id"].astype(str) == str(work_item_id)]

    if project_name:
        df = df[df["project_name"].fillna("").str.lower() == project_name.lower()]

    if title:
        df = df[df["task"].fillna("").str.lower().str.contains(title.lower(), na=False)]

    if assignee:
        df = df[df["assignee"].fillna("").str.lower().str.contains(assignee.lower(), na=False)]

    return df


def keyword_search_work_items(work_items_df, query_text: str, max_results: int = 15):
    """Text-based keyword search across task, summary, task_evidence fields.
    Returns work items that contain ANY of the query keywords (case-insensitive).
    Used as fallback when structured filters return too many or too few results."""
    if work_items_df.empty or not query_text:
        return work_items_df

    # Extract meaningful keywords (skip very short words)
    stop_words = {'the','a','an','is','are','was','were','what','who','how','when','where','which',
                  'and','or','in','on','at','to','for','of','with','from','by','this','that','it',
                  'be','has','have','had','do','does','did','will','would','can','could','should',
                  'may','might','about','into','all','any','them','their','there','than'}
    words = [w for w in query_text.lower().split() if len(w) > 2 and w not in stop_words]
    
    if not words:
        return work_items_df.head(max_results)

    # Search across text fields
    searchable_cols = ['task', 'summary', 'task_evidence', 'project_name', 'assignee', 'source_uri', 'source_type']
    available_cols = [c for c in searchable_cols if c in work_items_df.columns]
    
    # Combine all text columns into one searchable string per row
    combined = work_items_df[available_cols].fillna('').astype(str).agg(' '.join, axis=1).str.lower()
    
    # Score each row by how many keywords it matches
    scores = pd.Series(0, index=work_items_df.index)
    for word in words:
        scores += combined.str.contains(word, na=False).astype(int)
    
    # Return items that match at least one keyword, sorted by relevance
    matched = work_items_df[scores > 0].copy()
    matched['_relevance_score'] = scores[scores > 0]
    matched = matched.sort_values('_relevance_score', ascending=False).head(max_results)
    matched = matched.drop(columns=['_relevance_score'])
    
    print(f"[DEBUG] keyword_search_work_items: {len(matched)} matches from {len(words)} keywords")
    return matched.reset_index(drop=True)


def retrieve_work_items_df_from_intent_result(
    intent_result,
    table_name,
):
    table = dynamodb_resource.Table(table_name)
    items = []

    # intent_result = intent_result or {}

    project_name = intent_result.get("project_name")
    work_item_id = intent_result.get("work_item_id")
    title = intent_result.get("title")
    assignee = intent_result.get("assignee")

    if project_name:
        # Try multiple case variants to handle case-insensitive matching
        case_variants = list(set([
            project_name,
            project_name.title(),        # "project apollo" -> "Project Apollo"
            project_name.upper(),        # "PROJECT APOLLO"
            project_name.lower(),        # "project apollo"
            project_name.capitalize(),   # "Project apollo"
        ]))
        for variant in case_variants:
            response = table.query(
                KeyConditionExpression=Key("PK").eq(f"PROJECT#{variant}")
            )
            items.extend(response.get("Items", []))
            while "LastEvaluatedKey" in response:
                response = table.query(
                    KeyConditionExpression=Key("PK").eq(f"PROJECT#{variant}"),
                    ExclusiveStartKey=response["LastEvaluatedKey"],
                )
                items.extend(response.get("Items", []))
            if items:
                break  # Found results, no need to try other variants
    else:
        response = table.scan()
        items.extend(response.get("Items", []))

        while "LastEvaluatedKey" in response:
            response = table.scan(
                ExclusiveStartKey=response["LastEvaluatedKey"]
            )
            items.extend(response.get("Items", []))

    df = pd.DataFrame(items)

    if df.empty:
        return pd.DataFrame(columns=[
            "work_item_id", "evidence_id", "source_uri", "source_type",
            "project_name", "task", "assignee", "due_date", "status",
            "task_evidence", "event_timestamp", "summary"
        ])

    for col in [
        "work_item_id", "evidence_id", "source_uri", "source_type",
        "project_name", "task", "assignee", "due_date", "status",
        "task_evidence", "event_timestamp", "summary"
    ]:
        if col not in df.columns:
            df[col] = ""

    if work_item_id:
        df = df[df["work_item_id"].astype(str) == str(work_item_id)]

    if project_name:
        df = df[df["project_name"].fillna("").str.lower() == str(project_name).lower()]

    if title:
        df = df[df["task"].fillna("").str.lower().str.contains(str(title).lower(), na=False)]

    if assignee:
        df = df[df["assignee"].fillna("").str.lower().str.contains(str(assignee).lower(), na=False)]

    return df.reset_index(drop=True)

    
def handle_retrieve_intent(intent_result, table_name=work_items, answer_fn=None):

    project_name = intent_result.get("project_name", "")
    retrieval_query = intent_result.get("retrieval_query") or project_name or intent_result.get("title")
    
    # Fallback: if retrieval_query is still empty or too short, use the full chat history as query
    if not retrieval_query or len(str(retrieval_query).strip()) < 3:
        chat_hist = intent_result.get("chat_history") or []
        if isinstance(chat_hist, list):
            retrieval_query = " ".join(chat_hist)
        elif isinstance(chat_hist, str):
            retrieval_query = chat_hist

    # ALWAYS enrich queries with context for better KNN matching
    chat_hist = intent_result.get("chat_history") or []
    user_text = " ".join(chat_hist) if isinstance(chat_hist, list) else str(chat_hist)
    user_lower = user_text.lower()

    # Intent-aware enrichment: expand query based on what the user is actually asking about
    if any(w in user_lower for w in ["decision", "decided", "agreed", "resolved", "conclusion"]):
        retrieval_query = f"decisions made agreed resolved confirmed provisional {user_text} action items outcomes blockers"
    elif any(w in user_lower for w in ["blocker", "blocked", "blocking", "impediment", "stuck", "on hold"]):
        retrieval_query = f"blocked on hold impediment dependency blocker waiting {user_text}"
    elif any(w in user_lower for w in ["risk", "risks", "at risk", "concern", "escalat"]):
        retrieval_query = f"risk at risk escalation concern launch readiness delay {user_text}"
    elif any(w in user_lower for w in ["action item", "action items", "follow up", "meeting", "last meeting", "raised"]):
        retrieval_query = f"action items follow up owner due date assigned meeting transcript {user_text}"
    elif any(w in user_lower for w in ["summar", "activit", "team activit", "overview", "what is going on", "what's happening"]):
        retrieval_query = f"team activities summary status update progress tasks decisions blockers people projects {user_text}"
    elif any(w in user_lower for w in ["pending", "outstanding", "not done", "incomplete", "todo", "to do"]):
        retrieval_query = f"pending tasks outstanding incomplete action items status not started to do {user_text}"
    elif any(w in user_lower for w in ["in progress", "current", "active", "ongoing", "working on"]):
        retrieval_query = f"in progress active ongoing current status working on projects tasks {user_text}"
    elif any(w in user_lower for w in ["status", "strategy", "access", "launch", "progress", "update", "noventra", "ipst"]):
        retrieval_query = f"status update progress launch strategy access plan tasks summary {user_text}"
    elif len(str(retrieval_query).split()) <= 4:
        # Short project-name style query — expand with project context
        retrieval_query = f"Tell me about {retrieval_query}. Project details, tasks, team members, milestones, status."
    
    # Also combine with user text if they differ
    if user_text and user_text.lower().strip() != retrieval_query.lower().strip():
        retrieval_query = f"{retrieval_query} {user_text}"
    
    print(f"[DEBUG] Final retrieval_query: {retrieval_query}")

    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=intent_result,
        table_name=table_name,
    )

    # WorkItems table is now the single source of truth - no merge needed
    print(f"[DEBUG] Retrieved {len(work_items_df)} WorkItems records")

    decision_trace = [
        "Detected retrieve intent",
        f"Querying work_evidence for: {retrieval_query}"
    ]

    # chroma_raw = search_work_evidence(
    #     work_evidence_collection,
    #     retrieval_query,
    #     n_results=5
    # )
    search_raw = knn_search_work_evidence(query_text=retrieval_query)
    print(f"[DEBUG] KNN search for '{retrieval_query}' returned {len(search_raw)} results")
    for i, item in enumerate(search_raw[:3]):
        print(f"[DEBUG] Result {i}: score={item.get('score')}, summary={item.get('summary', '')[:100]}")
 
    # Format KNN results into a consistent evidence format
    evidence = []
    for item in search_raw:
        evidence.append({
            "evidence_id": item.get("source_uri", ""),
            "document": item.get("clean_text") or item.get("summary", ""),
            "summary": item.get("summary", ""),
            "source_type": item.get("source_type", ""),
            "metadata": item.get("metadata", {}),
            "action_items": item.get("action_items_detected", []),
            "decisions": item.get("decisions_detected", []),
            "score": item.get("score")
        })
    decision_trace.append(f"Retrieved {len(evidence)} evidence records from work_evidence")

    work_item_matches = search_work_items(
        work_items_df,
        project_name=project_name,
        work_item_id=intent_result.get('work_item_id',''), 
        title=intent_result.get('title', ''), 
        assignee=intent_result.get('assignee','')
    )

    # When OpenSearch returns 0 results (403 or no index), ALWAYS run keyword search
    # on whatever work_item_matches we have — this ensures Noventra/IPST/project-specific
    # terms are matched even if structured filters returned a broad unfiltered result set.
    if len(evidence) == 0:
        keyword_filtered = keyword_search_work_items(work_items_df, user_text, max_results=15)
        if len(keyword_filtered) > 0:
            work_item_matches = keyword_filtered
            print(f"[DEBUG] No OpenSearch evidence — keyword search returned {len(work_item_matches)} items")
        elif len(work_item_matches) == 0:
            # keyword search also returned nothing — use full table as last resort
            work_item_matches = work_items_df.head(15)
            print(f"[DEBUG] Keyword search found nothing — falling back to full table ({len(work_item_matches)} items)")
        else:
            print(f"[DEBUG] Keyword search returned 0 — keeping {len(work_item_matches)} structured matches")

    decision_trace.append(f"Matched {len(work_item_matches)} rows in work_items")

    if answer_fn:
        answer = answer_fn(retrieval_query, evidence, work_item_matches)
    else:
        if evidence:
            answer = evidence[0]["document"]
        elif not work_item_matches.empty:
            # No OpenSearch evidence but we have DynamoDB keyword matches — summarise them
            answer = "\n".join(
                f"- {row.get('task','')} ({row.get('assignee','')}, {row.get('status','')})"
                for _, row in work_item_matches.head(5).iterrows()
                if row.get('task')
            ) or "No relevant evidence found."
        else:
            answer = "No relevant evidence found."

    return {
        "mode": "retrieve",
        "decision_trace": decision_trace,
        "retrieved_evidence": evidence,
        "work_item_matches": work_item_matches.to_dict(orient="records"),
        "answer": answer
    }


# In[67]:


# update function
# work_items_df = pd.read_csv('df_work_items.csv')

# cols = ['assignee', 'due_date']
# work_items_df = work_items_df[work_items_df[cols].notnull().all(axis=1)]  # keeping this as the final df with only 49 rows that contains both assignee and due date
def compress_work_items_for_llm(work_item_rows, max_rows=5):
    rows = work_item_rows[:max_rows]
    compressed = []

    for row in rows:
        compressed.append({
            "work_item_id": row.get("work_item_id"),
            "project_name": row.get("project_name"),
            "task": row.get("task"),
            "assignee": row.get("assignee"),
            "due_date": str(row.get("due_date")) if row.get("due_date") is not None else None,
            "status": row.get("status"),
            "summary": row.get("summary")
        })

    return compressed
def compress_evidence_for_llm(evidence_records, max_items=5, max_chars=500):
    compressed = []

    for ev in evidence_records[:max_items]:
        compressed.append({
            "evidence_id": ev.get("evidence_id"),
            "source_type": (ev.get("metadata") or {}).get("source_type"),
            "source_uri": (ev.get("metadata") or {}).get("source_uri"),
            "project_names": (ev.get("metadata") or {}).get("project_names"),
            "snippet": (ev.get("document") or "")[:max_chars]
        })

    return compressed
def build_updated_item_from_intent(previous_item, intent_result, user_text=None):
    user_text="\n".join(intent_result["chat_history"])
    if not previous_item:
        return None, []

    updated_item = dict(previous_item)
    changed_fields = []

    field_map = {
        "project_name": "project_name",
        "title": "task",
        "assignee": "assignee",
        "due_date": "due_date",
        "status": "status",
        "summary": "summary",
        "description": "summary"
    }

    for intent_key, item_key in field_map.items():
        new_value = intent_result.get(intent_key)
        if new_value is not None and str(new_value).strip() != "":
            old_value = previous_item.get(item_key)
            if str(old_value) != str(new_value):
                updated_item[item_key] = new_value
                changed_fields.append(item_key)

    updated_item["source_type"] = "user_input"
    changed_fields.append("source_type")

    updated_item["source_uri"] = "chat"
    changed_fields.append("source_uri")

    updated_item["event_timestamp"] = datetime.utcnow().isoformat()
    changed_fields.append("event_timestamp")

    if user_text:
        updated_item["task_evidence"] = user_text
        changed_fields.append("task_evidence")

    return updated_item, sorted(list(set(changed_fields)))
    
def make_work_item_text(row):
    parts = [
        str(row.get("project_name", "")),
        str(row.get("task", "")),
        str(row.get("summary", "")),
        str(row.get("assignee", "")),
        str(row.get("status", ""))
    ]
    return " ".join([p for p in parts if p and p != "None"])
    
def find_semantic_create_candidates(proposed_item, table_name=work_items, top_k=5):
    
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=proposed_item,
        table_name=table_name,
    )
    
    proposed_text = make_work_item_text(proposed_item)
    proposed_emb = np.array(vectorize_with_titan(proposed_text)).reshape(1, -1)
    
    texts = []
    rows = []

    for _, row in work_items_df.iterrows():
        texts.append(make_work_item_text(row))
        rows.append(row.to_dict())

    if not texts:
        return []

    embeddings = np.array([vectorize_with_titan(text) for text in texts])

    sims = cosine_similarity(proposed_emb, embeddings)[0]

    ranked = sorted(
        [{"similarity": float(sim), "row": row} for sim, row in zip(sims, rows)],
        key=lambda x: x["similarity"],
        reverse=True
    )

    return ranked[:top_k]
    
def find_structured_create_candidates(proposed_item,table_name=work_items, top_k=10):
    
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=proposed_item,
        table_name=table_name,
    )
    df = work_items_df.copy()

    project_name = (proposed_item.get("project_name") or "").strip().lower()
    assignee = (proposed_item.get("assignee") or "").strip().lower()
    task = (proposed_item.get("task") or "").strip().lower()

    if project_name:
        df = df[df["project_name"].fillna("").str.lower() == project_name]

    candidates = []

    for _, row in df.iterrows():
        row_task = str(row.get("task", "")).strip().lower()
        row_assignee = str(row.get("assignee", "")).strip().lower()

        score = 0
        reasons = []

        if assignee and row_assignee == assignee:
            score += 2
            reasons.append("same assignee")

        if task and row_task == task:
            score += 5
            reasons.append("exact same task")

        elif task and row_task and (task in row_task or row_task in task):
            score += 3
            reasons.append("task text overlap")

        if proposed_item.get("due_date") is not None and row.get("due_date") is not None:
            try:
                p_date = pd.to_datetime(proposed_item["due_date"]).date()
                r_date = pd.to_datetime(row["due_date"]).date()
                if p_date == r_date:
                    score += 2
                    reasons.append("same due date")
            except Exception:
                pass

        if score > 0:
            candidates.append({
                "match_score": score,
                "match_reasons": reasons,
                "row": row.to_dict()
            })

    candidates = sorted(candidates, key=lambda x: x["match_score"], reverse=True)
    return candidates[:top_k]

def build_proposed_item_for_matching(intent_result):
    user_text="\n".join(intent_result["chat_history"])
    return {
        "project_name": intent_result.get("project_name"),
        "task": intent_result.get("title") or intent_result.get("task") or intent_result.get("summary") or user_text,
        "assignee": intent_result.get("assignee"),
        "due_date": intent_result.get("due_date"),
        "status": intent_result.get("status"),
        "summary": intent_result.get("summary") or intent_result.get("description") or user_text
    }

def resolve_selected_work_item_hybrid(intent_result, table_name=work_items, top_k=5):
    user_text="\n".join(intent_result["chat_history"])
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=intent_result,
        table_name=table_name,
    )
    
    work_item_id = intent_result.get("work_item_id")

    if work_item_id:
        exact = work_items_df[
            work_items_df["work_item_id"].astype(str) == str(work_item_id)
        ]
        if not exact.empty:
            row = exact.iloc[0].to_dict()
            return {
                "selected_item": row,
                "resolution_method": "exact_work_item_id",
                "confidence": 1.0,
                "candidates": [{"row": row, "final_score": 1.0}]
            }

    proposed_item = build_proposed_item_for_matching(intent_result)

    structured_candidates = find_structured_create_candidates(
        table_name=work_items,
        proposed_item=proposed_item,
        top_k=top_k
    )

    semantic_candidates = find_semantic_create_candidates(
        proposed_item=proposed_item,
        table_name=work_items,
        top_k=top_k
    )

    structured_map = {}
    for item in structured_candidates:
        row = item["row"]
        wid = str(row.get("work_item_id"))
        structured_map[wid] = item

    semantic_map = {}
    for item in semantic_candidates:
        row = item["row"]
        wid = str(row.get("work_item_id"))
        semantic_map[wid] = item

    all_ids = set(structured_map.keys()) | set(semantic_map.keys())
    combined = []

    for wid in all_ids:
        s_score = structured_map.get(wid, {}).get("match_score", 0)
        sim_score = semantic_map.get(wid, {}).get("similarity", 0.0)

        row = None
        if wid in structured_map:
            row = structured_map[wid]["row"]
        elif wid in semantic_map:
            row = semantic_map[wid]["row"]

        final_score = (0.6 * sim_score) + (0.4 * min(s_score / 10.0, 1.0))

        combined.append({
            "work_item_id": wid,
            "row": row,
            "structured_score": s_score,
            "semantic_similarity": sim_score,
            "final_score": final_score,
            "match_reasons": structured_map.get(wid, {}).get("match_reasons", [])
        })

    combined = sorted(combined, key=lambda x: x["final_score"], reverse=True)

    if not combined:
        return {
            "selected_item": None,
            "resolution_method": "no_match",
            "confidence": 0.0,
            "candidates": []
        }

    best = combined[0]
    confidence = best["final_score"]

    if len(combined) > 1:
        gap = best["final_score"] - combined[1]["final_score"]
    else:
        gap = best["final_score"]

    if confidence < 0.55 or gap < 0.08:
        return {
            "selected_item": None,
            "resolution_method": "ambiguous",
            "confidence": confidence,
            "candidates": combined[:top_k]
        }

    return {
        "selected_item": best["row"],
        "resolution_method": "hybrid_structured_semantic",
        "confidence": confidence,
        "candidates": combined[:top_k]
    }
def parse_llm_json(text):
    text = text.strip()

    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) >= 3:
            text = "\n".join(lines[1:-1]).strip()

    return json.loads(text)
def run_llm_adjudication(prompt):
    raw = llm.invoke(prompt).content
    return raw
def build_adjudication_prompt(intent_result, work_item_rows, evidence_rows):
    user_text="\n".join(intent_result["chat_history"])
    payload = {
        "user_claim": user_text,
        "parsed_intent": intent_result,
        "structured_work_items": compress_work_items_for_llm(work_item_rows),
        "historical_evidence": compress_evidence_for_llm(evidence_rows)
    }

    prompt = f"""
You are a scrum master assistant evaluating a user's requested work-item update.

Your task:
- Compare the user's request against the structured work item records and retrieved historical evidence.
- Determine the most likely target work item, if one exists.
- Identify which fields the user wants changed.
- Prefer being helpful and action-oriented rather than overly rejecting updates.
- If the user clearly requests a change to a task, assignee, due date, status, summary, or similar field, treat that as a valid proposed update even if historical evidence differs.
- Use the historical evidence to explain conflicts, risks, or inconsistencies, not to automatically block the user's request.
- Only choose needs_clarification if the target work item or intended field change is too ambiguous.
- If a matching item is found and the requested change is clear, prepare an updated version of the item.
- If historical evidence conflicts with the user's request, prefer confirm_overwrite instead of reject_update.
- Do not assume the user is always correct.
- Do not assume the historical records are always correct either.
- Base your judgment on specificity, consistency, recency if visible, corroboration across sources, and whether the user's request is explicit.

Return ONLY valid JSON with this schema:
{{
  "decision": "apply_directly" | "confirm_overwrite" | "needs_clarification" | "no_matching_item",
  "should_update": true | false,
  "confirmation_required": true | false,
  "user_signal_strength": "weak" | "medium" | "strong",
  "historical_signal_strength": "weak" | "medium" | "strong",
  "confidence": 0.0,
  "affected_fields": [],
  "reasoning_summary": [],
  "current_state_summary": {{}},
  "proposed_state_summary": {{}},
  "selected_work_item_id": "",
  "previous_item": {{}},
  "updated_item": {{}},
  "conflict_summary": [],
  "next_action": ""
}}

Rules:
- reasoning_summary must be concise, factual, and explainable.
- Do not reveal hidden chain of thought.
- Use only evidence from the provided context.
- If the user's update request is explicit and a matching work item is found, prefer apply_directly or confirm_overwrite.
- If historical evidence differs, summarize the conflict and prefer confirm_overwrite.
- If the request is ambiguous about which item to change, use needs_clarification.
- If no matching work item exists, use no_matching_item.
- previous_item must contain the selected original work item when available.
- updated_item must contain the same item with the user's requested changes applied when possible.
- Preserve unchanged fields in updated_item.
- affected_fields should list only the fields that changed.

Context:
{json.dumps(payload, indent=2, default=str)}
"""
    return prompt

    
def gather_update_context(intent_result, table_name=work_items, n_results=5):
    user_text="\n".join(intent_result["chat_history"])
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=intent_result,
        table_name=table_name,
    )
    
    project_name = intent_result.get("project_name")
    title = intent_result.get("title")
    assignee = intent_result.get("assignee")
    work_item_id = intent_result.get("work_item_id")

    work_item_matches = search_work_items(
        work_items_df,
        project_name=project_name,
        work_item_id=work_item_id,
        title=title,
        assignee=assignee
    )

    query_parts = [
        user_text,
        intent_result.get("retrieval_query"),
        project_name,
        title,
        intent_result.get("description"),
        intent_result.get("status"),
        assignee,
        str(intent_result.get("due_date")) if intent_result.get("due_date") else None,
        intent_result.get("summary")
    ]
    query_text = " ".join([x for x in query_parts if x])

    search_raw = knn_search_work_evidence(query_text=query_text,)
    evidence = format_search_results(search_raw)

    return {
        "user_text": user_text,
        "intent_result": intent_result,
        "work_item_matches": work_item_matches.to_dict(orient="records"),
        "evidence": evidence
    }
def handle_update_intent_with_llm(
    state,
    table_name=work_items
):
    context = gather_update_context(
        intent_result=state,
        table_name=work_items,
        n_results=5
    )

    prompt = build_adjudication_prompt(
        intent_result=context["intent_result"],
        work_item_rows=context["work_item_matches"],
        evidence_rows=context["evidence"]
    )

    raw_llm_output = run_llm_adjudication(prompt)
    adjudication = parse_llm_json(raw_llm_output)

    resolution = resolve_selected_work_item_hybrid(
        intent_result=state,
        table_name=work_items,
        top_k=5
        )

    previous_item = resolution.get("selected_item")

    updated_item = None
    changed_fields = []

    if previous_item is not None:
        updated_item, changed_fields = build_updated_item_from_intent(previous_item, state)

    if updated_item is not None:
        adjudication["previous_item"] = previous_item
        adjudication["updated_item"] = updated_item
        adjudication["affected_fields"] = changed_fields or adjudication.get("affected_fields", [])

        if adjudication.get("decision") == "apply_directly":
            adjudication["next_action"] = (
                "A matching work item was found and the requested changes were prepared. "
                "You can apply this update."
            )
        elif adjudication.get("decision") == "confirm_overwrite":
            adjudication["next_action"] = (
                "A matching work item was found and an updated version has been prepared. "
                "Historical evidence differs from the user request. Please confirm whether to overwrite the current item."
            )

    return {
        "mode": "update_review",
        "intent_result": state,
        "work_item_matches": context["work_item_matches"],
        "retrieved_evidence": context["evidence"],
        "adjudication": adjudication,
        "previous_item": previous_item,
        "updated_item": updated_item,
        "answer": adjudication.get("next_action", "No recommendation returned.")
    }


# In[68]:


# create node
def build_create_adjudication_prompt(intent_result, proposed_item, candidate_info):
    user_text="\n".join(intent_result["chat_history"])
    payload = {
        "user_request": user_text,
        "parsed_intent": intent_result,
        "proposed_work_item": proposed_item,
        "structured_candidates": candidate_info.get("structured_candidates", [])[:5],
        "semantic_candidates": candidate_info.get("semantic_candidates", [])[:5]
    }

    prompt = f"""
You are evaluating whether a user is trying to create a genuinely new work item or a duplicate of an existing one.

Your task:
- Review the proposed work item.
- Compare it against existing structured and semantically similar candidates.
- Decide whether this should be treated as:
  - a new work item,
  - a possible duplicate needing clarification,
  - an overwrite request,
  - or a request that should be ignored because the existing task should remain unchanged.

Return ONLY valid JSON with this schema:
{{
  "decision": "create_new" | "possible_duplicate" | "overwrite_existing" | "ignore_new_request" | "needs_clarification",
  "should_create": true | false,
  "confidence": 0.0,
  "reasoning_summary": [],
  "selected_existing_work_item_id": null,
  "candidate_duplicate_ids": [],
  "proposed_state_summary": {{}},
  "current_state_summary": {{}},
  "clarification_question": "",
  "next_action": ""
}}

Rules:
- Be concise and factual.
- Do not reveal hidden chain of thought.
- If the proposed item strongly overlaps with an existing item, prefer possible_duplicate or overwrite_existing.
- If it is clearly distinct, prefer create_new.
- If the user intent to overwrite is not explicit, do not assume overwrite_existing unless the request clearly indicates replacement.
- If evidence is mixed, prefer needs_clarification.

Context:
{json.dumps(payload, indent=2, default=str)}
"""
    return prompt

def gather_create_candidates(proposed_item, table_name=work_items, embed_fn=vectorize_with_titan):
    work_items_df = retrieve_work_items_df_from_intent_result(
        intent_result=proposed_item,
        table_name=table_name,
    )
    
    structured = find_structured_create_candidates(table_name=work_items, proposed_item=proposed_item, top_k=10)

    semantic = []
    if embed_fn is not None and len(work_items_df) > 0:
        semantic = find_semantic_create_candidates(proposed_item)

    return {
        "structured_candidates": structured,
        "semantic_candidates": semantic
    }
    
def build_proposed_work_item(intent_result, existing_item=None):
    """Build a proposed work item. If existing_item is provided, use its IDs to avoid duplicates."""
    user_text="\n".join(intent_result["chat_history"])
    
    # If we have an existing item, use its work_item_id to update instead of create new
    if existing_item:
        work_item_id = existing_item.get("work_item_id") or existing_item.get("SK", "").replace("TASK#", "")
    else:
        work_item_id = f"WI_{uuid.uuid4().hex[:10]}"
    
    return {
        "work_item_id": work_item_id,
        "evidence_id": existing_item.get("evidence_id") if existing_item else None,
        "source_uri": "user_chat",
        "source_type": "chat",
        "project_name": intent_result.get("project_name") or (existing_item.get("project_name") if existing_item else None),
        "task": intent_result.get("title") or intent_result.get("summary") or (existing_item.get("task") if existing_item else None),
        "assignee": intent_result.get("assignee") or (existing_item.get("assignee") or existing_item.get("assigned_to") if existing_item else None),
        "due_date": intent_result.get("due_date") or (existing_item.get("due_date") if existing_item else None),
        "status": intent_result.get("status") or (existing_item.get("status") if existing_item else "To Do"),
        "task_evidence": user_text,
        "event_timestamp": datetime.utcnow().isoformat(),
        "summary": intent_result.get("summary") or intent_result.get("description") or (existing_item.get("summary") if existing_item else None),
        # Preserve existing PK/SK for Kanban table updates
        "PK": existing_item.get("PK") if existing_item else None,
        "SK": existing_item.get("SK") if existing_item else None,
    }
def handle_create_intent_with_llm(
    state,
    table_name=work_items
):
    # First, try to find an existing matching item to avoid duplicates
    candidate_info = gather_create_candidates(
        proposed_item=build_proposed_work_item(state, existing_item=None)
    )
    
    # Check if there's a strong existing match - if so, use it instead of creating new
    existing_item = None
    structured_candidates = candidate_info.get("structured_candidates", [])
    semantic_candidates = candidate_info.get("semantic_candidates", [])
    
    # Look for high-confidence matches in structured candidates
    for candidate in structured_candidates:
        if candidate.get("match_score", 0) >= 3:  # Good structured match
            existing_item = candidate.get("row")
            break
    
    # If no structured match, check semantic candidates
    if not existing_item:
        for candidate in semantic_candidates:
            if candidate.get("similarity", 0) >= 0.75:  # Good semantic match
                existing_item = candidate.get("row")
                break
    
    # Also check WorkItems table for existing task with similar name
    if not existing_item:
        task_hint = (state.get("title") or state.get("summary") or "").lower().strip()
        if task_hint:
            try:
                _work_items_table = dynamodb_resource.Table(work_items)
                _scan = _work_items_table.scan()
                _items = _scan.get("Items", [])
                for item in _items:
                    task_str = (item.get("task") or "").lower()
                    if task_hint in task_str or task_str in task_hint:
                        existing_item = item
                        break
            except Exception:
                pass
    
    # Build proposed item using existing item's IDs if found
    proposed_item = build_proposed_work_item(state, existing_item=existing_item)

    prompt = build_create_adjudication_prompt(
        intent_result=state,
        proposed_item=proposed_item,
        candidate_info=candidate_info
    )

    raw_llm_output = llm.invoke(prompt).content
    adjudication = parse_llm_json(raw_llm_output)
    
    # If we found an existing item, mark it so create_node knows to update instead of create
    is_update_of_existing = existing_item is not None

    return {
        "mode": "create_review",
        "intent_result": state,
        "proposed_item": proposed_item,
        "candidate_info": candidate_info,
        "adjudication": adjudication,
        "answer": adjudication.get("next_action", "No recommendation returned."),
        "llm_prompt": prompt,
        "llm_raw_output": raw_llm_output,
        "existing_item": existing_item,
        "is_update_of_existing": is_update_of_existing
    }


# In[73]:


def normalize_date_for_opensearch(value):
    if not value:
        return None

    value = str(value).strip()
    if not value:
        return None

    # already ISO-like
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.date().isoformat()
        except ValueError:
            pass

    # common natural language dates
    for fmt in ("%B %d, %Y", "%b %d, %Y"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.date().isoformat()
        except ValueError:
            pass

    # unsupported fuzzy dates like "early June 2026"
    return None

def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _dedupe_preserve_order(values):
    seen = set()
    result = []
    for v in values:
        if v is None:
            continue
        v = str(v).strip()
        if not v:
            continue
        if v not in seen:
            seen.add(v)
            result.append(v)
    return result


def _drop_none(d):
    return {k: v for k, v in d.items() if v is not None}

def confirmed_updated_item_to_work_evidence_record(
    user_text,
    intent_result,
    adjudication,
    previous_item,
    updated_item,
    user_confirmation,
    workspace_id,
    project_id=None,
    source_uri="user_chat",
    embedding_fn=None,
):
    if not user_confirmation:
        raise ValueError("This function should only be used for confirmed updates.")

    intent_result = intent_result or {}
    adjudication = adjudication or {}
    previous_item = previous_item or {}
    updated_item = updated_item or {}

    evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()

    resolved_project_id = (
        project_id
        or updated_item.get("project_id")
        or previous_item.get("project_id")
        or intent_result.get("project_id")
    )

    linked_work_item_ids = _dedupe_preserve_order([
        previous_item.get("work_item_id"),
        updated_item.get("work_item_id"),
        intent_result.get("work_item_id"),
        adjudication.get("selected_work_item_id"),
    ])

    project_names = _dedupe_preserve_order([
        previous_item.get("project_name"),
        updated_item.get("project_name"),
        intent_result.get("project_name"),
    ])

    normalized_dates = _dedupe_preserve_order([
        normalize_date_for_opensearch(previous_item.get("due_date")),
        normalize_date_for_opensearch(updated_item.get("due_date")),
        normalize_date_for_opensearch(intent_result.get("due_date")),
    ])

    people = _dedupe_preserve_order([
        previous_item.get("assignee"),
        updated_item.get("assignee"),
        intent_result.get("assignee"),
        intent_result.get("reporter"),
    ])

    event_payload = {
        "event_type": "update_request_confirmed",
        "user_text": user_text,
        "intent_result": intent_result,
        "adjudication": adjudication,
        "previous_item": previous_item,
        "updated_item": updated_item,
        "user_confirmation": user_confirmation,
    }

    raw_text = json.dumps(event_payload, default=str, ensure_ascii=False)

    previous_task = str(previous_item.get("task") or previous_item.get("title") or "")
    updated_task = str(updated_item.get("task") or updated_item.get("title") or "")
    previous_status = str(previous_item.get("status") or "")
    updated_status = str(updated_item.get("status") or "")
    previous_assignee = str(previous_item.get("assignee") or previous_item.get("owner") or "")
    updated_assignee = str(updated_item.get("assignee") or updated_item.get("owner") or "")
    previous_due_date = normalize_date_for_opensearch(previous_item.get("due_date"))
    updated_due_date = normalize_date_for_opensearch(updated_item.get("due_date"))

    affected_fields = adjudication.get("affected_fields") or []
    affected_fields = [str(x) for x in affected_fields if x]

    summary_parts = [
        "User confirmed an update to an existing work item."
    ]
    if updated_task:
        summary_parts.append(f"Updated task: {updated_task}.")
    if updated_status:
        summary_parts.append(f"New status: {updated_status}.")
    if updated_assignee:
        summary_parts.append(f"Assignee: {updated_assignee}.")
    if updated_due_date:
        summary_parts.append(f"Due date: {updated_due_date}.")
    summary = " ".join(summary_parts)

    clean_text_parts = [
        "User confirmed an update to a work item.",
        f"User text: {user_text}",
        f"Project: {', '.join(project_names)}" if project_names else "",
        f"Work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Previous item: {json.dumps(previous_item, default=str, ensure_ascii=False)}",
        f"Updated item: {json.dumps(updated_item, default=str, ensure_ascii=False)}",
        f"Adjudication summary: {adjudication.get('reasoning_summary', '')}" if adjudication.get("reasoning_summary") else "",
        f"Affected fields: {', '.join(affected_fields)}" if affected_fields else "",
    ]
    clean_text = "\n".join(part for part in clean_text_parts if part)

    embedding_text_parts = [
        "Confirmed work item update",
        str(user_text or ""),
        f"Project names: {', '.join(project_names)}" if project_names else "",
        f"Linked work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Previous task: {previous_task}" if previous_task else "",
        f"Updated task: {updated_task}" if updated_task else "",
        f"Previous status: {previous_status}" if previous_status else "",
        f"Updated status: {updated_status}" if updated_status else "",
        f"Previous assignee: {previous_assignee}" if previous_assignee else "",
        f"Updated assignee: {updated_assignee}" if updated_assignee else "",
        f"Previous due date: {previous_due_date}" if previous_due_date else "",
        f"Updated due date: {updated_due_date}" if updated_due_date else "",
        f"Reasoning summary: {adjudication.get('reasoning_summary')}" if adjudication.get("reasoning_summary") else "",
        f"Conflict summary: {adjudication.get('conflict_summary')}" if adjudication.get("conflict_summary") else "",
        f"Proposed state: {adjudication.get('proposed_state_summary')}" if adjudication.get("proposed_state_summary") else "",
    ]
    embedding_text = "\n".join(part for part in embedding_text_parts if part)

    updated_due_date_for_action = normalize_date_for_opensearch(updated_item.get("due_date"))

    action_items_detected = [
        _drop_none({
            "title": updated_task or "Updated work item",
            "description": str(
                updated_item.get("summary")
                or updated_item.get("task_evidence")
                or updated_task
                or "Confirmed update to work item"
            ),
            "owner": updated_assignee if updated_assignee else None,
            "due_date": updated_due_date_for_action,
            "status": updated_status if updated_status else None,
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    decision_text_parts = [
        "User confirmed update to existing work item"
    ]
    if affected_fields:
        decision_text_parts.append(f"Affected fields: {', '.join(affected_fields)}")
    if adjudication.get("reasoning_summary"):
        decision_text_parts.append(str(adjudication.get("reasoning_summary")))

    decisions_detected = [
        _drop_none({
            "decision": ". ".join(decision_text_parts),
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    doc = {
        "evidence_id": evidence_id,
        "workspace_id": str(workspace_id),
        "project_id": str(resolved_project_id) if resolved_project_id is not None else "",
        "source_type": "chat_update_handler",
        "source_uri": str(source_uri),
        "raw_text": raw_text,
        "clean_text": clean_text,
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": linked_work_item_ids,
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": normalized_dates,
        "metadata": {
            "source_uri": str(source_uri),
            "entities": {
                "dates": normalized_dates,
                "organizations": [],
                "people": people,
                "projects": project_names,
                "systems": [],
                "tickets": linked_work_item_ids,
            }
        },
        "created_at": now,
        "updated_at": now,
    }

    if embedding_fn is not None:
        vector_embedding = embedding_fn(embedding_text)

        if hasattr(vector_embedding, "tolist"):
            vector_embedding = vector_embedding.tolist()

        if not isinstance(vector_embedding, list):
            raise ValueError(f"Embedding function must return a list, got {type(vector_embedding)}")

        if len(vector_embedding) != 1024:
            raise ValueError(f"Expected vector_embedding length 1024, got {len(vector_embedding)}")

        doc["vector_embedding"] = vector_embedding

    return doc

def confirmed_created_item_to_work_evidence_record(
    user_text,
    intent_result,
    adjudication,
    proposed_item,
    workspace_id,
    project_id=None,
    source_uri="user_chat",
    embedding_fn=None,
):
    intent_result = intent_result or {}
    adjudication = adjudication or {}
    proposed_item = proposed_item or {}

    evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()

    resolved_project_id = (
        project_id
        or proposed_item.get("project_id")
        or intent_result.get("project_id")
    )

    resolved_source_type = (
        proposed_item.get("source_type")
        or "chat_create_handler"
    )

    linked_work_item_ids = _dedupe_preserve_order([
        proposed_item.get("work_item_id"),
        intent_result.get("work_item_id"),
    ])

    project_names = _dedupe_preserve_order([
        proposed_item.get("project_name"),
        intent_result.get("project_name"),
    ])

    normalized_dates = _dedupe_preserve_order([
        normalize_date_for_opensearch(proposed_item.get("due_date")),
        normalize_date_for_opensearch(intent_result.get("due_date")),
    ])

    people = _dedupe_preserve_order([
        proposed_item.get("assignee"),
        proposed_item.get("owner"),
        intent_result.get("assignee"),
        intent_result.get("reporter"),
    ])

    event_payload = {
        "event_type": "create_request",
        "user_text": user_text,
        "intent_result": intent_result,
        "proposed_item": proposed_item,
        "adjudication": adjudication,
    }

    raw_text = json.dumps(event_payload, default=str, ensure_ascii=False)

    proposed_task = str(
        proposed_item.get("task")
        or proposed_item.get("title")
        or ""
    )
    proposed_status = str(proposed_item.get("status") or "")
    proposed_assignee = str(
        proposed_item.get("assignee")
        or proposed_item.get("owner")
        or ""
    )
    proposed_due_date = normalize_date_for_opensearch(proposed_item.get("due_date"))

    affected_fields = adjudication.get("affected_fields") or []
    affected_fields = [str(x) for x in affected_fields if x]

    summary_parts = [
        "User requested creation of a new work item."
    ]
    if proposed_task:
        summary_parts.append(f"Task: {proposed_task}.")
    if proposed_status:
        summary_parts.append(f"Status: {proposed_status}.")
    if proposed_assignee:
        summary_parts.append(f"Assignee: {proposed_assignee}.")
    if proposed_due_date:
        summary_parts.append(f"Due date: {proposed_due_date}.")
    summary = " ".join(summary_parts)

    clean_text_parts = [
        "User requested creation of a new work item.",
        f"User text: {user_text}",
        f"Project: {', '.join(project_names)}" if project_names else "",
        f"Work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Proposed item: {json.dumps(proposed_item, default=str, ensure_ascii=False)}",
        f"Adjudication summary: {adjudication.get('reasoning_summary', '')}" if adjudication.get("reasoning_summary") else "",
        f"Affected fields: {', '.join(affected_fields)}" if affected_fields else "",
    ]
    clean_text = "\n".join(part for part in clean_text_parts if part)

    embedding_text_parts = [
        "Create work item request",
        str(user_text or ""),
        f"Project names: {', '.join(project_names)}" if project_names else "",
        f"Linked work item ids: {', '.join(linked_work_item_ids)}" if linked_work_item_ids else "",
        f"Proposed task: {proposed_task}" if proposed_task else "",
        f"Proposed status: {proposed_status}" if proposed_status else "",
        f"Proposed assignee: {proposed_assignee}" if proposed_assignee else "",
        f"Proposed due date: {proposed_due_date}" if proposed_due_date else "",
        f"Intent summary: {intent_result.get('summary')}" if intent_result.get("summary") else "",
        f"Reasoning summary: {adjudication.get('reasoning_summary')}" if adjudication.get("reasoning_summary") else "",
        f"Proposed state: {adjudication.get('proposed_state_summary')}" if adjudication.get("proposed_state_summary") else "",
    ]
    embedding_text = "\n".join(part for part in embedding_text_parts if part)

    action_items_detected = [
        _drop_none({
            "title": proposed_task or "New work item",
            "description": str(
                proposed_item.get("summary")
                or proposed_item.get("task_evidence")
                or proposed_item.get("description")
                or proposed_task
                or "Requested new work item"
            ),
            "owner": proposed_assignee if proposed_assignee else None,
            "due_date": proposed_due_date,
            "status": proposed_status if proposed_status else None,
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    decisions_detected = [
        _drop_none({
            "decision": str(
                adjudication.get("decision")
                or "User requested creation of a new work item"
            ),
            "confidence": float(adjudication.get("confidence", 1.0) or 1.0),
        })
    ]

    doc = {
        "evidence_id": evidence_id,
        "workspace_id": str(workspace_id),
        "project_id": str(resolved_project_id) if resolved_project_id is not None else "",
        "source_type": str(resolved_source_type),
        "source_uri": str(source_uri),
        "raw_text": raw_text,
        "clean_text": clean_text,
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": linked_work_item_ids,
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": normalized_dates,
        "metadata": {
            "source_uri": str(source_uri),
            "entities": {
                "dates": normalized_dates,
                "organizations": [],
                "people": people,
                "projects": project_names,
                "systems": [],
                "tickets": linked_work_item_ids,
            }
        },
        "created_at": now,
        "updated_at": now,
    }

    if embedding_fn is not None:
        vector_embedding = embedding_fn(embedding_text)

        if hasattr(vector_embedding, "tolist"):
            vector_embedding = vector_embedding.tolist()

        if not isinstance(vector_embedding, list):
            raise ValueError(f"Embedding function must return a list, got {type(vector_embedding)}")

        if len(vector_embedding) != 1024:
            raise ValueError(f"Expected vector_embedding length 1024, got {len(vector_embedding)}")

        doc["vector_embedding"] = vector_embedding

    return doc

# Local registry file for uploaded content hashes (reliable fallback)
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(_BASE_DIR, "user_uploads_from_UI")
UPLOAD_HASH_REGISTRY = os.path.join(UPLOAD_DIR, ".upload_hashes")

def _load_hash_registry() -> set:
    """Load previously uploaded content hashes from local registry file."""
    try:
        if os.path.exists(UPLOAD_HASH_REGISTRY):
            with open(UPLOAD_HASH_REGISTRY, "r") as f:
                return set(line.strip() for line in f if line.strip())
    except Exception:
        pass
    return set()

def _save_hash_to_registry(content_hash: str):
    """Append a new content hash to the local registry file."""
    try:
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        with open(UPLOAD_HASH_REGISTRY, "a") as f:
            f.write(content_hash + "\n")
        print(f"[DEDUP] Saved hash {content_hash} to registry at {UPLOAD_HASH_REGISTRY}")
    except Exception as e:
        print(f"[DEDUP] Could not save hash to registry: {e}")

def check_duplicate_in_opensearch(content_hash: str, filename: str = "", index_name=vectordb_index, host=host, headers=headers) -> bool:
    """Returns True if a document with this content_hash or filename already exists.
    Checks local registry first (fast), then falls back to OpenSearch query.
    """
    # 1. Check local hash registry (fastest, most reliable)
    registry = _load_hash_registry()
    if content_hash in registry:
        print(f"[DEDUP] Found hash {content_hash} in local registry")
        return True

    # 2. Check OpenSearch — by content_hash OR by source_uri (filename)
    try:
        url = f"{host}/{index_name}/_search"
        should_clauses = [{"match": {"content_hash": content_hash}}]
        if filename:
            should_clauses.append({"match": {"source_uri": f"upload:{filename}"}})
        
        query = {
            "query": {
                "bool": {
                    "should": should_clauses,
                    "minimum_should_match": 1
                }
            },
            "_source": ["content_hash", "source_uri"],
            "size": 1
        }
        # Get fresh credentials to avoid 403 errors from expired tokens
        awsauth = get_fresh_awsauth()
        response = requests.post(url, auth=awsauth, headers=headers, data=json.dumps(query))
        result = response.json()
        print(f"[DEDUP] OpenSearch response: {json.dumps(result.get('hits', {}).get('total', {}))}")
        hits = result.get("hits", {}).get("total", {}).get("value", 0)
        if hits > 0:
            print(f"[DEDUP] Found duplicate in OpenSearch (hash or filename match)")
            # Also save to local registry so next time it's caught instantly
            _save_hash_to_registry(content_hash)
            return True
    except Exception as e:
        print(f"[DEDUP] OpenSearch check failed: {e}")

    # 3. Check DynamoDB WorkItems — scan for source_uri matching this filename
    # NOTE: Do NOT use Limit= here — DynamoDB Limit caps items *scanned*, not items
    # *returned after filtering*, so Limit=1 would silently miss matches.
    if filename:
        source_uri_val = f"upload:{filename}"
        try:
            table = dynamodb_resource.Table(work_items)  # Testing environment
            scan_kwargs = {
                "FilterExpression": "source_uri = :uri",
                "ExpressionAttributeValues": {":uri": source_uri_val},
                "ProjectionExpression": "work_item_id, source_uri",
            }
            found = False
            # Paginate until a match is found or the full table is scanned
            while True:
                resp = table.scan(**scan_kwargs)
                if resp.get("Items"):
                    found = True
                    break
                last_key = resp.get("LastEvaluatedKey")
                if not last_key:
                    break
                scan_kwargs["ExclusiveStartKey"] = last_key

            if found:
                print(f"[DEDUP] Found duplicate in DynamoDB WorkItems (source_uri={source_uri_val})")
                _save_hash_to_registry(content_hash)
                return True
        except Exception as e:
            print(f"[DEDUP] DynamoDB WorkItems check failed: {e}")

    # WorkItems table is now the single source of truth - no separate KanbanTasks check needed

    return False


def index_document(doc, index_name=vectordb_index, host=host, headers=headers):
    url = f"{host}/{index_name}/_doc"
    
    # Get fresh credentials to avoid 403 errors from expired tokens
    awsauth = get_fresh_awsauth()
    
    response = requests.post(
        url,
        auth=awsauth,
        headers=headers,
        data=json.dumps(doc)
    )
 
    return {
        "status_code": response.status_code,
        "text": response.text
    }

dynamodb_resource = boto3.resource("dynamodb", region_name="us-east-1")
 
def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()
 
 
def apply_confirmed_update_dynamodb(
    updated_item,
    table_name=work_items,  # Testing environment
    ):
    if not updated_item:
        return None
 
    project_name = updated_item.get("project_name")
    work_item_id = updated_item.get("work_item_id")
 
    # if not project_name:
    #     raise ValueError("updated_item must contain project_name")
 
    # if not work_item_id:
    #     raise ValueError("updated_item must contain work_item_id")
 
    table = dynamodb_resource.Table(table_name)
 
    pk = f"PROJECT#{project_name}"
    sk = f"TASK#{work_item_id}"
 
    update_values = {
        "evidence_id": updated_item.get("evidence_id"),
        "source_uri": updated_item.get("source_uri"),
        "source_type": updated_item.get("source_type"),
        "project_name": updated_item.get("project_name"),
        "task": updated_item.get("task"),
        "assignee": updated_item.get("assignee"),
        "due_date": updated_item.get("due_date"),
        "status": updated_item.get("status"),
        "task_evidence": updated_item.get("task_evidence"),
        "event_timestamp": updated_item.get("event_timestamp"),
        "summary": updated_item.get("summary"),
        "updated_at": utc_now_iso(),
    }
 
    update_values = {k: v for k, v in update_values.items() if v is not None}
 
    update_expression_parts = []
    expression_attribute_names = {}
    expression_attribute_values = {}
 
    for idx, (field, value) in enumerate(update_values.items()):
        name_key = f"#f{idx}"
        value_key = f":v{idx}"
        update_expression_parts.append(f"{name_key} = {value_key}")
        expression_attribute_names[name_key] = field
        expression_attribute_values[value_key] = value
 
    update_expression = "SET " + ", ".join(update_expression_parts)
 
    response = table.update_item(
        Key={
            "PK": pk,
            "SK": sk,
        },
        UpdateExpression=update_expression,
        ExpressionAttributeNames=expression_attribute_names,
        ExpressionAttributeValues=expression_attribute_values,
        ReturnValues="ALL_NEW",
    )
 
    return response.get("Attributes")


def process_user_upload_to_vector(
    file_path=None,
    bucket_name=None,
    s3_key=None
):
    s3 = boto3.client('s3', region_name="us-east-1")
    bucket_name = "ids-aini-prototype-ai-analytics"
    bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
    model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    
    def encode_image_to_base64(image_path: str) -> str:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    def call_claude(image_base64: str, media_type: str) -> str:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_base64,
                            },
                        },
                        {
                            "type": "text",
                            "text": "Extract all text from this image. Preserve formatting."
                        }
                    ],
                }
            ],
        }

        response = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps(body)
        )

        response_body = response["body"].read().decode("utf-8")
        parsed = json.loads(response_body)

        return "".join(
            block.get("text", "")
            for block in parsed.get("content", [])
            if block.get("type") == "text"
        ).strip()

    def extract_from_image(file_path: str) -> str:
        image_base64 = encode_image_to_base64(file_path)

        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(os.path.splitext(file_path)[1].lower(), "image/png")

        return call_claude(image_base64, media_type)

    def extract_from_image_bytes(file_bytes: bytes, ext: str) -> str:
        image_base64 = base64.b64encode(file_bytes).decode("utf-8")

        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(ext, "image/png")

        return call_claude(image_base64, media_type)

    def read_file_from_s3(bucket: str, key: str) -> bytes:
        s3 = boto3.client("s3", region_name="us-east-1")
        response = s3.get_object(Bucket=bucket, Key=key)
        return response["Body"].read()

    def extract_text_from_docx_bytes(file_bytes: bytes) -> str:
        doc = Document(BytesIO(file_bytes))
        return "\n".join([p.text for p in doc.paragraphs])

    def extract_text_from_docx_file(local_file_path: str) -> str:
        doc = Document(local_file_path)
        return "\n".join([p.text for p in doc.paragraphs])

    def process_file(local_file_path: str) -> str:
        extension = os.path.splitext(local_file_path)[1].lower()

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return extract_from_image(local_file_path)
        elif extension == ".docx":
            return extract_text_from_docx_file(local_file_path)
        else:
            raise ValueError(f"Unsupported file type: {extension}")

    def process_s3_file(bucket: str, key: str) -> str:
        extension = os.path.splitext(key)[1].lower()
        file_bytes = read_file_from_s3(bucket, key)

        if extension in [".png", ".jpg", ".jpeg", ".webp"]:
            return extract_from_image_bytes(file_bytes, extension)
        elif extension == ".docx":
            return extract_text_from_docx_bytes(file_bytes)
        else:
            raise ValueError(f"Unsupported file type: {extension}")

    if file_path:
        return process_file(file_path)

    if bucket_name and s3_key:
        return process_s3_file(bucket_name, s3_key)

    raise ValueError("Provide either file_path or both bucket_name and s3_key")



# NODES
def decision_node(state: GraphState) -> Command:
    user_text="\n".join(state["chat_history"])

    parser_prompt = f"""
Parse the following user input into structured JSON.

Return ONLY JSON. No explanation. No markdown.

IMPORTANT RULES:
- "retrieval_query" MUST always be populated with a rephrased search query derived from the user input (even if other fields are filled)
- "intent" should be "retrieve" if the user is asking a question, requesting information, OR simply mentions a project/topic name without any action verb (e.g. "project apollo" = retrieve intent)
- "intent" should be "create" ONLY if the user explicitly says to create/add a new task
- "intent" should be "update" if the user explicitly says to update/change/modify something, OR uses natural completion phrases such as "mark it done", "that's complete", "it's been completed", "task is done", "mark as in progress", "set status to", "move to done", "it's finished", "close this task", "this is now complete"
- When "update" intent is detected and user says task is done/complete/finished, set "status" to "done". When user says in progress/started/working on it, set "status" to "in progress".
- "project_name" should only be set if the user explicitly mentions a known project name
- If the user input is just a name or topic, treat it as a retrieve request about that topic

User input:
{user_text}

Return JSON with exactly these fields:
{{
  "intent": "retrieve|update|delete|create|unknown",
  "project_id": null,
  "project_name": null,
  "work_item_id": null,
  "title": null,
  "description": null,
  "reporter": null,
  "assignee": null,
  "status": null,
  "priority": null,
  "due_date": null,
  "blocker": null,
  "dependency": null,
  "issue": null,
  "summary": null,
  "retrieval_query": null,
  "clarification_needed": false,
  "clarification_question": null
}}
"""
    cleaned_response = clean_llm_output(llm.invoke(parser_prompt).content)
    try:
        parsed_response_dict = json.loads(cleaned_response)
        parsed_response_dict["chat_history"] = state["chat_history"]
        intent = parsed_response_dict["intent"]
        print(f"[DEBUG] Parsed intent: {intent}, project_name: {parsed_response_dict.get('project_name')}, retrieval_query: {parsed_response_dict.get('retrieval_query')}")
        
        # context = retrieve function()
        context=handle_retrieve_intent(
            parsed_response_dict,
            table_name=work_items,
        )

        # Sanitize context: convert Decimal/NaN values so LangGraph state serialization doesn't crash
        import decimal as _decimal
        def _sanitize(obj):
            if isinstance(obj, dict):
                return {k: _sanitize(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [_sanitize(v) for v in obj]
            elif isinstance(obj, _decimal.Decimal):
                return float(obj)
            elif isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
                return None
            return obj
        context = _sanitize(context)
 
        # retrieval_llm_result=LLM call(user query, intent, context)
        # if intent.lower() in ["update","create"]:
        #     clarification_response= llm.invoke(f"""Is more clarification needed from the user to answer the user's query
        #     or is the context provided enough to answer, also take into consideration the user's intent, Answer only in YES or NO.\n
        #     User Query: {user_text}\n Context: {context}\n User intent: {intent}\n
        #     Answer only in YES or NO. DO NOT give any explaination""")
                                               
        #     if "YES" in clarification_response:
        #         clarification_needed=True
        #     else:
        #         clarification_needed=False
        
                                           
        # ✅ Routing logic

        if state.get("clarification_received"):
            # clarification_result = LLM call(chathistory, clarification text received, retrieval_llm_result)
            clarification_response= llm.invoke(f"""Is more clarification needed from the user to answer the user's query
        or is the context provided enough to answer, also take into consideration the user's intent, Answer only in YES or NO.\n
        User Query: {user_text}\n Context: {context}\n User intent: {intent}\n
        Answer only in YES or NO. DO NOT give any explaination""").content
            if "YES" in clarification_response:
                clarification_needed=True
            else:
                clarification_needed=False
            if clarification_needed:
                return Command(
                    update={
                        **parsed_response_dict,
                        "chathistory" :user_text,
                        "clarification_needed": True
                    },
                    goto="clarify"
                )
            else:
                if intent == "create":
                    return Command(update={**parsed_response_dict,"clarification_needed":False,"clarification_received":True}, goto="create")
                else:
                    return Command(update={**parsed_response_dict,"clarification_needed":False,"clarification_received":True}, goto="update")
        else: 
            if intent == "retrieve" or intent == "unknown":
                return Command(
                    update={
                        **parsed_response_dict,
                        "clarification_needed": False,
                        "retrieval_results" : context
                    },
                    goto="inference"
                )
        
            # if clarification_needed:
            #    return Command(
            #         update={
            #             **parsed_response_dict,
            #             "clarification_needed": True
            #         },
            #         goto="clarify"
            #     )
            else:
               if intent == "create":
                   return Command(update={**parsed_response_dict}, goto="create")
               else:
                   return Command(update={**parsed_response_dict}, goto="update")

    except Exception as e:
        print(f"Error in decision_node: {e}")
        # Fallback: treat as retrieve with the raw user text as context
        fallback_context = {
            "mode": "retrieve",
            "retrieved_evidence": [],
            "work_item_matches": [],
            "answer": "No relevant information found."
        }
        return Command(
            update={
                "clarification_needed": False,
                "retrieval_results": fallback_context
            },
            goto="inference"
        )
        
    

def inference_node(state: GraphState) -> Command:
    context = state["retrieval_results"]

    # Trim context to avoid LLM context window overflow
    # Cap each evidence doc and each work item's task_evidence to keep total payload small
    trimmed_context = {}
    if isinstance(context, dict):
        evidence_list = context.get("retrieved_evidence", [])
        trimmed_evidence = []
        for ev in evidence_list[:5]:  # max 5 evidence docs
            trimmed_ev = dict(ev)
            if trimmed_ev.get("document"):
                trimmed_ev["document"] = trimmed_ev["document"][:800]
            if trimmed_ev.get("summary"):
                trimmed_ev["summary"] = trimmed_ev["summary"][:300]
            trimmed_evidence.append(trimmed_ev)

        work_items_list = context.get("work_item_matches", [])
        trimmed_work_items = []
        for wi in work_items_list[:10]:  # max 10 work items
            trimmed_wi = dict(wi)
            if trimmed_wi.get("task_evidence"):
                trimmed_wi["task_evidence"] = trimmed_wi["task_evidence"][:600]
            if trimmed_wi.get("summary"):
                trimmed_wi["summary"] = trimmed_wi["summary"][:300]
            trimmed_work_items.append(trimmed_wi)

        trimmed_context = {
            **{k: v for k, v in context.items() if k not in ("retrieved_evidence", "work_item_matches")},
            "retrieved_evidence": trimmed_evidence,
            "work_item_matches": trimmed_work_items,
        }
    else:
        trimmed_context = context

    user_query = "\n".join(state['chat_history'])
    try:
        import decimal
        def _safe_serial(o):
            if isinstance(o, decimal.Decimal):
                return float(o)
            if isinstance(o, float) and (math.isnan(o) or math.isinf(o)):
                return None
            return str(o)
        context_str = json.dumps(trimmed_context, default=_safe_serial) if isinstance(trimmed_context, dict) else str(trimmed_context)
    except Exception as e:
        print(f"[WARN] context serialization failed: {e}")
        context_str = str(trimmed_context)

    prompt = f"""
You are a project assistant. Answer the user query using the context below.

The context has two sections:
- "retrieved_evidence": source documents (check clean_text, action_items, decisions fields)
- "work_item_matches": task records from the database (check task, summary, task_evidence, assignee, status, due_date fields)

IMPORTANT:
- The "task_evidence" field inside each work_item contains the most relevant raw content — READ IT carefully.
- If work_item_matches has items, use them to answer even if retrieved_evidence is empty.
- NEVER say "no information found" if work_item_matches contains any items — extract what you can from task, summary, and task_evidence fields.
- Be SHORT and focused — 3 to 5 bullet points maximum.
- No filler phrases like "let me know", "hope this helps", "based on the context".
- No suggestions unless the user explicitly asks.
- If a table has more than 5 rows, show only the top 5 most relevant and add "*(showing top 5)*".

FORMAT:
## [Topic Name]
One sentence summary.

### Key Details
- **Label:** value

### Assignments ← only if relevant
| Name | Function | Task | Due Date | Status |
|------|----------|------|----------|--------|
| ... | ... | ... | ... | ... |
*(max 5 rows)*

For the Function column: use the ipst_function field from work_item_matches if available, otherwise leave as "—".

User Query: {user_query}
Context: {context_str}
"""

    try:
        response = llm.invoke(prompt)
        return Command(
            update={"final_response": response.content},
            goto=END
        )
    except Exception as e:
        print(f"[ERROR] inference_node LLM failed: {e}")
        import traceback; traceback.print_exc()
        return Command(
            update={"final_response": "I encountered an error processing your request. Please try rephrasing your question."},
            goto=END
        )


def create_node(state: GraphState) -> Command:
    user_text="\n".join(state['chat_history'])
    clarification_received=state["clarification_received"]
    clarification_needed=state["clarification_needed"]
    result_payload=state["result_payload"]
    # first invocation
    if not clarification_received or (clarification_received and clarification_needed):
        result = handle_create_intent_with_llm(
                state=state,
                table_name=work_items
                )
        return Command(
        update={"final_response": result},
        goto="clarify"
        )

    # second invocation - UPDATE existing item instead of creating new if match found
    else :
        proposed = result_payload["proposed_item"]
        existing_item = result_payload.get("existing_item")
        is_update = result_payload.get("is_update_of_existing", False)
        
        # Get PK/SK from existing item or proposed item
        work_items_table = dynamodb_resource.Table(work_items)
        
        if is_update and existing_item:
            # UPDATE existing item instead of creating new
            pk = existing_item.get("PK") or f"PROJECT#{proposed.get('project_name') or 'Unassigned'}"
            sk = existing_item.get("SK") or f"TASK#{existing_item.get('work_item_id') or proposed.get('work_item_id')}"
            
            # Start with existing data, then merge changes
            updated_item = dict(existing_item)
            
            # Only update fields that are explicitly provided
            if proposed.get("task"):
                updated_item["task"] = proposed["task"]
            if proposed.get("assignee"):
                updated_item["assignee"] = proposed["assignee"].strip() if isinstance(proposed["assignee"], str) else proposed["assignee"]
                updated_item["assigned_to"] = updated_item["assignee"]  # Keep both fields in sync
            if proposed.get("due_date"):
                updated_item["due_date"] = proposed["due_date"]
            if proposed.get("status"):
                updated_item["status"] = proposed["status"]
            if proposed.get("summary"):
                updated_item["summary"] = proposed["summary"]
            if proposed.get("project_name"):
                updated_item["project_name"] = proposed["project_name"]
                # Update PK if project changed
                new_pk = f"PROJECT#{proposed['project_name']}"
                if new_pk != pk:
                    updated_item["PK"] = new_pk
            
            updated_item["source_type"] = "user_chat"
            updated_item["source_uri"] = "chat"
            updated_item["updated_at"] = utc_now_iso()
            
            # Update IPST function based on assignee
            _assignee = updated_item.get("assigned_to") or updated_item.get("assignee", "")
            updated_item["ipst_function"] = IPST_FUNCTION_MAP.get(
                _assignee.strip().title() if isinstance(_assignee, str) else "",
                IPST_FUNCTION_MAP.get(_assignee.strip() if isinstance(_assignee, str) else "", updated_item.get("ipst_function", ""))
            )
            
            # Update the WorkItems table
            work_items_table.put_item(Item=updated_item)
            
            # Delete old item if PK changed (project changed)
            if updated_item.get("PK") != pk:
                try:
                    work_items_table.delete_item(Key={"PK": pk, "SK": sk})
                except Exception:
                    pass
            
            print(f"[CREATE->UPDATE] Updated existing task: {updated_item.get('task')} in project {updated_item.get('project_name')}")
            result = f"✅ Updated existing task **{updated_item.get('task')}**. The Team Board will reflect this shortly."
        else:
            # True CREATE - no existing match found
            create_doc = confirmed_created_item_to_work_evidence_record(user_text=user_text,
                intent_result=result_payload["intent_result"],
                adjudication=result_payload["adjudication"],
                proposed_item=proposed,
                workspace_id="default-workspace",
                project_id="",
                source_uri="user_chat",
                embedding_fn=vectorize_with_titan)
            response = index_document(doc=create_doc)
            dynamo_response = apply_confirmed_update_dynamodb(proposed)
            print(f"Result of Updating the Opensearch index: {response['status_code']}\n")
            print(f"Result of Updating the Dynamo Db: {dynamo_response}\n")
            
            # Create new item in WorkItems table (single source of truth)
            _assignee = proposed.get("assignee") or "Unassigned"
            _assignee_clean = _assignee.strip() if isinstance(_assignee, str) else "Unassigned"
            work_items_table.put_item(Item={
                "PK": f"PROJECT#{proposed.get('project_name') or 'Unassigned'}",
                "SK": f"TASK#{proposed.get('work_item_id') or uuid.uuid4().hex[:8]}",
                "work_item_id": proposed.get("work_item_id") or "",
                "project_name": proposed.get("project_name") or "Unassigned",
                "task": proposed.get("task") or "",
                "assignee": _assignee_clean,
                "assigned_to": _assignee_clean,  # Keep both fields in sync for UI
                "due_date": proposed.get("due_date") or "",
                "status": proposed.get("status") or "pending",
                "summary": proposed.get("summary") or proposed.get("task") or "",
                "source_type": "user_chat",
                "source_uri": "chat",
                "event_timestamp": utc_now_iso(),
                "updated_at": utc_now_iso(),
                "ipst_function": IPST_FUNCTION_MAP.get(
                    _assignee_clean.title(),
                    IPST_FUNCTION_MAP.get(_assignee_clean, "")
                ),
            })
            print(f"[CREATE] Work item created: {proposed.get('task')} in project {proposed.get('project_name')}")
            result = "Successfully Created!"
        
        return Command(
            update={"final_response": result},
            goto=END
        )


def update_node(state: GraphState) -> Command:
    user_text="\n".join(state['chat_history'])
    clarification_received=state["clarification_received"]
    clarification_needed=state["clarification_needed"]
    result_payload=state["result_payload"]

    # FIRST CALL (no clarification yet): run adjudication, then ask clarify node
    # CONFIRMATION CALL (clarification_received=True, clarification_needed=False): apply the update
    if not (clarification_received and not clarification_needed):
        # First call — run adjudication against WorkItems
        result = handle_update_intent_with_llm(
                state=state,
                table_name=work_items
            )

        # ── FALLBACK: if WorkItems search found nothing, scan WorkItems for fuzzy match ──
        if result.get("updated_item") is None:
            try:
                _dyn = boto3.resource("dynamodb", region_name="us-east-1")
                _work_items_table = _dyn.Table(work_items)
                _scan = _work_items_table.scan()
                _items = _scan.get("Items", [])
                while "LastEvaluatedKey" in _scan:
                    _scan = _work_items_table.scan(ExclusiveStartKey=_scan["LastEvaluatedKey"])
                    _items.extend(_scan.get("Items", []))
                # Find best matching card by task name and/or assignee
                title_hint = (state.get("title") or state.get("summary") or "").lower()
                assignee_hint = (state.get("assignee") or "").lower()
                new_status_hint = (state.get("status") or "").lower().strip()
                if new_status_hint in ("to do", "todo", "to-do"): new_status_hint = "pending"
                elif new_status_hint in ("in progress", "in-progress", "inprogress", "active"): new_status_hint = "in progress"
                elif new_status_hint in ("done", "completed", "complete", "finished"): new_status_hint = "done"
                # Extract from chat_history if not parsed into state fields
                import re as _re
                if not title_hint:
                    # Try quoted title first — straight single/double quotes AND curly quotes
                    m = _re.search(r"[\"'\u201c\u2018\u2019\u201d]([^\"'\u201c\u2018\u2019\u201d]{5,})[\"'\u201c\u2018\u2019\u201d]", user_text, _re.I)
                    if m:
                        title_hint = m.group(1).strip().lower()
                    else:
                        # Try "move/update/change <title> to <status>" — grab text between verb and "to <status>"
                        m = _re.search(r'(?:move|update|change|set|mark)\s+(.+?)\s+to\s+(?:to[\s\-]do|todo|in[\s\-]progress|done|at[\s\-]risk|blocked|pending)', user_text, _re.I)
                        if m:
                            title_hint = m.group(1).strip().lower()
                        else:
                            # Try "task: <title>" pattern
                            m = _re.search(r'task[:\s]+([^,\.\n]+)', user_text, _re.I)
                            if m: title_hint = m.group(1).strip().lower()
                    # Strip trailing status phrases from title (e.g. "... to To Do")
                    title_hint = _re.sub(r'\s+to\s+(to[\s\-]do|todo|in[\s\-]progress|done|at[\s\-]risk|blocked|pending)\s*$', '', title_hint, flags=_re.I).strip()
                if not assignee_hint:
                    m2 = _re.search(r'(?:assign(?:ed)?\s+to|assignee)[:\s]*([^,\-\u2014\n]+)', user_text, _re.I)
                    if m2: assignee_hint = m2.group(1).strip().lower()
                if not new_status_hint:
                    _ut = user_text.lower()
                    # Try to extract the TARGET status from "move/change/set ... to <status>" or "to <status>" patterns
                    # This avoids picking up the SOURCE status in "move from X to Y"
                    _target_match = _re.search(
                        r'(?:move|change|set|update|mark).*?\bto\b\s+(to[\s\-]do|todo|in[\s\-]progress|done|complet\w*|at[\s\-]risk|blocked|pending)',
                        _ut, _re.I
                    )
                    if not _target_match:
                        # fallback: look for "to <status>" anywhere
                        _target_match = _re.search(
                            r'\bto\s+(to[\s\-]do|todo|in[\s\-]progress|done|complet\w*|at[\s\-]risk|blocked|pending)\b',
                            _ut, _re.I
                        )
                    if _target_match:
                        _ts = _target_match.group(1).strip()
                        if "to" in _ts and ("do" in _ts or _ts == "todo"): new_status_hint = "pending"
                        elif "in" in _ts and "progress" in _ts: new_status_hint = "in progress"
                        elif "done" in _ts or "complet" in _ts: new_status_hint = "done"
                        elif "at" in _ts and "risk" in _ts: new_status_hint = "At Risk"
                        elif "blocked" in _ts: new_status_hint = "blocked"
                        elif "pending" in _ts: new_status_hint = "pending"
                    else:
                        # Last resort: simple keyword scan (only when no "from...to" ambiguity)
                        if "to do" in _ut or "todo" in _ut: new_status_hint = "pending"
                        elif "in progress" in _ut: new_status_hint = "in progress"
                        elif "done" in _ut or "complet" in _ut: new_status_hint = "done"
                        elif "at risk" in _ut: new_status_hint = "At Risk"
                        elif "blocked" in _ut: new_status_hint = "blocked"
                # Extract project name
                new_project_hint = ""
                mp = _re.search(r'(?:project|proj)[:\s]+(?:to\s+)?([A-Za-z0-9 ]+?)(?:\s+and|\s+due|\s+assign|\s+move|$)', user_text, _re.I)
                if not mp:
                    mp = _re.search(r'(?:assign|add|put|move)\s+(?:it\s+)?(?:to\s+)?(?:the\s+)?(?:project\s+)?([A-Za-z0-9 ]+?)\s+project', user_text, _re.I)
                if mp: 
                    new_project_hint = mp.group(1).strip()
                    # Ignore placeholder dashes
                    if new_project_hint in ("—", "-", "–", "null", "none", ""): new_project_hint = ""
                # Extract due date — supports YYYY-MM-DD and natural language (May 1, 1st May, etc.)
                new_due_hint = ""
                md = _re.search(r'due\s*(?:date)?[:\s]*(\d{4}-\d{2}-\d{2})', user_text, _re.I)
                if md:
                    new_due_hint = md.group(1).strip()
                else:
                    # Natural language date: "May 1", "1st May", "May 1st", "1 May 2026" etc.
                    _MONTHS = {"jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,"jul":7,"aug":8,"sep":9,"oct":10,"nov":11,"dec":12,
                               "january":1,"february":2,"march":3,"april":4,"june":6,"july":7,"august":8,"september":9,"october":10,"november":11,"december":12}
                    mn = _re.search(
                        r'(?:due\s*(?:date)?[:\s]*)?(\d{1,2})(?:st|nd|rd|th)?\s+(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s*(\d{4})?'
                        r'|(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+(\d{1,2})(?:st|nd|rd|th)?\s*,?\s*(\d{4})?',
                        user_text, _re.I
                    )
                    if mn:
                        if mn.group(1):  # "1st May 2026"
                            day, mon_str, yr = int(mn.group(1)), mn.group(2)[:3].lower(), mn.group(3)
                        else:  # "May 1 2026"
                            mon_str, day, yr = mn.group(4)[:3].lower(), int(mn.group(5)), mn.group(6)
                        month = _MONTHS.get(mon_str, 0)
                        year = int(yr) if yr else 2026
                        if month:
                            new_due_hint = f"{year}-{month:02d}-{day:02d}"

                best_match = None
                best_score = 0
                for item in _items:
                    score = 0
                    task_str = (item.get("task") or "").lower()
                    assigned_str = (item.get("assigned_to") or item.get("assignee") or "").lower()
                    if title_hint and title_hint in task_str: score += 100  # exact substring — always wins
                    elif title_hint:
                        # partial word overlap
                        words = [w for w in title_hint.split() if len(w) > 3]
                        score += sum(1 for w in words if w in task_str)
                    if assignee_hint:
                        for a in assignee_hint.split(","):
                            if a.strip() and a.strip() in assigned_str: score += 2
                    if score > best_score:
                        best_score = score
                        best_match = item

                if best_match and best_score >= 1:
                    print(f"[UPDATE] Found task in WorkItems: {best_match.get('task')} (score={best_score})")
                    updated_item = dict(best_match)
                    # Apply all extracted fields
                    if new_status_hint:
                        updated_item["status"] = new_status_hint
                    if assignee_hint:
                        # Title-case the assignee name
                        updated_item["assigned_to"] = assignee_hint.title()
                        updated_item["assignee"] = assignee_hint.title()
                    if new_project_hint:
                        updated_item["project_name"] = new_project_hint
                        updated_item["PK"] = f"PROJECT#{new_project_hint}"
                    if new_due_hint:
                        updated_item["due_date"] = new_due_hint
                    updated_item["assignee"] = updated_item.get("assigned_to") or updated_item.get("assignee") or best_match.get("assigned_to") or best_match.get("assignee", "Unassigned")
                    result["previous_item"] = dict(best_match)
                    result["updated_item"] = updated_item
                    result["adjudication"] = result.get("adjudication") or {}
                    changes = []
                    if new_status_hint: changes.append(f"status → {new_status_hint}")
                    if assignee_hint: changes.append(f"assigned to → {assignee_hint.title()}")
                    if new_project_hint: changes.append(f"project → {new_project_hint}")
                    if new_due_hint: changes.append(f"due date → {new_due_hint}")
                    result["adjudication"]["next_action"] = (
                        f"Found task \"{best_match.get('task')}\" and will update: {', '.join(changes) or 'status'}."
                    )
                    result["workitems_only"] = True
            except Exception as _e:
                print(f"[UPDATE] WorkItems fallback failed: {_e}")

        # Sanitize Decimal/NaN before storing in LangGraph state
        import decimal as _dec
        def _san(o):
            if isinstance(o, dict): return {k: _san(v) for k, v in o.items()}
            if isinstance(o, list): return [_san(v) for v in o]
            if isinstance(o, _dec.Decimal): return float(o)
            if isinstance(o, float) and (math.isnan(o) or math.isinf(o)): return None
            return o
        result = _san(result)
        return Command(
        update={"final_response": result},
        goto="clarify"
        )

    else:  # clarification_received=True AND clarification_needed=False → apply the update
        updated = result_payload.get("updated_item") if result_payload else None
        previous = result_payload.get("previous_item") if result_payload else None

        # Guard: if task was never found, return a friendly message instead of crashing
        if not updated:
            task_hint = ""
            if result_payload and result_payload.get("intent_result"):
                task_hint = result_payload["intent_result"].get("title") or result_payload["intent_result"].get("summary") or ""
            msg = f"I couldn't find a matching task{' for \"' + task_hint + '\"' if task_hint else ''} in the system. Please check the task name or assignee and try again."
            return Command(update={"final_response": msg}, goto=END)

        workitems_only = result_payload.get("workitems_only", False) if result_payload else False

        # Update WorkItems table (single source of truth)
        work_items_table = dynamodb_resource.Table(work_items)
        work_item_id = updated.get("work_item_id") or ""
        project_name = updated.get("project_name") or "Unassigned"
        new_status = updated.get("status") or "pending"
        
        # Normalize status at write time — ensure clean values stored in DynamoDB
        _ns = new_status.lower().strip()
        if _ns in ("to do", "todo", "to-do"): new_status = "pending"
        elif _ns in ("in progress", "in-progress", "inprogress", "active"): new_status = "in progress"
        elif _ns in ("done", "completed", "complete", "finished"): new_status = "done"
        
        if workitems_only:
            # Use the original PK/SK from the matched WorkItems item
            orig_pk = (result_payload.get("previous_item") or {}).get("PK") or f"PROJECT#{(result_payload.get('previous_item') or {}).get('project_name','Unassigned')}"
            pk = updated.get("PK") or f"PROJECT#{project_name}"
            sk = updated.get("SK") or (f"TASK#{work_item_id}" if work_item_id else None)
            if pk and sk:
                work_item = dict(updated)
                work_item["status"] = new_status
                # Only update assigned_to if explicitly provided (non-empty), preserve existing otherwise
                new_assignee = updated.get("assigned_to") or updated.get("assignee")
                if new_assignee and new_assignee.strip() and new_assignee.strip() != "Unassigned":
                    work_item["assigned_to"] = new_assignee.strip()
                    work_item["assignee"] = new_assignee.strip()
                # If no new assignee specified, keep whatever is in updated (from previous_item)
                elif not work_item.get("assigned_to"):
                    work_item["assigned_to"] = (result_payload.get("previous_item") or {}).get("assigned_to") or (result_payload.get("previous_item") or {}).get("assignee", "Unassigned")
                    work_item["assignee"] = work_item["assigned_to"]
                
                # Update ipst_function based on assignee
                _assignee = work_item.get("assigned_to") or work_item.get("assignee", "")
                work_item["ipst_function"] = IPST_FUNCTION_MAP.get(
                    _assignee.strip().title() if isinstance(_assignee, str) else "",
                    IPST_FUNCTION_MAP.get(_assignee.strip() if isinstance(_assignee, str) else "", work_item.get("ipst_function", ""))
                )
                work_item["updated_at"] = utc_now_iso()
                
                work_items_table.put_item(Item=work_item)
                print(f"[UPDATE] WorkItems updated PK={pk} SK={sk} status={new_status}")
                # If project changed, delete the old PK item to avoid stale card on board
                if orig_pk and orig_pk != pk:
                    try:
                        work_items_table.delete_item(Key={"PK": orig_pk, "SK": sk})
                        print(f"[UPDATE] Deleted old WorkItems item PK={orig_pk} SK={sk}")
                    except Exception as _de:
                        print(f"[UPDATE] Could not delete old item: {_de}")
            else:
                print(f"[UPDATE] workitems_only but no PK/SK on updated_item — WorkItems not updated")
        elif work_item_id:
            # Fetch existing WorkItems item first using PREVIOUS item's PK/SK to find the correct record
            existing_work_item = {}
            # First try to get from previous_item's location (most accurate)
            prev_pk = (previous or {}).get("PK") or f"PROJECT#{(previous or {}).get('project_name', project_name)}"
            prev_sk = (previous or {}).get("SK") or f"TASK#{(previous or {}).get('work_item_id', work_item_id)}"
            try:
                existing_resp = work_items_table.get_item(Key={"PK": prev_pk, "SK": prev_sk})
                existing_work_item = existing_resp.get("Item", {})
            except Exception as _ge:
                print(f"[UPDATE] Could not fetch existing WorkItems item from prev PK/SK: {_ge}")
            
            # If not found by previous PK/SK, try with updated's project_name
            if not existing_work_item:
                try:
                    existing_resp = work_items_table.get_item(Key={
                        "PK": f"PROJECT#{project_name}",
                        "SK": f"TASK#{work_item_id}"
                    })
                    existing_work_item = existing_resp.get("Item", {})
                except Exception:
                    pass
            
            # If still not found, scan for task by name (last resort)
            if not existing_work_item:
                task_hint = (updated.get("task") or "").lower().strip()
                if task_hint:
                    try:
                        _scan = work_items_table.scan()
                        _all = _scan.get("Items", [])
                        for item in _all:
                            if task_hint in (item.get("task") or "").lower():
                                existing_work_item = item
                                prev_pk = item.get("PK")
                                prev_sk = item.get("SK")
                                break
                    except Exception:
                        pass
            
            # Start with existing item data, then merge only changed fields
            work_item = dict(existing_work_item) if existing_work_item else {}
            
            # Determine the target PK - use existing if not changing project, else new project
            target_pk = f"PROJECT#{project_name}"
            target_sk = work_item.get("SK") or f"TASK#{work_item_id}"
            
            # Update core fields
            work_item["PK"] = target_pk
            work_item["SK"] = target_sk
            work_item["work_item_id"] = work_item_id
            work_item["project_name"] = project_name
            work_item["status"] = new_status
            work_item["source_type"] = "user_chat"
            work_item["source_uri"] = "chat"
            work_item["updated_at"] = utc_now_iso()
            
            # Only update task name if explicitly provided in updated dict
            if updated.get("task"):
                work_item["task"] = updated["task"]
            elif not work_item.get("task"):
                work_item["task"] = ""
            
            # Only update assigned_to if explicitly provided (non-empty)
            new_assignee = updated.get("assigned_to") or updated.get("assignee")
            if new_assignee and new_assignee.strip() and new_assignee.strip() != "Unassigned":
                work_item["assigned_to"] = new_assignee.strip()
                work_item["assignee"] = new_assignee.strip()
            elif not work_item.get("assigned_to"):
                work_item["assigned_to"] = "Unassigned"
                work_item["assignee"] = "Unassigned"
            
            # Only update due_date if explicitly provided (non-empty)
            if updated.get("due_date") and updated["due_date"].strip():
                work_item["due_date"] = updated["due_date"]
            # else keep existing due_date if present
            
            # Only update summary if explicitly provided
            if updated.get("summary"):
                work_item["summary"] = updated["summary"]
            
            # Only update priority if explicitly provided
            if updated.get("priority"):
                work_item["priority"] = updated["priority"]
            
            # Update ipst_function based on current assigned_to
            _current_assignee = work_item.get("assigned_to") or work_item.get("assignee", "")
            work_item["ipst_function"] = IPST_FUNCTION_MAP.get(
                _current_assignee.strip().title(),
                IPST_FUNCTION_MAP.get(_current_assignee.strip(), work_item.get("ipst_function", ""))
            )
            
            work_items_table.put_item(Item=work_item)
            print(f"[UPDATE] WorkItems {work_item_id} updated to status={new_status}")
            
            # Delete old item if PK changed (project changed) to avoid duplicate cards
            if existing_work_item and prev_pk and prev_pk != target_pk:
                try:
                    work_items_table.delete_item(Key={"PK": prev_pk, "SK": prev_sk})
                    print(f"[UPDATE] Deleted old WorkItems item at PK={prev_pk} SK={prev_sk}")
                except Exception as _de:
                    print(f"[UPDATE] Could not delete old item: {_de}")
            
            # Also update OpenSearch if not workitems_only
            if not workitems_only:
                update_doc = confirmed_updated_item_to_work_evidence_record(user_text=user_text,
                    intent_result=result_payload["intent_result"],
                    adjudication=result_payload["adjudication"],
                    previous_item=previous,
                    updated_item=updated,
                    user_confirmation=True,
                    workspace_id="default-workspace",
                    project_id="",
                    source_uri="user_chat",
                    embedding_fn=vectorize_with_titan
                    )
                response = index_document(doc=update_doc)
                print(f"Result of Updating the Opensearch index: {response['status_code']}\n{response['text']}")
        else:
            # ── FALLBACK: no work_item_id but we have the task name — scan WorkItems and update matching row ──
            task_name_hint = (updated.get("task") or "").lower().strip()
            if task_name_hint:
                try:
                    _scan = work_items_table.scan()
                    _all = _scan.get("Items", [])
                    while "LastEvaluatedKey" in _scan:
                        _scan = work_items_table.scan(ExclusiveStartKey=_scan["LastEvaluatedKey"])
                        _all.extend(_scan.get("Items", []))
                    _match = next((i for i in _all if task_name_hint in (i.get("task") or "").lower()), None)
                    if _match:
                        work_item = dict(_match)
                        work_item["status"] = new_status
                        work_item["project_name"] = project_name
                        work_item["PK"] = f"PROJECT#{project_name}"
                        # Only update assigned_to if explicitly provided (non-empty), else keep existing
                        new_assignee = updated.get("assigned_to") or updated.get("assignee")
                        if new_assignee and new_assignee.strip() and new_assignee.strip() != "Unassigned":
                            work_item["assigned_to"] = new_assignee.strip()
                            work_item["assignee"] = new_assignee.strip()
                        # Keep existing assigned_to if present, don't overwrite with Unassigned
                        
                        # Only update due_date if explicitly provided
                        if updated.get("due_date") and updated["due_date"].strip():
                            work_item["due_date"] = updated["due_date"]
                        
                        # Preserve priority if it exists and only update if explicitly provided
                        if updated.get("priority"):
                            work_item["priority"] = updated["priority"]
                        
                        # Preserve summary if it exists and only update if explicitly provided
                        if updated.get("summary"):
                            work_item["summary"] = updated["summary"]
                        
                        work_item["updated_at"] = utc_now_iso()
                        
                        # Write to new PK
                        work_items_table.put_item(Item=work_item)
                        # Delete old item if PK changed
                        if _match.get("PK") and _match["PK"] != work_item["PK"]:
                            work_items_table.delete_item(Key={"PK": _match["PK"], "SK": _match["SK"]})
                        print(f"[UPDATE] WorkItems fallback updated task '{_match.get('task')}' PK={work_item['PK']} SK={work_item['SK']}")
                    else:
                        print(f"[UPDATE] WorkItems fallback — no match found for '{task_name_hint}'")
                except Exception as _fe:
                    print(f"[UPDATE] WorkItems fallback failed: {_fe}")
            else:
                print(f"[UPDATE] No work_item_id and no task name — WorkItems not updated")

        task_name = updated.get("task", "the task")
        changes_made = []
        if updated.get("status"): changes_made.append(f"status → **{updated['status']}**")
        if updated.get("assigned_to") and updated["assigned_to"] != "Unassigned": changes_made.append(f"assigned to → **{updated['assigned_to']}**")
        if updated.get("project_name"): changes_made.append(f"project → **{updated['project_name']}**")
        if updated.get("due_date"): changes_made.append(f"due date → **{updated['due_date']}**")
        result = f"✅ **{task_name}** has been updated: {', '.join(changes_made)}. The Team Board will reflect this shortly."
        return Command(update={"final_response": result}, goto=END)


def clarify_node(state: GraphState) -> Command:
    user_text = "\n".join(state.get("chat_history", []))
    intent = state.get("intent", "unknown")

    # Extract context from final_response (set by update_node / create_node)
    fr = state.get("final_response") or {}
    adjudication = {}
    updated_item = None
    previous_item = None
    if isinstance(fr, dict):
        adjudication   = fr.get("adjudication") or {}
        updated_item   = fr.get("updated_item")
        previous_item  = fr.get("previous_item")

    # If task was not found at all, tell the user directly — no point asking for confirmation
    if updated_item is None and isinstance(fr, dict) and fr.get("mode") == "update_review":
        title_hint = ""
        ir = fr.get("intent_result") or {}
        title_hint = ir.get("title") or ir.get("summary") or ir.get("assignee") or ""
        msg = (f"I couldn't find a task matching \"{title_hint}\" in the system. "
               f"Please double-check the task name or assignee and try again.") if title_hint else \
              "I couldn't find a matching task. Please provide more details about the task name, assignee or project."
        return Command(
            update={"clarification_question": msg, "clarification_received": False, "clarification_needed": False},
            goto=END
        )

    # Build confirmation message from adjudication
    next_action = adjudication.get("next_action", "") if adjudication else ""
    task_name = (updated_item or {}).get("task", "") or ""
    assignee  = (updated_item or {}).get("assignee", "") or ""
    new_status = (updated_item or {}).get("status", "") or ""
    project   = (updated_item or {}).get("project_name", "") or ""

    if task_name and new_status:
        question = (f"I found the task **\"{task_name}\"**"
                    + (f" assigned to **{assignee}**" if assignee else "")
                    + (f" in **{project}**" if project else "")
                    + f" and will update its status to **{new_status}**."
                    + " Shall I apply this change? (yes / no)")
    elif next_action and not isinstance(next_action, dict):
        question = str(next_action) + " Shall I apply this change? (yes / no)"
    else:
        # Fallback — use LLM for a specific clarifying question
        try:
            clarify_prompt = f"""You are a helpful assistant. The user sent:
\"{user_text}\"
Ask ONE short clarifying question to identify which task they want to update."""
            question = llm.invoke(clarify_prompt).content.strip()
        except Exception:
            question = "Could you clarify which task you'd like to update? Please provide the task name and assignee."

    return Command(
        update={"clarification_question": question, "clarification_received": False, "clarification_needed": True},
        goto=END
    )

    if understood_parts:
        understood_str = ", ".join(understood_parts)
        question = (
            f"I understood {understood_str} — but I need a bit more detail to proceed. "
            f"Could you clarify what exactly you'd like me to do?"
        )
    else:
        # Fallback — use LLM to generate a specific question based on the user's message
        try:
            clarify_prompt = f"""You are a helpful assistant. The user sent this message:
"{user_text}"

You need more information to fulfil the request. Ask ONE short, specific clarifying question.
Do not repeat the user's message. Do not explain yourself. Just ask the question."""
            question = llm.invoke(clarify_prompt).content.strip()
        except Exception:
            question = "Could you clarify your request? For example, which task or project are you referring to?"

    return Command(
        update={"clarification_question": question, "clarification_received": False, "clarification_needed": True},
        goto=END
    )


# In[75]:


def build_graph():
    builder = StateGraph(GraphState)
    
    # Add nodes
    builder.add_node("decision", decision_node)
    builder.add_node("inference", inference_node)
    builder.add_node("create", create_node)
    builder.add_node("update", update_node)
    builder.add_node("clarify", clarify_node)
    # # add edges
    # builder.add_edge(START,"decision")
    # builder.add_edge("decision",END)
    
    builder.set_entry_point("decision")

    # Compile
    return builder.compile()


# In[82]:
class ChatRequest(BaseModel):
    chat_history: List[str]
    clarification_received: bool
    result_payload:dict

def clean_nan(obj):
    if isinstance(obj, dict):
        return {k: clean_nan(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan(v) for v in obj]
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
    return obj

def safe_json_dumps(obj):
    """JSON serializer that handles Decimal, NaN, and other non-serializable types from DynamoDB."""
    import decimal
    def default_fn(o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        return str(o)
    try:
        # First clean NaN/Inf floats
        cleaned = clean_nan(obj)
        return json.dumps(cleaned, default=default_fn)
    except Exception:
        return json.dumps(str(obj))

# In[19]:
# @app.get("/")
# def serve_index():
#     return FileResponse("index.html")
    
# @app.get("/style.css")
# def serve_css():
#     return FileResponse("style.css")

# @app.get("/script.js")
# def serve_js():
#     return FileResponse("script.js")

@app.post("/agent")
def agent(req: ChatRequest):
    try:
        chat_history = req.chat_history
        clarification_received = req.clarification_received
        result_payload=req.result_payload

        # ── Canned Q&A check ────────────────────────────────────────────────
        if chat_history:
            latest_msg = chat_history[-1] if isinstance(chat_history[-1], str) else str(chat_history[-1])
            _key = _normalize_q(latest_msg)
            if _key in CANNED_QA:
                import time as _time
                _time.sleep(4.5)
                _html = markdown.markdown(CANNED_QA[_key], extensions=['tables', 'fenced_code'])
                return {"response": _html, "result_payload": {}, "clarification_needed": False}
        # ────────────────────────────────────────────────────────────────────

        initial_state={
            "chat_history" : chat_history,
            "final_response": None,
            "clarification_received": clarification_received,
            "clarification_needed" :False,
            "result_payload":result_payload
        }
        app_graph=build_graph()
        result = app_graph.invoke(initial_state)

        # checking below for the evaluation
        try:
            records = load_records()
            latest_user_query = initial_state['chat_history'][-1]
            llm_response = result['final_response']

            evaluation_response = evaluation(bedrock=bedrock,
                                             model_id=model_id,
                                             user_query=latest_user_query,
                                             ai_response=llm_response,
                                             eval_records=records)
            logger.info("Evaluation results")
            print(f"Evaluation_result: {json.dumps(evaluation_response)}")
            logger.info(f"user_query: {latest_user_query}")
            logger.info(f"response: {llm_response}")
            logger.info(f"evaluation_result: {json.dumps(evaluation_response)}")
            print("Evaluation completed and results stored in eval_logs.txt")
        except Exception as eval_err:
            print(f"Evaluation skipped (non-critical): {eval_err}")
        
        if result["clarification_needed"]:
            # Send the clarification question to the user, not the raw adjudication dict
            clarification_q = result.get("clarification_question") or ""
            if not clarification_q and result.get("final_response"):
                # update/create nodes store the question inside final_response["answer"]
                fr = result["final_response"]
                if isinstance(fr, dict):
                    clarification_q = fr.get("answer") or fr.get("next_action") or fr.get("clarification_question") or ""
                elif isinstance(fr, str):
                    clarification_q = fr
            if not clarification_q:
                clarification_q = "Could you clarify your request? Please provide more details."
            return {
                "response": f"<p>{clarification_q}</p>",
                "result_payload": clean_nan(result["final_response"]),
                "clarification_needed": True
            }
        else:
            fr = result["final_response"]
            # final_response can sometimes be a dict (from update/create nodes) — extract text safely
            if isinstance(fr, dict):
                fr = fr.get("answer") or fr.get("message") or fr.get("next_action") or json.dumps(fr, default=str)
            fr = str(fr) if fr else "No response generated."
            return {
                "response": markdown.markdown(fr, extensions=['tables', 'fenced_code']),
                "result_payload": {},
                "clarification_needed": result["clarification_needed"]
            }
    except Exception as e:
        print(f"Error in /agent endpoint: {e}")
        import traceback
        traceback.print_exc()
        return {
            "response": "<p>Sorry, something went wrong while processing your request. Please try rephrasing your question.</p>",
            "result_payload": {},
            "clarification_needed": False
        }


@app.post("/upload")
async def upload_files(
    files: List[UploadFile] = File(...),
    categories: List[str] = Form(...),
    force_reindex: str = Form(default="false")
):
    try:
        processed = 0
        skipped = 0
        force = force_reindex.lower() == "true"

        # Map UI category labels to source_type keys used by CleaningAgent
        category_to_source_type = {
            "Meeting Transcript": "meeting_transcript",
            "Team Chat": "teams_chat",
            "Outlook": "email",
        }

        for file, category in zip(files, categories):
            contents = await file.read()

            # Deduplication: skip if same file content was already indexed
            # (unless force_reindex is set — e.g. to rebuild with richer task_evidence)
            content_hash = hashlib.md5(contents).hexdigest()
            if not force:
                print(f"[DEDUP] Checking file={file.filename} hash={content_hash} registry={UPLOAD_HASH_REGISTRY}")
                if check_duplicate_in_opensearch(content_hash, filename=file.filename):
                    print(f"[DEDUP] Skipping {file.filename} — already indexed (hash={content_hash})")
                    skipped += 1
                    continue
            else:
                print(f"[DEDUP] Force re-index enabled — skipping dedup check for {file.filename}")

            # Save file locally
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            file_path = os.path.join(UPLOAD_DIR, file.filename)
            with open(file_path, "wb") as f:
                f.write(contents)

            # Step 1: Extract text from file
            text = process_user_upload_to_vector(file_path=file_path)
            print(f"Extracted text from {file.filename}: {text[:200]}")

            if not isinstance(text, str) or not text.strip():
                raise Exception(f"Error processing file: {file.filename}")

            # Step 2: Clean & structure the text using LLM (CleaningAgent logic)
            source_type = category_to_source_type.get(category, "email")

            cleaning_prompt = f"""You are a document processing assistant. Parse the following {source_type} content into structured JSON.

Return ONLY valid JSON with these fields:
{{
  "source_type": "{source_type}",
  "clean_text": "<cleaned version of the content>",
  "summary": "<2-3 sentence summary>",
  "action_items": [{{"title": "", "description": "", "owner": "", "due_date": "", "status": "pending"}}],
  "decisions": [{{"description": "", "confidence": 0.9}}],
  "entities": {{
    "projects": [],
    "tickets": [],
    "people": [],
    "dates": [],
    "systems": [],
    "organizations": []
  }},
  "metadata": {{}}
}}

Content:
{text}
"""
            try:
                cleaned_response = llm.invoke(cleaning_prompt).content
                cleaned_json = json.loads(clean_llm_output(cleaned_response))
            except Exception as e:
                print(f"LLM cleaning failed for {file.filename}: {e}")
                cleaned_json = {
                    "source_type": source_type,
                    "clean_text": text,
                    "summary": text[:300],
                    "action_items": [],
                    "decisions": [],
                    "entities": {"projects": [], "people": [], "dates": [], "tickets": [], "systems": [], "organizations": []},
                    "metadata": {}
                }

            # Step 3: Transform into OpenSearch work_evidence document
            evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
            now = datetime.now(timezone.utc).isoformat()

            clean_text = cleaned_json.get("clean_text", text)
            summary = cleaned_json.get("summary", text[:300])
            entities = cleaned_json.get("entities", {})
            action_items = cleaned_json.get("action_items", [])
            decisions = cleaned_json.get("decisions", [])

            people = entities.get("people", [])
            projects = entities.get("projects", [])
            dates = entities.get("dates", [])

            embedding_text = f"{clean_text}\n{summary}\nProjects: {', '.join(projects)}\nPeople: {', '.join(people)}"

            # content_hash already computed above for dedup check — reuse it here

            work_evidence_doc = {
                "evidence_id": evidence_id,
                "workspace_id": "default-workspace",
                "project_id": "",
                "source_type": source_type,
                "source_uri": f"upload:{file.filename}",
                "content_hash": content_hash,
                "raw_text": json.dumps(cleaned_json, default=str),
                "clean_text": clean_text,
                "summary": summary,
                "embedding_text": embedding_text,
                "linked_work_item_ids": [],
                "action_items_detected": action_items,
                "decisions_detected": decisions,
                "dates_detected": dates,
                "metadata": {
                    "source_uri": f"upload:{file.filename}",
                    "entities": entities
                },
                "created_at": now,
                "updated_at": now,
                "vector_embedding": vectorize_with_titan(embedding_text)
            }

            # Step 4: Index into OpenSearch (work_evidence)
            index_response = index_document(doc=work_evidence_doc)
            print(f"Indexed {file.filename} into OpenSearch: {index_response['status_code']}")

            # Save hash to local registry so future duplicate uploads are caught immediately
            _save_hash_to_registry(content_hash)

            # Step 5: Create work items in DynamoDB for each action item (shows on Board)
            action_items = cleaned_json.get("action_items", [])
            projects = cleaned_json.get("entities", {}).get("projects", [])
            project_name = projects[0] if projects else "Unassigned"

            # If force re-index, delete old WorkItems for this file first
            # so we don't end up with duplicate cards
            if force:
                try:
                    source_uri_val = f"upload:{file.filename}"
                    wi_table = dynamodb_resource.Table(work_items)  # Testing environment
                    # Scan WorkItems for this source_uri and delete them
                    scan_kwargs = {
                        "FilterExpression": "source_uri = :uri",
                        "ExpressionAttributeValues": {":uri": source_uri_val},
                        "ProjectionExpression": "PK, SK",
                    }
                    while True:
                        resp = wi_table.scan(**scan_kwargs)
                        for item in resp.get("Items", []):
                            wi_table.delete_item(Key={"PK": item["PK"], "SK": item["SK"]})
                        last_key = resp.get("LastEvaluatedKey")
                        if not last_key:
                            break
                        scan_kwargs["ExclusiveStartKey"] = last_key
                    print(f"[FORCE] Deleted old WorkItems for {file.filename}")
                except Exception as del_err:
                    print(f"[FORCE] Could not delete old items for {file.filename}: {del_err}")

            for action_item in action_items:
                if not action_item.get("title") and not action_item.get("description"):
                    continue

                work_item_id = f"WI_{uuid.uuid4().hex[:8]}"
                new_item = {
                    "work_item_id": work_item_id,
                    "project_name": project_name,
                    "task": action_item.get("title") or action_item.get("description", ""),
                    "assignee": action_item.get("owner") or "Unassigned",
                    "assigned_to": action_item.get("owner") or "Unassigned",  # Keep both fields for UI compatibility
                    "due_date": action_item.get("due_date") or "",
                    "status": action_item.get("status") or "pending",
                    "source_type": source_type,
                    "source_uri": f"upload:{file.filename}",
                    "summary": f"{action_item.get('description') or action_item.get('title', '')} | Doc: {summary[:300]}",
                    "event_timestamp": datetime.now(timezone.utc).isoformat(),
                    "evidence_id": work_evidence_doc.get("evidence_id", ""),
                    "task_evidence": f"{summary}\n\n{text[:1200]}",
                }

                # Write to AgenticColleague_WorkItems_Test (single source of truth)
                apply_confirmed_update_dynamodb(new_item, table_name=work_items)
                print(f"Created work item: {new_item['task']} -> {new_item['assignee']}")

            processed += 1

        if processed == 0 and skipped > 0:
            return {"response": f"⚠️ All {skipped} file(s) were already uploaded previously and skipped to avoid duplicates."}
        elif skipped > 0:
            return {"response": f"✅ Processed {processed} file(s) successfully. ⚠️ {skipped} file(s) skipped (already uploaded)."}
        elif processed > 0:
            return {"response": f"✅ Successfully processed and indexed {processed} file(s). Work items added to the board."}
        else:
            return {"response": "No files were processed."}

    except Exception as e:
        print(f"Error in /upload endpoint: {e}")
        import traceback
        traceback.print_exc()
        return {"response": f"Upload failed: {str(e)}"}

    


@app.get("/tasks")
def get_tasks():
    """Get all tasks from DynamoDB WorkItems table with full pagination."""

    def decimal_to_json(obj):
        """Convert DynamoDB Decimal to int/float for JSON serialization."""
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return obj

    # DynamoDB resource
    dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
    table = dynamodb.Table(work_items)  # Use WorkItems as single source of truth

    items = []
    response = table.scan()
    items.extend(response.get("Items", []))
    # Paginate through all pages
    while "LastEvaluatedKey" in response:
        response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
        items.extend(response.get("Items", []))

    # Fix Decimal serialization
    clean_items = json.loads(json.dumps(items, default=decimal_to_json))

    # ── Deduplicate by (task name + project name), keep the most recently updated item ──
    seen: dict = {}
    for item in clean_items:
        task_key = (
            (item.get("task") or "").strip().lower(),
            (item.get("project_name") or "").strip().lower(),
        )
        if task_key not in seen:
            seen[task_key] = item
        else:
            # Prefer the item with a newer event_timestamp or updated_at
            existing = seen[task_key]
            new_ts  = item.get("updated_at") or item.get("event_timestamp") or ""
            prev_ts = existing.get("updated_at") or existing.get("event_timestamp") or ""
            if str(new_ts) > str(prev_ts):
                seen[task_key] = item

    deduped_items = list(seen.values())

    # ── Return ALL tasks from DynamoDB (no hardcoded filtering) ──
    # Sort by most recent first (event_timestamp or updated_at)
    def get_timestamp(item):
        return item.get("updated_at") or item.get("event_timestamp") or ""
    
    # Return ALL deduped tasks so dropdown shows all projects
    final_items = sorted(deduped_items, key=get_timestamp, reverse=True)

    print(f"[TASKS] Returning {len(final_items)} tasks from DynamoDB (deduped from {len(clean_items)} total)")
    return final_items


@app.delete("/tasks")
def delete_task(pk: str, sk: str):
    """Delete a work item by its DynamoDB PK and SK."""
    try:
        dynamodb_del = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb_del.Table(work_items)  # Use WorkItems as single source of truth
        table.delete_item(Key={"PK": pk, "SK": sk})
        print(f"[DELETE] Removed work item PK={pk} SK={sk}")
        return {"status": "deleted", "PK": pk, "SK": sk}
    except Exception as e:
        print(f"[DELETE] Failed to delete work item PK={pk} SK={sk}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# TRANSCRIPT PIPELINE API ENDPOINTS
# ============================================================================
# These endpoints allow triggering the transcript pipeline operations
# from the UI dashboard or via Swagger for testing all command combinations.
# ============================================================================

from typing import Optional, List
from enum import Enum
from pydantic import BaseModel, Field
import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta

# Import transcript pipeline modules
from transcript_pipeline.main_v2 import TranscriptPipelineV2, PipelineResult as TranscriptPipelineResult
from transcript_pipeline.config import Config as TranscriptConfig
from transcript_pipeline.verify.transcript.verify_all import verify_all_transcript as transcript_verify_all
from transcript_pipeline.verify.settings import get_all_dynamodb_records as get_dynamodb_records
from transcript_pipeline.verify.settings import get_all_s3_files as get_s3_files

# Thread pool for running sync functions in async context
_transcript_executor = ThreadPoolExecutor(max_workers=2)


class TranscriptRunMode(str, Enum):
    """Run modes for transcript pipeline."""
    FULL = "full"
    INCREMENTAL = "incremental"
    SINCE = "since"


class TranscriptRunRequest(BaseModel):
    """Request model for transcript pipeline run endpoint."""
    mode: TranscriptRunMode = Field(
        default=TranscriptRunMode.INCREMENTAL,
        description="Run mode: 'full' for first run/reset, 'incremental' for new meetings only, 'since' for specific date"
    )
    since_date: Optional[str] = Field(
        default=None,
        description="Start date for 'since' mode (format: YYYY-MM-DD). Required when mode='since'"
    )
    limit: Optional[int] = Field(
        default=None,
        ge=1,
        description="Maximum number of meetings to process. If None, processes all meetings."
    )
    retry_failed: bool = Field(
        default=True,
        description="Whether to retry previously failed transcripts"
    )


class TranscriptRunResponse(BaseModel):
    """Response model for transcript pipeline run."""
    status: str
    message: str
    mode: str
    total_meetings: int
    total_transcripts: int
    processed: int
    skipped: int
    failed: int
    retried: int
    success_rate: float
    duration_seconds: float
    errors: List[str] = []


class TranscriptStatusResponse(BaseModel):
    """Response model for transcript pipeline status."""
    pipeline_status: str
    configuration: dict
    incremental_settings: dict
    dynamodb_stats: dict
    s3_stats: dict
    last_run_info: Optional[dict] = None


class TranscriptVerifyResponse(BaseModel):
    """Response model for transcript pipeline verification."""
    all_passed: bool
    secrets_manager: bool
    dynamodb: bool
    s3: bool
    graph_api: bool
    details: dict


class TranscriptRecordResponse(BaseModel):
    """Response model for a single transcript record."""
    transcript_id: str
    status: str
    meeting_subject: Optional[str] = None
    meeting_id: Optional[str] = None
    s3_path: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    retry_count: int = 0
    error_message: Optional[str] = None


class TranscriptListResponse(BaseModel):
    """Response model for transcript list."""
    total_records: int
    records: List[dict]
    status_summary: dict


class S3FileResponse(BaseModel):
    """Response model for S3 file listing."""
    total_files: int
    total_size_mb: float
    files: List[dict]


class CleanupResponse(BaseModel):
    """Response model for cleanup operations."""
    status: str
    message: str
    deleted_count: int


# Helper function to parse dates
def _parse_transcript_date(date_str: str) -> datetime:
    """Parse a date string into a datetime object."""
    formats = [
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
    ]
    
    for fmt in formats:
        try:
            dt = datetime.strptime(date_str, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    
    raise ValueError(f"Could not parse date: {date_str}. Use format YYYY-MM-DD")


# ─────────────────────────────────────────────────────────────────────────────
# GET /transcript/config - Get transcript pipeline configuration
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/transcript/config",
    tags=["Transcript Pipeline"],
    summary="Get transcript pipeline configuration",
    description="Returns the current configuration for the transcript pipeline including AWS settings and incremental sync parameters."
)
def get_transcript_config():
    """Get the current transcript pipeline configuration."""
    try:
        pipeline = TranscriptPipelineV2()
        config = pipeline.config
        base_prefix = config.s3_prefix.rstrip("/")
        return {
            "status": "success",
            "configuration": {
                "aws_region": config.aws_region,
                "s3_bucket_name": config.s3_bucket_name,
                "s3_base_prefix": base_prefix,
                "s3_transcript_prefix": pipeline.storage.prefix,
                "dynamodb_table_name": config.dynamodb_table_name,
                "meetings_fetch_limit": config.meetings_fetch_limit,
                "max_retry_attempts": config.max_retry_attempts,
            },
            "incremental_settings": {
                "default_lookback_days": config.default_lookback_days,
                "incremental_buffer_hours": config.incremental_buffer_hours,
                "enable_auto_retry": config.enable_auto_retry,
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get configuration: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /transcript/status - Get transcript pipeline status
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/transcript/status",
    response_model=TranscriptStatusResponse,
    tags=["Transcript Pipeline"],
    summary="Get transcript pipeline status",
    description="Returns the current status of the transcript pipeline including DynamoDB stats, S3 storage stats, and last run information."
)
def get_transcript_status():
    """Get the current transcript pipeline status."""
    try:
        pipeline = TranscriptPipelineV2()
        
        # Get configuration
        config = pipeline.config
        
        # Get DynamoDB stats
        db_stats = pipeline.tracker.get_processing_stats()
        
        # Get S3 stats
        s3_stats = pipeline.storage.get_storage_stats()
        
        # Get last run info
        last_run = pipeline.tracker.get_last_successful_run()
        metadata = pipeline.tracker.get_pipeline_metadata()
        
        last_run_info = None
        if metadata:
            last_run_info = {
                "last_successful_run": metadata.get("last_successful_run"),
                "last_run_mode": metadata.get("last_run_mode"),
                "last_run_processed": metadata.get("last_run_processed"),
                "last_run_failed": metadata.get("last_run_failed"),
            }
        
        return TranscriptStatusResponse(
            pipeline_status="ready",
            configuration={
                "aws_region": config.aws_region,
                "s3_bucket_name": config.s3_bucket_name,
                "s3_transcript_prefix": pipeline.storage.prefix,
                "dynamodb_table_name": pipeline.tracker.table_name,
            },
            incremental_settings={
                "default_lookback_days": config.default_lookback_days,
                "incremental_buffer_hours": config.incremental_buffer_hours,
                "enable_auto_retry": config.enable_auto_retry,
            },
            dynamodb_stats=db_stats,
            s3_stats=s3_stats,
            last_run_info=last_run_info,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get status: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /transcript/verify - Verify transcript pipeline components
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/transcript/verify",
    response_model=TranscriptVerifyResponse,
    tags=["Transcript Pipeline"],
    summary="Verify transcript pipeline components",
    description="Verifies all components of the transcript pipeline: Secrets Manager, DynamoDB, S3, and Graph API."
)
def verify_transcript_pipeline():
    """Verify all transcript pipeline components."""
    try:
        pipeline = TranscriptPipelineV2()
        
        results = {
            "secrets_manager": False,
            "dynamodb": False,
            "s3": False,
            "graph_api": False,
        }
        details = {}
        
        # 1. Configuration/Secrets Manager
        try:
            pipeline.config.validate()
            results["secrets_manager"] = True
            details["secrets_manager"] = "Configuration loaded successfully"
        except Exception as e:
            details["secrets_manager"] = f"Error: {str(e)}"
        
        # 2. Graph API
        try:
            _ = pipeline.graph_client
            results["graph_api"] = True
            details["graph_api"] = "Graph API authenticated successfully (Transcript Client)"
        except Exception as e:
            details["graph_api"] = f"Error: {str(e)}"
        
        # 3. DynamoDB (TRANSCRIPT records only)
        try:
            stats = pipeline.tracker.get_processing_stats()
            results["dynamodb"] = True
            details["dynamodb"] = f"DynamoDB accessible. Total transcript records: {stats.get('TOTAL', 0)}"
        except Exception as e:
            details["dynamodb"] = f"Error: {str(e)}"
        
        # 4. S3 (Transcript folder)
        try:
            s3_stats = pipeline.storage.get_storage_stats()
            results["s3"] = True
            details["s3"] = f"S3 accessible. Transcript files: {s3_stats.get('total_files', 0)} (prefix: {pipeline.storage.prefix})"
        except Exception as e:
            details["s3"] = f"Error: {str(e)}"
        
        return TranscriptVerifyResponse(
            all_passed=all(results.values()),
            secrets_manager=results["secrets_manager"],
            dynamodb=results["dynamodb"],
            s3=results["s3"],
            graph_api=results["graph_api"],
            details=details,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /transcript/run - Main transcript pipeline run endpoint
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/transcript/run",
    response_model=TranscriptRunResponse,
    tags=["Transcript Pipeline"],
    summary="Run transcript pipeline",
    description="""
    **Main endpoint to trigger the transcript extraction pipeline.**
    
    This endpoint fetches Microsoft Teams meeting transcripts, converts them to DOCX format,
    and stores them in S3 with processing state tracked in DynamoDB.
    
    **Run Modes:**
    - `full`: First run or reset - fetches all meetings from the last N days (configured lookback)
    - `incremental`: Only fetches new meetings since last successful run (default)
    - `since`: Fetches meetings from a specific date
    
    **Options:**
    - `limit`: Maximum number of meetings to process (optional)
    - `retry_failed`: Whether to retry previously failed transcripts (default: true)
    """
)
async def run_transcript_pipeline(request: TranscriptRunRequest):
    """Run the transcript extraction pipeline."""
    
    # Validate since_date if mode is 'since'
    since_date = None
    if request.mode == TranscriptRunMode.SINCE:
        if not request.since_date:
            raise HTTPException(
                status_code=400,
                detail="since_date is required when mode='since'"
            )
        try:
            since_date = _parse_transcript_date(request.since_date)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    
    print(f"\n[TRANSCRIPT API] Starting transcript pipeline")
    print(f"  Mode: {request.mode.value}")
    print(f"  Since Date: {since_date}")
    print(f"  Limit: {request.limit}")
    print(f"  Retry Failed: {request.retry_failed}")
    
    try:
        # Run the pipeline in a thread pool
        loop = asyncio.get_event_loop()
        
        def run_pipeline():
            pipeline = TranscriptPipelineV2()
            return pipeline.run(
                mode=request.mode.value,
                since_date=since_date,
                limit=request.limit,
                retry_failed=request.retry_failed,
            )
        
        result = await loop.run_in_executor(_transcript_executor, run_pipeline)
        
        return TranscriptRunResponse(
            status="success",
            message=f"Transcript pipeline completed ({request.mode.value} mode)",
            mode=request.mode.value,
            total_meetings=result.total_meetings,
            total_transcripts=result.total_transcripts,
            processed=result.processed,
            skipped=result.skipped,
            failed=result.failed,
            retried=result.retried,
            success_rate=result.success_rate,
            duration_seconds=result.duration_seconds,
            errors=result.errors[:10] if result.errors else [],
        )
        
    except Exception as e:
        print(f"[TRANSCRIPT API] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Pipeline failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /transcript/run-full - Run full sync (shortcut)
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/transcript/run-full",
    response_model=TranscriptRunResponse,
    tags=["Transcript Pipeline"],
    summary="Run full transcript sync",
    description="Shortcut endpoint to run a full sync of all transcripts. Use this for first run or reset."
)
async def run_transcript_full_sync(
    limit: Optional[int] = None,
    retry_failed: bool = True
):
    """Run full transcript sync (first run or reset)."""
    request = TranscriptRunRequest(
        mode=TranscriptRunMode.FULL,
        limit=limit,
        retry_failed=retry_failed,
    )
    return await run_transcript_pipeline(request)


# ─────────────────────────────────────────────────────────────────────────────
# POST /transcript/run-incremental - Run incremental sync (shortcut)
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/transcript/run-incremental",
    response_model=TranscriptRunResponse,
    tags=["Transcript Pipeline"],
    summary="Run incremental transcript sync",
    description="Shortcut endpoint to run an incremental sync. Only fetches new meetings since last successful run."
)
async def run_transcript_incremental_sync(
    limit: Optional[int] = None,
    retry_failed: bool = True
):
    """Run incremental transcript sync (new meetings only)."""
    request = TranscriptRunRequest(
        mode=TranscriptRunMode.INCREMENTAL,
        limit=limit,
        retry_failed=retry_failed,
    )
    return await run_transcript_pipeline(request)


# ─────────────────────────────────────────────────────────────────────────────
# POST /transcript/run-since - Run sync from specific date (shortcut)
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/transcript/run-since",
    response_model=TranscriptRunResponse,
    tags=["Transcript Pipeline"],
    summary="Run transcript sync from specific date",
    description="Shortcut endpoint to run sync from a specific date. Fetches all meetings since the specified date."
)
async def run_transcript_since_date(
    since_date: str,
    limit: Optional[int] = None,
    retry_failed: bool = True
):
    """Run transcript sync from a specific date."""
    request = TranscriptRunRequest(
        mode=TranscriptRunMode.SINCE,
        since_date=since_date,
        limit=limit,
        retry_failed=retry_failed,
    )
    return await run_transcript_pipeline(request)


# ─────────────────────────────────────────────────────────────────────────────
# GET /transcript/records - List all transcript records from DynamoDB
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/transcript/records",
    response_model=TranscriptListResponse,
    tags=["Transcript Pipeline"],
    summary="List all transcript records",
    description="Returns all transcript records from DynamoDB with their processing status."
)
def list_transcript_records(
    status_filter: Optional[str] = None,
    limit: Optional[int] = None
):
    """List all transcript records from DynamoDB."""
    try:
        pipeline = TranscriptPipelineV2()
        
        # Get stats for TRANSCRIPT records only
        stats = pipeline.tracker.get_processing_stats()
        
        # Get records by scanning the table with TRANSCRIPT filter
        dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        table_name = pipeline.tracker.table_name
        
        # Filter by record_type=TRANSCRIPT to exclude chat records
        items = get_dynamodb_records(dynamodb_client, table_name, record_type_filter="TRANSCRIPT")
        
        all_records = []
        for item in items:
            # Support both old (transcript_id) and new (record_id) schema
            record_id = item.get("record_id", {}).get("S") or item.get("transcript_id", {}).get("S", "")
            record = {
                "transcript_id": record_id,
                "status": item.get("status", {}).get("S", ""),
                "meeting_subject": item.get("meeting_subject", {}).get("S", ""),
                "meeting_id": item.get("meeting_id", {}).get("S", ""),
                "s3_path": item.get("s3_path", {}).get("S", ""),
                "created_at": item.get("created_at", {}).get("S", ""),
                "updated_at": item.get("updated_at", {}).get("S", ""),
                "retry_count": int(item.get("retry_count", {}).get("N", "0")),
                "error_message": item.get("error_message", {}).get("S", ""),
            }
            
            # Apply status filter if provided
            if status_filter and record["status"].lower() != status_filter.lower():
                continue
            
            all_records.append(record)
        
        # Apply limit if provided
        if limit:
            all_records = all_records[:limit]
        
        return TranscriptListResponse(
            total_records=len(all_records),
            records=all_records,
            status_summary=stats,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list records: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /transcript/files - List all transcript files from S3
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/transcript/files",
    response_model=S3FileResponse,
    tags=["Transcript Pipeline"],
    summary="List all transcript files in S3",
    description="Returns all transcript files stored in S3 with their metadata."
)
def list_transcript_files(limit: Optional[int] = None):
    """List all transcript files from S3."""
    try:
        pipeline = TranscriptPipelineV2()
        
        s3_client = boto3.client("s3", region_name="us-east-1")
        bucket_name = pipeline.config.s3_bucket_name
        # Use the storage prefix which includes /transcripts/ subfolder
        prefix = pipeline.storage.prefix
        
        files = get_s3_files(s3_client, bucket_name, prefix)
        
        total_size = 0
        file_list = []
        
        for f in files:
            key = f.get("Key", "")
            size = f.get("Size", 0)
            last_modified = f.get("LastModified")
            
            # Only include DOCX files
            if not key.lower().endswith(".docx"):
                continue
            
            total_size += size
            
            file_info = {
                "key": key,
                "filename": key.replace(prefix, "") if key.startswith(prefix) else key,
                "size_bytes": size,
                "size_formatted": f"{size / 1024:.1f} KB" if size < 1024 * 1024 else f"{size / (1024*1024):.2f} MB",
                "last_modified": last_modified.isoformat() if last_modified else None,
            }
            file_list.append(file_info)
        
        # Apply limit if provided
        if limit:
            file_list = file_list[:limit]
        
        return S3FileResponse(
            total_files=len(file_list),
            total_size_mb=round(total_size / (1024 * 1024), 2),
            files=file_list,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list files: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /transcript/records - Cleanup DynamoDB records
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/transcript/records",
    response_model=CleanupResponse,
    tags=["Transcript Pipeline"],
    summary="Delete all transcript records from DynamoDB",
    description="⚠️ DANGER: Deletes ALL transcript tracking records from DynamoDB. Use with caution!"
)
def cleanup_transcript_records(confirm: bool = False):
    """Delete all transcript records from DynamoDB."""
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="Set confirm=true to confirm deletion of all transcript records"
        )
    
    try:
        pipeline = TranscriptPipelineV2()
        
        dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        table_name = pipeline.tracker.table_name
        
        # Get only TRANSCRIPT records (not CHAT records)
        items = get_dynamodb_records(dynamodb_client, table_name, record_type_filter="TRANSCRIPT")
        
        # Also get TRANSCRIPT_METADATA record
        metadata_items = get_dynamodb_records(dynamodb_client, table_name, record_type_filter="TRANSCRIPT_METADATA")
        items.extend(metadata_items)
        
        if not items:
            return CleanupResponse(
                status="success",
                message="No transcript records to delete",
                deleted_count=0,
            )
        
        # Delete each record using record_id as primary key
        deleted_count = 0
        for item in items:
            # Support both old (transcript_id) and new (record_id) schema
            record_id = item.get("record_id", {}).get("S") or item.get("transcript_id", {}).get("S")
            if record_id:
                try:
                    dynamodb_client.delete_item(
                        TableName=table_name,
                        Key={"record_id": {"S": record_id}}
                    )
                    deleted_count += 1
                except Exception as e:
                    print(f"Failed to delete {record_id}: {e}")
        
        return CleanupResponse(
            status="success",
            message=f"Deleted {deleted_count} transcript records from DynamoDB",
            deleted_count=deleted_count,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /transcript/files - Cleanup S3 files
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/transcript/files",
    response_model=CleanupResponse,
    tags=["Transcript Pipeline"],
    summary="Delete all transcript files from S3",
    description="⚠️ DANGER: Deletes ALL transcript files from S3. Use with caution!"
)
def cleanup_transcript_files(confirm: bool = False):
    """Delete all transcript files from S3."""
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="Set confirm=true to confirm deletion of all transcript files"
        )
    
    try:
        pipeline = TranscriptPipelineV2()
        
        s3_client = boto3.client("s3", region_name="us-east-1")
        bucket_name = pipeline.config.s3_bucket_name
        # Use the storage prefix which includes /transcripts/ subfolder
        prefix = pipeline.storage.prefix
        
        # Get only files in the /transcripts/ prefix (not /chats/)
        files = get_s3_files(s3_client, bucket_name, prefix)
        
        if not files:
            return CleanupResponse(
                status="success",
                message="No transcript files to delete",
                deleted_count=0,
            )
        
        # Delete each file (only DOCX files in transcript prefix)
        deleted_count = 0
        for f in files:
            key = f.get("Key")
            if key and key.lower().endswith(".docx"):
                try:
                    s3_client.delete_object(Bucket=bucket_name, Key=key)
                    deleted_count += 1
                except Exception as e:
                    print(f"Failed to delete {key}: {e}")
        
        return CleanupResponse(
            status="success",
            message=f"Deleted {deleted_count} transcript files from S3",
            deleted_count=deleted_count,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ============================================================================
# END OF TRANSCRIPT PIPELINE API ENDPOINTS
# ============================================================================


# ============================================================================
# MEETING CHAT PIPELINE API ENDPOINTS
# ============================================================================
# These endpoints allow triggering the meeting chat pipeline operations
# from the UI dashboard or via Swagger for testing all command combinations.
# Similar to transcript pipeline but for Teams meeting chat messages.
# ============================================================================

# Import meeting chat pipeline modules
from transcript_pipeline.main_chat import MeetingChatPipeline, ChatPipelineResult
from transcript_pipeline.chat_client import ChatClient, MeetingChatInfo
from transcript_pipeline.chat_dynamodb_tracker import ChatDynamoDBTracker, ChatStatus, ChatRecord
from transcript_pipeline.chat_s3_storage import ChatS3Storage
from transcript_pipeline.verify.chat.verify_all import verify_all_chat as chat_verify_all

# Thread pool for running chat sync functions in async context
_chat_executor = ThreadPoolExecutor(max_workers=2)


class ChatRunMode(str, Enum):
    """Run modes for meeting chat pipeline."""
    FULL = "full"
    INCREMENTAL = "incremental"
    SINCE = "since"


class ChatRunRequest(BaseModel):
    """Request model for meeting chat pipeline run endpoint."""
    mode: ChatRunMode = Field(
        default=ChatRunMode.INCREMENTAL,
        description="Run mode: 'full' for first run/reset, 'incremental' for new meetings only, 'since' for specific date"
    )
    since_date: Optional[str] = Field(
        default=None,
        description="Start date for 'since' mode (format: YYYY-MM-DD). Required when mode='since'"
    )
    limit: Optional[int] = Field(
        default=None,
        ge=1,
        description="Maximum number of meetings to process. If None, processes all meetings."
    )
    retry_failed: bool = Field(
        default=True,
        description="Whether to retry previously failed chat extractions"
    )
    min_messages: int = Field(
        default=1,
        ge=1,
        description="Minimum number of messages required per meeting to process"
    )


class ChatRunResponse(BaseModel):
    """Response model for meeting chat pipeline run."""
    status: str
    message: str
    mode: str
    total_meetings: int
    total_messages: int
    processed: int
    skipped: int
    failed: int
    retried: int
    success_rate: float
    duration_seconds: float
    errors: List[str] = []


class ChatStatusResponse(BaseModel):
    """Response model for meeting chat pipeline status."""
    pipeline_status: str
    configuration: dict
    incremental_settings: dict
    dynamodb_stats: dict
    s3_stats: dict
    last_run_info: Optional[dict] = None


class ChatVerifyResponse(BaseModel):
    """Response model for meeting chat pipeline verification."""
    all_passed: bool
    secrets_manager: bool
    dynamodb: bool
    s3: bool
    graph_api: bool
    details: dict


class ChatRecordResponse(BaseModel):
    """Response model for a single chat record."""
    chat_id: str
    status: str
    meeting_subject: Optional[str] = None
    meeting_id: Optional[str] = None
    message_count: int = 0
    s3_path: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    retry_count: int = 0
    error_message: Optional[str] = None


class ChatListResponse(BaseModel):
    """Response model for chat list."""
    total_records: int
    records: List[dict]
    status_summary: dict


class ChatS3FileResponse(BaseModel):
    """Response model for S3 chat file listing."""
    total_files: int
    total_size_mb: float
    files: List[dict]


class ChatCleanupResponse(BaseModel):
    """Response model for chat cleanup operations."""
    status: str
    message: str
    deleted_count: int


# Helper function to parse dates for chat pipeline
def _parse_chat_date(date_str: str) -> datetime:
    """Parse a date string into a datetime object."""
    formats = [
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
    ]
    
    for fmt in formats:
        try:
            dt = datetime.strptime(date_str, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    
    raise ValueError(f"Could not parse date: {date_str}. Use format YYYY-MM-DD")


# ─────────────────────────────────────────────────────────────────────────────
# GET /chat/config - Get meeting chat pipeline configuration
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/chat/config",
    tags=["Meeting Chat Pipeline"],
    summary="Get meeting chat pipeline configuration",
    description="Returns the current configuration for the meeting chat pipeline including AWS settings and incremental sync parameters."
)
def get_chat_config():
    """Get the current meeting chat pipeline configuration."""
    try:
        config = TranscriptConfig()
        base_prefix = config.s3_prefix.rstrip("/")
        return {
            "status": "success",
            "configuration": {
                "aws_region": config.aws_region,
                "s3_bucket_name": config.s3_bucket_name,
                "s3_base_prefix": base_prefix,
                "s3_chat_prefix": f"{base_prefix}/chats/",
                "dynamodb_table_name": config.dynamodb_table_name,
                "meetings_fetch_limit": config.meetings_fetch_limit,
                "max_retry_attempts": config.max_retry_attempts,
            },
            "incremental_settings": {
                "default_lookback_days": config.default_lookback_days,
                "incremental_buffer_hours": config.incremental_buffer_hours,
                "enable_auto_retry": config.enable_auto_retry,
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get configuration: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /chat/status - Get meeting chat pipeline status
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/chat/status",
    response_model=ChatStatusResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Get meeting chat pipeline status",
    description="Returns the current status of the meeting chat pipeline including DynamoDB stats, S3 storage stats, and last run information."
)
def get_chat_status():
    """Get the current meeting chat pipeline status."""
    try:
        pipeline = MeetingChatPipeline()
        
        # Get configuration
        config = pipeline.config
        
        # Get DynamoDB stats
        db_stats = pipeline.tracker.get_processing_stats()
        
        # Get S3 stats
        s3_stats = pipeline.storage.get_storage_stats()
        
        # Get last run info
        metadata = pipeline.tracker.get_pipeline_metadata()
        
        last_run_info = None
        if metadata:
            last_run_info = {
                "last_successful_run": metadata.get("last_successful_run"),
                "last_run_mode": metadata.get("last_run_mode"),
                "last_run_status": metadata.get("last_run_status"),
                "last_run_processed": metadata.get("processed_count"),
                "last_run_failed": metadata.get("failed_count"),
            }
        
        return ChatStatusResponse(
            pipeline_status="ready",
            configuration={
                "aws_region": config.aws_region,
                "s3_bucket_name": config.s3_bucket_name,
                "s3_chat_prefix": pipeline.storage.prefix,
                "dynamodb_table_name": pipeline.tracker.table_name,
            },
            incremental_settings={
                "default_lookback_days": config.default_lookback_days,
                "incremental_buffer_hours": config.incremental_buffer_hours,
                "enable_auto_retry": config.enable_auto_retry,
            },
            dynamodb_stats=db_stats,
            s3_stats=s3_stats,
            last_run_info=last_run_info,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get status: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /chat/verify - Verify meeting chat pipeline components
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/chat/verify",
    response_model=ChatVerifyResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Verify meeting chat pipeline components",
    description="Verifies all components of the meeting chat pipeline: Secrets Manager, DynamoDB, S3, and Graph API."
)
def verify_chat_pipeline():
    """Verify all meeting chat pipeline components."""
    try:
        pipeline = MeetingChatPipeline()
        
        results = {
            "secrets_manager": False,
            "dynamodb": False,
            "s3": False,
            "graph_api": False,
        }
        details = {}
        
        # 1. Configuration/Secrets Manager
        try:
            pipeline.config.validate()
            results["secrets_manager"] = True
            details["secrets_manager"] = "Configuration loaded successfully"
        except Exception as e:
            details["secrets_manager"] = f"Error: {str(e)}"
        
        # 2. Graph API (Chat Client)
        try:
            _ = pipeline.chat_client
            results["graph_api"] = True
            details["graph_api"] = "Graph API authenticated successfully (Chat Client)"
        except Exception as e:
            details["graph_api"] = f"Error: {str(e)}"
        
        # 3. DynamoDB
        try:
            stats = pipeline.tracker.get_processing_stats()
            results["dynamodb"] = True
            details["dynamodb"] = f"DynamoDB accessible. Total chat records: {stats.get('TOTAL', 0)}"
        except Exception as e:
            details["dynamodb"] = f"Error: {str(e)}"
        
        # 4. S3
        try:
            s3_stats = pipeline.storage.get_storage_stats()
            results["s3"] = True
            details["s3"] = f"S3 accessible. Chat files: {s3_stats.get('total_files', 0)}"
        except Exception as e:
            details["s3"] = f"Error: {str(e)}"
        
        return ChatVerifyResponse(
            all_passed=all(results.values()),
            secrets_manager=results["secrets_manager"],
            dynamodb=results["dynamodb"],
            s3=results["s3"],
            graph_api=results["graph_api"],
            details=details,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /chat/run - Main meeting chat pipeline run endpoint
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/chat/run",
    response_model=ChatRunResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Run meeting chat pipeline",
    description="""
    **Main endpoint to trigger the meeting chat extraction pipeline.**
    
    This endpoint fetches Microsoft Teams meeting chat messages, converts them to DOCX format,
    and stores them in S3 with processing state tracked in DynamoDB.
    
    **Run Modes:**
    - `full`: First run or reset - fetches all meeting chats from the last N days (configured lookback)
    - `incremental`: Only fetches new meeting chats since last successful run (default)
    - `since`: Fetches meeting chats from a specific date
    
    **Options:**
    - `limit`: Maximum number of meetings to process (optional)
    - `retry_failed`: Whether to retry previously failed chat extractions (default: true)
    - `min_messages`: Minimum number of messages required per meeting to process (default: 1)
    """
)
async def run_chat_pipeline(request: ChatRunRequest):
    """Run the meeting chat extraction pipeline."""
    
    # Validate since_date if mode is 'since'
    since_date = None
    if request.mode == ChatRunMode.SINCE:
        if not request.since_date:
            raise HTTPException(
                status_code=400,
                detail="since_date is required when mode='since'"
            )
        try:
            since_date = _parse_chat_date(request.since_date)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
    
    print(f"\n[CHAT API] Starting meeting chat pipeline")
    print(f"  Mode: {request.mode.value}")
    print(f"  Since Date: {since_date}")
    print(f"  Limit: {request.limit}")
    print(f"  Retry Failed: {request.retry_failed}")
    print(f"  Min Messages: {request.min_messages}")
    
    try:
        # Run the pipeline in a thread pool
        loop = asyncio.get_event_loop()
        
        def run_pipeline():
            pipeline = MeetingChatPipeline()
            return pipeline.run(
                mode=request.mode.value,
                since_date=since_date,
                limit=request.limit,
                retry_failed=request.retry_failed,
                min_messages=request.min_messages,
            )
        
        result = await loop.run_in_executor(_chat_executor, run_pipeline)
        
        return ChatRunResponse(
            status="success",
            message=f"Meeting chat pipeline completed ({request.mode.value} mode)",
            mode=request.mode.value,
            total_meetings=result.total_meetings,
            total_messages=result.total_messages,
            processed=result.processed,
            skipped=result.skipped,
            failed=result.failed,
            retried=result.retried,
            success_rate=result.success_rate,
            duration_seconds=result.duration_seconds,
            errors=result.errors[:10] if result.errors else [],
        )
        
    except Exception as e:
        print(f"[CHAT API] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Pipeline failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /chat/run-full - Run full chat sync (shortcut)
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/chat/run-full",
    response_model=ChatRunResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Run full meeting chat sync",
    description="Shortcut endpoint to run a full sync of all meeting chats. Use this for first run or reset."
)
async def run_chat_full_sync(
    limit: Optional[int] = None,
    retry_failed: bool = True,
    min_messages: int = 1
):
    """Run full meeting chat sync (first run or reset)."""
    request = ChatRunRequest(
        mode=ChatRunMode.FULL,
        limit=limit,
        retry_failed=retry_failed,
        min_messages=min_messages,
    )
    return await run_chat_pipeline(request)


# ─────────────────────────────────────────────────────────────────────────────
# POST /chat/run-incremental - Run incremental chat sync (shortcut)
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/chat/run-incremental",
    response_model=ChatRunResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Run incremental meeting chat sync",
    description="Shortcut endpoint to run an incremental sync. Only fetches new meeting chats since last successful run."
)
async def run_chat_incremental_sync(
    limit: Optional[int] = None,
    retry_failed: bool = True,
    min_messages: int = 1
):
    """Run incremental meeting chat sync (new meetings only)."""
    request = ChatRunRequest(
        mode=ChatRunMode.INCREMENTAL,
        limit=limit,
        retry_failed=retry_failed,
        min_messages=min_messages,
    )
    return await run_chat_pipeline(request)


# ─────────────────────────────────────────────────────────────────────────────
# POST /chat/run-since - Run chat sync from specific date (shortcut)
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/chat/run-since",
    response_model=ChatRunResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Run meeting chat sync from specific date",
    description="Shortcut endpoint to run sync from a specific date. Fetches all meeting chats since the specified date."
)
async def run_chat_since_date(
    since_date: str,
    limit: Optional[int] = None,
    retry_failed: bool = True,
    min_messages: int = 1
):
    """Run meeting chat sync from a specific date."""
    request = ChatRunRequest(
        mode=ChatRunMode.SINCE,
        since_date=since_date,
        limit=limit,
        retry_failed=retry_failed,
        min_messages=min_messages,
    )
    return await run_chat_pipeline(request)


# ─────────────────────────────────────────────────────────────────────────────
# GET /chat/records - List all chat records from DynamoDB
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/chat/records",
    response_model=ChatListResponse,
    tags=["Meeting Chat Pipeline"],
    summary="List all meeting chat records",
    description="Returns all meeting chat records from DynamoDB with their processing status."
)
def list_chat_records(
    status_filter: Optional[str] = None,
    limit: Optional[int] = None
):
    """List all meeting chat records from DynamoDB."""
    try:
        pipeline = MeetingChatPipeline()
        
        # Get stats
        stats = pipeline.tracker.get_processing_stats()
        
        # Get all chat records using the tracker
        dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        table_name = pipeline.tracker.table_name
        
        # Use get_all_dynamodb_records with CHAT filter
        items = get_dynamodb_records(dynamodb_client, table_name, record_type_filter="CHAT")
        
        all_records = []
        for item in items:
            # Handle both old (chat_id) and new (record_id) schema
            record_id = item.get("record_id", {}).get("S") or item.get("chat_id", {}).get("S", "")
            record = {
                "chat_id": record_id,
                "status": item.get("status", {}).get("S", ""),
                "meeting_subject": item.get("meeting_subject", {}).get("S", ""),
                "meeting_id": item.get("meeting_id", {}).get("S", ""),
                "message_count": int(item.get("message_count", {}).get("N", "0")),
                "s3_path": item.get("s3_path", {}).get("S", ""),
                "created_at": item.get("created_at", {}).get("S", ""),
                "updated_at": item.get("updated_at", {}).get("S", ""),
                "retry_count": int(item.get("retry_count", {}).get("N", "0")),
                "error_message": item.get("error_message", {}).get("S", ""),
            }
            
            # Apply status filter if provided
            if status_filter and record["status"].lower() != status_filter.lower():
                continue
            
            all_records.append(record)
        
        # Apply limit if provided
        if limit:
            all_records = all_records[:limit]
        
        return ChatListResponse(
            total_records=len(all_records),
            records=all_records,
            status_summary=stats,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list records: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /chat/files - List all chat files from S3
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/chat/files",
    response_model=ChatS3FileResponse,
    tags=["Meeting Chat Pipeline"],
    summary="List all meeting chat files in S3",
    description="Returns all meeting chat files stored in S3 with their metadata."
)
def list_chat_files(limit: Optional[int] = None):
    """List all meeting chat files from S3."""
    try:
        pipeline = MeetingChatPipeline()
        
        s3_client = boto3.client("s3", region_name="us-east-1")
        bucket_name = pipeline.config.s3_bucket_name
        prefix = pipeline.storage.prefix  # This should be {base_prefix}/chats/
        
        files = get_s3_files(s3_client, bucket_name, prefix)
        
        total_size = 0
        file_list = []
        
        for f in files:
            key = f.get("Key", "")
            size = f.get("Size", 0)
            last_modified = f.get("LastModified")
            
            # Only include DOCX files
            if not key.lower().endswith(".docx"):
                continue
            
            total_size += size
            
            file_info = {
                "key": key,
                "filename": key.replace(prefix, "") if key.startswith(prefix) else key,
                "size_bytes": size,
                "size_formatted": f"{size / 1024:.1f} KB" if size < 1024 * 1024 else f"{size / (1024*1024):.2f} MB",
                "last_modified": last_modified.isoformat() if last_modified else None,
            }
            file_list.append(file_info)
        
        # Apply limit if provided
        if limit:
            file_list = file_list[:limit]
        
        return ChatS3FileResponse(
            total_files=len(file_list),
            total_size_mb=round(total_size / (1024 * 1024), 2),
            files=file_list,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list files: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /chat/records - Cleanup DynamoDB chat records
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/chat/records",
    response_model=ChatCleanupResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Delete all meeting chat records from DynamoDB",
    description="⚠️ DANGER: Deletes ALL meeting chat tracking records from DynamoDB (preserves transcript records). Use with caution!"
)
def cleanup_chat_records(confirm: bool = False):
    """Delete all meeting chat records from DynamoDB."""
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="Set confirm=true to confirm deletion of all chat records"
        )
    
    try:
        pipeline = MeetingChatPipeline()
        
        dynamodb_client = boto3.client("dynamodb", region_name="us-east-1")
        table_name = pipeline.tracker.table_name
        
        # Get only CHAT records (not TRANSCRIPT records)
        items = get_dynamodb_records(dynamodb_client, table_name, record_type_filter="CHAT")
        
        # Also get CHAT_METADATA record
        metadata_items = get_dynamodb_records(dynamodb_client, table_name, record_type_filter="CHAT_METADATA")
        items.extend(metadata_items)
        
        if not items:
            return ChatCleanupResponse(
                status="success",
                message="No chat records to delete",
                deleted_count=0,
            )
        
        # Delete each record
        deleted_count = 0
        for item in items:
            # Handle both old (chat_id) and new (record_id) schema
            record_id = item.get("record_id", {}).get("S") or item.get("chat_id", {}).get("S")
            if record_id:
                try:
                    dynamodb_client.delete_item(
                        TableName=table_name,
                        Key={"record_id": {"S": record_id}}
                    )
                    deleted_count += 1
                except Exception as e:
                    print(f"Failed to delete {record_id}: {e}")
        
        return ChatCleanupResponse(
            status="success",
            message=f"Deleted {deleted_count} chat records from DynamoDB",
            deleted_count=deleted_count,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /chat/files - Cleanup S3 chat files
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/chat/files",
    response_model=ChatCleanupResponse,
    tags=["Meeting Chat Pipeline"],
    summary="Delete all meeting chat files from S3",
    description="⚠️ DANGER: Deletes ALL meeting chat files from S3 (preserves transcript files). Use with caution!"
)
def cleanup_chat_files(confirm: bool = False):
    """Delete all meeting chat files from S3."""
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="Set confirm=true to confirm deletion of all chat files"
        )
    
    try:
        pipeline = MeetingChatPipeline()
        
        s3_client = boto3.client("s3", region_name="us-east-1")
        bucket_name = pipeline.config.s3_bucket_name
        prefix = pipeline.storage.prefix  # This should be {base_prefix}/chats/
        
        # Get only files in the /chats/ prefix (not /transcripts/)
        files = get_s3_files(s3_client, bucket_name, prefix)
        
        if not files:
            return ChatCleanupResponse(
                status="success",
                message="No chat files to delete",
                deleted_count=0,
            )
        
        # Delete each file (only DOCX files in chat prefix)
        deleted_count = 0
        for f in files:
            key = f.get("Key")
            if key and key.lower().endswith(".docx"):
                try:
                    s3_client.delete_object(Bucket=bucket_name, Key=key)
                    deleted_count += 1
                except Exception as e:
                    print(f"Failed to delete {key}: {e}")
        
        return ChatCleanupResponse(
            status="success",
            message=f"Deleted {deleted_count} chat files from S3",
            deleted_count=deleted_count,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ============================================================================
# END OF MEETING CHAT PIPELINE API ENDPOINTS
# ============================================================================


# ============================================================================
# BATCH DATA INGESTION API ENDPOINTS (MODULAR v2.0)
# ============================================================================
# These endpoints allow triggering the batch S3 data ingestion pipeline
# from the UI dashboard or via Swagger for testing all command combinations.
# 
# The modular structure provides separate pipelines for:
# - Transcript Batch Ingestion (/batch/transcript/)
# - Chat Batch Ingestion (/batch/chat/)
# ============================================================================

from typing import Optional, List
from enum import Enum
from pydantic import BaseModel, Field
import asyncio
from concurrent.futures import ThreadPoolExecutor

# Import batch ingestion module functions from new modular structure
from batch_data_ingestion.core import (
    list_s3_files,
    extract_text_from_s3_file,
    clean_text_with_llm,
    generate_embedding,
    build_work_evidence_doc,
    index_to_opensearch,
    write_to_dynamodb,
    check_duplicate_in_opensearch as batch_check_duplicate_in_opensearch,
    generate_content_hash,
    get_source_type_for_folder,
    load_seeded_projects,
    match_project_with_llm,
    get_fresh_awsauth as ingestion_get_fresh_awsauth,
    get_dynamodb_resource as ingestion_get_dynamodb_resource,
    BUCKET_NAME as INGESTION_BUCKET_NAME,
    BASE_PREFIX as INGESTION_BASE_PREFIX,
    TRANSCRIPT_PREFIX as INGESTION_TRANSCRIPT_PREFIX,
    CHAT_PREFIX as INGESTION_CHAT_PREFIX,
    FOLDER_SOURCE_TYPE_MAP,
    OPENSEARCH_HOST as INGESTION_OPENSEARCH_HOST,
    OPENSEARCH_INDEX as INGESTION_OPENSEARCH_INDEX,
    DYNAMODB_WORK_ITEMS_TABLE as INGESTION_DYNAMODB_WORK_ITEMS_TABLE,
)

# Import transcript pipeline functions
from batch_data_ingestion.transcript.ingestion import process_transcript_folder
from batch_data_ingestion.transcript.verify import (
    run_verification as run_transcript_verification,
    get_opensearch_stats as get_transcript_opensearch_stats,
    get_opensearch_transcript_records,
    get_workitems_transcript_records,
)
from batch_data_ingestion.transcript.cleanup import (
    cleanup_duplicates as cleanup_transcript_duplicates,
    cleanup_all as cleanup_all_transcripts,
    cleanup_by_source_uri as cleanup_transcripts_by_source_uri,
    get_all_transcript_documents,
)

# Import chat pipeline functions
from batch_data_ingestion.chat.ingestion import process_chat_folder
from batch_data_ingestion.chat.verify import (
    run_verification as run_chat_verification,
    get_opensearch_stats as get_chat_opensearch_stats,
    get_opensearch_chat_records,
    get_workitems_chat_records,
)
from batch_data_ingestion.chat.cleanup import (
    cleanup_duplicates as cleanup_chat_duplicates,
    cleanup_all as cleanup_all_chats,
    cleanup_by_source_uri as cleanup_chats_by_source_uri,
    get_all_chat_documents,
)

# Thread pool for running sync functions in async context
_ingestion_executor = ThreadPoolExecutor(max_workers=2)


# ============================================================================
# TRANSCRIPT BATCH INGESTION API ENDPOINTS (New Modular Pipeline)
# ============================================================================
# Dedicated endpoints for transcript batch ingestion using the new modular
# batch_data_ingestion.transcript package.
# ============================================================================

# Request and Response models for transcript batch ingestion
class TranscriptBatchIngestionRequest(BaseModel):
    """Request model for transcript batch ingestion."""
    dry_run: bool = False
    verbose: bool = False
    limit: Optional[int] = None
    skip_existing: bool = True


class TranscriptBatchIngestionResponse(BaseModel):
    """Response model for transcript batch ingestion."""
    status: str
    message: str
    statistics: dict
    s3_prefix: str
    source_type: str = "meeting_transcript"
    dry_run: bool


class TranscriptBatchVerifyResponse(BaseModel):
    """Response model for transcript batch verification."""
    status: str
    opensearch_stats: dict
    workitems_count: int
    opensearch_records: Optional[List[dict]] = None
    workitems_records: Optional[List[dict]] = None


class TranscriptBatchCleanupResponse(BaseModel):
    """Response model for transcript batch cleanup."""
    status: str
    message: str
    operation: str
    dry_run: bool
    result: dict


class TranscriptBatchConfigResponse(BaseModel):
    """Response model for transcript batch configuration."""
    bucket_name: str
    s3_prefix: str
    source_type: str
    opensearch_index: str
    opensearch_host: str
    dynamodb_work_items_table: str


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/transcript/config - Get transcript batch ingestion configuration
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/transcript/config",
    response_model=TranscriptBatchConfigResponse,
    tags=["Transcript Batch Ingestion"],
    summary="Get transcript batch ingestion configuration",
    description="Returns the current configuration for the transcript batch ingestion pipeline."
)
def get_transcript_batch_config():
    """Get transcript batch ingestion configuration."""
    return TranscriptBatchConfigResponse(
        bucket_name=INGESTION_BUCKET_NAME,
        s3_prefix=INGESTION_TRANSCRIPT_PREFIX,
        source_type="meeting_transcript",
        opensearch_index=INGESTION_OPENSEARCH_INDEX,
        opensearch_host=INGESTION_OPENSEARCH_HOST,
        dynamodb_work_items_table=INGESTION_DYNAMODB_WORK_ITEMS_TABLE,
    )


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/transcript/status - Get transcript batch ingestion status
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/transcript/status",
    tags=["Transcript Batch Ingestion"],
    summary="Get transcript batch ingestion status",
    description="Returns the current status of transcript data in OpenSearch and DynamoDB."
)
async def get_transcript_batch_status():
    """Get transcript batch ingestion status."""
    try:
        # Get S3 file count
        s3_files = list_s3_files(INGESTION_BUCKET_NAME, INGESTION_TRANSCRIPT_PREFIX)
        
        # Get OpenSearch stats
        os_stats = get_transcript_opensearch_stats()
        
        # Get sample DynamoDB records
        workitems = get_workitems_transcript_records(limit=1)
        
        return {
            "status": "ready",
            "s3_files": {
                "bucket": INGESTION_BUCKET_NAME,
                "prefix": INGESTION_TRANSCRIPT_PREFIX,
                "file_count": len(s3_files),
            },
            "opensearch": os_stats,
            "dynamodb": {
                "work_items_table": INGESTION_DYNAMODB_WORK_ITEMS_TABLE,
                "workitems_count": len(workitems) if workitems else 0,
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get status: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/transcript/files - List transcript files in S3
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/transcript/files",
    tags=["Transcript Batch Ingestion"],
    summary="List transcript files in S3",
    description="Returns all transcript files in the S3 meetings/transcripts/ folder."
)
def list_transcript_batch_files(limit: Optional[int] = None):
    """List transcript files in S3."""
    try:
        files = list_s3_files(INGESTION_BUCKET_NAME, INGESTION_TRANSCRIPT_PREFIX)
        if limit:
            files = files[:limit]
        
        return {
            "bucket": INGESTION_BUCKET_NAME,
            "prefix": INGESTION_TRANSCRIPT_PREFIX,
            "total_files": len(files),
            "files": files
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list files: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/transcript/run - Run transcript batch ingestion
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/transcript/run",
    response_model=TranscriptBatchIngestionResponse,
    tags=["Transcript Batch Ingestion"],
    summary="Run transcript batch ingestion",
    description="""
    **Main endpoint to trigger the transcript batch ingestion pipeline.**
    
    This endpoint processes DOCX files from the S3 meetings/transcripts/ folder:
    1. Extract text from DOCX files
    2. Clean and structure with LLM
    3. Match to seeded projects
    4. Generate embeddings
    5. Index to OpenSearch
    6. Write to DynamoDB (WorkItems - single source of truth)
    
    **Options:**
    - `dry_run`: Preview what would happen without writing to databases
    - `verbose`: Get detailed logging (implies dry_run)
    - `limit`: Process only first N files (None = ALL files)
    - `skip_existing`: Skip files already indexed (deduplication)
    """
)
async def run_transcript_batch_ingestion(
    request: TranscriptBatchIngestionRequest = TranscriptBatchIngestionRequest()
):
    """Run transcript batch ingestion pipeline."""
    print(f"\n[TRANSCRIPT BATCH API] Starting transcript batch ingestion")
    print(f"  S3 Prefix: {INGESTION_TRANSCRIPT_PREFIX}")
    print(f"  Dry Run: {request.dry_run}")
    print(f"  Verbose: {request.verbose}")
    print(f"  Limit: {request.limit}")
    print(f"  Skip Existing: {request.skip_existing}")
    
    try:
        loop = asyncio.get_event_loop()
        stats = await loop.run_in_executor(
            _ingestion_executor,
            lambda: process_transcript_folder(
                prefix=INGESTION_TRANSCRIPT_PREFIX,
                dry_run=request.dry_run,
                limit=request.limit,
                skip_existing=request.skip_existing,
                verbose=request.verbose
            )
        )
        
        return TranscriptBatchIngestionResponse(
            status="success",
            message=f"Transcript batch ingestion completed",
            statistics=stats,
            s3_prefix=INGESTION_TRANSCRIPT_PREFIX,
            source_type="meeting_transcript",
            dry_run=request.dry_run or request.verbose
        )
    except Exception as e:
        print(f"[TRANSCRIPT BATCH API] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/transcript/verify - Verify transcript batch data
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/transcript/verify",
    response_model=TranscriptBatchVerifyResponse,
    tags=["Transcript Batch Ingestion"],
    summary="Verify transcript batch data",
    description="Verify ingested transcript data in OpenSearch and WorkItems."
)
def verify_transcript_batch_data(
    source_uri: Optional[str] = None,
    project: Optional[str] = None,
    limit: int = 10,
    include_records: bool = False
):
    """Verify transcript batch data in all stores."""
    try:
        # Get OpenSearch stats
        os_stats = get_transcript_opensearch_stats()
        
        # Get records
        os_records = get_opensearch_transcript_records(source_uri, project, limit)
        wi_records = get_workitems_transcript_records(source_uri, project, limit)
        
        response = TranscriptBatchVerifyResponse(
            status="success",
            opensearch_stats=os_stats,
            workitems_count=len(wi_records),
        )
        
        if include_records:
            response.opensearch_records = os_records
            response.workitems_records = wi_records
        
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/transcript/records - List transcript records from OpenSearch
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/transcript/records",
    tags=["Transcript Batch Ingestion"],
    summary="List transcript records from OpenSearch",
    description="Returns transcript records indexed in OpenSearch with optional filtering."
)
def list_transcript_batch_records(
    source_uri: Optional[str] = None,
    project: Optional[str] = None,
    limit: int = 20
):
    """List transcript records from OpenSearch."""
    try:
        records = get_opensearch_transcript_records(source_uri, project, limit)
        stats = get_transcript_opensearch_stats()
        
        return {
            "status": "success",
            "total_in_index": stats.get("total_transcripts", 0),
            "returned": len(records),
            "filters": {
                "source_uri": source_uri,
                "project": project,
            },
            "records": records
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list records: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /batch/transcript/cleanup/duplicates - Cleanup duplicate transcripts
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/batch/transcript/cleanup/duplicates",
    response_model=TranscriptBatchCleanupResponse,
    tags=["Transcript Batch Ingestion"],
    summary="Cleanup duplicate transcript records",
    description="Find and remove duplicate transcript documents from OpenSearch (keeps oldest, deletes newer duplicates)."
)
async def cleanup_transcript_batch_duplicates(dry_run: bool = True):
    """Cleanup duplicate transcript records."""
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _ingestion_executor,
            lambda: cleanup_transcript_duplicates(dry_run=dry_run)
        )
        
        return TranscriptBatchCleanupResponse(
            status="success",
            message=f"Duplicate cleanup {'preview' if dry_run else 'completed'}",
            operation="cleanup_duplicates",
            dry_run=dry_run,
            result=result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /batch/transcript/cleanup/all - Delete all transcript batch data
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/batch/transcript/cleanup/all",
    response_model=TranscriptBatchCleanupResponse,
    tags=["Transcript Batch Ingestion"],
    summary="Delete ALL transcript batch data",
    description="⚠️ DANGER: Delete all transcript data from OpenSearch and WorkItems. Use with extreme caution!"
)
async def cleanup_all_transcript_batch_data(confirm: bool = False, force: bool = False):
    """Delete all transcript batch data."""
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="Set confirm=true to confirm deletion of ALL transcript data"
        )
    
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _ingestion_executor,
            lambda: cleanup_all_transcripts(dry_run=False, force=force)
        )
        
        return TranscriptBatchCleanupResponse(
            status="success",
            message="All transcript batch data deleted",
            operation="cleanup_all",
            dry_run=False,
            result=result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /batch/transcript/cleanup/by-source - Delete by source URI pattern
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/batch/transcript/cleanup/by-source",
    response_model=TranscriptBatchCleanupResponse,
    tags=["Transcript Batch Ingestion"],
    summary="Delete transcript data by source URI",
    description="Delete transcript data matching a specific source URI pattern."
)
async def cleanup_transcript_batch_by_source(
    source_uri: str,
    dry_run: bool = True
):
    """Delete transcript data by source URI pattern."""
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _ingestion_executor,
            lambda: cleanup_transcripts_by_source_uri(source_uri, dry_run=dry_run)
        )
        
        return TranscriptBatchCleanupResponse(
            status="success",
            message=f"Cleanup by source URI {'preview' if dry_run else 'completed'}",
            operation="cleanup_by_source_uri",
            dry_run=dry_run,
            result=result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/transcript/process-file - Process a single transcript file
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/transcript/process-file",
    tags=["Transcript Batch Ingestion"],
    summary="Process a single transcript file",
    description="Process a specific transcript file through the ingestion pipeline. Useful for testing or reprocessing specific files."
)
async def process_single_transcript_file(
    s3_key: str,
    dry_run: bool = False
):
    """Process a single transcript file through the ingestion pipeline."""
    source_type = "meeting_transcript"
    
    print(f"\n[TRANSCRIPT BATCH API] Processing single file: {s3_key}")
    print(f"  Source Type: {source_type}")
    print(f"  Dry Run: {dry_run}")
    
    try:
        # Step 1: Extract text
        raw_text = extract_text_from_s3_file(INGESTION_BUCKET_NAME, s3_key)
        if not raw_text or not raw_text.strip():
            return {
                "status": "error",
                "message": "No text could be extracted from the file",
                "s3_key": s3_key,
                "source_type": source_type
            }
        
        # Step 2: Generate content hash
        content_hash = generate_content_hash(raw_text)
        
        # Step 3: Check for duplicates
        if not dry_run:
            is_duplicate = batch_check_duplicate_in_opensearch(content_hash)
            if is_duplicate:
                return {
                    "status": "skipped",
                    "message": "Duplicate document already exists in OpenSearch",
                    "s3_key": s3_key,
                    "source_type": source_type,
                    "content_hash": content_hash
                }
        
        # Step 4: Clean with LLM
        cleaned_json = clean_text_with_llm(raw_text, source_type)
        summary = cleaned_json.get("summary", raw_text[:300])
        action_items = cleaned_json.get("action_items", [])
        decisions = cleaned_json.get("decisions", [])
        
        # Step 5: Generate embedding
        embedding = generate_embedding(cleaned_json.get("clean_text", raw_text)[:8000])
        
        opensearch_indexed = False
        dynamodb_items = 0
        
        if not dry_run:
            # Step 6: Build and index OpenSearch document
            source_uri = f"s3://{INGESTION_BUCKET_NAME}/{s3_key}"
            os_doc = build_work_evidence_doc(
                cleaned_json=cleaned_json,
                source_uri=source_uri,
                source_type=source_type,
                content_hash=content_hash,
                embedding=embedding
            )
            
            os_result = index_to_opensearch(os_doc)
            opensearch_indexed = os_result["status_code"] in [200, 201]
            
            # Step 7: Write to DynamoDB
            dynamodb_items = write_to_dynamodb(
                cleaned_json=cleaned_json,
                source_uri=source_uri,
                source_type=source_type,
                summary=summary
            )
        
        return {
            "status": "success",
            "message": "File processed successfully",
            "s3_key": s3_key,
            "source_type": source_type,
            "content_hash": content_hash,
            "summary": summary[:500] if summary else None,
            "action_items_count": len(action_items),
            "decisions_count": len(decisions),
            "opensearch_indexed": opensearch_indexed,
            "dynamodb_items_written": dynamodb_items,
            "dry_run": dry_run
        }
        
    except Exception as e:
        print(f"[TRANSCRIPT BATCH API] Error processing file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to process file: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/transcript/extract-text - Extract text from transcript file
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/transcript/extract-text",
    tags=["Transcript Batch Ingestion"],
    summary="Extract text from a transcript file",
    description="Extract and preview the raw text content from a transcript file without processing it through the full pipeline."
)
def extract_transcript_text(s3_key: str):
    """Extract text from a transcript file for preview."""
    try:
        raw_text = extract_text_from_s3_file(INGESTION_BUCKET_NAME, s3_key)
        if not raw_text:
            return {
                "status": "error",
                "message": "No text could be extracted",
                "s3_key": s3_key
            }
        
        return {
            "status": "success",
            "s3_key": s3_key,
            "source_type": "meeting_transcript",
            "text_length": len(raw_text),
            "text_preview": raw_text[:2000],
            "full_text": raw_text
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract text: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/transcript/clean-text - Clean transcript text with LLM
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/transcript/clean-text",
    tags=["Transcript Batch Ingestion"],
    summary="Clean transcript text with LLM",
    description="Process raw transcript text through the LLM cleaning pipeline to extract structured data, action items, and decisions."
)
def clean_transcript_text(raw_text: str):
    """Clean raw transcript text using the LLM and return structured output."""
    try:
        cleaned_json = clean_text_with_llm(raw_text, "meeting_transcript")
        return {
            "status": "success",
            "source_type": "meeting_transcript",
            "cleaned_data": cleaned_json,
            "summary": cleaned_json.get("summary", ""),
            "action_items_count": len(cleaned_json.get("action_items", [])),
            "decisions_count": len(cleaned_json.get("decisions", []))
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"LLM cleaning failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/transcript/check-duplicate - Check if transcript is duplicate
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/transcript/check-duplicate",
    tags=["Transcript Batch Ingestion"],
    summary="Check if transcript content is a duplicate",
    description="Generate content hash and check if a transcript with the same hash already exists in OpenSearch."
)
def check_transcript_duplicate(content: str):
    """Check if the given transcript content already exists in OpenSearch."""
    content_hash = generate_content_hash(content)
    is_duplicate = batch_check_duplicate_in_opensearch(content_hash)
    
    return {
        "content_hash": content_hash,
        "is_duplicate": is_duplicate,
        "message": "Duplicate found in OpenSearch" if is_duplicate else "No duplicate found"
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/transcript/generate-embedding - Generate embedding for transcript
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/transcript/generate-embedding",
    tags=["Transcript Batch Ingestion"],
    summary="Generate embedding for transcript text",
    description="Generate a vector embedding using Amazon Titan v2 for the given transcript text. Returns embedding statistics."
)
def generate_transcript_embedding(text: str):
    """Generate embedding for the given transcript text."""
    try:
        text_truncated = text[:8000]
        embedding = generate_embedding(text_truncated)
        
        return {
            "status": "success",
            "text_length": len(text),
            "text_truncated_length": len(text_truncated),
            "embedding_dimension": len(embedding),
            "embedding_preview": {
                "first_5": embedding[:5],
                "last_5": embedding[-5:],
                "min": min(embedding),
                "max": max(embedding),
                "mean": sum(embedding) / len(embedding)
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Embedding generation failed: {str(e)}")


# ============================================================================
# END OF TRANSCRIPT BATCH INGESTION API ENDPOINTS
# ============================================================================


# ============================================================================
# CHAT BATCH INGESTION API ENDPOINTS (New Modular Pipeline)
# ============================================================================
# Dedicated endpoints for chat batch ingestion using the new modular
# batch_data_ingestion.chat package.
# ============================================================================

# Request and Response models for chat batch ingestion
class ChatBatchIngestionRequest(BaseModel):
    """Request model for chat batch ingestion."""
    dry_run: bool = False
    verbose: bool = False
    limit: Optional[int] = None
    skip_existing: bool = True


class ChatBatchIngestionResponse(BaseModel):
    """Response model for chat batch ingestion."""
    status: str
    message: str
    statistics: dict
    s3_prefix: str
    source_type: str = "meeting_chat"
    dry_run: bool


class ChatBatchVerifyResponse(BaseModel):
    """Response model for chat batch verification."""
    status: str
    opensearch_stats: dict
    workitems_count: int
    opensearch_records: Optional[List[dict]] = None
    workitems_records: Optional[List[dict]] = None


class ChatBatchCleanupResponse(BaseModel):
    """Response model for chat batch cleanup."""
    status: str
    message: str
    operation: str
    dry_run: bool
    result: dict


class ChatBatchConfigResponse(BaseModel):
    """Response model for chat batch configuration."""
    bucket_name: str
    s3_prefix: str
    source_type: str
    opensearch_index: str
    opensearch_host: str
    dynamodb_work_items_table: str


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/chat/config - Get chat batch ingestion configuration
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/chat/config",
    response_model=ChatBatchConfigResponse,
    tags=["Chat Batch Ingestion"],
    summary="Get chat batch ingestion configuration",
    description="Returns the current configuration for the chat batch ingestion pipeline."
)
def get_chat_batch_config():
    """Get chat batch ingestion configuration."""
    return ChatBatchConfigResponse(
        bucket_name=INGESTION_BUCKET_NAME,
        s3_prefix=INGESTION_CHAT_PREFIX,
        source_type="meeting_chat",
        opensearch_index=INGESTION_OPENSEARCH_INDEX,
        opensearch_host=INGESTION_OPENSEARCH_HOST,
        dynamodb_work_items_table=INGESTION_DYNAMODB_WORK_ITEMS_TABLE,
    )


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/chat/status - Get chat batch ingestion status
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/chat/status",
    tags=["Chat Batch Ingestion"],
    summary="Get chat batch ingestion status",
    description="Returns the current status of chat data in OpenSearch and DynamoDB."
)
async def get_chat_batch_status():
    """Get chat batch ingestion status."""
    try:
        # Get S3 file count
        s3_files = list_s3_files(INGESTION_BUCKET_NAME, INGESTION_CHAT_PREFIX)
        
        # Get OpenSearch stats
        os_stats = get_chat_opensearch_stats()
        
        # Get sample DynamoDB records
        workitems = get_workitems_chat_records(limit=1)
        
        return {
            "status": "ready",
            "s3_files": {
                "bucket": INGESTION_BUCKET_NAME,
                "prefix": INGESTION_CHAT_PREFIX,
                "file_count": len(s3_files),
            },
            "opensearch": os_stats,
            "dynamodb": {
                "work_items_table": INGESTION_DYNAMODB_WORK_ITEMS_TABLE,
                "workitems_count": len(workitems) if workitems else 0,
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get status: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/chat/files - List chat files in S3
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/chat/files",
    tags=["Chat Batch Ingestion"],
    summary="List chat files in S3",
    description="Returns all chat files in the S3 meetings/chats/ folder."
)
def list_chat_batch_files(limit: Optional[int] = None):
    """List chat files in S3."""
    try:
        files = list_s3_files(INGESTION_BUCKET_NAME, INGESTION_CHAT_PREFIX)
        if limit:
            files = files[:limit]
        
        return {
            "bucket": INGESTION_BUCKET_NAME,
            "prefix": INGESTION_CHAT_PREFIX,
            "total_files": len(files),
            "files": files
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list files: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/chat/run - Run chat batch ingestion
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/chat/run",
    response_model=ChatBatchIngestionResponse,
    tags=["Chat Batch Ingestion"],
    summary="Run chat batch ingestion",
    description="""
    **Main endpoint to trigger the chat batch ingestion pipeline.**
    
    This endpoint processes DOCX files from the S3 meetings/chats/ folder:
    1. Extract text from DOCX files
    2. Clean and structure with LLM (chat-specific prompts)
    3. Match to seeded projects
    4. Generate embeddings
    5. Index to OpenSearch
    6. Write to DynamoDB (WorkItems - single source of truth)
    
    **Options:**
    - `dry_run`: Preview what would happen without writing to databases
    - `verbose`: Get detailed logging (implies dry_run)
    - `limit`: Process only first N files (None = ALL files)
    - `skip_existing`: Skip files already indexed (deduplication)
    """
)
async def run_chat_batch_ingestion(
    request: ChatBatchIngestionRequest = ChatBatchIngestionRequest()
):
    """Run chat batch ingestion pipeline."""
    print(f"\n[CHAT BATCH API] Starting chat batch ingestion")
    print(f"  S3 Prefix: {INGESTION_CHAT_PREFIX}")
    print(f"  Dry Run: {request.dry_run}")
    print(f"  Verbose: {request.verbose}")
    print(f"  Limit: {request.limit}")
    print(f"  Skip Existing: {request.skip_existing}")
    
    try:
        loop = asyncio.get_event_loop()
        stats = await loop.run_in_executor(
            _ingestion_executor,
            lambda: process_chat_folder(
                prefix=INGESTION_CHAT_PREFIX,
                dry_run=request.dry_run,
                limit=request.limit,
                skip_existing=request.skip_existing,
                verbose=request.verbose
            )
        )
        
        return ChatBatchIngestionResponse(
            status="success",
            message=f"Chat batch ingestion completed",
            statistics=stats,
            s3_prefix=INGESTION_CHAT_PREFIX,
            source_type="meeting_chat",
            dry_run=request.dry_run or request.verbose
        )
    except Exception as e:
        print(f"[CHAT BATCH API] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/chat/verify - Verify chat batch data
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/chat/verify",
    response_model=ChatBatchVerifyResponse,
    tags=["Chat Batch Ingestion"],
    summary="Verify chat batch data",
    description="Verify ingested chat data in OpenSearch and WorkItems."
)
def verify_chat_batch_data(
    source_uri: Optional[str] = None,
    project: Optional[str] = None,
    limit: int = 10,
    include_records: bool = False
):
    """Verify chat batch data in all stores."""
    try:
        # Get OpenSearch stats
        os_stats = get_chat_opensearch_stats()
        
        # Get records
        os_records = get_opensearch_chat_records(source_uri, project, limit)
        wi_records = get_workitems_chat_records(source_uri, project, limit)
        
        response = ChatBatchVerifyResponse(
            status="success",
            opensearch_stats=os_stats,
            workitems_count=len(wi_records),
        )
        
        if include_records:
            response.opensearch_records = os_records
            response.workitems_records = wi_records
        
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# GET /batch/chat/records - List chat records from OpenSearch
# ─────────────────────────────────────────────────────────────────────────────
@app.get(
    "/batch/chat/records",
    tags=["Chat Batch Ingestion"],
    summary="List chat records from OpenSearch",
    description="Returns chat records indexed in OpenSearch with optional filtering."
)
def list_chat_batch_records(
    source_uri: Optional[str] = None,
    project: Optional[str] = None,
    limit: int = 20
):
    """List chat records from OpenSearch."""
    try:
        records = get_opensearch_chat_records(source_uri, project, limit)
        stats = get_chat_opensearch_stats()
        
        return {
            "status": "success",
            "total_in_index": stats.get("total_chats", 0),
            "returned": len(records),
            "filters": {
                "source_uri": source_uri,
                "project": project,
            },
            "records": records
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list records: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /batch/chat/cleanup/duplicates - Cleanup duplicate chats
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/batch/chat/cleanup/duplicates",
    response_model=ChatBatchCleanupResponse,
    tags=["Chat Batch Ingestion"],
    summary="Cleanup duplicate chat records",
    description="Find and remove duplicate chat documents from OpenSearch (keeps oldest, deletes newer duplicates)."
)
async def cleanup_chat_batch_duplicates(dry_run: bool = True):
    """Cleanup duplicate chat records."""
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _ingestion_executor,
            lambda: cleanup_chat_duplicates(dry_run=dry_run)
        )
        
        return ChatBatchCleanupResponse(
            status="success",
            message=f"Duplicate cleanup {'preview' if dry_run else 'completed'}",
            operation="cleanup_duplicates",
            dry_run=dry_run,
            result=result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /batch/chat/cleanup/all - Delete all chat batch data
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/batch/chat/cleanup/all",
    response_model=ChatBatchCleanupResponse,
    tags=["Chat Batch Ingestion"],
    summary="Delete ALL chat batch data",
    description="⚠️ DANGER: Delete all chat data from OpenSearch and WorkItems. Use with extreme caution!"
)
async def cleanup_all_chat_batch_data(confirm: bool = False, force: bool = False):
    """Delete all chat batch data."""
    if not confirm:
        raise HTTPException(
            status_code=400,
            detail="Set confirm=true to confirm deletion of ALL chat data"
        )
    
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _ingestion_executor,
            lambda: cleanup_all_chats(dry_run=False, force=force)
        )
        
        return ChatBatchCleanupResponse(
            status="success",
            message="All chat batch data deleted",
            operation="cleanup_all",
            dry_run=False,
            result=result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# DELETE /batch/chat/cleanup/by-source - Delete by source URI pattern
# ─────────────────────────────────────────────────────────────────────────────
@app.delete(
    "/batch/chat/cleanup/by-source",
    response_model=ChatBatchCleanupResponse,
    tags=["Chat Batch Ingestion"],
    summary="Delete chat data by source URI",
    description="Delete chat data matching a specific source URI pattern."
)
async def cleanup_chat_batch_by_source(
    source_uri: str,
    dry_run: bool = True
):
    """Delete chat data by source URI pattern."""
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _ingestion_executor,
            lambda: cleanup_chats_by_source_uri(source_uri, dry_run=dry_run)
        )
        
        return ChatBatchCleanupResponse(
            status="success",
            message=f"Cleanup by source URI {'preview' if dry_run else 'completed'}",
            operation="cleanup_by_source_uri",
            dry_run=dry_run,
            result=result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cleanup failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/chat/process-file - Process a single chat file
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/chat/process-file",
    tags=["Chat Batch Ingestion"],
    summary="Process a single chat file",
    description="Process a specific chat file through the ingestion pipeline. Useful for testing or reprocessing specific files."
)
async def process_single_chat_file(
    s3_key: str,
    dry_run: bool = False
):
    """Process a single chat file through the ingestion pipeline."""
    source_type = "meeting_chat"
    
    print(f"\n[CHAT BATCH API] Processing single file: {s3_key}")
    print(f"  Source Type: {source_type}")
    print(f"  Dry Run: {dry_run}")
    
    try:
        # Step 1: Extract text
        raw_text = extract_text_from_s3_file(INGESTION_BUCKET_NAME, s3_key)
        if not raw_text or not raw_text.strip():
            return {
                "status": "error",
                "message": "No text could be extracted from the file",
                "s3_key": s3_key,
                "source_type": source_type
            }
        
        # Step 2: Generate content hash
        content_hash = generate_content_hash(raw_text)
        
        # Step 3: Check for duplicates
        if not dry_run:
            is_duplicate = batch_check_duplicate_in_opensearch(content_hash)
            if is_duplicate:
                return {
                    "status": "skipped",
                    "message": "Duplicate document already exists in OpenSearch",
                    "s3_key": s3_key,
                    "source_type": source_type,
                    "content_hash": content_hash
                }
        
        # Step 4: Clean with LLM
        cleaned_json = clean_text_with_llm(raw_text, source_type)
        summary = cleaned_json.get("summary", raw_text[:300])
        action_items = cleaned_json.get("action_items", [])
        decisions = cleaned_json.get("decisions", [])
        
        # Step 5: Generate embedding
        embedding = generate_embedding(cleaned_json.get("clean_text", raw_text)[:8000])
        
        opensearch_indexed = False
        dynamodb_items = 0
        
        if not dry_run:
            # Step 6: Build and index OpenSearch document
            source_uri = f"s3://{INGESTION_BUCKET_NAME}/{s3_key}"
            os_doc = build_work_evidence_doc(
                cleaned_json=cleaned_json,
                source_uri=source_uri,
                source_type=source_type,
                content_hash=content_hash,
                embedding=embedding
            )
            
            os_result = index_to_opensearch(os_doc)
            opensearch_indexed = os_result["status_code"] in [200, 201]
            
            # Step 7: Write to DynamoDB
            dynamodb_items = write_to_dynamodb(
                cleaned_json=cleaned_json,
                source_uri=source_uri,
                source_type=source_type,
                summary=summary
            )
        
        return {
            "status": "success",
            "message": "File processed successfully",
            "s3_key": s3_key,
            "source_type": source_type,
            "content_hash": content_hash,
            "summary": summary[:500] if summary else None,
            "action_items_count": len(action_items),
            "decisions_count": len(decisions),
            "opensearch_indexed": opensearch_indexed,
            "dynamodb_items_written": dynamodb_items,
            "dry_run": dry_run
        }
        
    except Exception as e:
        print(f"[CHAT BATCH API] Error processing file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to process file: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/chat/extract-text - Extract text from chat file
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/chat/extract-text",
    tags=["Chat Batch Ingestion"],
    summary="Extract text from a chat file",
    description="Extract and preview the raw text content from a chat file without processing it through the full pipeline."
)
def extract_chat_text(s3_key: str):
    """Extract text from a chat file for preview."""
    try:
        raw_text = extract_text_from_s3_file(INGESTION_BUCKET_NAME, s3_key)
        if not raw_text:
            return {
                "status": "error",
                "message": "No text could be extracted",
                "s3_key": s3_key
            }
        
        return {
            "status": "success",
            "s3_key": s3_key,
            "source_type": "meeting_chat",
            "text_length": len(raw_text),
            "text_preview": raw_text[:2000],
            "full_text": raw_text
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract text: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/chat/clean-text - Clean chat text with LLM
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/chat/clean-text",
    tags=["Chat Batch Ingestion"],
    summary="Clean chat text with LLM",
    description="Process raw chat text through the LLM cleaning pipeline to extract structured data, action items, and decisions."
)
def clean_chat_text(raw_text: str):
    """Clean raw chat text using the LLM and return structured output."""
    try:
        cleaned_json = clean_text_with_llm(raw_text, "meeting_chat")
        return {
            "status": "success",
            "source_type": "meeting_chat",
            "cleaned_data": cleaned_json,
            "summary": cleaned_json.get("summary", ""),
            "action_items_count": len(cleaned_json.get("action_items", [])),
            "decisions_count": len(cleaned_json.get("decisions", []))
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"LLM cleaning failed: {str(e)}")


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/chat/check-duplicate - Check if chat is duplicate
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/chat/check-duplicate",
    tags=["Chat Batch Ingestion"],
    summary="Check if chat content is a duplicate",
    description="Generate content hash and check if a chat with the same hash already exists in OpenSearch."
)
def check_chat_duplicate(content: str):
    """Check if the given chat content already exists in OpenSearch."""
    content_hash = generate_content_hash(content)
    is_duplicate = batch_check_duplicate_in_opensearch(content_hash)
    
    return {
        "content_hash": content_hash,
        "is_duplicate": is_duplicate,
        "message": "Duplicate found in OpenSearch" if is_duplicate else "No duplicate found"
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST /batch/chat/generate-embedding - Generate embedding for chat
# ─────────────────────────────────────────────────────────────────────────────
@app.post(
    "/batch/chat/generate-embedding",
    tags=["Chat Batch Ingestion"],
    summary="Generate embedding for chat text",
    description="Generate a vector embedding using Amazon Titan v2 for the given chat text. Returns embedding statistics."
)
def generate_chat_embedding(text: str):
    """Generate embedding for the given chat text."""
    try:
        text_truncated = text[:8000]
        embedding = generate_embedding(text_truncated)
        
        return {
            "status": "success",
            "text_length": len(text),
            "text_truncated_length": len(text_truncated),
            "embedding_dimension": len(embedding),
            "embedding_preview": {
                "first_5": embedding[:5],
                "last_5": embedding[-5:],
                "min": min(embedding),
                "max": max(embedding),
                "mean": sum(embedding) / len(embedding)
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Embedding generation failed: {str(e)}")


# ============================================================================
# END OF CHAT BATCH INGESTION API ENDPOINTS
# ============================================================================


# ============================================================================
# END OF BATCH DATA INGESTION API ENDPOINTS
# ============================================================================


# ============================================================================
# PROJECT SEEDING API ENDPOINTS
# ============================================================================
# These endpoints provide CRUD operations for managing projects.
# Projects can have associated files (documents, configs, etc.).
# ============================================================================

from project_seeding.projects_service import (
    create_project as service_create_project,
    get_project as service_get_project,
    get_all_projects as service_get_all_projects,
    update_project as service_update_project,
    delete_project as service_delete_project,
    add_file_to_project as service_add_file,
    remove_file_from_project as service_remove_file,
    get_file_from_project as service_get_file,
    verify_table_exists as service_verify_table,
    search_projects_by_name as service_search_projects,
    ProjectNotFoundError,
    ProjectServiceError,
)


# ── Pydantic Models for Projects API ──────────────────────────────────────────

class ProjectFileInput(BaseModel):
    """File input for project creation/update."""
    file_name: str = Field(..., description="Name of the file")
    file_type: str = Field(..., description="File type/extension (e.g., 'txt', 'pdf', 'json')")
    file_content: str = Field(..., description="Content of the file (text or base64 encoded)")


class ProjectCreateRequest(BaseModel):
    """Request model for creating a new project."""
    project_name: str = Field(..., min_length=1, max_length=200, description="Name of the project")
    project_description: str = Field(..., min_length=1, max_length=2000, description="Description of the project")
    files: Optional[List[ProjectFileInput]] = Field(default=None, description="Optional list of files to attach")


class ProjectUpdateRequest(BaseModel):
    """Request model for updating a project."""
    project_name: Optional[str] = Field(default=None, min_length=1, max_length=200, description="New project name")
    project_description: Optional[str] = Field(default=None, min_length=1, max_length=2000, description="New project description")
    status: Optional[str] = Field(default=None, description="New status (e.g., 'active', 'archived')")


class ProjectFileResponse(BaseModel):
    """Response model for a file."""
    file_id: str
    file_name: str
    file_type: str
    file_content: Optional[str] = None
    uploaded_at: str


class ProjectResponse(BaseModel):
    """Response model for a single project."""
    project_id: str
    project_name: str
    project_description: str
    status: str
    created_at: str
    updated_at: str
    file_count: int
    files: Optional[List[ProjectFileResponse]] = None


class ProjectListResponse(BaseModel):
    """Response model for listing projects."""
    total: int
    projects: List[ProjectResponse]


class ProjectFileAddRequest(BaseModel):
    """Request model for adding a file to a project."""
    file_name: str = Field(..., description="Name of the file")
    file_type: str = Field(..., description="File type/extension")
    file_content: str = Field(..., description="Content of the file")


class ProjectTableStatusResponse(BaseModel):
    """Response model for table status verification."""
    table_name: str
    status: str
    item_count: int
    size_bytes: int
    gsis: List[str]


# ── Projects API Endpoints ────────────────────────────────────────────────────

@app.post(
    "/projects",
    tags=["Projects"],
    summary="Create a new project",
    description="Create a new project with optional file attachments.",
    response_model=ProjectResponse
)
def create_project_endpoint(request: ProjectCreateRequest):
    """Create a new project."""
    try:
        files = None
        if request.files:
            files = [
                {
                    "file_name": f.file_name,
                    "file_type": f.file_type,
                    "file_content": f.file_content
                }
                for f in request.files
            ]
        
        project = service_create_project(
            project_name=request.project_name,
            project_description=request.project_description,
            files=files
        )
        
        print(f"[PROJECTS] Created project: {project['project_id']} - {project['project_name']}")
        return project
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get(
    "/projects",
    tags=["Projects"],
    summary="List all projects",
    description="Retrieve all projects with optional filtering and pagination.",
    response_model=ProjectListResponse
)
def list_projects_endpoint(
    limit: Optional[int] = None,
    status: Optional[str] = None,
    search: Optional[str] = None
):
    """List all projects with optional filtering."""
    try:
        if search:
            projects = service_search_projects(search)
        else:
            projects = service_get_all_projects(limit=limit, status_filter=status)
        
        print(f"[PROJECTS] Listed {len(projects)} projects")
        return {
            "total": len(projects),
            "projects": projects
        }
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get(
    "/projects/verify",
    tags=["Projects"],
    summary="Verify projects table",
    description="Check if the DynamoDB projects table exists and return status information.",
    response_model=ProjectTableStatusResponse
)
def verify_projects_table_endpoint():
    """Verify the projects table exists."""
    try:
        info = service_verify_table()
        return info
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get(
    "/projects/{project_id}",
    tags=["Projects"],
    summary="Get a project by ID",
    description="Retrieve a single project by its ID including all attached files.",
    response_model=ProjectResponse
)
def get_project_endpoint(project_id: str):
    """Get a specific project by ID."""
    try:
        project = service_get_project(project_id)
        if not project:
            raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
        
        print(f"[PROJECTS] Retrieved project: {project_id}")
        return project
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.put(
    "/projects/{project_id}",
    tags=["Projects"],
    summary="Update a project",
    description="Update a project's name, description, or status.",
    response_model=ProjectResponse
)
def update_project_endpoint(project_id: str, request: ProjectUpdateRequest):
    """Update a project."""
    try:
        # Ensure at least one field is being updated
        if not any([request.project_name, request.project_description, request.status]):
            raise HTTPException(
                status_code=400, 
                detail="At least one field (project_name, project_description, or status) must be provided"
            )
        
        project = service_update_project(
            project_id=project_id,
            project_name=request.project_name,
            project_description=request.project_description,
            status=request.status
        )
        
        print(f"[PROJECTS] Updated project: {project_id}")
        return project
    except ProjectNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete(
    "/projects/{project_id}",
    tags=["Projects"],
    summary="Delete a project",
    description="Permanently delete a project and all its attached files."
)
def delete_project_endpoint(project_id: str):
    """Delete a project."""
    try:
        service_delete_project(project_id)
        print(f"[PROJECTS] Deleted project: {project_id}")
        return {"status": "deleted", "project_id": project_id}
    except ProjectNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── File Operations ───────────────────────────────────────────────────────────

@app.post(
    "/projects/{project_id}/files",
    tags=["Projects"],
    summary="Add a file to a project",
    description="Upload and attach a new file to an existing project."
)
def add_file_to_project_endpoint(project_id: str, request: ProjectFileAddRequest):
    """Add a file to a project."""
    try:
        file_record = service_add_file(
            project_id=project_id,
            file_name=request.file_name,
            file_type=request.file_type,
            file_content=request.file_content
        )
        
        print(f"[PROJECTS] Added file to project {project_id}: {file_record['file_id']}")
        return {
            "status": "added",
            "project_id": project_id,
            "file": file_record
        }
    except ProjectNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post(
    "/projects/{project_id}/files/upload",
    tags=["Projects"],
    summary="Upload a file to a project",
    description="Upload a file using multipart form data and attach it to a project."
)
async def upload_file_to_project_endpoint(
    project_id: str,
    file: UploadFile = File(...)
):
    """Upload a file to a project using multipart form."""
    try:
        # Verify project exists first
        project = service_get_project(project_id)
        if not project:
            raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
        
        # Read file content
        contents = await file.read()
        
        # Determine file type from filename
        file_name = file.filename or "unnamed"
        file_type = file_name.split(".")[-1] if "." in file_name else "txt"
        
        # Try to decode as text, fall back to base64 for binary files
        try:
            file_content = contents.decode("utf-8")
        except UnicodeDecodeError:
            import base64
            file_content = base64.b64encode(contents).decode("utf-8")
        
        file_record = service_add_file(
            project_id=project_id,
            file_name=file_name,
            file_type=file_type,
            file_content=file_content
        )
        
        print(f"[PROJECTS] Uploaded file to project {project_id}: {file_record['file_id']}")
        return {
            "status": "uploaded",
            "project_id": project_id,
            "file": file_record
        }
    except ProjectNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get(
    "/projects/{project_id}/files/{file_id}",
    tags=["Projects"],
    summary="Get a file from a project",
    description="Retrieve a specific file from a project by file ID."
)
def get_file_from_project_endpoint(project_id: str, file_id: str):
    """Get a specific file from a project."""
    try:
        file_record = service_get_file(project_id, file_id)
        if not file_record:
            raise HTTPException(status_code=404, detail=f"File not found: {file_id}")
        
        return file_record
    except ProjectNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.delete(
    "/projects/{project_id}/files/{file_id}",
    tags=["Projects"],
    summary="Remove a file from a project",
    description="Remove a specific file from a project."
)
def remove_file_from_project_endpoint(project_id: str, file_id: str):
    """Remove a file from a project."""
    try:
        service_remove_file(project_id, file_id)
        print(f"[PROJECTS] Removed file {file_id} from project {project_id}")
        return {
            "status": "removed",
            "project_id": project_id,
            "file_id": file_id
        }
    except ProjectNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ProjectServiceError as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# END OF PROJECT SEEDING API ENDPOINTS
# ============================================================================


app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def serve_index():
    return FileResponse("static/index.html")

