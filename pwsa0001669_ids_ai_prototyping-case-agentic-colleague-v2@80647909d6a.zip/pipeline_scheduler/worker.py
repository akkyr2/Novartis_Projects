"""
Pipeline Worker with Queue and Locking Mechanism
=================================================
Single-worker queue processor that prevents overlapping pipeline executions.

This worker:
1. Listens to a job queue (file-based for simplicity, Redis-compatible)
2. Processes one job at a time with file-based locking
3. Skips duplicate jobs if a job is already running
4. Logs all executions for monitoring

Lock Mechanism:
- Uses a file-based lock (/tmp/pipeline.lock or configurable)
- Only one worker can hold the lock at a time
- If a job tries to start while lock is held, it queues up
- Prevents AWS resource conflicts from overlapping executions

Usage:
    python -m pipeline_scheduler.worker
    
Environment Variables:
    PIPELINE_LOCK_FILE: Path to lock file (default: /tmp/pipeline.lock)
    PIPELINE_QUEUE_DIR: Directory for job queue (default: /tmp/pipeline_queue)
    PIPELINE_LOG_DIR: Directory for execution logs (default: ./logs)
"""

import os
import sys
import json
import time
import signal
import logging
import threading
from pathlib import Path
from queue import Queue, Empty
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from dataclasses import dataclass

# Platform-specific imports for file locking
if sys.platform == "win32":
    import msvcrt
else:
    import fcntl

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

from pipeline_scheduler.unified_pipeline import run_unified_pipeline, UnifiedPipelineResult

# ============================================================================
# CONFIGURATION
# ============================================================================
LOCK_FILE = os.environ.get("PIPELINE_LOCK_FILE", "/tmp/pipeline.lock")
QUEUE_DIR = os.environ.get("PIPELINE_QUEUE_DIR", "/tmp/pipeline_queue")
LOG_DIR = os.environ.get("PIPELINE_LOG_DIR", os.path.join(_PROJECT_ROOT, "logs"))
RUNNING_JOB_FILE = os.environ.get("PIPELINE_RUNNING_JOB_FILE", "/tmp/pipeline_running_job.json")
JOB_HISTORY_FILE = os.environ.get("PIPELINE_JOB_HISTORY_FILE", "/tmp/pipeline_job_history.json")

# Job JSON logging - disabled by default to prevent large data accumulation
# Enable via PIPELINE_JOB_LOGGING=true or --enable-job-logging flag
JOB_LOGGING_ENABLED = os.environ.get("PIPELINE_JOB_LOGGING", "false").lower() in ("true", "1", "yes")

# Maximum number of jobs to keep in history (lightweight tracking)
MAX_JOB_HISTORY = int(os.environ.get("PIPELINE_MAX_JOB_HISTORY", "20"))

# For Windows compatibility
if sys.platform == "win32":
    LOCK_FILE = os.environ.get("PIPELINE_LOCK_FILE", os.path.join(_PROJECT_ROOT, "pipeline.lock"))
    QUEUE_DIR = os.environ.get("PIPELINE_QUEUE_DIR", os.path.join(_PROJECT_ROOT, "pipeline_queue"))
    RUNNING_JOB_FILE = os.environ.get("PIPELINE_RUNNING_JOB_FILE", os.path.join(_PROJECT_ROOT, "pipeline_running_job.json"))
    JOB_HISTORY_FILE = os.environ.get("PIPELINE_JOB_HISTORY_FILE", os.path.join(_PROJECT_ROOT, "pipeline_job_history.json"))

# Ensure directories exist
Path(QUEUE_DIR).mkdir(parents=True, exist_ok=True)
Path(LOG_DIR).mkdir(parents=True, exist_ok=True)

# ============================================================================
# LOGGING SETUP
# ============================================================================
# Create a dedicated logger for worker (don't use basicConfig as it may conflict)
logger = logging.getLogger("pipeline_worker")
logger.setLevel(logging.INFO)

# Only add handlers if not already added (prevents duplicate handlers on reimport)
if not logger.handlers:
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler with immediate flush
    file_handler = logging.FileHandler(os.path.join(LOG_DIR, "worker.log"))
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(console_formatter)
    logger.addHandler(file_handler)

# Prevent propagation to root logger (avoids duplicate logs)
logger.propagate = False


# ============================================================================
# FILE-BASED LOCK (Cross-Platform)
# ============================================================================
class FileLock:
    """
    Simple file-based lock for preventing concurrent pipeline executions.
    Works across processes (important for Docker containers).
    """
    
    def __init__(self, lock_file: str):
        self.lock_file = lock_file
        self.lock_fd = None
        self._locked = False
    
    def acquire(self, blocking: bool = True, timeout: float = None) -> bool:
        """
        Acquire the lock.
        
        Args:
            blocking: If True, wait for lock. If False, return immediately.
            timeout: Maximum time to wait (only if blocking=True)
            
        Returns:
            True if lock acquired, False otherwise
        """
        start_time = time.time()
        
        while True:
            try:
                # Open or create lock file
                self.lock_fd = open(self.lock_file, "w")
                
                if sys.platform == "win32":
                    # Windows: use msvcrt
                    import msvcrt
                    try:
                        msvcrt.locking(self.lock_fd.fileno(), msvcrt.LK_NBLCK, 1)
                        self._locked = True
                        # Write PID to lock file
                        self.lock_fd.write(f"{os.getpid()}\n{datetime.now(timezone.utc).isoformat()}")
                        self.lock_fd.flush()
                        return True
                    except IOError:
                        self.lock_fd.close()
                        self.lock_fd = None
                        if not blocking:
                            return False
                else:
                    # Unix: use fcntl
                    try:
                        fcntl.flock(self.lock_fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        self._locked = True
                        # Write PID to lock file
                        self.lock_fd.write(f"{os.getpid()}\n{datetime.now(timezone.utc).isoformat()}")
                        self.lock_fd.flush()
                        return True
                    except (IOError, OSError):
                        self.lock_fd.close()
                        self.lock_fd = None
                        if not blocking:
                            return False
                
                # Check timeout
                if timeout is not None and (time.time() - start_time) >= timeout:
                    return False
                
                # Wait a bit before retrying
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Error acquiring lock: {e}")
                if self.lock_fd:
                    self.lock_fd.close()
                    self.lock_fd = None
                return False
    
    def release(self):
        """Release the lock."""
        if self.lock_fd:
            try:
                if sys.platform == "win32":
                    import msvcrt
                    try:
                        msvcrt.locking(self.lock_fd.fileno(), msvcrt.LK_UNLCK, 1)
                    except:
                        pass
                else:
                    fcntl.flock(self.lock_fd.fileno(), fcntl.LOCK_UN)
                
                self.lock_fd.close()
                self.lock_fd = None
                self._locked = False
                
                # Remove lock file
                try:
                    os.remove(self.lock_file)
                except:
                    pass
                    
            except Exception as e:
                logger.error(f"Error releasing lock: {e}")
    
    def is_locked(self) -> bool:
        """Check if lock file exists and is locked by another process."""
        if not os.path.exists(self.lock_file):
            return False
        
        # Try to acquire non-blocking
        test_lock = FileLock(self.lock_file)
        if test_lock.acquire(blocking=False):
            test_lock.release()
            return False
        return True
    
    def __enter__(self):
        self.acquire()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()


# ============================================================================
# JOB QUEUE (File-Based)
# ============================================================================
@dataclass
class PipelineJob:
    """Represents a pipeline job in the queue."""
    job_id: str
    created_at: str
    pipeline_type: str = "transcript"  # 'transcript', 'chat', or 'all'
    transcript_mode: str = "incremental"
    transcript_retry_failed: bool = True
    ingestion_folder: str = "transcripts/"  # Legacy field, kept for backward compatibility
    ingestion_skip_existing: bool = True
    ingestion_dry_run: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "job_id": self.job_id,
            "created_at": self.created_at,
            "pipeline_type": self.pipeline_type,
            "transcript_mode": self.transcript_mode,
            "transcript_retry_failed": self.transcript_retry_failed,
            "ingestion_folder": self.ingestion_folder,
            "ingestion_skip_existing": self.ingestion_skip_existing,
            "ingestion_dry_run": self.ingestion_dry_run
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PipelineJob":
        # Handle jobs created before pipeline_type was added
        if "pipeline_type" not in data:
            data["pipeline_type"] = "transcript"
        return cls(**data)


class JobQueue:
    """
    File-based job queue for pipeline jobs.
    Jobs are stored as JSON files in a directory.
    """
    
    def __init__(self, queue_dir: str = QUEUE_DIR):
        self.queue_dir = queue_dir
        Path(queue_dir).mkdir(parents=True, exist_ok=True)
    
    def enqueue(self, job: PipelineJob) -> str:
        """Add a job to the queue. Returns the job file path."""
        filename = f"{job.created_at.replace(':', '-')}_{job.job_id}.json"
        filepath = os.path.join(self.queue_dir, filename)
        
        with open(filepath, "w") as f:
            json.dump(job.to_dict(), f, indent=2)
        
        logger.info(f"📥 Job enqueued: {job.job_id}")
        return filepath
    
    def dequeue(self) -> Optional[PipelineJob]:
        """Get the oldest job from the queue (FIFO). Returns None if empty."""
        files = sorted(Path(self.queue_dir).glob("*.json"))
        
        if not files:
            return None
        
        oldest_file = files[0]
        
        try:
            with open(oldest_file, "r") as f:
                data = json.load(f)
            
            # Remove from queue
            oldest_file.unlink()
            
            return PipelineJob.from_dict(data)
            
        except Exception as e:
            logger.error(f"Error reading job file {oldest_file}: {e}")
            # Move corrupted file
            oldest_file.rename(oldest_file.with_suffix(".error"))
            return None
    
    def peek(self) -> Optional[PipelineJob]:
        """Look at the next job without removing it."""
        files = sorted(Path(self.queue_dir).glob("*.json"))
        
        if not files:
            return None
        
        try:
            with open(files[0], "r") as f:
                data = json.load(f)
            return PipelineJob.from_dict(data)
        except:
            return None
    
    def size(self) -> int:
        """Get number of jobs in queue."""
        return len(list(Path(self.queue_dir).glob("*.json")))
    
    def clear(self):
        """Clear all jobs from queue."""
        for f in Path(self.queue_dir).glob("*.json"):
            f.unlink()
    
    def list_jobs(self) -> list:
        """List all jobs in queue."""
        jobs = []
        for f in sorted(Path(self.queue_dir).glob("*.json")):
            try:
                with open(f, "r") as file:
                    data = json.load(file)
                jobs.append(PipelineJob.from_dict(data))
            except:
                pass
        return jobs


# ============================================================================
# PIPELINE WORKER
# ============================================================================
class PipelineWorker:
    """
    Single-worker that processes pipeline jobs from the queue.
    Uses file-based locking to prevent concurrent executions.
    """
    
    def __init__(self):
        self.queue = JobQueue()
        self.lock = FileLock(LOCK_FILE)
        self.running = True
        self.current_job: Optional[PipelineJob] = None
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)
    
    def _handle_shutdown(self, signum, frame):
        """Handle shutdown signals gracefully."""
        logger.info("🛑 Shutdown signal received. Finishing current job...")
        self.running = False
    
    def process_job(self, job: PipelineJob) -> UnifiedPipelineResult:
        """Process a single job."""
        logger.info(f"🔧 Processing job: {job.job_id} (pipeline: {job.pipeline_type})")
        self.current_job = job
        
        # Write running job info to file so --status can see it
        self._write_running_job_file(job)
        
        try:
            result = run_unified_pipeline(
                job_id=job.job_id,
                pipeline_type=job.pipeline_type,
                transcript_mode=job.transcript_mode,
                transcript_retry_failed=job.transcript_retry_failed,
                ingestion_folder=job.ingestion_folder,
                ingestion_skip_existing=job.ingestion_skip_existing,
                ingestion_dry_run=job.ingestion_dry_run,
            )
            
            # Log result to file
            self._log_result(job, result)
            
            return result
            
        finally:
            self.current_job = None
            # Clear running job file
            self._clear_running_job_file()
    
    def _write_running_job_file(self, job: PipelineJob):
        """Write current running job info to a file for status checking."""
        try:
            running_info = {
                "job_id": job.job_id,
                "started_at": datetime.now(timezone.utc).isoformat(),
                "pid": os.getpid(),
                "pipeline_type": job.pipeline_type,
                "transcript_mode": job.transcript_mode,
                "ingestion_folder": job.ingestion_folder,
            }
            with open(RUNNING_JOB_FILE, "w") as f:
                json.dump(running_info, f, indent=2)
        except Exception as e:
            logger.error(f"Error writing running job file: {e}")
    
    def _clear_running_job_file(self):
        """Clear the running job file when job completes."""
        try:
            if os.path.exists(RUNNING_JOB_FILE):
                os.remove(RUNNING_JOB_FILE)
        except Exception as e:
            logger.error(f"Error clearing running job file: {e}")
    
    def _add_to_job_history(self, job: PipelineJob, result: UnifiedPipelineResult):
        """
        Add job to lightweight history file (always enabled).
        Keeps only the last MAX_JOB_HISTORY jobs to prevent unbounded growth.
        """
        try:
            # Load existing history
            history = []
            if os.path.exists(JOB_HISTORY_FILE):
                try:
                    with open(JOB_HISTORY_FILE, "r") as f:
                        history = json.load(f)
                except:
                    history = []
            
            # Create lightweight job summary
            job_summary = {
                "job_id": job.job_id,
                "pipeline_type": job.pipeline_type,
                "started_at": result.started_at,
                "completed_at": result.completed_at,
                "duration_seconds": result.duration_seconds,
                "success": result.overall_success,
                "transcript_processed": result.transcript_processed,
                "transcript_skipped": result.transcript_skipped,
                "ingestion_processed": result.ingestion_processed,
                "ingestion_skipped": result.ingestion_skipped,
                "errors": result.errors[:3] if result.errors else [],
            }
            
            # Add to history (newest first)
            history.insert(0, job_summary)
            
            # Trim to max size
            history = history[:MAX_JOB_HISTORY]
            
            # Save history
            with open(JOB_HISTORY_FILE, "w") as f:
                json.dump(history, f, indent=2)
                
        except Exception as e:
            logger.error(f"Error updating job history: {e}")
    
    def _log_result(self, job: PipelineJob, result: UnifiedPipelineResult):
        """Log job result to a file (only if JOB_LOGGING_ENABLED is true)."""
        # Always add to lightweight job history
        self._add_to_job_history(job, result)
        
        # Full JSON logging only if enabled
        if not JOB_LOGGING_ENABLED:
            logger.debug(f"Full job logging disabled. Job history updated for {job.job_id}")
            return
        
        log_file = os.path.join(LOG_DIR, f"job_{job.job_id}.json")
        
        try:
            with open(log_file, "w") as f:
                json.dump({
                    "job": job.to_dict(),
                    "result": result.to_dict()
                }, f, indent=2)
            logger.info(f"Job result logged to {log_file}")
        except Exception as e:
            logger.error(f"Error logging result: {e}")
    
    def run_once(self) -> bool:
        """
        Try to process one job from the queue.
        
        Returns:
            True if a job was processed, False if queue was empty or locked
        """
        # Check if queue has jobs
        if self.queue.size() == 0:
            return False
        
        # Try to acquire lock (non-blocking)
        if not self.lock.acquire(blocking=False):
            logger.debug("⏳ Lock held by another process, waiting...")
            return False
        
        try:
            # Get next job
            job = self.queue.dequeue()
            
            if job is None:
                return False
            
            # Process the job
            self.process_job(job)
            return True
            
        finally:
            self.lock.release()
    
    def run_forever(self, poll_interval: float = 1.0):
        """
        Run the worker forever, polling for new jobs.
        
        Args:
            poll_interval: Seconds between queue checks
        """
        logger.info("🚀 Pipeline Worker started")
        logger.info(f"   Queue directory: {QUEUE_DIR}")
        logger.info(f"   Lock file: {LOCK_FILE}")
        logger.info(f"   Log directory: {LOG_DIR}")
        logger.info(f"   Poll interval: {poll_interval}s")
        logger.info("-" * 50)
        
        while self.running:
            try:
                queue_size = self.queue.size()
                
                if queue_size > 0:
                    logger.info(f"📬 Queue has {queue_size} job(s)")
                    
                    if self.lock.is_locked():
                        logger.info("⏳ Waiting for current job to finish...")
                    else:
                        self.run_once()
                
                time.sleep(poll_interval)
                
            except Exception as e:
                logger.error(f"Worker error: {e}")
                time.sleep(poll_interval)
        
        logger.info("🛑 Pipeline Worker stopped")
    
    def get_status(self) -> Dict[str, Any]:
        """Get current worker status."""
        return {
            "running": self.running,
            "current_job": self.current_job.to_dict() if self.current_job else None,
            "queue_size": self.queue.size(),
            "lock_held": self.lock.is_locked(),
            "queued_jobs": [j.to_dict() for j in self.queue.list_jobs()]
        }


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================
def submit_job(
    pipeline_type: str = "transcript",
    transcript_mode: str = "incremental",
    transcript_retry_failed: bool = True,
    ingestion_folder: str = "transcripts/",
    ingestion_skip_existing: bool = True,
    ingestion_dry_run: bool = False,
) -> str:
    """
    Submit a new job to the queue.
    
    Args:
        pipeline_type: 'transcript', 'chat', or 'all'
        transcript_mode: 'incremental' or 'full' (for transcript pipeline)
        transcript_retry_failed: Whether to retry failed transcripts
        ingestion_folder: Legacy parameter, kept for backward compatibility
        ingestion_skip_existing: Skip already indexed documents
        ingestion_dry_run: Don't write to databases
    
    Returns:
        Job ID
    """
    job_id = f"{pipeline_type}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')}"
    
    job = PipelineJob(
        job_id=job_id,
        created_at=datetime.now(timezone.utc).isoformat(),
        pipeline_type=pipeline_type,
        transcript_mode=transcript_mode,
        transcript_retry_failed=transcript_retry_failed,
        ingestion_folder=ingestion_folder,
        ingestion_skip_existing=ingestion_skip_existing,
        ingestion_dry_run=ingestion_dry_run,
    )
    
    queue = JobQueue()
    queue.enqueue(job)
    
    return job_id


def get_queue_status() -> Dict[str, Any]:
    """Get current queue status including recent completed jobs."""
    queue = JobQueue()
    lock = FileLock(LOCK_FILE)
    
    # Get recent completed jobs from job history file (always available)
    recent_completed = []
    
    # First, try the lightweight job history file (always enabled)
    if os.path.exists(JOB_HISTORY_FILE):
        try:
            with open(JOB_HISTORY_FILE, "r") as f:
                history = json.load(f)
                # Take top 5 most recent
                for job in history[:5]:
                    recent_completed.append({
                        "job_id": job.get("job_id", "unknown"),
                        "pipeline_type": job.get("pipeline_type", "unknown"),
                        "started_at": job.get("started_at", ""),
                        "completed_at": job.get("completed_at", ""),
                        "duration_seconds": job.get("duration_seconds", 0),
                        "success": job.get("success", False),
                        "transcript_processed": job.get("transcript_processed", 0),
                        "ingestion_processed": job.get("ingestion_processed", 0),
                    })
        except:
            pass
    
    # Fallback: try reading from individual log files (if JOB_LOGGING was enabled)
    if not recent_completed:
        try:
            log_files = sorted(Path(LOG_DIR).glob("job_*.json"), reverse=True)[:5]
            for log_file in log_files:
                try:
                    with open(log_file, "r") as f:
                        data = json.load(f)
                        job_data = data.get("job", {})
                        result_data = data.get("result", {})
                        recent_completed.append({
                            "job_id": job_data.get("job_id", "unknown"),
                            "pipeline_type": job_data.get("pipeline_type", "unknown"),
                            "started_at": result_data.get("started_at", ""),
                            "completed_at": result_data.get("completed_at", ""),
                            "duration_seconds": result_data.get("duration_seconds", 0),
                            "success": result_data.get("overall_success", False),
                            "transcript_processed": result_data.get("transcript", {}).get("processed", 0),
                            "ingestion_processed": result_data.get("ingestion", {}).get("processed", 0),
                        })
                except:
                    pass
        except:
            pass
        pass
    
    # Check for running job from the dedicated running job file
    running_job = None
    is_running = False
    
    # First check if running job file exists (most reliable)
    if os.path.exists(RUNNING_JOB_FILE):
        try:
            with open(RUNNING_JOB_FILE, "r") as f:
                running_job = json.load(f)
                is_running = True
        except Exception as e:
            pass
    
    # Fallback: check lock file
    if running_job is None and lock.is_locked():
        is_running = True
        try:
            with open(LOCK_FILE, "r") as f:
                lines = f.readlines()
                if len(lines) >= 2:
                    running_job = {
                        "pid": lines[0].strip(),
                        "started_at": lines[1].strip(),
                        "status": "running (limited info from lock file)"
                    }
        except:
            running_job = {"status": "running (details unavailable)"}
    
    return {
        "queue_size": queue.size(),
        "lock_held": is_running,
        "running_job": running_job,
        "queued_jobs": [j.to_dict() for j in queue.list_jobs()],
        "recent_completed": recent_completed,
        "jobs": [j.to_dict() for j in queue.list_jobs()]  # Keep for backward compatibility
    }


# ============================================================================
# CLI ENTRY POINT
# ============================================================================
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Pipeline Worker")
    parser.add_argument("--poll-interval", type=float, default=1.0,
                        help="Seconds between queue checks (default: 1.0)")
    parser.add_argument("--status", action="store_true",
                        help="Show queue status and exit")
    parser.add_argument("--clear", action="store_true",
                        help="Clear job queue and exit")
    parser.add_argument("--submit", action="store_true",
                        help="Submit a job and exit")
    parser.add_argument("--pipeline", "-p", 
                        choices=["transcript", "chat", "all"],
                        default="transcript",
                        help="Pipeline type to submit/run (default: transcript)")
    
    args = parser.parse_args()
    
    if args.status:
        status = get_queue_status()
        print(json.dumps(status, indent=2))
    elif args.clear:
        queue = JobQueue()
        queue.clear()
        print("Queue cleared")
    elif args.submit:
        job_id = submit_job(pipeline_type=args.pipeline)
        print(f"Job submitted: {job_id} (pipeline: {args.pipeline})")
    else:
        worker = PipelineWorker()
        worker.run_forever(poll_interval=args.poll_interval)
