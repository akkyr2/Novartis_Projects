"""
Combined Runner - Runs Both Scheduler and Worker in One Process
================================================================
This module runs both the scheduler (submits jobs) and worker (processes jobs)
in a single process using threading.

This is convenient for Docker single-container deployments.

Usage:
    python -m pipeline_scheduler.run
    
    # Or with options
    python -m pipeline_scheduler.run --interval 1 --enabled
    
Environment Variables:
    PIPELINE_ENABLED: Enable scheduled runs (default: true)
    PIPELINE_INTERVAL_MINUTES: Minutes between runs (default: 1)
"""

import os
import sys
import time
import signal
import logging
import threading
from datetime import datetime, timezone

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

from pipeline_scheduler.worker import PipelineWorker, submit_job, get_queue_status

# ============================================================================
# CONFIGURATION
# ============================================================================
ENABLED = os.environ.get("PIPELINE_ENABLED", "true").lower() in ("true", "1", "yes")
INTERVAL_MINUTES = int(os.environ.get("PIPELINE_INTERVAL_MINUTES", "1"))
TRANSCRIPT_MODE = os.environ.get("PIPELINE_TRANSCRIPT_MODE", "incremental")
MAX_QUEUE_SIZE = int(os.environ.get("PIPELINE_MAX_QUEUE_SIZE", "5"))
PIPELINE_TYPE = os.environ.get("PIPELINE_TYPE", "transcript")  # 'transcript', 'chat', or 'all'

# ============================================================================
# LOGGING SETUP
# ============================================================================
LOG_DIR = os.environ.get("PIPELINE_LOG_DIR", os.path.join(_PROJECT_ROOT, "logs"))
os.makedirs(LOG_DIR, exist_ok=True)

# Create a dedicated logger for runner (don't use basicConfig as it may conflict)
logger = logging.getLogger("pipeline_runner")
logger.setLevel(logging.INFO)

# Only add handlers if not already added (prevents duplicate handlers on reimport)
if not logger.handlers:
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler with immediate flush
    file_handler = logging.FileHandler(os.path.join(LOG_DIR, "combined_runner.log"))
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(console_formatter)
    logger.addHandler(file_handler)

# Prevent propagation to root logger (avoids duplicate logs)
logger.propagate = False


# ============================================================================
# COMBINED RUNNER CLASS
# ============================================================================
class CombinedRunner:
    """
    Runs both scheduler and worker in a single process.
    - Scheduler thread: Submits jobs at regular intervals
    - Worker thread: Processes jobs from the queue (main thread)
    """
    
    def __init__(self, interval_minutes: int = INTERVAL_MINUTES, pipeline_type: str = PIPELINE_TYPE):
        self.interval_minutes = interval_minutes
        self.interval_seconds = interval_minutes * 60
        self.pipeline_type = pipeline_type
        self.running = True
        self.worker = PipelineWorker()
        self.scheduler_thread = None
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)
    
    def _handle_shutdown(self, signum, frame):
        """Handle shutdown signals."""
        logger.info("🛑 Shutdown signal received")
        self.running = False
        self.worker.running = False
    
    def _submit_job_if_needed(self):
        """Submit a job if queue is not full."""
        status = get_queue_status()
        queue_size = status["queue_size"]
        
        if queue_size >= MAX_QUEUE_SIZE:
            logger.warning(f"⚠️  Queue full ({queue_size}/{MAX_QUEUE_SIZE}). Skipping scheduled trigger.")
            return
        
        try:
            job_id = submit_job(
                pipeline_type=self.pipeline_type,
                transcript_mode=TRANSCRIPT_MODE,
                transcript_retry_failed=True,
                ingestion_folder="transcripts/",
                ingestion_skip_existing=True,
                ingestion_dry_run=False,
            )
            logger.info(f"⏰ Scheduled job submitted: {job_id} (pipeline: {self.pipeline_type})")
        except Exception as e:
            logger.error(f"❌ Failed to submit scheduled job: {e}")
    
    def _scheduler_loop(self):
        """Scheduler loop that runs in a separate thread."""
        logger.info("📅 Scheduler thread started")
        
        # Submit first job immediately
        self._submit_job_if_needed()
        
        while self.running:
            # Sleep in small increments to allow quick shutdown
            for _ in range(self.interval_seconds):
                if not self.running:
                    break
                time.sleep(1)
            
            if self.running:
                self._submit_job_if_needed()
        
        logger.info("📅 Scheduler thread stopped")
    
    def run(self):
        """Run the combined scheduler + worker."""
        # Import here to get the current value after CLI flag processing
        from pipeline_scheduler.worker import JOB_LOGGING_ENABLED
        
        if not ENABLED:
            logger.warning("⚠️  Pipeline scheduler is DISABLED")
            logger.warning("   Set PIPELINE_ENABLED=true to enable")
            logger.warning("   Worker will still process any manually submitted jobs")
        
        logger.info("=" * 70)
        logger.info("🚀 COMBINED PIPELINE RUNNER STARTING")
        logger.info("=" * 70)
        logger.info(f"   Scheduler Enabled: {ENABLED}")
        logger.info(f"   Interval: Every {self.interval_minutes} minute(s)")
        logger.info(f"   Pipeline Type: {self.pipeline_type}")
        logger.info(f"   Transcript Mode: {TRANSCRIPT_MODE}")
        logger.info(f"   Max Queue Size: {MAX_QUEUE_SIZE}")
        logger.info(f"   Job JSON Logging: {'ENABLED' if JOB_LOGGING_ENABLED else 'DISABLED'}")
        logger.info("-" * 70)
        logger.info("   This process runs BOTH:")
        logger.info("   1. Scheduler (submits jobs every minute)")
        logger.info("   2. Worker (processes jobs from queue)")
        if not JOB_LOGGING_ENABLED:
            logger.info("   ℹ️  Job JSON logs disabled. Use --enable-job-logging to enable.")
        logger.info("-" * 70)
        logger.info("   Press Ctrl+C to stop")
        logger.info("=" * 70 + "\n")
        
        # Start scheduler in a separate thread (only if enabled)
        if ENABLED:
            self.scheduler_thread = threading.Thread(
                target=self._scheduler_loop,
                name="scheduler",
                daemon=True
            )
            self.scheduler_thread.start()
        
        # Run worker in main thread
        self.worker.run_forever(poll_interval=1.0)
        
        logger.info("🛑 Combined runner stopped")


# ============================================================================
# CLI ENTRY POINT
# ============================================================================
def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Combined Pipeline Runner (Scheduler + Worker)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Run with default settings (every 1 minute, transcript pipeline)
    python -m pipeline_scheduler.run
    
    # Run every 5 minutes
    python -m pipeline_scheduler.run --interval 5
    
    # Run chat pipeline only
    python -m pipeline_scheduler.run --pipeline chat
    
    # Run all pipelines (transcript + chat)
    python -m pipeline_scheduler.run --pipeline all
    
    # Run worker only (no scheduled jobs)
    python -m pipeline_scheduler.run --disabled
    
    # Enable job JSON logging (creates logs/job_*.json files)
    python -m pipeline_scheduler.run --enable-job-logging
    
    # Check status
    python -m pipeline_scheduler.run --status
    
    # Submit a manual job for chat pipeline
    python -m pipeline_scheduler.run --submit --pipeline chat
"""
    )
    parser.add_argument("--interval", type=int, default=INTERVAL_MINUTES,
                        help=f"Minutes between scheduled runs (default: {INTERVAL_MINUTES})")
    parser.add_argument("--pipeline", "-p",
                        choices=["transcript", "chat", "all"],
                        default=PIPELINE_TYPE,
                        help=f"Pipeline type to run (default: {PIPELINE_TYPE})")
    parser.add_argument("--enabled", action="store_true", default=None,
                        help="Enable scheduler (overrides env var)")
    parser.add_argument("--disabled", action="store_true",
                        help="Disable scheduler, run worker only")
    parser.add_argument("--enable-job-logging", action="store_true",
                        help="Enable JSON logging for each job (creates logs/job_*.json files)")
    parser.add_argument("--status", action="store_true",
                        help="Show queue status and exit")
    parser.add_argument("--status-json", action="store_true",
                        help="Show queue status as JSON and exit")
    parser.add_argument("--submit", action="store_true",
                        help="Submit a job and exit")
    
    args = parser.parse_args()
    
    if args.status_json:
        import json
        status = get_queue_status()
        print(json.dumps(status, indent=2))
        return
    
    if args.status:
        status = get_queue_status()
        print("\n" + "=" * 60)
        print("📊 PIPELINE SCHEDULER STATUS")
        print("=" * 60)
        
        # Running status
        if status["lock_held"] or status.get("running_job"):
            print(f"\n🔄 STATUS: JOB CURRENTLY RUNNING")
            if status.get("running_job"):
                rj = status["running_job"]
                print(f"   Job ID: {rj.get('job_id', 'N/A')}")
                print(f"   PID: {rj.get('pid', 'N/A')}")
                print(f"   Started: {rj.get('started_at', 'N/A')}")
                print(f"   Pipeline Type: {rj.get('pipeline_type', 'N/A')}")
                print(f"   Mode: {rj.get('transcript_mode', 'N/A')}")
            else:
                print("   (details unavailable)")
        else:
            print(f"\n⏸️  STATUS: IDLE (waiting for next scheduled trigger)")
        
        # Queue info
        print(f"\n📬 QUEUE: {status['queue_size']} job(s) waiting")
        if status["queued_jobs"]:
            for job in status["queued_jobs"]:
                print(f"   • {job['job_id']} (created: {job['created_at']})")
        
        # Recent completed
        print(f"\n✅ RECENT COMPLETED JOBS:")
        if status.get("recent_completed"):
            for job in status["recent_completed"]:
                success_icon = "✅" if job.get("success") else "❌"
                pipeline_type = job.get("pipeline_type", "unknown")
                print(f"   {success_icon} {job['job_id']} ({pipeline_type})")
                print(f"      Duration: {job.get('duration_seconds', 0):.1f}s")
                print(f"      Transcripts: {job.get('transcript_processed', 0)}, Ingested: {job.get('ingestion_processed', 0)}")
        else:
            print("   No completed jobs found (run a pipeline first)")
        
        print("\n" + "=" * 60)
        return
    
    if args.submit:
        job_id = submit_job(pipeline_type=args.pipeline)
        print(f"Job submitted: {job_id} (pipeline: {args.pipeline})")
        return
    
    # Handle enabled/disabled flags
    global ENABLED
    if args.disabled:
        ENABLED = False
        os.environ["PIPELINE_ENABLED"] = "false"
    elif args.enabled:
        ENABLED = True
        os.environ["PIPELINE_ENABLED"] = "true"
    
    # Handle job logging flag
    if args.enable_job_logging:
        os.environ["PIPELINE_JOB_LOGGING"] = "true"
        # Need to update the worker module's global variable
        import pipeline_scheduler.worker as worker_module
        worker_module.JOB_LOGGING_ENABLED = True
        logger.info("📝 Job JSON logging ENABLED (logs/job_*.json files will be created)")
    
    runner = CombinedRunner(interval_minutes=args.interval, pipeline_type=args.pipeline)
    runner.run()


if __name__ == "__main__":
    main()
