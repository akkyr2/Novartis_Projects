"""
Pipeline Scheduler Package
==========================
This package provides a scheduled worker-queue mechanism for running
the data pipelines (transcript + ingestion) with proper locking to
prevent overlapping executions.

Components:
- unified_pipeline.py: Runs both pipelines sequentially
- worker.py: Single-worker queue processor with locking
- scheduler.py: APScheduler-based cron trigger (every minute)

Usage (Docker):
    # Worker process (runs jobs from queue)
    python -m pipeline_scheduler.worker
    
    # Scheduler process (adds jobs to queue every minute)
    python -m pipeline_scheduler.scheduler
    
    # Or use the combined runner
    python -m pipeline_scheduler.run
"""
