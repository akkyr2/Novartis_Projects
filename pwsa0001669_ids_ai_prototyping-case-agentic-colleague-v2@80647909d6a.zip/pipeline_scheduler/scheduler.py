"""
Pipeline Scheduler (Cron-like Job Submitter)
=============================================
Submits pipeline jobs to the queue at regular intervals (every minute by default).

This scheduler uses APScheduler to trigger job submissions.
The actual job execution is handled by the worker process.

Usage:
    python -m pipeline_scheduler.scheduler
    
Environment Variables:
    PIPELINE_ENABLED: Enable/disable scheduler (default: true)
    PIPELINE_INTERVAL_MINUTES: Minutes between runs (default: 1)
    PIPELINE_TRANSCRIPT_MODE: incremental or full (default: incremental)
"""

import os
import sys
import logging
import signal
import time
from datetime import datetime, timezone

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.interval import IntervalTrigger

from pipeline_scheduler.worker import submit_job, get_queue_status

# ============================================================================
# CONFIGURATION
# ============================================================================
ENABLED = os.environ.get("PIPELINE_ENABLED", "true").lower() in ("true", "1", "yes")
INTERVAL_MINUTES = int(os.environ.get("PIPELINE_INTERVAL_MINUTES", "1"))
TRANSCRIPT_MODE = os.environ.get("PIPELINE_TRANSCRIPT_MODE", "incremental")
MAX_QUEUE_SIZE = int(os.environ.get("PIPELINE_MAX_QUEUE_SIZE", "5"))
PIPELINE_TYPE = os.environ.get("PIPELINE_TYPE", "transcript")  # 'transcript', 'chat', or 'all'

# ============================================================================
# LOGGING SETUP
# ============================================================================
LOG_DIR = os.environ.get("PIPELINE_LOG_DIR", os.path.join(_PROJECT_ROOT, "logs"))
os.makedirs(LOG_DIR, exist_ok=True)

# Create a dedicated logger for scheduler (don't use basicConfig as it may conflict)
logger = logging.getLogger("pipeline_scheduler")
logger.setLevel(logging.INFO)

# Only add handlers if not already added (prevents duplicate handlers on reimport)
if not logger.handlers:
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler
    file_handler = logging.FileHandler(os.path.join(LOG_DIR, "scheduler.log"))
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(console_formatter)
    logger.addHandler(file_handler)

# Prevent propagation to root logger (avoids duplicate logs)
logger.propagate = False

# Reduce APScheduler verbosity
logging.getLogger("apscheduler").setLevel(logging.WARNING)


# ============================================================================
# SCHEDULED JOB FUNCTION
# ============================================================================
def scheduled_pipeline_job(pipeline_type: str = None):
    """
    Function called by the scheduler to submit a pipeline job.
    Checks queue size before submitting to prevent queue buildup.
    
    Args:
        pipeline_type: Override pipeline type (defaults to PIPELINE_TYPE env var)
    """
    if pipeline_type is None:
        pipeline_type = PIPELINE_TYPE
    
    logger.info(f"⏰ Scheduler triggered (pipeline: {pipeline_type})")
    
    # Check current queue status
    status = get_queue_status()
    queue_size = status["queue_size"]
    lock_held = status["lock_held"]
    
    logger.info(f"   Queue size: {queue_size}, Lock held: {lock_held}")
    
    # Don't submit if queue is too large (jobs piling up)
    if queue_size >= MAX_QUEUE_SIZE:
        logger.warning(f"   ⚠️  Queue full ({queue_size}/{MAX_QUEUE_SIZE}). Skipping this trigger.")
        logger.warning(f"   This means previous jobs are taking longer than expected.")
        return
    
    # Submit new job
    try:
        job_id = submit_job(
            pipeline_type=pipeline_type,
            transcript_mode=TRANSCRIPT_MODE,
            transcript_retry_failed=True,
            ingestion_folder="transcripts/",
            ingestion_skip_existing=True,
            ingestion_dry_run=False,
        )
        logger.info(f"   ✅ Job submitted: {job_id}")
        
    except Exception as e:
        logger.error(f"   ❌ Failed to submit job: {e}")


# ============================================================================
# SCHEDULER CLASS
# ============================================================================
class PipelineScheduler:
    """
    Cron-like scheduler that submits pipeline jobs at regular intervals.
    """
    
    def __init__(self, interval_minutes: int = INTERVAL_MINUTES, pipeline_type: str = PIPELINE_TYPE):
        self.interval_minutes = interval_minutes
        self.pipeline_type = pipeline_type
        self.scheduler = BlockingScheduler()
        self.running = False
        
        # Add the job with partial to pass pipeline_type
        from functools import partial
        job_func = partial(scheduled_pipeline_job, pipeline_type=pipeline_type)
        
        self.scheduler.add_job(
            job_func,
            trigger=IntervalTrigger(minutes=interval_minutes),
            id="pipeline_job",
            name=f"Pipeline Job ({pipeline_type})",
            replace_existing=True,
            max_instances=1,  # Prevent overlapping scheduler triggers
        )
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)
    
    def _handle_shutdown(self, signum, frame):
        """Handle shutdown signals gracefully."""
        logger.info("🛑 Shutdown signal received")
        self.stop()
    
    def start(self):
        """Start the scheduler."""
        if not ENABLED:
            logger.warning("⚠️  Scheduler is DISABLED (PIPELINE_ENABLED=false)")
            logger.warning("   Set PIPELINE_ENABLED=true to enable scheduled runs")
            return
        
        logger.info("=" * 60)
        logger.info("🚀 Pipeline Scheduler starting")
        logger.info("=" * 60)
        logger.info(f"   Interval: Every {self.interval_minutes} minute(s)")
        logger.info(f"   Pipeline Type: {self.pipeline_type}")
        logger.info(f"   Transcript Mode: {TRANSCRIPT_MODE}")
        logger.info(f"   Max Queue Size: {MAX_QUEUE_SIZE}")
        logger.info("-" * 60)
        logger.info("   Press Ctrl+C to stop")
        logger.info("=" * 60)
        
        # Run first job immediately
        logger.info("\n📌 Running initial job immediately...")
        scheduled_pipeline_job(pipeline_type=self.pipeline_type)
        
        # Start scheduler
        self.running = True
        try:
            self.scheduler.start()
        except (KeyboardInterrupt, SystemExit):
            pass
    
    def stop(self):
        """Stop the scheduler."""
        if self.running:
            self.scheduler.shutdown(wait=False)
            self.running = False
            logger.info("🛑 Scheduler stopped")


# ============================================================================
# CLI ENTRY POINT
# ============================================================================
def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Pipeline Scheduler")
    parser.add_argument("--interval", type=int, default=INTERVAL_MINUTES,
                        help=f"Minutes between runs (default: {INTERVAL_MINUTES})")
    parser.add_argument("--pipeline", "-p",
                        choices=["transcript", "chat", "all"],
                        default=PIPELINE_TYPE,
                        help=f"Pipeline type to run (default: {PIPELINE_TYPE})")
    parser.add_argument("--once", action="store_true",
                        help="Submit one job and exit (for testing)")
    parser.add_argument("--status", action="store_true",
                        help="Show queue status and exit")
    
    args = parser.parse_args()
    
    if args.status:
        import json
        status = get_queue_status()
        print(json.dumps(status, indent=2))
    elif args.once:
        scheduled_pipeline_job(pipeline_type=args.pipeline)
    else:
        scheduler = PipelineScheduler(interval_minutes=args.interval, pipeline_type=args.pipeline)
        scheduler.start()


if __name__ == "__main__":
    main()
