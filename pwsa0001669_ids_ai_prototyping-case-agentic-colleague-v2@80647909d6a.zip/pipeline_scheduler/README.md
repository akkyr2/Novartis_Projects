# Pipeline Scheduler Module

## Table of Contents

1. [Module Overview](#1-module-overview)
2. [Business Context](#2-business-context)
3. [Functional Overview](#3-functional-overview)
4. [Architecture Overview](#4-architecture-overview)
5. [Folder Structure](#5-folder-structure)
6. [Technology Stack](#6-technology-stack)
7. [Dependencies](#7-dependencies)
8. [Configuration](#8-configuration)
9. [Environment Variables](#9-environment-variables)
10. [Installation Guide](#10-installation-guide)
11. [Build Process](#11-build-process)
12. [Running the Application](#12-running-the-application)
13. [API Documentation](#13-api-documentation)
14. [Database Documentation](#14-database-documentation)
15. [End-to-End Flow](#15-end-to-end-flow)
16. [Component Deep Dive](#16-component-deep-dive)
17. [Data Flow](#17-data-flow)
18. [Logging and Monitoring](#18-logging-and-monitoring)
19. [Error Handling Strategy](#19-error-handling-strategy)
20. [Security Considerations](#20-security-considerations)
21. [Testing](#21-testing)
22. [Deployment](#22-deployment)
23. [Troubleshooting Guide](#23-troubleshooting-guide)
24. [Performance Considerations](#24-performance-considerations)
25. [Assumptions and Limitations](#25-assumptions-and-limitations)
26. [Future Improvements](#26-future-improvements)
27. [Frequently Asked Questions](#27-frequently-asked-questions)
28. [Glossary](#28-glossary)
29. [Ownership and Support](#29-ownership-and-support)
30. [Quick Start Guide](#30-quick-start-guide)

---

## 1. Module Overview

### What This Module Does

The **Pipeline Scheduler** is an automated job scheduling and execution system that orchestrates data pipelines for the Agentic Colleague application. It fetches Microsoft Teams meeting transcripts, processes them, and ingests them into AWS services (S3, OpenSearch, DynamoDB) for later retrieval and AI-powered analysis.

### Why It Exists

Without this module, data synchronization from Microsoft Teams would need to be triggered manually. The Pipeline Scheduler automates this process, running at configurable intervals (default: every 1 minute) to ensure that meeting data is continuously ingested into the system with minimal latency.

### Business Value

- **Automation**: Eliminates manual data synchronization efforts
- **Near Real-Time Updates**: Meeting data available within minutes of creation
- **Reliability**: Prevents data loss through queuing and retry mechanisms
- **Efficiency**: Incremental sync minimizes API calls and processing time
- **Observability**: Comprehensive logging and status monitoring

---

## 2. Business Context

### Business Purpose

The Agentic Colleague application provides AI-powered insights from Microsoft Teams meetings. For this to work effectively, meeting transcripts must be continuously synchronized from Microsoft Graph API to the application's data stores.

### Use Cases

| Use Case | Description |
|----------|-------------|
| **Transcript Synchronization** | Fetch meeting transcripts from Teams and store in S3 |
| **Data Ingestion** | Process raw files and index into OpenSearch for search capabilities |
| **Project Matching** | Automatically associate meetings with business projects |
| **Incremental Updates** | Only process new meetings since the last successful run |

### Real-World Examples

1. **Daily Stand-up Meeting**: A team conducts a 15-minute stand-up. Within 1-2 minutes after the transcript becomes available in Teams, the pipeline fetches it, processes it, and makes it searchable in the Agentic Colleague application.

2. **Project Review Meeting**: A long project review meeting generates a transcript. The pipeline fetches it and associates it with the correct project.

3. **Failed Pipeline Recovery**: If the pipeline encounters an API error, the job remains in the queue and is automatically retried on the next scheduler trigger.

### Expected Outcomes

- Meeting data is available in the application within 5 minutes of transcript availability
- Zero data loss through queue persistence and retry mechanisms
- System handles 1000+ meetings per day without performance degradation
- Operations team can monitor pipeline health through status commands

---

## 3. Functional Overview

### Core Responsibilities

| Responsibility | Description |
|----------------|-------------|
| **Job Scheduling** | Trigger pipeline jobs at regular intervals (configurable) |
| **Job Queuing** | Manage a FIFO queue of pending jobs with max size limit |
| **Concurrency Control** | Prevent overlapping executions via file-based locking |
| **Pipeline Orchestration** | Execute fetch and ingestion steps in correct sequence |
| **Status Reporting** | Provide real-time visibility into queue and job status |
| **Graceful Shutdown** | Complete current job before stopping on SIGTERM/SIGINT |

### Major Features

| Feature | Description |
|---------|-------------|
| **Transcript Pipeline** | Fetch and process meeting transcripts from Teams |
| **Incremental Mode** | Only fetch new data since last successful run |
| **File-Based Locking** | Cross-platform lock mechanism (Windows/Linux) |
| **Job History Tracking** | Maintain history of last 20 completed jobs |
| **Combined Runner** | Single process for both scheduler and worker |
| **Docker Ready** | Full Docker and Docker Compose support |
| **CLI Interface** | Comprehensive command-line options for all operations |

### Included Functionality

- ✅ Scheduled job submission at configurable intervals
- ✅ File-based job queue (FIFO ordering)
- ✅ File-based locking to prevent concurrent executions
- ✅ Transcript pipeline (Teams → S3 → OpenSearch/DynamoDB)
- ✅ Status monitoring and reporting
- ✅ Graceful shutdown handling
- ✅ Job result logging (optional detailed JSON)
- ✅ Cross-platform support (Windows and Linux)

### Excluded Functionality

- ❌ Distributed job processing (single-worker design)
- ❌ Database-backed queue (uses file system)
- ❌ Web-based dashboard (CLI/logs only)
- ❌ Automatic scaling (fixed single-worker)
- ❌ Complex retry strategies (simple queue-based retry)

---

## 4. Architecture Overview

### High-Level Architecture

```mermaid
graph TB
    subgraph "Pipeline Scheduler System"
        S[Scheduler<br/>APScheduler] -->|Submit Job| Q[Job Queue<br/>File-based FIFO]
        Q -->|Dequeue| W[Worker<br/>Single Worker]
        W -->|Acquire| L[File Lock<br/>Mutex]
        L -->|Execute| UP[Unified Pipeline]
    end
    
    subgraph "Transcript Pipeline"
        UP --> TF[Transcript Fetch]
        TF --> TI[Transcript Ingest]
    end
    
    subgraph "External Systems"
        TF -->|Graph API| Teams[Microsoft Teams]
        
        TI -->|Store| S3[AWS S3]
        TI -->|Index| OS[OpenSearch]
        TI -->|Track| DDB[DynamoDB]
    end
```

### Component Relationships

```mermaid
graph LR
    subgraph "Entry Points"
        RUN[run.py<br/>Combined Runner]
        SCH[scheduler.py<br/>Job Submitter]
        WRK[worker.py<br/>Job Processor]
    end
    
    subgraph "Core Components"
        PIPE[pipelines.py<br/>Config Definitions]
        UNI[unified_pipeline.py<br/>Pipeline Orchestrator]
    end
    
    subgraph "External Modules"
        TPV2[transcript_pipeline<br/>main_v2.py]
        BDT[batch_data_ingestion<br/>transcript/ingestion.py]
    end
    
    RUN --> SCH
    RUN --> WRK
    SCH --> WRK
    WRK --> UNI
    UNI --> PIPE
    UNI --> TPV2
    UNI --> BDT
```

### Dependency Relationships

| Component | Depends On | Purpose |
|-----------|------------|---------|
| `run.py` | `worker.py`, `scheduler.py` | Combines scheduler and worker in one process |
| `scheduler.py` | `worker.py` (submit_job) | Submits jobs to queue |
| `worker.py` | `unified_pipeline.py` | Processes jobs by calling pipeline |
| `unified_pipeline.py` | `pipelines.py`, external modules | Orchestrates pipeline execution |
| `pipelines.py` | None | Configuration definitions only |

### Internal and External Integrations

**Internal Integrations:**
- `transcript_pipeline.main_v2`: Fetches transcripts from Microsoft Graph API
- `batch_data_ingestion.transcript.ingestion`: Ingests transcripts to OpenSearch/DynamoDB

**External Integrations:**
- **Microsoft Graph API**: Source of meeting transcripts
- **AWS S3**: Storage for processed meeting documents (DOCX files)
- **AWS OpenSearch**: Search index for meeting content
- **AWS DynamoDB**: Tracking and metadata storage (WorkItems table)

---

## 5. Folder Structure

```
pipeline_scheduler/
├── __init__.py           # Package initialization with module docstring
├── README.md             # This documentation
├── pipelines.py          # Pipeline type definitions and configurations
├── unified_pipeline.py   # Main pipeline orchestrator (entry point for execution)
├── worker.py             # Job queue processor with file-based locking
├── scheduler.py          # APScheduler-based cron trigger (job submitter)
├── run.py                # Combined runner (scheduler + worker in one process)
└── __pycache__/          # Python bytecode cache (auto-generated)
```

### File Descriptions

| File | Lines | Purpose |
|------|-------|---------|
| `__init__.py` | ~25 | Package initialization, exports public API |
| `pipelines.py` | ~100 | Defines `PipelineType` enum and `PipelineConfig` dataclass |
| `unified_pipeline.py` | ~700 | Orchestrates pipeline execution, routes to correct pipeline |
| `worker.py` | ~740 | Job queue, file lock, worker loop, CLI for worker operations |
| `scheduler.py` | ~236 | APScheduler integration, submits jobs on interval |
| `run.py` | ~330 | Combined runner with CLI, threading for scheduler + worker |

---

## 6. Technology Stack

### Programming Languages

| Language | Version | Usage |
|----------|---------|-------|
| Python | 3.10+ | Primary language for all components |

### Frameworks and Libraries

| Library | Version | Purpose |
|---------|---------|---------|
| `APScheduler` | ≥3.10.0 | Cron-like job scheduling |
| `boto3` | Latest | AWS SDK for S3, DynamoDB, OpenSearch |
| `msal` | Latest | Microsoft Authentication Library for Graph API |
| `requests` | Latest | HTTP client for API calls |
| `python-docx` | Latest | DOCX file generation |
| `pydantic` | Latest | Data validation and settings |

### Runtime Requirements

| Requirement | Specification |
|-------------|---------------|
| Python Runtime | 3.10 or higher |
| Operating System | Windows, Linux, macOS |
| Memory | Minimum 512 MB (recommended 1 GB) |
| Disk Space | Minimum 100 MB for queue and logs |
| Network | Access to Microsoft Graph API and AWS services |

### Build Tools

| Tool | Purpose |
|------|---------|
| `pip` | Package installation |
| `venv` | Virtual environment management |
| `Docker` | Containerization (optional) |
| `Docker Compose` | Multi-container orchestration (optional) |

---

## 7. Dependencies

### Internal Dependencies

| Module | Purpose |
|--------|---------|
| `transcript_pipeline.main_v2` | `TranscriptPipelineV2` class for fetching transcripts |
| `batch_data_ingestion.transcript.ingestion` | `process_transcript_folder()` for ingestion |

### External Dependencies (from requirements.txt)

| Package | Required | Purpose |
|---------|----------|---------|
| `apscheduler` | Yes | Interval-based job scheduling |
| `boto3` | Yes | AWS service integration |
| `botocore` | Yes | AWS low-level client |
| `msal` | Yes | Microsoft authentication |
| `requests` | Yes | HTTP requests |
| `python-docx` | Yes | Document generation |
| `pydantic-settings` | Yes | Configuration management |
| `python-dotenv` | Yes | Environment variable loading |

### Third-Party Services

| Service | Purpose | Required |
|---------|---------|----------|
| Microsoft Graph API | Source of meeting data | Yes |
| AWS S3 | Document storage | Yes |
| AWS OpenSearch | Search indexing | Yes |
| AWS DynamoDB | Metadata tracking | Yes |
| AWS Bedrock | LLM processing (for ingestion) | Yes |

### Why Each Dependency Exists

| Dependency | Rationale |
|------------|-----------|
| `apscheduler` | Industry-standard Python scheduler, supports blocking and background modes |
| `boto3` | Official AWS SDK, required for all AWS service interactions |
| `msal` | Official Microsoft library for OAuth2 authentication |
| `python-docx` | Standard library for creating Word documents from meeting data |

---

## 8. Configuration

### Configuration Files

| File | Location | Purpose |
|------|----------|---------|
| `.env` | Project root | Environment variables for all components |
| `config.py` | Project root | Pydantic settings model for application config |

### Pipeline Configurations

The `pipelines.py` module defines the transcript pipeline configuration:

```python
# PipelineType enum
TRANSCRIPT = "transcript"  # Meeting transcripts
```

**Transcript Pipeline Config:**
```python
PipelineConfig(
    name="Transcript Pipeline",
    description="Fetch Teams transcripts and ingest to OpenSearch/DynamoDB",
    transcript_mode="incremental",
    transcript_retry_failed=True,
    ingestion_prefix="meetings/transcripts/",
    run_transcript_fetch=True,
    run_ingestion=True,
)
```

---

## 9. Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PIPELINE_ENABLED` | No | `true` | Enable/disable scheduled job submission |
| `PIPELINE_TYPE` | No | `transcript` | Pipeline type: `transcript` |
| `PIPELINE_INTERVAL_MINUTES` | No | `1` | Minutes between scheduled triggers |
| `PIPELINE_TRANSCRIPT_MODE` | No | `incremental` | Sync mode: `incremental` or `full` |
| `PIPELINE_MAX_QUEUE_SIZE` | No | `5` | Maximum jobs allowed in queue |
| `PIPELINE_JOB_LOGGING` | No | `false` | Enable detailed JSON job logging |
| `PIPELINE_MAX_JOB_HISTORY` | No | `20` | Number of completed jobs to retain |
| `PIPELINE_LOCK_FILE` | No | `/tmp/pipeline.lock` | Path to lock file |
| `PIPELINE_QUEUE_DIR` | No | `/tmp/pipeline_queue` | Directory for queue files |
| `PIPELINE_LOG_DIR` | No | `./logs` | Directory for log files |
| `PIPELINE_RUNNING_JOB_FILE` | No | `/tmp/pipeline_running_job.json` | File tracking running job |
| `PIPELINE_JOB_HISTORY_FILE` | No | `/tmp/pipeline_job_history.json` | File tracking completed jobs |

### Windows-Specific Defaults

On Windows, file paths default to the project directory:
- `PIPELINE_LOCK_FILE`: `{PROJECT_ROOT}/pipeline.lock`
- `PIPELINE_QUEUE_DIR`: `{PROJECT_ROOT}/pipeline_queue`
- `PIPELINE_RUNNING_JOB_FILE`: `{PROJECT_ROOT}/pipeline_running_job.json`
- `PIPELINE_JOB_HISTORY_FILE`: `{PROJECT_ROOT}/pipeline_job_history.json`

### Setting Environment Variables

**Windows PowerShell:**
```powershell
$env:PIPELINE_ENABLED = "true"
$env:PIPELINE_INTERVAL_MINUTES = "5"
$env:PIPELINE_TYPE = "all"
```

**Linux/macOS Bash:**
```bash
export PIPELINE_ENABLED=true
export PIPELINE_INTERVAL_MINUTES=5
export PIPELINE_TYPE=all
```

**Docker:**
```bash
docker run -e PIPELINE_ENABLED=true -e PIPELINE_TYPE=all ...
```

---

## 10. Installation Guide

### Prerequisites

1. **Python 3.10+** installed and available in PATH
2. **AWS credentials** configured (via environment or AWS CLI)
3. **Microsoft Graph API** credentials (client ID, client secret, tenant ID)
4. **Network access** to Microsoft Graph API and AWS services

### Step-by-Step Setup

**Step 1: Clone or navigate to the project**
```powershell
cd "C:\path\to\agentic-colleague-v2"
```

**Step 2: Create and activate virtual environment**
```powershell
# Create virtual environment
python -m venv venv

# Activate (Windows PowerShell)
.\venv\Scripts\Activate.ps1
```

**Step 3: Install dependencies**
```powershell
pip install -r requirements.txt
```

**Step 4: Verify APScheduler is installed**
```powershell
pip show apscheduler
```

**Step 5: Create required directories**
```powershell
New-Item -ItemType Directory -Force -Path logs
New-Item -ItemType Directory -Force -Path pipeline_queue
```

**Step 6: Configure environment variables**
```powershell
# Copy example env file (if exists)
Copy-Item .env.example .env

# Edit .env with your configuration
notepad .env
```

**Step 7: Verify installation**
```powershell
python -c "from pipeline_scheduler.run import main; print('Installation OK')"
```

### Verification Checklist

| Check | Command | Expected Result |
|-------|---------|-----------------|
| Module imports | `python -c "from pipeline_scheduler.run import main"` | No errors |
| Status command | `python -m pipeline_scheduler.run --status` | Shows status output |
| APScheduler | `pip show apscheduler` | Shows package info |
| Logs directory | `Test-Path logs` | True |

---

## 11. Build Process

### Build Commands

This module does not require a traditional build process. It runs directly from Python source files.

```powershell
# No build required - run directly
python -m pipeline_scheduler.run
```

### Docker Build

```powershell
# Build Docker image
docker build -t agentic-colleague .

# Verify build
docker images | Select-String agentic-colleague
```

### Generated Artifacts

| Artifact | Location | Description |
|----------|----------|-------------|
| `__pycache__/` | Each module directory | Python bytecode cache |
| `*.pyc` | `__pycache__/` | Compiled Python files |
| Log files | `logs/` | Runtime logs |
| Queue files | `pipeline_queue/` | Pending job JSON files |

---

## 12. Running the Application

### Local Execution

**Default Run (Scheduler + Worker):**
```powershell
python -m pipeline_scheduler.run
```

**With Custom Settings:**
```powershell
# 5-minute interval
python -m pipeline_scheduler.run --interval 5

# Worker only (no scheduled jobs)
python -m pipeline_scheduler.run --disabled

# With detailed job logging
python -m pipeline_scheduler.run --enable-job-logging
```

### Development Mode

```powershell
# Run with verbose Python output
python -u -m pipeline_scheduler.run 2>&1 | Tee-Object -FilePath debug.log
```

### Production Mode (Docker)

```powershell
# Using Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f scheduler
```

### Debug Mode

```powershell
# Test unified pipeline directly (dry run)
python -m pipeline_scheduler.unified_pipeline --dry-run

# Check status
python -m pipeline_scheduler.run --status
```

### All CLI Options

| Command | Description |
|---------|-------------|
| `python -m pipeline_scheduler.run` | Combined scheduler + worker |
| `python -m pipeline_scheduler.run --interval N` | Set interval to N minutes |
| `python -m pipeline_scheduler.run --pipeline transcript` | Set pipeline type (transcript is default) |
| `python -m pipeline_scheduler.run --enabled` | Force enable scheduler |
| `python -m pipeline_scheduler.run --disabled` | Disable scheduler (worker only) |
| `python -m pipeline_scheduler.run --enable-job-logging` | Enable detailed JSON logs |
| `python -m pipeline_scheduler.run --status` | Show formatted status |
| `python -m pipeline_scheduler.run --status-json` | Show JSON status |
| `python -m pipeline_scheduler.run --submit` | Submit manual job |
| `python -m pipeline_scheduler.worker` | Run worker only |
| `python -m pipeline_scheduler.worker --clear` | Clear job queue |
| `python -m pipeline_scheduler.scheduler` | Run scheduler only |
| `python -m pipeline_scheduler.unified_pipeline --dry-run` | Test pipeline without writes |

---

## 13. API Documentation

### Internal Python APIs

This module does not expose HTTP APIs. It provides Python functions for programmatic access.

#### `submit_job()` Function

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pipeline_type` | `str` | `"transcript"` | Pipeline: `transcript` |
| `transcript_mode` | `str` | `"incremental"` | Mode: `incremental` or `full` |
| `transcript_retry_failed` | `bool` | `True` | Retry failed transcripts |
| `ingestion_folder` | `str` | `"transcripts/"` | Legacy parameter (ignored) |
| `ingestion_skip_existing` | `bool` | `True` | Skip already indexed documents |
| `ingestion_dry_run` | `bool` | `False` | Don't write to databases |

**Returns:** `str` - Job ID

**Example:**
```python
from pipeline_scheduler.worker import submit_job

job_id = submit_job(
    pipeline_type="all",
    transcript_mode="incremental",
)
print(f"Submitted job: {job_id}")
```

#### `get_queue_status()` Function

**Returns:** Dictionary with queue and worker status

```python
{
    "queue_size": int,
    "lock_held": bool,
    "running_job": {
        "job_id": str,
        "pid": int,
        "started_at": str,  # ISO datetime
        "pipeline_type": str,
        "transcript_mode": str,
    } or None,
    "queued_jobs": [...],
    "recent_completed": [...],
}
```

#### `run_unified_pipeline()` Function

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `job_id` | `str` | Auto-generated | Unique job identifier |
| `pipeline_type` | `str` | `"transcript"` | Pipeline type |
| `transcript_mode` | `str` | `"incremental"` | Sync mode |
| `transcript_retry_failed` | `bool` | `True` | Retry failed items |
| `ingestion_folder` | `str` | `"transcripts/"` | Legacy (ignored) |
| `ingestion_skip_existing` | `bool` | `True` | Skip existing |
| `ingestion_dry_run` | `bool` | `False` | Dry run mode |

**Returns:** `UnifiedPipelineResult` dataclass

---

## 14. Database Documentation

### Database Types

This module interacts with databases through the ingestion modules:

| Database | Purpose |
|----------|---------|
| **AWS OpenSearch** | Full-text search index for meeting content |
| **AWS DynamoDB** | WorkItems table for tracking and metadata |

### DynamoDB Schema (WorkItems)

| Attribute | Type | Description |
|-----------|------|-------------|
| `work_item_id` | String (PK) | Unique identifier |
| `document_type` | String | `transcript` |
| `meeting_id` | String | Microsoft Teams meeting ID |
| `s3_path` | String | Path to document in S3 |
| `processed_at` | String | ISO timestamp |
| `project_id` | String | Matched project identifier |
| `status` | String | Processing status |

### Data Flow

```mermaid
flowchart LR
    subgraph "Pipeline Scheduler"
        PS[Scheduler] --> Q[Queue]
        Q --> W[Worker]
    end
    
    subgraph "Fetch Stage"
        W --> TPV2[Transcript Fetch]
        TPV2 --> GraphAPI[MS Graph API]
    end
    
    subgraph "Storage"
        GraphAPI --> S3[AWS S3<br/>DOCX Files]
    end
    
    subgraph "Ingestion Stage"
        S3 --> TI[Transcript Ingestion]
        TI --> OS[OpenSearch]
        TI --> DDB[DynamoDB]
    end
```

---

## 15. End-to-End Flow

### Request-to-Response Lifecycle

```mermaid
sequenceDiagram
    participant S as Scheduler
    participant Q as Job Queue
    participant W as Worker
    participant L as File Lock
    participant UP as Unified Pipeline
    participant TF as Transcript Fetch
    participant TI as Transcript Ingest
    participant Teams as MS Graph API
    participant S3 as AWS S3
    participant OS as OpenSearch
    
    S->>S: Timer triggers (every 1 min)
    S->>Q: Check queue size
    
    alt Queue < MAX_SIZE
        S->>Q: Submit new job
        Q->>Q: Write job JSON file
    else Queue >= MAX_SIZE
        S->>S: Skip (prevent pileup)
    end
    
    W->>Q: Poll for jobs
    Q->>W: Return job (FIFO)
    W->>L: Acquire lock
    
    alt Lock available
        L->>W: Lock acquired
        W->>UP: Execute pipeline
        
        UP->>TF: Run transcript fetch
        TF->>Teams: Get transcripts
        Teams->>TF: Return transcripts
        TF->>S3: Upload DOCX files
        
        UP->>TI: Run ingestion
        TI->>S3: Read DOCX files
        TI->>OS: Index documents
        
        UP->>W: Return result
        W->>W: Log result
        W->>L: Release lock
        
    else Lock held
        W->>W: Wait and retry
    end
```

### Job Lifecycle States

```mermaid
stateDiagram-v2
    [*] --> Submitted: Scheduler submits
    Submitted --> Queued: Added to queue
    Queued --> WaitingForLock: Worker picks up
    WaitingForLock --> Executing: Lock acquired
    WaitingForLock --> Queued: Lock busy (retry later)
    Executing --> Completed: Success
    Executing --> Failed: Error
    Completed --> [*]
    Failed --> [*]
```

---

## 16. Component Deep Dive

### 16.1 Scheduler (`scheduler.py`)

**Purpose:** Submit pipeline jobs to the queue at regular intervals.

**Inputs:**
- Environment variables (interval, pipeline type, etc.)
- Current queue status

**Outputs:**
- Job submissions to queue
- Log messages

**Dependencies:**
- APScheduler (`BlockingScheduler`, `IntervalTrigger`)
- `worker.py` (`submit_job`, `get_queue_status`)

**Internal Logic:**
1. Initialize APScheduler with interval trigger
2. On trigger: check queue size
3. If queue < MAX_SIZE: submit new job
4. If queue >= MAX_SIZE: skip (prevent pileup)

### 16.2 Worker (`worker.py`)

**Purpose:** Process jobs from the queue with locking to prevent concurrency.

**Inputs:**
- Jobs from queue (JSON files)
- Environment variables

**Outputs:**
- Processed job results
- Log files
- Job history

**Dependencies:**
- `unified_pipeline.py`
- File system (queue, lock, logs)

**Internal Logic:**
1. Poll queue directory for job files (FIFO order)
2. Attempt to acquire file lock
3. If locked: wait and retry
4. If available: dequeue job, execute pipeline
5. Write results to log and history
6. Release lock

### 16.3 Unified Pipeline (`unified_pipeline.py`)

**Purpose:** Orchestrate transcript pipeline execution.

**Inputs:**
- Job parameters (mode, flags)

**Outputs:**
- `UnifiedPipelineResult` with step results

**Dependencies:**
- `pipelines.py` (configuration)
- `transcript_pipeline.main_v2`
- `batch_data_ingestion.transcript.ingestion`

**Internal Logic:**
1. Parse pipeline parameters
2. Execute transcript fetch step
3. Execute ingestion step
4. Collect and aggregate results
5. Handle errors gracefully

### 16.4 Combined Runner (`run.py`)

**Purpose:** Run scheduler and worker in a single process.

**Inputs:**
- CLI arguments
- Environment variables

**Outputs:**
- Running scheduler + worker threads
- Combined logs

**Dependencies:**
- `scheduler.py` concepts
- `worker.py` (`PipelineWorker`, `submit_job`)
- Threading

**Internal Logic:**
1. Parse CLI arguments
2. Start worker in main thread
3. Start scheduler in daemon thread (if enabled)
4. Handle shutdown signals gracefully

### 16.5 Pipeline Configuration (`pipelines.py`)

**Purpose:** Define pipeline types and their configurations.

**Exports:**
- `PipelineType` enum
- `PipelineConfig` dataclass
- `PIPELINE_CONFIGS` dictionary

**Configuration Fields:**
- `name`: Display name
- `description`: Human-readable description
- `transcript_mode`: Sync mode
- `ingestion_prefix`: S3 folder prefix
- `run_transcript_fetch`: Whether to fetch from Teams
- `run_ingestion`: Whether to run ingestion

---

## 17. Data Flow

### Data Sources

| Source | Data Type | Frequency |
|--------|-----------|-----------|
| Microsoft Graph API | Meeting transcripts | On-demand (via pipeline) |
| DynamoDB | Processing state/history | On each job |

### Processing Steps

```mermaid
flowchart TD
    subgraph "1. Fetch Stage"
        A[Teams API] --> B[Parse Response]
        B --> C[Generate DOCX]
        C --> D[Upload to S3]
        D --> E[Update DynamoDB State]
    end
    
    subgraph "2. Ingestion Stage"
        F[List S3 Files] --> G[Download DOCX]
        G --> H[Extract Text]
        H --> I[LLM Processing]
        I --> J[Project Matching]
        J --> K[Generate Embeddings]
        K --> L[Index to OpenSearch]
        L --> M[Write to DynamoDB]
    end
    
    E --> F
```

### Storage Locations

| Data | Location | Format |
|------|----------|--------|
| Meeting transcripts | S3: `meetings/transcripts/{year}/{month}/{meeting_id}.docx` | DOCX |
| Search index | OpenSearch | JSON documents |
| Metadata | DynamoDB: WorkItems | Key-value records |

### Output Formats

| Output | Format | Destination |
|--------|--------|-------------|
| Job results | JSON | Log files, job history |
| Indexed documents | JSON | OpenSearch |
| Tracking records | DynamoDB items | DynamoDB |

---

## 18. Logging and Monitoring

### Logging Framework

| Logger Name | File | Purpose |
|-------------|------|---------|
| `pipeline_scheduler` | `logs/scheduler.log` | Scheduler events |
| `pipeline_worker` | `logs/worker.log` | Worker events |
| `pipeline_runner` | `logs/combined_runner.log` | Combined runner |
| `unified_pipeline` | Console only | Pipeline execution |

### Log Format

```
2026-08-20 14:30:22 | INFO    | pipeline_worker | 🔧 Processing job: transcript_20260820_143022
```

Format: `{timestamp} | {level:7} | {logger} | {message}`

### Log Levels

| Level | Usage |
|-------|-------|
| `DEBUG` | Detailed tracing (disabled by default) |
| `INFO` | Normal operations, job status |
| `WARNING` | Queue full, retries |
| `ERROR` | Failures, exceptions |

### Monitoring Tools

**Status Command:**
```powershell
python -m pipeline_scheduler.run --status
```

**Real-time Monitoring:**
```powershell
# Watch status every 5 seconds
while ($true) { 
    Clear-Host
    python -m pipeline_scheduler.run --status
    Start-Sleep -Seconds 5
}
```

**Log Tailing:**
```powershell
Get-Content -Path logs\worker.log -Tail 50 -Wait
```

### Alerting Mechanisms

This module does not include built-in alerting. Alerts should be configured externally:

- Monitor log files for ERROR entries
- Check queue size periodically
- Monitor job completion rate

---

## 19. Error Handling Strategy

### Error Types

| Error Type | Handling | Recovery |
|------------|----------|----------|
| API errors (Graph API) | Log, mark as failed | Retry on next job |
| Lock acquisition failure | Wait and retry | Automatic |
| Queue file corruption | Move to `.error` suffix | Manual cleanup |
| Pipeline step failure | Continue to next step | Partial results |
| Shutdown signal | Finish current job | Graceful |

### Retry Mechanisms

| Mechanism | Scope | Behavior |
|-----------|-------|----------|
| Lock retry | Worker | Poll every 0.5s until lock available |
| Job retry | Queue | Failed jobs can be resubmitted manually |
| Transcript retry | Pipeline | `--retry-failed` flag processes failed items |

### Fallback Behavior

```python
try:
    result = _run_transcript_fetch(mode, retry_failed)
except Exception as e:
    result.success = False
    result.error = str(e)
    logger.error(f"Transcript fetch error: {e}")
```

- Errors are caught and logged
- Pipeline continues with partial results
- Overall success reflects all step outcomes

### Recovery Approaches

| Scenario | Recovery Steps |
|----------|----------------|
| Stuck lock file | Remove lock file manually |
| Queue backup | Increase interval or clear old jobs |
| Pipeline failure | Review logs, fix issue, rerun |
| Corrupted job file | Remove `.error` files |

---

## 20. Security Considerations

### Authentication

| Service | Authentication Method |
|---------|----------------------|
| Microsoft Graph API | OAuth2 via MSAL (client credentials) |
| AWS Services | IAM roles or access keys via boto3 |

### Authorization

- Pipeline runs with configured AWS credentials
- Graph API access limited by app registration permissions
- No user-level authorization within the scheduler

### Secrets Management

| Secret | Storage | Best Practice |
|--------|---------|---------------|
| Graph API credentials | `.env` file or environment | Use AWS Secrets Manager in production |
| AWS credentials | Environment or IAM role | Use IAM roles when in AWS |

### Data Protection

- Meeting data stored encrypted at rest in S3
- DynamoDB encryption enabled by default
- No PII logged in log files (only IDs and counts)

### Security Best Practices

- ✅ Credentials never hardcoded
- ✅ Environment-based configuration
- ✅ Minimal logging of sensitive data
- ⚠️ Lock files in `/tmp` (consider secure location)
- ⚠️ Queue files not encrypted (consider for sensitive environments)

---

## 21. Testing

### Unit Tests

Currently, no dedicated unit tests exist for this module.

**Recommended Test Structure:**
```
tests/
└── pipeline_scheduler/
    ├── test_pipelines.py
    ├── test_worker.py
    ├── test_scheduler.py
    └── test_unified_pipeline.py
```

### Integration Tests

**Manual Integration Test:**
```powershell
# 1. Verify connections
python -m transcript_pipeline.main_v2 verify

# 2. Test dry run
python -m pipeline_scheduler.unified_pipeline --dry-run

# 3. Submit single job
python -m pipeline_scheduler.run --submit

# 4. Run worker once
python -m pipeline_scheduler.worker --poll-interval 60
```

### End-to-End Tests

```powershell
# Full E2E test
python -m pipeline_scheduler.run --interval 1 --pipeline transcript

# Verify after 2-3 minutes
python -m pipeline_scheduler.run --status
```

### Test Execution Commands

```powershell
# If tests are added:
python -m pytest tests/pipeline_scheduler/ -v
```

### Coverage Information

No coverage data available (tests not implemented).

---

## 22. Deployment

### Deployment Process

**Local Deployment:**
1. Clone repository
2. Install dependencies
3. Configure environment
4. Run `python -m pipeline_scheduler.run`

**Docker Deployment:**
1. Build image: `docker build -t agentic-colleague .`
2. Run container with environment variables
3. Monitor logs

### Pipeline Stages

| Stage | Action |
|-------|--------|
| Build | `docker build -t agentic-colleague .` |
| Test | Run integration tests |
| Deploy | Push to registry, deploy to container service |
| Monitor | Check logs and status |

### Infrastructure Requirements

| Resource | Minimum | Recommended |
|----------|---------|-------------|
| CPU | 0.5 vCPU | 1 vCPU |
| Memory | 512 MB | 1 GB |
| Storage | 100 MB | 500 MB |
| Network | Internet access | VPC with AWS endpoints |

### Rollback Process

1. Stop current container/process
2. Deploy previous version
3. Clear queue if needed: `python -m pipeline_scheduler.worker --clear`
4. Restart scheduler

### Docker Compose Deployment

```yaml
# docker-compose.yml (excerpt)
services:
  scheduler:
    build: .
    environment:
      - PIPELINE_ENABLED=true
      - PIPELINE_INTERVAL_MINUTES=1
      - PIPELINE_TYPE=all
    volumes:
      - ./logs:/app/logs
```

---

## 23. Troubleshooting Guide

| Problem | Possible Cause | Resolution |
|---------|----------------|------------|
| Jobs not processing | Lock file stuck | Remove `pipeline.lock` and `pipeline_running_job.json` |
| Queue keeps growing | Jobs taking too long | Increase `PIPELINE_INTERVAL_MINUTES` |
| "Module not found" error | Wrong directory or venv | `cd` to project root, activate venv |
| Permission denied on lock | Different user owns lock | `sudo rm /tmp/pipeline.lock` or change path |
| No jobs in queue | Normal behavior | Check "RECENT COMPLETED" in status |
| Pipeline returns empty | No new meetings | Check incremental date range |
| Graph API errors | Token expired or permissions | Verify credentials and app registration |
| S3 access denied | IAM permissions | Check boto3 credentials and bucket policy |
| OpenSearch timeout | Network or cluster issue | Verify OpenSearch endpoint and VPC |
| "Lock held by another process" | Concurrent worker | Stop duplicate workers or wait |

### Debug Commands

```powershell
# Check all temp files
Get-ChildItem -Path "$env:TEMP\pipeline*"

# View last 100 log lines
Get-Content -Path logs\worker.log -Tail 100

# Check if lock exists
Test-Path pipeline.lock

# Force clear everything
Remove-Item -Force pipeline.lock, pipeline_running_job.json -ErrorAction SilentlyContinue
python -m pipeline_scheduler.worker --clear
```

---

## 24. Performance Considerations

### Bottlenecks

| Bottleneck | Impact | Mitigation |
|------------|--------|------------|
| Graph API rate limits | Slow transcript fetch | Use incremental mode |
| Large DOCX processing | Memory usage | Process in batches |
| OpenSearch indexing | Throughput limits | Bulk indexing |
| Single worker | Sequential processing | Acceptable for current scale |

### Scalability Concerns

- **Single Worker**: Current design uses one worker; not horizontally scalable
- **File-based Queue**: Works for moderate load; Redis recommended for high volume
- **Sequential Pipelines**: All steps run sequentially; parallelism not supported

### Optimization Techniques

| Technique | Implementation |
|-----------|---------------|
| Incremental sync | Default mode - only fetches new meetings |
| Skip existing | Ingestion skips already-indexed documents |
| Queue size limit | Prevents unbounded queue growth |
| Lightweight history | Only keeps last 20 jobs in memory |

### Performance Metrics

| Metric | Typical Value |
|--------|---------------|
| Job execution time | 30-300 seconds |
| Queue throughput | ~1 job/minute |
| API calls per job | 10-50 (incremental) |
| Memory usage | 200-500 MB |

---

## 25. Assumptions and Limitations

### Assumptions

| Assumption | Implication |
|------------|-------------|
| Single machine deployment | No distributed coordination needed |
| Reliable file system | Queue and lock files are durable |
| Network connectivity | AWS and Graph API always reachable |
| Valid credentials | Auth tokens don't expire mid-job |
| Meeting transcripts available | Teams provides transcripts within minutes |

### Limitations

| Limitation | Impact | Workaround |
|------------|--------|------------|
| Single worker | No parallel processing | Acceptable for current volume |
| File-based queue | Not horizontally scalable | Use Redis for high scale |
| No dead-letter queue | Failed jobs need manual handling | Monitor logs |
| No priority queue | All jobs equal priority | Process critical data separately |
| Windows/Linux paths | Different defaults | Use environment variables |

### Technical Debt

| Item | Description | Priority |
|------|-------------|----------|
| No unit tests | Testing done manually | High |
| Legacy parameters | `ingestion_folder` parameter unused | Low |
| Hardcoded timeouts | Some waits are not configurable | Medium |
| Mixed logging | Console + file handlers | Low |

---

## 26. Future Improvements

### Architecture Improvements

| Improvement | Benefit | Effort |
|-------------|---------|--------|
| Redis-based queue | Scalable, persistent | Medium |
| Multiple workers | Parallel processing | High |
| Web dashboard | Better monitoring | Medium |
| Database-backed state | More reliable than files | Medium |

### Technical Improvements

| Improvement | Benefit | Effort |
|-------------|---------|--------|
| Add unit tests | Reliability, refactoring safety | Medium |
| Configurable timeouts | More control | Low |
| Dead-letter queue | Handle failures better | Medium |
| Metrics export | Prometheus/CloudWatch integration | Medium |
| Health check endpoint | Kubernetes readiness probe | Low |

### Feature Improvements

| Feature | Benefit | Effort |
|---------|---------|--------|
| Priority queue | Process important meetings first | Medium |
| Scheduled maintenance windows | Pause during updates | Low |
| Email notifications | Alert on failures | Low |
| Backfill command | Reprocess historical data | Medium |

---

## 27. Frequently Asked Questions

### General

**Q: What happens if I start two schedulers?**
A: Both will submit jobs to the same queue. The file lock prevents duplicate processing, but the queue will grow faster than expected.

**Q: What if a job fails?**
A: The job completes with `success=False`. Review logs for details. Submit a new job to retry.

### Configuration

**Q: How do I change the interval without restarting?**
A: Currently not supported. You must restart with the new `--interval` value.

**Q: Where are the queue files stored?**
A: On Linux: `/tmp/pipeline_queue/`. On Windows: `{project}/pipeline_queue/`. Configurable via `PIPELINE_QUEUE_DIR`.

**Q: What's the difference between `--enabled` and `--disabled`?**
A: `--enabled` runs scheduler + worker. `--disabled` runs worker only (processes manually submitted jobs).

### Operations

**Q: How do I clear a stuck queue?**
A: Run `python -m pipeline_scheduler.worker --clear`

**Q: How do I see what's running right now?**
A: Run `python -m pipeline_scheduler.run --status`

**Q: Why is job logging disabled by default?**
A: To prevent disk space accumulation (1440 files/day at 1-minute intervals).

### Troubleshooting

**Q: The scheduler says "Queue full" but I see no jobs running.**
A: The lock file may be stale. Remove it: `Remove-Item pipeline.lock`

**Q: Jobs are processing but nothing is indexed.**
A: Check if `--dry-run` is enabled or if there are no new meetings since last run.

---

## 28. Glossary

| Term | Definition |
|------|------------|
| **APScheduler** | Advanced Python Scheduler - library for job scheduling |
| **FIFO** | First In, First Out - queue ordering |
| **Graph API** | Microsoft Graph API - interface to Microsoft 365 data |
| **Incremental Mode** | Only fetch data since last successful run |
| **Ingestion** | Process of indexing data into OpenSearch/DynamoDB |
| **Job** | A unit of work (pipeline execution) |
| **Lock File** | File-based mutex to prevent concurrent execution |
| **OpenSearch** | AWS managed Elasticsearch service for search |
| **Pipeline** | Sequence of data processing steps |
| **Queue** | FIFO storage for pending jobs |
| **Scheduler** | Component that triggers jobs on a schedule |
| **Transcript** | Text record of a meeting conversation |
| **Worker** | Component that processes jobs from the queue |
| **WorkItems** | DynamoDB table storing meeting metadata |

---

## 29. Ownership and Support

### Team Ownership

| Role | Responsibility |
|------|----------------|
| Development Team | Feature development, bug fixes |
| DevOps Team | Deployment, monitoring, infrastructure |
| Support Team | User issues, log analysis |

### Support Process

1. **Check status**: `python -m pipeline_scheduler.run --status`
2. **Review logs**: `logs/worker.log`, `logs/scheduler.log`
3. **Search documentation**: This README and API docs
4. **Contact team**: Escalate to development team if unresolved

### Escalation Path

```
Level 1: Self-service (docs, logs, status)
    ↓
Level 2: Support team analysis
    ↓
Level 3: Development team investigation
    ↓
Level 4: Architecture review (for systemic issues)
```

---

## 30. Quick Start Guide

### 5-Minute Setup

**Step 1: Activate environment (30 seconds)**
```powershell
cd "C:\path\to\agentic-colleague-v2"
.\venv\Scripts\Activate.ps1
```

**Step 2: Verify installation (30 seconds)**
```powershell
python -c "from pipeline_scheduler.run import main; print('OK')"
```

**Step 3: Check current status (30 seconds)**
```powershell
python -m pipeline_scheduler.run --status
```

**Step 4: Submit a test job (30 seconds)**
```powershell
python -m pipeline_scheduler.run --submit --pipeline transcript
```

**Step 5: Start the scheduler (1 minute)**
```powershell
python -m pipeline_scheduler.run --interval 1
```

**Step 6: Verify it's working (2 minutes)**
```powershell
# In another terminal
python -m pipeline_scheduler.run --status
# Should show running job or recent completions
```

### Quick Reference Card

| Task | Command |
|------|---------|
| Start scheduler | `python -m pipeline_scheduler.run` |
| Check status | `python -m pipeline_scheduler.run --status` |
| Submit manual job | `python -m pipeline_scheduler.run --submit` |
| Stop scheduler | `Ctrl+C` |
| Clear queue | `python -m pipeline_scheduler.worker --clear` |
| View logs | `Get-Content logs\worker.log -Tail 50` |

### Common Workflows

**Run pipeline every 5 minutes:**
```powershell
python -m pipeline_scheduler.run --interval 5
```

**Test without writing to databases:**
```powershell
python -m pipeline_scheduler.unified_pipeline --dry-run
```

**Process only new data since a specific date:**
```powershell
python -m transcript_pipeline.main_v2 run --since "2026-08-01"
```

---

## Version History

| Version | Date | Changes |
|---------|------|--------|
| 2.0.0 | 2026-08-20 | Comprehensive documentation rewrite (transcript-focused) |
| 1.1.0 | 2026-08-04 | Configurable job logging (disabled by default) |
| 1.0.0 | 2026-08-03 | Initial release |

---

*Last updated: August 20, 2026*
