"""
Pipeline Configuration Module
=============================
Defines pipeline types and their configurations for the scheduler system.

Supported Pipeline Types:
- TRANSCRIPT: Fetches Teams transcripts → S3 → OpenSearch/DynamoDB
- CHAT: Ingests chat data from S3 → OpenSearch/DynamoDB
- ALL: Runs both transcript and chat pipelines sequentially

Usage:
    from pipeline_scheduler.pipelines import PipelineType, PIPELINE_CONFIGS
    
    # Get config for a specific pipeline
    config = PIPELINE_CONFIGS[PipelineType.TRANSCRIPT]
"""

from enum import Enum
from dataclasses import dataclass
from typing import Optional, Callable, Dict, Any


class PipelineType(str, Enum):
    """Supported pipeline types."""
    TRANSCRIPT = "transcript"
    CHAT = "chat"
    ALL = "all"
    
    @classmethod
    def from_string(cls, value: str) -> "PipelineType":
        """Convert string to PipelineType."""
        value = value.lower().strip()
        for pt in cls:
            if pt.value == value:
                return pt
        raise ValueError(f"Unknown pipeline type: {value}. Valid: {[p.value for p in cls]}")


@dataclass
class PipelineConfig:
    """Configuration for a specific pipeline type."""
    
    name: str
    description: str
    
    # Transcript pipeline settings (only for TRANSCRIPT type)
    transcript_mode: str = "incremental"  # "incremental" or "full"
    transcript_retry_failed: bool = True
    
    # Ingestion settings
    ingestion_prefix: str = ""  # S3 prefix for data
    ingestion_skip_existing: bool = True
    ingestion_dry_run: bool = False
    
    # Pipeline flags
    run_transcript_fetch: bool = False  # Whether to fetch from Teams API
    run_ingestion: bool = True  # Whether to run data ingestion


# ============================================================================
# PIPELINE CONFIGURATIONS
# ============================================================================

PIPELINE_CONFIGS: Dict[PipelineType, PipelineConfig] = {
    PipelineType.TRANSCRIPT: PipelineConfig(
        name="Transcript Pipeline",
        description="Fetch Teams transcripts and ingest to OpenSearch/DynamoDB",
        transcript_mode="incremental",
        transcript_retry_failed=True,
        ingestion_prefix="meetings/transcripts/",
        ingestion_skip_existing=True,
        run_transcript_fetch=True,
        run_ingestion=True,
    ),
    
    PipelineType.CHAT: PipelineConfig(
        name="Chat Pipeline", 
        description="Ingest chat data from S3 to OpenSearch/DynamoDB",
        ingestion_prefix="meetings/chats/",
        ingestion_skip_existing=True,
        run_transcript_fetch=False,  # Chat doesn't need Teams API fetch
        run_ingestion=True,
    ),
    
    PipelineType.ALL: PipelineConfig(
        name="All Pipelines",
        description="Run both transcript and chat pipelines sequentially",
        transcript_mode="incremental",
        transcript_retry_failed=True,
        ingestion_prefix="",  # Not used directly
        run_transcript_fetch=True,
        run_ingestion=True,
    ),
}


def get_pipeline_config(pipeline_type: PipelineType) -> PipelineConfig:
    """Get configuration for a pipeline type."""
    return PIPELINE_CONFIGS[pipeline_type]


def list_pipeline_types() -> list:
    """List all available pipeline types."""
    return [p.value for p in PipelineType]
