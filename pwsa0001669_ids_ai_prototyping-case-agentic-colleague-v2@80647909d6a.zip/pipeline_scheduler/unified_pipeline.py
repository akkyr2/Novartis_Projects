"""
Unified Pipeline Runner
=======================
Runs pipelines (transcript, chat, or all) based on the specified type.

This module is called by the worker when processing a job from the queue.

Pipeline Types:
- TRANSCRIPT: Fetch Teams transcripts → S3 → OpenSearch/DynamoDB
- CHAT: Ingest chat data from S3 → OpenSearch/DynamoDB  
- ALL: Run both transcript and chat pipelines sequentially

The pipelines run in incremental mode by default to minimize processing time.
"""

import os
import sys
import time
import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from dataclasses import dataclass, field

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

from pipeline_scheduler.pipelines import PipelineType, PipelineConfig, get_pipeline_config

# ============================================================================
# LOGGING SETUP
# ============================================================================
logger = logging.getLogger("unified_pipeline")
logger.setLevel(logging.INFO)

if not logger.handlers:
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

logger.propagate = False


# ============================================================================
# RESULT DATA CLASSES
# ============================================================================
@dataclass
class PipelineStepResult:
    """Result of a single pipeline step."""
    name: str = ""
    success: bool = False
    processed: int = 0
    skipped: int = 0
    failed: int = 0
    error: Optional[str] = None
    duration_seconds: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "success": self.success,
            "processed": self.processed,
            "skipped": self.skipped,
            "failed": self.failed,
            "error": self.error,
            "duration_seconds": self.duration_seconds
        }


@dataclass
class UnifiedPipelineResult:
    """Result of a unified pipeline run."""
    
    job_id: str = ""
    pipeline_type: str = ""
    started_at: str = ""
    completed_at: str = ""
    duration_seconds: float = 0.0
    
    # Step results
    steps: Dict[str, PipelineStepResult] = field(default_factory=dict)
    
    # Legacy fields for backward compatibility
    transcript_success: bool = False
    transcript_processed: int = 0
    transcript_skipped: int = 0
    transcript_failed: int = 0
    transcript_error: Optional[str] = None
    
    ingestion_success: bool = False
    ingestion_processed: int = 0
    ingestion_skipped: int = 0
    ingestion_failed: int = 0
    ingestion_error: Optional[str] = None
    
    # Overall status
    overall_success: bool = False
    errors: list = field(default_factory=list)
    
    def add_step_result(self, step_name: str, result: PipelineStepResult):
        """Add a step result."""
        self.steps[step_name] = result
        
        # Update legacy fields for backward compatibility
        if step_name == "transcript_fetch":
            self.transcript_success = result.success
            self.transcript_processed = result.processed
            self.transcript_skipped = result.skipped
            self.transcript_failed = result.failed
            self.transcript_error = result.error
        elif step_name in ("transcript_ingestion", "chat_ingestion"):
            self.ingestion_success = result.success
            self.ingestion_processed = result.processed
            self.ingestion_skipped = result.skipped
            self.ingestion_failed = result.failed
            self.ingestion_error = result.error
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "job_id": self.job_id,
            "pipeline_type": self.pipeline_type,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "duration_seconds": self.duration_seconds,
            "steps": {k: v.to_dict() for k, v in self.steps.items()},
            # Legacy format for backward compatibility
            "transcript": {
                "success": self.transcript_success,
                "processed": self.transcript_processed,
                "skipped": self.transcript_skipped,
                "failed": self.transcript_failed,
                "error": self.transcript_error
            },
            "ingestion": {
                "success": self.ingestion_success,
                "processed": self.ingestion_processed,
                "skipped": self.ingestion_skipped,
                "failed": self.ingestion_failed,
                "error": self.ingestion_error
            },
            "overall_success": self.overall_success,
            "errors": self.errors
        }


# ============================================================================
# PIPELINE STEP RUNNERS
# ============================================================================

def _run_transcript_fetch(
    mode: str = "incremental",
    retry_failed: bool = True,
) -> PipelineStepResult:
    """Run the transcript fetch pipeline (Teams API → S3)."""
    result = PipelineStepResult(name="transcript_fetch")
    start_time = time.time()
    
    try:
        from transcript_pipeline.main_v2 import TranscriptPipelineV2
        
        pipeline = TranscriptPipelineV2()
        transcript_result = pipeline.run(
            mode=mode,
            retry_failed=retry_failed,
        )
        
        result.success = transcript_result.failed == 0
        result.processed = transcript_result.processed
        result.skipped = transcript_result.skipped
        result.failed = transcript_result.failed
        
        if transcript_result.errors:
            result.error = "; ".join(transcript_result.errors[:3])
        
    except Exception as e:
        result.success = False
        result.error = str(e)
        logger.error(f"Transcript fetch error: {e}")
    
    result.duration_seconds = round(time.time() - start_time, 2)
    return result


def _run_transcript_ingestion(
    skip_existing: bool = True,
    dry_run: bool = False,
) -> PipelineStepResult:
    """Run the transcript ingestion pipeline (S3 → OpenSearch/DynamoDB)."""
    result = PipelineStepResult(name="transcript_ingestion")
    start_time = time.time()
    
    try:
        from batch_data_ingestion.transcript.ingestion import process_transcript_folder
        
        stats = process_transcript_folder(
            dry_run=dry_run,
            skip_existing=skip_existing,
            verbose=False
        )
        
        result.success = True
        result.processed = stats.get("indexed", 0)
        result.skipped = stats.get("skipped_duplicate", 0) + stats.get("skipped_error", 0)
        result.failed = stats.get("failed", 0)
        
        if result.failed > 0:
            result.success = False
        
    except Exception as e:
        result.success = False
        result.error = str(e)
        logger.error(f"Transcript ingestion error: {e}")
    
    result.duration_seconds = round(time.time() - start_time, 2)
    return result


def _run_chat_fetch(
    mode: str = "incremental",
    retry_failed: bool = True,
    min_messages: int = 1,
) -> PipelineStepResult:
    """Run the chat fetch pipeline (Teams Graph API → S3)."""
    result = PipelineStepResult(name="chat_fetch")
    start_time = time.time()
    
    try:
        from transcript_pipeline.main_chat import MeetingChatPipeline
        
        pipeline = MeetingChatPipeline()
        chat_result = pipeline.run(
            mode=mode,
            retry_failed=retry_failed,
            min_messages=min_messages,
        )
        
        result.success = chat_result.failed == 0
        result.processed = chat_result.processed
        result.skipped = chat_result.skipped
        result.failed = chat_result.failed
        
        if chat_result.errors:
            result.error = "; ".join(chat_result.errors[:3])
        
    except Exception as e:
        result.success = False
        result.error = str(e)
        logger.error(f"Chat fetch error: {e}")
    
    result.duration_seconds = round(time.time() - start_time, 2)
    return result


def _run_chat_ingestion(
    skip_existing: bool = True,
    dry_run: bool = False,
) -> PipelineStepResult:
    """Run the chat ingestion pipeline (S3 → OpenSearch/DynamoDB)."""
    result = PipelineStepResult(name="chat_ingestion")
    start_time = time.time()
    
    try:
        from batch_data_ingestion.chat.ingestion import process_chat_folder
        
        stats = process_chat_folder(
            dry_run=dry_run,
            skip_existing=skip_existing,
            verbose=False
        )
        
        result.success = True
        result.processed = stats.get("indexed", 0)
        result.skipped = stats.get("skipped_duplicate", 0) + stats.get("skipped_error", 0)
        result.failed = stats.get("failed", 0)
        
        if result.failed > 0:
            result.success = False
        
    except Exception as e:
        result.success = False
        result.error = str(e)
        logger.error(f"Chat ingestion error: {e}")
    
    result.duration_seconds = round(time.time() - start_time, 2)
    return result


# ============================================================================
# MAIN PIPELINE RUNNERS
# ============================================================================

def run_transcript_pipeline(
    job_id: str = None,
    transcript_mode: str = "incremental",
    transcript_retry_failed: bool = True,
    ingestion_skip_existing: bool = True,
    ingestion_dry_run: bool = False,
) -> UnifiedPipelineResult:
    """
    Run the transcript pipeline (fetch + ingest).
    
    Steps:
    1. Fetch transcripts from Teams API → S3
    2. Ingest transcripts from S3 → OpenSearch/DynamoDB
    """
    if job_id is None:
        job_id = f"transcript_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    
    result = UnifiedPipelineResult(
        job_id=job_id,
        pipeline_type=PipelineType.TRANSCRIPT.value,
        started_at=datetime.now(timezone.utc).isoformat()
    )
    
    start_time = time.time()
    
    logger.info("=" * 70)
    logger.info(f"TRANSCRIPT PIPELINE STARTING | Job ID: {job_id}")
    logger.info("=" * 70)
    logger.info(f"  Mode: {transcript_mode}")
    logger.info(f"  Retry Failed: {transcript_retry_failed}")
    logger.info(f"  Skip Existing: {ingestion_skip_existing}")
    logger.info(f"  Dry Run: {ingestion_dry_run}")
    logger.info("-" * 70)
    
    # Step 1: Fetch transcripts
    logger.info("\n[STEP 1/2] 📄 Fetching Teams Transcripts...")
    fetch_result = _run_transcript_fetch(transcript_mode, transcript_retry_failed)
    result.add_step_result("transcript_fetch", fetch_result)
    
    if fetch_result.success:
        logger.info(f"  ✅ Fetch Complete: {fetch_result.processed} processed, {fetch_result.skipped} skipped")
    else:
        logger.error(f"  ❌ Fetch Failed: {fetch_result.error}")
        result.errors.append(f"[Fetch] {fetch_result.error}")
    
    # Step 2: Ingest transcripts (only if fetch processed something OR this is a retry)
    # Skip ingestion if fetch processed 0 new items to avoid duplicate processing
    should_run_ingestion = fetch_result.processed > 0 or fetch_result.failed > 0
    
    if should_run_ingestion:
        logger.info("\n[STEP 2/2] 🚀 Ingesting Transcripts to OpenSearch/DynamoDB...")
        ingest_result = _run_transcript_ingestion(ingestion_skip_existing, ingestion_dry_run)
        result.add_step_result("transcript_ingestion", ingest_result)
        
        if ingest_result.success:
            logger.info(f"  ✅ Ingestion Complete: {ingest_result.processed} indexed, {ingest_result.skipped} skipped")
        else:
            logger.error(f"  ❌ Ingestion Failed: {ingest_result.error}")
            result.errors.append(f"[Ingestion] {ingest_result.error}")
    else:
        logger.info("\n[STEP 2/2] ⏭️  Skipping Ingestion (no new transcripts to process)")
        # Create a skipped result
        ingest_result = PipelineStepResult(
            name="transcript_ingestion",
            success=True,
            processed=0,
            skipped=0,
            failed=0,
            duration_seconds=0.0
        )
        result.add_step_result("transcript_ingestion", ingest_result)
    
    # Finalize
    result.completed_at = datetime.now(timezone.utc).isoformat()
    result.duration_seconds = round(time.time() - start_time, 2)
    result.overall_success = fetch_result.success and ingest_result.success
    
    _log_pipeline_summary(result)
    return result


def run_chat_pipeline(
    job_id: str = None,
    chat_mode: str = "incremental",
    chat_retry_failed: bool = True,
    ingestion_skip_existing: bool = True,
    ingestion_dry_run: bool = False,
) -> UnifiedPipelineResult:
    """
    Run the chat pipeline (fetch + ingest).
    
    Steps:
    1. Fetch chats from Teams API → S3
    2. Ingest chats from S3 → OpenSearch/DynamoDB
    """
    if job_id is None:
        job_id = f"chat_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    
    result = UnifiedPipelineResult(
        job_id=job_id,
        pipeline_type=PipelineType.CHAT.value,
        started_at=datetime.now(timezone.utc).isoformat()
    )
    
    start_time = time.time()
    
    logger.info("=" * 70)
    logger.info(f"CHAT PIPELINE STARTING | Job ID: {job_id}")
    logger.info("=" * 70)
    logger.info(f"  Mode: {chat_mode}")
    logger.info(f"  Retry Failed: {chat_retry_failed}")
    logger.info(f"  Skip Existing: {ingestion_skip_existing}")
    logger.info(f"  Dry Run: {ingestion_dry_run}")
    logger.info("-" * 70)
    
    # Step 1: Fetch chats from Graph API
    logger.info("\n[STEP 1/2] 💬 Fetching Teams Chats...")
    fetch_result = _run_chat_fetch(chat_mode, chat_retry_failed)
    result.add_step_result("chat_fetch", fetch_result)
    
    if fetch_result.success:
        logger.info(f"  ✅ Fetch Complete: {fetch_result.processed} processed, {fetch_result.skipped} skipped")
    else:
        logger.error(f"  ❌ Fetch Failed: {fetch_result.error}")
        result.errors.append(f"[Chat Fetch] {fetch_result.error}")
    
    # Step 2: Ingest chats (only if fetch processed something OR this is a retry)
    # Skip ingestion if fetch processed 0 new items to avoid duplicate processing
    should_run_ingestion = fetch_result.processed > 0 or fetch_result.failed > 0
    
    if should_run_ingestion:
        logger.info("\n[STEP 2/2] 🚀 Ingesting Chats to OpenSearch/DynamoDB...")
        ingest_result = _run_chat_ingestion(ingestion_skip_existing, ingestion_dry_run)
        result.add_step_result("chat_ingestion", ingest_result)
        
        if ingest_result.success:
            logger.info(f"  ✅ Ingestion Complete: {ingest_result.processed} indexed, {ingest_result.skipped} skipped")
        else:
            logger.error(f"  ❌ Ingestion Failed: {ingest_result.error}")
            result.errors.append(f"[Chat Ingestion] {ingest_result.error}")
    else:
        logger.info("\n[STEP 2/2] ⏭️  Skipping Ingestion (no new chats to process)")
        # Create a skipped result
        ingest_result = PipelineStepResult(
            name="chat_ingestion",
            success=True,
            processed=0,
            skipped=0,
            failed=0,
            duration_seconds=0.0
        )
        result.add_step_result("chat_ingestion", ingest_result)
    
    # Finalize
    result.completed_at = datetime.now(timezone.utc).isoformat()
    result.duration_seconds = round(time.time() - start_time, 2)
    result.overall_success = fetch_result.success and ingest_result.success
    
    # Set ingestion fields for backward compatibility
    result.ingestion_success = ingest_result.success
    result.ingestion_processed = ingest_result.processed
    result.ingestion_skipped = ingest_result.skipped
    result.ingestion_failed = ingest_result.failed
    result.ingestion_error = ingest_result.error
    
    _log_pipeline_summary(result)
    return result


def run_all_pipelines(
    job_id: str = None,
    transcript_mode: str = "incremental",
    transcript_retry_failed: bool = True,
    ingestion_skip_existing: bool = True,
    ingestion_dry_run: bool = False,
) -> UnifiedPipelineResult:
    """
    Run all pipelines sequentially (transcript + chat).
    
    Steps:
    1. Fetch transcripts from Teams API → S3
    2. Ingest transcripts from S3 → OpenSearch/DynamoDB
    3. Fetch chats from Teams API → S3
    4. Ingest chats from S3 → OpenSearch/DynamoDB
    """
    if job_id is None:
        job_id = f"all_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    
    result = UnifiedPipelineResult(
        job_id=job_id,
        pipeline_type=PipelineType.ALL.value,
        started_at=datetime.now(timezone.utc).isoformat()
    )
    
    start_time = time.time()
    
    logger.info("=" * 70)
    logger.info(f"ALL PIPELINES STARTING | Job ID: {job_id}")
    logger.info("=" * 70)
    logger.info(f"  Transcript Mode: {transcript_mode}")
    logger.info(f"  Retry Failed: {transcript_retry_failed}")
    logger.info(f"  Skip Existing: {ingestion_skip_existing}")
    logger.info(f"  Dry Run: {ingestion_dry_run}")
    logger.info("-" * 70)
    
    # Step 1: Fetch transcripts
    logger.info("\n[STEP 1/4] 📄 Fetching Teams Transcripts...")
    fetch_result = _run_transcript_fetch(transcript_mode, transcript_retry_failed)
    result.add_step_result("transcript_fetch", fetch_result)
    
    if fetch_result.success:
        logger.info(f"  ✅ Fetch Complete: {fetch_result.processed} processed")
    else:
        logger.error(f"  ❌ Fetch Failed: {fetch_result.error}")
        result.errors.append(f"[Transcript Fetch] {fetch_result.error}")
    
    # Step 2: Ingest transcripts
    logger.info("\n[STEP 2/4] 🚀 Ingesting Transcripts...")
    transcript_ingest = _run_transcript_ingestion(ingestion_skip_existing, ingestion_dry_run)
    result.add_step_result("transcript_ingestion", transcript_ingest)
    
    if transcript_ingest.success:
        logger.info(f"  ✅ Transcript Ingestion Complete: {transcript_ingest.processed} indexed")
    else:
        logger.error(f"  ❌ Transcript Ingestion Failed: {transcript_ingest.error}")
        result.errors.append(f"[Transcript Ingestion] {transcript_ingest.error}")
    
    # Step 3: Fetch chats
    logger.info("\n[STEP 3/4] 💬 Fetching Teams Chats...")
    chat_fetch = _run_chat_fetch(transcript_mode, transcript_retry_failed)
    result.add_step_result("chat_fetch", chat_fetch)
    
    if chat_fetch.success:
        logger.info(f"  ✅ Chat Fetch Complete: {chat_fetch.processed} processed")
    else:
        logger.error(f"  ❌ Chat Fetch Failed: {chat_fetch.error}")
        result.errors.append(f"[Chat Fetch] {chat_fetch.error}")
    
    # Step 4: Ingest chats
    logger.info("\n[STEP 4/4] 🚀 Ingesting Chats...")
    chat_ingest = _run_chat_ingestion(ingestion_skip_existing, ingestion_dry_run)
    result.add_step_result("chat_ingestion", chat_ingest)
    
    if chat_ingest.success:
        logger.info(f"  ✅ Chat Ingestion Complete: {chat_ingest.processed} indexed")
    else:
        logger.error(f"  ❌ Chat Ingestion Failed: {chat_ingest.error}")
        result.errors.append(f"[Chat Ingestion] {chat_ingest.error}")
    
    # Finalize
    result.completed_at = datetime.now(timezone.utc).isoformat()
    result.duration_seconds = round(time.time() - start_time, 2)
    result.overall_success = all(step.success for step in result.steps.values())
    
    # Set legacy fields
    result.transcript_success = fetch_result.success
    result.transcript_processed = fetch_result.processed
    result.transcript_skipped = fetch_result.skipped
    result.transcript_failed = fetch_result.failed
    result.transcript_error = fetch_result.error
    
    # Set combined ingestion stats
    result.ingestion_processed = transcript_ingest.processed + chat_ingest.processed
    result.ingestion_skipped = transcript_ingest.skipped + chat_ingest.skipped
    result.ingestion_failed = transcript_ingest.failed + chat_ingest.failed
    result.ingestion_success = transcript_ingest.success and chat_ingest.success
    
    _log_pipeline_summary(result)
    return result


def _log_pipeline_summary(result: UnifiedPipelineResult):
    """Log pipeline summary."""
    logger.info("\n" + "=" * 70)
    logger.info(f"PIPELINE COMPLETE: {result.pipeline_type.upper()}")
    logger.info("=" * 70)
    logger.info(f"  Job ID: {result.job_id}")
    logger.info(f"  Duration: {result.duration_seconds} seconds")
    logger.info(f"  Overall Success: {'✅ YES' if result.overall_success else '❌ NO'}")
    
    if result.steps:
        logger.info(f"  Steps:")
        for name, step in result.steps.items():
            icon = "✅" if step.success else "❌"
            logger.info(f"    {icon} {name}: {step.processed} processed, {step.skipped} skipped, {step.failed} failed ({step.duration_seconds}s)")
    
    if result.errors:
        logger.info(f"  Errors ({len(result.errors)}):")
        for err in result.errors[:5]:
            logger.info(f"    • {err[:100]}")
    
    logger.info("=" * 70 + "\n")


# ============================================================================
# UNIFIED PIPELINE ENTRY POINT
# ============================================================================

def run_unified_pipeline(
    job_id: str = None,
    pipeline_type: str = "transcript",
    transcript_mode: str = "incremental",
    transcript_retry_failed: bool = True,
    ingestion_folder: str = "transcripts/",  # Legacy parameter, ignored
    ingestion_skip_existing: bool = True,
    ingestion_dry_run: bool = False,
) -> UnifiedPipelineResult:
    """
    Run unified pipeline based on type.
    
    This is the main entry point called by the worker.
    
    Args:
        job_id: Unique identifier for this job
        pipeline_type: 'transcript', 'chat', or 'all'
        transcript_mode: 'incremental' or 'full' (for transcript pipeline)
        transcript_retry_failed: Whether to retry failed transcripts
        ingestion_folder: Legacy parameter, ignored (kept for backward compatibility)
        ingestion_skip_existing: Skip already indexed documents
        ingestion_dry_run: Don't write to databases
        
    Returns:
        UnifiedPipelineResult with results from the pipeline
    """
    # Convert string to enum if needed
    if isinstance(pipeline_type, str):
        try:
            pipeline_type_enum = PipelineType.from_string(pipeline_type)
        except ValueError:
            # Default to transcript for backward compatibility
            logger.warning(f"Unknown pipeline type '{pipeline_type}', defaulting to 'transcript'")
            pipeline_type_enum = PipelineType.TRANSCRIPT
    else:
        pipeline_type_enum = pipeline_type
    
    if pipeline_type_enum == PipelineType.TRANSCRIPT:
        return run_transcript_pipeline(
            job_id=job_id,
            transcript_mode=transcript_mode,
            transcript_retry_failed=transcript_retry_failed,
            ingestion_skip_existing=ingestion_skip_existing,
            ingestion_dry_run=ingestion_dry_run,
        )
    
    elif pipeline_type_enum == PipelineType.CHAT:
        return run_chat_pipeline(
            job_id=job_id,
            ingestion_skip_existing=ingestion_skip_existing,
            ingestion_dry_run=ingestion_dry_run,
        )
    
    elif pipeline_type_enum == PipelineType.ALL:
        return run_all_pipelines(
            job_id=job_id,
            transcript_mode=transcript_mode,
            transcript_retry_failed=transcript_retry_failed,
            ingestion_skip_existing=ingestion_skip_existing,
            ingestion_dry_run=ingestion_dry_run,
        )
    
    else:
        raise ValueError(f"Unknown pipeline type: {pipeline_type_enum}")


# ============================================================================
# CLI ENTRY POINT (for testing)
# ============================================================================
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run pipeline manually")
    parser.add_argument("--pipeline", "-p", 
                        choices=["transcript", "chat", "all"],
                        default="transcript",
                        help="Pipeline type to run (default: transcript)")
    parser.add_argument("--mode", choices=["incremental", "full"], default="incremental",
                        help="Transcript fetch mode (default: incremental)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Don't write to databases")
    parser.add_argument("--no-retry", action="store_true",
                        help="Don't retry failed transcripts")
    parser.add_argument("--no-skip", action="store_true",
                        help="Don't skip existing documents")
    
    args = parser.parse_args()
    
    result = run_unified_pipeline(
        pipeline_type=args.pipeline,
        transcript_mode=args.mode,
        transcript_retry_failed=not args.no_retry,
        ingestion_skip_existing=not args.no_skip,
        ingestion_dry_run=args.dry_run,
    )
    
    print(f"\nResult: {result.to_dict()}")
