# Project Seeding Module

## Table of Contents
- [1. Module Overview](#1-module-overview)
- [2. Business Context](#2-business-context)
- [3. Functional Overview](#3-functional-overview)
- [4. Architecture Overview](#4-architecture-overview)
- [5. Folder Structure](#5-folder-structure)
- [6. Technology Stack](#6-technology-stack)
- [7. Dependencies](#7-dependencies)
- [8. Configuration](#8-configuration)
- [9. Environment Variables](#9-environment-variables)
- [10. Installation Guide](#10-installation-guide)
- [11. Build Process](#11-build-process)
- [12. Running the Application](#12-running-the-application)
- [13. API Documentation](#13-api-documentation)
- [14. Database Documentation](#14-database-documentation)
- [15. End-to-End Flow](#15-end-to-end-flow)
- [16. Component Deep Dive](#16-component-deep-dive)
- [17. Data Flow](#17-data-flow)
- [18. Logging and Monitoring](#18-logging-and-monitoring)
- [19. Error Handling Strategy](#19-error-handling-strategy)
- [20. Security Considerations](#20-security-considerations)
- [21. Testing](#21-testing)
- [22. Deployment](#22-deployment)
- [23. Troubleshooting Guide](#23-troubleshooting-guide)
- [24. Performance Considerations](#24-performance-considerations)
- [25. Assumptions and Limitations](#25-assumptions-and-limitations)
- [26. Future Improvements](#26-future-improvements)
- [27. Frequently Asked Questions](#27-frequently-asked-questions)
- [28. Glossary](#28-glossary)
- [29. Ownership and Support](#29-ownership-and-support)
- [30. Quick Start Guide](#30-quick-start-guide)

---

## 1. Module Overview

### What This Module Does
The **Project Seeding Module** provides a centralized service layer for managing projects in AWS DynamoDB. It serves as the foundational data store for project metadata within the Agentic Colleague application — an AI-powered project management assistant.

### Why It Exists
In the Agentic Colleague ecosystem, projects need to be pre-defined ("seeded") so that:
1. The AI agent can accurately match detected project names from meeting transcripts
2. Work items and evidence can be associated with correct, canonical project identifiers
3. Project metadata (descriptions, status, attached files) can be managed consistently

### Business Value
- **Prevents AI hallucination**: By constraining project matching to seeded projects, the system avoids creating phantom or duplicate projects
- **Ensures data consistency**: All modules reference the same canonical project data
- **Enables project lifecycle management**: Create, update, archive, and delete projects with file attachments

---

## 2. Business Context

### Business Purpose
The Agentic Colleague application ingests collaboration content (meeting transcripts) and extracts project-related signals. For this to work accurately, the system needs a **master list of approved projects** against which detected project names can be validated and matched.

### Use Cases

| Use Case | Description |
|----------|-------------|
| **UC-1: Seed New Project** | A product manager creates a new project with name, description, and optional reference files before onboarding begins |
| **UC-2: Match Project Name** | During batch ingestion, the LLM detects "Project Alpha" in a transcript; the system matches it to seeded project `PRJ_abc123` |
| **UC-3: Update Project Metadata** | Change project status from "Active" to "Inactive" when project is completed |
| **UC-4: Attach Reference Files** | Upload requirements documents, SOWs, or guidelines to provide context for AI matching |
| **UC-5: Archive Old Projects** | Delete deprecated projects and clean up associated data |

### Real-World Example
```
Scenario: New drug development project onboarding

1. Project Manager creates project via CLI:
   python -m project_seeding.test_projects_table --create \
     --name "Oncology Drug 2026 Phase III" \
     --desc "Clinical trial management for oncology drug candidate XYZ-789"

2. Uploads reference documents:
   python -m project_seeding.test_projects_table --add-file PRJ_abc123 --file protocol.pdf

3. When a meeting transcript mentions "the oncology project" or "XYZ-789 trial", 
   the AI matches it to the seeded project instead of creating duplicates
```

### Expected Outcomes
- Zero duplicate projects from AI-detected names
- 100% traceability from work items back to canonical projects
- Self-service project lifecycle management

---

## 3. Functional Overview

### Core Responsibilities
| Responsibility | Description |
|---------------|-------------|
| **Project CRUD** | Create, Read, Update, Delete operations for projects |
| **File Management** | Attach/remove files to projects (stored as content in DynamoDB) |
| **Search & Query** | Find projects by ID, list all projects, search by name |
| **Validation** | Ensure table exists, validate project existence before updates |

### Major Features

#### ✅ Included Features
- Create projects with optional file attachments
- Retrieve single project or list all projects
- Update project name, description, and status
- Add/remove files from existing projects
- Search projects by partial name match
- Command-line interface for testing and operations
- Lazy DynamoDB connection with automatic reconnection
- Comprehensive error handling with custom exceptions
- Decimal-to-native-type conversion for API responses

#### ❌ Intentionally Excluded
- Binary file storage (files stored as text/base64 in DynamoDB, not S3)
- Full-text search (basic in-memory name matching only)
- Project hierarchies or sub-projects
- User-level permissions per project
- Soft delete / version history
- Pagination tokens for large result sets

---

## 4. Architecture Overview

### High-Level Architecture

```mermaid
graph TB
    subgraph "Consumers"
        MAIN[main.py<br/>FastAPI Application]
        BATCH[batch_data_ingestion<br/>Project Matching]
        CLI[test_projects_table.py<br/>CLI Tool]
    end
    
    subgraph "Project Seeding Module"
        INIT[__init__.py<br/>Public API]
        SERVICE[projects_service.py<br/>Service Layer]
    end
    
    subgraph "AWS Infrastructure"
        DYNAMO[(DynamoDB<br/>AgenticColleague_Projects_Test)]
    end
    
    MAIN --> INIT
    BATCH --> INIT
    CLI --> SERVICE
    INIT --> SERVICE
    SERVICE --> DYNAMO
```

### Component Relationships

```mermaid
flowchart LR
    subgraph project_seeding
        A[__init__.py] --> B[projects_service.py]
    end
    
    subgraph Consumers
        C[main.py] --> A
        D[project_matching.py] --> A
        E[CLI] --> B
    end
    
    B --> F[(DynamoDB)]
```

### Dependency Relationships

```mermaid
graph TD
    PS[project_seeding] --> BOTO3[boto3]
    PS --> BOTOCORE[botocore]
    
    BOTO3 --> AWS[AWS SDK]
    
    subgraph "Internal Dependencies"
        BATCH[batch_data_ingestion] --> PS
        MAIN[main.py] --> PS
    end
```

---

## 5. Folder Structure

```
project_seeding/
├── __init__.py              # Public API - exports all service functions
├── projects_service.py      # Core service layer - all business logic
├── test_projects_table.py   # CLI tool for testing and operations
├── README.md                # This documentation
└── __pycache__/             # Python bytecode cache (generated)
```

### File Descriptions

| File | Purpose | Key Contents |
|------|---------|--------------|
| `__init__.py` | **Module entry point** | Exports all public functions, exceptions, and configuration constants |
| `projects_service.py` | **Service layer** | All DynamoDB CRUD operations, error handling, connection management |
| `test_projects_table.py` | **CLI tool** | Command-line interface for testing, verification, and data cleanup |

---

## 6. Technology Stack

| Category | Technology | Version | Purpose |
|----------|------------|---------|---------|
| **Language** | Python | 3.9+ | Primary language |
| **Cloud Provider** | AWS | - | Infrastructure platform |
| **Database** | DynamoDB | - | NoSQL data store for projects |
| **SDK** | boto3 | Latest | AWS SDK for Python |
| **Error Handling** | botocore | Latest | Low-level AWS client exceptions |

### Runtime Requirements
- Python 3.9 or higher
- Valid AWS credentials with DynamoDB permissions
- Network access to AWS DynamoDB service in `us-east-1` region

---

## 7. Dependencies

### Internal Dependencies

| Dependency | Why It Exists |
|------------|---------------|
| None | This module has no internal dependencies; it is a foundational module |

### External Dependencies

| Package | Version | Why It Exists |
|---------|---------|---------------|
| `boto3` | Latest | AWS SDK for DynamoDB operations |
| `botocore` | Latest | AWS error handling and exceptions |

### Third-Party Services

| Service | Purpose |
|---------|---------|
| AWS DynamoDB | NoSQL database for storing project metadata |
| AWS IAM | Authentication and authorization for DynamoDB access |

### Shared Libraries
This module is **consumed by** other modules:
- `main.py` - FastAPI endpoints for project management
- `batch_data_ingestion/core/project_matching.py` - Project name matching during batch processing

---

## 8. Configuration

### Hardcoded Configuration

Configuration is defined as constants at the top of `projects_service.py`:

```python
TABLE_NAME = "AgenticColleague_Projects_Test"
AWS_REGION = "us-east-1"
GSI_PROJECT_NAME = "GSI1-ProjectName-Index"
```

| Constant | Value | Description |
|----------|-------|-------------|
| `TABLE_NAME` | `AgenticColleague_Projects_Test` | DynamoDB table name |
| `AWS_REGION` | `us-east-1` | AWS region for DynamoDB |
| `GSI_PROJECT_NAME` | `GSI1-ProjectName-Index` | Global Secondary Index name (defined but not actively used) |

### Configuration Files
This module does not use external configuration files. All configuration is embedded in source code.

> ⚠️ **Technical Debt**: Configuration should be externalized to environment variables or a config file for different environments (dev, staging, production).

---

## 9. Environment Variables

### Required AWS Credentials

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AWS_ACCESS_KEY_ID` | Yes* | None | AWS access key for authentication |
| `AWS_SECRET_ACCESS_KEY` | Yes* | None | AWS secret key for authentication |
| `AWS_SESSION_TOKEN` | No | None | Session token for temporary credentials |
| `AWS_PROFILE` | No | `default` | AWS CLI profile name |
| `AWS_DEFAULT_REGION` | No | `us-east-1` | Default region (overridden by code) |

> \* Either environment variables, `~/.aws/credentials`, or IAM role must provide valid credentials.

### Module-Specific Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| None | - | - | Module uses hardcoded configuration |

---

## 10. Installation Guide

### Prerequisites
1. Python 3.9 or higher installed
2. AWS credentials configured (via environment variables, `~/.aws/credentials`, or IAM role)
3. DynamoDB table `AgenticColleague_Projects_Test` exists in `us-east-1`

### Step-by-Step Setup

```powershell
# 1. Clone the repository (if not already done)
git clone <repository-url>
cd agentic-colleague-v2

# 2. Create and activate virtual environment
python -m venv venv
.\venv\Scripts\Activate.ps1

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure AWS credentials (one of these methods)

# Method A: Environment variables
$env:AWS_ACCESS_KEY_ID = "your-access-key"
$env:AWS_SECRET_ACCESS_KEY = "your-secret-key"

# Method B: AWS CLI configuration
aws configure

# 5. Verify installation
python -m project_seeding.test_projects_table --verify
```

### Verification
After installation, run the verification command:
```powershell
python -m project_seeding.test_projects_table --verify
```

Expected output:
```
======================================================================
  TABLE VERIFICATION
======================================================================
✅ Table 'AgenticColleague_Projects_Test' exists
  Status: ACTIVE
  Items: 5
  Size: 2048 bytes
  GSIs: 1
    - GSI1-ProjectName-Index
```

---

## 11. Build Process

### Build Commands
This is a pure Python module with no compilation step.

```powershell
# No build required - Python interprets source directly

# To create a distribution package (optional)
python -m pip install build
python -m build
```

### Build Stages
| Stage | Description |
|-------|-------------|
| **Lint** | Code quality checks (not automated in this module) |
| **Test** | Run `--test` command to verify CRUD operations |
| **Package** | Standard Python wheel/sdist if needed |

### Generated Artifacts
| Artifact | Location | Description |
|----------|----------|-------------|
| `__pycache__/` | Module directory | Python bytecode (auto-generated) |

---

## 12. Running the Application

### As a Library
```python
# Import and use in your Python code
from project_seeding import (
    create_project,
    get_project,
    get_all_projects,
    update_project,
    delete_project,
    add_file_to_project,
)

# Create a project
project = create_project(
    project_name="My New Project",
    project_description="Description of the project"
)
print(f"Created: {project['project_id']}")

# Get all active projects
projects = get_all_projects(status_filter="Active")
for p in projects:
    print(f"- {p['project_name']}")
```

### Command-Line Interface

```powershell
# Verify table exists
python -m project_seeding.test_projects_table --verify

# Create a project
python -m project_seeding.test_projects_table --create --name "Project Alpha" --desc "Alpha description"

# Create with file attachment
python -m project_seeding.test_projects_table --create --name "Project Beta" --desc "Beta description" --file requirements.txt

# List all projects
python -m project_seeding.test_projects_table --list

# Get specific project
python -m project_seeding.test_projects_table --get PRJ_abc123

# Update project
python -m project_seeding.test_projects_table --update PRJ_abc123 --name "New Name" --desc "New Description"

# Add file to existing project
python -m project_seeding.test_projects_table --add-file PRJ_abc123 --file document.txt

# Delete project
python -m project_seeding.test_projects_table --delete PRJ_abc123

# Run all CRUD tests
python -m project_seeding.test_projects_table --test

# Cleanup test data
python -m project_seeding.test_projects_table --cleanup
```

### Debug Mode
Add Python debugging flags:
```powershell
# With verbose boto3 logging
$env:BOTO3_DEBUG = "true"
python -m project_seeding.test_projects_table --list

# With Python debugger
python -m pdb -m project_seeding.test_projects_table --get PRJ_abc123
```

---

## 13. API Documentation

This module provides a **programmatic API** (not HTTP). It is consumed by FastAPI endpoints in `main.py`.

### CRUD Operations

#### `create_project`

| Attribute | Details |
|-----------|---------|
| **Purpose** | Create a new project in DynamoDB |
| **Parameters** | `project_name: str`, `project_description: str`, `files: Optional[List[Dict]]` |
| **Returns** | `Dict` - Created project with generated `project_id` |
| **Raises** | `ProjectServiceError` on failure |

```python
# Example
project = create_project(
    project_name="Project Alpha",
    project_description="Description here",
    files=[
        {"file_name": "readme.txt", "file_type": "txt", "file_content": "Content..."}
    ]
)
# Returns: {"project_id": "PRJ_abc123", "project_name": "Project Alpha", ...}
```

#### `get_project`

| Attribute | Details |
|-----------|---------|
| **Purpose** | Retrieve a project by ID |
| **Parameters** | `project_id: str` |
| **Returns** | `Dict` if found, `None` if not found |
| **Raises** | `ProjectServiceError` on AWS errors |

#### `get_all_projects`

| Attribute | Details |
|-----------|---------|
| **Purpose** | List all projects with optional filtering |
| **Parameters** | `limit: Optional[int]`, `status_filter: Optional[str]` |
| **Returns** | `List[Dict]` - Projects sorted by created_at (newest first) |
| **Raises** | `ProjectServiceError` on AWS errors |

#### `update_project`

| Attribute | Details |
|-----------|---------|
| **Purpose** | Update project metadata |
| **Parameters** | `project_id: str`, `project_name: Optional[str]`, `project_description: Optional[str]`, `status: Optional[str]` |
| **Returns** | `Dict` - Updated project |
| **Raises** | `ProjectNotFoundError` if project doesn't exist |

#### `delete_project`

| Attribute | Details |
|-----------|---------|
| **Purpose** | Delete a project |
| **Parameters** | `project_id: str` |
| **Returns** | `bool` - True if deleted |
| **Raises** | `ProjectNotFoundError` if project doesn't exist |

### File Operations

#### `add_file_to_project`

| Attribute | Details |
|-----------|---------|
| **Purpose** | Add a file attachment to a project |
| **Parameters** | `project_id: str`, `file_name: str`, `file_type: str`, `file_content: str` |
| **Returns** | `Dict` - Created file record with `file_id` |
| **Raises** | `ProjectNotFoundError` if project doesn't exist |

#### `remove_file_from_project`

| Attribute | Details |
|-----------|---------|
| **Purpose** | Remove a file from a project |
| **Parameters** | `project_id: str`, `file_id: str` |
| **Returns** | `bool` - True if removed |
| **Raises** | `ProjectNotFoundError` if project or file doesn't exist |

#### `get_file_from_project`

| Attribute | Details |
|-----------|---------|
| **Purpose** | Retrieve a specific file from a project |
| **Parameters** | `project_id: str`, `file_id: str` |
| **Returns** | `Dict` - File record, `None` if not found |

### Utility Functions

| Function | Purpose |
|----------|---------|
| `verify_table_exists()` | Check if DynamoDB table exists and return status info |
| `search_projects_by_name(name_query)` | Search projects by partial name match (case-insensitive) |
| `reset_dynamodb_connection()` | Reset cached DynamoDB connection (for testing/reconnection) |

---

## 14. Database Documentation

### Database Type
**AWS DynamoDB** - Fully managed NoSQL database service

### Table Schema

#### Table: `AgenticColleague_Projects_Test`

| Attribute | Type | Description |
|-----------|------|-------------|
| `PK` | String (Partition Key) | Format: `PROJECT#{project_id}` |
| `SK` | String (Sort Key) | Always `METADATA` for project items |
| `project_id` | String | Unique identifier (format: `PRJ_xxxxxxxxxx`) |
| `project_name` | String | Human-readable project name |
| `project_description` | String | Detailed project description |
| `status` | String | Project status (`Active`, `Inactive`) |
| `created_at` | String | ISO 8601 timestamp |
| `updated_at` | String | ISO 8601 timestamp |
| `files` | List | Array of file attachment objects |
| `file_count` | Number | Count of attached files |

#### File Object Schema

| Attribute | Type | Description |
|-----------|------|-------------|
| `file_id` | String | Unique identifier (format: `FILE_xxxxxxxx`) |
| `file_name` | String | Original filename |
| `file_type` | String | File extension/type |
| `file_content` | String | File content (text or base64) |
| `uploaded_at` | String | ISO 8601 timestamp |

### Data Model Diagram

```mermaid
erDiagram
    PROJECT {
        string PK "PROJECT#id"
        string SK "METADATA"
        string project_id "PRJ_xxx"
        string project_name
        string project_description
        string status "Active|Inactive"
        string created_at
        string updated_at
        int file_count
    }
    
    FILE {
        string file_id "FILE_xxx"
        string file_name
        string file_type
        string file_content
        string uploaded_at
    }
    
    PROJECT ||--o{ FILE : "contains"
```

### Global Secondary Indexes

| Index Name | Partition Key | Sort Key | Purpose |
|------------|---------------|----------|---------|
| `GSI1-ProjectName-Index` | `project_name` | - | Query by project name (defined but not actively used) |

### Access Patterns

| Pattern | Implementation |
|---------|---------------|
| Get project by ID | `GetItem` on PK=`PROJECT#{id}`, SK=`METADATA` |
| List all projects | `Scan` with filter `SK = METADATA` |
| Filter by status | `Scan` with filter `status = {value}` |
| Search by name | In-memory filter after scan |

---

## 15. End-to-End Flow

### Create Project Flow

```mermaid
sequenceDiagram
    participant Client
    participant Service as projects_service
    participant DynamoDB
    
    Client->>Service: create_project(name, desc, files)
    Service->>Service: generate_project_id()
    Service->>Service: generate_file_id() for each file
    Service->>Service: Build item with timestamps
    Service->>DynamoDB: put_item(item)
    DynamoDB-->>Service: Success
    Service->>Service: sanitize_project(item)
    Service-->>Client: Return created project
```

### Project Matching Flow (Batch Ingestion)

```mermaid
sequenceDiagram
    participant Batch as Batch Ingestion
    participant ProjectMatching as project_matching.py
    participant Service as projects_service
    participant DynamoDB
    participant LLM as Bedrock LLM
    
    Note over Batch: Pipeline starts
    Batch->>ProjectMatching: load_seeded_projects()
    ProjectMatching->>Service: get_all_projects(status="Active")
    Service->>DynamoDB: scan(filter=METADATA, status=Active)
    DynamoDB-->>Service: List of projects
    Service-->>ProjectMatching: Seeded projects
    ProjectMatching->>ProjectMatching: Cache projects in memory
    
    Note over Batch: Processing transcript
    Batch->>ProjectMatching: match_project_with_llm(detected_names, content)
    ProjectMatching->>ProjectMatching: Build context from cache
    ProjectMatching->>LLM: Match prompt with context
    LLM-->>ProjectMatching: Matched project_id
    ProjectMatching-->>Batch: Canonical project info
```

---

## 16. Component Deep Dive

### `projects_service.py`

#### Purpose
Central service layer providing all DynamoDB operations for projects. Acts as the single source of truth for project data operations.

#### Inputs
- Project metadata (name, description, status)
- File attachments (name, type, content)
- Project IDs for queries

#### Outputs
- Sanitized project dictionaries (Decimal → native types)
- Boolean success indicators
- Exception classes for error conditions

#### Dependencies
- `boto3` - AWS SDK
- `botocore.exceptions` - Error handling

#### Internal Logic

**Connection Management**
```python
# Lazy initialization pattern
def get_dynamodb_table():
    global _dynamodb, _table
    if _table is None:
        _dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
        _table = _dynamodb.Table(TABLE_NAME)
    return _table
```

**ID Generation**
- Project IDs: `PRJ_{uuid_hex[:10]}` → e.g., `PRJ_a1b2c3d4e5`
- File IDs: `FILE_{uuid_hex[:8]}` → e.g., `FILE_f6g7h8i9`

**Timestamp Format**
- ISO 8601 UTC: `2026-07-31T14:30:00Z`

### `test_projects_table.py`

#### Purpose
Command-line interface for manual testing, verification, and operational tasks.

#### Inputs
- CLI arguments (see Running the Application section)

#### Outputs
- Formatted console output with emoji indicators
- Exit codes (0 = success, 1 = error)

#### Key Features
- `--test`: Runs comprehensive CRUD test suite
- `--cleanup`: Removes all items with `TEST_` prefix in name

---

## 17. Data Flow

### Data Sources
| Source | Data Type | Description |
|--------|-----------|-------------|
| User Input | Project metadata | Names, descriptions via CLI or API |
| File System | File content | Text files read and stored |
| DynamoDB | Persisted data | Retrieved projects and files |

### Processing
1. **Input Validation**: Basic parameter checks
2. **ID Generation**: UUID-based unique identifiers
3. **Timestamp Generation**: UTC ISO format
4. **DynamoDB Operations**: Put, Get, Update, Delete, Scan
5. **Response Sanitization**: Decimal → int/float conversion

### Storage
All data persisted to DynamoDB table `AgenticColleague_Projects_Test`

### Outputs
| Consumer | Data Type | Description |
|----------|-----------|-------------|
| FastAPI Endpoints | JSON | API responses |
| Batch Ingestion | Project list | Cached for LLM matching |
| CLI | Console output | Formatted display |

### Data Flow Diagram

```mermaid
flowchart TD
    subgraph Inputs
        CLI[CLI Input]
        API[API Request]
        FILES[File System]
    end
    
    subgraph Processing
        VALIDATE[Validate Input]
        GENERATE[Generate IDs & Timestamps]
        SANITIZE[Sanitize Output]
    end
    
    subgraph Storage
        DYNAMO[(DynamoDB)]
    end
    
    subgraph Outputs
        RESPONSE[API Response]
        CONSOLE[Console Output]
        CACHE[In-Memory Cache]
    end
    
    CLI --> VALIDATE
    API --> VALIDATE
    FILES --> VALIDATE
    VALIDATE --> GENERATE
    GENERATE --> DYNAMO
    DYNAMO --> SANITIZE
    SANITIZE --> RESPONSE
    SANITIZE --> CONSOLE
    SANITIZE --> CACHE
```

---

## 18. Logging and Monitoring

### Current State
> ⚠️ **Gap**: The module does not implement structured logging. All output is via `print()` statements.

### Console Output
The CLI tool uses visual indicators:
- `✅` Success
- `❌` Error
- `ℹ️` Information

### Recommended Logging (Future)
```python
import logging
logger = logging.getLogger(__name__)
logger.info("Created project %s", project_id)
logger.error("DynamoDB error: %s", error)
```

### Monitoring
No built-in monitoring. Relies on:
- AWS CloudWatch for DynamoDB metrics
- Application-level monitoring in `main.py`

---

## 19. Error Handling Strategy

### Exception Hierarchy

```mermaid
classDiagram
    Exception <|-- ProjectServiceError
    Exception <|-- ProjectNotFoundError
    
    class ProjectServiceError {
        +General service errors
        +AWS/DynamoDB errors
        +Configuration errors
    }
    
    class ProjectNotFoundError {
        +Project does not exist
        +File does not exist
    }
```

### Error Types

| Error Type | When Raised | Handling |
|------------|-------------|----------|
| `ProjectNotFoundError` | Project/file ID doesn't exist | Return 404 to client |
| `ProjectServiceError` | AWS credentials invalid | Display error, retry |
| `ProjectServiceError` | Table doesn't exist | Display error, exit |
| `ProjectServiceError` | Access denied (403) | Check IAM permissions |
| `ProjectServiceError` | Throughput exceeded | Retry with backoff |

### AWS Error Mapping

| AWS Error Code | Mapped Exception |
|----------------|------------------|
| `AccessDeniedException` | `ProjectServiceError` (check IAM) |
| `ResourceNotFoundException` | `ProjectServiceError` (table missing) |
| `ValidationException` | `ProjectServiceError` (bad request) |
| `ProvisionedThroughputExceededException` | `ProjectServiceError` (retry) |
| `ConditionalCheckFailedException` | `ProjectServiceError` |

### Retry Mechanisms
> ⚠️ **Gap**: No automatic retry logic implemented. boto3's built-in retry handles some transient failures.

### Fallback Behavior
- `get_project()` returns `None` if not found (no exception)
- `get_all_projects()` returns empty list on filter mismatch

---

## 20. Security Considerations

### Authentication
- **AWS IAM**: All access via AWS credentials
- **No application-level auth**: Module trusts AWS authentication

### Authorization

#### Required IAM Permissions
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "dynamodb:GetItem",
                "dynamodb:PutItem",
                "dynamodb:UpdateItem",
                "dynamodb:DeleteItem",
                "dynamodb:Scan",
                "dynamodb:DescribeTable"
            ],
            "Resource": [
                "arn:aws:dynamodb:us-east-1:*:table/AgenticColleague_Projects_Test",
                "arn:aws:dynamodb:us-east-1:*:table/AgenticColleague_Projects_Test/index/*"
            ]
        }
    ]
}
```

### Secrets Management
| Secret | Storage Method | Recommendation |
|--------|----------------|----------------|
| AWS Access Key | Environment variable / `~/.aws/credentials` | Use IAM roles in production |
| AWS Secret Key | Environment variable / `~/.aws/credentials` | Use IAM roles in production |

### Data Protection
- **At Rest**: DynamoDB encryption enabled (AWS managed)
- **In Transit**: TLS 1.2+ for all AWS API calls
- **File Content**: Stored as plaintext in DynamoDB (no client-side encryption)

> ⚠️ **Security Note**: Sensitive file content should be encrypted before storage or stored in S3 with encryption.

### Security Best Practices Used
- ✅ Lazy credential validation
- ✅ Descriptive error messages without exposing secrets
- ✅ No hardcoded credentials in source
- ❌ No input sanitization for file content
- ❌ No rate limiting

---

## 21. Testing

### Test Approach
The module includes a built-in test suite accessible via CLI.

### Running Tests
```powershell
# Run full CRUD test suite
python -m project_seeding.test_projects_table --test

# Clean up test data after testing
python -m project_seeding.test_projects_table --cleanup
```

### Test Coverage

| Test | Description | Automated |
|------|-------------|-----------|
| Create with files | Create project with attached files | ✅ |
| Create without files | Create minimal project | ✅ |
| Get by ID | Retrieve created project | ✅ |
| List all | Retrieve all test projects | ✅ |
| Update metadata | Change name/description | ✅ |
| Add file | Attach file to existing project | ✅ |
| Delete project | Remove project | ✅ |

### Test Data Prefix
All test data uses `TEST_` prefix for easy identification and cleanup.

### Unit Tests
> ⚠️ **Gap**: No formal unit test framework (pytest) is configured. Tests are functional integration tests against live DynamoDB.

### Integration Tests
The `--test` command performs integration testing against the actual DynamoDB table.

### Coverage Information
No code coverage tooling is configured.

---

## 22. Deployment

### Deployment Process
This is a library module deployed as part of the Agentic Colleague application.

### Prerequisites
1. DynamoDB table must exist before deployment
2. IAM roles/policies must be configured
3. AWS region must be accessible

### Table Creation (One-Time)
```powershell
# Create table via AWS CLI
aws dynamodb create-table `
    --table-name AgenticColleague_Projects_Test `
    --attribute-definitions `
        AttributeName=PK,AttributeType=S `
        AttributeName=SK,AttributeType=S `
    --key-schema `
        AttributeName=PK,KeyType=HASH `
        AttributeName=SK,KeyType=RANGE `
    --billing-mode PAY_PER_REQUEST `
    --region us-east-1
```

### Infrastructure Requirements
| Resource | Specification |
|----------|---------------|
| DynamoDB Table | On-demand capacity mode |
| Region | `us-east-1` |
| Encryption | AWS managed keys |

### Rollback Process
1. Code is version-controlled
2. DynamoDB data persists across deployments
3. Roll back application code; data remains intact

---

## 23. Troubleshooting Guide

| Problem | Possible Cause | Resolution |
|---------|----------------|------------|
| `ProjectServiceError: AWS credentials not found` | Missing AWS credentials | Configure via env vars, `~/.aws/credentials`, or IAM role |
| `ProjectServiceError: AWS access denied (403)` | Insufficient IAM permissions | Add required DynamoDB permissions to IAM role/user |
| `ProjectServiceError: Table does not exist` | Table not created or wrong region | Create table in `us-east-1` with correct name |
| `ProjectNotFoundError` | Project ID typo or deleted | Verify project ID exists with `--list` |
| Empty project list | No projects seeded | Create projects first |
| Connection timeout | Network issues | Check VPC/firewall rules, NAT gateway |
| `Decimal` in response | Raw DynamoDB response | Should be auto-sanitized; check `sanitize_project()` |
| Test data remaining | Forgot cleanup | Run `--cleanup` command |

### Diagnostic Commands

```powershell
# Check table exists and connection works
python -m project_seeding.test_projects_table --verify

# List all projects to verify data
python -m project_seeding.test_projects_table --list

# Test AWS credentials
aws sts get-caller-identity

# Test DynamoDB access
aws dynamodb describe-table --table-name AgenticColleague_Projects_Test --region us-east-1
```

---

## 24. Performance Considerations

### Current Implementation

| Operation | Complexity | Notes |
|-----------|-----------|-------|
| `create_project` | O(1) | Single PutItem |
| `get_project` | O(1) | Single GetItem |
| `get_all_projects` | O(n) | Full table scan |
| `update_project` | O(1) + O(1) | GetItem + UpdateItem |
| `delete_project` | O(1) + O(1) | GetItem + DeleteItem |
| `search_projects_by_name` | O(n) | Full scan + in-memory filter |

### Bottlenecks

| Issue | Impact | Mitigation |
|-------|--------|------------|
| Table scans | Expensive at scale | Use GSI for queries |
| In-memory search | Memory usage scales with projects | Implement GSI-based search |
| No pagination tokens | Client must handle large lists | Add pagination support |
| File content in DynamoDB | 400KB item limit | Move large files to S3 |

### Scalability Concerns
- **< 100 projects**: Current implementation is fine
- **100-1000 projects**: Consider GSI for status filtering
- **> 1000 projects**: Implement proper pagination, move to OpenSearch for search

### Optimization Techniques Applied
- ✅ Lazy DynamoDB connection
- ✅ Single table design with PK/SK
- ❌ No read caching (except in batch ingestion)
- ❌ No write batching

---

## 25. Assumptions and Limitations

### Assumptions

| Assumption | Implication |
|------------|-------------|
| Single region deployment | Table exists in `us-east-1` only |
| Single table access | All operations against one table |
| Text-based files | Binary files must be base64 encoded |
| Unique project names | No validation enforces uniqueness |
| Status values | Expected to be "Active" or "Inactive" |
| Small file count | Files stored as DynamoDB list attribute |

### Limitations

| Limitation | Impact | Workaround |
|------------|--------|------------|
| 400KB item limit | Large files cannot be stored | Use S3 for file storage |
| No GSI query optimization | Search requires table scan | Accept for small datasets |
| Hardcoded configuration | No multi-environment support | Environment variables |
| No soft delete | Deleted projects are gone forever | Export before delete |
| No audit trail | Cannot track who made changes | Add audit logging |

---

## 26. Future Improvements

### High Priority
| Improvement | Benefit | Effort |
|-------------|---------|--------|
| Externalize configuration | Multi-environment support | Low |
| Add structured logging | Better debugging and monitoring | Low |
| Implement GSI queries | Performance at scale | Medium |
| Add pagination | Handle large project lists | Medium |

### Medium Priority
| Improvement | Benefit | Effort |
|-------------|---------|--------|
| Move files to S3 | Remove 400KB limit | High |
| Add pytest unit tests | CI/CD integration | Medium |
| Implement soft delete | Data recovery option | Low |
| Add project name uniqueness | Prevent duplicates | Low |

### Low Priority / Nice-to-Have
| Improvement | Benefit | Effort |
|-------------|---------|--------|
| Add project hierarchies | Sub-project support | High |
| Implement caching layer | Reduced DynamoDB costs | Medium |
| Add audit trail | Change tracking | Medium |
| Full-text search via OpenSearch | Better search capabilities | High |

---

## 27. Frequently Asked Questions

### General

**Q: What is a "seeded" project?**
A: A seeded project is a pre-defined project record in DynamoDB that the AI agent uses to match detected project names during content processing. Think of it as a "master list" of approved projects.

**Q: Why can't the AI just create new projects automatically?**
A: To prevent hallucination and duplicate projects. For example, "Project X", "the X project", and "X initiative" should all map to the same canonical project, which requires human curation.

### Technical

**Q: Why are file contents stored in DynamoDB instead of S3?**
A: Simplicity for the initial implementation. Files are typically small text documents (requirements, descriptions). For larger files, S3 integration is recommended.

**Q: What happens if the DynamoDB table doesn't exist?**
A: The `get_dynamodb_table()` function will raise a `ProjectServiceError` with a descriptive message. Use `--verify` to check table status.

**Q: How do I change the table name or region?**
A: Currently, these are hardcoded constants. Modify `TABLE_NAME` and `AWS_REGION` in `projects_service.py`, or refactor to use environment variables.

### Operations

**Q: How do I clean up test data?**
A: Run `python -m project_seeding.test_projects_table --cleanup`. This removes all projects with names starting with `TEST_`.

**Q: Can I use this with DynamoDB Local for development?**
A: Not directly. You would need to modify `get_dynamodb_table()` to accept an endpoint URL parameter.

---

## 28. Glossary

| Term | Definition |
|------|------------|
| **Agentic Colleague** | The parent AI-powered project management assistant application |
| **Seeded Project** | A pre-defined project record that provides canonical names for AI matching |
| **Project ID** | Unique identifier in format `PRJ_xxxxxxxxxx` |
| **File ID** | Unique identifier for attachments in format `FILE_xxxxxxxx` |
| **PK/SK** | Partition Key / Sort Key - DynamoDB's primary key components |
| **GSI** | Global Secondary Index - DynamoDB feature for alternative query patterns |
| **Sanitize** | Convert DynamoDB Decimal types to native Python types |
| **CRUD** | Create, Read, Update, Delete - basic data operations |
| **IAM** | AWS Identity and Access Management |
| **boto3** | Official AWS SDK for Python |

---

## 29. Ownership and Support

### Team Ownership
| Role | Responsibility |
|------|----------------|
| **Module Owner** | Maintain `project_seeding` module code |
| **Platform Team** | Manage DynamoDB table and IAM permissions |
| **DevOps** | Deployment and infrastructure |

### Support Process
1. Check this README and troubleshooting guide
2. Verify AWS credentials and permissions
3. Run `--verify` and `--test` commands
4. Check CloudWatch logs for DynamoDB errors
5. Escalate to module owner for code issues

### Escalation Path
1. **L1**: Self-service troubleshooting
2. **L2**: Platform team (infrastructure issues)
3. **L3**: Module owner (code bugs)

---

## 30. Quick Start Guide

### 5-Minute Onboarding

#### Step 1: Verify Environment (1 min)
```powershell
# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Verify AWS credentials
aws sts get-caller-identity
```

#### Step 2: Verify Table Access (1 min)
```powershell
python -m project_seeding.test_projects_table --verify
```

#### Step 3: Create Your First Project (1 min)
```powershell
python -m project_seeding.test_projects_table --create `
    --name "My Test Project" `
    --desc "Testing the project seeding module"
```

#### Step 4: List Projects (30 sec)
```powershell
python -m project_seeding.test_projects_table --list
```

#### Step 5: Use in Code (1.5 min)
```python
# In Python
from project_seeding import get_all_projects, create_project

# Get all active projects
projects = get_all_projects(status_filter="Active")
for p in projects:
    print(f"{p['project_id']}: {p['project_name']}")

# Create a new project programmatically
new_project = create_project(
    project_name="API Created Project",
    project_description="Created via Python code"
)
print(f"Created: {new_project['project_id']}")
```

#### Step 6: Cleanup Test Data
```powershell
python -m project_seeding.test_projects_table --cleanup
```

### You're Ready! 🎉
You can now:
- Create and manage projects via CLI or code
- Understand how the batch ingestion module uses seeded projects
- Troubleshoot common issues

---

## Document Metadata

| Field | Value |
|-------|-------|
| **Created** | August 20, 2026 |
| **Last Updated** | August 20, 2026 |
| **Module Version** | 1.0 |
| **Documentation Version** | 1.0 |
| **Author** | Generated by AI Documentation Assistant |
