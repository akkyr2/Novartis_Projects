#!/usr/bin/env python3
"""
AgenticColleague_Projects_Test - Comprehensive CRUD Script
===========================================================
Full CRUD operations for Projects DynamoDB table via command line.

COMMANDS:
---------
# Table Info
python -m project_seeding.test_projects_table --verify                     # Check table exists

# CREATE
python -m  project_seeding.test_projects_table --create --name "My Project" --desc "Description"
python -m project_seeding.test_projects_table --create --name "My Project" --desc "Description" --file requirements.txt

# READ
python -m project_seeding.test_projects_table --list                       # List all projects
python -m project_seeding.test_projects_table --get PRJ_abc123             # Get specific project

# UPDATE
python -m project_seeding.test_projects_table --update PRJ_abc123 --name "New Name"
python -m project_seeding.test_projects_table --update PRJ_abc123 --desc "New Description"
python -m project_seeding.test_projects_table --update PRJ_abc123 --name "New Name" --desc "New Desc"

# ADD FILE
python -m project_seeding.test_projects_table --add-file PRJ_abc123 --file document.txt
# DELETE
python -m project_seeding.test_projects_table --delete PRJ_abc123          # Delete a project

# TEST & CLEANUP
python -m project_seeding.test_projects_table --test                       # Run all CRUD tests
python -m project_seeding.test_projects_table --cleanup                    # Remove TEST_ data

Created: July 31, 2026
"""

import argparse
import json
import uuid
import sys
import os
from datetime import datetime, timezone
from typing import Dict, List, Optional

import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

# ============================================================================
# CONFIGURATION
# ============================================================================
TABLE_NAME = "AgenticColleague_Projects_Test"
AWS_REGION = "us-east-1"
GSI_PROJECT_NAME = "GSI1-ProjectName-Index"
TEST_PREFIX = "TEST_"

# Initialize DynamoDB
dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
table = dynamodb.Table(TABLE_NAME)

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def generate_project_id() -> str:
    return f"PRJ_{uuid.uuid4().hex[:10]}"

def generate_file_id() -> str:
    return f"FILE_{uuid.uuid4().hex[:8]}"

def print_separator(char="─", length=70):
    print(char * length)

def print_header(title: str):
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}")

def print_success(msg: str):
    print(f"✅ {msg}")

def print_error(msg: str):
    print(f"❌ {msg}")

def print_info(msg: str):
    print(f"ℹ️  {msg}")

def read_file_content(file_path: str) -> tuple:
    """Read file content and return (file_name, file_type, content)."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_name = os.path.basename(file_path)
    file_type = os.path.splitext(file_name)[1].lstrip('.') or 'txt'
    
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    return file_name, file_type, content

# ============================================================================
# CRUD OPERATIONS
# ============================================================================

def create_project(project_name: str, project_description: str, files: List[Dict] = None) -> Dict:
    """Create a new project."""
    project_id = generate_project_id()
    now = utc_now_iso()
    
    processed_files = []
    if files:
        for f in files:
            processed_files.append({
                "file_id": generate_file_id(),
                "file_name": f["file_name"],
                "file_type": f["file_type"],
                "file_content": f["file_content"],
                "uploaded_at": now,
            })
    
    item = {
        "PK": f"PROJECT#{project_id}",
        "SK": "METADATA",
        "project_id": project_id,
        "project_name": project_name,
        "project_description": project_description,
        "status": "active",
        "created_at": now,
        "updated_at": now,
        "files": processed_files,
        "file_count": len(processed_files),
    }
    
    table.put_item(Item=item)
    return item


def get_project(project_id: str) -> Optional[Dict]:
    """Get a project by ID."""
    response = table.get_item(
        Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"}
    )
    return response.get("Item")


def get_all_projects() -> List[Dict]:
    """Get all projects with pagination."""
    items = []
    response = table.scan(FilterExpression=Attr("SK").eq("METADATA"))
    items.extend(response.get("Items", []))
    
    while "LastEvaluatedKey" in response:
        response = table.scan(
            FilterExpression=Attr("SK").eq("METADATA"),
            ExclusiveStartKey=response["LastEvaluatedKey"]
        )
        items.extend(response.get("Items", []))
    
    return items


def update_project(project_id: str, project_name: str = None, project_description: str = None) -> Optional[Dict]:
    """Update project name and/or description."""
    update_parts = ["updated_at = :now"]
    values = {":now": utc_now_iso()}
    
    if project_name:
        update_parts.append("project_name = :name")
        values[":name"] = project_name
    
    if project_description:
        update_parts.append("project_description = :desc")
        values[":desc"] = project_description
    
    response = table.update_item(
        Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"},
        UpdateExpression="SET " + ", ".join(update_parts),
        ExpressionAttributeValues=values,
        ReturnValues="ALL_NEW"
    )
    return response.get("Attributes")


def add_file_to_project(project_id: str, file_name: str, file_type: str, file_content: str) -> Dict:
    """Add a file to an existing project."""
    now = utc_now_iso()
    
    file_record = {
        "file_id": generate_file_id(),
        "file_name": file_name,
        "file_type": file_type,
        "file_content": file_content,
        "uploaded_at": now,
    }
    
    table.update_item(
        Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"},
        UpdateExpression="SET files = list_append(if_not_exists(files, :empty), :file), file_count = if_not_exists(file_count, :zero) + :one, updated_at = :now",
        ExpressionAttributeValues={
            ":file": [file_record],
            ":empty": [],
            ":zero": 0,
            ":one": 1,
            ":now": now,
        }
    )
    return file_record


def delete_project(project_id: str) -> bool:
    """Delete a project."""
    try:
        table.delete_item(Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"})
        return True
    except ClientError as e:
        print_error(f"Delete failed: {e}")
        return False


# ============================================================================
# COMMAND HANDLERS
# ============================================================================

def cmd_verify():
    """Verify table exists and show info."""
    print_header("TABLE VERIFICATION")
    
    try:
        status = table.table_status
        print_success(f"Table '{TABLE_NAME}' exists")
        print(f"  Status: {status}")
        
        desc = table.meta.client.describe_table(TableName=TABLE_NAME)
        info = desc.get("Table", {})
        
        print(f"  Items: {info.get('ItemCount', 0)}")
        print(f"  Size: {info.get('TableSizeBytes', 0)} bytes")
        
        gsis = info.get("GlobalSecondaryIndexes", [])
        print(f"  GSIs: {len(gsis)}")
        for gsi in gsis:
            print(f"    - {gsi['IndexName']}")
        
    except ClientError as e:
        if "ResourceNotFoundException" in str(e):
            print_error(f"Table '{TABLE_NAME}' does not exist!")
        else:
            print_error(f"Error: {e}")
        sys.exit(1)


def cmd_create(name: str, desc: str, file_path: str = None):
    """Create a new project."""
    print_header("CREATE PROJECT")
    
    files = []
    if file_path:
        try:
            file_name, file_type, content = read_file_content(file_path)
            files.append({
                "file_name": file_name,
                "file_type": file_type,
                "file_content": content
            })
            print_info(f"Read file: {file_name} ({len(content)} chars)")
        except Exception as e:
            print_error(f"Failed to read file: {e}")
            sys.exit(1)
    
    try:
        project = create_project(name, desc, files if files else None)
        print_success(f"Project created!")
        print(f"  ID: {project['project_id']}")
        print(f"  Name: {project['project_name']}")
        print(f"  Description: {project['project_description']}")
        print(f"  Files: {project['file_count']}")
        print(f"  Created: {project['created_at']}")
    except Exception as e:
        print_error(f"Create failed: {e}")
        sys.exit(1)


def cmd_get(project_id: str):
    """Get and display a project."""
    print_header(f"PROJECT: {project_id}")
    
    project = get_project(project_id)
    
    if not project:
        print_error(f"Project not found: {project_id}")
        sys.exit(1)
    
    print(f"  ID: {project['project_id']}")
    print(f"  Name: {project['project_name']}")
    print(f"  Description: {project['project_description']}")
    print(f"  Status: {project.get('status', 'N/A')}")
    print(f"  Created: {project['created_at']}")
    print(f"  Updated: {project['updated_at']}")
    print(f"  Files: {project.get('file_count', 0)}")
    
    files = project.get('files', [])
    if files:
        print("\n  📁 Files:")
        for i, f in enumerate(files):
            print(f"    [{i}] {f['file_name']} ({f['file_type']})")
            preview = f['file_content'][:100].replace('\n', ' ')
            if len(f['file_content']) > 100:
                preview += "..."
            print(f"        Content: {preview}")


def cmd_list():
    """List all projects."""
    print_header("ALL PROJECTS")
    
    projects = get_all_projects()
    
    if not projects:
        print_info("No projects found")
        return
    
    print(f"\nTotal: {len(projects)} projects\n")
    print_separator()
    
    for p in projects:
        print(f"📂 {p['project_id']}")
        print(f"   Name: {p['project_name']}")
        desc = p['project_description'][:60] + "..." if len(p['project_description']) > 60 else p['project_description']
        print(f"   Desc: {desc}")
        print(f"   Files: {p.get('file_count', 0)} | Created: {p['created_at']}")
        print_separator()


def cmd_update(project_id: str, name: str = None, desc: str = None):
    """Update a project."""
    print_header(f"UPDATE PROJECT: {project_id}")
    
    if not name and not desc:
        print_error("Provide --name and/or --desc to update")
        sys.exit(1)
    
    # Check project exists
    if not get_project(project_id):
        print_error(f"Project not found: {project_id}")
        sys.exit(1)
    
    try:
        updated = update_project(project_id, name, desc)
        print_success("Project updated!")
        print(f"  Name: {updated['project_name']}")
        print(f"  Description: {updated['project_description']}")
        print(f"  Updated: {updated['updated_at']}")
    except Exception as e:
        print_error(f"Update failed: {e}")
        sys.exit(1)


def cmd_add_file(project_id: str, file_path: str):
    """Add a file to a project."""
    print_header(f"ADD FILE TO: {project_id}")
    
    # Check project exists
    if not get_project(project_id):
        print_error(f"Project not found: {project_id}")
        sys.exit(1)
    
    try:
        file_name, file_type, content = read_file_content(file_path)
        print_info(f"Read file: {file_name} ({len(content)} chars)")
        
        file_record = add_file_to_project(project_id, file_name, file_type, content)
        print_success("File added!")
        print(f"  File ID: {file_record['file_id']}")
        print(f"  Name: {file_record['file_name']}")
        print(f"  Type: {file_record['file_type']}")
    except FileNotFoundError as e:
        print_error(str(e))
        sys.exit(1)
    except Exception as e:
        print_error(f"Add file failed: {e}")
        sys.exit(1)


def cmd_delete(project_id: str):
    """Delete a project."""
    print_header(f"DELETE PROJECT: {project_id}")
    
    # Check project exists
    project = get_project(project_id)
    if not project:
        print_error(f"Project not found: {project_id}")
        sys.exit(1)
    
    print(f"  Name: {project['project_name']}")
    print(f"  Files: {project.get('file_count', 0)}")
    
    if delete_project(project_id):
        print_success("Project deleted!")
        
        # Verify deletion
        if get_project(project_id) is None:
            print_success("Verified: Project no longer exists")
    else:
        print_error("Delete failed")
        sys.exit(1)


def cmd_test():
    """Run comprehensive CRUD tests."""
    print_header("RUNNING CRUD TESTS")
    created_ids = []
    
    # --- CREATE ---
    print("\n[1/6] CREATE: Project with files")
    try:
        p = create_project(
            f"{TEST_PREFIX}Test Project Alpha",
            "Test project with multiple files for CRUD testing.",
            files=[
                {"file_name": "readme.txt", "file_type": "txt", "file_content": "This is a readme file.\nLine 2 of readme."},
                {"file_name": "data.json", "file_type": "json", "file_content": '{"key": "value", "count": 42}'}
            ]
        )
        created_ids.append(p["project_id"])
        print_success(f"Created: {p['project_id']} with {p['file_count']} files")
    except Exception as e:
        print_error(f"Create failed: {e}")
    
    print("\n[2/6] CREATE: Project without files")
    try:
        p = create_project(f"{TEST_PREFIX}Test Project Beta", "Simple project without files.")
        created_ids.append(p["project_id"])
        print_success(f"Created: {p['project_id']}")
    except Exception as e:
        print_error(f"Create failed: {e}")
    
    # --- READ ---
    print("\n[3/6] READ: Get project by ID")
    if created_ids:
        project = get_project(created_ids[0])
        if project:
            print_success(f"Retrieved: {project['project_id']}")
            print(f"    Name: {project['project_name']}")
            print(f"    Files: {project['file_count']}")
            for f in project.get('files', []):
                print(f"      - {f['file_name']}: {f['file_content'][:30]}...")
        else:
            print_error("Project not found")
    
    print("\n[4/6] READ: List all projects")
    projects = get_all_projects()
    test_projects = [p for p in projects if p['project_name'].startswith(TEST_PREFIX)]
    print_success(f"Found {len(test_projects)} test projects (total: {len(projects)})")
    
    # --- UPDATE ---
    print("\n[5/6] UPDATE: Modify project and add file")
    if created_ids:
        pid = created_ids[0]
        
        # Update name/desc
        updated = update_project(pid, f"{TEST_PREFIX}Test Project Alpha (UPDATED)", "UPDATED description.")
        if updated:
            print_success(f"Updated name: {updated['project_name']}")
        
        # Add file
        file_record = add_file_to_project(pid, "notes.md", "md", "# Meeting Notes\n- Item 1\n- Item 2")
        print_success(f"Added file: {file_record['file_name']}")
        
        # Verify
        project = get_project(pid)
        print_success(f"Verified: Now has {project['file_count']} files")
    
    # --- DELETE ---
    print("\n[6/6] DELETE: Remove project")
    if len(created_ids) > 1:
        del_id = created_ids.pop()
        if delete_project(del_id):
            print_success(f"Deleted: {del_id}")
            if get_project(del_id) is None:
                print_success("Verified: Project no longer exists")
    
    # --- SUMMARY ---
    print_header("TEST SUMMARY")
    print_success("All CRUD operations completed!")
    print(f"  Created projects still in table: {len(created_ids)}")
    print(f"\n  Run --cleanup to remove test data")
    print(f"  Run --list to see all projects")


def cmd_cleanup():
    """Remove all test data."""
    print_header("CLEANUP TEST DATA")
    
    response = table.scan(FilterExpression=Attr("project_name").begins_with(TEST_PREFIX))
    items = response.get("Items", [])
    
    while "LastEvaluatedKey" in response:
        response = table.scan(
            FilterExpression=Attr("project_name").begins_with(TEST_PREFIX),
            ExclusiveStartKey=response["LastEvaluatedKey"]
        )
        items.extend(response.get("Items", []))
    
    if not items:
        print_info("No test data found")
        return
    
    print(f"Found {len(items)} test items")
    
    for item in items:
        table.delete_item(Key={"PK": item["PK"], "SK": item["SK"]})
        print(f"  Deleted: {item['project_id']} - {item['project_name']}")
    
    print_success(f"Cleaned up {len(items)} items")


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Projects Table CRUD Operations",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
EXAMPLES:
  python -m project_seeding.test_projects_table --verify
  python -m project_seeding.test_projects_table --create --name "My Project" --desc "Description"
  python -m project_seeding.test_projects_table --create --name "Project" --desc "Desc" --file doc.txt
  python -m project_seeding.test_projects_table --list
  python -m project_seeding.test_projects_table --get PRJ_abc123
  python -m project_seeding.test_projects_table --update PRJ_abc123 --name "New Name"
  python -m project_seeding.test_projects_table --add-file PRJ_abc123 --file document.txt
  python -m project_seeding.test_projects_table --delete PRJ_abc123
  python -m project_seeding.test_projects_table --test
  python -m project_seeding.test_projects_table --cleanup
        """
    )
    
    # Commands
    parser.add_argument("--verify", action="store_true", help="Verify table exists")
    parser.add_argument("--create", action="store_true", help="Create a new project")
    parser.add_argument("--get", metavar="ID", help="Get project by ID")
    parser.add_argument("--list", action="store_true", help="List all projects")
    parser.add_argument("--update", metavar="ID", help="Update project by ID")
    parser.add_argument("--add-file", metavar="ID", help="Add file to project")
    parser.add_argument("--delete", metavar="ID", help="Delete project by ID")
    parser.add_argument("--test", action="store_true", help="Run CRUD tests")
    parser.add_argument("--cleanup", action="store_true", help="Remove test data")
    
    # Options
    parser.add_argument("--name", help="Project name (for create/update)")
    parser.add_argument("--desc", help="Project description (for create/update)")
    parser.add_argument("--file", help="File path to upload")
    
    args = parser.parse_args()
    
    # Execute command
    if args.verify:
        cmd_verify()
    elif args.create:
        if not args.name or not args.desc:
            print_error("--create requires --name and --desc")
            sys.exit(1)
        cmd_create(args.name, args.desc, args.file)
    elif args.get:
        cmd_get(args.get)
    elif args.list:
        cmd_list()
    elif args.update:
        cmd_update(args.update, args.name, args.desc)
    elif args.add_file:
        if not args.file:
            print_error("--add-file requires --file")
            sys.exit(1)
        cmd_add_file(args.add_file, args.file)
    elif args.delete:
        cmd_delete(args.delete)
    elif args.test:
        cmd_test()
    elif args.cleanup:
        cmd_cleanup()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
