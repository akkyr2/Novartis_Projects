#!/usr/bin/env python3
"""
Projects Service Module
=======================
Service layer for Projects DynamoDB CRUD operations.
This module provides clean, reusable functions for managing projects
that can be called from FastAPI endpoints or other services.

Table: AgenticColleague_Projects_Test
Primary Key: PK (PROJECT#{project_id}), SK (METADATA)

Created: July 31, 2026
"""

import uuid
import base64
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any

import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError
from decimal import Decimal

# ============================================================================
# CONFIGURATION
# ============================================================================
TABLE_NAME = "AgenticColleague_Projects_Test"
AWS_REGION = "us-east-1"
GSI_PROJECT_NAME = "GSI1-ProjectName-Index"

# Initialize DynamoDB resource (lazy initialization for better testing)
_dynamodb = None
_table = None


def get_dynamodb_table():
    """
    Get DynamoDB table resource with lazy initialization.
    
    Raises:
        ProjectServiceError: If AWS credentials are missing or invalid
    """
    global _dynamodb, _table
    if _table is None:
        try:
            _dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
            _table = _dynamodb.Table(TABLE_NAME)
            # Verify we can access the table (will raise if credentials are bad)
            _ = _table.table_status
        except NoCredentialsError:
            raise ProjectServiceError(
                "AWS credentials not found. Please configure AWS credentials "
                "(via environment variables, ~/.aws/credentials, or IAM role)."
            )
        except PartialCredentialsError:
            raise ProjectServiceError(
                "Incomplete AWS credentials. Please ensure both AWS_ACCESS_KEY_ID "
                "and AWS_SECRET_ACCESS_KEY are configured."
            )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "AccessDeniedException" or "403" in str(e):
                raise ProjectServiceError(
                    f"AWS access denied (403). Please check IAM permissions for table '{TABLE_NAME}'. "
                    f"Required permissions: dynamodb:GetItem, PutItem, UpdateItem, DeleteItem, Scan, DescribeTable."
                )
            elif error_code == "ResourceNotFoundException":
                raise ProjectServiceError(f"DynamoDB table '{TABLE_NAME}' does not exist in region '{AWS_REGION}'.")
            raise ProjectServiceError(f"Failed to connect to DynamoDB: {e}")
    return _table


def reset_dynamodb_connection():
    """Reset the DynamoDB connection (useful for testing or reconnection)."""
    global _dynamodb, _table
    _dynamodb = None
    _table = None


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def utc_now_iso() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def generate_project_id() -> str:
    """Generate a unique project ID."""
    return f"PRJ_{uuid.uuid4().hex[:10]}"


def generate_file_id() -> str:
    """Generate a unique file ID."""
    return f"FILE_{uuid.uuid4().hex[:8]}"


def decimal_to_python(obj: Any) -> Any:
    """Convert DynamoDB Decimal types to Python native types."""
    if isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_python(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_python(i) for i in obj]
    return obj


def sanitize_project(project: Dict) -> Dict:
    """
    Sanitize project data for API response.
    Converts Decimal to native Python types and removes internal keys.
    """
    if not project:
        return None
    
    # Convert Decimal types
    clean = decimal_to_python(project)
    
    # Optionally remove internal DynamoDB keys for cleaner API response
    # Keep PK/SK for reference but you can remove if desired
    return clean


# ============================================================================
# CRUD OPERATIONS
# ============================================================================

class ProjectNotFoundError(Exception):
    """Raised when a project is not found."""
    pass


class ProjectServiceError(Exception):
    """General service error."""
    pass


def _handle_client_error(e: ClientError, operation: str) -> None:
    """
    Handle AWS ClientError and raise appropriate ProjectServiceError.
    
    Args:
        e: The ClientError exception
        operation: Description of the operation that failed
    """
    error_code = e.response.get("Error", {}).get("Code", "")
    error_message = e.response.get("Error", {}).get("Message", str(e))
    
    if error_code == "AccessDeniedException" or "403" in str(e) or "Forbidden" in str(e):
        raise ProjectServiceError(
            f"AWS access denied during {operation}. "
            f"Please verify IAM permissions for DynamoDB table '{TABLE_NAME}'. "
            f"Error: {error_message}"
        )
    elif error_code == "ResourceNotFoundException":
        raise ProjectServiceError(f"DynamoDB table '{TABLE_NAME}' not found during {operation}.")
    elif error_code == "ValidationException":
        raise ProjectServiceError(f"Invalid request during {operation}: {error_message}")
    elif error_code == "ProvisionedThroughputExceededException":
        raise ProjectServiceError(f"DynamoDB throughput exceeded during {operation}. Please retry.")
    elif error_code == "ConditionalCheckFailedException":
        raise ProjectServiceError(f"Conditional check failed during {operation}: {error_message}")
    else:
        raise ProjectServiceError(f"AWS error during {operation}: [{error_code}] {error_message}")


def create_project(
    project_name: str,
    project_description: str,
    files: Optional[List[Dict]] = None
) -> Dict:
    """
    Create a new project in DynamoDB.
    
    Args:
        project_name: Name of the project
        project_description: Description of the project
        files: Optional list of files with keys: file_name, file_type, file_content
        
    Returns:
        Created project item
        
    Raises:
        ProjectServiceError: If creation fails
    """
    table = get_dynamodb_table()
    project_id = generate_project_id()
    now = utc_now_iso()
    
    # Process files if provided
    processed_files = []
    if files:
        for f in files:
            processed_files.append({
                "file_id": generate_file_id(),
                "file_name": f.get("file_name", "unnamed"),
                "file_type": f.get("file_type", "txt"),
                "file_content": f.get("file_content", ""),
                "uploaded_at": now,
            })
    
    item = {
        "PK": f"PROJECT#{project_id}",
        "SK": "METADATA",
        "project_id": project_id,
        "project_name": project_name,
        "project_description": project_description,
        "status": "Active",
        "created_at": now,
        "updated_at": now,
        "files": processed_files,
        "file_count": len(processed_files),
    }
    
    try:
        table.put_item(Item=item)
        return sanitize_project(item)
    except ClientError as e:
        _handle_client_error(e, "create_project")


def get_project(project_id: str) -> Optional[Dict]:
    """
    Get a project by its ID.
    
    Args:
        project_id: The project ID (e.g., PRJ_abc123)
        
    Returns:
        Project item if found, None otherwise
    """
    table = get_dynamodb_table()
    
    try:
        response = table.get_item(
            Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"}
        )
        item = response.get("Item")
        return sanitize_project(item) if item else None
    except ClientError as e:
        _handle_client_error(e, "get_project")


def get_all_projects(
    limit: Optional[int] = None,
    status_filter: Optional[str] = None
) -> List[Dict]:
    """
    Get all projects with optional filtering.
    
    Args:
        limit: Maximum number of projects to return
        status_filter: Filter by status (e.g., 'Active', 'Inactive')
        
    Returns:
        List of project items
    """
    table = get_dynamodb_table()
    items = []
    
    # Build filter expression
    filter_expr = Attr("SK").eq("METADATA")
    if status_filter:
        filter_expr = filter_expr & Attr("status").eq(status_filter)
    
    try:
        response = table.scan(FilterExpression=filter_expr)
        items.extend(response.get("Items", []))
        
        # Paginate through all results
        while "LastEvaluatedKey" in response:
            if limit and len(items) >= limit:
                break
            response = table.scan(
                FilterExpression=filter_expr,
                ExclusiveStartKey=response["LastEvaluatedKey"]
            )
            items.extend(response.get("Items", []))
        
        # Apply limit if specified
        if limit:
            items = items[:limit]
        
        # Sort by created_at descending (newest first)
        items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        
        return [sanitize_project(item) for item in items]
    except ClientError as e:
        _handle_client_error(e, "get_all_projects")


def update_project(
    project_id: str,
    project_name: Optional[str] = None,
    project_description: Optional[str] = None,
    status: Optional[str] = None
) -> Dict:
    """
    Update a project's metadata.
    
    Args:
        project_id: The project ID to update
        project_name: New name (optional)
        project_description: New description (optional)
        status: New status (optional)
        
    Returns:
        Updated project item
        
    Raises:
        ProjectNotFoundError: If project doesn't exist
        ProjectServiceError: If update fails
    """
    table = get_dynamodb_table()
    
    # Verify project exists
    existing = get_project(project_id)
    if not existing:
        raise ProjectNotFoundError(f"Project not found: {project_id}")
    
    # Build update expression
    update_parts = ["updated_at = :now"]
    values = {":now": utc_now_iso()}
    
    if project_name is not None:
        update_parts.append("project_name = :name")
        values[":name"] = project_name
    
    if project_description is not None:
        update_parts.append("project_description = :desc")
        values[":desc"] = project_description
    
    if status is not None:
        update_parts.append("#st = :status")
        values[":status"] = status
    
    try:
        # Handle reserved word 'status'
        expression_attr_names = {}
        if status is not None:
            expression_attr_names["#st"] = "status"
        
        update_kwargs = {
            "Key": {"PK": f"PROJECT#{project_id}", "SK": "METADATA"},
            "UpdateExpression": "SET " + ", ".join(update_parts),
            "ExpressionAttributeValues": values,
            "ReturnValues": "ALL_NEW"
        }
        
        if expression_attr_names:
            update_kwargs["ExpressionAttributeNames"] = expression_attr_names
        
        response = table.update_item(**update_kwargs)
        return sanitize_project(response.get("Attributes"))
    except ClientError as e:
        _handle_client_error(e, "update_project")


def delete_project(project_id: str) -> bool:
    """
    Delete a project by its ID.
    
    Args:
        project_id: The project ID to delete
        
    Returns:
        True if deleted successfully
        
    Raises:
        ProjectNotFoundError: If project doesn't exist
        ProjectServiceError: If deletion fails
    """
    table = get_dynamodb_table()
    
    # Verify project exists
    existing = get_project(project_id)
    if not existing:
        raise ProjectNotFoundError(f"Project not found: {project_id}")
    
    try:
        table.delete_item(
            Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"}
        )
        return True
    except ClientError as e:
        _handle_client_error(e, "delete_project")


# ============================================================================
# FILE OPERATIONS
# ============================================================================

def add_file_to_project(
    project_id: str,
    file_name: str,
    file_type: str,
    file_content: str
) -> Dict:
    """
    Add a file to an existing project.
    
    Args:
        project_id: The project ID
        file_name: Name of the file
        file_type: File extension/type (e.g., 'txt', 'pdf', 'json')
        file_content: Content of the file (text or base64 encoded)
        
    Returns:
        The created file record
        
    Raises:
        ProjectNotFoundError: If project doesn't exist
        ProjectServiceError: If operation fails
    """
    table = get_dynamodb_table()
    
    # Verify project exists
    existing = get_project(project_id)
    if not existing:
        raise ProjectNotFoundError(f"Project not found: {project_id}")
    
    now = utc_now_iso()
    file_record = {
        "file_id": generate_file_id(),
        "file_name": file_name,
        "file_type": file_type,
        "file_content": file_content,
        "uploaded_at": now,
    }
    
    try:
        table.update_item(
            Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"},
            UpdateExpression=(
                "SET files = list_append(if_not_exists(files, :empty), :file), "
                "file_count = if_not_exists(file_count, :zero) + :one, "
                "updated_at = :now"
            ),
            ExpressionAttributeValues={
                ":file": [file_record],
                ":empty": [],
                ":zero": 0,
                ":one": 1,
                ":now": now,
            }
        )
        return file_record
    except ClientError as e:
        _handle_client_error(e, "add_file_to_project")


def remove_file_from_project(project_id: str, file_id: str) -> bool:
    """
    Remove a file from a project.
    
    Args:
        project_id: The project ID
        file_id: The file ID to remove
        
    Returns:
        True if removed successfully
        
    Raises:
        ProjectNotFoundError: If project or file doesn't exist
        ProjectServiceError: If operation fails
    """
    table = get_dynamodb_table()
    
    # Get project and find file index
    project = get_project(project_id)
    if not project:
        raise ProjectNotFoundError(f"Project not found: {project_id}")
    
    files = project.get("files", [])
    file_index = None
    for i, f in enumerate(files):
        if f.get("file_id") == file_id:
            file_index = i
            break
    
    if file_index is None:
        raise ProjectNotFoundError(f"File not found: {file_id}")
    
    try:
        # Remove file from list
        table.update_item(
            Key={"PK": f"PROJECT#{project_id}", "SK": "METADATA"},
            UpdateExpression=f"REMOVE files[{file_index}] SET file_count = file_count - :one, updated_at = :now",
            ExpressionAttributeValues={
                ":one": 1,
                ":now": utc_now_iso(),
            }
        )
        return True
    except ClientError as e:
        _handle_client_error(e, "remove_file_from_project")


def get_file_from_project(project_id: str, file_id: str) -> Optional[Dict]:
    """
    Get a specific file from a project.
    
    Args:
        project_id: The project ID
        file_id: The file ID
        
    Returns:
        File record if found, None otherwise
    """
    project = get_project(project_id)
    if not project:
        raise ProjectNotFoundError(f"Project not found: {project_id}")
    
    files = project.get("files", [])
    for f in files:
        if f.get("file_id") == file_id:
            return f
    
    return None


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def verify_table_exists() -> Dict:
    """
    Verify the DynamoDB table exists and return info.
    
    Returns:
        Dict with table status and info
    """
    table = get_dynamodb_table()
    
    try:
        status = table.table_status
        desc = table.meta.client.describe_table(TableName=TABLE_NAME)
        info = desc.get("Table", {})
        
        return {
            "table_name": TABLE_NAME,
            "status": status,
            "item_count": info.get("ItemCount", 0),
            "size_bytes": info.get("TableSizeBytes", 0),
            "gsis": [gsi["IndexName"] for gsi in info.get("GlobalSecondaryIndexes", [])]
        }
    except ClientError as e:
        if "ResourceNotFoundException" in str(e):
            raise ProjectServiceError(f"Table '{TABLE_NAME}' does not exist")
        raise ProjectServiceError(f"Error verifying table: {e}")


def search_projects_by_name(name_query: str) -> List[Dict]:
    """
    Search projects by name (case-insensitive contains).
    
    Args:
        name_query: Search string
        
    Returns:
        List of matching projects
    """
    # Get all projects and filter in memory
    # For production, consider using GSI or OpenSearch
    all_projects = get_all_projects()
    query_lower = name_query.lower()
    
    return [
        p for p in all_projects 
        if query_lower in p.get("project_name", "").lower()
    ]
