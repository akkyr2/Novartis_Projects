"""
Project Seeding Module
======================
This module provides services for managing projects in DynamoDB.

Services:
- projects_service: CRUD operations for projects and file attachments

Usage:
    from project_seeding import (
        create_project,
        get_project,
        get_all_projects,
        update_project,
        delete_project,
        add_file_to_project,
        remove_file_from_project,
    )
"""

from .projects_service import (
    # CRUD Operations
    create_project,
    get_project,
    get_all_projects,
    update_project,
    delete_project,
    
    # File Operations
    add_file_to_project,
    remove_file_from_project,
    get_file_from_project,
    
    # Utility Functions
    verify_table_exists,
    search_projects_by_name,
    reset_dynamodb_connection,
    
    # Exceptions
    ProjectNotFoundError,
    ProjectServiceError,
    
    # Configuration
    TABLE_NAME,
    AWS_REGION,
)

__all__ = [
    # CRUD Operations
    "create_project",
    "get_project",
    "get_all_projects",
    "update_project",
    "delete_project",
    
    # File Operations
    "add_file_to_project",
    "remove_file_from_project",
    "get_file_from_project",
    
    # Utility Functions
    "verify_table_exists",
    "search_projects_by_name",
    "reset_dynamodb_connection",
    
    # Exceptions
    "ProjectNotFoundError",
    "ProjectServiceError",
    
    # Configuration
    "TABLE_NAME",
    "AWS_REGION",
]
