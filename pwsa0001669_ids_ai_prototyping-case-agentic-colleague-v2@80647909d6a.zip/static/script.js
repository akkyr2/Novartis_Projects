// ===================================================================
// IPST FUNCTION MAP — maps team member names to their IPST function/role
// Update with real IPST member names + functions before the summit demo
// Example functions: CE, Medical, GM, IMO, Regulatory, Market Access, Finance
// ===================================================================
const IPST_FUNCTION_MAP = {
  // ── Demo / POC team (Apollo project) ──
  "Tom Barry":          "GM",
  "Tom":                "GM",
  "Stan Tsvirko":       "Sponsor",
  "Stan":               "Sponsor",
  "Saburi Mohan":       "IMO",
  "Saburi":             "IMO",
  "Satya Shukla":       "CE",
  "Satya":              "CE",
  "Ash":                "Medical",
  "Revath":             "Regulatory",
  "Mohan Dhanalakota":  "Market Access",
  "Mohan":              "Market Access",
  "Sarah Chen":         "BEL",
  "Sarah":              "BEL",
  "Nina Patel":         "Bus. Excellence",
  "Nina":               "Bus. Excellence",
  "Dr. Priya Nair":     "Medical",
  "Dr Priya Nair":      "Medical",
  "Priya Nair":         "Medical",
  "Priya":              "Medical",
  "Luis Martinez":      "Market Access",
  "Luis":               "Market Access",
  "Mark Davidson":      "Forecasting",
  "Mark":               "Forecasting",
  "Priya Nair + Luis Martinez": "Medical + Market Access",
  "Jake Reynolds":      "Marketing",
  "Jake":               "Marketing",
  "Rachel Kim":         "Field Strategy",
  "Rachel":             "Field Strategy",
  "IDS partner":        "IDS",
  // ── Add your real IPST team members below before the demo ──
  // "First Last": "Function",
};

// Global task store — shared between Kanban and Chat pages
let allTasks = [];

// ===== Global function to navigate to task on Kanban board =====
// Called from clickable task links in chat responses
window.navigateToTask = function(url) {
  // Simply navigate to the URL - the checkHighlight function on the Kanban page
  // will handle finding and highlighting the correct card
  if (typeof url === 'string' && url.includes('?')) {
    window.location.href = url;
  } else {
    // Fallback for old-style calls with just taskId
    // Build correct path to Kanban board based on current location
    const isInStatic = window.location.pathname.includes('/static/');
    const kanbanPath = isInStatic ? 'index.html' : 'static/index.html';
    window.location.href = `${kanbanPath}?highlight=${encodeURIComponent(url)}`;
  }
  return false; // Prevent default link behavior
};

// ===== Detect current page and set API base path =====
const pathName = window.location.pathname;
const pathSegments = pathName.split("/").filter(s => s.length > 0);
const currentPage = pathSegments.length > 0 ? pathSegments[pathSegments.length - 1] : "";

// Debug logging
console.log('[INIT] pathname:', pathName);
console.log('[INIT] pathSegments:', pathSegments);
console.log('[INIT] currentPage:', currentPage);

// Determine API base path based on current page location
// - Pages in /static/ folder need "../" to reach API endpoints at root
// - All other pages (including root) use "./" for relative API calls
const isInStaticFolder = pathName.includes('/static/');
const API_BASE = isInStaticFolder ? '../' : './';

console.log('[INIT] isInStaticFolder:', isInStaticFolder);
console.log('[INIT] API_BASE:', API_BASE);

// Determine which page to initialize
// Check file extensions to identify actual HTML pages vs path segments
const isHtmlPage = currentPage.endsWith('.html');
const isIndexPage = currentPage === 'index.html';
const isChatPage = currentPage === 'chat.html';
const isUploadPage = currentPage === 'upload.html';
const isOnboardingHtml = currentPage === 'onboarding.html';

// Root path detection: no .html extension AND not in /static/ folder
// This handles: /, /app/, /codeeditor/default/ports/7007/, etc.
const isRootPath = !isHtmlPage && !isInStaticFolder;

console.log('[INIT] isHtmlPage:', isHtmlPage, '| isRootPath:', isRootPath);

if (isIndexPage && isInStaticFolder) {
  // index.html in /static/ folder = Team Board (Kanban)
  console.log('[INIT] Initializing Kanban...');
  initKanban();
} else if (isUploadPage) {
  console.log('[INIT] Initializing Upload...');
  initUpload();
} else if (isChatPage) {
  console.log('[INIT] Initializing Chat...');
  initChat();
} else if (isOnboardingHtml || isRootPath) {
  // onboarding.html OR root path (main.py serves onboarding.html at root)
  console.log('[INIT] Initializing Onboarding...');
  initOnboarding();
}


// ===================================================================
// KANBAN PAGE
// ===================================================================
function initKanban() {

  // --- Static data (commented out - now fetching from API) ---
  /*
  const tasks = {
    todo: [
      { title: "API Integration", project: "proj‑1", assignee: "Vivek", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Ujjawal", date: "15 Apr" },
      { title: "Data Pipeline", project: "proj‑2", assignee: "Rahul", date: "15 Apr" },
    ],
    inProgress: [
      { title: "Dashboard UI", project: "proj‑2", assignee: "Aman", date: "10 Apr" },
      { title: "Authentication api", project: "proj‑2", assignee: "Ujjawal", date: "30 Apr" },
    ],
    done: [
      { title: "Login Module", project: "proj‑1", assignee: "Rahul", date: "05 Apr" },
    ]
  };
  */

  function getInitials(name) {
    if (!name) return '?';
    return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);
  }

  function getAvatarColor(name) {
    let hash = 0;
    for (let i = 0; i < (name||'').length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    const hue = Math.abs(hash % 360);
    return `hsl(${hue}, 55%, 42%)`;
  }

  // allTasks is declared globally above

  function createCard(task, statusClass) {
    const rawAssignee = (task.assigned_to || '').trim();
    const isUnassigned = !rawAssignee || ['unassigned', 'tbd', 'none', 'n/a', ''].includes(rawAssignee.toLowerCase());
    const displayName = isUnassigned ? 'Unassigned' : rawAssignee;
    const initials = isUnassigned ? '?' : getInitials(rawAssignee);
    const color = isUnassigned ? '#666' : getAvatarColor(rawAssignee);
    const id = task.task_id || (task.task + rawAssignee).replace(/\s/g,'');
    const pk = encodeURIComponent(task.PK || `PROJECT#${task.project_name}`);
    const sk = encodeURIComponent(task.SK || `TASK#${id}`);
    // Resolve IPST function for this card's owner
    const fn = (!isUnassigned && (task.ipst_function || lookupIpstFunction(rawAssignee))) || '';
    const fnBadge = fn ? `<span class="func-badge" title="IPST Function">${fn}</span>` : '';
    const tbdClass = isUnassigned ? ' tbd-assignee' : '';
    // Overdue / due-soon colouring
    let dateClass = '';
    if (task.due_date && !['done','completed','complete','finished','closed'].includes((task.status||'').toLowerCase().trim())) {
      const due = new Date(task.due_date); due.setHours(0,0,0,0);
      const today = new Date(); today.setHours(0,0,0,0);
      const diff = Math.round((due - today) / 86400000);
      if (diff < 0) dateClass = ' date-overdue';
      else if (diff <= 3) dateClass = ' date-soon';
    }
    return `
      <div class="kanban-card ${statusClass}" draggable="true" data-task-id="${escapeHtml(id)}" data-task='${JSON.stringify(task).replace(/'/g,"&#39;")}'>  
        <button class="card-delete-btn" title="Delete task" data-pk="${pk}" data-sk="${sk}" onclick="event.stopPropagation()">&times;</button>
        <span class="kanban-project-pill">${task.project_name}</span>
        <h4>${task.task}</h4>
        <div class="kanban-footer">
          <span class="assignee-avatar${tbdClass}" style="background:${color}">${initials}</span>
          <span class="assignee-name${tbdClass}">${displayName}${fnBadge}</span>
          <span class="date${dateClass}">${task.due_date || ""}</span>
        </div>
      </div>
    `;
  }  // Show skeleton cards while loading
  function showSkeletons() {
    const skel = `<div class="kanban-card-skeleton"><div class="skel-line skel-short"></div><div class="skel-line skel-long"></div><div class="skel-line skel-mid"></div></div>`.repeat(3);
    document.getElementById('todoCards').innerHTML = skel;
    document.getElementById('progressCards').innerHTML = skel;
    document.getElementById('doneCards').innerHTML = skel;
  }
  showSkeletons();

  // ── Topbar ticker ──
  const _ticker = document.getElementById('topbarTicker');
  const _phrase1 = 'Tasks extracted from your Microsoft 365 team materials';
  let _tickerTaskCount = null;
  let _tickerInterval = null;
  let _tickerPhase = 0;

  function _typewrite(el, text, cb) {
    el.textContent = '';
    el.classList.remove('ticker-out', 'ticker-in');
    el.classList.add('ticker-visible');
    let i = 0;
    const iv = setInterval(() => {
      el.textContent = text.slice(0, ++i);
      if (i >= text.length) { clearInterval(iv); if (cb) setTimeout(cb, 2200); }
    }, 28);
  }

  function _tickerShow(text) {
    if (!_ticker) return;
    _ticker.classList.add('ticker-out');
    _ticker.classList.remove('ticker-visible');
    setTimeout(() => {
      _ticker.textContent = text;
      _ticker.classList.remove('ticker-out');
      _ticker.classList.add('ticker-in');
      requestAnimationFrame(() => requestAnimationFrame(() => {
        _ticker.classList.remove('ticker-in');
        _ticker.classList.add('ticker-visible');
      }));
    }, 420);
  }

  function _startTickerCycle() {
    if (_tickerInterval) clearInterval(_tickerInterval);
    _tickerInterval = setInterval(() => {
      if (_tickerTaskCount === null) return;
      _tickerPhase = 1 - _tickerPhase;
      const text = _tickerPhase === 0
        ? _phrase1
        : `${_tickerTaskCount} task${_tickerTaskCount !== 1 ? 's' : ''} · auto-refreshes every 10s`;
      _tickerShow(text);
    }, 4000);
  }

  if (_ticker) {
    _ticker.classList.add('ticker-in');
    requestAnimationFrame(() => requestAnimationFrame(() => _typewrite(_ticker, _phrase1, () => _startTickerCycle())));
  }

  function renderBoard(tasks) {
    document.getElementById("todoCount").textContent = tasks.todo.length;
    document.getElementById("progressCount").textContent = tasks.inProgress.length;
    document.getElementById("doneCount").textContent = tasks.done.length;
    const total = tasks.todo.length + tasks.inProgress.length + tasks.done.length;
    _tickerTaskCount = total;

    const emptyHtml = `<div class="kanban-empty">No tasks yet</div>`;
    document.getElementById("todoCards").innerHTML =
      tasks.todo.length ? tasks.todo.map(t => createCard(t, "status-pending")).join("") : emptyHtml;
    document.getElementById("progressCards").innerHTML =
      tasks.inProgress.length ? tasks.inProgress.map(t => createCard(t, "status-progress")).join("") : emptyHtml;
    document.getElementById("doneCards").innerHTML =
      tasks.done.length ? tasks.done.map(t => createCard(t, "status-done")).join("") : emptyHtml;

    // Re-attach drag & click listeners
    initDragAndDrop();
    initCardClick();
  }

  // ── Search / Filter ──
  const searchInput = document.getElementById('kanbanSearch');
  const filterAssignee = document.getElementById('kanbanFilterAssignee');
  const filterProject = document.getElementById('kanbanFilterProject');

  function applyFilters() {
    const q = (searchInput?.value || '').toLowerCase();
    const assignee = (filterAssignee?.value || '').toLowerCase();
    const project = (filterProject?.value || '').toLowerCase();
    const filtered = allTasks.filter(t => {
      if (q && !t.task.toLowerCase().includes(q) && !(t.assigned_to||'').toLowerCase().includes(q) && !(t.project_name||'').toLowerCase().includes(q)) return false;
      if (assignee && (t.assigned_to||'').toLowerCase() !== assignee) return false;
      if (project && (t.project_name||'').toLowerCase() !== project) return false;
      return true;
    });
    const tasks = { todo: [], inProgress: [], done: [] };
    filtered.forEach(item => {
      const status = (item.status || '').toLowerCase().trim();
      if (['done','completed','complete','finished','closed'].includes(status)) tasks.done.push(item);
      else if (['in progress','in_progress','inprogress','active','ongoing','started'].includes(status)) tasks.inProgress.push(item);
      else tasks.todo.push(item);
    });
    renderBoard(tasks);
  }
  if (searchInput) searchInput.addEventListener('input', applyFilters);
  if (filterAssignee) filterAssignee.addEventListener('change', applyFilters);
  if (filterProject) filterProject.addEventListener('change', applyFilters);

  // Track whether the project filter has been set by the user
  let _projectFilterUserSet = false;
  if (filterProject) {
    filterProject.addEventListener('change', () => { _projectFilterUserSet = true; });
  }

  function populateFilters(data) {
    // Normalise to Title Case and deduplicate case-insensitively
    function toTitleCase(s) {
      return s.trim().replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
    }
    function normDedup(arr) {
      const seen = new Map();
      arr.filter(Boolean).forEach(v => {
        const key = v.trim().toLowerCase();
        if (!seen.has(key)) seen.set(key, toTitleCase(v));
      });
      return [...seen.values()].sort();
    }
    const assignees = normDedup(data.map(t => t.assigned_to));
    const projects  = normDedup(data.map(t => t.project_name));
    if (filterAssignee) {
      const cur = (filterAssignee.value || '').toLowerCase();
      filterAssignee.innerHTML = '<option value="">All Assignees</option>' + assignees.map(a => `<option value="${a.toLowerCase()}">${a}</option>`).join('');
      [...filterAssignee.options].forEach(o => { if (o.value === cur) filterAssignee.value = o.value; });
    }
    if (filterProject) {
      const cur = (filterProject.value || '').toLowerCase();
      filterProject.innerHTML = '<option value="">All Projects</option>' + projects.map(p => `<option value="${p.toLowerCase()}">${p}</option>`).join('');
      // Restore previous selection OR default to Noventra IPST on first load
      if (cur) {
        [...filterProject.options].forEach(o => { if (o.value === cur) filterProject.value = o.value; });
      } else if (!_projectFilterUserSet) {
        // Auto-select Noventra IPST — but NOT when navigating from a chat link (?highlight)
        // so the highlighted card is always visible regardless of project
        const hasHighlight = new URLSearchParams(window.location.search).get('highlight');
        if (!hasHighlight) {
          const noventraOpt = [...filterProject.options].find(o => o.value.includes('noventra'));
          if (noventraOpt) { filterProject.value = noventraOpt.value; }
        }
      }
    }
  }

  // ── Drag & Drop ──
  function initDragAndDrop() {
    const cards = document.querySelectorAll('.kanban-card[draggable]');
    const columns = document.querySelectorAll('.kanban-cards-scroll');

    cards.forEach(card => {
      card.addEventListener('dragstart', e => {
        card.classList.add('dragging');
        e.dataTransfer.setData('text/plain', card.dataset.taskId);
        e.dataTransfer.effectAllowed = 'move';
      });
      card.addEventListener('dragend', () => card.classList.remove('dragging'));
    });

    columns.forEach(col => {
      col.addEventListener('dragover', e => { e.preventDefault(); col.classList.add('drag-over'); });
      col.addEventListener('dragleave', () => col.classList.remove('drag-over'));
      col.addEventListener('drop', e => {
        e.preventDefault();
        col.classList.remove('drag-over');
        const taskId = e.dataTransfer.getData('text/plain');
        // Determine new status from column
        let newStatus = 'To Do';
        if (col.id === 'progressCards') newStatus = 'In Progress';
        else if (col.id === 'doneCards') newStatus = 'Done';
        // Find task and update via chat API
        const task = allTasks.find(t => (t.task_id || (t.task + t.assigned_to).replace(/\s/g,'')) === taskId);
        if (task && (task.status || '').toLowerCase().trim() !== newStatus.toLowerCase()) {
          showToast(`Moving "${task.task}" \u2192 ${newStatus}...`, 'info', 2500);
          // Build a message that clearly triggers update intent in the decision node
          const statusPhrase = newStatus === 'Done' ? 'mark it done'
            : newStatus === 'In Progress' ? 'set status to in progress'
            : 'set status to to do';
          const dragMsg = `${statusPhrase} — task: "${task.task}", assignee: ${task.assigned_to}, project: ${task.project_name}`;
          fetch(API_BASE + 'agent', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_history: [dragMsg],
              clarification_received: false,
              result_payload: {}
            })
          })
          .then(r => r.json())
          .then(data => {
            if (data.clarification_needed) {
              // Auto-confirm: send 'yes' with the payload from first call
              return fetch(API_BASE + 'agent', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  chat_history: [dragMsg, 'yes'],
                  clarification_received: true,
                  result_payload: { ...data.result_payload, clarification_needed: false }
                })
              }).then(r => r.json());
            }
            // Agent applied update directly (no clarification needed)
            return data;
          })
          .then(finalData => {
            if (finalData && finalData.clarification_needed) {
              // Shouldn't happen but guard anyway
              showToast(`Update pending — please confirm in Chat`, 'warning');
            } else {
              showToast(`✅ "${task.task}" moved to ${newStatus}`, 'success');
            }
            // Suppress the "Board updated" toast since we just showed a success toast
            _suppressBoardUpdateToast = true;
            setTimeout(fetchAndRenderTasks, 1500);
          })
          .catch(() => showToast('Failed to update task — try via Chat instead', 'error'));
        }
      });
    });
  }

  // ── Card Click → Expand Modal ──
  function initCardClick() {
    document.querySelectorAll('.kanban-card[data-task]').forEach(card => {
      card.addEventListener('click', e => {
        if (e.target.closest('.assignee-avatar') || e.target.closest('.card-delete-btn')) return;
        try {
          const task = JSON.parse(card.dataset.task);
          showCardModal(task);
        } catch(err) {}
      });
    });

    // Delete button
    document.querySelectorAll('.card-delete-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const card = btn.closest('.kanban-card');
        const taskName = card.querySelector('h4')?.textContent || 'this task';
        if (!confirm(`Delete "${taskName}" from the board?`)) return;
        const pk = decodeURIComponent(btn.dataset.pk);
        const sk = decodeURIComponent(btn.dataset.sk);
        fetch(`${API_BASE}tasks?pk=${encodeURIComponent(pk)}&sk=${encodeURIComponent(sk)}`, { method: 'DELETE' })
          .then(r => r.json())
          .then(() => {
            card.style.transition = 'opacity .3s, transform .3s';
            card.style.opacity = '0';
            card.style.transform = 'scale(.85)';
            setTimeout(() => { card.remove(); fetchAndRenderTasks(); }, 320);
            showToast(`🗑️ "${taskName}" deleted`, 'info');
          })
          .catch(() => showToast('Failed to delete task', 'error'));
      });
    });
  }

  function showCardModal(task) {
    const overlay = document.createElement('div');
    overlay.className = 'card-modal-overlay';
    const fn = task.ipst_function || lookupIpstFunction(task.assigned_to || '');
    const assignee = task.assigned_to && !['unassigned','tbd','none','n/a'].includes((task.assigned_to||'').toLowerCase())
      ? task.assigned_to : '<span style="opacity:.6;font-style:italic">Unassigned</span>';
    overlay.innerHTML = `
      <div class="card-modal" style="position:relative;">
        <button class="modal-close" title="Close (Esc)">&times;</button>
        <h3>${task.task}</h3>
        <div class="modal-grid">
          <span class="modal-label">Project</span>      <span class="modal-value">${task.project_name || '—'}</span>
          <span class="modal-label">Assigned to</span>  <span class="modal-value">${assignee}</span>
          <span class="modal-label">Function</span>     <span class="modal-value">${fn ? `<span class="func-badge">${fn}</span>` : '<span style="opacity:.4">—</span>'}</span>
          <span class="modal-label">Status</span>       <span class="modal-value">${task.status || '—'}</span>
          <span class="modal-label">Due date</span>     <span class="modal-value">${task.due_date || '—'}</span>
          <span class="modal-label">Priority</span>     <span class="modal-value">${task.priority || '—'}</span>
          ${task.description ? `<span class="modal-label">Description</span><span class="modal-value">${task.description}</span>` : ''}
        </div>
        <div class="modal-esc-hint">Press Esc or click outside to close</div>
      </div>
    `;
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    overlay.querySelector('.modal-close').addEventListener('click', () => overlay.remove());
    document.addEventListener('keydown', function escHandler(e) {
      if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', escHandler); }
    });
    document.body.appendChild(overlay);
  }

  let lastTaskCount = -1;
  let _suppressBoardUpdateToast = false; // Suppress toast during drag-drop refresh

  // ── Highlight a card when navigated from a chat link ──
  function checkHighlight() {
    const params = new URLSearchParams(window.location.search);
    const highlight = params.get('highlight');
    if (!highlight) return;
    const lower        = highlight.toLowerCase().trim();
    const assigneeHint = (params.get('assignee') || '').toLowerCase().trim();
    const statusHint   = (params.get('status')   || '').toLowerCase().trim();

    // Map status hint to the column id it should be in
    const DONE_STATUSES = ['done','completed','complete','finished','closed'];
    const PROG_STATUSES = ['in progress','in_progress','inprogress','active','ongoing','started'];
    let expectedCol = null;
    if (statusHint) {
      if (DONE_STATUSES.some(s => statusHint.startsWith(s))) expectedCol = 'doneCards';
      else if (PROG_STATUSES.some(s => statusHint.startsWith(s))) expectedCol = 'progressCards';
      else expectedCol = 'todoCards'; // at risk, not ready, blocked, provisional, pending → todo
    }

    let found = null;
    let bestScore = -1;
    document.querySelectorAll('.kanban-card').forEach(card => {
      const title    = (card.querySelector('h4')?.textContent || '').trim().toLowerCase();
      const assignee = (card.querySelector('.assignee-name')?.textContent || '').trim().toLowerCase();
      const colId    = card.closest('.kanban-cards-scroll')?.id || '';

      // Score title match
      let score = -1;
      if (title === lower) score = 100;
      else if (title.includes(lower) || lower.includes(title)) score = 50;
      else {
        const titleWords = new Set(title.split(/\s+/));
        const overlap = lower.split(/\s+/).filter(w => w.length > 2 && titleWords.has(w)).length;
        if (overlap > 0) score = overlap;
      }
      if (score < 0) return;

      // Boost: assignee matches (skip generic unassigned)
      const isGenericAssignee = ['unassigned','tbd','none','n/a',''].includes(assigneeHint);
      if (assigneeHint && !isGenericAssignee) {
        const hintWords = assigneeHint.split(/\s+/).filter(w => w.length > 1);
        const matchCount = hintWords.filter(w => assignee.includes(w)).length;
        if (matchCount > 0) score += 200 * matchCount; // +200 per matched name word (first + last = +400)
      }
      // Boost: card is in the expected status column
      if (expectedCol && colId === expectedCol) {
        score += 500;
      }

      if (score > bestScore) { bestScore = score; found = card; }
    });
    if (found && bestScore >= 0) {
      found.classList.add('card-highlight');
      found.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => found.classList.remove('card-highlight'), 8000);
    } else if (highlight) {
      // Card not found — show a toast so user knows board is open but task wasn't matched
      showToast(`Task "${highlight.length > 40 ? highlight.slice(0,40)+'…' : highlight}" not found on board`, 'info', 5000);
    }
  }

  function fetchAndRenderTasks() {
    fetch(API_BASE + "tasks")
      .then(res => res.json())
      .then(data => {
        allTasks = data;
        populateFilters(data);

        // If filters active, use them
        const q = (searchInput?.value || '').toLowerCase();
        const assignee = filterAssignee?.value || '';
        const project = filterProject?.value || '';
        const _hlParam = new URLSearchParams(window.location.search).get('highlight');
        if (q || assignee || project) {
          applyFilters();
          // Still run highlight after filter renders if navigating from chat
          if (_hlParam && lastTaskCount < 0) {
            lastTaskCount = data.length;
            let _hlTries = 0;
            function _tryHlFiltered() {
              _hlTries++;
              checkHighlight();
              if (_hlTries < 8 && !document.querySelector('.card-highlight')) setTimeout(_tryHlFiltered, 400);
            }
            setTimeout(_tryHlFiltered, 300);
          }
        }
        else {
          const tasks = { todo: [], inProgress: [], done: [] };
          data.forEach(item => {
            const status = (item.status || "").toLowerCase().trim();
            if (["done", "completed", "complete", "finished", "closed"].includes(status)) {
              tasks.done.push(item);
            } else if (["in progress", "in_progress", "inprogress", "active", "ongoing", "started"].includes(status)) {
              tasks.inProgress.push(item);
            } else {
              tasks.todo.push(item);
            }
          });
          // Toast on task count change (after first load) - but NOT during drag-drop refresh
          if (lastTaskCount >= 0 && data.length !== lastTaskCount && !_suppressBoardUpdateToast) {
            showToast(`Board updated — ${data.length} tasks`, 'info');
          }
          _suppressBoardUpdateToast = false; // Reset flag after use
          const isFirstLoad = lastTaskCount < 0;
          lastTaskCount = data.length;
          renderBoard(tasks);
          // On the very first load, scroll to highlighted card if URL has ?highlight=
          if (isFirstLoad) {
            // Retry checkHighlight until a matching card is found (board render may lag)
            let _hlTries = 0;
            function _tryHighlight() {
              _hlTries++;
              const params = new URLSearchParams(window.location.search);
              if (!params.get('highlight')) return;
              checkHighlight();
              // If no card highlighted yet and still early, retry
              if (_hlTries < 8 && !document.querySelector('.card-highlight')) {
                setTimeout(_tryHighlight, 400);
              }
            }
            setTimeout(_tryHighlight, 300);
          }
        }
      })
      .catch(err => {
        console.error("Failed to fetch tasks from API:", err);
      });
  }

  // Fetch immediately on page load
  fetchAndRenderTasks();

  // Auto-refresh every 10 seconds
  setInterval(fetchAndRenderTasks, 10000);
}


// ===================================================================
// UPLOAD PAGE
// ===================================================================
function initUpload() {
  let selectedFiles = [];

  const fileInput = document.getElementById("fileInput");
  const fileCards = document.getElementById("fileCards");
  const dropPlaceholder = document.getElementById("dropPlaceholder");
  const fileCategorySelect = document.getElementById("fileCategory");

  fileInput.addEventListener("change", (e) => {
    const category = fileCategorySelect.value;
    if (!category) {
      alert("Please select Doc Type first");
      fileInput.value = "";
      return;
    }
    for (let file of e.target.files) {
      selectedFiles.push({ file, category });
    }
    fileCategorySelect.value = "";
    fileInput.value = "";
    renderFiles();
  });

  // Expose globally for onclick handlers
  window.removeFile = function(index) {
    selectedFiles.splice(index, 1);
    renderFiles();
  };

  window.uploadAllFiles = function() {
    if (selectedFiles.length === 0) {
      alert("No files selected");
      return;
    }
    const formData = new FormData();
    selectedFiles.forEach((item) => {
      formData.append("files", item.file);
      formData.append("categories", item.category);
    });
    const forceCheckbox = document.getElementById("forceReindex");
    const forceReindex = forceCheckbox && forceCheckbox.checked;
    if (forceReindex) formData.append("force_reindex", "true");

    const uploadBtn = document.getElementById("uploadBtn");
    const statusBanner = document.getElementById("uploadStatus");
    const progressWrap = document.getElementById("uploadProgressWrap");
    const progressBar = document.getElementById("uploadProgressBar");
    if (uploadBtn) { uploadBtn.disabled = true; uploadBtn.textContent = "Uploading…"; }
    if (statusBanner) { statusBanner.style.display = "none"; }
    if (progressWrap) { progressWrap.classList.add("active"); }
    if (progressBar) { progressBar.style.width = "15%"; }

    // Simulate progress while waiting
    let fakeProgress = 15;
    const progressInterval = setInterval(() => {
      fakeProgress = Math.min(fakeProgress + Math.random() * 12, 85);
      if (progressBar) progressBar.style.width = fakeProgress + "%";
    }, 600);

    fetch(API_BASE + "upload", { method: "POST", body: formData })
      .then(res => res.json())
      .then((data) => {
        clearInterval(progressInterval);
        if (progressBar) progressBar.style.width = "100%";
        setTimeout(() => { if (progressWrap) progressWrap.classList.remove("active"); }, 800);
        const msg = (data.response || "");
        const isDuplicate = msg.includes("already uploaded") || msg.includes("skipped");
        const isFailed = msg.toLowerCase().includes("failed") || msg.toLowerCase().includes("error");

        if (statusBanner) {
          statusBanner.style.display = "block";
          statusBanner.textContent = msg || "Upload complete.";
          if (isDuplicate && !msg.includes("✅")) {
            // All files were duplicates
            statusBanner.style.background = "rgba(251,191,36,0.15)";
            statusBanner.style.border = "1px solid rgba(251,191,36,0.5)";
            statusBanner.style.color = "#fbbf24";
          } else if (isFailed) {
            statusBanner.style.background = "rgba(239,68,68,0.15)";
            statusBanner.style.border = "1px solid rgba(239,68,68,0.4)";
            statusBanner.style.color = "#f87171";
          } else {
            // Success (possibly with some skipped)
            statusBanner.style.background = "rgba(34,197,94,0.12)";
            statusBanner.style.border = "1px solid rgba(34,197,94,0.4)";
            statusBanner.style.color = "#4ade80";
          }
        }

        if (!isFailed) {
          selectedFiles = [];
          renderFiles();
        }
      })
      .catch(err => {
        console.error(err);
        clearInterval(progressInterval);
        if (progressWrap) progressWrap.classList.remove("active");
        showToast('Upload failed — please try again', 'error');
        if (statusBanner) {
          statusBanner.style.display = "block";
          statusBanner.textContent = "❌ Upload failed — please try again.";
          statusBanner.style.background = "rgba(239,68,68,0.15)";
          statusBanner.style.border = "1px solid rgba(239,68,68,0.4)";
          statusBanner.style.color = "#f87171";
        }
      })
      .finally(() => {
        if (uploadBtn) { uploadBtn.disabled = false; uploadBtn.textContent = "Upload All"; }
      });
  };

  function renderFiles() {
    fileCards.innerHTML = "";
    if (selectedFiles.length === 0) {
      dropPlaceholder.style.display = "block";
    } else {
      dropPlaceholder.style.display = "none";
    }
    selectedFiles.forEach((item, index) => {
      const card = document.createElement("div");
      card.className = "file-card";
      card.innerHTML = `
        <div class="file-card-content" id="content-${index}">Loading...</div>
        <div class="file-card-meta">
          <span class="file-card-category">${item.category}</span>
          <span class="file-card-size">${formatSize(item.file.size)}</span>
        </div>
        <div class="file-card-header">
          <span class="file-card-name">${item.file.name}</span>
          <button class="remove-btn" onclick="removeFile(${index})">✕</button>
        </div>
      `;
      fileCards.appendChild(card);
      loadFileContent(item.file, index);
    });
  }

  function loadFileContent(file, index) {
    const contentDiv = document.getElementById(`content-${index}`);
    const type = file.type;
    const name = file.name.toLowerCase();

    if (type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (e) => { contentDiv.innerHTML = `<img src="${e.target.result}" alt="${file.name}" />`; };
      reader.readAsDataURL(file);

    } else if (type === "application/pdf" || name.endsWith(".pdf")) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const pdf = await pdfjsLib.getDocument({ data: e.target.result }).promise;
          const page = await pdf.getPage(1);
          const viewport = page.getViewport({ scale: 0.8 });
          const canvas = document.createElement("canvas");
          canvas.width = viewport.width;
          canvas.height = viewport.height;
          canvas.style.width = "100%";
          canvas.style.borderRadius = "6px";
          const ctx = canvas.getContext("2d");
          await page.render({ canvasContext: ctx, viewport }).promise;
          contentDiv.innerHTML = "";
          contentDiv.appendChild(canvas);
          if (pdf.numPages > 1) {
            contentDiv.innerHTML += `<span class="file-type-label" style="display:block;margin-top:4px;">Page 1 of ${pdf.numPages}</span>`;
          }
        } catch { contentDiv.innerHTML = `<span class="file-type-label">📄 PDF (preview failed)</span>`; }
      };
      reader.readAsArrayBuffer(file);

    } else if (type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || name.endsWith(".docx")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        mammoth.convertToHtml({ arrayBuffer: e.target.result })
          .then((result) => {
            const preview = result.value.length > 1000 ? result.value.substring(0, 1000) + "..." : result.value;
            contentDiv.innerHTML = `<div class="docx-preview">${preview}</div>`;
          })
          .catch(() => { contentDiv.innerHTML = `<span class="file-type-label">📄 Word (preview failed)</span>`; });
      };
      reader.readAsArrayBuffer(file);

    } else if (name.endsWith(".doc")) {
      contentDiv.innerHTML = `<span class="file-type-label">📄 Word (.doc) — preview not supported</span>`;

    } else if (type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || type === "application/vnd.ms-excel" || name.endsWith(".xlsx") || name.endsWith(".xls")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const workbook = XLSX.read(e.target.result, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
          const rows = jsonData.slice(0, 10);
          let html = `<table class="xlsx-preview"><tbody>`;
          rows.forEach((row, i) => {
            html += `<tr>`;
            row.forEach((cell) => { html += i === 0 ? `<th>${escapeHtml(String(cell ?? ""))}</th>` : `<td>${escapeHtml(String(cell ?? ""))}</td>`; });
            html += `</tr>`;
          });
          html += `</tbody></table>`;
          if (jsonData.length > 10) html += `<span class="file-type-label">...${jsonData.length - 10} more rows</span>`;
          contentDiv.innerHTML = html;
        } catch { contentDiv.innerHTML = `<span class="file-type-label">📊 Excel (preview failed)</span>`; }
      };
      reader.readAsArrayBuffer(file);

    } else if (type.startsWith("video/")) {
      const reader = new FileReader();
      reader.onload = (e) => { contentDiv.innerHTML = `<video src="${e.target.result}" controls class="video-preview"></video>`; };
      reader.readAsDataURL(file);

    } else if (type.startsWith("audio/")) {
      const reader = new FileReader();
      reader.onload = (e) => { contentDiv.innerHTML = `<audio src="${e.target.result}" controls class="audio-preview"></audio>`; };
      reader.readAsDataURL(file);

    } else if (type.startsWith("text/") || type === "application/json" || type === "application/xml" || name.endsWith(".csv")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        const preview = text.length > 500 ? text.substring(0, 500) + "..." : text;
        contentDiv.innerHTML = `<pre>${escapeHtml(preview)}</pre>`;
      };
      reader.readAsText(file);

    } else {
      contentDiv.innerHTML = `<span class="file-type-label">📎 ${file.type || "Unknown"} — no preview</span>`;
    }
  }
}


// ===================================================================
// CHAT PAGE
// ===================================================================
function initChat() {
  const chatMessages = document.getElementById("chatMessages");
  const chatInput = document.getElementById("chatInput");

  // ── Pre-load tasks so postProcessBotMessage can build accurate board links ──
  fetch(API_BASE + 'tasks').then(r => r.json()).then(data => {
    allTasks = data;
    // Re-process any bot bubbles already rendered (e.g. canned responses that came back
    // before tasks were fetched, or messages restored from localStorage)
    document.querySelectorAll('.msg-bubble--bot').forEach(bubble => postProcessBotMessage(bubble));
  }).catch(() => {});

  // ── State ──
  let chatHistory           = JSON.parse(localStorage.getItem("chatHistory") || "[]");
  let resultPayload         = JSON.parse(localStorage.getItem("resultPayload") || "{}");
  let clarificationNeeded   = JSON.parse(localStorage.getItem("clarificationNeeded") || "false");
  let clarificationReceived = JSON.parse(localStorage.getItem("clarificationReceived") || "false");
  let savedMessages         = JSON.parse(localStorage.getItem("chatMessages") || "[]");
  let requestInFlight       = false;
  let abortController       = null;
  let isNavigatingAway      = false;   // set true on beforeunload — silences ANY fetch error

  // ── Auto-resize textarea ──
  if (chatInput) {
    chatInput.addEventListener("input", () => {
      chatInput.style.height = "auto";
      chatInput.style.height = Math.min(chatInput.scrollHeight, 140) + "px";
    });
    chatInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });
  }

  // ── On navigation away: flag it + abort the fetch ──
  // Browser can kill fetch with TypeError("Failed to fetch") OR AbortError
  // depending on timing. The flag catches both cases.
  window.addEventListener("beforeunload", () => {
    isNavigatingAway = true;
    if (abortController) abortController.abort("navigation");
  });

  // ── State flag: suppress scroll during bulk message restore ──
  let isRestoring = false;

  // ── Restore saved messages — strip any stale error messages before restoring ──
  const ERROR_TEXT = "Something went wrong. Please try again.";
  savedMessages = savedMessages.filter(m => m.text !== ERROR_TEXT);
  localStorage.setItem("chatMessages", JSON.stringify(savedMessages));

  if (savedMessages.length > 0) {
    hideWelcome();
    isRestoring = true;
    savedMessages.forEach(msg => appendMessage(msg.text, msg.sender, false));
    isRestoring = false;
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  // ── Re-sync on tab return — only re-render if messages were added from another window ──
  let savedScrollTop = 0;
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      // Save scroll position when leaving tab
      savedScrollTop = chatMessages.scrollTop;
    } else if (document.visibilityState === "visible") {
      const fresh = JSON.parse(localStorage.getItem("chatMessages") || "[]");
      if (fresh.length > savedMessages.length) {
        // New messages added from another window — re-render silently
        savedMessages = fresh;
        chatMessages.innerHTML = "";
        isRestoring = true;
        savedMessages.forEach(msg => appendMessage(msg.text, msg.sender, false));
        isRestoring = false;
        chatMessages.scrollTop = chatMessages.scrollHeight;
      } else {
        // Same messages — just restore exact scroll position, no re-render
        chatMessages.scrollTop = savedScrollTop;
      }
    }
  });

  // ── Fire a request (shared by send + re-fire on load) ──
  function firePendingRequest(requestBody) {
    if (requestInFlight) return;
    requestInFlight = true;
    disableInput();
    showTyping();
    abortController = new AbortController();
    fetch(API_BASE + "agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody),
      signal: abortController.signal
    })
      .then(res => {
        // Read raw text first so we never lose the body
        return res.text().then(rawText => ({ ok: res.ok, status: res.status, rawText }));
      })
      .then(({ ok, status, rawText }) => {
        removeTyping();
        if (isNavigatingAway) return;
        localStorage.removeItem("chatPendingRequest");
        let data;
        try { data = JSON.parse(rawText); }
        catch (e) {
          console.error("Non-JSON response from /agent ("+status+"):", rawText.slice(0,300));
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        if (!ok) {
          console.error("Error response from /agent:", status, data);
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        const botAnswer = data.answer || data.response || "Sorry, I couldn't find an answer."
        appendMessage(botAnswer, "bot", true, true);
        resultPayload       = data.result_payload;
        clarificationNeeded = data.clarification_needed;
        saveState();
      })
      .catch(err => {
        removeTyping();
        if (isNavigatingAway || err.name === "AbortError") return;
        localStorage.removeItem("chatPendingRequest");
        console.error("firePendingRequest error:", err.name, err.message);
        appendMessage("Something went wrong. Please try again.", "bot", false);
      })
      .finally(() => {
        requestInFlight = false;
        enableInput();
      });
  }

  // ── On load: re-fire any pending request after a short delay so page is fully ready ──
  const pendingOnLoad = localStorage.getItem("chatPendingRequest");
  if (pendingOnLoad) {
    try {
      const req = JSON.parse(pendingOnLoad);
      setTimeout(() => firePendingRequest(req), 400);
    } catch (e) {
      localStorage.removeItem("chatPendingRequest");
    }
  }

  function saveState() {
    localStorage.setItem("chatHistory",          JSON.stringify(chatHistory));
    localStorage.setItem("resultPayload",         JSON.stringify(resultPayload));
    localStorage.setItem("clarificationNeeded",   JSON.stringify(clarificationNeeded));
    localStorage.setItem("clarificationReceived", JSON.stringify(clarificationReceived));
    localStorage.setItem("chatMessages",          JSON.stringify(savedMessages));
  }

  function disableInput() {
    if (chatInput) chatInput.disabled = true;
    const sendBtn = document.getElementById("sendBtn");
    if (sendBtn) sendBtn.disabled = true;
  }

  function enableInput() {
    if (chatInput) chatInput.disabled = false;
    const sendBtn = document.getElementById("sendBtn");
    if (sendBtn) sendBtn.disabled = false;
    if (chatInput) chatInput.focus();
  }

  function hideWelcome() {
    const w = document.getElementById("chatWelcome");
    if (w) w.remove();
  }

  window.sendMessage = function() {
    if (!chatInput) return;
    const text = chatInput.value.trim();
    if (!text) return;

    hideWelcome();
    appendMessage(text, "user");
    chatInput.value = "";
    chatInput.style.height = "auto";
    requestInFlight = true;
    disableInput();
    showTyping();

    if (clarificationNeeded) {
      clarificationReceived = true;
      // Must clear clarification_needed in the payload so update_node
      // takes the "apply update" branch, not the "re-ask" branch
      clarificationNeeded = false;
    } else {
      chatHistory = [];
      clarificationReceived = false;
    }
    chatHistory.push(text);
    saveState();

    // When sending a confirmation, strip clarification_needed from result_payload too
    const payloadToSend = resultPayload
      ? { ...resultPayload, clarification_needed: false }
      : resultPayload;
    const requestBody = { chat_history: chatHistory, clarification_received: clarificationReceived, result_payload: payloadToSend };
    localStorage.setItem("chatPendingRequest", JSON.stringify(requestBody));

    abortController = new AbortController();
    fetch(API_BASE + "agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody),
      signal: abortController.signal
    })
      .then(res => {
        return res.text().then(rawText => ({ ok: res.ok, status: res.status, rawText }));
      })
      .then(({ ok, status, rawText }) => {
        removeTyping();
        if (isNavigatingAway) return;
        localStorage.removeItem("chatPendingRequest");
        let data;
        try { data = JSON.parse(rawText); }
        catch (e) {
          console.error("Non-JSON response from /agent ("+status+"):", rawText.slice(0,300));
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        if (!ok) {
          console.error("Error response from /agent:", status, data);
          appendMessage("Something went wrong. Please try again.", "bot", false);
          return;
        }
        const botAnswer = data.answer || data.response || "Sorry, I couldn't find an answer.";
        appendMessage(botAnswer, "bot", true, true);
        resultPayload       = data.result_payload;
        clarificationNeeded = data.clarification_needed;
        saveState();
      })
      .catch(err => {
        removeTyping();
        if (isNavigatingAway || err.name === "AbortError") return;
        localStorage.removeItem("chatPendingRequest");
        console.error("sendMessage error:", err.name, err.message);
        appendMessage("Something went wrong. Please try again.", "bot", false);
      })
      .finally(() => {
        requestInFlight = false;
        enableInput();
      });
  };

  // ── Suggestion chips (sidebar) ──
  window.askSuggestion = function(btn) {
    const text = btn.textContent.trim();
    if (!text || !chatInput) return;
    chatInput.value = text;
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 140) + "px";
    sendMessage();
  };

  // ── Welcome panel quick chips ──
  window.useQuickPrompt = function(btn) {
    const text = btn.textContent.trim();
    if (!text || !chatInput) return;
    chatInput.value = text;
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 140) + "px";
    sendMessage();
  };

  // ── Clear chat ──
  window.clearChat = function() {
    chatHistory = [];
    resultPayload = {};
    clarificationNeeded = false;
    clarificationReceived = false;
    savedMessages = [];
    ["chatHistory","resultPayload","clarificationNeeded","clarificationReceived","chatMessages","chatPendingRequest"]
      .forEach(k => localStorage.removeItem(k));
    chatMessages.innerHTML = `
      <div class="chat-welcome" id="chatWelcome">
        <div class="chat-welcome-icon">🤖</div>
        <h3>What would you like to know?</h3>
        <p>I can answer questions about your uploaded documents, track tasks, and help you find key information.</p>
        <div class="chat-quick-actions">
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">Who is working on Project Apollo?</button>
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">What are the blockers on the Noventra launch?</button>
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">What decisions were made in the last meeting?</button>
          <button class="chat-quick-chip" onclick="useQuickPrompt(this)">What tasks are still pending?</button>
        </div>
      </div>`;
  };

  // ── Append message (with optional typewriter for bot) ──
  let _lastUserRow = null;
  function scrollToShowQuestion() {
    if (_lastUserRow && !isRestoring) {
      requestAnimationFrame(() => {
        _lastUserRow.scrollIntoView({ behavior: 'instant', block: 'start' });
      });
    } else if (!isRestoring) {
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }

  function appendMessage(text, sender, persist = true, typewriter = false) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const isUser = sender === "user";

    const row = document.createElement("div");
    row.className = `msg-row ${isUser ? "msg-row--user" : "msg-row--bot"}`;

    const avatar = document.createElement("div");
    avatar.className = `msg-avatar ${isUser ? "msg-avatar--user" : "msg-avatar--bot"}`;
    avatar.textContent = isUser ? "You" : "AI";

    const stack = document.createElement("div");
    stack.className = "msg-stack";

    const meta = document.createElement("div");
    meta.className = "msg-meta";
    meta.textContent = (isUser ? "You" : "Agentic Colleague") + " · " + timeStr;

    const bubble = document.createElement("div");
    bubble.className = `msg-bubble ${isUser ? "msg-bubble--user" : "msg-bubble--bot"}`;

    if (isUser) {
      bubble.textContent = text;
      if (!isRestoring) _lastUserRow = row;
    } else if (typewriter) {
      bubble.innerHTML = "";
      stack.appendChild(meta);
      stack.appendChild(bubble);
      row.appendChild(avatar);
      row.appendChild(stack);
      chatMessages.appendChild(row);
      if (isHtml(text)) {
        bubble.innerHTML = applyThemeToHtml(text);
        scrollToShowQuestion();
        if (!isRestoring) {
          setTimeout(() => {
            postProcessBotMessage(bubble);
            scrollToShowQuestion();
            const idx = savedMessages.length - 1;
            if (idx >= 0 && savedMessages[idx].sender === 'bot') {
              savedMessages[idx].text = bubble.innerHTML;
              localStorage.setItem('chatMessages', JSON.stringify(savedMessages));
            }
          }, 0);
        }
      } else {
        typewriterEffect(bubble, text);
      }
      if (persist) savedMessages.push({ text, sender });
      return;
    } else {
      bubble.innerHTML = isHtml(text) ? applyThemeToHtml(text) : renderMarkdown(text);
      if (!isRestoring) {
        setTimeout(() => {
          postProcessBotMessage(bubble);
          scrollToShowQuestion();
          const idx = savedMessages.length - 1;
          if (idx >= 0 && savedMessages[idx].sender === 'bot') {
            savedMessages[idx].text = bubble.innerHTML;
            localStorage.setItem('chatMessages', JSON.stringify(savedMessages));
          }
        }, 0);
      }
    }

    stack.appendChild(meta);
    stack.appendChild(bubble);
    if (isUser) {
      row.appendChild(stack);
      row.appendChild(avatar);
    } else {
      row.appendChild(avatar);
      row.appendChild(stack);
    }
    chatMessages.appendChild(row);
    if (!isRestoring) {
      if (isUser) {
        // Scroll so the question appears at the top — response will appear below it
        requestAnimationFrame(() => row.scrollIntoView({ behavior: 'instant', block: 'start' }));
      }
      else scrollToShowQuestion();
    }

    if (persist) savedMessages.push({ text, sender });
  }

  // ── Detect if text is already HTML (from backend markdown.markdown()) ──
  function isHtml(text) {
    return /<(p|h[1-6]|ul|ol|li|table|thead|tbody|tr|td|th|strong|em|code|pre|br|div)[\s>]/i.test(text);
  }

  // ── Inject md-table class into backend <table> tags so CSS styles apply ──
  function applyThemeToHtml(html) {
    // Add md-table to tables that don't have it yet (handles both with/without existing class)
    return html
      .replace(/<table([^>]*class="([^"]*)")([^>]*)>/gi, (m, p1, cls, p3) =>
        cls.includes('md-table') ? m : `<table${p1.replace(cls, cls + ' md-table')}${p3}>`
      )
      .replace(/<table(?![^>]*class=)([^>]*)>/gi, '<table class="md-table"$1>');
  }

  // ── Markdown renderer (lightweight) ──
  function renderMarkdown(text) {
    if (!text) return '';
    let html = text;

    // Code blocks (protect from other transforms)
    const codeBlocks = [];
    html = html.replace(/```([\s\S]*?)```/g, (_, code) => {
      codeBlocks.push(`<pre><code>${code}</code></pre>`);
      return `%%CODE${codeBlocks.length - 1}%%`;
    });

    // Tables — must run before line-break conversion
    html = html.replace(/((?:^\|.+\|\s*\n?)+)/gm, (match) => {
      const rows = match.trim().split('\n').filter(r => r.trim());
      // Filter separator rows like |---|---|
      const dataRows = rows.filter(r => !/^\|[\s:\-|]+\|$/.test(r.trim()));
      if (dataRows.length < 1) return match;
      const parseRow = r => r.replace(/^\||\|$/g, '').split('|').map(c => c.trim());
      const [header, ...body] = dataRows;
      const ths = parseRow(header).map(h => `<th>${h}</th>`).join('');
      const trs = body.map(r => `<tr>${parseRow(r).map(c => `<td>${c}</td>`).join('')}</tr>`).join('');
      return `<table class="md-table"><thead><tr>${ths}</tr></thead><tbody>${trs}</tbody></table>`;
    });

    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    // Bold
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    // Italic
    html = html.replace(/(?<![*])\*([^*]+)\*(?![*])/g, '<em>$1</em>');
    // Headers
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    // Unordered lists
    html = html.replace(/^[-•*] (.+)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>[\s\S]*?<\/li>\n?)+/g, m => `<ul>${m}</ul>`);
    // Ordered lists
    html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');
    // Line breaks (skip inside block elements already converted)
    html = html.replace(/(?<!<\/table>)(?<!<\/ul>)(?<!<\/h[23]>)\n/g, '<br>');
    // Clean up extra <br> after block elements
    html = html.replace(/(<\/table>|<\/ul>|<\/h[23]>|<\/pre>)<br>/g, '$1');
    // Remove <br> tags immediately before a table (gap before table fix)
    html = html.replace(/(<br>\s*)+(<table)/g, '$2');
    // Remove leading <br> tags at the very start
    html = html.replace(/^(<br>\s*)+/, '');
    // Restore code blocks
    html = html.replace(/%%CODE(\d+)%%/g, (_, i) => codeBlocks[+i]);
    return html;
  }

  // ── Typewriter effect ──
  function typewriterEffect(bubble, fullText) {
    const speed = 8;
    const chunkSize = 3;
    let index = 0;
    bubble.classList.add("typing-response");
    bubble.innerHTML = "";

    function tick() {
      index = Math.min(index + chunkSize, fullText.length);
      const visible = fullText.slice(0, index);
      bubble.innerHTML = escapeHtml(visible).replace(/\n/g, "<br>");
      // Keep question visible at top while response grows below it
      scrollToShowQuestion();
      if (index < fullText.length) {
        setTimeout(tick, speed);
      } else {
        bubble.classList.remove("typing-response");
        bubble.innerHTML = renderMarkdown(fullText);
        setTimeout(() => {
          postProcessBotMessage(bubble);
          scrollToShowQuestion();
          const idx = savedMessages.length - 1;
          if (idx >= 0 && savedMessages[idx].sender === 'bot') {
            savedMessages[idx].text = bubble.innerHTML;
            localStorage.setItem('chatMessages', JSON.stringify(savedMessages));
          }
        }, 0);
        scrollToShowQuestion();
      }
    }
    tick();
  }

  function showTyping() {
    const row = document.createElement("div");
    row.className = "msg-row msg-row--bot";
    row.id = "typingIndicator";
    row.innerHTML = `
      <div class="msg-avatar msg-avatar--bot">AI</div>
      <div class="msg-stack">
        <div class="msg-meta">Agentic Colleague</div>
        <div class="msg-bubble msg-bubble--bot">
          <div class="typing-dots"><span></span><span></span><span></span></div>
        </div>
      </div>`;
    chatMessages.appendChild(row);
    scrollToShowQuestion();
  }

  function removeTyping() {
    const t = document.getElementById("typingIndicator");
    if (t) t.remove();
  }
}


// ===================================================================
// SHARED UTILITIES
// ===================================================================
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// Escape a string for use in HTML data-* attributes
// We use base64 encoding to safely handle ALL special characters including quotes, newlines, unicode, etc.
function escapeForDataAttr(text) {
  if (text == null) return '';
  try {
    // Use base64 encoding to handle any character safely
    // btoa only works with Latin1, so we need to encode Unicode first
    return btoa(unescape(encodeURIComponent(String(text))));
  } catch (e) {
    console.error('escapeForDataAttr error:', e);
    return '';
  }
}

// Decode a base64-encoded data attribute back to original string
function decodeDataAttr(str) {
  if (!str) return '';
  try {
    // Reverse the base64 + Unicode encoding
    return decodeURIComponent(escape(atob(str)));
  } catch (e) {
    console.error('decodeDataAttr error:', e);
    // Fallback: return as-is if decoding fails
    return str;
  }
}

// ── IPST function lookup ──
// Tries (in order): exact → strip prefix (Dr./Mr./Ms.) → first-name → partial contains
function lookupIpstFunction(name) {
  if (!name) return '';
  const raw = name.trim();

  // 1. Exact match
  if (IPST_FUNCTION_MAP[raw]) return IPST_FUNCTION_MAP[raw];

  const lower = raw.toLowerCase();

  // 2. Case-insensitive exact
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    if (k.trim().toLowerCase() === lower) return v;
  }

  // 3. Strip honorific prefix (Dr., Mr., Ms., Prof.) and retry
  const stripped = lower.replace(/^(dr\.?|mr\.?|ms\.?|mrs\.?|prof\.?)\s+/i, '').trim();
  if (stripped !== lower) {
    for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
      if (k.trim().toLowerCase() === stripped) return v;
    }
  }

  // 4. First-name match (first word of the cell vs first word of map key)
  const firstName = lower.split(/\s+/)[0];
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    if (k.trim().toLowerCase().split(/\s+/)[0] === firstName) return v;
  }

  // 5. Partial contains — map key appears anywhere inside cell text
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    const kl = k.trim().toLowerCase();
    if (kl.length > 3 && lower.includes(kl)) return v;
  }

  // 6. Cell text appears inside a map key
  for (const [k, v] of Object.entries(IPST_FUNCTION_MAP)) {
    const kl = k.trim().toLowerCase();
    if (lower.length > 3 && kl.includes(lower)) return v;
  }

  return '';
}

// ── Post-process a bot message bubble ──
// 1. Makes task names in assignment tables clickable (→ Kanban highlight)
// 2. Injects a Function column based on IPST_FUNCTION_MAP if not already present
function postProcessBotMessage(bubble) {
  if (!bubble) return;
  // Query all tables — also add md-table class to any that slipped through
  bubble.querySelectorAll('table').forEach(t => t.classList.add('md-table'));
  const tables = bubble.querySelectorAll('table');
  tables.forEach(table => {
    const headerRow = table.querySelector('thead tr');
    if (!headerRow) return;
    const ths = Array.from(headerRow.querySelectorAll('th'));
    const headers = ths.map(th => th.textContent.trim().toLowerCase());

    const nameIdx = headers.findIndex(h => ['name','assignee','assigned to','owner'].includes(h));
    const taskIdx = headers.findIndex(h => ['task','action item','action items','description','item','preparation responsibility','responsibility','work item'].includes(h));
    const funcIdx = headers.findIndex(h => ['function','func','role','ipst function','function / role'].includes(h));

    // ── Scenario 3 MBR prep table — skip task links (preparation responsibility column) ──
    const isMbrPrepTable = headers.includes('preparation responsibility');

    // ── Inject Function column if there's a Name/Assignee col and no Function col ──
    // Also fill in empty/dash cells if Function column already exists
    if (nameIdx !== -1) {
      if (funcIdx === -1) {
        // Column missing — inject it
        const funcTh = document.createElement('th');
        funcTh.textContent = 'Function';
        const insertAfter = ths[nameIdx + 1] || null;
        if (insertAfter) headerRow.insertBefore(funcTh, insertAfter);
        else headerRow.appendChild(funcTh);

        table.querySelectorAll('tbody tr').forEach(row => {
          const cells = row.querySelectorAll('td');
          const nameVal = nameIdx < cells.length ? cells[nameIdx].textContent.trim() : '';
          const fn = lookupIpstFunction(nameVal);
          const funcTd = document.createElement('td');
          funcTd.innerHTML = fn
            ? `<span class="function-badge">${fn}</span>`
            : '<span style="opacity:.4">—</span>';
          const insertAfterTd = cells[nameIdx + 1] || null;
          if (insertAfterTd) row.insertBefore(funcTd, insertAfterTd);
          else row.appendChild(funcTd);
        });
      } else {
        // Column exists — overwrite with badge if we have a lookup result for this name
        // Always overwrite: our map is authoritative regardless of what the LLM put in the cell
        table.querySelectorAll('tbody tr').forEach(row => {
          const cells = row.querySelectorAll('td');
          if (funcIdx >= cells.length) return;
          const nameVal = nameIdx < cells.length ? cells[nameIdx].textContent.trim() : '';
          const fn = lookupIpstFunction(nameVal);
          if (fn) {
            cells[funcIdx].innerHTML = `<span class="function-badge">${fn}</span>`;
          } else {
            // No match — render a muted dash so it looks clean
            const existing = cells[funcIdx].textContent.trim();
            if (!existing || /^[-–—\s]*$/.test(existing)) {
              cells[funcIdx].innerHTML = '<span style="opacity:.4">—</span>';
            }
          }
        });
      }
    }

    // ── Make task name cells clickable links to the Kanban board ──
    if (taskIdx !== -1) {
      // Build correct path to Kanban board (index.html in /static/)
      const kanbanUrl = isInStaticFolder ? 'index.html' : 'static/index.html';
      table.querySelectorAll('tbody tr').forEach(row => {
        const cells = row.querySelectorAll('td');
        if (taskIdx >= cells.length) return;
        const cell = cells[taskIdx];
        
        // Skip if already processed
        if (cell.querySelector('a.chat-task-link')) return;
        
        const taskName = cell.textContent.trim();
        if (!taskName || ['—', '-', '...'].includes(taskName)) return;

        // ── Look up real task data from allTasks for accurate highlight params ──
        let realAssignee = '', realStatus = '';
        if (allTasks && allTasks.length > 0) {
          const tLower = taskName.toLowerCase();
          // Score each task: exact match > contains > word overlap
          let bestMatch = null, bestScore = -1;
          allTasks.forEach(t => {
            const tStr = (t.task || '').toLowerCase();
            let sc = 0;
            if (tStr === tLower) sc = 100;
            else if (tStr.includes(tLower) || tLower.includes(tStr)) sc = 50;
            else {
              const words = tLower.split(/\s+/).filter(w => w.length > 3);
              sc = words.filter(w => tStr.includes(w)).length;
            }
            if (sc > bestScore) { bestScore = sc; bestMatch = t; }
          });
          if (bestMatch && bestScore > 0) {
            realAssignee = bestMatch.assigned_to || '';
            realStatus   = bestMatch.status || '';
          }
        }

        // Fall back to what the table says if lookup found nothing
        if (!realAssignee && nameIdx !== -1 && nameIdx < cells.length)
          realAssignee = cells[nameIdx].textContent.trim();
        if (!realStatus) {
          const statusIdx = Array.from(table.querySelectorAll('thead th')).findIndex(th => ['status','state'].includes(th.textContent.trim().toLowerCase()));
          if (statusIdx !== -1 && statusIdx < cells.length) realStatus = cells[statusIdx].textContent.trim();
        }

        const genericAssignee = ['unassigned','tbd','none','n/a','—','-',''].includes((realAssignee||'').toLowerCase().trim());
        const assigneeParam = (!genericAssignee && realAssignee) ? `&assignee=${encodeURIComponent(realAssignee)}` : '';
        const statusParam   = realStatus ? `&status=${encodeURIComponent(realStatus)}` : '';
        cell.innerHTML =
          `<a class="chat-task-link" href="${kanbanUrl}?highlight=${encodeURIComponent(taskName)}${assigneeParam}${statusParam}" target="_blank" title="Open on Team Board">${taskName} <span class="link-icon">📋</span></a>`;
      });
    }

  });
}


// ===================================================================
// PROJECT ONBOARDING PAGE
// ===================================================================
function initOnboarding() {
  // Initialize project form functionality
  initProjectForm();
  // Initialize project action button handlers (event delegation)
  initProjectActionHandlers();
  // Load existing projects list
  loadProjectsList();
}

// Event delegation for project edit/delete buttons
// This avoids inline onclick handlers which break with special characters
function initProjectActionHandlers() {
  const tableBody = document.getElementById('projectsTableBody');
  if (!tableBody) return;
  
  tableBody.addEventListener('click', function(e) {
    // Find the button that was clicked (or its parent button)
    const editBtn = e.target.closest('.edit-icon');
    const deleteBtn = e.target.closest('.delete-icon');
    
    if (editBtn) {
      e.preventDefault();
      e.stopPropagation();
      const projectId = editBtn.dataset.projectId || '';
      const projectName = editBtn.dataset.projectName || '';
      const projectDescription = editBtn.dataset.projectDescription || '';
      showEditProjectModal(projectId, projectName, projectDescription);
    } else if (deleteBtn) {
      e.preventDefault();
      e.stopPropagation();
      const projectId = deleteBtn.dataset.projectId || '';
      const projectName = deleteBtn.dataset.projectName || '';
      deleteProject(projectId, projectName);
    }
  });
}

// ===================================================================
// PROJECT SEEDING - Form Handling & API Integration
// ===================================================================

// Store selected files for upload
let projectSelectedFiles = [];

function initProjectForm() {
  const form = document.getElementById('projectCreateForm');
  const fileInput = document.getElementById('projectFiles');
  const fileUploadArea = document.getElementById('fileUploadArea');
  
  if (!form) return;
  
  // File input change handler
  if (fileInput) {
    fileInput.addEventListener('change', (e) => {
      handleFileSelection(e.target.files);
    });
  }
  
  // Drag and drop handlers
  if (fileUploadArea) {
    fileUploadArea.addEventListener('dragover', (e) => {
      e.preventDefault();
      fileUploadArea.classList.add('drag-over');
    });
    
    fileUploadArea.addEventListener('dragleave', (e) => {
      e.preventDefault();
      fileUploadArea.classList.remove('drag-over');
    });
    
    fileUploadArea.addEventListener('drop', (e) => {
      e.preventDefault();
      fileUploadArea.classList.remove('drag-over');
      handleFileSelection(e.dataTransfer.files);
    });
  }
}

// Show Create Project Modal
window.showCreateProjectModal = function() {
  const modal = document.getElementById('createProjectModal');
  if (modal) {
    modal.style.display = 'flex';
    // Reset form when opening modal
    resetProjectForm();
    // Initialize file upload area
    initProjectForm();
    // Add escape key listener
    document.addEventListener('keydown', handleCreateModalEscape);
  }
};

// Close Create Project Modal
window.closeCreateProjectModal = function() {
  const modal = document.getElementById('createProjectModal');
  if (modal) {
    modal.style.display = 'none';
    resetProjectForm();
  }
  document.removeEventListener('keydown', handleCreateModalEscape);
};

function handleCreateModalEscape(e) {
  if (e.key === 'Escape') {
    closeCreateProjectModal();
  }
}

// Handle form submission from modal
window.submitProjectCreate = async function(event) {
  event.preventDefault();
  await submitProjectForm();
};

function handleFileSelection(files) {
  for (const file of files) {
    // Check for duplicates
    if (!projectSelectedFiles.some(f => f.name === file.name && f.size === file.size)) {
      projectSelectedFiles.push(file);
    }
  }
  renderSelectedFiles();
}

function renderSelectedFiles() {
  const container = document.getElementById('selectedFilesList');
  if (!container) return;
  
  if (projectSelectedFiles.length === 0) {
    container.innerHTML = '';
    return;
  }
  
  container.innerHTML = projectSelectedFiles.map((file, index) => `
    <div class="selected-file-item">
      <span class="file-name" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</span>
      <span class="file-size">${formatSize(file.size)}</span>
      <button type="button" class="remove-file-btn" onclick="removeProjectFile(${index})" title="Remove file">&times;</button>
    </div>
  `).join('');
}

// Global function to remove a file from selection
window.removeProjectFile = function(index) {
  projectSelectedFiles.splice(index, 1);
  renderSelectedFiles();
};

// Global function to reset the project form
window.resetProjectForm = function() {
  const form = document.getElementById('projectCreateForm');
  if (form) form.reset();
  projectSelectedFiles = [];
  renderSelectedFiles();
  hideFormStatus();
};

function showFormStatus(message, type = 'loading') {
  const statusDiv = document.getElementById('projectFormStatus');
  if (!statusDiv) return;
  
  statusDiv.className = `form-status ${type}`;
  statusDiv.style.display = 'flex';
  
  if (type === 'loading') {
    statusDiv.innerHTML = `<div class="status-spinner"></div><span>${message}</span>`;
  } else {
    const icon = type === 'success' ? '✅' : '❌';
    statusDiv.innerHTML = `<span>${icon}</span><span>${message}</span>`;
  }
}

function hideFormStatus() {
  const statusDiv = document.getElementById('projectFormStatus');
  if (statusDiv) statusDiv.style.display = 'none';
}

async function submitProjectForm() {
  const projectName = document.getElementById('projectName')?.value?.trim();
  const projectDescription = document.getElementById('projectDescription')?.value?.trim();
  const projectStatus = document.getElementById('projectStatus')?.value === 'true';
  const submitBtn = document.getElementById('submitProjectBtn');
  
  // Validation
  if (!projectName) {
    showToast('Please enter a project name', 'error');
    return;
  }
  
  if (!projectDescription) {
    showToast('Please enter a project description', 'error');
    return;
  }
  
  // Disable submit button
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.querySelector('.btn-text').textContent = 'Creating...';
  }
  
  showFormStatus('Creating project...', 'loading');
  
  try {
    // Prepare files data (convert to base64)
    const filesData = [];
    for (const file of projectSelectedFiles) {
      const base64Content = await fileToBase64(file);
      const fileExt = file.name.split('.').pop().toLowerCase();
      filesData.push({
        file_name: file.name,
        file_type: fileExt,
        file_content: base64Content
      });
    }
    
    // Prepare request body
    const requestBody = {
      project_name: projectName,
      project_description: projectDescription,
      is_active: projectStatus
    };
    
    // Add files if any
    if (filesData.length > 0) {
      requestBody.files = filesData;
    }
    
    // Submit to API (use API_BASE for correct path resolution)
    const response = await fetch(API_BASE + 'projects', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }
    
    const result = await response.json();
    
    // Success
    showFormStatus(`Project "${projectName}" created successfully!`, 'success');
    showToast(`✅ Project "${projectName}" created successfully!`, 'success');
    
    // Close modal and refresh list after success
    setTimeout(() => {
      closeCreateProjectModal();
      loadProjectsList(); // Refresh the projects list
    }, 1500);
    
  } catch (error) {
    console.error('Error creating project:', error);
    showFormStatus(`Failed to create project: ${error.message}`, 'error');
    showToast('❌ Failed to create project — see details below', 'error');
  } finally {
    // Re-enable submit button
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.querySelector('.btn-text').textContent = 'Create Project';
    }
  }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      // Remove data URL prefix to get just base64
      const base64 = reader.result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ===================================================================
// PROJECTS LISTING - Load and Display Existing Projects
// ===================================================================

async function loadProjectsList() {
  const tableContainer = document.getElementById('projectsTableContainer');
  const tableLoading = document.getElementById('tableLoading');
  const projectsTable = document.getElementById('projectsTable');
  const tableEmpty = document.getElementById('tableEmpty');
  const tableBody = document.getElementById('projectsTableBody');
  
  if (!tableContainer) return;
  
  // Show loading state
  if (tableLoading) tableLoading.style.display = 'flex';
  if (projectsTable) projectsTable.style.display = 'none';
  if (tableEmpty) tableEmpty.style.display = 'none';
  
  try {
    // Use API_BASE for correct path resolution
    const response = await fetch(API_BASE + 'projects?limit=10', {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`Server returned ${response.status}`);
    }
    
    const data = await response.json();
    const projects = data.projects || data || [];
    
    // Hide loading
    if (tableLoading) tableLoading.style.display = 'none';
    
    if (projects.length === 0) {
      // Show empty state
      if (tableEmpty) tableEmpty.style.display = 'flex';
      return;
    }
    
    // Render table rows with toggle, edit, and delete actions
    if (tableBody) {
      tableBody.innerHTML = projects.map(project => {
        // Check status field (string: "Active"/"Inactive") or fall back to is_active boolean
        const statusStr = (project.status || '').toLowerCase();
        const isActive = statusStr === 'active' || (statusStr === '' && project.is_active !== false);
        const filesCount = project.files?.length || 0;
        const createdDate = project.created_at 
          ? new Date(project.created_at).toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'short', 
              day: 'numeric' 
            })
          : '—';
        const description = project.project_description || '—';
        const truncatedDesc = description.length > 80 
          ? description.substring(0, 80) + '...' 
          : description;
        const projectId = project.project_id || '';
        const projectName = project.project_name || 'Unnamed';
        
        return `
          <tr data-project-id="${escapeHtml(projectId)}">
            <td class="project-name">${escapeHtml(projectName)}</td>
            <td class="project-desc" title="${escapeHtml(description)}">${escapeHtml(truncatedDesc)}</td>
            <td class="status-cell">
              <label class="status-toggle" title="Toggle active status">
                <input type="checkbox" ${isActive ? 'checked' : ''} onchange="toggleProjectStatus('${escapeHtml(projectId)}', this.checked)" />
                <span class="toggle-slider"></span>
                <span class="toggle-label">${isActive ? 'Active' : 'Inactive'}</span>
              </label>
            </td>
            <td class="files-count">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/>
                <polyline points="13 2 13 9 20 9"/>
              </svg>
              ${filesCount}
            </td>
            <td class="created-date">${createdDate}</td>
            <td class="actions-cell">
              <div class="action-icons">
                <button class="action-icon edit-icon" data-project-id="${escapeHtml(projectId)}" data-project-name="${escapeForDataAttr(projectName)}" data-project-description="${escapeForDataAttr(description)}" title="Edit project">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                  </svg>
                </button>
                <button class="action-icon delete-icon" data-project-id="${escapeHtml(projectId)}" data-project-name="${escapeForDataAttr(projectName)}" title="Delete project">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                    <line x1="10" y1="11" x2="10" y2="17"/>
                    <line x1="14" y1="11" x2="14" y2="17"/>
                  </svg>
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }
    
    // Show table
    if (projectsTable) projectsTable.style.display = 'table';
    
  } catch (error) {
    console.error('Error loading projects:', error);
    
    // Hide loading
    if (tableLoading) tableLoading.style.display = 'none';
    
    // Show error in table container
    if (tableContainer) {
      tableContainer.innerHTML = `
        <div class="table-empty" style="display: flex;">
          <p style="color: #ff5050;">Failed to load projects: ${escapeHtml(error.message)}</p>
          <button class="btn-secondary" onclick="loadProjectsList()" style="margin-top: 12px;">Retry</button>
        </div>
      `;
    }
    
    showToast('❌ Failed to load projects list', 'error');
  }
}

// Make loadProjectsList available globally for onclick handlers
window.loadProjectsList = loadProjectsList;

// ===================================================================
// PROJECT STATUS TOGGLE - Update active/inactive status
// ===================================================================

async function toggleProjectStatus(projectId, isActive) {
  const status = isActive ? 'Active' : 'Inactive';
  
  // Find the toggle label and update it immediately for responsiveness
  const row = document.querySelector(`tr[data-project-id="${projectId}"]`);
  const toggleLabel = row?.querySelector('.toggle-label');
  if (toggleLabel) {
    toggleLabel.textContent = isActive ? 'Active' : 'Inactive';
  }
  
  try {
    const response = await fetch(API_BASE + `projects/${encodeURIComponent(projectId)}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ status: status })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }
    
    showToast(`✅ Project status updated to ${status}`, 'success');
    
  } catch (error) {
    console.error('Error updating project status:', error);
    showToast(`❌ Failed to update status: ${error.message}`, 'error');
    
    // Revert the toggle on error
    const checkbox = row?.querySelector('input[type="checkbox"]');
    if (checkbox) {
      checkbox.checked = !isActive;
    }
    if (toggleLabel) {
      toggleLabel.textContent = !isActive ? 'Active' : 'Inactive';
    }
  }
}

// Make toggleProjectStatus available globally
window.toggleProjectStatus = toggleProjectStatus;

// ===================================================================
// EDIT PROJECT MODAL - Show popup to edit project details
// ===================================================================

function showEditProjectModal(projectId, projectName, projectDescription) {
  const modal = document.getElementById('editProjectModal');
  const editProjectId = document.getElementById('editProjectId');
  const editProjectName = document.getElementById('editProjectName');
  const editProjectDescription = document.getElementById('editProjectDescription');
  
  if (!modal) return;
  
  // Populate form fields - use global decodeDataAttr to decode base64-encoded values
  if (editProjectId) editProjectId.value = projectId;
  if (editProjectName) editProjectName.value = decodeDataAttr(projectName);
  if (editProjectDescription) {
    editProjectDescription.value = decodeDataAttr(projectDescription);
  }
  
  // Show modal
  modal.style.display = 'flex';
  
  // Focus on name field
  setTimeout(() => editProjectName?.focus(), 100);
  
  // Add escape key listener
  document.addEventListener('keydown', handleEditModalEscape);
}

function closeEditProjectModal() {
  const modal = document.getElementById('editProjectModal');
  if (modal) {
    modal.style.display = 'none';
  }
  document.removeEventListener('keydown', handleEditModalEscape);
}

function handleEditModalEscape(e) {
  if (e.key === 'Escape') {
    closeEditProjectModal();
  }
}

async function submitProjectUpdate(event) {
  event.preventDefault();
  
  const projectId = document.getElementById('editProjectId')?.value;
  const projectName = document.getElementById('editProjectName')?.value?.trim();
  const projectDescription = document.getElementById('editProjectDescription')?.value?.trim();
  const updateBtn = document.getElementById('updateProjectBtn');
  
  // Validation
  if (!projectId) {
    showToast('Project ID is missing', 'error');
    return;
  }
  
  if (!projectName) {
    showToast('Please enter a project name', 'error');
    return;
  }
  
  if (!projectDescription) {
    showToast('Please enter a project description', 'error');
    return;
  }
  
  // Disable button
  if (updateBtn) {
    updateBtn.disabled = true;
    updateBtn.querySelector('.btn-text').textContent = 'Updating...';
  }
  
  try {
    const response = await fetch(API_BASE + `projects/${encodeURIComponent(projectId)}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        project_name: projectName,
        project_description: projectDescription
      })
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }
    
    showToast(`✅ Project "${projectName}" updated successfully!`, 'success');
    
    // Close modal and refresh list
    closeEditProjectModal();
    loadProjectsList();
    
  } catch (error) {
    console.error('Error updating project:', error);
    showToast(`❌ Failed to update project: ${error.message}`, 'error');
  } finally {
    // Re-enable button
    if (updateBtn) {
      updateBtn.disabled = false;
      updateBtn.querySelector('.btn-text').textContent = 'Update Project';
    }
  }
}

// Make modal functions available globally
window.showEditProjectModal = showEditProjectModal;
window.closeEditProjectModal = closeEditProjectModal;
window.submitProjectUpdate = submitProjectUpdate;

// ===================================================================
// DELETE PROJECT - Delete with confirmation
// ===================================================================

async function deleteProject(projectId, projectNameEncoded) {
  // Decode the project name using global decodeDataAttr (base64)
  const projectName = decodeDataAttr(projectNameEncoded);
  
  // Show confirmation dialog
  const confirmed = confirm(`Are you sure you want to delete the project "${projectName}"?\n\nThis action cannot be undone and will permanently delete the project and all its files.`);
  
  if (!confirmed) return;
  
  // Find the row and add a visual indicator
  const row = document.querySelector(`tr[data-project-id="${projectId}"]`);
  if (row) {
    row.style.opacity = '0.5';
    row.style.pointerEvents = 'none';
  }
  
  try {
    const response = await fetch(API_BASE + `projects/${encodeURIComponent(projectId)}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json'
      }
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }
    
    showToast(`🗑️ Project "${projectName}" deleted successfully`, 'success');
    
    // Animate row removal
    if (row) {
      row.style.transition = 'opacity 0.3s, transform 0.3s';
      row.style.transform = 'translateX(-20px)';
      setTimeout(() => {
        row.remove();
        // Check if table is now empty
        const tableBody = document.getElementById('projectsTableBody');
        if (tableBody && tableBody.children.length === 0) {
          document.getElementById('projectsTable').style.display = 'none';
          document.getElementById('tableEmpty').style.display = 'flex';
        }
      }, 300);
    }
    
  } catch (error) {
    console.error('Error deleting project:', error);
    showToast(`❌ Failed to delete project: ${error.message}`, 'error');
    
    // Restore row on error
    if (row) {
      row.style.opacity = '1';
      row.style.pointerEvents = 'auto';
    }
  }
}

// Make deleteProject available globally
window.deleteProject = deleteProject;

// ===================================================================
// UNIFIED PIPELINE - Runs Transcript then Ingestion sequentially
// ===================================================================
async function triggerUnifiedPipeline() {
  const triggerBtn = document.getElementById('triggerUnifiedBtn');
  const statusDiv = document.getElementById('unifiedStatus');
  const statusText = document.getElementById('unifiedStatusText');
  const resultsDiv = document.getElementById('unifiedResults');
  
  // Get options
  const transcriptMode = document.getElementById('transcriptMode')?.value ?? 'incremental';
  const retryFailed = document.getElementById('transcriptRetryFailed')?.checked ?? true;
  const skipExisting = document.getElementById('skipExisting')?.checked ?? true;
  const dryRun = document.getElementById('dryRun')?.checked ?? false;

  // Step elements
  const step1 = document.getElementById('step1');
  const step2 = document.getElementById('step2');
  const step1Status = document.getElementById('step1Status');
  const step2Status = document.getElementById('step2Status');
  const connector = document.querySelector('.pipeline-connector');

  // Reset step states
  step1.className = 'pipeline-step';
  step2.className = 'pipeline-step';
  step1Status.textContent = '';
  step2Status.textContent = '';
  connector.className = 'pipeline-connector';

  // Disable button and show processing status
  triggerBtn.disabled = true;
  triggerBtn.querySelector('.btn-text').textContent = 'Running Pipeline...';
  statusDiv.style.display = 'flex';
  resultsDiv.style.display = 'none';

  let transcriptResult = null;
  let ingestionResult = null;

  // ─────────────────────────────────────────────────────────────────
  // STEP 1: Transcript Pipeline
  // ─────────────────────────────────────────────────────────────────
  try {
    step1.classList.add('active');
    statusText.textContent = 'Step 1/2: Fetching Teams transcripts...';
    showToast('📄 Step 1: Starting transcript pipeline...', 'info', 4000);

    const transcriptResponse = await fetch(API_BASE + 'transcript/run', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        mode: transcriptMode,
        retry_failed: retryFailed
      })
    });

    if (!transcriptResponse.ok) {
      const errorText = await transcriptResponse.text();
      throw new Error(`Transcript pipeline failed: ${transcriptResponse.status} - ${errorText}`);
    }

    transcriptResult = await transcriptResponse.json();
    
    // Mark step 1 as completed
    step1.classList.remove('active');
    step1.classList.add('completed');
    step1Status.textContent = '✅';
    connector.classList.add('active');
    
    showToast(`✅ Step 1 complete: ${transcriptResult.processed ?? 0} transcripts processed`, 'success', 4000);

  } catch (error) {
    console.error('Transcript pipeline error:', error);
    
    // Mark step 1 as failed
    step1.classList.remove('active');
    step1.classList.add('failed');
    step1Status.textContent = '❌';
    
    // Show error and stop
    statusDiv.style.display = 'none';
    resultsDiv.className = 'pipeline-results error';
    resultsDiv.style.display = 'block';
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">❌</span> Pipeline Failed at Step 1: Transcript Pipeline</h5>
      <p class="error-message">${escapeHtml(error.message)}</p>
      <p style="margin-top: 12px; font-size: 13px; color: var(--text-muted);">
        Step 2 (Data Ingestion) was not executed because Step 1 failed.
      </p>
    `;
    
    showToast('❌ Pipeline failed at Step 1 — see details below', 'error', 6000);
    
    // Re-enable button
    triggerBtn.disabled = false;
    triggerBtn.querySelector('.btn-text').textContent = 'Run Pipeline';
    return;
  }

  // ─────────────────────────────────────────────────────────────────
  // STEP 2: Data Ingestion Pipeline (Transcript Batch)
  // ─────────────────────────────────────────────────────────────────
  try {
    step2.classList.add('active');
    statusText.textContent = 'Step 2/2: Processing and indexing documents...';
    showToast('🚀 Step 2: Starting transcript batch ingestion pipeline...', 'info', 4000);

    const ingestionResponse = await fetch(API_BASE + 'batch/transcript/run', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        dry_run: dryRun,
        verbose: false,
        skip_existing: skipExisting
      })
    });

    if (!ingestionResponse.ok) {
      const errorText = await ingestionResponse.text();
      throw new Error(`Data ingestion failed: ${ingestionResponse.status} - ${errorText}`);
    }

    ingestionResult = await ingestionResponse.json();
    
    // Mark step 2 as completed
    step2.classList.remove('active');
    step2.classList.add('completed');
    step2Status.textContent = '✅';
    
    showToast(`✅ Step 2 complete: ${ingestionResult.statistics?.files_processed ?? 0} files indexed`, 'success', 4000);

  } catch (error) {
    console.error('Ingestion pipeline error:', error);
    
    // Mark step 2 as failed
    step2.classList.remove('active');
    step2.classList.add('failed');
    step2Status.textContent = '❌';
    
    // Show partial success
    statusDiv.style.display = 'none';
    resultsDiv.className = 'pipeline-results error';
    resultsDiv.style.display = 'block';
    
    const tStats = transcriptResult || {};
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">⚠️</span> Pipeline Partially Complete</h5>
      <p style="margin-bottom: 16px; color: var(--text-secondary);">Step 1 succeeded but Step 2 failed.</p>
      
      <div style="margin-bottom: 16px;">
        <strong style="color: #50c878;">✅ Step 1: Transcript Pipeline (Success)</strong>
        <div class="result-stats" style="margin-top: 8px;">
          <div class="stat-item">
            <div class="stat-label">Meetings</div>
            <div class="stat-value">${tStats.total_meetings ?? 0}</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Processed</div>
            <div class="stat-value">${tStats.processed ?? 0}</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Mode</div>
            <div class="stat-value">${tStats.mode ?? transcriptMode}</div>
          </div>
        </div>
      </div>
      
      <div>
        <strong style="color: #ff5050;">❌ Step 2: Data Ingestion (Failed)</strong>
        <p class="error-message" style="margin-top: 8px;">${escapeHtml(error.message)}</p>
      </div>
    `;
    
    showToast('⚠️ Pipeline partially complete — Step 2 failed', 'warning', 6000);
    
    // Re-enable button
    triggerBtn.disabled = false;
    triggerBtn.querySelector('.btn-text').textContent = 'Run Pipeline';
    return;
  }

  // ─────────────────────────────────────────────────────────────────
  // SUCCESS: Both pipelines completed
  // ─────────────────────────────────────────────────────────────────
  statusDiv.style.display = 'none';
  resultsDiv.className = 'pipeline-results';
  resultsDiv.style.display = 'block';
  
  const tStats = transcriptResult || {};
  const iStats = ingestionResult?.statistics || {};
  
  resultsDiv.innerHTML = `
    <h5><span class="result-icon">🎉</span> Complete Pipeline Finished Successfully!</h5>
    
    <div style="margin-bottom: 20px;">
      <strong style="color: #50c878; font-size: 13px;">✅ Step 1: Transcript Pipeline</strong>
      <div class="result-stats" style="margin-top: 8px;">
        <div class="stat-item">
          <div class="stat-label">Meetings Found</div>
          <div class="stat-value">${tStats.total_meetings ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Transcripts</div>
          <div class="stat-value">${tStats.total_transcripts ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Processed</div>
          <div class="stat-value">${tStats.processed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Skipped</div>
          <div class="stat-value">${tStats.skipped ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Success Rate</div>
          <div class="stat-value">${(tStats.success_rate ?? 0).toFixed(1)}%</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Duration</div>
          <div class="stat-value">${(tStats.duration_seconds ?? 0).toFixed(1)}s</div>
        </div>
      </div>
    </div>
    
    <div>
      <strong style="color: #50c878; font-size: 13px;">✅ Step 2: Data Ingestion Pipeline</strong>
      <div class="result-stats" style="margin-top: 8px;">
        <div class="stat-item">
          <div class="stat-label">Files Processed</div>
          <div class="stat-value">${iStats.files_processed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Files Skipped</div>
          <div class="stat-value">${iStats.files_skipped ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">OpenSearch Indexed</div>
          <div class="stat-value">${iStats.opensearch_indexed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">DynamoDB Writes</div>
          <div class="stat-value">${iStats.dynamodb_written ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Errors</div>
          <div class="stat-value">${iStats.errors ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Mode</div>
          <div class="stat-value">${ingestionResult?.dry_run ? 'Dry Run' : 'Live'}</div>
        </div>
      </div>
    </div>
  `;
  
  showToast('🎉 Complete pipeline finished successfully!', 'success', 6000);
  
  // Re-enable button
  triggerBtn.disabled = false;
  triggerBtn.querySelector('.btn-text').textContent = 'Run Pipeline';
}

// ===================================================================
// CHAT PIPELINE - Runs Chat Extraction then Ingestion sequentially
// ===================================================================
async function triggerChatPipeline() {
  const triggerBtn = document.getElementById('triggerChatPipelineBtn');
  const statusDiv = document.getElementById('chatPipelineStatus');
  const statusText = document.getElementById('chatPipelineStatusText');
  const resultsDiv = document.getElementById('chatPipelineResults');
  
  // Get options
  const chatMode = document.getElementById('chatMode')?.value ?? 'incremental';
  const retryFailed = document.getElementById('chatRetryFailed')?.checked ?? true;
  const skipExisting = document.getElementById('chatSkipExisting')?.checked ?? true;
  const dryRun = document.getElementById('chatDryRun')?.checked ?? false;

  // Step elements for Chat Pipeline
  const step1 = document.getElementById('chatStep1');
  const step2 = document.getElementById('chatStep2');
  const step1Status = document.getElementById('chatStep1Status');
  const step2Status = document.getElementById('chatStep2Status');
  const connector = document.querySelector('.chat-connector');

  // Reset step states
  step1.className = 'pipeline-step';
  step2.className = 'pipeline-step';
  step1Status.textContent = '';
  step2Status.textContent = '';
  if (connector) connector.className = 'pipeline-connector chat-connector';

  // Disable button and show processing status
  triggerBtn.disabled = true;
  triggerBtn.querySelector('.btn-text').textContent = 'Running Pipeline...';
  statusDiv.style.display = 'flex';
  resultsDiv.style.display = 'none';

  let chatResult = null;
  let ingestionResult = null;

  // ─────────────────────────────────────────────────────────────────
  // STEP 1: Chat Pipeline (Extract meeting chats)
  // ─────────────────────────────────────────────────────────────────
  try {
    step1.classList.add('active');
    statusText.textContent = 'Step 1/2: Fetching Teams meeting chats...';
    showToast('💬 Step 1: Starting chat extraction pipeline...', 'info', 4000);

    const chatResponse = await fetch(API_BASE + 'chat/run', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        mode: chatMode,
        retry_failed: retryFailed
      })
    });

    if (!chatResponse.ok) {
      const errorText = await chatResponse.text();
      throw new Error(`Chat pipeline failed: ${chatResponse.status} - ${errorText}`);
    }

    chatResult = await chatResponse.json();
    
    // Mark step 1 as completed
    step1.classList.remove('active');
    step1.classList.add('completed');
    step1Status.textContent = '✅';
    if (connector) connector.classList.add('active');
    
    showToast(`✅ Step 1 complete: ${chatResult.processed ?? 0} chats processed`, 'success', 4000);

  } catch (error) {
    console.error('Chat extraction pipeline error:', error);
    
    // Mark step 1 as failed
    step1.classList.remove('active');
    step1.classList.add('failed');
    step1Status.textContent = '❌';
    
    // Show error and stop
    statusDiv.style.display = 'none';
    resultsDiv.className = 'pipeline-results compact-results error';
    resultsDiv.style.display = 'block';
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">❌</span> Pipeline Failed at Step 1: Chat Extraction</h5>
      <p class="error-message">${escapeHtml(error.message)}</p>
      <p style="margin-top: 12px; font-size: 13px; color: var(--text-muted);">
        Step 2 (Chat Ingestion) was not executed because Step 1 failed.
      </p>
    `;
    
    showToast('❌ Chat pipeline failed at Step 1 — see details below', 'error', 6000);
    
    // Re-enable button
    triggerBtn.disabled = false;
    triggerBtn.querySelector('.btn-text').textContent = 'Run Pipeline';
    return;
  }

  // ─────────────────────────────────────────────────────────────────
  // STEP 2: Chat Ingestion Pipeline (Index to OpenSearch)
  // ─────────────────────────────────────────────────────────────────
  try {
    step2.classList.add('active');
    statusText.textContent = 'Step 2/2: Processing and indexing chat documents...';
    showToast('🚀 Step 2: Starting chat batch ingestion pipeline...', 'info', 4000);

    const ingestionResponse = await fetch(API_BASE + 'batch/chat/run', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        dry_run: dryRun,
        verbose: false,
        skip_existing: skipExisting
      })
    });

    if (!ingestionResponse.ok) {
      const errorText = await ingestionResponse.text();
      throw new Error(`Chat ingestion failed: ${ingestionResponse.status} - ${errorText}`);
    }

    ingestionResult = await ingestionResponse.json();
    
    // Mark step 2 as completed
    step2.classList.remove('active');
    step2.classList.add('completed');
    step2Status.textContent = '✅';
    
    showToast(`✅ Step 2 complete: ${ingestionResult.statistics?.files_processed ?? 0} files indexed`, 'success', 4000);

  } catch (error) {
    console.error('Chat ingestion pipeline error:', error);
    
    // Mark step 2 as failed
    step2.classList.remove('active');
    step2.classList.add('failed');
    step2Status.textContent = '❌';
    
    // Show partial success
    statusDiv.style.display = 'none';
    resultsDiv.className = 'pipeline-results compact-results error';
    resultsDiv.style.display = 'block';
    
    const cStats = chatResult || {};
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">⚠️</span> Pipeline Partially Complete</h5>
      <p style="margin-bottom: 16px; color: var(--text-secondary);">Step 1 succeeded but Step 2 failed.</p>
      
      <div style="margin-bottom: 16px;">
        <strong style="color: #50c878;">✅ Step 1: Chat Extraction (Success)</strong>
        <div class="result-stats" style="margin-top: 8px;">
          <div class="stat-item">
            <div class="stat-label">Meetings</div>
            <div class="stat-value">${cStats.total_meetings ?? 0}</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Messages</div>
            <div class="stat-value">${cStats.total_messages ?? 0}</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Processed</div>
            <div class="stat-value">${cStats.processed ?? 0}</div>
          </div>
          <div class="stat-item">
            <div class="stat-label">Mode</div>
            <div class="stat-value">${cStats.mode ?? chatMode}</div>
          </div>
        </div>
      </div>
      
      <div>
        <strong style="color: #ff5050;">❌ Step 2: Chat Ingestion (Failed)</strong>
        <p class="error-message" style="margin-top: 8px;">${escapeHtml(error.message)}</p>
      </div>
    `;
    
    showToast('⚠️ Chat pipeline partially complete — Step 2 failed', 'warning', 6000);
    
    // Re-enable button
    triggerBtn.disabled = false;
    triggerBtn.querySelector('.btn-text').textContent = 'Run Pipeline';
    return;
  }

  // ─────────────────────────────────────────────────────────────────
  // SUCCESS: Both pipelines completed
  // ─────────────────────────────────────────────────────────────────
  statusDiv.style.display = 'none';
  resultsDiv.className = 'pipeline-results compact-results';
  resultsDiv.style.display = 'block';
  
  const cStats = chatResult || {};
  const iStats = ingestionResult?.statistics || {};
  
  resultsDiv.innerHTML = `
    <h5><span class="result-icon">🎉</span> Chat Pipeline Finished Successfully!</h5>
    
    <div style="margin-bottom: 20px;">
      <strong style="color: #50c878; font-size: 13px;">✅ Step 1: Chat Extraction</strong>
      <div class="result-stats" style="margin-top: 8px;">
        <div class="stat-item">
          <div class="stat-label">Meetings Found</div>
          <div class="stat-value">${cStats.total_meetings ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Total Messages</div>
          <div class="stat-value">${cStats.total_messages ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Processed</div>
          <div class="stat-value">${cStats.processed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Skipped</div>
          <div class="stat-value">${cStats.skipped ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Success Rate</div>
          <div class="stat-value">${(cStats.success_rate ?? 0).toFixed(1)}%</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Duration</div>
          <div class="stat-value">${(cStats.duration_seconds ?? 0).toFixed(1)}s</div>
        </div>
      </div>
    </div>
    
    <div>
      <strong style="color: #50c878; font-size: 13px;">✅ Step 2: Chat Ingestion</strong>
      <div class="result-stats" style="margin-top: 8px;">
        <div class="stat-item">
          <div class="stat-label">Files Processed</div>
          <div class="stat-value">${iStats.files_processed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Files Skipped</div>
          <div class="stat-value">${iStats.files_skipped ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">OpenSearch Indexed</div>
          <div class="stat-value">${iStats.opensearch_indexed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">DynamoDB Writes</div>
          <div class="stat-value">${iStats.dynamodb_written ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Errors</div>
          <div class="stat-value">${iStats.errors ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Mode</div>
          <div class="stat-value">${ingestionResult?.dry_run ? 'Dry Run' : 'Live'}</div>
        </div>
      </div>
    </div>
  `;
  
  showToast('🎉 Chat pipeline finished successfully!', 'success', 6000);
  
  // Re-enable button
  triggerBtn.disabled = false;
  triggerBtn.querySelector('.btn-text').textContent = 'Run Pipeline';
}

// Make triggerChatPipeline available globally
window.triggerChatPipeline = triggerChatPipeline;

// Legacy functions kept for backward compatibility (v1 backup)
async function triggerIngestionPipeline() {
  const triggerBtn = document.getElementById('triggerPipelineBtn');
  const statusDiv = document.getElementById('pipelineStatus');
  const resultsDiv = document.getElementById('pipelineResults');
  const skipExisting = document.getElementById('skipExisting')?.checked ?? true;
  const dryRun = document.getElementById('dryRun')?.checked ?? false;

  // Disable button and show processing status
  triggerBtn.disabled = true;
  triggerBtn.querySelector('.btn-text').textContent = 'Processing...';
  statusDiv.style.display = 'flex';
  resultsDiv.style.display = 'none';

  // Show immediate toast that pipeline was triggered
  showToast('🚀 Data ingestion pipeline triggered! Processing...', 'info', 5000);

  try {
    // Use API_BASE for correct path resolution
    const response = await fetch(API_BASE + 'batch/transcript/run', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        dry_run: dryRun,
        verbose: false,
        skip_existing: skipExisting
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    // Hide status spinner
    statusDiv.style.display = 'none';

    // Show success results
    resultsDiv.className = 'pipeline-results';
    resultsDiv.style.display = 'block';
    
    const stats = data.statistics || {};
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">✅</span> Pipeline Completed Successfully</h5>
      <div class="result-stats">
        <div class="stat-item">
          <div class="stat-label">Files Processed</div>
          <div class="stat-value">${stats.files_processed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Files Skipped</div>
          <div class="stat-value">${stats.files_skipped ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">OpenSearch Indexed</div>
          <div class="stat-value">${stats.opensearch_indexed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">DynamoDB Writes</div>
          <div class="stat-value">${stats.dynamodb_written ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Errors</div>
          <div class="stat-value">${stats.errors ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Mode</div>
          <div class="stat-value">${data.dry_run ? 'Dry Run' : 'Live'}</div>
        </div>
      </div>
    `;

    // Show success toast
    showToast(`✅ Pipeline completed! ${stats.files_processed ?? 0} files processed.`, 'success', 6000);

  } catch (error) {
    console.error('Pipeline error:', error);
    
    // Hide status spinner
    statusDiv.style.display = 'none';

    // Show error results
    resultsDiv.className = 'pipeline-results error';
    resultsDiv.style.display = 'block';
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">❌</span> Pipeline Failed</h5>
      <p class="error-message">${escapeHtml(error.message)}</p>
    `;

    // Show error toast
    showToast('❌ Pipeline failed — see details below', 'error', 6000);
  } finally {
    // Re-enable button
    triggerBtn.disabled = false;
    triggerBtn.querySelector('.btn-text').textContent = 'Trigger Pipeline';
  }
}

// Global function for triggering the transcript pipeline (called from onclick in HTML)
async function triggerTranscriptPipeline() {
  const triggerBtn = document.getElementById('triggerTranscriptBtn');
  const statusDiv = document.getElementById('transcriptStatus');
  const resultsDiv = document.getElementById('transcriptResults');
  const mode = document.getElementById('transcriptMode')?.value ?? 'incremental';
  const retryFailed = document.getElementById('transcriptRetryFailed')?.checked ?? true;

  // Disable button and show processing status
  triggerBtn.disabled = true;
  triggerBtn.querySelector('.btn-text').textContent = 'Processing...';
  statusDiv.style.display = 'flex';
  resultsDiv.style.display = 'none';

  // Show immediate toast that pipeline was triggered
  showToast('📄 Transcript pipeline triggered! Fetching meetings...', 'info', 5000);

  try {
    // Use API_BASE for correct path resolution
    const response = await fetch(API_BASE + 'transcript/run', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        mode: mode,
        retry_failed: retryFailed
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    // Hide status spinner
    statusDiv.style.display = 'none';

    // Show success results
    resultsDiv.className = 'pipeline-results';
    resultsDiv.style.display = 'block';
    
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">✅</span> Transcript Pipeline Completed</h5>
      <div class="result-stats">
        <div class="stat-item">
          <div class="stat-label">Meetings Found</div>
          <div class="stat-value">${data.total_meetings ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Transcripts</div>
          <div class="stat-value">${data.total_transcripts ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Processed</div>
          <div class="stat-value">${data.processed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Skipped</div>
          <div class="stat-value">${data.skipped ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Failed</div>
          <div class="stat-value">${data.failed ?? 0}</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Success Rate</div>
          <div class="stat-value">${(data.success_rate ?? 0).toFixed(1)}%</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Duration</div>
          <div class="stat-value">${(data.duration_seconds ?? 0).toFixed(1)}s</div>
        </div>
        <div class="stat-item">
          <div class="stat-label">Mode</div>
          <div class="stat-value">${data.mode ?? mode}</div>
        </div>
      </div>
    `;

    // Show success toast
    showToast(`✅ Transcript pipeline completed! ${data.processed ?? 0} transcripts processed.`, 'success', 6000);

  } catch (error) {
    console.error('Transcript pipeline error:', error);
    
    // Hide status spinner
    statusDiv.style.display = 'none';

    // Show error results
    resultsDiv.className = 'pipeline-results error';
    resultsDiv.style.display = 'block';
    resultsDiv.innerHTML = `
      <h5><span class="result-icon">❌</span> Transcript Pipeline Failed</h5>
      <p class="error-message">${escapeHtml(error.message)}</p>
    `;

    // Show error toast
    showToast('❌ Transcript pipeline failed — see details below', 'error', 6000);
  } finally {
    // Re-enable button
    triggerBtn.disabled = false;
    triggerBtn.querySelector('.btn-text').textContent = 'Trigger Pipeline';
  }
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1048576).toFixed(1) + " MB";
}

// ── Toast Notification System ──
function showToast(message, type = 'success', duration = 4000) {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span class="toast-msg">${message}</span>`;
  container.appendChild(toast);
  // Trigger enter animation
  requestAnimationFrame(() => toast.classList.add('toast--visible'));
  setTimeout(() => {
    toast.classList.remove('toast--visible');
    toast.classList.add('toast--exit');
    setTimeout(() => toast.remove(), 350);
  }, duration);
}

// ── Theme Swatch Picker (4 themes) ──
(function initTheme() {
  const saved = localStorage.getItem('theme') || 'dark';
  applyTheme(saved);

  document.addEventListener('click', e => {
    const swatch = e.target.closest('.theme-swatch');
    if (!swatch) return;
    const theme = swatch.dataset.theme;
    if (theme) applyTheme(theme);
  });

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    document.querySelectorAll('.theme-swatch').forEach(s => {
      s.classList.toggle('active', s.dataset.theme === theme);
    });
  }
})();
