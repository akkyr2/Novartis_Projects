"""
Transcript Pipeline Module
==========================
Data ingestion pipeline for meeting transcript files.

This module provides:
- Transcript ingestion (S3 -> OpenSearch + DynamoDB)
- Verification scripts
- Cleanup utilities

Usage:
    # Run ingestion
    python -m batch_data_ingestion.transcript.ingestion
    
    # Verify data
    python -m batch_data_ingestion.transcript.verify
    
    # Cleanup
    python -m batch_data_ingestion.transcript.cleanup --dry-run
"""

from .ingestion import process_transcript_folder

__all__ = [
    "process_transcript_folder",
]
