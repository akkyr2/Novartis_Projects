"""
Batch Data Ingestion Package
============================
This package contains scripts for batch processing of S3 files into the Agentic Colleague
vector database (OpenSearch) and structured storage (DynamoDB).

The package now supports two separate pipelines:
- **Transcript Pipeline**: Processes meeting transcripts from S3 meetings/transcripts/
- **Chat Pipeline**: Processes meeting chats from S3 meetings/chats/

Package Structure:
    batch_data_ingestion/
    ├── core/                 # Shared utilities
    │   ├── aws_clients.py    # AWS client initialization
    │   ├── config.py         # Configuration constants
    │   ├── text_extraction.py # Text extraction (DOCX, TXT, EML)
    │   ├── llm_processing.py  # LLM cleaning and embedding
    │   ├── project_matching.py # Project matching logic
    │   ├── opensearch_utils.py # OpenSearch indexing
    │   ├── dynamodb_utils.py   # DynamoDB writes
    │   ├── s3_utils.py         # S3 file listing
    │   └── helpers.py          # Common helpers
    ├── transcript/           # Transcript pipeline
    │   ├── ingestion.py      # Main ingestion script
    │   ├── verify.py         # Verification script
    │   └── cleanup.py        # Cleanup script
    ├── chat/                 # Chat pipeline
    │   ├── ingestion.py      # Main ingestion script
    │   ├── verify.py         # Verification script
    │   └── cleanup.py        # Cleanup script
    ├── lambda_handler.py     # AWS Lambda entry point
    └── (legacy scripts)      # Backward compatible scripts

Usage (CLI - from project root folder):
    
    # ====== TRANSCRIPT PIPELINE ======
    # Ingest transcripts
    python -m batch_data_ingestion.transcript.ingestion
    python -m batch_data_ingestion.transcript.ingestion --limit 5 --dry-run
    python -m batch_data_ingestion.transcript.ingestion --verbose --limit 1
    
    # Verify transcript data
    python -m batch_data_ingestion.transcript.verify
    python -m batch_data_ingestion.transcript.verify --project "Noventra"
    
    # Cleanup transcript data
    python -m batch_data_ingestion.transcript.cleanup --dry-run
    python -m batch_data_ingestion.transcript.cleanup --duplicates
    
    # ====== CHAT PIPELINE ======
    # Ingest chats
    python -m batch_data_ingestion.chat.ingestion
    python -m batch_data_ingestion.chat.ingestion --limit 5 --dry-run
    python -m batch_data_ingestion.chat.ingestion --verbose --limit 1
    
    # Verify chat data
    python -m batch_data_ingestion.chat.verify
    python -m batch_data_ingestion.chat.verify --project "Noventra"
    
    # Cleanup chat data
    python -m batch_data_ingestion.chat.cleanup --dry-run
    python -m batch_data_ingestion.chat.cleanup --duplicates

Usage (Lambda/Programmatic):
    from batch_data_ingestion.transcript import process_transcript_folder
    from batch_data_ingestion.chat import process_chat_folder
    
    # Process transcripts
    result = process_transcript_folder(limit=10, dry_run=False)
    
    # Process chats
    result = process_chat_folder(limit=10, dry_run=False)

Path Handling:
    All scripts automatically detect the project root directory and change to it
    before loading configuration. This ensures the .env file is found regardless
    of where the script is invoked from (CLI, Lambda, cron, etc.).
"""

import os
import sys

__version__ = "2.0.0"  # Updated for transcript/chat pipeline separation
__author__ = "Agentic Colleague Team"


def _setup_project_path():
    """
    Setup the project path and working directory.
    Call this before importing any project modules.
    
    Returns:
        str: The project root directory path
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    
    # Add to Python path
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    
    # Change working directory for .env loading
    os.chdir(project_root)
    
    return project_root


# ============================================================================
# BACKWARD COMPATIBLE PROCESS FUNCTION
# ============================================================================

def process_s3_folder(
    folder: str,
    dry_run: bool = False,
    limit: int = None,
    skip_existing: bool = True,
    verbose: bool = False
) -> dict:
    """
    Process S3 folder using the appropriate pipeline (backward compatible).
    
    This function provides backward compatibility with the old batch_s3_ingestion
    module by routing to the appropriate new pipeline based on folder name.
    
    Args:
        folder: S3 folder name (e.g., 'transcripts/', 'Teams_Chat/', etc.)
        dry_run: If True, don't write to databases
        limit: Maximum number of files to process (None for all)
        skip_existing: If True, skip files that are already indexed
        verbose: If True, print detailed output
        
    Returns:
        dict: Summary of ingestion results
    """
    _setup_project_path()
    
    # Normalize folder name
    folder_lower = folder.lower().strip("/")
    
    # Route to appropriate pipeline based on folder name
    if folder_lower in ["transcripts", "transcribe_data", "meetings/transcripts"]:
        from batch_data_ingestion.transcript.ingestion import process_transcript_folder
        from batch_data_ingestion.core.config import TRANSCRIPT_PREFIX, BASE_PREFIX
        
        # Determine the prefix
        if folder_lower == "meetings/transcripts":
            prefix = TRANSCRIPT_PREFIX
        else:
            prefix = f"{BASE_PREFIX}{folder}/"
        
        return process_transcript_folder(
            prefix=prefix,
            dry_run=dry_run,
            limit=limit,
            skip_existing=skip_existing,
            verbose=verbose
        )
    
    elif folder_lower in ["teams_chat", "chats", "meetings/chats"]:
        from batch_data_ingestion.chat.ingestion import process_chat_folder
        from batch_data_ingestion.core.config import CHAT_PREFIX, BASE_PREFIX
        
        # Determine the prefix
        if folder_lower == "meetings/chats":
            prefix = CHAT_PREFIX
        else:
            prefix = f"{BASE_PREFIX}{folder}/"
        
        return process_chat_folder(
            prefix=prefix,
            dry_run=dry_run,
            limit=limit,
            skip_existing=skip_existing,
            verbose=verbose
        )
    
    else:
        # For other folders, use transcript pipeline as default
        # (emails, channel posts, etc. have similar structure)
        from batch_data_ingestion.transcript.ingestion import process_transcript_folder
        from batch_data_ingestion.core.config import BASE_PREFIX
        
        prefix = f"{BASE_PREFIX}{folder}/"
        
        return process_transcript_folder(
            prefix=prefix,
            dry_run=dry_run,
            limit=limit,
            skip_existing=skip_existing,
            verbose=verbose
        )


def run_batch_ingestion(folder: str, limit: int = None, dry_run: bool = False, 
                        verbose: bool = False, skip_existing: bool = True) -> dict:
    """
    Run batch ingestion programmatically (for Lambda/scheduled triggers).
    
    Args:
        folder: S3 folder name within Agentic-Colleague-synthetic/ (e.g., 'transcripts/')
        limit: Maximum number of files to process (None for all)
        dry_run: If True, don't write to databases
        verbose: If True, print detailed output
        skip_existing: If True, skip files that are already indexed
        
    Returns:
        dict: Summary of ingestion results
    """
    _setup_project_path()
    
    # Route to appropriate pipeline based on folder name
    return process_s3_folder(
        folder=folder,
        limit=limit,
        dry_run=dry_run,
        verbose=verbose,
        skip_existing=skip_existing
    )


def run_verification(source_uri: str = None, evidence_id: str = None,
                     hours: int = 1, limit: int = 10) -> dict:
    """
    Run verification programmatically (for Lambda/scheduled triggers).
    
    Args:
        source_uri: Optional file name to search for
        evidence_id: Optional evidence ID to search for
        hours: Look back N hours for recent records
        limit: Maximum results to return
        
    Returns:
        dict: Verification results
    """
    _setup_project_path()
    
    # Import here after path is setup
    from batch_data_ingestion.verify_ingestion import (
        search_by_source_uri, 
        search_by_evidence_id,
        get_recent_records
    )
    
    if source_uri:
        return search_by_source_uri(source_uri)
    elif evidence_id:
        return search_by_evidence_id(evidence_id)
    else:
        return get_recent_records(hours=hours, limit=limit)


def run_cleanup(dry_run: bool = True) -> dict:
    """
    Run duplicate cleanup programmatically (for Lambda/scheduled triggers).
    
    Args:
        dry_run: If True, only report duplicates without deleting
        
    Returns:
        dict: Cleanup results with duplicates found/deleted
    """
    _setup_project_path()
    
    # Import here after path is setup
    from batch_data_ingestion.cleanup_duplicates import (
        get_all_documents,
        find_duplicates,
        delete_document
    )
    
    docs = get_all_documents()
    duplicates = find_duplicates(docs)
    
    result = {
        "total_documents": len(docs),
        "duplicate_groups": len(duplicates),
        "duplicates_to_delete": sum(len(ids) - 1 for ids in duplicates.values()),
        "deleted": [],
        "dry_run": dry_run
    }
    
    if not dry_run:
        for content_hash, doc_ids in duplicates.items():
            # Keep the first (oldest), delete the rest
            for doc_id in doc_ids[1:]:
                if delete_document(doc_id):
                    result["deleted"].append(doc_id)
    
    return result


# ============================================================================
# NEW PIPELINE-SPECIFIC FUNCTIONS
# ============================================================================

def run_transcript_ingestion(limit: int = None, dry_run: bool = False,
                             verbose: bool = False, skip_existing: bool = True) -> dict:
    """
    Run transcript ingestion programmatically.
    
    Args:
        limit: Maximum number of files to process (None for all)
        dry_run: If True, don't write to databases
        verbose: If True, print detailed output
        skip_existing: If True, skip files that are already indexed
        
    Returns:
        dict: Summary of ingestion results
    """
    _setup_project_path()
    
    from batch_data_ingestion.transcript.ingestion import process_transcript_folder
    
    return process_transcript_folder(
        limit=limit,
        dry_run=dry_run,
        verbose=verbose,
        skip_existing=skip_existing
    )


def run_chat_ingestion(limit: int = None, dry_run: bool = False,
                       verbose: bool = False, skip_existing: bool = True) -> dict:
    """
    Run chat ingestion programmatically.
    
    Args:
        limit: Maximum number of files to process (None for all)
        dry_run: If True, don't write to databases
        verbose: If True, print detailed output
        skip_existing: If True, skip files that are already indexed
        
    Returns:
        dict: Summary of ingestion results
    """
    _setup_project_path()
    
    from batch_data_ingestion.chat.ingestion import process_chat_folder
    
    return process_chat_folder(
        limit=limit,
        dry_run=dry_run,
        verbose=verbose,
        skip_existing=skip_existing
    )


# Export the main functions
__all__ = [
    # Legacy functions (backward compatible)
    "process_s3_folder",  # Backward compatible with old batch_s3_ingestion
    "run_batch_ingestion",
    "run_verification",
    "run_cleanup",
    # New pipeline-specific functions
    "run_transcript_ingestion",
    "run_chat_ingestion",
]
