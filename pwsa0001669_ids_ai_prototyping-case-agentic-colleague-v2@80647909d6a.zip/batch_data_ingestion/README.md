# Batch Data Ingestion Pipeline

> **Version:** 2.1.0  
> **Last Updated:** August 20, 2026  
> **Module Location:** `batch_data_ingestion/`

---

## Table of Contents

1. [Module Overview](#1-module-overview)
2. [Business Context](#2-business-context)
3. [Functional Overview](#3-functional-overview)
4. [Architecture Overview](#4-architecture-overview)
5. [Folder Structure](#5-folder-structure)
6. [Technology Stack](#6-technology-stack)
7. [Dependencies](#7-dependencies)
8. [Configuration](#8-configuration)
9. [Environment Variables](#9-environment-variables)
10. [Installation Guide](#10-installation-guide)
11. [Build Process](#11-build-process)
12. [Running the Application](#12-running-the-application)
13. [API Documentation](#13-api-documentation)
14. [Database Documentation](#14-database-documentation)
15. [End-to-End Flow](#15-end-to-end-flow)
16. [Component Deep Dive](#16-component-deep-dive)
17. [Data Flow](#17-data-flow)
18. [Logging and Monitoring](#18-logging-and-monitoring)
19. [Error Handling Strategy](#19-error-handling-strategy)
20. [Security Considerations](#20-security-considerations)
21. [Testing](#21-testing)
22. [Deployment](#22-deployment)
23. [Troubleshooting Guide](#23-troubleshooting-guide)
24. [Performance Considerations](#24-performance-considerations)
25. [Assumptions and Limitations](#25-assumptions-and-limitations)
26. [Future Improvements](#26-future-improvements)
27. [Frequently Asked Questions](#27-frequently-asked-questions)
28. [Glossary](#28-glossary)
29. [Ownership and Support](#29-ownership-and-support)
30. [Quick Start Guide](#30-quick-start-guide)

---

## 1. Module Overview

### What This Module Does

The **Batch Data Ingestion Pipeline** is a core data processing module that transforms unstructured collaboration content (meeting transcripts) into structured, searchable work evidence. It extracts actionable intelligence from raw documents and makes them available for AI-powered project management assistance.

### Why It Exists

Organizations generate massive amounts of collaboration data through meetings. This data contains valuable project intelligence—action items, decisions, dependencies, and status updates—that often gets lost in the noise. This module solves this problem by:

1. **Automatically extracting** text from collaboration documents
2. **Using AI (Claude/Bedrock)** to identify and structure project-relevant information
3. **Creating searchable embeddings** for semantic retrieval
4. **Storing structured data** for project tracking and AI assistance

### Business Value

- **Time Savings:** Eliminates manual action item tracking from meetings
- **Completeness:** AI processes 100% of document content (no data loss from chunking)
- **Consistency:** Standardized extraction across all source types
- **Searchability:** Vector embeddings enable semantic search across all work evidence

---

## 2. Business Context

### Business Purpose

The Agentic Colleague platform serves as an AI-powered project management assistant. To provide intelligent assistance, it needs access to the full context of project work—including what was discussed in meetings, what decisions were made, and what action items were assigned.

This module is the **data ingestion layer** that feeds the AI with project intelligence.

### Use Cases

| Use Case | Description | Outcome |
|----------|-------------|---------|
| **Meeting Follow-up** | Team has a meeting; transcript is generated | Action items auto-appear on Kanban board |
| **Project Search** | PM searches "what was decided about API design?" | Semantic search finds relevant meeting excerpts |
| **Status Tracking** | Manager asks "what's the status of feature X?" | AI retrieves latest mentions from transcripts |

### Real-World Example

```
1. Engineering team has a 60-minute sprint planning meeting
2. Teams generates a transcript document (DOCX)
3. Document is uploaded to S3: meetings/transcripts/sprint_planning_2026-08-15.docx
4. Batch ingestion pipeline runs (scheduled or triggered)
5. Pipeline extracts:
   - 7 action items with owners and due dates
   - 3 key decisions
   - References to 2 projects (Noventra, Graph API Integration)
6. Action items appear on Kanban board
7. PM can search "sprint planning decisions" and get relevant context
```

### Expected Outcomes

- ✅ 100% of transcript content is processed (no truncation)
- ✅ Action items are extracted with owner, due date, status
- ✅ Documents are linked to correct projects via intelligent matching
- ✅ Semantic search returns relevant results for natural language queries

---

## 3. Functional Overview

### Core Responsibilities

| Responsibility | Description |
|----------------|-------------|
| **Text Extraction** | Read DOCX/TXT/EML files from S3 |
| **LLM Cleaning** | Use Claude to clean and structure content |
| **Entity Extraction** | Identify people, projects, dates, tickets |
| **Action Item Detection** | Extract tasks with owner/due date/status |
| **Decision Detection** | Identify key decisions made |
| **Project Matching** | Match content to seeded projects |
| **Embedding Generation** | Create vector embeddings with Titan v2 |
| **Deduplication** | Skip already-indexed content via content hash |
| **Vector Indexing** | Store embeddings in OpenSearch |
| **Work Item Creation** | Write action items to DynamoDB |

### Major Features

#### 1. Transcript Pipeline

| Pipeline | Source | S3 Path | Source Type |
|----------|--------|---------|-------------|
| **Transcript** | Meeting transcripts | `meetings/transcripts/` | `meeting_transcript` |

#### 2. Map-Reduce Chunking (No Data Loss)

Large documents are split into overlapping chunks (6000 chars each), processed independently, then merged with intelligent deduplication. This ensures:
- No action items are missed from long meetings
- Status updates from later in the meeting override earlier status
- All content is embedded for semantic search

#### 3. Multi-Vector Embedding

Documents are indexed with multiple vector embeddings (one per chunk), enabling:
- Precise semantic search within long documents
- Parent document with full metadata
- Chunk documents for fine-grained retrieval

#### 4. Intelligent Project Matching

Two-phase project matching:
1. LLM detects project names from content
2. LLM matches to seeded projects in DynamoDB
3. Fallback string matching if LLM fails

### What's Intentionally Excluded

| Excluded | Reason |
|----------|--------|
| Real-time streaming | This is a batch processor; real-time handled by other modules |
| Email processing | Legacy support exists but not primary focus |
| File upload UI | Handled by separate upload endpoints |
| OCR/image processing | Only text-based documents supported |

---

## 4. Architecture Overview

### High-Level Architecture

```mermaid
graph TB
    subgraph "Data Sources"
        S3[(S3 Bucket<br/>meetings/)]
        S3T[transcripts/]
        S3 --> S3T
    end

    subgraph "Processing Layer"
        TP[Transcript Pipeline]
        
        subgraph "Core Modules"
            TE[Text Extraction]
            LLM[LLM Processing<br/>Claude]
            EMB[Embedding<br/>Titan v2]
            PM[Project Matching]
        end
    end

    subgraph "Storage Layer"
        OS[(OpenSearch<br/>Vector Index)]
        DDB[(DynamoDB<br/>WorkItems)]
    end

    subgraph "Entry Points"
        CLI[CLI Commands]
        API[FastAPI Endpoints]
        LAM[Lambda Handler]
        UI[Onboarding UI]
    end

    S3T --> TP
    
    TP --> TE
    TE --> LLM
    LLM --> PM
    PM --> EMB
    EMB --> OS
    LLM --> DDB

    CLI --> TP
    API --> TP
    LAM --> TP
    UI --> API
```

### Component Relationships

```mermaid
graph LR
    subgraph "core/"
        config[config.py]
        aws[aws_clients.py]
        s3[s3_utils.py]
        txt[text_extraction.py]
        llm[llm_processing.py]
        proj[project_matching.py]
        os[opensearch_utils.py]
        ddb[dynamodb_utils.py]
        hlp[helpers.py]
    end

    subgraph "transcript/"
        ti[ingestion.py]
        tv[verify.py]
        tc[cleanup.py]
    end

    config --> aws
    aws --> s3
    aws --> txt
    aws --> llm
    aws --> proj
    aws --> os
    aws --> ddb

    ti --> s3
    ti --> txt
    ti --> llm
    ti --> proj
    ti --> os
    ti --> ddb

```

### External Integrations

| Integration | Service | Purpose |
|-------------|---------|---------|
| **AWS S3** | File Storage | Source documents |
| **AWS Bedrock** | Claude Sonnet | Text cleaning, entity extraction |
| **AWS Bedrock** | Titan Embed v2 | Vector embedding generation |
| **AWS OpenSearch Serverless** | Vector DB | Semantic search index |
| **AWS DynamoDB** | NoSQL DB | Work items storage |
| **Project Seeding Service** | Internal | Seeded projects for matching |

---

## 5. Folder Structure

```
batch_data_ingestion/
├── __init__.py              # Package exports, version, convenience functions
├── README.md                # This documentation
├── API_TEST_GUIDE.md        # Swagger API testing guide
│
├── core/                    # Shared utilities (used by all pipelines)
│   ├── __init__.py          # Core module exports
│   ├── config.py            # S3/OpenSearch/DynamoDB configuration constants
│   ├── aws_clients.py       # Lazy-loaded AWS clients (S3, DynamoDB, Bedrock)
│   ├── text_extraction.py   # Extract text from DOCX, TXT, EML files
│   ├── llm_processing.py    # LLM cleaning, chunking, embedding generation
│   ├── project_matching.py  # Match projects to seeded projects via LLM
│   ├── opensearch_utils.py  # Build documents, index to OpenSearch
│   ├── dynamodb_utils.py    # Write work items to DynamoDB
│   ├── s3_utils.py          # List S3 files, source type mapping
│   └── helpers.py           # Formatting, printing utilities
│
├── transcript/              # Transcript-specific pipeline
│   ├── __init__.py          # Exports process_transcript_folder
│   ├── ingestion.py         # Main transcript ingestion script
│   ├── verify.py            # Verification script for transcripts
│   └── cleanup.py           # Cleanup/delete transcript data
│
└── (legacy scripts)         # Backward compatible scripts
    ├── batch_s3_ingestion.py    # Original batch ingestion
    ├── verify_opensearch.py     # Original OpenSearch verify
    └── cleanup_duplicates.py    # Original cleanup
```

### Key Files Explained

| File | Purpose |
|------|---------|
| `core/config.py` | Central configuration - S3 prefixes, table names, index names |
| `core/aws_clients.py` | Lazy-loaded clients to avoid unnecessary connections |
| `core/llm_processing.py` | **Heart of the pipeline** - chunking, LLM calls, merging |
| `core/project_matching.py` | Intelligent project matching using LLM + fallback |
| `core/opensearch_utils.py` | Multi-vector document building, indexing |
| `transcript/ingestion.py` | Main entry point for transcript processing |

---

## 6. Technology Stack

### Programming Languages

| Language | Version | Usage |
|----------|---------|-------|
| Python | 3.9+ | All application code |

### Frameworks & Libraries

| Library | Version | Purpose |
|---------|---------|---------|
| `boto3` | Latest | AWS SDK for S3, DynamoDB, Bedrock |
| `requests` | Latest | HTTP client for OpenSearch |
| `requests-aws4auth` | Latest | AWS SigV4 authentication |
| `python-docx` | Latest | DOCX file parsing |
| `pydantic-settings` | Latest | Environment configuration |
| `python-dotenv` | Latest | Load `.env` files |
| `langchain_aws` | Latest | LangChain Bedrock integration |

### AWS Services

| Service | Resource | Purpose |
|---------|----------|---------|
| **S3** | `ids-aini-prototype-ai-analytics` bucket | Source file storage |
| **Bedrock** | `claude-sonnet-4-5` | Text cleaning and extraction |
| **Bedrock** | `titan-embed-text-v2:0` | 1024-dim vector embeddings |
| **OpenSearch Serverless** | `work_evidence_test` index | Vector storage and search |
| **DynamoDB** | `AgenticColleague_WorkItems_Test` | Work items and tasks |

### Build Tools

| Tool | Purpose |
|------|---------|
| pip | Package installation |
| venv | Virtual environment |

---

## 7. Dependencies

### Internal Dependencies

| Dependency | Location | Purpose |
|------------|----------|---------|
| `config.py` | Project root | Global settings (AWS region, model IDs) |
| `utils.bedrock_client` | `utils/` | BedrockClient wrapper for LLM calls |
| `utils.data_ingestion_prompts` | `utils/` | System prompts for different source types |
| `project_seeding.projects_service` | `project_seeding/` | Get seeded projects from DynamoDB |

### External Dependencies

| Dependency | Why It's Needed |
|------------|-----------------|
| `boto3` | All AWS service interactions |
| `requests` | OpenSearch REST API calls |
| `requests-aws4auth` | Sign requests to OpenSearch Serverless |
| `python-docx` | Extract text from Word documents |
| `pydantic-settings` | Type-safe configuration management |
| `langchain_aws` | High-level LLM abstraction |

### Third-Party Services

| Service | Purpose | Required |
|---------|---------|----------|
| AWS Bedrock | LLM and embedding inference | ✅ Yes |
| AWS OpenSearch Serverless | Vector storage | ✅ Yes |
| AWS DynamoDB | Work item storage | ✅ Yes |
| AWS S3 | Source file storage | ✅ Yes |

---

## 8. Configuration

### Configuration Files

| File | Location | Purpose |
|------|----------|---------|
| `.env` | Project root | Environment variables |
| `config.py` | Project root | Global settings class |
| `core/config.py` | This module | Module-specific constants |

### Module Configuration Constants

Located in `core/config.py`:

```python
# S3 Configuration
BUCKET_NAME = "ids-aini-prototype-ai-analytics"
TRANSCRIPT_PREFIX = "Agentic-Colleague-synthetic/meetings/transcripts/"

# OpenSearch Configuration
OPENSEARCH_INDEX = "work_evidence_test"
EMBEDDING_DIMENSION = 1024

# DynamoDB Configuration
DYNAMODB_WORK_ITEMS_TABLE = "AgenticColleague_WorkItems_Test"

# Supported File Types
SUPPORTED_EXTENSIONS = [".docx", ".txt", ".eml"]

# Chunking Configuration (in llm_processing.py)
CHUNK_SIZE = 6000        # Characters per chunk
CHUNK_OVERLAP = 500      # Overlap between chunks
MIN_CHUNK_SIZE = 500     # Minimum chunk size
```

---

## 9. Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `aws_region` | ✅ | - | AWS region (e.g., `us-east-1`) |
| `bucket_name` | ✅ | - | S3 bucket name for source files |
| `model_id` | ✅ | - | Bedrock model ID for Claude |
| `embedding_model_id` | ✅ | - | Bedrock model ID for Titan embeddings |
| `host` | ✅ | - | OpenSearch Serverless endpoint URL |
| `index_name` | ✅ | - | OpenSearch index name |
| `service` | ✅ | - | AWS service name (typically `aoss`) |
| `work_items` | ✅ | - | DynamoDB table name for work items |
| `prefix_folder` | ❌ | - | Legacy S3 prefix |
| `EMBEDDING_DIMENTION` | ✅ | - | Embedding vector dimension (1024) |

### Sample `.env` File

```env
aws_region = "us-east-1"
bucket_name = "ids-aini-prototype-ai-analytics"
model_id = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
embedding_model_id = "amazon.titan-embed-text-v2:0"
host = "https://oqjh772goqkmg0mlp7gg.us-east-1.aoss.amazonaws.com"
index_name = "work_evidence_test"
service = "aoss"
work_items = "AgenticColleague_WorkItems_Test"
EMBEDDING_DIMENTION = 1024
```

---

## 10. Installation Guide

### Prerequisites

- Python 3.9 or higher
- AWS CLI configured with valid credentials
- Access to required AWS services (S3, Bedrock, OpenSearch, DynamoDB)

### Step-by-Step Setup

```powershell
# 1. Clone the repository
git clone <repository-url>
cd agentic-colleague-v2

# 2. Create virtual environment
python -m venv venv

# 3. Activate virtual environment (Windows)
.\venv\Scripts\Activate.ps1

# 4. Install dependencies
pip install -r requirements.txt

# 5. Create .env file
cp .env.example .env
# Edit .env with your AWS configuration

# 6. Verify AWS credentials
aws sts get-caller-identity

# 7. Test module import
python -c "from batch_data_ingestion import __version__; print(__version__)"
```

### Verify Installation

```powershell
# Test transcript pipeline (dry run)
python -m batch_data_ingestion.transcript.ingestion --dry-run --limit 1
```

---

## 11. Build Process

### This Module Has No Build Step

The module is pure Python and runs directly from source code. No compilation or transpilation is needed.

### Package Structure

The module is structured as a Python package with:
- `__init__.py` files defining exports
- Relative imports within the package
- Absolute imports from project root

### Running as Module

```powershell
# Must run from project root
cd agentic-colleague-v2

# Run as Python module (not script)
python -m batch_data_ingestion.transcript.ingestion
```

---

## 12. Running the Application

### CLI Commands

#### Transcript Pipeline

```powershell
# Process all transcripts
python -m batch_data_ingestion.transcript.ingestion

# Dry run (no database writes)
python -m batch_data_ingestion.transcript.ingestion --dry-run

# Limit number of files
python -m batch_data_ingestion.transcript.ingestion --limit 10

# Verbose mode (detailed output, implies dry-run)
python -m batch_data_ingestion.transcript.ingestion --verbose --limit 1

# Process legacy folders
python -m batch_data_ingestion.transcript.ingestion --legacy

# Force re-index (don't skip duplicates)
python -m batch_data_ingestion.transcript.ingestion --no-skip-existing
```

#### Verification

```powershell
# Transcript verification
python -m batch_data_ingestion.transcript.verify
python -m batch_data_ingestion.transcript.verify --project "Noventra"
python -m batch_data_ingestion.transcript.verify --export results.json
```

#### Cleanup

```powershell
# Transcript cleanup (dry run)
python -m batch_data_ingestion.transcript.cleanup --dry-run

# Delete duplicates only
python -m batch_data_ingestion.transcript.cleanup --duplicates

# Delete all (with confirmation)
python -m batch_data_ingestion.transcript.cleanup --all --force
```

### FastAPI Integration

Start the main application:

```powershell
uvicorn main:app --host 0.0.0.0 --port 7007 --reload
```

Access endpoints:
- Swagger UI: `http://localhost:7007/docs`
- Batch ingestion: `/batch/transcript/run`

### Lambda Deployment

See [Section 22: Deployment](#22-deployment) for Lambda handler details.

---

## 13. API Documentation

### FastAPI Endpoints

#### GET `/batch/transcript/config`

Get transcript batch ingestion configuration.

| Field | Type | Description |
|-------|------|-------------|
| Request | None | No parameters |
| Response | JSON | Configuration details |

**Response Example:**
```json
{
  "bucket_name": "ids-aini-prototype-ai-analytics",
  "s3_prefix": "Agentic-Colleague-synthetic/meetings/transcripts/"
}
```

---

#### POST `/batch/transcript/run`

Run transcript batch ingestion.

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `dry_run` | boolean | ❌ | `false` | Preview mode, no writes |
| `verbose` | boolean | ❌ | `false` | Detailed output |
| `limit` | integer | ❌ | `null` | Max files to process |
| `skip_existing` | boolean | ❌ | `true` | Skip duplicates |

**Request Example:**
```json
{
  "dry_run": false,
  "limit": 10,
  "skip_existing": true
}
```

**Response Example:**
```json
{
  "status": "success",
  "statistics": {
    "total": 10,
    "processed": 8,
    "skipped_duplicate": 2,
    "skipped_error": 0,
    "opensearch_indexed": 8,
    "dynamodb_items": 24
  }
}
```

---

### Error Responses

| Status Code | Meaning | Example |
|-------------|---------|---------|
| 200 | Success | Normal completion |
| 400 | Bad Request | Invalid parameters |
| 403 | Forbidden | AWS credentials expired |
| 500 | Server Error | Processing failure |

---

## 14. Database Documentation

### OpenSearch Index: `work_evidence_test`

#### Schema

| Field | Type | Description |
|-------|------|-------------|
| `evidence_id` | keyword | Unique ID (e.g., `EV_abc123`) |
| `workspace_id` | keyword | Workspace identifier |
| `project_id` | keyword | Matched project ID |
| `project_name` | keyword | Matched project name |
| `source_type` | keyword | `meeting_transcript` |
| `source_uri` | keyword | S3 URI of source file |
| `content_hash` | keyword | MD5 hash for deduplication |
| `raw_text` | text | Original structured JSON |
| `clean_text` | text | LLM-cleaned text |
| `summary` | text | Auto-generated summary |
| `embedding_text` | text | Text used for embedding |
| `vector_embedding` | dense_vector (1024) | Titan v2 embedding |
| `action_items_detected` | nested | Array of action items |
| `decisions_detected` | nested | Array of decisions |
| `dates_detected` | keyword[] | Extracted dates |
| `metadata` | object | Additional metadata |
| `created_at` | date | Creation timestamp |
| `updated_at` | date | Update timestamp |
| `is_chunk` | boolean | True if chunk document |
| `chunk_index` | integer | Chunk position |
| `total_chunks` | integer | Total chunks in parent |

#### Multi-Vector Structure

For large documents:
- **Parent Document:** Full metadata, all action items, first chunk embedding
- **Chunk Documents:** Individual text chunk with its own embedding

```mermaid
graph TB
    Parent["Parent Document<br/>evidence_id: EV_abc123<br/>is_chunk: false"]
    C0["Chunk 0<br/>evidence_id: EV_abc123_chunk_0<br/>is_chunk: true"]
    C1["Chunk 1<br/>evidence_id: EV_abc123_chunk_1<br/>is_chunk: true"]
    C2["Chunk 2<br/>evidence_id: EV_abc123_chunk_2<br/>is_chunk: true"]
    
    Parent --> C0
    Parent --> C1
    Parent --> C2
```

---

### DynamoDB Table: `AgenticColleague_WorkItems_Test`

#### Schema

| Attribute | Type | Key | Description |
|-----------|------|-----|-------------|
| `PK` | String | Partition | `PROJECT#{project_name}` |
| `SK` | String | Sort | `TASK#{work_item_id}` |
| `work_item_id` | String | - | Unique ID (e.g., `WI_abc123`) |
| `project_id` | String | - | Matched project ID |
| `project_name` | String | - | Project name |
| `task` | String | - | Action item description |
| `assignee` | String | - | Task owner |
| `assigned_to` | String | - | UI compatibility field |
| `due_date` | String | - | Due date if extracted |
| `status` | String | - | `pending`, `in progress`, `done` |
| `source_type` | String | - | Source document type |
| `source_uri` | String | - | S3 URI of source |
| `summary` | String | - | Task context |
| `task_evidence` | String | - | Supporting text |
| `event_timestamp` | String | - | ISO timestamp |

#### Access Patterns

| Pattern | PK | SK |
|---------|----|----|
| Get tasks for project | `PROJECT#Noventra` | `begins_with(TASK#)` |
| Get specific task | `PROJECT#Noventra` | `TASK#WI_abc123` |
| Scan all tasks | Full table scan | Filter by `source_type` |

---

## 15. End-to-End Flow

### Request-to-Response Lifecycle

```mermaid
sequenceDiagram
    participant UI as Onboarding UI
    participant API as FastAPI
    participant TP as Transcript Pipeline
    participant S3 as AWS S3
    participant Bedrock as AWS Bedrock
    participant OS as OpenSearch
    participant DDB as DynamoDB

    UI->>API: POST /batch/transcript/run
    API->>TP: process_transcript_folder()
    
    TP->>S3: list_s3_files(prefix)
    S3-->>TP: [file1.docx, file2.docx, ...]
    
    loop For each file
        TP->>S3: get_object(file)
        S3-->>TP: file_bytes
        
        TP->>TP: extract_text_from_docx()
        TP->>TP: generate_content_hash()
        
        TP->>OS: check_duplicate()
        alt Duplicate found
            OS-->>TP: exists=true
            TP->>TP: skip file
        else New file
            OS-->>TP: exists=false
            
            TP->>TP: split_text_into_chunks()
            
            loop For each chunk
                TP->>Bedrock: invoke_model(Claude)
                Bedrock-->>TP: cleaned_json
            end
            
            TP->>TP: merge_chunk_results()
            TP->>Bedrock: invoke_model(project matching)
            Bedrock-->>TP: matched_project
            
            loop For each chunk
                TP->>Bedrock: invoke_model(Titan embed)
                Bedrock-->>TP: embedding[]
            end
            
            TP->>OS: index_document()
            OS-->>TP: indexed
            
            loop For each action item
                TP->>DDB: put_item()
                DDB-->>TP: success
            end
        end
    end
    
    TP-->>API: statistics
    API-->>UI: {status: success, statistics: {...}}
```

### Processing Steps Summary

| Step | Component | Action |
|------|-----------|--------|
| 1 | S3 Utils | List files in S3 prefix |
| 2 | Text Extraction | Read DOCX, extract text |
| 3 | LLM Processing | Generate content hash |
| 4 | OpenSearch Utils | Check for duplicates |
| 5 | LLM Processing | Split text into chunks |
| 6 | LLM Processing | Clean each chunk with Claude |
| 7 | LLM Processing | Merge chunk results |
| 8 | Project Matching | Match to seeded projects |
| 9 | LLM Processing | Generate embeddings |
| 10 | OpenSearch Utils | Build and index documents |
| 11 | DynamoDB Utils | Write work items |

---

## 16. Component Deep Dive

### 16.1 Text Extraction (`core/text_extraction.py`)

**Purpose:** Extract text content from various file formats stored in S3.

**Inputs:**
- S3 bucket name
- S3 object key

**Outputs:**
- Extracted text string

**Supported Formats:**
| Format | Function | Notes |
|--------|----------|-------|
| `.docx` | `extract_text_from_docx_bytes()` | Uses python-docx |
| `.txt` | `extract_text_from_txt_bytes()` | UTF-8 with Latin-1 fallback |
| `.eml` | `extract_text_from_eml_bytes()` | Extracts headers + body |

**Internal Logic:**
1. Read file bytes from S3
2. Detect extension
3. Route to appropriate extractor
4. Return text or None on error

---

### 16.2 LLM Processing (`core/llm_processing.py`)

**Purpose:** Clean text, extract entities, and generate embeddings using AWS Bedrock.

**Key Functions:**

| Function | Purpose |
|----------|---------|
| `split_text_into_chunks()` | Divide text at sentence boundaries |
| `_process_single_chunk()` | Send one chunk to Claude |
| `_merge_chunk_results()` | Combine results with deduplication |
| `_reconcile_action_items()` | Resolve status conflicts across chunks |
| `clean_text_with_llm()` | Main entry point |
| `generate_embedding()` | Create Titan v2 vector |

**Chunking Strategy:**
```
Document: 15,000 characters
↓
Chunk 1: chars 0-6000 (sentence boundary)
Chunk 2: chars 5500-11500 (500 char overlap)
Chunk 3: chars 11000-15000
↓
Process each with Claude
↓
Merge with deduplication
```

**Status Reconciliation:**
When the same action item appears in multiple chunks:
- Highest status wins: `done > in progress > pending`
- Most specific owner/due date preserved
- Confidence scores compared

---

### 16.3 Project Matching (`core/project_matching.py`)

**Purpose:** Match detected project names to seeded projects in DynamoDB.

**Two-Phase Matching:**

```mermaid
graph LR
    subgraph "Phase 1: LLM Detection"
        Raw[Raw Text]
        LLM1[Claude]
        Detected["Detected: ['Graph API', 'API Integration']"]
        Raw --> LLM1 --> Detected
    end
    
    subgraph "Phase 2: LLM Matching"
        Seeded["Seeded Projects<br/>from DynamoDB"]
        LLM2[Claude]
        Matched["Matched: 'Graph API Integration'<br/>project_id: PROJ_001"]
        Detected --> LLM2
        Seeded --> LLM2
        LLM2 --> Matched
    end
    
    subgraph "Fallback"
        StringMatch[String Similarity]
        Matched -.-> StringMatch
    end
```

**Fallback Logic:**
1. Exact string match
2. Substring/contains match
3. Return as new project

---

### 16.4 OpenSearch Utils (`core/opensearch_utils.py`)

**Purpose:** Build documents and index to OpenSearch Serverless.

**Key Functions:**

| Function | Purpose |
|----------|---------|
| `build_work_evidence_doc()` | Build single-vector document |
| `build_work_evidence_doc_with_chunks()` | Build parent + chunk documents |
| `index_to_opensearch()` | Index single document |
| `index_document_with_chunks()` | Index parent and all chunks |
| `check_duplicate_in_opensearch()` | Query by content_hash or source_uri |
| `get_fresh_awsauth()` | Refresh AWS credentials |

**Credential Refresh:**
AWS temporary credentials expire. The module refreshes credentials before each request:
```python
def get_fresh_awsauth():
    session = boto3.Session()
    credentials = session.get_credentials()
    return AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        AWS_REGION,
        "aoss",
        session_token=credentials.token
    )
```

---

### 16.5 DynamoDB Utils (`core/dynamodb_utils.py`)

**Purpose:** Write extracted action items to DynamoDB.

**Data Transformation:**
```
LLM Output:
{
  "action_items": [
    {"description": "Review API design", "owner": "John", "due_date": "2026-08-25"}
  ]
}

↓ write_to_dynamodb()

DynamoDB Item:
{
  "PK": "PROJECT#Graph API Integration",
  "SK": "TASK#WI_abc123",
  "task": "Review API design",
  "assignee": "John",
  "due_date": "2026-08-25",
  "status": "pending",
  ...
}
```

---

## 17. Data Flow

### Data Sources

| Source | Format | S3 Location |
|--------|--------|-------------|
| Meeting Transcripts | DOCX | `meetings/transcripts/` |
| Legacy Transcripts | DOCX/TXT | `transcripts/`, `Transcribe_Data/` |

### Processing Flow

```mermaid
flowchart TD
    subgraph Sources
        S3[S3 Bucket]
    end
    
    subgraph Extraction
        TE[Text Extraction]
        DOCX[DOCX Parser]
        TXT[TXT Reader]
    end
    
    subgraph Processing
        HASH[Content Hash]
        CHUNK[Chunking]
        LLM[Claude LLM]
        MERGE[Merge Results]
        MATCH[Project Match]
        EMB[Titan Embeddings]
    end
    
    subgraph Storage
        OS[(OpenSearch)]
        DDB[(DynamoDB)]
    end
    
    S3 --> TE
    TE --> DOCX
    TE --> TXT
    DOCX --> HASH
    TXT --> HASH
    HASH --> CHUNK
    CHUNK --> LLM
    LLM --> MERGE
    MERGE --> MATCH
    MATCH --> EMB
    EMB --> OS
    MERGE --> DDB
```

### Data Outputs

| Destination | Data Type | Purpose |
|-------------|-----------|---------|
| OpenSearch | Vector documents | Semantic search |
| DynamoDB | Work items | Kanban board display |

---

## 18. Logging and Monitoring

### Logging Approach

The module uses **print statements** with emoji prefixes for visual clarity:

| Emoji | Meaning |
|-------|---------|
| ✅ | Success |
| ❌ | Error |
| ⚠️ | Warning |
| ⏭️ | Skipped |
| 📂 | File operation |
| 📋 | Data listing |
| 🎙️ | Transcript |
| 🔍 | Search/Query |

### Output Example

```
======================================================================
🎙️ TRANSCRIPT INGESTION PIPELINE
======================================================================
Bucket:      ids-aini-prototype-ai-analytics
Prefix:      Agentic-Colleague-synthetic/meetings/transcripts/
Source Type: meeting_transcript
======================================================================

📋 Loading seeded projects from DynamoDB...
   ✅ Loaded 5 seeded projects
📂 Listing S3 files...
   Found 15 files

[1/15] 🎙️ sprint_planning_2026-08-15.docx
  1️⃣ Extracting text...
     ✅ Extracted 12,453 chars
  2️⃣ Content Hash: abc123def456
  3️⃣ Cleaning with LLM...
     📄 Document split into 3 chunks (12453 chars total)
        Processing chunk 1/3...
        Processing chunk 2/3...
        Processing chunk 3/3...
        Merging results from 3 chunks...
        ✅ Merged: 7 action items, 3 decisions
  4️⃣ Generating embeddings...
     ✅ Generated 3 embeddings (1 per chunk)
  5️⃣ Building OpenSearch documents...
     ✅ Built 1 parent doc + 3 chunk docs
  6️⃣ Indexing to OpenSearch...
     ✅ Parent indexed
     ✅ Chunks indexed: 3/3
  7️⃣ Writing to DynamoDB...
     ✅ Wrote 7 work items
```

### Monitoring Recommendations

| Tool | Purpose | Setup |
|------|---------|-------|
| CloudWatch Logs | Lambda execution logs | Enable via Lambda config |
| CloudWatch Metrics | Custom metrics | Add boto3 cloudwatch calls |
| X-Ray | Distributed tracing | Add X-Ray SDK |

---

## 19. Error Handling Strategy

### Error Types

| Error Type | Handling | Recovery |
|------------|----------|----------|
| **S3 Access Error** | Log and skip file | Continue with next file |
| **Text Extraction Error** | Return None, skip | Continue with next file |
| **LLM Timeout** | Retry with backoff | 3 retries, then skip |
| **Chunk Processing Error** | Return fallback JSON | Continue processing |
| **Project Match Error** | Use fallback matching | Simple string match |
| **OpenSearch Index Error** | Log and continue | Track in stats |
| **DynamoDB Write Error** | Log and continue | Track in stats |
| **AWS Credential Expiry** | Refresh credentials | Auto-handled |

### Error Recovery Patterns

```python
# Pattern 1: Try-except with fallback
try:
    result = match_project_with_llm(...)
except Exception as e:
    print(f"⚠️ LLM matching failed: {e}")
    result = _fallback_project_match(detected_projects)

# Pattern 2: Skip on error
try:
    raw_text = extract_text_from_s3_file(bucket, key)
except Exception as e:
    print(f"❌ Error extracting text: {e}")
    stats["skipped_error"] += 1
    continue

# Pattern 3: Credential refresh
def get_fresh_awsauth():
    # Always creates new session
    session = boto3.Session()
    credentials = session.get_credentials()
    return AWS4Auth(...)
```

### Statistics Tracking

```python
stats = {
    "total": len(files),
    "processed": 0,
    "skipped_duplicate": 0,
    "skipped_error": 0,
    "opensearch_indexed": 0,
    "dynamodb_items": 0
}
```

---

## 20. Security Considerations

### Authentication

| Component | Auth Method |
|-----------|-------------|
| S3 | IAM role / AWS credentials |
| Bedrock | IAM role / AWS credentials |
| OpenSearch Serverless | SigV4 signing |
| DynamoDB | IAM role / AWS credentials |

### Credentials Management

- ✅ Credentials loaded from environment or IAM role
- ✅ No hardcoded secrets in code
- ✅ Temporary credentials auto-refreshed
- ✅ `.env` file should not be committed (add to `.gitignore`)

### Data Protection

| Data | Protection |
|------|------------|
| S3 files | Server-side encryption |
| OpenSearch | Encryption at rest |
| DynamoDB | Encryption at rest |
| In-transit | HTTPS/TLS |

### IAM Permissions Required

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::ids-aini-prototype-ai-analytics",
        "arn:aws:s3:::ids-aini-prototype-ai-analytics/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "aoss:APIAccessAll"
      ],
      "Resource": "arn:aws:aoss:*:*:collection/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:PutItem",
        "dynamodb:GetItem",
        "dynamodb:Scan",
        "dynamodb:Query",
        "dynamodb:DeleteItem"
      ],
      "Resource": "arn:aws:dynamodb:*:*:table/AgenticColleague_*"
    }
  ]
}
```

### Security Best Practices

- ✅ Use IAM roles instead of access keys in production
- ✅ Apply least privilege principle
- ✅ Enable CloudTrail for audit logging
- ✅ Use VPC endpoints for private connectivity
- ⚠️ Review LLM outputs for sensitive data exposure

---

## 21. Testing

### Manual Testing

#### Dry Run Testing

```powershell
# Test without any database writes
python -m batch_data_ingestion.transcript.ingestion --dry-run --limit 1

# Verbose mode shows full output
python -m batch_data_ingestion.transcript.ingestion --verbose --limit 1
```

#### Verification Testing

```powershell
# Verify what's in OpenSearch
python -m batch_data_ingestion.transcript.verify --opensearch --limit 5

# Verify what's in DynamoDB
python -m batch_data_ingestion.transcript.verify --workitems --limit 5
```

### API Testing

```powershell
# Start server
uvicorn main:app --host 0.0.0.0 --port 7007

# Test via curl
curl -X POST http://localhost:7007/batch/transcript/run `
  -H "Content-Type: application/json" `
  -d '{"dry_run": true, "limit": 1}'
```

### Recommended Test Sequence

| Step | Command | Expected Outcome |
|------|---------|------------------|
| 1 | Verify AWS connectivity | `aws sts get-caller-identity` succeeds |
| 2 | Test S3 access | Files listed from prefix |
| 3 | Test single file (dry run) | LLM processing completes |
| 4 | Test single file (real) | Data appears in OpenSearch/DynamoDB |
| 5 | Test duplicate detection | Second run skips same file |
| 6 | Test cleanup | Data removed successfully |

### Test Data

Sample S3 files available at:
- `Agentic-Colleague-synthetic/meetings/transcripts/`

---

## 22. Deployment

### Local Development

```powershell
# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Run CLI
python -m batch_data_ingestion.transcript.ingestion

# Or via FastAPI
uvicorn main:app --reload --port 7007
```

### Lambda Deployment

#### Handler Configuration

| Setting | Value |
|---------|-------|
| Runtime | Python 3.9+ |
| Handler | `batch_data_ingestion.lambda_handler.handler` |
| Timeout | 900 seconds (15 min) |
| Memory | 512 MB minimum |

#### EventBridge Events

```json
{
  "action": "ingest_transcript",
  "limit": 100
}
```

#### Lambda Actions

| Action | Description |
|--------|-------------|
| `ingest_transcript` | Process meeting transcripts |
| `verify_transcript` | Verify transcript data |
| `cleanup_transcript` | Remove duplicate transcripts |

### Docker Deployment

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "7007"]
```

### Infrastructure Requirements

| Resource | Specification |
|----------|---------------|
| CPU | 2 vCPU minimum |
| Memory | 1 GB minimum |
| Network | Access to AWS services |
| Storage | Minimal (stateless) |

### Rollback Process

1. Identify problematic ingestion run (via timestamps)
2. Run cleanup with filter: `--source-uri "timestamp_pattern"`
3. Redeploy previous version
4. Re-run ingestion

---

## 23. Troubleshooting Guide

| Problem | Possible Cause | Resolution |
|---------|----------------|------------|
| `403 Forbidden from OpenSearch` | AWS credentials expired | Credentials auto-refresh; check IAM permissions |
| `ModuleNotFoundError: batch_data_ingestion` | Running from wrong directory | Run from project root: `cd agentic-colleague-v2` |
| `Found 0 files` | Wrong S3 prefix | Verify prefix: `aws s3 ls s3://bucket/prefix/` |
| `No text extracted` | Unsupported file format | Check file extension (.docx, .txt, .eml) |
| `LLM processing failed` | Bedrock timeout or quota | Check Bedrock console; retry with smaller limit |
| `Project matching failed` | No seeded projects | Run project seeding first |
| `Duplicate found, skipping` | Content already indexed | Use `--no-skip-existing` to force |
| `DynamoDB write failed` | Missing table or permissions | Check table exists; verify IAM policy |
| `OpenSearch index failed` | Index doesn't exist | Create index with correct mapping |
| `EmptyDataError` | Empty or corrupt file | Skip file; check S3 object |

### Diagnostic Commands

```powershell
# Check AWS identity
aws sts get-caller-identity

# List S3 files
aws s3 ls s3://ids-aini-prototype-ai-analytics/Agentic-Colleague-synthetic/meetings/

# Check DynamoDB table
aws dynamodb describe-table --table-name AgenticColleague_WorkItems_Test

# Check OpenSearch
curl -X GET "https://your-opensearch-endpoint/work_evidence_test/_count"
```

---

## 24. Performance Considerations

### Bottlenecks

| Bottleneck | Impact | Mitigation |
|------------|--------|------------|
| LLM API latency | ~2-5s per chunk | Process files in parallel |
| Large documents | Multiple chunks = more LLM calls | Acceptable for accuracy |
| OpenSearch refresh | Slight delay after indexing | 0.5s sleep between files |
| Network I/O | S3 downloads | Batch processing |

### Scalability

| Dimension | Current | Scalable To |
|-----------|---------|-------------|
| Files per run | Any | Limited by Lambda timeout |
| File size | Any (chunked) | Tested up to 500KB |
| Concurrent runs | 1 | Thread pools in FastAPI |
| Index size | Thousands | Millions (OpenSearch scales) |

### Optimization Techniques

1. **Parallel chunk processing** (not implemented - LLM calls are serial)
2. **Batch DynamoDB writes** (not implemented - item-by-item)
3. **Bulk OpenSearch indexing** (not implemented - document-by-document)
4. **Connection pooling** for AWS clients (implemented - lazy loading)

### Resource Usage

| Resource | Usage Pattern |
|----------|---------------|
| CPU | Moderate (text processing) |
| Memory | Low-moderate (no large in-memory data) |
| Network | High (S3 + LLM + OpenSearch) |
| Storage | None (stateless) |

---

## 25. Assumptions and Limitations

### Assumptions

| Assumption | Description |
|------------|-------------|
| File format | Source files are DOCX, TXT, or EML |
| Language | Content is primarily English |
| AWS access | Running environment has AWS credentials |
| Bedrock access | Account has Bedrock model access |
| Project seeding | Projects exist in DynamoDB for matching |
| UTF-8 encoding | Text files are UTF-8 or Latin-1 |

### Limitations

| Limitation | Description | Workaround |
|------------|-------------|------------|
| No OCR | Cannot process scanned documents | Use pre-processed text |
| No real-time | Batch processing only | Use other modules for real-time |
| Single language | English-focused prompts | Modify prompts for other languages |
| No image analysis | Ignores images in documents | Future enhancement |
| Sequential LLM calls | One chunk at a time | Trade-off for reliability |
| No retry queue | Failed files not queued | Manual re-run needed |

### Technical Debt

| Item | Description | Priority |
|------|-------------|----------|
| Print-based logging | Should use Python logging | Medium |
| No unit tests | Manual testing only | High |
| Hardcoded prompts | Should be configurable | Low |
| No caching | LLM results not cached | Medium |
| Sync processing | Could benefit from async | Medium |

---

## 26. Future Improvements

### Short-Term (1-3 months)

| Improvement | Description | Benefit |
|-------------|-------------|---------|
| Add unit tests | pytest-based test suite | Quality assurance |
| Implement logging | Replace prints with logging | Better observability |
| Add retry queue | SQS-based retry mechanism | Reliability |
| Batch DynamoDB writes | Use `batch_writer()` | Performance |

### Medium-Term (3-6 months)

| Improvement | Description | Benefit |
|-------------|-------------|---------|
| Async processing | asyncio for parallelism | Performance |
| Multi-language support | Configurable prompts | Global users |
| OCR integration | Textract for scanned docs | More content types |
| Streaming ingestion | Real-time processing | Reduced latency |

### Long-Term (6-12 months)

| Improvement | Description | Benefit |
|-------------|-------------|---------|
| ML-based entity extraction | Train custom models | Accuracy |
| Graph database | Neo4j for relationships | Advanced queries |
| Event sourcing | Track all changes | Audit trail |
| Multi-tenant | Workspace isolation | Enterprise ready |

---

## 27. Frequently Asked Questions

### General

**Q: What file types are supported?**  
A: DOCX, TXT, and EML files. DOCX is the primary format for meeting transcripts.

**Q: How long does processing take?**  
A: Approximately 5-10 seconds per file, depending on file size and number of chunks.

**Q: Can I process historical data?**  
A: Yes, use the CLI with appropriate S3 prefix. Legacy folders are also supported with `--legacy` flag.

### Technical

**Q: What happens if a file is too large?**  
A: The file is split into overlapping chunks (~6000 characters each). All chunks are processed and merged.

**Q: How are duplicates handled?**  
A: Content is hashed (MD5). If the hash exists in OpenSearch, the file is skipped. Use `--no-skip-existing` to force re-processing.

**Q: What if the LLM returns invalid JSON?**  
A: A fallback structure is used with the raw text truncated. The file is not skipped.

**Q: Can I run multiple pipelines simultaneously?**  
A: The FastAPI endpoints use thread pools, but LLM calls are rate-limited by Bedrock quotas.

### Operational

**Q: How do I clean up test data?**  
A: Use the cleanup scripts: `python -m batch_data_ingestion.transcript.cleanup --duplicates`

**Q: How do I verify data was ingested?**  
A: Use the verify scripts: `python -m batch_data_ingestion.transcript.verify`

**Q: What if AWS credentials expire?**  
A: The module automatically refreshes credentials before each request using `get_fresh_awsauth()`.

---

## 28. Glossary

| Term | Definition |
|------|------------|
| **Action Item** | A task extracted from content with description, owner, due date, and status |
| **Bedrock** | AWS managed service for foundation models (LLMs) |
| **Chunk** | A portion of a large document (~6000 chars) processed independently |
| **Claude** | Anthropic's LLM used for text cleaning and extraction |
| **Content Hash** | MD5 hash of file content used for deduplication |
| **Decision** | A key decision point extracted from meeting content |
| **Dry Run** | Execution mode that processes data but doesn't write to databases |
| **Embedding** | Vector representation of text for semantic similarity |
| **Entity** | Extracted structured data: people, projects, dates, tickets |
| **Evidence** | A processed document stored in OpenSearch |
| **Map-Reduce** | Strategy of processing chunks independently then merging |
| **Multi-Vector** | Indexing multiple embeddings per document (one per chunk) |
| **OpenSearch Serverless** | AWS managed vector database service |
| **Parent Document** | Main document with full metadata and first chunk embedding |
| **Project Matching** | Process of linking content to seeded projects |
| **Seeded Project** | Pre-defined project in DynamoDB for matching |
| **Source Type** | Category of content: meeting_transcript |
| **Source URI** | S3 path of the original document |
| **Titan** | Amazon's embedding model for vector generation |
| **Work Item** | An action item stored in DynamoDB for Kanban display |

---

## 29. Ownership and Support

### Team Ownership

| Role | Responsibility |
|------|----------------|
| **Agentic Colleague Team** | Module development and maintenance |
| **Data Engineering** | Pipeline scheduling and monitoring |
| **Platform Team** | AWS infrastructure and access |

### Support Process

1. **First Level:** Check this README and FAQ
2. **Second Level:** Review logs and run verification scripts
3. **Third Level:** Contact Agentic Colleague team

### Escalation Path

```
Developer → Team Lead → Engineering Manager → Platform Team
```

### Contact

- **Module Maintainers:** Agentic Colleague Team
- **Documentation:** This README
- **Issue Tracking:** Project issue tracker

---

## 30. Quick Start Guide

### 5-Minute Onboarding

```powershell
# Step 1: Navigate to project root
cd "C:\path\to\agentic-colleague-v2"

# Step 2: Activate virtual environment
.\venv\Scripts\Activate.ps1

# Step 3: Verify AWS credentials
aws sts get-caller-identity

# Step 4: Test with dry run (no database writes)
python -m batch_data_ingestion.transcript.ingestion --dry-run --limit 1

# Step 5: If Step 4 succeeds, run for real
python -m batch_data_ingestion.transcript.ingestion --limit 5

# Step 6: Verify results
python -m batch_data_ingestion.transcript.verify --limit 5
```

### What You Should See

1. **Dry run output:**
   - File listing from S3
   - Text extraction success
   - LLM cleaning with action items/decisions
   - "[DRY RUN]" messages for database operations

2. **Real run output:**
   - Same as above, plus:
   - "✅ Indexed" for OpenSearch
   - "✅ Wrote X work items" for DynamoDB

3. **Verification output:**
   - Summary statistics
   - Sample records from OpenSearch
   - Sample work items from DynamoDB

### Common First-Time Issues

| Issue | Quick Fix |
|-------|-----------|
| `ModuleNotFoundError` | Run from project root, not batch_data_ingestion/ |
| `NoCredentialsError` | Run `aws configure` or check IAM role |
| `AccessDenied` | Check S3/Bedrock/OpenSearch/DynamoDB permissions |
| `Found 0 files` | Verify S3 prefix has files: `aws s3 ls s3://bucket/prefix/` |

---

## Appendix: Quick Reference

### CLI Commands Cheat Sheet

```powershell
# Transcript Pipeline
python -m batch_data_ingestion.transcript.ingestion           # Full run
python -m batch_data_ingestion.transcript.ingestion --dry-run # No writes
python -m batch_data_ingestion.transcript.ingestion --limit 5 # Limit files
python -m batch_data_ingestion.transcript.verify              # Check data
python -m batch_data_ingestion.transcript.cleanup --dry-run   # Preview cleanup

# API Testing
curl http://localhost:7007/batch/transcript/config
curl -X POST http://localhost:7007/batch/transcript/run -H "Content-Type: application/json" -d '{}'
```

### Key Configuration Values

| Setting | Value |
|---------|-------|
| S3 Bucket | `ids-aini-prototype-ai-analytics` |
| Transcript Prefix | `Agentic-Colleague-synthetic/meetings/transcripts/` |
| OpenSearch Index | `work_evidence_test` |
| DynamoDB Table | `AgenticColleague_WorkItems_Test` |
| Embedding Dimension | 1024 |
| Chunk Size | 6000 characters |

---

*Last Updated: August 20, 2026*
