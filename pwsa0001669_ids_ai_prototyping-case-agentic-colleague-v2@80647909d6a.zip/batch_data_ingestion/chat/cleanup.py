"""
Chat Cleanup Script
===================
Cleanup utilities for chat data in OpenSearch and WorkItems.

This script provides functions to:
- Find and remove duplicate chat records
- Delete all chat records (with confirmation)
- Cleanup specific records by evidence_id or source_uri

Usage (run from project root folder):
    # Dry run - show what would be deleted
    python -m batch_data_ingestion.chat.cleanup --dry-run
    
    # Delete duplicates only
    python -m batch_data_ingestion.chat.cleanup --duplicates
    
    # Delete all chat records (with confirmation)
    python -m batch_data_ingestion.chat.cleanup --all --force
    
    # Delete by source_uri pattern
    python -m batch_data_ingestion.chat.cleanup --source-uri "old_chat"
    
    # Delete specific evidence_id
    python -m batch_data_ingestion.chat.cleanup --evidence-id "EV_abc123"
"""

import argparse
import json
import os
import sys
from collections import defaultdict
from decimal import Decimal
from typing import Any, Dict, List, Optional

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_BATCH_DIR = os.path.dirname(_SCRIPT_DIR)
_PROJECT_ROOT = os.path.dirname(_BATCH_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import requests
from boto3.dynamodb.conditions import Key, Attr

from batch_data_ingestion.core import (
    OPENSEARCH_HOST,
    OPENSEARCH_INDEX,
    DYNAMODB_WORK_ITEMS_TABLE,
    get_fresh_awsauth,
    get_dynamodb_resource,
)
from batch_data_ingestion.core.helpers import truncate, print_header


# Chat source types to include
CHAT_SOURCE_TYPES = ["meeting_chat", "teams_chat"]


# ============================================================================
# OPENSEARCH CLEANUP
# ============================================================================

def get_all_chat_documents(limit: int = 2000) -> List[Dict]:
    """Get all chat documents from OpenSearch."""
    url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_search"
    
    body = {
        "size": limit,
        "query": {"terms": {"source_type": CHAT_SOURCE_TYPES}},
        "_source": ["evidence_id", "content_hash", "source_uri", "created_at", "project_name", "source_type"],
        "sort": [{"created_at": {"order": "asc"}}]
    }
    
    try:
        awsauth = get_fresh_awsauth()
        response = requests.post(
            url,
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            data=json.dumps(body)
        )
        
        if response.status_code != 200:
            print(f"❌ Error fetching documents: {response.status_code}")
            return []
        
        result = response.json()
        hits = result.get("hits", {}).get("hits", [])
        
        return [
            {"_id": hit["_id"], **hit["_source"]}
            for hit in hits
        ]
        
    except Exception as e:
        print(f"❌ Query failed: {e}")
        return []


def find_duplicate_chats(documents: List[Dict]) -> Dict[str, List[Dict]]:
    """Group documents by content_hash and find duplicates."""
    by_hash = defaultdict(list)
    
    for doc in documents:
        content_hash = doc.get("content_hash")
        if content_hash:
            by_hash[content_hash].append(doc)
    
    # Only return groups with more than one document
    return {
        hash_: docs 
        for hash_, docs in by_hash.items() 
        if len(docs) > 1
    }


def delete_opensearch_document(doc_id: str) -> bool:
    """Delete a document from OpenSearch by _id."""
    url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_doc/{doc_id}"
    
    try:
        awsauth = get_fresh_awsauth()
        response = requests.delete(
            url,
            auth=awsauth,
            headers={"Content-Type": "application/json"}
        )
        return response.status_code in [200, 204]
    except Exception as e:
        print(f"❌ Delete failed: {e}")
        return False


def delete_opensearch_by_query(query: Dict) -> int:
    """Delete documents matching a query.
    
    Note: OpenSearch Serverless may not support _delete_by_query reliably,
    so we first fetch document IDs, then delete individually.
    """
    # First, try the _delete_by_query API
    url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_delete_by_query"
    
    try:
        awsauth = get_fresh_awsauth()
        response = requests.post(
            url,
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            data=json.dumps({"query": query})
        )
        
        if response.status_code == 200:
            result = response.json()
            deleted_count = result.get("deleted", 0)
            if deleted_count > 0:
                return deleted_count
    except Exception as e:
        print(f"   ⚠️ _delete_by_query failed: {e}")
    
    # Fallback: fetch all matching documents and delete by ID
    print("   📋 Using fallback: delete by document ID...")
    search_url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_search"
    
    try:
        awsauth = get_fresh_awsauth()
        search_response = requests.post(
            search_url,
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            data=json.dumps({
                "size": 2000,
                "query": query,
                "_source": False
            })
        )
        
        if search_response.status_code != 200:
            print(f"   ❌ Search failed: {search_response.status_code}")
            return 0
        
        hits = search_response.json().get("hits", {}).get("hits", [])
        deleted_count = 0
        
        for hit in hits:
            doc_id = hit["_id"]
            if delete_opensearch_document(doc_id):
                deleted_count += 1
        
        return deleted_count
        
    except Exception as e:
        print(f"   ❌ Fallback delete failed: {e}")
        return 0


# ============================================================================
# DYNAMODB CLEANUP
# ============================================================================

def decimal_to_native(obj):
    """Convert DynamoDB Decimal to Python int/float."""
    if isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_native(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_native(v) for v in obj]
    return obj


def get_dynamodb_chat_items(table_name: str, limit: int = 2000) -> List[Dict]:
    """Get all chat items from a DynamoDB table."""
    dynamodb = get_dynamodb_resource()
    table = dynamodb.Table(table_name)
    
    items = []
    scan_kwargs = {
        "FilterExpression": Attr("source_type").is_in(CHAT_SOURCE_TYPES)
    }
    
    try:
        while len(items) < limit:
            response = table.scan(**scan_kwargs)
            items.extend(response.get("Items", []))
            
            last_key = response.get("LastEvaluatedKey")
            if not last_key:
                break
            scan_kwargs["ExclusiveStartKey"] = last_key
        
        return [decimal_to_native(item) for item in items[:limit]]
    except Exception as e:
        print(f"❌ Scan failed: {e}")
        return []


def delete_dynamodb_item(table_name: str, pk: str, sk: str) -> bool:
    """Delete an item from DynamoDB."""
    dynamodb = get_dynamodb_resource()
    table = dynamodb.Table(table_name)
    
    try:
        table.delete_item(Key={"PK": pk, "SK": sk})
        return True
    except Exception as e:
        print(f"❌ Delete failed: {e}")
        return False


def delete_dynamodb_chat_items(table_name: str, source_uri_filter: Optional[str] = None) -> int:
    """Delete chat items from DynamoDB."""
    items = get_dynamodb_chat_items(table_name)
    
    if source_uri_filter:
        items = [i for i in items if source_uri_filter in i.get("source_uri", "")]
    
    deleted = 0
    for item in items:
        pk = item.get("PK")
        sk = item.get("SK")
        if pk and sk:
            if delete_dynamodb_item(table_name, pk, sk):
                deleted += 1
    
    return deleted


# ============================================================================
# CLEANUP OPERATIONS
# ============================================================================

def cleanup_duplicates(dry_run: bool = True) -> Dict[str, Any]:
    """Find and remove duplicate chat documents."""
    print_header("🧹 CHAT DUPLICATE CLEANUP")
    print(f"   Mode: {'DRY RUN' if dry_run else '⚠️ DELETE'}")
    
    # Get all chat documents
    print("\n📂 Fetching chat documents...")
    documents = get_all_chat_documents()
    print(f"   Found {len(documents)} chat documents")
    
    # Find duplicates
    duplicates = find_duplicate_chats(documents)
    
    result = {
        "total_documents": len(documents),
        "duplicate_groups": len(duplicates),
        "duplicates_to_delete": sum(len(docs) - 1 for docs in duplicates.values()),
        "deleted": [],
        "dry_run": dry_run
    }
    
    if not duplicates:
        print("\n✅ No duplicates found!")
        return result
    
    print(f"\n⚠️ Found {len(duplicates)} content hashes with duplicates")
    print(f"   Total duplicates to delete: {result['duplicates_to_delete']}")
    
    for content_hash, docs in list(duplicates.items())[:5]:  # Show first 5
        print(f"\n   Hash: {content_hash[:20]}...")
        for idx, doc in enumerate(docs):
            marker = "✓ KEEP" if idx == 0 else "✗ DELETE"
            print(f"      {marker}: {doc.get('evidence_id')} - {truncate(doc.get('source_uri', ''), 40)}")
    
    if not dry_run:
        print("\n🗑️ Deleting duplicates...")
        for content_hash, docs in duplicates.items():
            # Keep the oldest (first), delete the rest
            for doc in docs[1:]:
                if delete_opensearch_document(doc["_id"]):
                    result["deleted"].append(doc["evidence_id"])
                    print(f"   ✅ Deleted: {doc['evidence_id']}")
        
        print(f"\n✅ Deleted {len(result['deleted'])} duplicate documents")
    
    return result


def cleanup_all(dry_run: bool = True, force: bool = False) -> Dict[str, Any]:
    """Delete all chat data from OpenSearch and DynamoDB."""
    print_header("🧹 DELETE ALL CHAT DATA")
    print(f"   Mode: {'DRY RUN' if dry_run else '⚠️ DELETE'}")
    
    result = {
        "opensearch_deleted": 0,
        "workitems_deleted": 0,
        "dry_run": dry_run
    }
    
    # Count documents
    documents = get_all_chat_documents()
    workitems = get_dynamodb_chat_items(DYNAMODB_WORK_ITEMS_TABLE)
    
    print(f"\n📊 Current Data:")
    print(f"   OpenSearch chats:    {len(documents)}")
    print(f"   WorkItems:           {len(workitems)}")
    
    if dry_run:
        print("\n[DRY RUN] Would delete all records above")
        return result
    
    if not force:
        print("\n⚠️ This will delete ALL chat data!")
        confirm = input("Type 'DELETE' to confirm: ")
        if confirm != "DELETE":
            print("❌ Aborted")
            return result
    
    # Delete from OpenSearch
    print("\n🗑️ Deleting from OpenSearch...")
    deleted = delete_opensearch_by_query({"terms": {"source_type": CHAT_SOURCE_TYPES}})
    result["opensearch_deleted"] = deleted
    print(f"   ✅ Deleted {deleted} documents")
    
    # Delete from WorkItems
    print("\n🗑️ Deleting from WorkItems...")
    deleted = delete_dynamodb_chat_items(DYNAMODB_WORK_ITEMS_TABLE)
    result["workitems_deleted"] = deleted
    print(f"   ✅ Deleted {deleted} items")
    
    return result


def cleanup_by_source_uri(source_uri: str, dry_run: bool = True) -> Dict[str, Any]:
    """Delete chat data matching a source_uri pattern."""
    print_header(f"🧹 CLEANUP BY SOURCE URI: {source_uri}")
    print(f"   Mode: {'DRY RUN' if dry_run else '⚠️ DELETE'}")
    
    result = {
        "source_uri_pattern": source_uri,
        "opensearch_deleted": 0,
        "workitems_deleted": 0,
        "dry_run": dry_run
    }
    
    # Find matching documents
    documents = get_all_chat_documents()
    matching_docs = [d for d in documents if source_uri in d.get("source_uri", "")]
    
    workitems = get_dynamodb_chat_items(DYNAMODB_WORK_ITEMS_TABLE)
    matching_workitems = [w for w in workitems if source_uri in w.get("source_uri", "")]
    
    print(f"\n📊 Matching Records:")
    print(f"   OpenSearch:   {len(matching_docs)}")
    print(f"   WorkItems:    {len(matching_workitems)}")
    
    if dry_run:
        print("\n[DRY RUN] Would delete records above")
        for doc in matching_docs[:5]:
            print(f"   - {doc.get('evidence_id')}: {truncate(doc.get('source_uri', ''), 50)}")
        return result
    
    # Delete from OpenSearch
    for doc in matching_docs:
        if delete_opensearch_document(doc["_id"]):
            result["opensearch_deleted"] += 1
    
    # Delete from WorkItems
    for item in matching_workitems:
        if delete_dynamodb_item(DYNAMODB_WORK_ITEMS_TABLE, item["PK"], item["SK"]):
            result["workitems_deleted"] += 1
    
    print(f"\n✅ Cleanup Complete:")
    print(f"   OpenSearch:   {result['opensearch_deleted']} deleted")
    print(f"   WorkItems:    {result['workitems_deleted']} deleted")
    
    return result


# ============================================================================
# CLI ENTRY POINT
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Cleanup chat data",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be deleted without actually deleting"
    )
    
    parser.add_argument(
        "--duplicates",
        action="store_true",
        help="Find and remove duplicate records only"
    )
    
    parser.add_argument(
        "--all",
        action="store_true",
        help="Delete all chat records"
    )
    
    parser.add_argument(
        "--force",
        action="store_true",
        help="Skip confirmation prompt for --all"
    )
    
    parser.add_argument(
        "--source-uri",
        type=str,
        help="Delete records matching source URI pattern"
    )
    
    parser.add_argument(
        "--evidence-id",
        type=str,
        help="Delete specific evidence ID"
    )
    
    args = parser.parse_args()
    
    # Default to dry_run unless --all or --duplicates without --dry-run
    dry_run = args.dry_run or not (args.all or args.duplicates or args.source_uri or args.evidence_id)
    
    if args.duplicates:
        cleanup_duplicates(dry_run=dry_run)
    elif args.all:
        cleanup_all(dry_run=dry_run, force=args.force)
    elif args.source_uri:
        cleanup_by_source_uri(args.source_uri, dry_run=dry_run)
    elif args.evidence_id:
        # Delete specific evidence_id
        print(f"Deleting evidence_id: {args.evidence_id}")
        if not dry_run:
            deleted = delete_opensearch_by_query({"term": {"evidence_id": args.evidence_id}})
            print(f"✅ Deleted {deleted} documents")
        else:
            print("[DRY RUN] Would delete this evidence_id")
    else:
        # Default: show duplicates in dry_run mode
        cleanup_duplicates(dry_run=True)


if __name__ == "__main__":
    main()
