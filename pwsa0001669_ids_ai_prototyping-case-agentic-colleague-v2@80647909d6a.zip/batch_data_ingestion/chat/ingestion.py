"""
Chat Data Ingestion Pipeline
============================
This module provides the main ingestion pipeline for meeting chat files.

It processes DOCX files from the S3 meetings/chats/ folder:
1. Extract text from DOCX files
2. Clean and structure with LLM (using teams_chat prompt)
3. Match to seeded projects
4. Generate embeddings
5. Index to OpenSearch
6. Write to DynamoDB (WorkItems - single source of truth)

Usage (run from project root folder):
    # Process chats from the new meetings/chats folder
    python -m batch_data_ingestion.chat.ingestion
    
    # Process with limit
    python -m batch_data_ingestion.chat.ingestion --limit 5
    
    # Dry run (no database writes)
    python -m batch_data_ingestion.chat.ingestion --dry-run
    
    # Verbose mode (see full pipeline output)
    python -m batch_data_ingestion.chat.ingestion --verbose --limit 1
    
    # Process legacy Teams_Chat folder
    python -m batch_data_ingestion.chat.ingestion --legacy
"""

import argparse
import os
import sys
from typing import Dict, List, Optional, Any

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_BATCH_DIR = os.path.dirname(_SCRIPT_DIR)
_PROJECT_ROOT = os.path.dirname(_BATCH_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

# Import core utilities
from batch_data_ingestion.core import (
    BUCKET_NAME,
    CHAT_PREFIX,
    OPENSEARCH_INDEX,
    DYNAMODB_WORK_ITEMS_TABLE,
    list_s3_files,
    get_source_type_for_folder,
    extract_text_from_s3_file,
    generate_content_hash,
    clean_text_with_llm,
    generate_embedding,
    load_seeded_projects,
    match_project_with_llm,
    build_work_evidence_doc,
    build_work_evidence_doc_with_chunks,
    index_to_opensearch,
    index_document_with_chunks,
    check_duplicate_in_opensearch,
    write_to_dynamodb,
    print_separator,
    print_section,
)


# ============================================================================
# CHAT INGESTION PIPELINE
# ============================================================================

def process_chat_folder(
    prefix: str = CHAT_PREFIX,
    dry_run: bool = False,
    limit: Optional[int] = None,
    skip_existing: bool = True,
    verbose: bool = False,
) -> Dict[str, int]:
    """
    Process all chat files in the S3 folder.
    
    Args:
        prefix: S3 prefix for chat files
        dry_run: If True, don't write to OpenSearch/DynamoDB
        limit: Maximum number of files to process
        skip_existing: Skip files that already exist in OpenSearch (dedup)
        verbose: If True, show detailed output at each step (implies dry_run)
    
    Returns:
        Statistics dict with counts
    """
    # Verbose mode implies dry_run (no DB writes)
    if verbose:
        dry_run = True
    
    source_type = get_source_type_for_folder(prefix)
    
    print(f"\n{'='*70}")
    print(f"💬 CHAT INGESTION PIPELINE {'(VERBOSE MODE - NO DB WRITES)' if verbose else ''}")
    print(f"{'='*70}")
    print(f"Bucket:      {BUCKET_NAME}")
    print(f"Prefix:      {prefix}")
    print(f"Source Type: {source_type}")
    print(f"Dry Run:     {dry_run}")
    print(f"Verbose:     {verbose}")
    print(f"Limit:       {limit or 'None'}")
    print(f"Skip Dupes:  {skip_existing}")
    print(f"{'='*70}\n")
    
    # =========================================================================
    # LOAD SEEDED PROJECTS (for project matching)
    # =========================================================================
    load_seeded_projects()
    
    # List files
    print("📂 Listing S3 files...")
    files = list_s3_files(BUCKET_NAME, prefix)
    print(f"   Found {len(files)} files")
    
    if limit:
        files = files[:limit]
        print(f"   Limited to {len(files)} files")
    
    # Statistics
    stats = {
        "total": len(files),
        "processed": 0,
        "skipped_duplicate": 0,
        "skipped_error": 0,
        "opensearch_indexed": 0,
        "dynamodb_items": 0
    }
    
    # Process each file
    for idx, key in enumerate(files, 1):
        filename = os.path.basename(key)
        
        if verbose:
            print(f"\n{'#'*70}")
            print(f"# FILE {idx}/{len(files)}: {filename}")
            print(f"# S3 Key: {key}")
            print(f"{'#'*70}")
        else:
            print(f"\n[{idx}/{len(files)}] 💬 {filename}")
        
        # =====================================================================
        # STEP 1: EXTRACT TEXT FROM S3 FILE
        # =====================================================================
        print("  1️⃣ Extracting text...")
        raw_text = extract_text_from_s3_file(BUCKET_NAME, key)
        
        if not raw_text or not raw_text.strip():
            print("     ❌ No text extracted, skipping")
            stats["skipped_error"] += 1
            continue
        
        print(f"     ✅ Extracted {len(raw_text)} chars")
        
        if verbose:
            print_section("RAW EXTRACTED TEXT", raw_text, max_length=1000)
        
        # =====================================================================
        # STEP 2: GENERATE CONTENT HASH & CHECK DUPLICATES
        # =====================================================================
        content_hash = generate_content_hash(raw_text)
        source_uri = f"s3://{BUCKET_NAME}/{key}"
        
        if verbose:
            print(f"\n  2️⃣ Content Hash: {content_hash}")
        
        if skip_existing and not dry_run:
            # Check for duplicates by both content hash AND source URI
            # This catches re-uploads of the same file even if content changed slightly
            if check_duplicate_in_opensearch(content_hash, source_uri):
                print("     ⏭️ Duplicate found, skipping")
                stats["skipped_duplicate"] += 1
                continue
        
        # =====================================================================
        # STEP 3: CLEAN WITH LLM (with chunk info for multi-vector embedding)
        # =====================================================================
        print("  3️⃣ Cleaning with LLM...")
        # Use meeting_chat source type for chat-specific cleaning
        cleaned_json = clean_text_with_llm(raw_text, source_type, return_chunks=True)
        summary = cleaned_json.get("summary", raw_text[:300])
        
        action_items = cleaned_json.get("action_items", [])
        decisions = cleaned_json.get("decisions", [])
        entities = cleaned_json.get("entities", {})
        
        print(f"     ✅ Cleaned successfully")
        print(f"        - Action Items: {len(action_items)}")
        print(f"        - Decisions:    {len(decisions)}")
        print(f"        - People:       {len(entities.get('people', []))}")
        print(f"        - Projects:     {len(entities.get('projects', []))}")
        
        if verbose:
            print_section("CLEANED JSON - Full Structure", cleaned_json, max_length=2000)
            print_section("SUMMARY", summary, max_length=500)
            print_section("CLEAN TEXT", cleaned_json.get("clean_text", ""), max_length=1000)
            
            if action_items:
                print_section("ACTION ITEMS DETECTED", action_items, max_length=1500)
            
            if decisions:
                print_section("DECISIONS DETECTED", decisions, max_length=1000)
            
            if entities:
                print_section("ENTITIES EXTRACTED", entities, max_length=1000)
        
        # =====================================================================
        # STEP 3.5: MATCH PROJECT TO SEEDED PROJECTS
        # =====================================================================
        print("  3️⃣.5️⃣ Matching project to seeded projects...")
        detected_projects = entities.get("projects", [])
        matched_project = match_project_with_llm(
            detected_projects=detected_projects,
            content_summary=summary,
            verbose=verbose
        )
        
        if matched_project.get("is_new_project"):
            print(f"     ⚠️ No match found - would create new project: {matched_project.get('project_name')}")
        else:
            print(f"     ✅ Matched to: {matched_project.get('project_name')} ({matched_project.get('project_id')})")
            print(f"        Confidence: {matched_project.get('match_confidence')}")
        
        if verbose:
            print_section("PROJECT MATCHING RESULT", matched_project, max_length=500)
        
        # =====================================================================
        # STEP 4: GENERATE EMBEDDINGS (Multi-Vector for full document coverage)
        # =====================================================================
        print("  4️⃣ Generating embeddings...")
        
        # Get chunks from cleaned_json metadata (set by return_chunks=True)
        chunks_info = cleaned_json.get("metadata", {}).get("chunks", [])
        
        if not chunks_info:
            # Fallback: single chunk for the whole document
            chunks_info = [{"text": cleaned_json.get("clean_text", raw_text), "start": 0, "end": len(raw_text)}]
        
        # Generate embedding for each chunk
        chunk_embeddings = []
        for idx, chunk_info in enumerate(chunks_info):
            chunk_text = chunk_info["text"]
            # Truncate each chunk to embedding model limit (each chunk is already ~6000 chars)
            embedding_input = chunk_text[:8000]
            embedding = generate_embedding(embedding_input)
            chunk_embeddings.append((chunk_text, embedding, chunk_info["start"], chunk_info["end"]))
            
            if len(chunks_info) > 1:
                print(f"        Chunk {idx + 1}/{len(chunks_info)}: {len(embedding)}-dim embedding")
        
        print(f"     ✅ Generated {len(chunk_embeddings)} embeddings (1 per chunk)")
        
        if verbose:
            print(f"\n  📊 EMBEDDING SUMMARY:")
            print(f"     Total chunks: {len(chunk_embeddings)}")
            for idx, (chunk_text, emb, start, end) in enumerate(chunk_embeddings):
                print(f"     Chunk {idx}: chars {start}-{end}, {len(emb)}-dim vector")
                print(f"        First 3 dims: {emb[:3]}")
        
        # =====================================================================
        # STEP 5: BUILD OPENSEARCH DOCUMENTS (Parent + Chunks)
        # =====================================================================
        source_uri = f"s3://{BUCKET_NAME}/{key}"
        
        if len(chunk_embeddings) > 1:
            # Multi-vector mode: create parent doc + chunk docs
            print("  5️⃣ Building OpenSearch documents (multi-vector mode)...")
            parent_doc, chunk_docs = build_work_evidence_doc_with_chunks(
                cleaned_json=cleaned_json,
                source_uri=source_uri,
                source_type=source_type,
                content_hash=content_hash,
                chunk_embeddings=chunk_embeddings,
                matched_project=matched_project
            )
            print(f"     ✅ Built 1 parent doc + {len(chunk_docs)} chunk docs")
            
            if verbose:
                parent_display = {k: v for k, v in parent_doc.items() if k != "vector_embedding"}
                parent_display["vector_embedding"] = f"<{len(chunk_embeddings[0][1])}-dim vector>"
                print_section("PARENT DOCUMENT", parent_display, max_length=2000)
                print(f"\n     CHUNK DOCUMENTS: {len(chunk_docs)} documents")
        else:
            # Single chunk: use original method for backward compatibility
            print("  5️⃣ Building OpenSearch document (single-vector mode)...")
            parent_doc = build_work_evidence_doc(
                cleaned_json=cleaned_json,
                source_uri=source_uri,
                source_type=source_type,
                content_hash=content_hash,
                embedding=chunk_embeddings[0][1],
                matched_project=matched_project
            )
            chunk_docs = []
            
            if verbose:
                os_doc_display = {k: v for k, v in parent_doc.items() if k != "vector_embedding"}
                os_doc_display["vector_embedding"] = f"<{len(chunk_embeddings[0][1])}-dim vector>"
                print_section("OPENSEARCH DOCUMENT (ready to index)", os_doc_display, max_length=2500)
        
        # =====================================================================
        # STEP 6: INDEX TO OPENSEARCH
        # =====================================================================
        if dry_run:
            print("  6️⃣ [DRY RUN] Would index to OpenSearch")
            if verbose:
                print(f"     → Index: {OPENSEARCH_INDEX}")
                print(f"     → Documents: 1 parent + {len(chunk_docs)} chunks")
        else:
            print("  6️⃣ Indexing to OpenSearch...")
            
            if chunk_docs:
                # Multi-vector mode
                idx_result = index_document_with_chunks(parent_doc, chunk_docs)
                if idx_result["parent_indexed"]:
                    print(f"     ✅ Parent indexed")
                    stats["opensearch_indexed"] += 1
                print(f"     ✅ Chunks indexed: {idx_result['chunks_indexed']}/{idx_result['total_chunks']}")
                stats["opensearch_indexed"] += idx_result["chunks_indexed"]
                if idx_result["errors"]:
                    print(f"     ⚠️ Errors: {idx_result['errors'][:3]}")
            else:
                # Single-vector mode
                os_result = index_to_opensearch(parent_doc)
                if os_result["status_code"] in [200, 201]:
                    print(f"     ✅ Indexed (status: {os_result['status_code']})")
                    stats["opensearch_indexed"] += 1
                else:
                    print(f"     ⚠️ Index failed: {os_result['status_code']} - {os_result['text'][:100]}")
            
            # Small delay to ensure OpenSearch refresh completes before next iteration
            # This helps prevent duplicate detection failures in rapid processing
            import time
            time.sleep(0.5)
        
        # =====================================================================
        # STEP 7: WRITE TO DYNAMODB
        # =====================================================================
        if dry_run:
            print("  6️⃣ [DRY RUN] Would write to DynamoDB")
            if verbose:
                print(f"     → Table: {DYNAMODB_WORK_ITEMS_TABLE}")
                print(f"     → Would create {len(action_items)} work items")
                print(f"     → Project: {matched_project.get('project_name')} ({matched_project.get('project_id') or 'NEW'})")
        else:
            print("  6️⃣ Writing to DynamoDB...")
            db_count = write_to_dynamodb(
                cleaned_json=cleaned_json,
                source_uri=source_uri,
                source_type=source_type,
                summary=summary,
                matched_project=matched_project
            )
            print(f"     ✅ Wrote {db_count} work items")
            stats["dynamodb_items"] += db_count
        
        stats["processed"] += 1
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"✅ FILE {idx} PROCESSING COMPLETE")
            print(f"{'='*70}")
    
    # Print summary
    print(f"\n{'='*60}")
    print("📊 CHAT INGESTION SUMMARY")
    print(f"{'='*60}")
    print(f"Total files found:     {stats['total']}")
    print(f"Successfully processed:{stats['processed']}")
    print(f"Skipped (duplicate):   {stats['skipped_duplicate']}")
    print(f"Skipped (error):       {stats['skipped_error']}")
    print(f"OpenSearch indexed:    {stats['opensearch_indexed']}")
    print(f"DynamoDB items:        {stats['dynamodb_items']}")
    print(f"{'='*60}\n")
    
    return stats


# ============================================================================
# CLI ENTRY POINT
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Chat Data Ingestion Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples (run from project root folder):
  # Process chats from meetings/chats/ folder
  python -m batch_data_ingestion.chat.ingestion
  
  # Dry run - no database writes
  python -m batch_data_ingestion.chat.ingestion --dry-run
  
  # Limit number of files
  python -m batch_data_ingestion.chat.ingestion --limit 10
  
  # VERBOSE MODE - See full pipeline details (no DB writes)
  python -m batch_data_ingestion.chat.ingestion --verbose --limit 1
  
  # Process legacy Teams_Chat folder
  python -m batch_data_ingestion.chat.ingestion --legacy
  
  # Force re-index (don't skip duplicates)
  python -m batch_data_ingestion.chat.ingestion --no-skip-existing
        """
    )
    
    parser.add_argument(
        "--prefix",
        type=str,
        default=CHAT_PREFIX,
        help=f"S3 prefix to process (default: {CHAT_PREFIX})"
    )
    
    parser.add_argument(
        "--legacy",
        action="store_true",
        help="Process legacy Teams_Chat/ folder instead of meetings/chats/"
    )
    
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Don't write to OpenSearch/DynamoDB, just show what would happen"
    )
    
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show detailed output at each pipeline step (implies --dry-run)"
    )
    
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Maximum number of files to process"
    )
    
    parser.add_argument(
        "--no-skip-existing",
        action="store_true",
        help="Don't skip files that already exist in OpenSearch"
    )
    
    args = parser.parse_args()
    
    # Determine prefix
    prefix = args.prefix
    if args.legacy:
        prefix = "Agentic-Colleague-synthetic/Teams_Chat/"
    
    # Ensure prefix ends with /
    if not prefix.endswith("/"):
        prefix += "/"
    
    process_chat_folder(
        prefix=prefix,
        dry_run=args.dry_run,
        limit=args.limit,
        skip_existing=not args.no_skip_existing,
        verbose=args.verbose
    )


if __name__ == "__main__":
    main()
