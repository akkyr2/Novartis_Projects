"""
Chat Pipeline Module
====================
Data ingestion pipeline for meeting chat files.

This module provides:
- Chat ingestion (S3 -> OpenSearch + DynamoDB)
- Verification scripts
- Cleanup utilities

Usage:
    # Run ingestion
    python -m batch_data_ingestion.chat.ingestion
    
    # Verify data
    python -m batch_data_ingestion.chat.verify
    
    # Cleanup
    python -m batch_data_ingestion.chat.cleanup --dry-run
"""

from .ingestion import process_chat_folder

__all__ = [
    "process_chat_folder",
]
