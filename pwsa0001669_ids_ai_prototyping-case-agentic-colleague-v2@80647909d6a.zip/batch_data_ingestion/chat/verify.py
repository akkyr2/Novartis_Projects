"""
Chat Verification Script
========================
Verify ingested chat data in OpenSearch and WorkItems.

Usage (run from project root folder):
    # Show all verification stats
    python -m batch_data_ingestion.chat.verify
    
    # Verify specific source_uri
    python -m batch_data_ingestion.chat.verify --source-uri "chat"
    
    # Search by project
    python -m batch_data_ingestion.chat.verify --project "Noventra"
    
    # Show OpenSearch records
    python -m batch_data_ingestion.chat.verify --opensearch --limit 10
    
    # Show WorkItems records
    python -m batch_data_ingestion.chat.verify --workitems --limit 10
    
    # Export to JSON
    python -m batch_data_ingestion.chat.verify --export results.json
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from typing import Any, Dict, List, Optional

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_BATCH_DIR = os.path.dirname(_SCRIPT_DIR)
_PROJECT_ROOT = os.path.dirname(_BATCH_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
import requests
from boto3.dynamodb.conditions import Key, Attr

from config import settings
from batch_data_ingestion.core import (
    BUCKET_NAME,
    CHAT_PREFIX,
    OPENSEARCH_HOST,
    OPENSEARCH_INDEX,
    DYNAMODB_WORK_ITEMS_TABLE,
    get_fresh_awsauth,
    get_dynamodb_resource,
)
from batch_data_ingestion.core.helpers import truncate, print_header, print_separator


# Chat source types to include
CHAT_SOURCE_TYPES = ["meeting_chat", "teams_chat"]


# ============================================================================
# OPENSEARCH VERIFICATION
# ============================================================================

def get_opensearch_chat_records(
    source_uri_filter: Optional[str] = None,
    project_filter: Optional[str] = None,
    limit: int = 20
) -> List[Dict]:
    """Get chat records from OpenSearch."""
    url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_search"
    
    # Build query for chat source types
    must_clauses = [
        {"terms": {"source_type": CHAT_SOURCE_TYPES}}
    ]
    
    if source_uri_filter:
        must_clauses.append({"wildcard": {"source_uri": f"*{source_uri_filter}*"}})
    
    if project_filter:
        must_clauses.append({
            "bool": {
                "should": [
                    {"wildcard": {"project_name": f"*{project_filter}*"}},
                    {"match": {"metadata.entities.projects": project_filter}}
                ]
            }
        })
    
    body = {
        "size": limit,
        "query": {"bool": {"must": must_clauses}},
        "_source": {
            "excludes": ["vector_embedding"]
        },
        "sort": [{"created_at": {"order": "desc"}}]
    }
    
    try:
        awsauth = get_fresh_awsauth()
        response = requests.post(
            url,
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            data=json.dumps(body)
        )
        
        if response.status_code != 200:
            print(f"❌ OpenSearch query failed: {response.status_code}")
            return []
        
        result = response.json()
        hits = result.get("hits", {}).get("hits", [])
        return [hit["_source"] for hit in hits]
        
    except Exception as e:
        print(f"❌ OpenSearch error: {e}")
        return []


def get_opensearch_stats() -> Dict[str, Any]:
    """Get chat-specific statistics from OpenSearch."""
    url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_search"
    
    body = {
        "size": 0,
        "query": {"terms": {"source_type": CHAT_SOURCE_TYPES}},
        "aggs": {
            "total_count": {"value_count": {"field": "evidence_id"}},
            "by_project": {
                "terms": {"field": "project_name", "size": 50}
            },
            "by_source_type": {
                "terms": {"field": "source_type", "size": 10}
            }
        }
    }
    
    try:
        awsauth = get_fresh_awsauth()
        response = requests.post(
            url,
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            data=json.dumps(body)
        )
        
        if response.status_code != 200:
            return {"error": f"HTTP {response.status_code}"}
        
        result = response.json()
        aggs = result.get("aggregations", {})
        
        return {
            "total_chats": result.get("hits", {}).get("total", {}).get("value", 0),
            "by_source_type": [
                {"type": b["key"], "count": b["doc_count"]}
                for b in aggs.get("by_source_type", {}).get("buckets", [])
            ],
            "projects": [
                {"name": b["key"], "count": b["doc_count"]}
                for b in aggs.get("by_project", {}).get("buckets", [])
            ]
        }
        
    except Exception as e:
        return {"error": str(e)}


# ============================================================================
# DYNAMODB VERIFICATION
# ============================================================================

def decimal_to_native(obj):
    """Convert DynamoDB Decimal to Python int/float."""
    if isinstance(obj, Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_native(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_native(v) for v in obj]
    return obj


def get_workitems_chat_records(
    source_uri_filter: Optional[str] = None,
    project_filter: Optional[str] = None,
    limit: int = 20
) -> List[Dict]:
    """Get chat-related work items from DynamoDB."""
    dynamodb = get_dynamodb_resource()
    table = dynamodb.Table(DYNAMODB_WORK_ITEMS_TABLE)
    
    # Build filter expression for chat source types
    filter_expressions = [
        Attr("source_type").is_in(CHAT_SOURCE_TYPES)
    ]
    
    if source_uri_filter:
        filter_expressions.append(Attr("source_uri").contains(source_uri_filter))
    
    if project_filter:
        filter_expressions.append(Attr("project_name").contains(project_filter))
    
    # Combine filters
    combined_filter = filter_expressions[0]
    for f in filter_expressions[1:]:
        combined_filter = combined_filter & f
    
    try:
        items = []
        scan_kwargs = {"FilterExpression": combined_filter}
        
        while len(items) < limit:
            response = table.scan(**scan_kwargs)
            items.extend(response.get("Items", []))
            
            last_key = response.get("LastEvaluatedKey")
            if not last_key:
                break
            scan_kwargs["ExclusiveStartKey"] = last_key
        
        return [decimal_to_native(item) for item in items[:limit]]
        
    except Exception as e:
        print(f"❌ WorkItems query failed: {e}")
        return []





# ============================================================================
# DISPLAY FUNCTIONS
# ============================================================================

def display_opensearch_records(records: List[Dict], full: bool = False):
    """Display OpenSearch records in formatted output."""
    if not records:
        print("   No records found")
        return
    
    for idx, rec in enumerate(records, 1):
        print(f"\n   [{idx}] {rec.get('evidence_id', 'N/A')}")
        print(f"       Project Name:    {rec.get('project_name', 'N/A')}")
        print(f"       Project ID:      {rec.get('project_id', 'N/A')}")
        print(f"       Workspace ID:    {rec.get('workspace_id', 'N/A')}")
        print(f"       Source Type:     {rec.get('source_type', 'N/A')}")
        print(f"       Source URI:      {rec.get('source_uri', 'N/A')}")
        print(f"       Content Hash:    {rec.get('content_hash', 'N/A')}")
        print(f"       Created At:      {rec.get('created_at', 'N/A')}")
        print(f"       Updated At:      {rec.get('updated_at', 'N/A')}")
        print(f"       Summary:         {rec.get('summary', 'N/A')}")
        
        # Text fields - truncate only if not full mode
        if full:
            print(f"       Raw Text:        {rec.get('raw_text', 'N/A')}")
            print(f"       Clean Text:      {rec.get('clean_text', 'N/A')}")
            print(f"       Embedding Text:  {rec.get('embedding_text', 'N/A')}")
        else:
            print(f"       Raw Text:        {truncate(rec.get('raw_text', ''), 300)}")
            print(f"       Clean Text:      {truncate(rec.get('clean_text', ''), 300)}")
            print(f"       Embedding Text:  {truncate(rec.get('embedding_text', ''), 300)}")
        
        # Linked work items
        linked_ids = rec.get('linked_work_item_ids', [])
        print(f"       Linked Work Items: {linked_ids if linked_ids else 'None'}")
        
        # Action items detected
        action_items = rec.get('action_items_detected', [])
        print(f"       Action Items ({len(action_items)}):")
        if action_items:
            for ai_idx, ai in enumerate(action_items, 1):
                print(f"         [{ai_idx}] Title:       {ai.get('title', 'N/A')}")
                print(f"             Description: {ai.get('description', 'N/A')}")
                print(f"             Owner:       {ai.get('owner', 'N/A')}")
                print(f"             Due Date:    {ai.get('due_date', 'N/A')}")
                print(f"             Status:      {ai.get('status', 'N/A')}")
                print(f"             Confidence:  {ai.get('confidence', 'N/A')}")
        else:
            print("           None")
        
        # Decisions detected
        decisions = rec.get('decisions_detected', [])
        print(f"       Decisions ({len(decisions)}):")
        if decisions:
            for dec_idx, dec in enumerate(decisions, 1):
                print(f"         [{dec_idx}] Decision:   {dec.get('decision', 'N/A')}")
                print(f"             Confidence: {dec.get('confidence', 'N/A')}")
        else:
            print("           None")
        
        # Dates detected
        dates = rec.get('dates_detected', [])
        print(f"       Dates Detected:  {dates if dates else 'None'}")
        
        # Metadata section
        metadata = rec.get('metadata', {})
        print(f"       Metadata:")
        print(f"         Source URI:      {metadata.get('source_uri', 'N/A')}")
        entities = metadata.get('entities', {})
        print(f"         Entities:")
        print(f"           People:        {entities.get('people', [])}")
        print(f"           Projects:      {entities.get('projects', [])}")
        print(f"           Dates:         {entities.get('dates', [])}")
        matched_proj = metadata.get('matched_project', {})
        print(f"         Matched Project: {matched_proj if matched_proj else 'None'}")
        
        # Check for any additional fields not explicitly handled
        known_fields = {
            'evidence_id', 'project_name', 'project_id', 'workspace_id', 'source_type',
            'source_uri', 'content_hash', 'created_at', 'updated_at', 'summary',
            'raw_text', 'clean_text', 'embedding_text', 'linked_work_item_ids',
            'action_items_detected', 'decisions_detected', 'dates_detected', 'metadata',
            'vector_embedding'
        }
        extra_fields = set(rec.keys()) - known_fields
        if extra_fields:
            print(f"       Additional Fields:")
            for field in sorted(extra_fields):
                print(f"         {field}: {rec.get(field, 'N/A')}")
        
        print(f"       {'─'*60}")


def display_workitems_records(records: List[Dict], full: bool = False):
    """Display WorkItems records in formatted output."""
    if not records:
        print("   No records found")
        return
    
    for idx, rec in enumerate(records, 1):
        print(f"\n   [{idx}] {rec.get('work_item_id', 'N/A')}")
        print(f"       PK:              {rec.get('PK', 'N/A')}")
        print(f"       SK:              {rec.get('SK', 'N/A')}")
        print(f"       Project Name:    {rec.get('project_name', 'N/A')}")
        print(f"       Project ID:      {rec.get('project_id', 'N/A')}")
        print(f"       Task:            {rec.get('task', 'N/A')}")
        print(f"       Assignee:        {rec.get('assignee', 'N/A')}")
        print(f"       Assigned To:     {rec.get('assigned_to', 'N/A')}")
        print(f"       Status:          {rec.get('status', 'N/A')}")
        print(f"       Due Date:        {rec.get('due_date', 'N/A')}")
        print(f"       Source Type:     {rec.get('source_type', 'N/A')}")
        print(f"       Source URI:      {rec.get('source_uri', 'N/A')}")
        print(f"       Summary:         {rec.get('summary', 'N/A')}")
        print(f"       Evidence ID:     {rec.get('evidence_id', 'N/A')}")
        print(f"       Event Timestamp: {rec.get('event_timestamp', 'N/A')}")
        
        # Task evidence - truncate only if not full mode
        if full:
            print(f"       Task Evidence:   {rec.get('task_evidence', 'N/A')}")
        else:
            print(f"       Task Evidence:   {truncate(rec.get('task_evidence', ''), 300)}")
        
        # Check for any additional fields not explicitly handled
        known_fields = {
            'PK', 'SK', 'work_item_id', 'project_name', 'project_id', 'task',
            'assignee', 'assigned_to', 'status', 'due_date', 'source_type',
            'source_uri', 'summary', 'evidence_id', 'event_timestamp', 'task_evidence'
        }
        extra_fields = set(rec.keys()) - known_fields
        if extra_fields:
            print(f"       Additional Fields:")
            for field in sorted(extra_fields):
                value = rec.get(field, 'N/A')
                if full:
                    print(f"         {field}: {value}")
                else:
                    print(f"         {field}: {truncate(str(value), 200) if isinstance(value, str) else value}")
        
        print(f"       {'─'*60}")





# ============================================================================
# MAIN VERIFICATION
# ============================================================================

def run_verification(
    source_uri: Optional[str] = None,
    project: Optional[str] = None,
    show_opensearch: bool = True,
    show_workitems: bool = True,
    limit: int = 10,
    full: bool = False,
    export_file: Optional[str] = None
):
    """Run comprehensive chat verification."""
    
    print_header("💬 CHAT DATA VERIFICATION")
    print(f"   Source Filter: {source_uri or 'None'}")
    print(f"   Project Filter: {project or 'None'}")
    print(f"   Limit: {limit}")
    
    results = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "filters": {
            "source_uri": source_uri,
            "project": project
        }
    }
    
    # OpenSearch Stats
    if show_opensearch:
        print("\n" + "="*60)
        print("📊 OPENSEARCH CHAT STATISTICS")
        print("="*60)
        
        stats = get_opensearch_stats()
        if "error" not in stats:
            print(f"   Total Chats: {stats['total_chats']}")
            print(f"\n   By Source Type:")
            for st in stats.get("by_source_type", []):
                print(f"      - {st['type']}: {st['count']}")
            print(f"\n   By Project:")
            for proj in stats.get("projects", [])[:10]:
                print(f"      - {proj['name']}: {proj['count']}")
        else:
            print(f"   Error: {stats['error']}")
        
        results["opensearch_stats"] = stats
        
        print("\n   Recent Records:")
        records = get_opensearch_chat_records(source_uri, project, limit)
        display_opensearch_records(records, full)
        results["opensearch_records"] = records
    
    # WorkItems
    if show_workitems:
        print("\n" + "="*60)
        print("📋 WORKITEMS CHAT RECORDS")
        print("="*60)
        
        records = get_workitems_chat_records(source_uri, project, limit)
        print(f"   Found: {len(records)} records")
        display_workitems_records(records, full)
        results["workitems_records"] = records
    
    # Export
    if export_file:
        with open(export_file, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, default=str)
        print(f"\n✅ Results exported to: {export_file}")
    
    print("\n" + "="*60)


# ============================================================================
# CLI ENTRY POINT
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Verify ingested chat data",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        "--source-uri",
        type=str,
        help="Filter by source URI pattern"
    )
    
    parser.add_argument(
        "--project",
        type=str,
        help="Filter by project name"
    )
    
    parser.add_argument(
        "--opensearch",
        action="store_true",
        help="Show only OpenSearch records"
    )
    
    parser.add_argument(
        "--workitems",
        action="store_true",
        help="Show only WorkItems records"
    )
    
    parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Maximum records to show (default: 10)"
    )
    
    parser.add_argument(
        "--full",
        action="store_true",
        help="Show full record details"
    )
    
    parser.add_argument(
        "--export",
        type=str,
        help="Export results to JSON file"
    )
    
    args = parser.parse_args()
    
    # If specific stores are selected, show only those
    show_opensearch = True
    show_workitems = True
    
    if args.opensearch or args.workitems:
        show_opensearch = args.opensearch
        show_workitems = args.workitems
    
    run_verification(
        source_uri=args.source_uri,
        project=args.project,
        show_opensearch=show_opensearch,
        show_workitems=show_workitems,
        limit=args.limit,
        full=args.full,
        export_file=args.export
    )


if __name__ == "__main__":
    main()
