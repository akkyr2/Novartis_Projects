# Batch Data Ingestion API - Test Guide

This document provides test data and examples for testing all batch ingestion API endpoints via Swagger UI.

**Base URL:** `http://localhost:7007`  
**Swagger UI:** `http://localhost:7007/docs`

---

## Table of Contents

1. [GET /ingestion/config](#1-get-ingestionconfig)
2. [GET /ingestion/folders](#2-get-ingestionfolders)
3. [GET /ingestion/files/{folder}](#3-get-ingestionfilesfolder)
4. [GET /ingestion/status](#4-get-ingestionstatus)
5. [POST /ingestion/run](#5-post-ingestionrun)
6. [POST /ingestion/run-all](#6-post-ingestionrun-all)
7. [POST /ingestion/process-file](#7-post-ingestionprocess-file)
8. [POST /ingestion/check-duplicate](#8-post-ingestioncheck-duplicate)
9. [POST /ingestion/extract-text](#9-post-ingestionextract-text)
10. [POST /ingestion/clean-text](#10-post-ingestionclean-text)
11. [POST /ingestion/generate-embedding](#11-post-ingestiongenerate-embedding)

---

## 1. GET /ingestion/config

**Description:** Get pipeline configuration (bucket, tables, available folders)

**Request:** No parameters required

**Expected Response:**
```json
{
  "bucket_name": "ids-aini-prototype-ai-analytics",
  "base_prefix": "Agentic-Colleague-synthetic/",
  "opensearch_index": "work_evidence_test",
  "dynamodb_work_items_table": "AgenticColleague_WorkItems_Test",
  "available_folders": [
    "transcripts",
    "Transcribe_Data",
    "Outlook_emails",
    "Teams_Chat",
    "Team_Channels"
  ],
  "folder_source_type_mapping": {
    "transcripts": "meeting_transcript",
    "Transcribe_Data": "meeting_transcript",
    "Outlook_emails": "email",
    "Teams_Chat": "teams_chat",
    "Team_Channels": "teams_channel_post"
  }
}
```

---

## 2. GET /ingestion/folders

**Description:** List all available S3 folders for ingestion

**Request:** No parameters required

**Expected Response:**
```json
{
  "bucket": "ids-aini-prototype-ai-analytics",
  "base_prefix": "Agentic-Colleague-synthetic/",
  "folders": [
    {
      "folder": "transcripts",
      "source_type": "meeting_transcript",
      "full_prefix": "Agentic-Colleague-synthetic/transcripts/"
    },
    {
      "folder": "Transcribe_Data",
      "source_type": "meeting_transcript",
      "full_prefix": "Agentic-Colleague-synthetic/Transcribe_Data/"
    },
    {
      "folder": "Outlook_emails",
      "source_type": "email",
      "full_prefix": "Agentic-Colleague-synthetic/Outlook_emails/"
    },
    {
      "folder": "Teams_Chat",
      "source_type": "teams_chat",
      "full_prefix": "Agentic-Colleague-synthetic/Teams_Chat/"
    },
    {
      "folder": "Team_Channels",
      "source_type": "teams_channel_post",
      "full_prefix": "Agentic-Colleague-synthetic/Team_Channels/"
    }
  ]
}
```

---

## 3. GET /ingestion/files/{folder}

**Description:** List files in an S3 folder

### Test Case 3.1: List transcripts (no limit)
**Parameters:**
- `folder`: `transcripts`
- `limit`: (leave empty)

### Test Case 3.2: List Outlook_emails with limit
**Parameters:**
- `folder`: `Outlook_emails`
- `limit`: `5`

### Test Case 3.3: List Teams_Chat
**Parameters:**
- `folder`: `Teams_Chat`
- `limit`: `10`

### Test Case 3.4: List Team_Channels
**Parameters:**
- `folder`: `Team_Channels`
- `limit`: `3`

### Test Case 3.5: List Transcribe_Data
**Parameters:**
- `folder`: `Transcribe_Data`
- `limit`: `2`

---

## 4. GET /ingestion/status

**Description:** Get pipeline status and file counts for all folders

**Request:** No parameters required

**Expected Response:** Shows file counts and status for each folder

---

## 5. POST /ingestion/run

**Description:** Main endpoint to trigger batch ingestion pipeline

> **Note:** The `limit` parameter is **optional**. If omitted or set to `null`, ALL files in the folder will be processed.

### Test Case 5.1: Dry Run - Transcripts (Process ALL Files)
```json
{
  "folder": "transcripts",
  "dry_run": true,
  "verbose": false,
  "skip_existing": true
}
```

### Test Case 5.2: Verbose Mode - Outlook Emails (Process ALL with Details)
```json
{
  "folder": "Outlook_emails",
  "dry_run": true,
  "verbose": true,
  "skip_existing": true
}
```

### Test Case 5.3: Dry Run - Teams Chat (Process ALL Files)
```json
{
  "folder": "Teams_Chat",
  "dry_run": true,
  "verbose": false,
  "skip_existing": true
}
```

### Test Case 5.4: Dry Run - Team Channels (Process ALL Files)
```json
{
  "folder": "Team_Channels",
  "dry_run": true,
  "verbose": false,
  "skip_existing": true
}
```

### Test Case 5.5: Dry Run - Transcribe Data (Process ALL Files)
```json
{
  "folder": "Transcribe_Data",
  "dry_run": true,
  "verbose": false,
  "skip_existing": true
}
```

### Test Case 5.6: ACTUAL RUN - Transcripts (Writes ALL to DB)
⚠️ **WARNING: This will write ALL files to OpenSearch and DynamoDB**
```json
{
  "folder": "transcripts",
  "dry_run": false,
  "verbose": false,
  "skip_existing": true
}
```

### Test Case 5.7: Force Re-index (Skip Duplicate Check, Process ALL)
```json
{
  "folder": "Outlook_emails",
  "dry_run": true,
  "verbose": false,
  "skip_existing": false
}
```

### Test Case 5.8: With Optional Limit (Process Only First N Files)
> Use this if you want to limit processing to a specific number of files
```json
{
  "folder": "transcripts",
  "dry_run": true,
  "verbose": false,
  "limit": 5,
  "skip_existing": true
}
```

---

## 6. POST /ingestion/run-all

**Description:** Process all available S3 folders sequentially

> **Note:** The `limit_per_folder` parameter is **optional**. If omitted, ALL files in each folder will be processed.

### Test Case 6.1: Dry Run All Folders (Process ALL Files)
**Query Parameters:**
- `dry_run`: `true`
- `skip_existing`: `true`

> Leave `limit_per_folder` empty to process all files in each folder.

### Test Case 6.2: Dry Run All Folders (With Optional Limit)
**Query Parameters:**
- `dry_run`: `true`
- `limit_per_folder`: `5`
- `skip_existing`: `true`

> Use `limit_per_folder` only if you want to restrict the number of files processed per folder.

---

## 7. POST /ingestion/process-file

**Description:** Process a single S3 file through the pipeline

### Test Case 7.1: Process Single Transcript File (Dry Run)
```json
{
  "s3_key": "Agentic-Colleague-synthetic/transcripts/meeting_transcript_001.docx",
  "dry_run": true
}
```

### Test Case 7.2: Process Single Email File (Dry Run)
```json
{
  "s3_key": "Agentic-Colleague-synthetic/Outlook_emails/email_001.eml",
  "dry_run": true
}
```

### Test Case 7.3: Process Single Teams Chat File (Dry Run)
```json
{
  "s3_key": "Agentic-Colleague-synthetic/Teams_Chat/chat_001.txt",
  "dry_run": true
}
```

> **Note:** Replace the `s3_key` values with actual file paths from the `/ingestion/files/{folder}` endpoint results.

---

## 8. POST /ingestion/check-duplicate

**Description:** Check if content already exists in OpenSearch

### Test Case 8.1: Check Sample Meeting Transcript
```json
{
  "content": "Meeting Transcript - Noventra IPST Weekly Sync\nDate: April 8, 2026\nAttendees: Sarah Chen, Dr. Priya Nair, Luis Martinez, Mark Davidson\n\nAgenda:\n1. Launch Readiness Update\n2. TPP Finalization Status\n3. Forecast Review\n\nSarah Chen: Good morning everyone. Let's start with the launch readiness update.\n\nDr. Priya Nair: The medical evidence review is taking longer than expected. We're about a week behind schedule due to data complexities in the subgroup analysis.\n\nLuis Martinez: Market Access is also facing delays. The updated payer research results aren't finalized yet, which is blocking our access strategy.\n\nMark Davidson: Without the TPP inputs from Medical and Market Access, I can't lock the forecast. I've prepared a provisional scenario using broad access assumptions.\n\nSarah Chen: Understood. I'll flag Launch Readiness as At Risk until we have alignment on these cross-functional dependencies.\n\nAction Items:\n- Dr. Priya Nair: Complete medical evidence review by April 15, 2026\n- Luis Martinez: Finalize access research and assumptions by April 22, 2026\n- Mark Davidson: Update forecast based on final TPP by April 24, 2026\n- Sarah Chen: Prepare LRR status update for leadership by April 23, 2026\n\nDecisions:\n- Team agreed to proceed with provisional forecast scenario\n- Launch Readiness remains At Risk until TPP is finalized\n\nNext Steps:\n- Follow-up sync scheduled for April 15, 2026"
}
```

### Test Case 8.2: Check Sample Email Content
```json
{
  "content": "From: Mark Davidson <mark.davidson@novartis.com>\nTo: Sarah Chen <sarah.chen@novartis.com>\nCc: Noventra IPST Core Team\nSubject: Forecast Update - Provisional Scenario Ready\nDate: April 10, 2026\n\nHi Sarah,\n\nAs discussed in our last meeting, I've prepared a provisional forecast scenario so we can keep moving forward while waiting for the final TPP inputs.\n\nKey assumptions in this scenario:\n- Broad payer access assumption (conservative)\n- Launch date: October 2026 (unchanged)\n- Market share projections based on current competitive landscape\n\nPlease note that this forecast is clearly marked as provisional and dependent on final TPP finalization. Once we have aligned inputs from Medical and Market Access, I'll update accordingly.\n\nI've also flagged this to Finance leadership so they're aware of the dependency.\n\nLet me know if you have any questions.\n\nBest,\nMark Davidson\nForecasting Lead, Noventra IPST"
}
```

### Test Case 8.3: Check Sample Teams Chat Content
```json
{
  "content": "Teams Chat - Noventra IPST\nApril 9, 2026 10:30 AM\n\nLuis Martinez: @Sarah Chen - heads up, the market research results are still being refined. We need another week to finalize the access assumptions.\n\nSarah Chen: Thanks for the update Luis. This impacts the TPP timeline. @Dr. Priya Nair - where are we on the medical evidence review?\n\nDr. Priya Nair: Still working through the subgroup analysis. Should have preliminary results by end of this week.\n\nSarah Chen: OK, so we're looking at a potential 1-week delay across the board. I'll update the tracker and flag this for the next IPST sync.\n\nNina Patel: I can prepare an updated status view for the sync if that helps.\n\nSarah Chen: Yes please, that would be great. Let's make sure we have one aligned view before we go to leadership.\n\nLuis Martinez: Agreed. We should align on the access strategy before finalizing anything."
}
```

### Test Case 8.4: Check Unique/New Content
```json
{
  "content": "This is a completely unique test content that should not exist in the database. Random ID: TEST-12345-UNIQUE"
}
```

---

## 9. POST /ingestion/extract-text

**Description:** Extract text from an S3 file (preview only)

### Test Case 9.1: Extract from Transcript File
**Query Parameter:**
- `s3_key`: `Agentic-Colleague-synthetic/transcripts/meeting_transcript_001.docx`

### Test Case 9.2: Extract from Email File
**Query Parameter:**
- `s3_key`: `Agentic-Colleague-synthetic/Outlook_emails/email_001.eml`

### Test Case 9.3: Extract from Teams Chat File
**Query Parameter:**
- `s3_key`: `Agentic-Colleague-synthetic/Teams_Chat/chat_001.txt`

> **Note:** Get actual file paths from `/ingestion/files/{folder}` endpoint first.

---

## 10. POST /ingestion/clean-text

**Description:** Process raw text through LLM cleaning pipeline

### Test Case 10.1: Clean Meeting Transcript
**Query Parameters:**
- `source_type`: `meeting_transcript`
- `raw_text`:
```
Meeting Transcript - Noventra IPST Weekly Sync
Date: April 8, 2026
Attendees: Sarah Chen (BEL), Dr. Priya Nair (Medical), Luis Martinez (Market Access), Mark Davidson (Forecasting)

Agenda:
1. Launch Readiness Update
2. TPP Finalization Status
3. Forecast Review

Sarah Chen: Good morning everyone. Let's start with the launch readiness update. As you know, we're targeting October 2026 for the Noventra launch.

Dr. Priya Nair: The medical evidence review is taking longer than expected. We're about a week behind schedule due to data complexities in the subgroup analysis. I should have preliminary results by April 15.

Luis Martinez: Market Access is also facing delays. The updated payer research results aren't finalized yet, which is blocking our access strategy decisions.

Mark Davidson: Without the TPP inputs from Medical and Market Access, I can't lock the forecast. I've prepared a provisional scenario using broad access assumptions, but it's clearly marked as dependent on final TPP.

Sarah Chen: Understood. I'll flag Launch Readiness as At Risk until we have alignment on these cross-functional dependencies. Victor asked for a confirmed TPP and IEP for the June 8 LRR.

Action Items:
1. Dr. Priya Nair to complete medical evidence review by April 15, 2026
2. Luis Martinez to finalize access research and assumptions by April 22, 2026
3. Mark Davidson to update forecast based on final TPP by April 24, 2026
4. Sarah Chen to prepare LRR status update for leadership by April 23, 2026

Decisions Made:
- Team agreed to proceed with provisional forecast scenario
- Launch Readiness remains At Risk until TPP is finalized
- Cross-functional alignment meeting scheduled for April 23

Meeting adjourned at 10:45 AM.
```

### Test Case 10.2: Clean Email Content
**Query Parameters:**
- `source_type`: `email`
- `raw_text`:
```
From: Luis Martinez <luis.martinez@novartis.com>
To: Sarah Chen <sarah.chen@novartis.com>
Cc: Noventra IPST Core Team
Subject: Market Access Update - Timeline Impact
Date: April 12, 2026

Hi Sarah,

Following up on our discussion at the IPST sync. Here's where we stand on Market Access:

Current Status:
- Payer research results are being finalized (expected by April 20)
- Access strategy recommendations will follow within 2 days
- Updated payer materials cannot be completed until strategy is confirmed

Impact on Timeline:
- This pushes our access strategy finalization to approximately April 22-24
- Downstream impact on TPP finalization and forecast lock

Risks:
- If we miss the April 24 deadline, we may need to request an extension for the forecast submission
- Field training materials are on hold pending approved messaging

Recommendation:
- I suggest we schedule a cross-functional alignment call for April 23 to reconcile all inputs before the LRR

Please let me know if you have any questions or concerns.

Best regards,
Luis Martinez
Market Access Lead, Noventra IPST
```

### Test Case 10.3: Clean Teams Chat Content
**Query Parameters:**
- `source_type`: `teams_chat`
- `raw_text`:
```
Teams Chat - Noventra IPST Core Team
April 14, 2026 2:15 PM

Rachel Kim: @Sarah Chen - I need clarity on the Payer Objection Handling Plan. Who owns this?

Sarah Chen: Good question. @Luis Martinez @Dr. Priya Nair - can one of you confirm ownership?

Luis Martinez: This should sit with Market Access but we need Medical input for the clinical evidence portion.

Dr. Priya Nair: Happy to provide the medical evidence inputs. But the overall plan should be owned by Market Access or Field Strategy.

Rachel Kim: I can take ownership from Field Strategy side if Market Access handles the payer-facing content.

Luis Martinez: That works for me. Let's sync offline to divide responsibilities.

Sarah Chen: Perfect. I'll update the tracker to show Rachel and Luis as co-owners. Due date?

Rachel Kim: Given the current timeline constraints, I'd say end of April at the earliest.

Luis Martinez: Agreed. April 30 as target date.

Sarah Chen: Noted. I'll add this to the Kanban board.
```

### Test Case 10.4: Clean Teams Channel Post
**Query Parameters:**
- `source_type`: `teams_channel_post`
- `raw_text`:
```
Teams Channel: Noventra IPST - Announcements
Posted by: Nina Patel
Date: April 15, 2026

📢 Weekly Status Update - Noventra IPST

Hi team,

Here's our weekly status summary:

✅ Completed:
- Medical evidence review (preliminary results available)
- Provisional forecast scenario prepared

🔄 In Progress:
- Access research finalization (Luis Martinez)
- TPP input reconciliation (Priya + Luis)
- LRR preparation materials (Sarah Chen)

⚠️ At Risk:
- Launch Readiness Review (cross-functional dependencies not resolved)
- Forecast Lock (waiting on TPP finalization)

📅 Upcoming Milestones:
- April 22: Access assumptions due
- April 23: Cross-functional alignment meeting
- April 24: Target date for TPP finalization
- June 8: LRR with US LT

🚨 Blockers:
- Payer Objection Handling Plan - needs ownership confirmation

Please update your status in the tracker by EOD Friday.

Thanks,
Nina Patel
Business Excellence
```

---

## 11. POST /ingestion/generate-embedding

**Description:** Generate vector embedding using Amazon Titan v2

### Test Case 11.1: Short Text Embedding
**Query Parameter:**
- `text`: `Noventra IPST launch readiness review meeting transcript discussing TPP finalization and forecast dependencies.`

### Test Case 11.2: Medium Text Embedding
**Query Parameter:**
- `text`: `The Noventra IPST team is working on finalizing the Target Product Profile (TPP) for the October 2026 launch. Key stakeholders include Sarah Chen (Business Excellence Lead), Dr. Priya Nair (Medical), Luis Martinez (Market Access), and Mark Davidson (Forecasting). The team is currently facing delays due to cross-functional dependencies between Medical evidence review and Market Access strategy finalization.`

### Test Case 11.3: Long Text Embedding
**Query Parameter:**
- `text`:
```
Meeting Transcript - Noventra IPST Launch Readiness Review Preparation

Date: April 20, 2026
Attendees: Sarah Chen (BEL), Dr. Priya Nair (Medical), Luis Martinez (Market Access), Mark Davidson (Forecasting), Nina Patel (Business Excellence), Rachel Kim (Field Strategy)

The team convened to discuss preparation for the upcoming Launch Readiness Review (LRR) scheduled for June 8, 2026. The primary focus was on resolving the cross-functional dependencies that have been flagged as At Risk.

Dr. Priya Nair confirmed that the medical evidence review has been completed, though later than originally planned. The subgroup analysis results are now available for TPP finalization.

Luis Martinez reported that the access research is still being refined, with final recommendations expected by April 22. This is causing a downstream delay on the access strategy and TPP inputs.

Mark Davidson emphasized that the forecast cannot be locked until TPP inputs from both Medical and Market Access are reconciled. He has prepared a provisional forecast scenario using conservative assumptions.

Sarah Chen noted that Launch Readiness remains At Risk and will stay flagged as such until cross-functional alignment is achieved. She reminded the team that Victor specifically asked for a confirmed TPP and Integrated Evidence Plan for the June 8 LRR.

The team agreed on the following action items and decisions to move forward with LRR preparation while managing the current risks and dependencies.
```

### Test Case 11.4: Action Items Text Embedding
**Query Parameter:**
- `text`: `Action Items: 1) Dr. Priya Nair to provide medical evidence inputs for TPP by April 22. 2) Luis Martinez to finalize access assumptions by April 22. 3) Mark Davidson to update forecast after TPP finalization by April 24. 4) Sarah Chen to prepare LRR decision matrix by June 6. 5) Nina Patel to update decision log with cross-functional decisions.`

---

## Quick Test Workflow

Follow this sequence to test the entire pipeline:

### Step 1: Check Configuration
```
GET /ingestion/config
GET /ingestion/folders
GET /ingestion/status
```

### Step 2: List Available Files
```
GET /ingestion/files/transcripts
GET /ingestion/files/Outlook_emails
```
> Note: No limit needed - returns all files by default

### Step 3: Preview Single File Processing
```
POST /ingestion/extract-text?s3_key=<file_from_step_2>
```

### Step 4: Test LLM Cleaning
```
POST /ingestion/clean-text (with sample text from Test Case 10.1)
```

### Step 5: Test Embedding Generation
```
POST /ingestion/generate-embedding (with sample text from Test Case 11.1)
```

### Step 6: Check Duplicate Detection
```
POST /ingestion/check-duplicate (with sample content from Test Case 8.1)
```

### Step 7: Dry Run Batch Ingestion (ALL Files)
```
POST /ingestion/run (Test Case 5.1 - dry_run: true, no limit)
```

### Step 8: (Optional) Actual Ingestion (ALL Files)
```
POST /ingestion/run (Test Case 5.6 - dry_run: false, no limit)
```

---

## Error Handling Test Cases

### Invalid Folder
```json
{
  "folder": "invalid_folder",
  "dry_run": true,
  "limit": 1
}
```
**Expected:** 422 Validation Error

### Invalid S3 Key
```json
{
  "s3_key": "non-existent/path/file.docx",
  "dry_run": true
}
```
**Expected:** 500 Error with message about file not found

### Invalid Source Type
**Query Parameters:**
- `source_type`: `invalid_type`
- `raw_text`: `Test content`

**Expected:** 400 Error with valid source types listed

---

## Notes

1. **Dry Run Mode**: Always start with `dry_run: true` to preview changes without writing to databases.

2. **Verbose Mode**: Use `verbose: true` for detailed output during debugging. This automatically implies `dry_run: true`.

3. **Limit Parameter**: The `limit` parameter is **OPTIONAL**. If omitted, ALL files in the folder will be processed. Use `limit` only when you want to restrict processing to a specific number of files.

4. **Skip Existing**: Keep `skip_existing: true` to avoid duplicate entries. Set to `false` only for re-indexing.

5. **Actual S3 Keys**: Replace placeholder S3 keys with actual file paths obtained from `/ingestion/files/{folder}` endpoint.

6. **Rate Limiting**: The LLM and embedding generation have rate limits. For large folders, consider using `limit` parameter to process in batches if you encounter rate limit errors.
