"""
LLM Processing Utilities for Batch Data Ingestion.

This module provides functions for:
- Text cleaning and structuring with LLM (Claude via Bedrock)
- Embedding generation (Titan v2)
- Content hashing for deduplication
- Map-Reduce chunking for processing large documents without data loss
"""

import hashlib
import json
from typing import Any, Dict, List, Tuple

from utils.data_ingestion_prompts import SYSTEM_PROMPTS

from .aws_clients import get_bedrock_client
from .project_matching import get_seeded_projects_context


# ============================================================================
# CHUNKING CONFIGURATION
# ============================================================================
CHUNK_SIZE = 6000          # Characters per chunk (leaving room for prompt overhead)
CHUNK_OVERLAP = 500        # Overlap between chunks to avoid cutting sentences mid-way
MIN_CHUNK_SIZE = 500       # Minimum chunk size to process (avoid tiny fragments)


def generate_content_hash(content: str) -> str:
    """
    Generate MD5 hash of content for deduplication.
    
    Args:
        content: Text content to hash
        
    Returns:
        MD5 hash string
    """
    return hashlib.md5(content.encode("utf-8")).hexdigest()


def split_text_into_chunks(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> List[Tuple[str, int, int]]:
    """
    Split text into overlapping chunks for processing.
    
    Tries to split at sentence boundaries when possible to maintain context.
    
    Args:
        text: Full text to split
        chunk_size: Maximum characters per chunk
        overlap: Number of characters to overlap between chunks
        
    Returns:
        List of tuples: (chunk_text, start_index, end_index)
    """
    if len(text) <= chunk_size:
        return [(text, 0, len(text))]
    
    chunks = []
    start = 0
    
    while start < len(text):
        end = start + chunk_size
        
        # If we're not at the end, try to find a good break point
        if end < len(text):
            # Look for sentence endings (. ! ?) within the last 500 chars of the chunk
            search_start = max(start + chunk_size - 500, start)
            search_region = text[search_start:end]
            
            # Find the last sentence boundary
            last_period = search_region.rfind('. ')
            last_exclaim = search_region.rfind('! ')
            last_question = search_region.rfind('? ')
            last_newline = search_region.rfind('\n\n')
            
            best_break = max(last_period, last_exclaim, last_question, last_newline)
            
            if best_break > 0:
                end = search_start + best_break + 2  # +2 to include the punctuation and space
        else:
            end = len(text)
        
        chunk_text = text[start:end].strip()
        if len(chunk_text) >= MIN_CHUNK_SIZE:
            chunks.append((chunk_text, start, end))
        
        # Move start position, accounting for overlap
        start = end - overlap if end < len(text) else len(text)
    
    return chunks


def generate_embedding(text: str) -> List[float]:
    """
    Generate embedding using Titan v2 via BedrockClient.
    
    Args:
        text: Text to embed (will be truncated if too long)
        
    Returns:
        1024-dimensional embedding vector
    """
    bedrock_client = get_bedrock_client()
    
    # Truncate text if too long (Titan has token limits)
    max_chars = 8000
    if len(text) > max_chars:
        text = text[:max_chars]
    
    return bedrock_client.vectorize_with_titan(text)


def _process_single_chunk(
    chunk_text: str,
    source_type: str,
    chunk_index: int,
    total_chunks: int,
    bedrock_client,
    project_context: str
) -> Dict[str, Any]:
    """
    Process a single chunk with LLM to extract structured information.
    
    Args:
        chunk_text: Text chunk to process
        source_type: Type of source document
        chunk_index: Index of this chunk (0-based)
        total_chunks: Total number of chunks
        bedrock_client: Bedrock client instance
        project_context: Project matching instructions
        
    Returns:
        Structured JSON dict from this chunk
    """
    # Use the appropriate cleaning prompt based on source type
    effective_source_type = source_type
    if source_type == "meeting_chat":
        effective_source_type = "teams_chat"
    
    if effective_source_type not in SYSTEM_PROMPTS:
        effective_source_type = "email"  # fallback
    
    # Build the cleaning prompt with project context
    if project_context:
        project_instruction = f"""

IMPORTANT PROJECT MATCHING INSTRUCTIONS:
{project_context}

When extracting "entities.projects", you MUST:
1. First check if the content relates to any of the AVAILABLE PROJECTS listed above
2. Use the EXACT project name from the list if there is a match (even partial/similar names)
3. Only use a new project name if NONE of the available projects match the content
4. Consider project descriptions when matching - content about similar topics should match

"""
    else:
        project_instruction = ""
    
    chunk_context = ""
    if total_chunks > 1:
        chunk_context = f"\n\nNOTE: This is chunk {chunk_index + 1} of {total_chunks} from a larger document. Extract ALL action items, decisions, and entities from this chunk.\n"
    
    cleaning_prompt = f"""{SYSTEM_PROMPTS[effective_source_type]}{project_instruction}{chunk_context}

Parse the following content and return ONLY valid JSON matching the required schema.
Do not include markdown fences or explanations.

Content:
{chunk_text}
"""
    
    try:
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 8192,
            "temperature": 0.1,
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": cleaning_prompt}],
                }
            ],
        }
        
        response = bedrock_client.invoke(body)
        generated_text = response["content"][0]["text"]
        
        # Clean and parse JSON
        generated_text = generated_text.strip()
        if generated_text.startswith("```json"):
            generated_text = generated_text[7:]
        if generated_text.startswith("```"):
            generated_text = generated_text[3:]
        if generated_text.endswith("```"):
            generated_text = generated_text[:-3]
        
        return json.loads(generated_text.strip())
        
    except Exception as e:
        print(f"  ⚠️ Chunk {chunk_index + 1} LLM processing failed: {e}")
        return {
            "source_type": source_type,
            "clean_text": chunk_text[:2000],
            "summary": "",
            "action_items": [],
            "decisions": [],
            "entities": {
                "projects": [],
                "people": [],
                "dates": [],
                "tickets": [],
                "systems": [],
                "organizations": []
            },
            "metadata": {}
        }


# Status priority for reconciliation (higher = more "complete")
STATUS_PRIORITY = {
    "done": 5,
    "completed": 5,
    "complete": 5,
    "in progress": 4,
    "in-progress": 4,
    "inprogress": 4,
    "in_progress": 4,
    "started": 3,
    "pending": 2,
    "to do": 1,
    "todo": 1,
    "not started": 1,
    "": 0,
    None: 0
}


def _normalize_status(status: str) -> str:
    """Normalize status string to a consistent format."""
    if not status:
        return "pending"
    
    status_lower = status.lower().strip().replace("-", " ").replace("_", " ")
    
    if status_lower in ["done", "completed", "complete", "finished"]:
        return "done"
    elif status_lower in ["in progress", "inprogress", "started", "working", "ongoing"]:
        return "in progress"
    elif status_lower in ["pending", "to do", "todo", "not started", "open"]:
        return "pending"
    else:
        return status_lower


def _get_status_priority(status: str) -> int:
    """Get priority value for a status (higher = more complete)."""
    normalized = _normalize_status(status)
    return STATUS_PRIORITY.get(normalized, 0)


def _similarity_score(text1: str, text2: str) -> float:
    """
    Calculate simple word-based similarity between two strings.
    Returns value between 0 and 1.
    """
    if not text1 or not text2:
        return 0.0
    
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    
    if not words1 or not words2:
        return 0.0
    
    intersection = words1 & words2
    union = words1 | words2
    
    return len(intersection) / len(union) if union else 0.0


def _reconcile_action_items(items: List[Dict]) -> List[Dict]:
    """
    Reconcile and deduplicate action items across chunks with status consistency.
    
    When the same action item appears in multiple chunks:
    1. Uses the HIGHEST status (done > in progress > pending)
    2. Prefers the most specific owner/assignee
    3. Prefers the most specific due_date
    4. Merges descriptions if significantly different
    
    This ensures that if chunk 1 says "task is pending" and chunk 7 says 
    "task is complete", the final status will be "done".
    """
    if not items:
        return []
    
    # Group similar action items together
    # Key: normalized description prefix + owner
    groups: Dict[str, List[Dict]] = {}
    
    for item in items:
        desc = (item.get("description") or item.get("title") or "").lower().strip()
        owner = (item.get("owner") or item.get("assignee") or "").lower().strip()
        
        if not desc:
            continue
        
        # Create a grouping key
        # Use first 80 chars of description + owner for grouping
        base_key = f"{desc[:80]}|{owner}"
        
        # Check if this item is similar to any existing group
        matched_key = None
        for existing_key in groups:
            existing_desc = existing_key.split("|")[0]
            if _similarity_score(desc[:80], existing_desc) > 0.6:
                matched_key = existing_key
                break
        
        if matched_key:
            groups[matched_key].append(item)
        else:
            groups[base_key] = [item]
    
    # Reconcile each group into a single action item
    reconciled = []
    
    for key, group_items in groups.items():
        if len(group_items) == 1:
            # Single item - just normalize status
            item = group_items[0].copy()
            item["status"] = _normalize_status(item.get("status", "pending"))
            reconciled.append(item)
        else:
            # Multiple items - reconcile them
            reconciled_item = _merge_action_item_group(group_items)
            reconciled.append(reconciled_item)
    
    return reconciled


def _merge_action_item_group(items: List[Dict]) -> Dict:
    """
    Merge a group of similar action items into one with the best information.
    """
    # Start with the first item as base
    merged = items[0].copy()
    
    best_status_priority = _get_status_priority(merged.get("status"))
    best_status = _normalize_status(merged.get("status", "pending"))
    
    # Track best values
    best_owner = merged.get("owner") or merged.get("assignee") or ""
    best_due_date = merged.get("due_date") or ""
    best_description = merged.get("description") or merged.get("title") or ""
    best_confidence = float(merged.get("confidence", 0.9))
    
    # Process remaining items in the group
    for item in items[1:]:
        # Status: use the highest priority (most "complete")
        item_status = _normalize_status(item.get("status", "pending"))
        item_priority = _get_status_priority(item_status)
        
        if item_priority > best_status_priority:
            best_status_priority = item_priority
            best_status = item_status
        
        # Owner: prefer non-empty, more specific names
        item_owner = item.get("owner") or item.get("assignee") or ""
        if item_owner and (not best_owner or len(item_owner) > len(best_owner)):
            best_owner = item_owner
        
        # Due date: prefer non-empty, more specific dates
        item_due = item.get("due_date") or ""
        if item_due and not best_due_date:
            best_due_date = item_due
        elif item_due and best_due_date:
            # Keep the more specific/later due date if both exist
            # Simple heuristic: longer string is often more specific
            if len(item_due) > len(best_due_date):
                best_due_date = item_due
        
        # Description: prefer longer, more detailed descriptions
        item_desc = item.get("description") or item.get("title") or ""
        if len(item_desc) > len(best_description):
            best_description = item_desc
        
        # Confidence: use highest confidence
        item_conf = float(item.get("confidence", 0.9))
        if item_conf > best_confidence:
            best_confidence = item_conf
    
    # Build the merged item
    merged["description"] = best_description
    merged["title"] = best_description  # Keep both for compatibility
    merged["status"] = best_status
    merged["owner"] = best_owner
    merged["assignee"] = best_owner  # Keep both for compatibility
    merged["due_date"] = best_due_date
    merged["confidence"] = best_confidence
    
    # Add metadata about the merge
    merged["_merged_from_chunks"] = len(items)
    merged["_reconciled"] = True
    
    return merged


def _deduplicate_action_items(items: List[Dict]) -> List[Dict]:
    """
    Remove duplicate action items with cross-chunk status reconciliation.
    
    This is a wrapper that calls _reconcile_action_items for full reconciliation.
    """
    return _reconcile_action_items(items)


def _deduplicate_decisions(items: List) -> List[Dict]:
    """
    Remove duplicate decisions based on description similarity.
    """
    if not items:
        return []
    
    seen = set()
    unique = []
    
    for item in items:
        if isinstance(item, dict):
            desc = (item.get("description") or item.get("decision") or "").lower().strip()
        else:
            desc = str(item).lower().strip()
            item = {"description": str(item), "confidence": 0.9}
        
        key = desc[:100]
        
        if key not in seen and desc:
            seen.add(key)
            unique.append(item)
    
    return unique


def _deduplicate_list(items: List[str]) -> List[str]:
    """
    Remove duplicate strings (case-insensitive).
    """
    if not items:
        return []
    
    seen = set()
    unique = []
    
    for item in items:
        key = str(item).lower().strip()
        if key not in seen and key:
            seen.add(key)
            unique.append(item)
    
    return unique


def _merge_chunk_results(chunk_results: List[Dict[str, Any]], full_text: str) -> Dict[str, Any]:
    """
    Merge results from all chunks into a single coherent structure.
    
    Args:
        chunk_results: List of cleaned JSON results from each chunk
        full_text: The complete original text
        
    Returns:
        Merged and deduplicated result structure
    """
    # Collect all items from all chunks
    all_action_items = []
    all_decisions = []
    all_people = []
    all_projects = []
    all_dates = []
    all_tickets = []
    all_systems = []
    all_organizations = []
    all_clean_texts = []
    all_summaries = []
    
    for result in chunk_results:
        # Action items
        all_action_items.extend(result.get("action_items", []))
        
        # Decisions
        all_decisions.extend(result.get("decisions", []))
        
        # Entities
        entities = result.get("entities", {})
        all_people.extend(entities.get("people", []))
        all_projects.extend(entities.get("projects", []))
        all_dates.extend(entities.get("dates", []))
        all_tickets.extend(entities.get("tickets", []))
        all_systems.extend(entities.get("systems", []))
        all_organizations.extend(entities.get("organizations", []))
        
        # Text content
        clean_text = result.get("clean_text", "")
        if clean_text:
            all_clean_texts.append(clean_text)
        
        summary = result.get("summary", "")
        if summary:
            all_summaries.append(summary)
    
    # Deduplicate with cross-chunk reconciliation
    unique_action_items = _deduplicate_action_items(all_action_items)
    unique_decisions = _deduplicate_decisions(all_decisions)
    unique_people = _deduplicate_list(all_people)
    unique_projects = _deduplicate_list(all_projects)
    unique_dates = _deduplicate_list(all_dates)
    unique_tickets = _deduplicate_list(all_tickets)
    unique_systems = _deduplicate_list(all_systems)
    unique_organizations = _deduplicate_list(all_organizations)
    
    # Count how many action items were reconciled across chunks
    reconciled_count = sum(1 for item in unique_action_items if item.get("_reconciled"))
    
    # Log reconciliation info
    if reconciled_count > 0:
        print(f"        ℹ️ Reconciled {reconciled_count} action items with status updates from later chunks")
    
    # Combine clean texts (remove duplicates from overlap)
    combined_clean_text = "\n\n".join(all_clean_texts) if all_clean_texts else full_text[:10000]
    
    # Combine summaries into one coherent summary
    if len(all_summaries) > 1:
        combined_summary = " ".join(all_summaries)
        # Truncate to reasonable length for summary
        if len(combined_summary) > 1000:
            combined_summary = combined_summary[:1000] + "..."
    elif all_summaries:
        combined_summary = all_summaries[0]
    else:
        combined_summary = full_text[:300]
    
    # Get source_type from first result
    source_type = chunk_results[0].get("source_type", "unknown") if chunk_results else "unknown"
    
    # Clean up internal reconciliation markers from action items before returning
    cleaned_action_items = []
    for item in unique_action_items:
        clean_item = {k: v for k, v in item.items() if not k.startswith("_")}
        cleaned_action_items.append(clean_item)
    
    return {
        "source_type": source_type,
        "clean_text": combined_clean_text,
        "summary": combined_summary,
        "action_items": cleaned_action_items,
        "decisions": unique_decisions,
        "entities": {
            "projects": unique_projects,
            "people": unique_people,
            "dates": unique_dates,
            "tickets": unique_tickets,
            "systems": unique_systems,
            "organizations": unique_organizations
        },
        "metadata": {
            "total_chunks_processed": len(chunk_results),
            "total_action_items_before_reconciliation": len(all_action_items),
            "total_action_items_after_reconciliation": len(cleaned_action_items),
            "action_items_reconciled_across_chunks": reconciled_count,
            "total_decisions_before_dedup": len(all_decisions),
            "original_text_length": len(full_text)
        }
    }


def clean_text_with_llm(raw_text: str, source_type: str, return_chunks: bool = False) -> Dict[str, Any]:
    """
    Use LLM to clean and structure raw text using Map-Reduce chunking strategy.
    
    For documents longer than CHUNK_SIZE, splits into overlapping chunks,
    processes each chunk with LLM, then merges and deduplicates results.
    This ensures NO content is lost from large documents.
    
    Returns structured JSON with action_items, decisions, entities, etc.
    Includes seeded project context so LLM picks from existing projects first.
    
    Args:
        raw_text: Raw text content to clean (any length)
        source_type: Type of source (email, meeting_transcript, teams_chat, etc.)
        return_chunks: If True, includes chunk info in metadata for multi-vector embedding
        
    Returns:
        Structured JSON dict with cleaned content from the ENTIRE document.
        If return_chunks=True, metadata includes 'chunks' list with (text, start, end) for each chunk.
    """
    bedrock_client = get_bedrock_client()
    
    # Get seeded project context to include in prompt
    project_context = get_seeded_projects_context()
    
    # Split text into chunks
    chunks = split_text_into_chunks(raw_text)
    total_chunks = len(chunks)
    
    if total_chunks > 1:
        print(f"     📄 Document split into {total_chunks} chunks ({len(raw_text)} chars total)")
    
    # Process each chunk
    chunk_results = []
    for idx, (chunk_text, start_idx, end_idx) in enumerate(chunks):
        if total_chunks > 1:
            print(f"        Processing chunk {idx + 1}/{total_chunks} (chars {start_idx}-{end_idx})...")
        
        result = _process_single_chunk(
            chunk_text=chunk_text,
            source_type=source_type,
            chunk_index=idx,
            total_chunks=total_chunks,
            bedrock_client=bedrock_client,
            project_context=project_context
        )
        chunk_results.append(result)
    
    # Merge all chunk results
    if total_chunks > 1:
        print(f"        Merging results from {total_chunks} chunks...")
        merged = _merge_chunk_results(chunk_results, raw_text)
        print(f"        ✅ Merged: {len(merged.get('action_items', []))} action items, {len(merged.get('decisions', []))} decisions")
        
        # Add chunk info for multi-vector embedding if requested
        if return_chunks:
            merged["metadata"]["chunks"] = [
                {"text": chunk_text, "start": start_idx, "end": end_idx}
                for chunk_text, start_idx, end_idx in chunks
            ]
        
        return merged
    else:
        # Single chunk - return as-is
        result = chunk_results[0] if chunk_results else {
            "source_type": source_type,
            "clean_text": raw_text[:5000],
            "summary": raw_text[:300],
            "action_items": [],
            "decisions": [],
            "entities": {
                "projects": [],
                "people": [],
                "dates": [],
                "tickets": [],
                "systems": [],
                "organizations": []
            },
            "metadata": {}
        }
        
        # Add chunk info for consistency
        if return_chunks:
            if "metadata" not in result:
                result["metadata"] = {}
            result["metadata"]["chunks"] = [
                {"text": raw_text, "start": 0, "end": len(raw_text)}
            ]
        
        return result
