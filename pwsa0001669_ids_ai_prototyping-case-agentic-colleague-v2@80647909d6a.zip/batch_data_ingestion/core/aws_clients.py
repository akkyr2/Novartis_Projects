"""
AWS Client Initialization for Batch Data Ingestion.

This module provides lazy-loaded AWS clients for:
- S3 (file storage)
- DynamoDB (structured data storage)
- Bedrock (LLM and embeddings)
- OpenSearch Serverless (vector database)
"""

import boto3
from requests_aws4auth import AWS4Auth

from .config import AWS_REGION

# ============================================================================
# GLOBAL CLIENTS (lazy loaded)
# ============================================================================
_s3_client = None
_dynamodb_resource = None
_bedrock_client = None


def get_s3_client():
    """Get or create S3 client."""
    global _s3_client
    if _s3_client is None:
        _s3_client = boto3.client("s3", region_name=AWS_REGION)
    return _s3_client


def get_dynamodb_resource():
    """Get or create DynamoDB resource."""
    global _dynamodb_resource
    if _dynamodb_resource is None:
        _dynamodb_resource = boto3.resource("dynamodb", region_name=AWS_REGION)
    return _dynamodb_resource


def get_bedrock_client():
    """
    Get or create Bedrock client wrapper.
    Uses the existing BedrockClient from utils.
    """
    global _bedrock_client
    if _bedrock_client is None:
        from utils.bedrock_client import BedrockClient
        _bedrock_client = BedrockClient()
    return _bedrock_client


def get_fresh_awsauth():
    """
    Get fresh AWS4Auth credentials for OpenSearch Serverless.
    
    This function creates new credentials each time it's called,
    preventing 403 errors caused by expired session tokens.
    
    AWS temporary credentials expire (typically 1-12 hours), so we must
    refresh them before each OpenSearch request rather than using
    static credentials created at module import time.
    
    Returns:
        AWS4Auth: Fresh authentication object for OpenSearch requests
    """
    session = boto3.Session()
    credentials = session.get_credentials()
    return AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        AWS_REGION,
        "aoss",  # OpenSearch Serverless service
        session_token=credentials.token
    )
