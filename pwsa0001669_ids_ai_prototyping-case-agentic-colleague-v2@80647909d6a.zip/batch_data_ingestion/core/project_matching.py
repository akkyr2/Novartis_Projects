"""
Project Matching Utilities for Batch Data Ingestion.

This module provides functions to match detected project names
against seeded projects in DynamoDB, ensuring consistency across
the data pipeline.
"""

import json
from typing import Any, Dict, List

from project_seeding.projects_service import get_all_projects

from .aws_clients import get_bedrock_client

# Global cache for seeded projects (loaded once at pipeline start)
_SEEDED_PROJECTS_CACHE: List[Dict[str, Any]] = []


def load_seeded_projects() -> List[Dict[str, Any]]:
    """
    Load all seeded projects from DynamoDB and cache them.
    This is called once at the beginning of batch processing.
    
    Returns:
        List of seeded projects with project_id, project_name, project_description
    """
    global _SEEDED_PROJECTS_CACHE
    
    try:
        print("📋 Loading seeded projects from DynamoDB...")
        projects = get_all_projects(status_filter="Active")
        
        # Extract only the fields we need for matching
        _SEEDED_PROJECTS_CACHE = [
            {
                "project_id": p.get("project_id", ""),
                "project_name": p.get("project_name", ""),
                "project_description": p.get("project_description", "")
            }
            for p in projects
        ]
        
        print(f"   ✅ Loaded {len(_SEEDED_PROJECTS_CACHE)} seeded projects")
        for p in _SEEDED_PROJECTS_CACHE:
            print(f"      - {p['project_name']} ({p['project_id']})")
        
        return _SEEDED_PROJECTS_CACHE
        
    except Exception as e:
        print(f"   ⚠️ Failed to load seeded projects: {e}")
        _SEEDED_PROJECTS_CACHE = []
        return []


def get_seeded_projects_context() -> str:
    """
    Build a context string for LLM with all seeded project information.
    This is included in the LLM prompt so it can match projects correctly.
    
    Returns:
        Formatted string with project names and descriptions
    """
    if not _SEEDED_PROJECTS_CACHE:
        return ""
    
    context_lines = ["AVAILABLE PROJECTS (use these project names EXACTLY if content matches):"]
    for idx, p in enumerate(_SEEDED_PROJECTS_CACHE, 1):
        context_lines.append(
            f"  {idx}. Project Name: \"{p['project_name']}\"\n"
            f"     Description: {p['project_description'][:300]}"
        )
    
    return "\n".join(context_lines)


def match_project_with_llm(
    detected_projects: List[str],
    content_summary: str,
    verbose: bool = False
) -> Dict[str, Any]:
    """
    Use LLM to match detected project names against seeded projects.
    
    Args:
        detected_projects: List of project names detected by initial LLM cleaning
        content_summary: Summary of the content for context
        verbose: Whether to print detailed output
        
    Returns:
        Dict with matched project info:
        {
            "project_id": str,      # Seeded project ID or empty for new
            "project_name": str,    # Canonical project name
            "is_new_project": bool, # Whether this is a new project
            "match_confidence": str # high/medium/low/none
        }
    """
    # If no seeded projects, return first detected or Unassigned
    if not _SEEDED_PROJECTS_CACHE:
        return {
            "project_id": "",
            "project_name": detected_projects[0] if detected_projects else "Unassigned",
            "is_new_project": bool(detected_projects),
            "match_confidence": "none"
        }
    
    # If no projects detected, return Unassigned
    if not detected_projects:
        return {
            "project_id": "",
            "project_name": "Unassigned",
            "is_new_project": False,
            "match_confidence": "none"
        }
    
    # Build the matching prompt
    seeded_info = json.dumps([
        {"project_id": p["project_id"], "project_name": p["project_name"], "description": p["project_description"][:500]}
        for p in _SEEDED_PROJECTS_CACHE
    ], indent=2)
    
    matching_prompt = f"""You are a project matching assistant. Your task is to match detected project names from meeting transcripts/emails to the correct seeded project.

SEEDED PROJECTS (these are the official projects in the system):
{seeded_info}

DETECTED PROJECT NAMES FROM CONTENT:
{json.dumps(detected_projects)}

CONTENT SUMMARY FOR CONTEXT:
{content_summary[:1000]}

INSTRUCTIONS:
1. Compare each detected project name against the seeded projects
2. Consider both NAME similarity and DESCRIPTION relevance to the content
3. "Graph API Integration" and "Graph API" should match to the same project if one exists
4. Common variations like abbreviations, expanded names, or slightly different wording should match
5. Only suggest creating a new project if there is NO reasonable match

Return ONLY valid JSON (no markdown fences):
{{
    "matched_project_id": "<project_id from seeded list OR empty string if new>",
    "matched_project_name": "<exact project_name from seeded list OR new name if creating>",
    "is_new_project": <true if no match found, false if matched>,
    "match_confidence": "<high|medium|low>",
    "reasoning": "<brief explanation of why this match was chosen>"
}}"""

    try:
        bedrock_client = get_bedrock_client()
        
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1024,
            "temperature": 0.1,
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": matching_prompt}],
                }
            ],
        }
        
        response = bedrock_client.invoke(body)
        generated_text = response["content"][0]["text"].strip()
        
        # Clean JSON response
        if generated_text.startswith("```json"):
            generated_text = generated_text[7:]
        if generated_text.startswith("```"):
            generated_text = generated_text[3:]
        if generated_text.endswith("```"):
            generated_text = generated_text[:-3]
        
        result = json.loads(generated_text.strip())
        
        if verbose:
            print(f"\n  🔍 PROJECT MATCHING RESULT:")
            print(f"     Detected:   {detected_projects}")
            print(f"     Matched:    {result.get('matched_project_name')}")
            print(f"     Project ID: {result.get('matched_project_id', 'NEW')}")
            print(f"     Confidence: {result.get('match_confidence')}")
            print(f"     Reasoning:  {result.get('reasoning', '')[:100]}")
        
        return {
            "project_id": result.get("matched_project_id", ""),
            "project_name": result.get("matched_project_name", detected_projects[0]),
            "is_new_project": result.get("is_new_project", False),
            "match_confidence": result.get("match_confidence", "low"),
            "reasoning": result.get("reasoning", "")
        }
        
    except Exception as e:
        print(f"  ⚠️ Project matching failed: {e}")
        # Fallback: try simple string matching
        return _fallback_project_match(detected_projects)


def _fallback_project_match(detected_projects: List[str]) -> Dict[str, Any]:
    """
    Fallback project matching using simple string similarity.
    Used when LLM matching fails.
    """
    if not detected_projects or not _SEEDED_PROJECTS_CACHE:
        return {
            "project_id": "",
            "project_name": detected_projects[0] if detected_projects else "Unassigned",
            "is_new_project": bool(detected_projects),
            "match_confidence": "none"
        }
    
    detected_lower = detected_projects[0].lower()
    
    # Try exact match first
    for p in _SEEDED_PROJECTS_CACHE:
        if p["project_name"].lower() == detected_lower:
            return {
                "project_id": p["project_id"],
                "project_name": p["project_name"],
                "is_new_project": False,
                "match_confidence": "high"
            }
    
    # Try substring/contains match
    for p in _SEEDED_PROJECTS_CACHE:
        seeded_lower = p["project_name"].lower()
        if detected_lower in seeded_lower or seeded_lower in detected_lower:
            return {
                "project_id": p["project_id"],
                "project_name": p["project_name"],
                "is_new_project": False,
                "match_confidence": "medium"
            }
    
    # No match found
    return {
        "project_id": "",
        "project_name": detected_projects[0],
        "is_new_project": True,
        "match_confidence": "none"
    }


def clear_project_cache():
    """Clear the seeded projects cache. Useful for testing or refresh."""
    global _SEEDED_PROJECTS_CACHE
    _SEEDED_PROJECTS_CACHE = []


def get_cached_projects() -> List[Dict[str, Any]]:
    """Get the currently cached seeded projects."""
    return _SEEDED_PROJECTS_CACHE.copy()
