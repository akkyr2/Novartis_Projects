"""
Core Configuration for Batch Data Ingestion Pipelines.

This module contains all configuration constants used by both
transcript and chat data ingestion pipelines.
"""

import os
import sys

# ============================================================================
# PATH SETUP
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_BATCH_DIR = os.path.dirname(_SCRIPT_DIR)
_PROJECT_ROOT = os.path.dirname(_BATCH_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# Change working directory to project root so .env file is found
os.chdir(_PROJECT_ROOT)

# Import settings from project config
from config import settings

# ============================================================================
# S3 CONFIGURATION
# ============================================================================
BUCKET_NAME = settings.bucket_name  # "ids-aini-prototype-ai-analytics"
BASE_PREFIX = "Agentic-Colleague-synthetic/"

# Pipeline-specific prefixes (under meetings/ folder)
TRANSCRIPT_PREFIX = "Agentic-Colleague-synthetic/meetings/transcripts/"
CHAT_PREFIX = "Agentic-Colleague-synthetic/meetings/chats/"

# Legacy folder prefixes (for backward compatibility)
LEGACY_TRANSCRIPT_FOLDERS = [
    "transcripts/",
    "Transcribe_Data/",
]

LEGACY_CHAT_FOLDERS = [
    "Teams_Chat/",
]

LEGACY_EMAIL_FOLDERS = [
    "Outlook_emails/",
]

LEGACY_CHANNEL_FOLDERS = [
    "Team_Channels/",
]

# ============================================================================
# OPENSEARCH CONFIGURATION
# ============================================================================
OPENSEARCH_HOST = settings.host  # OpenSearch Serverless collection
OPENSEARCH_INDEX = "work_evidence_test"  # Testing index
EMBEDDING_DIMENSION = 1024  # Titan v2 embedding dimension

# ============================================================================
# DYNAMODB CONFIGURATION
# ============================================================================
DYNAMODB_WORK_ITEMS_TABLE = "AgenticColleague_WorkItems_Test"  # Testing environment
# Note: KanbanTasks table removed - using only WorkItems table for centralized data

# ============================================================================
# AWS REGION
# ============================================================================
AWS_REGION = settings.aws_region

# ============================================================================
# FOLDER TO SOURCE TYPE MAPPING
# ============================================================================
FOLDER_SOURCE_TYPE_MAP = {
    # Meeting transcripts
    "transcripts": "meeting_transcript",
    "Transcribe_Data": "meeting_transcript",
    "meetings/transcripts": "meeting_transcript",
    
    # Meeting chats
    "chats": "meeting_chat",
    "Teams_Chat": "teams_chat",
    "meetings/chats": "meeting_chat",
    
    # Email
    "Outlook_emails": "email",
    
    # Channel posts
    "Team_Channels": "teams_channel_post",
}

# ============================================================================
# SUPPORTED FILE EXTENSIONS
# ============================================================================
SUPPORTED_EXTENSIONS = [".docx", ".txt", ".eml"]
