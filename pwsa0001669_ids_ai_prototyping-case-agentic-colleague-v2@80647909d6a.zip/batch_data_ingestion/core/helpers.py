"""
Helper Utilities for Batch Data Ingestion.

This module provides common helper functions used across the pipeline.
"""

import json
from datetime import datetime, timezone
from typing import Any


def utc_now_iso() -> str:
    """Return current UTC time in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def print_separator(char: str = "─", length: int = 70):
    """Print a separator line."""
    print(char * length)


def print_section(title: str, content: Any, max_length: int = 500):
    """
    Print a section with title and truncated content.
    
    Args:
        title: Section title
        content: Content to display (dict, list, or string)
        max_length: Maximum characters to display
    """
    print(f"\n  📋 {title}:")
    print_separator("─", 60)
    
    if isinstance(content, dict):
        formatted = json.dumps(content, indent=2, default=str)
    elif isinstance(content, list):
        formatted = json.dumps(content, indent=2, default=str)
    else:
        formatted = str(content)
    
    if len(formatted) > max_length:
        print(f"  {formatted[:max_length]}...")
        print(f"  ... [truncated, total {len(formatted)} chars]")
    else:
        for line in formatted.split("\n"):
            print(f"  {line}")
    
    print_separator("─", 60)


def truncate(text: str, max_length: int = 200) -> str:
    """
    Truncate text to maximum length with ellipsis.
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        
    Returns:
        Truncated text with ellipsis if needed
    """
    if not text:
        return ""
    text = str(text)
    if len(text) <= max_length:
        return text
    return text[:max_length] + "..."


def format_count(count: int) -> str:
    """Format count with commas for readability."""
    if count >= 1000:
        return f"{count:,}"
    return str(count)


def format_size_mb(size_bytes: int) -> str:
    """Format byte size as MB."""
    mb = size_bytes / (1024 * 1024)
    return f"{mb:.2f}"


def print_header(title: str):
    """Print a formatted header."""
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}")


def print_stats_table(stats: dict):
    """
    Print a statistics table.
    
    Args:
        stats: Dict of stat_name -> value
    """
    max_key_len = max(len(str(k)) for k in stats.keys())
    for key, value in stats.items():
        print(f"   {key:<{max_key_len}}: {value}")
