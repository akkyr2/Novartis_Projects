"""
Text Extraction Utilities for Batch Data Ingestion.

This module provides functions to extract text from various file formats:
- DOCX (Word documents)
- TXT (Plain text)
- EML (Email files)

Supports reading files from S3 and extracting text based on file extension.
"""

import os
from io import BytesIO
from typing import Optional

from docx import Document

from .aws_clients import get_s3_client


def extract_text_from_docx_bytes(file_bytes: bytes) -> str:
    """
    Extract text from a DOCX file provided as bytes.
    
    Args:
        file_bytes: Raw bytes of the DOCX file
        
    Returns:
        Extracted text with paragraphs joined by newlines
    """
    doc = Document(BytesIO(file_bytes))
    return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])


def extract_text_from_txt_bytes(file_bytes: bytes) -> str:
    """
    Extract text from a TXT file provided as bytes.
    
    Args:
        file_bytes: Raw bytes of the TXT file
        
    Returns:
        Decoded text content (UTF-8 or Latin-1 fallback)
    """
    try:
        return file_bytes.decode("utf-8")
    except UnicodeDecodeError:
        return file_bytes.decode("latin-1")


def extract_text_from_eml_bytes(file_bytes: bytes) -> str:
    """
    Extract text from an EML (email) file provided as bytes.
    
    Args:
        file_bytes: Raw bytes of the EML file
        
    Returns:
        Extracted text including headers and body
    """
    import email
    from email import policy
    
    msg = email.message_from_bytes(file_bytes, policy=policy.default)
    
    parts = []
    
    # Add headers
    if msg["From"]:
        parts.append(f"From: {msg['From']}")
    if msg["To"]:
        parts.append(f"To: {msg['To']}")
    if msg["Subject"]:
        parts.append(f"Subject: {msg['Subject']}")
    if msg["Date"]:
        parts.append(f"Date: {msg['Date']}")
    
    parts.append("")  # Blank line separator
    
    # Get body
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            if content_type == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    try:
                        parts.append(payload.decode("utf-8"))
                    except UnicodeDecodeError:
                        parts.append(payload.decode("latin-1"))
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            try:
                parts.append(payload.decode("utf-8"))
            except UnicodeDecodeError:
                parts.append(payload.decode("latin-1"))
    
    return "\n".join(parts)


def read_file_from_s3(bucket: str, key: str) -> bytes:
    """
    Read a file from S3 and return its bytes.
    
    Args:
        bucket: S3 bucket name
        key: S3 object key
        
    Returns:
        Raw bytes of the file
    """
    s3_client = get_s3_client()
    response = s3_client.get_object(Bucket=bucket, Key=key)
    return response["Body"].read()


def extract_text_from_s3_file(bucket: str, key: str) -> Optional[str]:
    """
    Read a file from S3 and extract text based on file extension.
    
    Supports: .docx, .txt, .eml
    
    Args:
        bucket: S3 bucket name
        key: S3 object key
        
    Returns:
        Extracted text content, or None if unsupported/error
    """
    extension = os.path.splitext(key)[1].lower()
    
    try:
        file_bytes = read_file_from_s3(bucket, key)
        
        if extension == ".docx":
            return extract_text_from_docx_bytes(file_bytes)
        elif extension == ".txt":
            return extract_text_from_txt_bytes(file_bytes)
        elif extension == ".eml":
            return extract_text_from_eml_bytes(file_bytes)
        else:
            print(f"  ⚠️ Unsupported file type: {extension} for {key}")
            return None
            
    except Exception as e:
        print(f"  ❌ Error extracting text from {key}: {e}")
        return None
