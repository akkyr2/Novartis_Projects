"""
S3 Utilities for Batch Data Ingestion.

This module provides functions for:
- Listing files in S3 folders
- Mapping folder names to source types
"""

import os
from typing import List, Optional

from .aws_clients import get_s3_client
from .config import FOLDER_SOURCE_TYPE_MAP, SUPPORTED_EXTENSIONS


def list_s3_files(
    bucket: str,
    prefix: str,
    extensions: Optional[List[str]] = None
) -> List[str]:
    """
    List all files in an S3 prefix (with pagination).
    Optionally filter by file extensions.
    
    Args:
        bucket: S3 bucket name
        prefix: S3 prefix (folder path)
        extensions: List of allowed file extensions (e.g., [".docx", ".txt"])
        
    Returns:
        List of S3 object keys
    """
    if extensions is None:
        extensions = SUPPORTED_EXTENSIONS
    
    s3_client = get_s3_client()
    paginator = s3_client.get_paginator("list_objects_v2")
    pages = paginator.paginate(Bucket=bucket, Prefix=prefix)
    
    keys = []
    for page in pages:
        if "Contents" in page:
            for obj in page["Contents"]:
                key = obj["Key"]
                # Skip folder markers
                if key.endswith("/"):
                    continue
                # Filter by extension
                ext = os.path.splitext(key)[1].lower()
                if ext in extensions:
                    keys.append(key)
    
    return keys


def get_source_type_for_folder(folder_name: str) -> str:
    """
    Map folder name to source_type.
    
    Args:
        folder_name: Folder path (e.g., "transcripts/", "meetings/chats/")
        
    Returns:
        Source type string (e.g., "meeting_transcript", "meeting_chat")
    """
    # Clean the folder name
    folder_clean = folder_name.strip("/")
    
    # Try exact match first
    if folder_clean in FOLDER_SOURCE_TYPE_MAP:
        return FOLDER_SOURCE_TYPE_MAP[folder_clean]
    
    # Try partial match from path components
    folder_parts = folder_clean.split("/")
    for part in folder_parts:
        if part in FOLDER_SOURCE_TYPE_MAP:
            return FOLDER_SOURCE_TYPE_MAP[part]
    
    # Default fallback based on common patterns
    if "transcript" in folder_clean.lower():
        return "meeting_transcript"
    elif "chat" in folder_clean.lower():
        return "meeting_chat"
    elif "email" in folder_clean.lower():
        return "email"
    elif "channel" in folder_clean.lower():
        return "teams_channel_post"
    
    # Ultimate fallback
    return "email"


def get_file_metadata(bucket: str, key: str) -> dict:
    """
    Get metadata for a specific S3 object.
    
    Args:
        bucket: S3 bucket name
        key: S3 object key
        
    Returns:
        Dict with file metadata (size, last_modified, etc.)
    """
    try:
        s3_client = get_s3_client()
        response = s3_client.head_object(Bucket=bucket, Key=key)
        
        return {
            "key": key,
            "size_bytes": response.get("ContentLength", 0),
            "last_modified": response.get("LastModified"),
            "content_type": response.get("ContentType", ""),
            "etag": response.get("ETag", "").strip('"')
        }
    except Exception as e:
        return {"error": str(e)}
