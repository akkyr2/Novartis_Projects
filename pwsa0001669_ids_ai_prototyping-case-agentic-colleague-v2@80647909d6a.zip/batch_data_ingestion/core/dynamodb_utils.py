"""
DynamoDB Utilities for Batch Data Ingestion.

This module provides functions for writing to DynamoDB tables:
- WorkItems table (centralized data store for all work items and tasks)
"""

import uuid
from typing import Any, Dict, List, Optional

from .aws_clients import get_dynamodb_resource
from .config import DYNAMODB_WORK_ITEMS_TABLE
from .helpers import utc_now_iso


def write_work_item(
    work_item: Dict[str, Any],
    table_name: str = DYNAMODB_WORK_ITEMS_TABLE
) -> bool:
    """
    Write a single work item to DynamoDB.
    
    Args:
        work_item: Work item dict with PK, SK, and other attributes
        table_name: DynamoDB table name
        
    Returns:
        True if successful, False otherwise
    """
    try:
        dynamodb = get_dynamodb_resource()
        table = dynamodb.Table(table_name)
        table.put_item(Item=work_item)
        return True
    except Exception as e:
        print(f"    ⚠️ WorkItem write failed: {e}")
        return False


def write_to_dynamodb(
    cleaned_json: Dict[str, Any],
    source_uri: str,
    source_type: str,
    summary: str,
    matched_project: Optional[Dict[str, Any]] = None
) -> int:
    """
    Write action items to DynamoDB WorkItems table.
    
    Args:
        cleaned_json: Cleaned content from LLM
        source_uri: S3 URI of source file
        source_type: Type of source
        summary: Summary of the content
        matched_project: Optional matched project info with project_id and project_name
        
    Returns:
        Number of items written
    """
    action_items = cleaned_json.get("action_items", [])
    
    # Use matched project if available, otherwise fall back to LLM-detected project
    if matched_project and matched_project.get("project_name"):
        project_name = matched_project["project_name"]
        project_id = matched_project.get("project_id", "")
    else:
        entities = cleaned_json.get("entities", {})
        projects = entities.get("projects", [])
        project_name = projects[0] if projects else "Unassigned"
        project_id = ""
    
    dynamodb = get_dynamodb_resource()
    work_items_table = dynamodb.Table(DYNAMODB_WORK_ITEMS_TABLE)
    
    count = 0
    
    for item in action_items:
        if not isinstance(item, dict):
            continue
        
        title = item.get("description", item.get("title", ""))
        if not title:
            continue
        
        work_item_id = f"WI_{uuid.uuid4().hex[:8]}"
        now = utc_now_iso()
        
        # Build work item with matched project info
        work_item = {
            "PK": f"PROJECT#{project_name}",
            "SK": f"TASK#{work_item_id}",
            "work_item_id": work_item_id,
            "project_id": project_id,
            "project_name": project_name,
            "task": title,
            "assignee": item.get("owner", "Unassigned"),
            "assigned_to": item.get("owner", "Unassigned"),  # UI compatibility field
            "due_date": item.get("due_date", ""),
            "status": item.get("status", "pending"),
            "source_type": source_type,
            "source_uri": source_uri,
            "summary": f"{title} | {summary[:200]}",
            "task_evidence": f"{summary}\n\n{cleaned_json.get('clean_text', '')[:1000]}",
            "event_timestamp": now,
            "evidence_id": "",
        }
        
        try:
            # Write to WorkItems - the single source of truth
            work_items_table.put_item(Item=work_item)
            count += 1
            
        except Exception as e:
            print(f"    ⚠️ DynamoDB write failed for {title}: {e}")
    
    return count


def get_dynamodb_stats(table_name: str) -> Dict[str, Any]:
    """
    Get statistics about a DynamoDB table.
    
    Args:
        table_name: Name of the DynamoDB table
        
    Returns:
        Dict with item count and table info
    """
    try:
        dynamodb = get_dynamodb_resource()
        table = dynamodb.Table(table_name)
        
        return {
            "table_name": table_name,
            "item_count": table.item_count,
            "table_status": table.table_status
        }
    except Exception as e:
        return {"error": str(e)}
