"""
Batch Data Ingestion - Core Module
==================================
Shared utilities and configurations for both transcript and chat data ingestion pipelines.

This module provides:
- AWS client initialization (S3, DynamoDB, OpenSearch, Bedrock)
- Common text extraction functions (DOCX, TXT, EML)
- Embedding generation using AWS Titan v2
- LLM cleaning with Claude via Bedrock
- OpenSearch indexing utilities
- DynamoDB write utilities
- Project matching logic

Usage:
    from batch_data_ingestion.core import (
        get_s3_client,
        get_dynamodb_resource,
        extract_text_from_docx_bytes,
        generate_embedding,
        clean_text_with_llm,
        index_to_opensearch,
        write_to_dynamodb,
    )
"""

from .config import (
    BUCKET_NAME,
    BASE_PREFIX,
    TRANSCRIPT_PREFIX,
    CHAT_PREFIX,
    OPENSEARCH_HOST,
    OPENSEARCH_INDEX,
    DYNAMODB_WORK_ITEMS_TABLE,
    EMBEDDING_DIMENSION,
    FOLDER_SOURCE_TYPE_MAP,
)

from .aws_clients import (
    get_s3_client,
    get_dynamodb_resource,
    get_bedrock_client,
    get_fresh_awsauth,
)

from .text_extraction import (
    extract_text_from_docx_bytes,
    extract_text_from_txt_bytes,
    extract_text_from_eml_bytes,
    read_file_from_s3,
    extract_text_from_s3_file,
)

from .llm_processing import (
    clean_text_with_llm,
    generate_embedding,
    generate_content_hash,
    split_text_into_chunks,
    CHUNK_SIZE,
    CHUNK_OVERLAP,
)

from .project_matching import (
    load_seeded_projects,
    get_seeded_projects_context,
    match_project_with_llm,
)

from .opensearch_utils import (
    build_work_evidence_doc,
    build_work_evidence_doc_with_chunks,
    index_to_opensearch,
    index_document_with_chunks,
    check_duplicate_in_opensearch,
)

from .dynamodb_utils import (
    write_to_dynamodb,
    write_work_item,
)

from .s3_utils import (
    list_s3_files,
    get_source_type_for_folder,
)

from .helpers import (
    utc_now_iso,
    print_separator,
    print_section,
)

__all__ = [
    # Config
    "BUCKET_NAME",
    "BASE_PREFIX",
    "TRANSCRIPT_PREFIX",
    "CHAT_PREFIX",
    "OPENSEARCH_HOST",
    "OPENSEARCH_INDEX",
    "DYNAMODB_WORK_ITEMS_TABLE",
    "EMBEDDING_DIMENSION",
    "FOLDER_SOURCE_TYPE_MAP",
    # AWS Clients
    "get_s3_client",
    "get_dynamodb_resource",
    "get_bedrock_client",
    "get_fresh_awsauth",
    # Text Extraction
    "extract_text_from_docx_bytes",
    "extract_text_from_txt_bytes",
    "extract_text_from_eml_bytes",
    "read_file_from_s3",
    "extract_text_from_s3_file",
    # LLM Processing
    "clean_text_with_llm",
    "generate_embedding",
    "generate_content_hash",
    "split_text_into_chunks",
    "CHUNK_SIZE",
    "CHUNK_OVERLAP",
    # Project Matching
    "load_seeded_projects",
    "get_seeded_projects_context",
    "match_project_with_llm",
    # OpenSearch
    "build_work_evidence_doc",
    "build_work_evidence_doc_with_chunks",
    "index_to_opensearch",
    "index_document_with_chunks",
    "check_duplicate_in_opensearch",
    # DynamoDB
    "write_to_dynamodb",
    "write_work_item",
    # S3
    "list_s3_files",
    "get_source_type_for_folder",
    # Helpers
    "utc_now_iso",
    "print_separator",
    "print_section",
]
