"""
OpenSearch Utilities for Batch Data Ingestion.

This module provides functions for:
- Building work evidence documents for OpenSearch
- Indexing documents to OpenSearch
- Checking for duplicates
- Multi-vector chunk indexing for full document coverage
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import requests

from .aws_clients import get_fresh_awsauth
from .config import OPENSEARCH_HOST, OPENSEARCH_INDEX
from .helpers import utc_now_iso


def build_work_evidence_doc(
    cleaned_json: Dict[str, Any],
    source_uri: str,
    source_type: str,
    content_hash: str,
    embedding: List[float],
    matched_project: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Build the work_evidence document for OpenSearch.
    
    Args:
        cleaned_json: Cleaned and structured content from LLM
        source_uri: S3 URI of the source file
        source_type: Type of source (email, meeting_transcript, meeting_chat, etc.)
        content_hash: MD5 hash of content for deduplication
        embedding: Vector embedding of the content
        matched_project: Optional matched project info with project_id and project_name
        
    Returns:
        Document ready for OpenSearch indexing
    """
    
    evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()
    
    clean_text = cleaned_json.get("clean_text", "")
    summary = cleaned_json.get("summary", clean_text[:300])
    entities = cleaned_json.get("entities", {})
    action_items = cleaned_json.get("action_items", [])
    decisions = cleaned_json.get("decisions", [])
    
    # Use matched project info if available
    if matched_project:
        project_id = matched_project.get("project_id", "")
        project_name = matched_project.get("project_name", "")
    else:
        project_id = ""
        project_name = ""
    
    # Build embedding text
    people = entities.get("people", [])
    projects = entities.get("projects", [])
    dates = entities.get("dates", [])
    
    embedding_text = f"{clean_text}\n{summary}"
    if project_name:
        embedding_text += f"\nProject: {project_name}"
    elif projects:
        embedding_text += f"\nProjects: {', '.join(projects)}"
    if people:
        embedding_text += f"\nPeople: {', '.join(people)}"
    
    # Format action items for OpenSearch
    action_items_detected = []
    for item in action_items:
        if isinstance(item, dict):
            action_items_detected.append({
                "title": item.get("description", item.get("title", "")),
                "description": item.get("description", ""),
                "owner": item.get("owner", ""),
                "due_date": item.get("due_date", ""),
                "status": item.get("status", "pending"),
                "confidence": float(item.get("confidence", 0.9))
            })
    
    # Format decisions for OpenSearch
    decisions_detected = []
    for dec in decisions:
        if isinstance(dec, dict):
            decisions_detected.append({
                "decision": dec.get("description", dec.get("decision", "")),
                "confidence": float(dec.get("confidence", 0.9))
            })
        elif isinstance(dec, str):
            decisions_detected.append({
                "decision": dec,
                "confidence": 0.9
            })
    
    doc = {
        "evidence_id": evidence_id,
        "workspace_id": "default-workspace",
        "project_id": project_id,
        "project_name": project_name,
        "source_type": source_type,
        "source_uri": source_uri,
        "content_hash": content_hash,
        "raw_text": json.dumps(cleaned_json, default=str),
        "clean_text": clean_text,
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": [],
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": dates if isinstance(dates, list) else [],
        "metadata": {
            "source_uri": source_uri,
            "entities": entities,
            "matched_project": matched_project
        },
        "created_at": now,
        "updated_at": now,
        "vector_embedding": embedding
    }
    
    return doc


def index_to_opensearch(doc: Dict[str, Any], refresh: bool = True) -> Dict[str, Any]:
    """
    Index a document to OpenSearch with fresh credentials.
    
    Args:
        doc: Document to index (must include vector_embedding)
        refresh: If True, forces immediate refresh so document is searchable right away.
                 This prevents duplicate detection failures in rapid successive jobs.
                 Default is True to ensure deduplication works correctly.
        
    Returns:
        Dict with status_code and response text
    """
    # Note: AWS OpenSearch Serverless doesn't support ?refresh=true parameter
    # Instead, we do an explicit _refresh call after indexing
    url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_doc"
    
    # Get fresh credentials to avoid 403 errors from expired tokens
    awsauth = get_fresh_awsauth()
    
    response = requests.post(
        url,
        auth=awsauth,
        headers={"Content-Type": "application/json"},
        data=json.dumps(doc)
    )
    
    # If indexing succeeded and refresh requested, force a refresh
    # This makes the document immediately searchable for deduplication
    if refresh and response.status_code in (200, 201):
        try:
            refresh_url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_refresh"
            requests.post(refresh_url, auth=awsauth)
        except Exception:
            pass  # Non-critical, dedup will still work on next refresh cycle
    
    return {
        "status_code": response.status_code,
        "text": response.text
    }


def check_duplicate_in_opensearch(content_hash: str, source_uri: str = None) -> bool:
    """
    Check if a document with this content_hash or source_uri already exists.
    
    Uses refresh=true to ensure we see the latest indexed documents,
    preventing race conditions when multiple jobs run in succession.
    
    Args:
        content_hash: MD5 hash of content to check
        source_uri: Optional S3 URI to check (checks both hash and URI)
        
    Returns:
        True if duplicate exists, False otherwise
    """
    try:
        # Force refresh before search to see recently indexed documents
        # This prevents false negatives when jobs run back-to-back
        refresh_url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_refresh"
        awsauth = get_fresh_awsauth()
        requests.post(refresh_url, auth=awsauth)
        
        url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_search"
        
        # Build query - check both content_hash OR source_uri
        if source_uri:
            # Check for either content hash match OR source URI match
            body = {
                "size": 1,
                "query": {
                    "bool": {
                        "should": [
                            {"term": {"content_hash": content_hash}},
                            {"term": {"source_uri.keyword": source_uri}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "_source": ["content_hash", "evidence_id", "source_uri"]
            }
        else:
            # Just check content hash
            body = {
                "size": 1,
                "query": {
                    "term": {"content_hash": content_hash}
                },
                "_source": ["content_hash", "evidence_id"]
            }
        
        response = requests.post(
            url,
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            data=json.dumps(body)
        )
        
        if response.status_code != 200:
            print(f"  ⚠️ Dedup check returned status {response.status_code}")
            return False
        
        result = response.json()
        hits = result.get("hits", {}).get("hits", [])
        
        if hits:
            existing_id = hits[0].get("_source", {}).get("evidence_id", "unknown")
            print(f"     ℹ️ Duplicate found: {existing_id}")
            return True
        return False
        
    except Exception as e:
        print(f"  ⚠️ Dedup check failed: {e}")
        return False


def get_opensearch_stats() -> Dict[str, Any]:
    """
    Get statistics about the OpenSearch index.
    
    Returns:
        Dict with count and index info
    """
    try:
        awsauth = get_fresh_awsauth()
        
        # Get count
        count_url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_count"
        count_response = requests.get(
            count_url,
            auth=awsauth,
            headers={"Content-Type": "application/json"}
        )
        
        count = 0
        if count_response.status_code == 200:
            count = count_response.json().get("count", 0)
        
        return {
            "index": OPENSEARCH_INDEX,
            "host": OPENSEARCH_HOST,
            "document_count": count
        }
        
    except Exception as e:
        return {"error": str(e)}


# ============================================================================
# MULTI-VECTOR EMBEDDING SUPPORT
# ============================================================================

def build_work_evidence_doc_with_chunks(
    cleaned_json: Dict[str, Any],
    source_uri: str,
    source_type: str,
    content_hash: str,
    chunk_embeddings: List[Tuple[str, List[float], int, int]],
    matched_project: Optional[Dict[str, Any]] = None
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """
    Build work_evidence documents with multi-vector chunk support.
    
    Creates:
    1. A parent document with full metadata, action items, decisions (uses first chunk embedding for backward compatibility)
    2. Multiple chunk documents, each with their own embedding for full-text semantic search
    
    Args:
        cleaned_json: Cleaned and structured content from LLM (merged from all chunks)
        source_uri: S3 URI of the source file
        source_type: Type of source (email, meeting_transcript, meeting_chat, etc.)
        content_hash: MD5 hash of content for deduplication
        chunk_embeddings: List of (chunk_text, embedding, start_idx, end_idx) tuples
        matched_project: Optional matched project info with project_id and project_name
        
    Returns:
        Tuple of (parent_doc, list_of_chunk_docs)
    """
    
    parent_evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
    now = utc_now_iso()
    
    clean_text = cleaned_json.get("clean_text", "")
    summary = cleaned_json.get("summary", clean_text[:300])
    entities = cleaned_json.get("entities", {})
    action_items = cleaned_json.get("action_items", [])
    decisions = cleaned_json.get("decisions", [])
    
    # Use matched project info if available
    if matched_project:
        project_id = matched_project.get("project_id", "")
        project_name = matched_project.get("project_name", "")
    else:
        project_id = ""
        project_name = ""
    
    # Build embedding text for parent (summary-based)
    people = entities.get("people", [])
    projects = entities.get("projects", [])
    dates = entities.get("dates", [])
    
    embedding_text = f"{summary}"
    if project_name:
        embedding_text += f"\nProject: {project_name}"
    elif projects:
        embedding_text += f"\nProjects: {', '.join(projects)}"
    if people:
        embedding_text += f"\nPeople: {', '.join(people)}"
    
    # Format action items for OpenSearch
    action_items_detected = []
    for item in action_items:
        if isinstance(item, dict):
            action_items_detected.append({
                "title": item.get("description", item.get("title", "")),
                "description": item.get("description", ""),
                "owner": item.get("owner", ""),
                "due_date": item.get("due_date", ""),
                "status": item.get("status", "pending"),
                "confidence": float(item.get("confidence", 0.9))
            })
    
    # Format decisions for OpenSearch
    decisions_detected = []
    for dec in decisions:
        if isinstance(dec, dict):
            decisions_detected.append({
                "decision": dec.get("description", dec.get("decision", "")),
                "confidence": float(dec.get("confidence", 0.9))
            })
        elif isinstance(dec, str):
            decisions_detected.append({
                "decision": dec,
                "confidence": 0.9
            })
    
    # Use first chunk's embedding for parent document (backward compatibility)
    parent_embedding = chunk_embeddings[0][1] if chunk_embeddings else []
    
    # Parent document - contains ALL metadata, action items, decisions, full clean_text
    parent_doc = {
        "evidence_id": parent_evidence_id,
        "workspace_id": "default-workspace",
        "project_id": project_id,
        "project_name": project_name,
        "source_type": source_type,
        "source_uri": source_uri,
        "content_hash": content_hash,
        "raw_text": json.dumps(cleaned_json, default=str),
        "clean_text": clean_text,  # Full combined clean text from all chunks
        "summary": summary,
        "embedding_text": embedding_text,
        "linked_work_item_ids": [],
        "action_items_detected": action_items_detected,
        "decisions_detected": decisions_detected,
        "dates_detected": dates if isinstance(dates, list) else [],
        "metadata": {
            "source_uri": source_uri,
            "entities": entities,
            "matched_project": matched_project,
            "chunk_count": len(chunk_embeddings),
            "original_text_length": len(clean_text),
            "is_parent_doc": True
        },
        "created_at": now,
        "updated_at": now,
        "vector_embedding": parent_embedding,
        "is_chunk": False,
        "chunk_index": 0,
        "total_chunks": len(chunk_embeddings)
    }
    
    # Chunk documents - each has its own embedding for semantic search
    chunk_docs = []
    for idx, (chunk_text, chunk_embedding, start_idx, end_idx) in enumerate(chunk_embeddings):
        chunk_evidence_id = f"{parent_evidence_id}_chunk_{idx}"
        
        chunk_doc = {
            "evidence_id": chunk_evidence_id,
            "parent_evidence_id": parent_evidence_id,  # Link to parent
            "workspace_id": "default-workspace",
            "project_id": project_id,
            "project_name": project_name,
            "source_type": source_type,
            "source_uri": source_uri,
            "content_hash": f"{content_hash}_chunk_{idx}",
            "clean_text": chunk_text,  # Just this chunk's text
            "summary": summary,  # Same summary for context
            "embedding_text": chunk_text,
            "metadata": {
                "source_uri": source_uri,
                "parent_evidence_id": parent_evidence_id,
                "chunk_index": idx,
                "total_chunks": len(chunk_embeddings),
                "char_start": start_idx,
                "char_end": end_idx,
                "is_chunk": True
            },
            "created_at": now,
            "updated_at": now,
            "vector_embedding": chunk_embedding,
            "is_chunk": True,
            "chunk_index": idx,
            "total_chunks": len(chunk_embeddings)
        }
        chunk_docs.append(chunk_doc)
    
    return parent_doc, chunk_docs


def index_document_with_chunks(
    parent_doc: Dict[str, Any],
    chunk_docs: List[Dict[str, Any]],
    refresh: bool = True
) -> Dict[str, Any]:
    """
    Index parent document and all chunk documents to OpenSearch.
    
    Args:
        parent_doc: The parent document with full metadata
        chunk_docs: List of chunk documents with individual embeddings
        refresh: If True, forces immediate refresh
        
    Returns:
        Dict with indexing results
    """
    awsauth = get_fresh_awsauth()
    url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_doc"
    
    results = {
        "parent_indexed": False,
        "chunks_indexed": 0,
        "total_chunks": len(chunk_docs),
        "errors": []
    }
    
    # Index parent document
    try:
        response = requests.post(
            url,
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            data=json.dumps(parent_doc)
        )
        if response.status_code in (200, 201):
            results["parent_indexed"] = True
        else:
            results["errors"].append(f"Parent: {response.status_code} - {response.text[:100]}")
    except Exception as e:
        results["errors"].append(f"Parent: {str(e)}")
    
    # Index chunk documents
    for chunk_doc in chunk_docs:
        try:
            response = requests.post(
                url,
                auth=awsauth,
                headers={"Content-Type": "application/json"},
                data=json.dumps(chunk_doc)
            )
            if response.status_code in (200, 201):
                results["chunks_indexed"] += 1
            else:
                results["errors"].append(f"Chunk {chunk_doc.get('chunk_index')}: {response.status_code}")
        except Exception as e:
            results["errors"].append(f"Chunk: {str(e)}")
    
    # Refresh index if requested
    if refresh:
        try:
            refresh_url = f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_refresh"
            requests.post(refresh_url, auth=awsauth)
        except Exception:
            pass
    
    return results
