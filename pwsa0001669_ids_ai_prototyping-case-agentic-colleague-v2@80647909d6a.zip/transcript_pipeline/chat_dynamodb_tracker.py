"""
DynamoDB Tracker for the Meeting Chat Pipeline.

Manages chat processing state in a SHARED DynamoDB table with transcripts:
- Table Name: AgenticColleague_MeetingTracker (configurable)
- Primary Key: record_id (stores chat_id for chat records)
- Record Type: "CHAT" for chat records, "CHAT_METADATA" for pipeline metadata
- GSI: record_type-status-index for querying by type and status

Features:
- Tracking chat processing status (PENDING, PROCESSING, COMPLETED, FAILED, PERMANENTLY_FAILED)
- Retry logic with configurable max attempts
- Querying for unprocessed or failed chats
- Pipeline metadata for incremental runs

Usage:
    from chat_dynamodb_tracker import ChatDynamoDBTracker
    from config import Config
    
    config = Config()
    tracker = ChatDynamoDBTracker(config)
    
    # Check if chat is already processed
    if not tracker.is_processed(chat_id):
        tracker.mark_processing(chat_id, meeting_id, subject, join_url)
        # ... process chat ...
        tracker.mark_completed(chat_id, s3_path)
"""

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.config import Config, DynamoDBError


# =============================================================================
# CONSTANTS
# =============================================================================

# Record type identifier for chat records in the shared table
RECORD_TYPE_CHAT = "CHAT"

# Special record ID for chat pipeline metadata (not a real chat)
CHAT_PIPELINE_METADATA_ID = "__CHAT_PIPELINE_METADATA__"


# =============================================================================
# ENUMS AND DATA CLASSES
# =============================================================================

class ChatStatus(Enum):
    """Chat processing status."""
    
    PENDING = "PENDING"                       # Discovered but not yet processed
    PROCESSING = "PROCESSING"                 # Currently being processed
    COMPLETED = "COMPLETED"                   # Successfully processed and uploaded
    FAILED = "FAILED"                         # Failed, can be retried
    PERMANENTLY_FAILED = "PERMANENTLY_FAILED" # Failed after max retries


@dataclass
class ChatRecord:
    """Represents a chat tracking record in DynamoDB."""
    
    chat_id: str
    meeting_id: str
    join_url: str
    meeting_subject: str
    status: ChatStatus
    record_type: str = RECORD_TYPE_CHAT  # To distinguish from transcript records
    message_count: int = 0
    retry_count: int = 0
    max_retries: int = 3
    s3_path: Optional[str] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    processed_at: Optional[str] = None
    
    @classmethod
    def from_dynamodb_item(cls, item: dict) -> "ChatRecord":
        """Create ChatRecord from DynamoDB item."""
        # Support both old (chat_id) and new (record_id) schema
        record_id = item.get("record_id", {}).get("S") or item.get("chat_id", {}).get("S", "")
        return cls(
            chat_id=record_id,
            meeting_id=item.get("meeting_id", {}).get("S", ""),
            join_url=item.get("join_url", {}).get("S", ""),
            meeting_subject=item.get("meeting_subject", {}).get("S", ""),
            status=ChatStatus(item.get("status", {}).get("S", "PENDING")),
            record_type=item.get("record_type", {}).get("S", RECORD_TYPE_CHAT),
            message_count=int(item.get("message_count", {}).get("N", "0")),
            retry_count=int(item.get("retry_count", {}).get("N", "0")),
            max_retries=int(item.get("max_retries", {}).get("N", "3")),
            s3_path=item.get("s3_path", {}).get("S"),
            error_message=item.get("error_message", {}).get("S"),
            created_at=item.get("created_at", {}).get("S"),
            updated_at=item.get("updated_at", {}).get("S"),
            processed_at=item.get("processed_at", {}).get("S"),
        )
    
    def to_dynamodb_item(self) -> dict:
        """Convert to DynamoDB item format."""
        item = {
            "record_id": {"S": self.chat_id},  # Use record_id as primary key
            "record_type": {"S": self.record_type},  # Distinguish from transcripts
            "meeting_id": {"S": self.meeting_id},
            "join_url": {"S": self.join_url},
            "meeting_subject": {"S": self.meeting_subject},
            "status": {"S": self.status.value},
            "message_count": {"N": str(self.message_count)},
            "retry_count": {"N": str(self.retry_count)},
            "max_retries": {"N": str(self.max_retries)},
        }
        
        if self.s3_path:
            item["s3_path"] = {"S": self.s3_path}
        if self.error_message:
            item["error_message"] = {"S": self.error_message}
        if self.created_at:
            item["created_at"] = {"S": self.created_at}
        if self.updated_at:
            item["updated_at"] = {"S": self.updated_at}
        if self.processed_at:
            item["processed_at"] = {"S": self.processed_at}
        
        return item
    
    @property
    def can_retry(self) -> bool:
        """Check if this record can be retried."""
        return (
            self.status == ChatStatus.FAILED 
            and self.retry_count < self.max_retries
        )
    
    @property
    def is_processable(self) -> bool:
        """Check if this chat should be processed."""
        return self.status in [
            ChatStatus.PENDING,
            ChatStatus.FAILED,
        ] and self.retry_count < self.max_retries


# =============================================================================
# DYNAMODB TRACKER CLASS FOR CHATS
# =============================================================================

class ChatDynamoDBTracker:
    """
    DynamoDB Tracker for managing meeting chat processing state.
    
    Uses SHARED table with transcript tracker (AgenticColleague_MeetingTracker).
    Records are distinguished by record_type field:
    - CHAT: Chat records
    - CHAT_METADATA: Pipeline run metadata
    
    Handles:
    - Creating/checking DynamoDB table existence (shared with transcripts)
    - Tracking chat processing status
    - Retry logic for failed chats
    - Pipeline metadata for incremental runs
    """
    
    def __init__(self, config: Config, auto_create_table: bool = True):
        """
        Initialize the Chat DynamoDB Tracker.
        
        Args:
            config: Configuration instance
            auto_create_table: Whether to auto-create the table if missing
            
        Raises:
            DynamoDBError: If connection fails or table cannot be created
        """
        self.config = config
        self.logger = config.logger
        
        # Use SHARED table with transcript tracker
        # Table name comes from config (AgenticColleague_MeetingTracker)
        self.table_name = config.dynamodb_table_name
        
        self.max_retries = config.max_retry_attempts
        
        try:
            self._client = boto3.client("dynamodb", region_name=config.aws_region)
            self._resource = boto3.resource("dynamodb", region_name=config.aws_region)
            self._table = self._resource.Table(self.table_name)
            self.logger.debug(f"Connected to DynamoDB for chat tracking in region {config.aws_region}")
            
        except NoCredentialsError:
            raise DynamoDBError(
                "No AWS credentials found. "
                "Ensure AWS credentials are configured."
            )
        except Exception as e:
            raise DynamoDBError(f"Failed to connect to DynamoDB: {e}")
        
        if auto_create_table:
            self._ensure_table_exists()
    
    # -------------------------------------------------------------------------
    # TABLE MANAGEMENT
    # -------------------------------------------------------------------------
    
    def _ensure_table_exists(self):
        """Ensure the DynamoDB table exists, creating it if necessary."""
        try:
            self._client.describe_table(TableName=self.table_name)
            self.logger.debug(f"DynamoDB table '{self.table_name}' exists")
            
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                self.logger.info(f"Creating DynamoDB table '{self.table_name}'...")
                self._create_table()
            else:
                raise DynamoDBError(f"Error checking table: {e}")
    
    def _create_table(self):
        """
        Create the shared DynamoDB table for both chat and transcript tracking.
        
        Schema:
        - Primary Key: record_id (chat_id or transcript_id)
        - GSI: record_type-status-index (for querying by type and status)
        """
        try:
            self._client.create_table(
                TableName=self.table_name,
                KeySchema=[
                    {"AttributeName": "record_id", "KeyType": "HASH"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "record_id", "AttributeType": "S"},
                    {"AttributeName": "record_type", "AttributeType": "S"},
                    {"AttributeName": "status", "AttributeType": "S"},
                ],
                GlobalSecondaryIndexes=[
                    {
                        "IndexName": "record_type-status-index",
                        "KeySchema": [
                            {"AttributeName": "record_type", "KeyType": "HASH"},
                            {"AttributeName": "status", "KeyType": "RANGE"},
                        ],
                        "Projection": {"ProjectionType": "ALL"},
                    },
                ],
                BillingMode="PAY_PER_REQUEST",
            )
            
            # Wait for table to be created
            waiter = self._client.get_waiter("table_exists")
            waiter.wait(TableName=self.table_name)
            
            self.logger.info(f"✅ Created DynamoDB table '{self.table_name}'")
            
        except ClientError as e:
            raise DynamoDBError(f"Failed to create table: {e}")
    
    # -------------------------------------------------------------------------
    # RECORD OPERATIONS
    # -------------------------------------------------------------------------
    
    def _now_iso(self) -> str:
        """Get current timestamp in ISO format."""
        return datetime.now(timezone.utc).isoformat()
    
    def get_record(self, chat_id: str) -> Optional[ChatRecord]:
        """
        Get a chat record by ID.
        
        Args:
            chat_id: Chat thread ID
            
        Returns:
            ChatRecord or None if not found
        """
        try:
            response = self._client.get_item(
                TableName=self.table_name,
                Key={"record_id": {"S": chat_id}},
            )
            
            item = response.get("Item")
            if item:
                record = ChatRecord.from_dynamodb_item(item)
                # Verify this is a CHAT record, not a transcript
                if record.record_type == RECORD_TYPE_CHAT:
                    return record
            return None
            
        except ClientError as e:
            raise DynamoDBError(f"Error getting record: {e}")
    
    def is_processed(self, chat_id: str) -> bool:
        """Check if a chat has already been successfully processed."""
        record = self.get_record(chat_id)
        return record is not None and record.status == ChatStatus.COMPLETED
    
    def should_process(self, chat_id: str) -> bool:
        """
        Check if a chat should be processed.
        
        Returns True if:
        - Chat doesn't exist in the database
        - Chat exists but is in PENDING status
        - Chat exists, is in FAILED status, and has retries remaining
        """
        record = self.get_record(chat_id)
        
        if record is None:
            return True
        
        return record.is_processable
    
    def mark_processing(
        self,
        chat_id: str,
        meeting_id: str,
        meeting_subject: str,
        join_url: str,
        message_count: int = 0,
    ) -> ChatRecord:
        """
        Mark a chat as currently being processed.
        
        Args:
            chat_id: Chat thread ID
            meeting_id: Online meeting ID
            meeting_subject: Meeting subject/title
            join_url: Teams meeting join URL
            message_count: Number of messages in the chat
            
        Returns:
            Created/updated ChatRecord
        """
        now = self._now_iso()
        
        existing = self.get_record(chat_id)
        
        record = ChatRecord(
            chat_id=chat_id,
            meeting_id=meeting_id,
            join_url=join_url,
            meeting_subject=meeting_subject,
            status=ChatStatus.PROCESSING,
            message_count=message_count,
            retry_count=existing.retry_count if existing else 0,
            max_retries=self.max_retries,
            created_at=existing.created_at if existing else now,
            updated_at=now,
        )
        
        try:
            self._client.put_item(
                TableName=self.table_name,
                Item=record.to_dynamodb_item(),
            )
            self.logger.debug(f"Marked chat as PROCESSING: {chat_id[:30]}...")
            return record
            
        except ClientError as e:
            raise DynamoDBError(f"Error marking chat as processing: {e}")
    
    def mark_completed(self, chat_id: str, s3_path: str) -> ChatRecord:
        """
        Mark a chat as successfully processed.
        
        Args:
            chat_id: Chat thread ID
            s3_path: S3 path where chat document was uploaded
            
        Returns:
            Updated ChatRecord
        """
        now = self._now_iso()
        
        try:
            self._client.update_item(
                TableName=self.table_name,
                Key={"record_id": {"S": chat_id}},
                UpdateExpression=(
                    "SET #status = :status, s3_path = :s3_path, "
                    "updated_at = :updated_at, processed_at = :processed_at, "
                    "error_message = :empty"
                ),
                ExpressionAttributeNames={"#status": "status"},
                ExpressionAttributeValues={
                    ":status": {"S": ChatStatus.COMPLETED.value},
                    ":s3_path": {"S": s3_path},
                    ":updated_at": {"S": now},
                    ":processed_at": {"S": now},
                    ":empty": {"S": ""},
                },
            )
            
            self.logger.debug(f"Marked chat as COMPLETED: {chat_id[:30]}...")
            return self.get_record(chat_id)
            
        except ClientError as e:
            raise DynamoDBError(f"Error marking chat as completed: {e}")
    
    def mark_failed(
        self,
        chat_id: str,
        error_message: str,
        increment_retry: bool = True,
    ) -> ChatRecord:
        """
        Mark a chat as failed.
        
        Args:
            chat_id: Chat thread ID
            error_message: Error message describing the failure
            increment_retry: Whether to increment retry count
            
        Returns:
            Updated ChatRecord
        """
        now = self._now_iso()
        existing = self.get_record(chat_id)
        
        new_retry_count = (existing.retry_count if existing else 0)
        if increment_retry:
            new_retry_count += 1
        
        # Determine if permanently failed
        if new_retry_count >= self.max_retries:
            new_status = ChatStatus.PERMANENTLY_FAILED
        else:
            new_status = ChatStatus.FAILED
        
        try:
            self._client.update_item(
                TableName=self.table_name,
                Key={"record_id": {"S": chat_id}},
                UpdateExpression=(
                    "SET #status = :status, error_message = :error, "
                    "retry_count = :retry, updated_at = :updated"
                ),
                ExpressionAttributeNames={"#status": "status"},
                ExpressionAttributeValues={
                    ":status": {"S": new_status.value},
                    ":error": {"S": error_message[:1000]},
                    ":retry": {"N": str(new_retry_count)},
                    ":updated": {"S": now},
                },
            )
            
            self.logger.debug(
                f"Marked chat as {new_status.value}: {chat_id[:30]}... (retry {new_retry_count})"
            )
            return self.get_record(chat_id)
            
        except ClientError as e:
            raise DynamoDBError(f"Error marking chat as failed: {e}")
    
    # -------------------------------------------------------------------------
    # QUERY OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_by_status(self, status: ChatStatus, limit: int = 100) -> List[ChatRecord]:
        """
        Get all CHAT records with a specific status.
        
        Uses the record_type-status-index GSI to filter by both record_type and status.
        """
        try:
            response = self._client.query(
                TableName=self.table_name,
                IndexName="record_type-status-index",
                KeyConditionExpression="record_type = :record_type AND #status = :status",
                ExpressionAttributeNames={"#status": "status"},
                ExpressionAttributeValues={
                    ":record_type": {"S": RECORD_TYPE_CHAT},
                    ":status": {"S": status.value},
                },
                Limit=limit,
            )
            
            items = response.get("Items", [])
            return [ChatRecord.from_dynamodb_item(item) for item in items]
            
        except ClientError as e:
            raise DynamoDBError(f"Error querying by status: {e}")
    
    def get_failed_for_retry(self, limit: int = 50) -> List[ChatRecord]:
        """Get failed records that can be retried."""
        failed_records = self.get_by_status(ChatStatus.FAILED, limit)
        return [r for r in failed_records if r.can_retry]
    
    def get_processing_stats(self) -> dict:
        """Get statistics about chat processing."""
        try:
            stats = {
                "TOTAL": 0,
                "PENDING": 0,
                "PROCESSING": 0,
                "COMPLETED": 0,
                "FAILED": 0,
                "PERMANENTLY_FAILED": 0,
            }
            
            for status in ChatStatus:
                records = self.get_by_status(status, limit=1000)
                # Filter out pipeline metadata record
                count = len([r for r in records if r.chat_id != CHAT_PIPELINE_METADATA_ID])
                stats[status.value] = count
                stats["TOTAL"] += count
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Error getting stats: {e}")
            return {"error": str(e)}
    
    def print_stats(self):
        """Print processing statistics."""
        stats = self.get_processing_stats()
        
        print("\n📊 Chat Processing Statistics:")
        print(f"   Total chats tracked: {stats.get('TOTAL', 0)}")
        print(f"   ✅ Completed:        {stats.get('COMPLETED', 0)}")
        print(f"   🔄 Processing:       {stats.get('PROCESSING', 0)}")
        print(f"   ⏳ Pending:          {stats.get('PENDING', 0)}")
        print(f"   ❌ Failed:           {stats.get('FAILED', 0)}")
        print(f"   🚫 Permanently Failed: {stats.get('PERMANENTLY_FAILED', 0)}")
    
    # -------------------------------------------------------------------------
    # PIPELINE METADATA OPERATIONS (for incremental sync)
    # -------------------------------------------------------------------------
    
    def get_pipeline_metadata(self) -> Optional[dict]:
        """
        Get pipeline metadata for incremental runs.
        
        The pipeline metadata is stored as a special record in the shared table
        with record_id = CHAT_PIPELINE_METADATA_ID and record_type = "CHAT_METADATA".
        
        Returns:
            Dictionary with metadata or None if first run
        """
        try:
            response = self._client.get_item(
                TableName=self.table_name,
                Key={"record_id": {"S": CHAT_PIPELINE_METADATA_ID}},
            )
            
            item = response.get("Item")
            if item:
                return {
                    "last_successful_run": item.get("last_successful_run", {}).get("S"),
                    "last_run_status": item.get("last_run_status", {}).get("S"),
                    "total_processed": int(item.get("total_processed", {}).get("N", "0")),
                    "total_failed": int(item.get("total_failed", {}).get("N", "0")),
                    "updated_at": item.get("updated_at", {}).get("S"),
                }
            return None
            
        except ClientError as e:
            self.logger.warning(f"Error getting pipeline metadata: {e}")
            return None
    
    def update_pipeline_metadata(
        self,
        last_successful_run: datetime = None,
        last_run_status: str = "SUCCESS",
        processed_count: int = 0,
        failed_count: int = 0,
    ):
        """
        Update pipeline metadata after a run.
        
        Args:
            last_successful_run: Timestamp of last successful run
            last_run_status: Status of last run (SUCCESS, PARTIAL, FAILED)
            processed_count: Number of chats processed in this run
            failed_count: Number of chats that failed in this run
        """
        now = self._now_iso()
        
        existing = self.get_pipeline_metadata()
        total_processed = (existing.get("total_processed", 0) if existing else 0) + processed_count
        total_failed = (existing.get("total_failed", 0) if existing else 0) + failed_count
        
        item = {
            "record_id": {"S": CHAT_PIPELINE_METADATA_ID},
            "record_type": {"S": "CHAT_METADATA"},  # Distinguish from other record types
            "meeting_id": {"S": "METADATA"},
            "join_url": {"S": "N/A"},
            "meeting_subject": {"S": "Chat Pipeline Metadata - Do Not Delete"},
            "status": {"S": "METADATA"},
            "message_count": {"N": "0"},
            "retry_count": {"N": "0"},
            "max_retries": {"N": "0"},
            "updated_at": {"S": now},
            "last_run_status": {"S": last_run_status},
            "total_processed": {"N": str(total_processed)},
            "total_failed": {"N": str(total_failed)},
        }
        
        if last_successful_run:
            item["last_successful_run"] = {"S": last_successful_run.isoformat()}
        elif existing and existing.get("last_successful_run"):
            item["last_successful_run"] = {"S": existing["last_successful_run"]}
        
        try:
            self._client.put_item(TableName=self.table_name, Item=item)
            self.logger.debug("Updated pipeline metadata")
        except ClientError as e:
            self.logger.warning(f"Error updating pipeline metadata: {e}")
    
    def get_last_successful_run(self) -> Optional[datetime]:
        """
        Get the timestamp of the last successful pipeline run.
        
        Returns:
            datetime or None if no previous run
        """
        metadata = self.get_pipeline_metadata()
        if metadata and metadata.get("last_successful_run"):
            try:
                return datetime.fromisoformat(metadata["last_successful_run"])
            except ValueError:
                return None
        return None
    
    def is_first_run(self) -> bool:
        """Check if this is the first pipeline run."""
        return self.get_last_successful_run() is None
    
    def print_pipeline_metadata(self):
        """Print pipeline metadata."""
        metadata = self.get_pipeline_metadata()
        
        print("\n🔄 Chat Pipeline Run History:")
        if metadata:
            print(f"   Last successful run: {metadata.get('last_successful_run', 'N/A')}")
            print(f"   Last run status:     {metadata.get('last_run_status', 'N/A')}")
            print(f"   Total processed:     {metadata.get('total_processed', 0)}")
            print(f"   Total failed:        {metadata.get('total_failed', 0)}")
        else:
            print("   No previous runs (first run)")
    
    # -------------------------------------------------------------------------
    # CLEANUP OPERATIONS
    # -------------------------------------------------------------------------
    
    def delete_all_records(self, confirm: bool = False) -> int:
        """
        Delete all CHAT records from the table (preserves transcript records).
        
        Args:
            confirm: Must be True to actually delete
            
        Returns:
            Number of records deleted
        """
        if not confirm:
            raise DynamoDBError("Must pass confirm=True to delete all records")
        
        self.logger.warning("Deleting all chat tracking records...")
        
        deleted = 0
        try:
            # Scan for CHAT and CHAT_METADATA records only
            scan_response = self._client.scan(
                TableName=self.table_name,
                FilterExpression="record_type IN (:chat, :chat_metadata)",
                ExpressionAttributeValues={
                    ":chat": {"S": RECORD_TYPE_CHAT},
                    ":chat_metadata": {"S": "CHAT_METADATA"},
                },
                ProjectionExpression="record_id",
            )
            
            for item in scan_response.get("Items", []):
                record_id = item["record_id"]["S"]
                self._client.delete_item(
                    TableName=self.table_name,
                    Key={"record_id": {"S": record_id}},
                )
                deleted += 1
            
            self.logger.info(f"Deleted {deleted} chat records")
            return deleted
            
        except ClientError as e:
            raise DynamoDBError(f"Error deleting records: {e}")


# =============================================================================
# MODULE-LEVEL CONVENIENCE
# =============================================================================

def create_chat_tracker(config: Config = None) -> ChatDynamoDBTracker:
    """Create a ChatDynamoDBTracker instance."""
    if config is None:
        config = Config()
    return ChatDynamoDBTracker(config)


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    from config import Config, ConfigurationError
    
    try:
        config = Config()
        tracker = ChatDynamoDBTracker(config)
        
        print("\n" + "=" * 60)
        print("CHAT DYNAMODB TRACKER STATUS")
        print("=" * 60)
        print(f"Table Name: {tracker.table_name}")
        
        tracker.print_pipeline_metadata()
        tracker.print_stats()
        
        print("\n✅ Chat DynamoDB Tracker test completed!")
        
    except ConfigurationError as e:
        print(f"\n❌ Configuration Error: {e}")
    except DynamoDBError as e:
        print(f"\n❌ DynamoDB Error: {e}")
