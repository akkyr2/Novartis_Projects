"""
S3 Storage module for the Transcript Pipeline.

Handles:
- Converting VTT transcript content to DOCX format
- Uploading transcripts to S3 with proper naming and folder structure
- Managing transcript files in S3

Path format: s3://{bucket}/{prefix}/{year}/{month}/{sanitized_subject}_{transcript_id}.docx

Usage:
    from s3_storage import S3Storage
    from config import Config
    
    config = Config()
    storage = S3Storage(config)
    
    # Upload transcript
    s3_path = storage.upload_transcript(
        transcript_content=vtt_content,
        transcript_id="abc123",
        meeting_subject="Team Standup",
        meeting_date="2024-01-15T10:00:00"
    )
"""

import io
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Tuple

import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

from transcript_pipeline.config import Config, S3StorageError


# =============================================================================
# VTT PARSER
# =============================================================================

@dataclass
class VTTEntry:
    """Represents a single VTT transcript entry."""
    
    timestamp: str
    speaker: str
    text: str
    
    @property
    def formatted_speaker(self) -> str:
        """Get formatted speaker name."""
        return self.speaker.strip() if self.speaker else "Unknown Speaker"


class VTTParser:
    """
    Parser for WebVTT (VTT) transcript format.
    
    Parses VTT content from Microsoft Teams transcripts which has format:
    
    WEBVTT
    
    00:00:00.000 --> 00:00:05.000
    <v Speaker Name>The transcript text here.</v>
    
    00:00:05.000 --> 00:00:10.000
    <v Another Speaker>More text.</v>
    """
    
    # Regex patterns
    TIMESTAMP_PATTERN = re.compile(
        r"(\d{2}:\d{2}:\d{2}[.,]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[.,]\d{3})"
    )
    SPEAKER_PATTERN = re.compile(r"<v\s+([^>]+)>(.+?)</v>", re.DOTALL)
    
    @classmethod
    def parse(cls, vtt_content: str) -> list[VTTEntry]:
        """
        Parse VTT content into structured entries.
        
        Args:
            vtt_content: Raw VTT transcript content
            
        Returns:
            List of VTTEntry objects
        """
        entries = []
        current_timestamp = ""
        
        lines = vtt_content.strip().split("\n")
        i = 0
        
        while i < len(lines):
            line = lines[i].strip()
            
            # Skip WEBVTT header and empty lines
            if not line or line == "WEBVTT" or line.startswith("NOTE"):
                i += 1
                continue
            
            # Check for timestamp line
            timestamp_match = cls.TIMESTAMP_PATTERN.match(line)
            if timestamp_match:
                current_timestamp = timestamp_match.group(1)
                i += 1
                continue
            
            # Check for speaker and text
            speaker_match = cls.SPEAKER_PATTERN.search(line)
            if speaker_match:
                speaker = speaker_match.group(1)
                text = speaker_match.group(2).strip()
                
                entries.append(VTTEntry(
                    timestamp=current_timestamp,
                    speaker=speaker,
                    text=text,
                ))
            elif line and current_timestamp:
                # Line without speaker tag - use previous speaker or Unknown
                text = re.sub(r"<[^>]+>", "", line).strip()
                if text:
                    entries.append(VTTEntry(
                        timestamp=current_timestamp,
                        speaker="Unknown",
                        text=text,
                    ))
            
            i += 1
        
        return entries
    
    @classmethod
    def to_plain_text(cls, vtt_content: str) -> str:
        """
        Convert VTT content to plain text format.
        
        Args:
            vtt_content: Raw VTT content
            
        Returns:
            Plain text transcript
        """
        entries = cls.parse(vtt_content)
        
        lines = []
        current_speaker = None
        
        for entry in entries:
            if entry.speaker != current_speaker:
                current_speaker = entry.speaker
                lines.append(f"\n[{entry.timestamp}] {entry.formatted_speaker}:")
            
            lines.append(f"  {entry.text}")
        
        return "\n".join(lines).strip()


# =============================================================================
# DOCX CONVERTER
# =============================================================================

class DocxConverter:
    """
    Converts VTT transcript content to DOCX format.
    
    Creates a professionally formatted document with:
    - Title and metadata
    - Timestamp and speaker formatting
    - Clean readable layout
    """
    
    @classmethod
    def convert(
        cls,
        vtt_content: str,
        meeting_subject: str,
        meeting_date: Optional[str] = None,
        meeting_id: Optional[str] = None,
        transcript_id: Optional[str] = None,
    ) -> bytes:
        """
        Convert VTT content to DOCX bytes.
        
        Args:
            vtt_content: Raw VTT transcript content
            meeting_subject: Meeting subject/title
            meeting_date: Meeting date (ISO format)
            meeting_id: Online meeting ID
            transcript_id: Transcript ID
            
        Returns:
            DOCX file content as bytes
        """
        # Parse VTT content
        entries = VTTParser.parse(vtt_content)
        
        # Create document
        doc = Document()
        
        # Set document properties
        doc.core_properties.title = meeting_subject
        doc.core_properties.subject = "Teams Meeting Transcript"
        
        # Add title
        title = doc.add_heading(meeting_subject, level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add metadata section
        doc.add_paragraph()  # Spacer
        
        metadata = doc.add_paragraph()
        metadata.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        if meeting_date:
            formatted_date = cls._format_date(meeting_date)
            run = metadata.add_run(f"📅 Date: {formatted_date}")
            run.font.size = Pt(11)
            run.font.italic = True
        
        # Add separator
        doc.add_paragraph("─" * 60)
        doc.add_paragraph()  # Spacer
        
        # Add transcript content
        if not entries:
            doc.add_paragraph("No transcript content available.")
        else:
            current_speaker = None
            
            for entry in entries:
                # Add speaker header when speaker changes
                if entry.speaker != current_speaker:
                    current_speaker = entry.speaker
                    
                    # Add spacing before new speaker
                    if len(doc.paragraphs) > 5:  # Not first entry
                        doc.add_paragraph()
                    
                    # Speaker paragraph
                    speaker_para = doc.add_paragraph()
                    
                    # Timestamp
                    time_run = speaker_para.add_run(f"[{entry.timestamp}] ")
                    time_run.font.size = Pt(9)
                    time_run.font.color.rgb = None  # Use default gray
                    time_run.font.italic = True
                    
                    # Speaker name
                    speaker_run = speaker_para.add_run(entry.formatted_speaker)
                    speaker_run.font.size = Pt(11)
                    speaker_run.font.bold = True
                
                # Add text content
                text_para = doc.add_paragraph()
                text_para.paragraph_format.left_indent = Inches(0.25)
                text_run = text_para.add_run(entry.text)
                text_run.font.size = Pt(11)
        
        # Add footer with metadata
        doc.add_paragraph()  # Spacer
        doc.add_paragraph("─" * 60)
        
        footer = doc.add_paragraph()
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_text = "Generated by Transcript Pipeline"
        if transcript_id:
            footer_text += f" | Transcript ID: {transcript_id[:20]}..."
        footer_run = footer.add_run(footer_text)
        footer_run.font.size = Pt(8)
        footer_run.font.italic = True
        
        # Save to bytes
        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        
        return buffer.getvalue()
    
    @staticmethod
    def _format_date(date_string: str) -> str:
        """Format ISO date string to readable format."""
        try:
            if "T" in date_string:
                dt = datetime.fromisoformat(date_string.replace("Z", "+00:00"))
            else:
                dt = datetime.fromisoformat(date_string)
            return dt.strftime("%B %d, %Y at %I:%M %p")
        except (ValueError, TypeError):
            return date_string


# =============================================================================
# S3 STORAGE CLASS
# =============================================================================

class S3Storage:
    """
    S3 Storage for transcript files.
    
    Handles uploading transcript DOCX files to S3 with proper
    naming conventions and folder structure.
    """
    
    def __init__(self, config: Config):
        """
        Initialize S3 Storage.
        
        Args:
            config: Configuration instance
            
        Raises:
            S3StorageError: If connection fails
        """
        self.config = config
        self.logger = config.logger
        self.bucket_name = config.s3_bucket_name
        
        # Use "transcripts" subfolder under the configured prefix
        base_prefix = config.s3_prefix.rstrip("/")
        self.prefix = f"{base_prefix}/transcripts/"
        
        try:
            self._client = boto3.client("s3", region_name=config.aws_region)
            self.logger.debug(f"Connected to S3 in region {config.aws_region}")
            
        except NoCredentialsError:
            raise S3StorageError(
                "No AWS credentials found. "
                "Ensure AWS credentials are configured (environment, ~/.aws/credentials, or IAM role)"
            )
        except Exception as e:
            raise S3StorageError(f"Failed to connect to S3: {e}")
    
    # -------------------------------------------------------------------------
    # FILE NAMING
    # -------------------------------------------------------------------------
    
    @staticmethod
    def sanitize_filename(text: str, max_length: int = 20) -> str:
        """
        Sanitize text for use in filename.
        
        Args:
            text: Text to sanitize
            max_length: Maximum length for the sanitized text (default 20 for short names)
            
        Returns:
            Sanitized filename-safe string
        """
        # Remove or replace invalid characters
        sanitized = re.sub(r'[<>:"/\\|?*]', '', text)
        # Replace spaces and special chars with underscores
        sanitized = re.sub(r'[\s\-]+', '_', sanitized)
        # Remove multiple underscores
        sanitized = re.sub(r'_+', '_', sanitized)
        # Strip leading/trailing underscores
        sanitized = sanitized.strip('_')
        # Limit length
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length].rstrip('_')
        # Default if empty
        if not sanitized:
            sanitized = "transcript"
        
        return sanitized
    
    @staticmethod
    def sanitize_for_s3_metadata(text: str, max_length: int = 100) -> str:
        """
        Sanitize text for use in S3 metadata (ASCII only).
        
        S3 metadata can only contain ASCII characters. This method:
        1. Normalizes Unicode characters to their closest ASCII equivalents
        2. Removes any remaining non-ASCII characters
        3. Truncates to max length
        
        Args:
            text: Text to sanitize
            max_length: Maximum length for the sanitized text
            
        Returns:
            ASCII-safe string for S3 metadata
        """
        import unicodedata
        
        if not text:
            return ""
        
        # Normalize Unicode to decomposed form (separates base chars from accents)
        # Then encode to ASCII, ignoring non-ASCII characters
        normalized = unicodedata.normalize('NFKD', text)
        
        # Replace common Unicode characters with ASCII equivalents
        replacements = {
            '\u2018': "'",   # Left single quote
            '\u2019': "'",   # Right single quote
            '\u201c': '"',   # Left double quote
            '\u201d': '"',   # Right double quote
            '\u2013': '-',   # En dash
            '\u2014': '-',   # Em dash
            '\u2026': '...', # Ellipsis
            '\uff06': '&',   # Fullwidth ampersand
            '\ufe60': '&',   # Small ampersand
            '\u0026': '&',   # Regular ampersand (should be fine, but just in case)
        }
        
        for unicode_char, ascii_char in replacements.items():
            normalized = normalized.replace(unicode_char, ascii_char)
        
        # Encode to ASCII, replacing unknown chars with '?', then decode back
        ascii_text = normalized.encode('ascii', 'replace').decode('ascii')
        
        # Replace '?' with empty string for cleaner output
        ascii_text = ascii_text.replace('?', '')
        
        # Remove multiple spaces
        ascii_text = re.sub(r'\s+', ' ', ascii_text).strip()
        
        # Truncate to max length
        if len(ascii_text) > max_length:
            ascii_text = ascii_text[:max_length]
        
        return ascii_text
    
    def generate_s3_key(
        self,
        transcript_id: str,
        meeting_subject: str,
        meeting_date: Optional[str] = None,
    ) -> str:
        """
        Generate S3 key (path) for transcript file.
        
        Format: {prefix}{year}/{month}/{short_subject}_{transcript_id_24chars}.docx
        
        Uses 24 characters of transcript ID for uniqueness (full IDs are ~40+ chars).
        Subject is shortened to 20 chars to keep filenames reasonable.
        
        Args:
            transcript_id: Transcript ID (full ID from Graph API)
            meeting_subject: Meeting subject
            meeting_date: Meeting date (ISO format) - used for folder structure
            
        Returns:
            S3 key string
        """
        # Parse date for folder structure
        if meeting_date:
            try:
                if "T" in meeting_date:
                    dt = datetime.fromisoformat(meeting_date.replace("Z", "+00:00"))
                else:
                    dt = datetime.fromisoformat(meeting_date)
                year = dt.strftime("%Y")
                month = dt.strftime("%m")
            except (ValueError, TypeError):
                year = datetime.now().strftime("%Y")
                month = datetime.now().strftime("%m")
        else:
            year = datetime.now().strftime("%Y")
            month = datetime.now().strftime("%m")
        
        # Sanitize subject for filename (short - 20 chars max)
        safe_subject = self.sanitize_filename(meeting_subject)
        
        # Use LAST 20 chars of transcript ID for uniqueness
        # The first ~14 chars are often shared (meeting-level ID)
        # The unique part is at the end of the transcript ID
        short_id = transcript_id[-20:] if transcript_id and len(transcript_id) >= 20 else transcript_id or "unknown"
        
        # Build key: Agentic_Colleague_B6lATZRTE5Om1lZXabcd.docx
        key = f"{self.prefix}{year}/{month}/{safe_subject}_{short_id}.docx"
        
        return key
    
    # -------------------------------------------------------------------------
    # UPLOAD OPERATIONS
    # -------------------------------------------------------------------------
    
    def upload_transcript(
        self,
        transcript_content: str,
        transcript_id: str,
        meeting_subject: str,
        meeting_date: Optional[str] = None,
        meeting_id: Optional[str] = None,
    ) -> str:
        """
        Upload transcript to S3 as DOCX file.
        
        Converts VTT content to DOCX format and uploads to S3.
        
        Args:
            transcript_content: VTT transcript content
            transcript_id: Transcript ID
            meeting_subject: Meeting subject
            meeting_date: Meeting date (ISO format)
            meeting_id: Online meeting ID
            
        Returns:
            S3 URI of uploaded file (s3://bucket/key)
            
        Raises:
            S3StorageError: If upload fails
        """
        self.logger.info(f"Uploading transcript for: {meeting_subject[:50]}...")
        
        # Convert to DOCX
        try:
            docx_bytes = DocxConverter.convert(
                vtt_content=transcript_content,
                meeting_subject=meeting_subject,
                meeting_date=meeting_date,
                meeting_id=meeting_id,
                transcript_id=transcript_id,
            )
        except Exception as e:
            raise S3StorageError(f"Failed to convert transcript to DOCX: {e}")
        
        # Generate S3 key
        s3_key = self.generate_s3_key(
            transcript_id=transcript_id,
            meeting_subject=meeting_subject,
            meeting_date=meeting_date,
        )
        
        # Upload to S3
        try:
            self._client.put_object(
                Bucket=self.bucket_name,
                Key=s3_key,
                Body=docx_bytes,
                ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                Metadata={
                    "transcript_id": self.sanitize_for_s3_metadata(transcript_id, 100),
                    "meeting_subject": self.sanitize_for_s3_metadata(meeting_subject, 100),
                    "meeting_id": self.sanitize_for_s3_metadata(meeting_id or "", 100),
                },
            )
            
            s3_uri = f"s3://{self.bucket_name}/{s3_key}"
            self.logger.info(f"  📤 Uploaded: {s3_uri}")
            
            return s3_uri
            
        except ClientError as e:
            raise S3StorageError(f"Failed to upload to S3: {e}")
    
    def upload_raw_content(
        self,
        content: str,
        s3_key: str,
        content_type: str = "text/plain",
    ) -> str:
        """
        Upload raw content to S3.
        
        Args:
            content: Content to upload
            s3_key: S3 key (path)
            content_type: Content type header
            
        Returns:
            S3 URI of uploaded file
        """
        try:
            self._client.put_object(
                Bucket=self.bucket_name,
                Key=s3_key,
                Body=content.encode("utf-8"),
                ContentType=content_type,
            )
            
            return f"s3://{self.bucket_name}/{s3_key}"
            
        except ClientError as e:
            raise S3StorageError(f"Failed to upload to S3: {e}")
    
    # -------------------------------------------------------------------------
    # UTILITY METHODS
    # -------------------------------------------------------------------------
    
    def file_exists(self, s3_key: str) -> bool:
        """
        Check if a file exists in S3.
        
        Args:
            s3_key: S3 key to check
            
        Returns:
            True if file exists
        """
        try:
            self._client.head_object(Bucket=self.bucket_name, Key=s3_key)
            return True
        except ClientError:
            return False
    
    def list_files(self, prefix: str = None, max_keys: int = 100) -> list[dict]:
        """
        List files in S3 with given prefix.
        
        Args:
            prefix: S3 prefix to filter by (default: configured prefix)
            max_keys: Maximum number of files to return
            
        Returns:
            List of file info dictionaries
        """
        prefix = prefix or self.prefix
        
        try:
            response = self._client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix=prefix,
                MaxKeys=max_keys,
            )
            
            files = []
            for obj in response.get("Contents", []):
                files.append({
                    "key": obj["Key"],
                    "size": obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                    "filename": obj["Key"].split("/")[-1],
                })
            
            return files
            
        except ClientError as e:
            self.logger.error(f"Error listing files: {e}")
            return []
    
    def get_storage_stats(self) -> dict:
        """
        Get storage statistics for transcripts.
        
        Returns:
            Dictionary with file count and total size
        """
        files = self.list_files(max_keys=1000)
        
        total_size = sum(f["size"] for f in files)
        docx_files = [f for f in files if f["key"].endswith(".docx")]
        
        return {
            "total_files": len(files),
            "docx_files": len(docx_files),
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
        }


# =============================================================================
# MODULE-LEVEL CONVENIENCE
# =============================================================================

def create_storage(config: Config = None) -> S3Storage:
    """
    Create an S3Storage instance.
    
    Args:
        config: Optional Config instance (creates new one if not provided)
        
    Returns:
        S3Storage instance
    """
    if config is None:
        config = Config()
    return S3Storage(config)


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    from config import Config, ConfigurationError
    
    try:
        config = Config()
        
        print("\n" + "=" * 60)
        print("TESTING S3 STORAGE")
        print("=" * 60)
        
        storage = S3Storage(config)
        
        # Test VTT parsing
        sample_vtt = """WEBVTT

00:00:00.000 --> 00:00:05.000
<v John Smith>Hello everyone, welcome to the meeting.</v>

00:00:05.000 --> 00:00:10.000
<v Jane Doe>Thanks John, let's get started.</v>

00:00:10.000 --> 00:00:15.000
<v John Smith>First item on the agenda is the project update.</v>
"""
        
        entries = VTTParser.parse(sample_vtt)
        print(f"\nParsed {len(entries)} VTT entries:")
        for entry in entries:
            print(f"  [{entry.timestamp}] {entry.speaker}: {entry.text[:30]}...")
        
        # Test key generation
        test_key = storage.generate_s3_key(
            transcript_id="ABC123DEF456",
            meeting_subject="Weekly Team Standup - Q1 Planning",
            meeting_date="2024-01-15T10:00:00",
        )
        print(f"\nGenerated S3 key: {test_key}")
        
        # Get storage stats
        stats = storage.get_storage_stats()
        print(f"\nStorage stats:")
        print(f"  Total files: {stats['total_files']}")
        print(f"  DOCX files: {stats['docx_files']}")
        print(f"  Total size: {stats['total_size_mb']} MB")
        
        print("\n✅ S3 Storage test completed!")
        
    except ConfigurationError as e:
        print(f"\n❌ Configuration Error: {e}")
    except S3StorageError as e:
        print(f"\n❌ S3 Storage Error: {e}")
