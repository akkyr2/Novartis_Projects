"""
Microsoft Graph API Client for Meeting Chat extraction.

Handles fetching chat messages from Teams meetings via Microsoft Graph API.

The flow to get meeting chat messages:
1. Get the online meeting using JoinWebUrl filter
2. Extract the chatInfo.threadId from the meeting
3. Fetch chat messages from /users/{userId}/chats/{chatId}/messages

Usage:
    from chat_client import ChatClient
    from config import Config
    
    config = Config()
    client = ChatClient(config)
    
    # Get all meetings with chat messages
    meetings = client.get_meetings_with_chats()
    
    # Get chat messages for a specific meeting
    messages = client.get_chat_messages(chat_id)
"""

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from urllib.parse import unquote

import msal
import requests

from transcript_pipeline.config import Config, GraphAPIError


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def extract_chat_thread_id_from_join_url(join_url: str) -> Optional[str]:
    """
    Extract the chat thread ID from a Teams meeting join URL.
    The thread ID is in the format: 19:meeting_XXXXX@thread.v2
    
    This is the same approach used in the working notebook.
    
    Args:
        join_url: Teams meeting join URL
    
    Returns:
        Chat thread ID or None if not found
    """
    if not join_url:
        return None
    
    # Decode URL encoding
    decoded_url = unquote(join_url)
    
    # Pattern to match the meeting thread ID
    # Format: 19:meeting_XXXXX@thread.v2
    pattern = r'(19:meeting_[a-zA-Z0-9_-]+@thread\.v2)'
    match = re.search(pattern, decoded_url)
    
    if match:
        return match.group(1)
    
    return None


# =============================================================================
# DATA CLASSES FOR TYPE SAFETY
# =============================================================================

@dataclass
class ChatMessage:
    """Represents a single chat message from a meeting."""
    
    message_id: str
    chat_id: str
    sender_name: str
    sender_email: Optional[str]
    content: str
    content_type: str  # 'text' or 'html'
    created_datetime: str
    message_type: str  # 'message', 'systemEventMessage', etc.
    importance: str
    
    @classmethod
    def from_api_response(cls, data: dict, chat_id: str) -> "ChatMessage":
        """Create ChatMessage from Graph API response."""
        sender = data.get("from", {})
        user = sender.get("user", {}) if sender else {}
        
        # Extract content based on body type
        body = data.get("body", {})
        content = body.get("content", "")
        content_type = body.get("contentType", "text")
        
        return cls(
            message_id=data.get("id", ""),
            chat_id=chat_id,
            sender_name=user.get("displayName", "Unknown"),
            sender_email=user.get("email") or user.get("userPrincipalName"),
            content=content,
            content_type=content_type.lower(),
            created_datetime=data.get("createdDateTime", ""),
            message_type=data.get("messageType", "message"),
            importance=data.get("importance", "normal"),
        )
    
    @property
    def is_user_message(self) -> bool:
        """
        Check if this is a regular user message (not system).
        
        Matching the notebook approach: only keep messageType == 'message'
        """
        # Only 'message' type is a real user message (matching notebook filter)
        # Exclude: systemEventMessage, unknownFutureValue, chatMessageHostedContent, etc.
        if self.message_type != "message":
            return False
        
        # Must have some content (HTML or plain text)
        # Note: content might be HTML like <p>Hello</p>
        if not self.content or not self.content.strip():
            return False
        
        # Filter out empty HTML (like <p></p> or <div></div>)
        clean_content = re.sub(r'<[^>]+>', '', self.content).strip()
        return len(clean_content) > 0


@dataclass
class MeetingChatInfo:
    """Represents meeting information with associated chat."""
    
    meeting_id: str
    chat_id: str  # The threadId from chatInfo
    subject: str
    join_url: str
    start_datetime: Optional[str] = None
    end_datetime: Optional[str] = None
    organizer_id: Optional[str] = None
    organizer_name: Optional[str] = None
    event_id: Optional[str] = None
    messages: List[ChatMessage] = field(default_factory=list)
    total_message_count: int = 0
    
    @classmethod
    def from_calendar_event(cls, event: dict) -> Optional["MeetingChatInfo"]:
        """Create MeetingChatInfo from a calendar event."""
        online_meeting = event.get("onlineMeeting", {})
        join_url = online_meeting.get("joinUrl") if online_meeting else None
        
        if not join_url:
            return None
        
        # Extract chat thread ID directly from join URL (as in working notebook)
        chat_id = extract_chat_thread_id_from_join_url(join_url)
        
        organizer = event.get("organizer", {}).get("emailAddress", {})
        
        return cls(
            meeting_id=event.get("id", ""),  # Use event ID as meeting ID
            chat_id=chat_id or "",  # Extract from URL directly
            subject=event.get("subject", "Untitled Meeting"),
            join_url=join_url,
            start_datetime=event.get("start", {}).get("dateTime"),
            end_datetime=event.get("end", {}).get("dateTime"),
            organizer_id=organizer.get("address"),
            organizer_name=organizer.get("name"),
            event_id=event.get("id"),
        )


# =============================================================================
# CHAT CLIENT CLASS
# =============================================================================

class ChatClient:
    """
    Microsoft Graph API Client for Meeting Chat.
    
    Handles authentication and provides methods to interact with
    Microsoft Graph API for fetching meeting chat messages.
    """
    
    def __init__(self, config: Config):
        """
        Initialize the Chat Client.
        
        Args:
            config: Configuration instance with Azure AD credentials
            
        Raises:
            GraphAPIError: If authentication fails
        """
        self.config = config
        self.logger = config.logger
        self._access_token: Optional[str] = None
        self._token_expires: Optional[datetime] = None
        
        # Authenticate on initialization
        self._authenticate()
    
    # -------------------------------------------------------------------------
    # AUTHENTICATION
    # -------------------------------------------------------------------------
    
    def _get_certificate_content(self) -> str:
        """Get certificate content either from config or file."""
        if self.config.azure_cert_content:
            self.logger.debug("Using certificate content from Secrets Manager")
            return self.config.azure_cert_content.strip()
        
        if self.config.azure_cert_path:
            try:
                self.logger.debug(f"Loading certificate from file: {self.config.azure_cert_path}")
                with open(self.config.azure_cert_path, "r") as f:
                    return f.read().strip()
            except Exception as e:
                raise GraphAPIError(f"Failed to load certificate file: {e}")
        
        raise GraphAPIError(
            "No certificate available. Set AZURE_CERT_CONTENT in Secrets Manager "
            "or AZURE_CERT_PATH to a valid certificate file."
        )
    
    def _authenticate(self):
        """Authenticate with Azure AD using certificate-based credentials."""
        self.logger.info("Authenticating Chat Client with Microsoft Graph API...")
        
        try:
            private_key = self._get_certificate_content()
            
            # Validate certificate format
            pem_header_marker = "-" * 5 + "BEGIN"
            if not private_key.startswith(pem_header_marker):
                raise GraphAPIError(
                    "Invalid certificate format. Expected PEM format."
                )
            
            authority_url = f"https://login.microsoftonline.com/{self.config.azure_tenant_id}"
            scopes = ["https://graph.microsoft.com/.default"]
            
            client_credential = {
                "private_key": private_key,
                "thumbprint": self.config.azure_cert_thumbprint,
            }
            
            app = msal.ConfidentialClientApplication(
                client_id=self.config.azure_client_id,
                authority=authority_url,
                client_credential=client_credential,
            )
            
            token_response = app.acquire_token_for_client(scopes=scopes)
            
            if "access_token" in token_response:
                self._access_token = token_response["access_token"]
                self.logger.info("✅ Chat Client authenticated with Graph API")
            else:
                error = token_response.get("error", "Unknown error")
                error_desc = token_response.get("error_description", "No description")
                raise GraphAPIError(f"Authentication failed: {error} - {error_desc}")
                
        except GraphAPIError:
            raise
        except Exception as e:
            raise GraphAPIError(f"Authentication error: {e}")
    
    def _get_headers(self, accept: str = "application/json") -> dict:
        """Get HTTP headers for API requests."""
        return {
            "Authorization": f"Bearer {self._access_token}",
            "Content-Type": "application/json",
            "Accept": accept,
        }
    
    def _make_request(
        self, 
        method: str, 
        url: str, 
        params: dict = None, 
        accept: str = "application/json"
    ) -> requests.Response:
        """Make an HTTP request to the Graph API."""
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._get_headers(accept),
                params=params,
                timeout=30,
            )
            self.logger.debug(f"{method} {url} -> {response.status_code}")
            return response
        except requests.exceptions.RequestException as e:
            raise GraphAPIError(f"Request failed: {e}")
    
    # -------------------------------------------------------------------------
    # CALENDAR OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_calendar_view(
        self,
        start_datetime: datetime,
        end_datetime: datetime = None,
        limit: int = None,
    ) -> List[dict]:
        """
        Get calendar events within a specific date range using calendarView endpoint.
        
        Args:
            start_datetime: Start of the date range (inclusive)
            end_datetime: End of the date range (inclusive, default: now)
            limit: Maximum number of events to fetch (default from config)
            
        Returns:
            List of calendar event dictionaries within the date range
        """
        limit = limit or self.config.meetings_fetch_limit
        
        if start_datetime.tzinfo is None:
            start_datetime = start_datetime.replace(tzinfo=timezone.utc)
        
        if end_datetime is None:
            end_datetime = datetime.now(timezone.utc)
        elif end_datetime.tzinfo is None:
            end_datetime = end_datetime.replace(tzinfo=timezone.utc)
        
        start_str = start_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
        end_str = end_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
        
        url = f"{self.config.graph_base_url}/users/{self.config.graph_user_id}/calendarView"
        params = {
            "startDateTime": start_str,
            "endDateTime": end_str,
            "$select": "id,subject,start,end,isOnlineMeeting,onlineMeeting,onlineMeetingProvider,organizer",
            "$top": limit,
            "$orderby": "start/dateTime desc",
        }
        
        self.logger.info(
            f"Fetching calendar events from {start_str} to {end_str} (limit: {limit})..."
        )
        
        response = self._make_request("GET", url, params)
        
        if response.status_code != 200:
            raise GraphAPIError(
                f"Failed to fetch calendar view: {response.status_code} - {response.text}"
            )
        
        events = response.json().get("value", [])
        self.logger.info(f"Found {len(events)} calendar events in date range")
        
        return events
    
    def get_online_meetings_in_range(
        self,
        start_datetime: datetime,
        end_datetime: datetime = None,
        limit: int = None,
    ) -> List[MeetingChatInfo]:
        """
        Get online meetings (Teams meetings) within a specific date range.
        
        Args:
            start_datetime: Start of the date range
            end_datetime: End of the date range (default: now)
            limit: Maximum number of events to fetch
            
        Returns:
            List of MeetingChatInfo objects for online meetings in the range
        """
        events = self.get_calendar_view(start_datetime, end_datetime, limit)
        
        online_meetings = []
        for event in events:
            if event.get("isOnlineMeeting", False):
                meeting = MeetingChatInfo.from_calendar_event(event)
                if meeting:
                    online_meetings.append(meeting)
        
        self.logger.info(
            f"Found {len(online_meetings)} online meetings in date range "
            f"(out of {len(events)} events)"
        )
        
        return online_meetings
    
    # -------------------------------------------------------------------------
    # MEETING & CHAT OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_meeting_by_join_url(self, join_url: str) -> Optional[dict]:
        """
        Get the full online meeting details by its join URL.
        
        Args:
            join_url: Teams meeting join URL
            
        Returns:
            Full meeting object including chatInfo, or None if not found
        """
        escaped_url = join_url.strip().replace("'", "''")
        
        url = (
            f"{self.config.graph_base_url}/users/{self.config.graph_user_id}/onlineMeetings"
            f"?$filter=JoinWebUrl eq '{escaped_url}'"
        )
        
        response = self._make_request("GET", url)
        
        if response.status_code == 404:
            self.logger.debug("Meeting not found (404) - likely deleted or expired")
            return None
        
        if response.status_code != 200:
            self.logger.debug(f"Failed to get meeting: {response.status_code}")
            return None
        
        meetings = response.json().get("value", [])
        
        if meetings:
            return meetings[0]
        
        return None
    
    def get_chat_id_from_meeting(self, join_url: str) -> Optional[str]:
        """
        Get the chat thread ID from an online meeting.
        
        Args:
            join_url: Teams meeting join URL
            
        Returns:
            Chat thread ID or None if not found
        """
        meeting = self.get_meeting_by_join_url(join_url)
        
        if not meeting:
            return None
        
        chat_info = meeting.get("chatInfo", {})
        thread_id = chat_info.get("threadId")
        
        if thread_id:
            self.logger.debug(f"Found chat thread ID: {thread_id}")
        
        return thread_id
    
    def test_chat_access(self, chat_id: str) -> dict:
        """
        Test access to a chat and return detailed error information.
        
        This is a diagnostic method to understand permission issues.
        Tests ALL endpoints and reports which ones work.
        
        Args:
            chat_id: Chat thread ID to test
            
        Returns:
            Dict with test results and error details
        """
        result = {
            "chat_id": chat_id,
            "endpoints_tested": [],
            "can_access_chat": False,
            "can_read_messages": False,
            "error_details": None,
        }
        
        # Test 1: Direct /chats endpoint (chat metadata)
        url1 = f"{self.config.graph_base_url}/chats/{chat_id}"
        response1 = self._make_request("GET", url1)
        result["endpoints_tested"].append({
            "endpoint": f"/chats/{chat_id[:30]}...",
            "purpose": "Chat metadata",
            "status": response1.status_code,
            "error": response1.text[:200] if response1.status_code != 200 else None,
        })
        
        if response1.status_code == 200:
            result["can_access_chat"] = True
            result["chat_info"] = response1.json()
        
        # Test 2: /chats/{id}/messages endpoint (THIS IS THE KEY TEST)
        url2 = f"{self.config.graph_base_url}/chats/{chat_id}/messages"
        response2 = self._make_request("GET", url2, {"$top": 1})
        result["endpoints_tested"].append({
            "endpoint": f"/chats/{chat_id[:30]}../messages",
            "purpose": "Read messages (v1.0)",
            "status": response2.status_code,
            "error": response2.text[:200] if response2.status_code != 200 else None,
        })
        
        if response2.status_code == 200:
            result["can_read_messages"] = True
            return result  # Success - no need to test more
        
        # Test 3: /users/{userId}/chats/{id}/messages endpoint
        url3 = (
            f"{self.config.graph_base_url}/users/{self.config.graph_user_id}"
            f"/chats/{chat_id}/messages"
        )
        response3 = self._make_request("GET", url3, {"$top": 1})
        result["endpoints_tested"].append({
            "endpoint": f"/users/.../chats/{chat_id[:30]}../messages",
            "purpose": "Read messages (user context)",
            "status": response3.status_code,
            "error": response3.text[:200] if response3.status_code != 200 else None,
        })
        
        if response3.status_code == 200:
            result["can_read_messages"] = True
            return result
        
        # Test 4: Beta API /chats/{id}/messages endpoint
        url4 = f"https://graph.microsoft.com/beta/chats/{chat_id}/messages"
        response4 = self._make_request("GET", url4, {"$top": 1})
        result["endpoints_tested"].append({
            "endpoint": f"BETA /chats/{chat_id[:30]}../messages",
            "purpose": "Read messages (beta)",
            "status": response4.status_code,
            "error": response4.text[:200] if response4.status_code != 200 else None,
        })
        
        if response4.status_code == 200:
            result["can_read_messages"] = True
            result["note"] = "Beta API works - consider using beta endpoint"
        else:
            result["error_details"] = (
                "❌ Cannot read chat messages. All /messages endpoints failed.\n"
                "REQUIRED PERMISSION: Chat.Read.All (Application permission)\n"
                "Go to Azure Portal → App Registrations → [Your App] → API Permissions → Add Chat.Read.All"
            )
        
        return result
    
    def get_chat_messages(
        self,
        chat_id: str,
        limit: int = 100,
        include_system_messages: bool = False,
    ) -> List[ChatMessage]:
        """
        Get messages from a chat thread.
        
        Uses the /users/{userId}/chats/{chatId}/messages endpoint as primary
        (matching the working notebook approach).
        
        Args:
            chat_id: Chat thread ID (19:meeting_xxx@thread.v2 format)
            limit: Maximum number of messages to fetch
            include_system_messages: Whether to include system event messages
            
        Returns:
            List of ChatMessage objects (sorted chronologically, oldest first)
        """
        # Use the /users/{userId}/chats endpoint as primary (matching notebook)
        # Graph API only supports descending order for chat messages
        url = (
            f"{self.config.graph_base_url}/users/{self.config.graph_user_id}"
            f"/chats/{chat_id}/messages"
        )
        params = {
            "$top": limit,
            "$orderby": "createdDateTime desc"  # API only supports desc
        }
        
        self.logger.debug(f"Fetching chat messages for chat ID: {chat_id[:50]}...")
        self.logger.debug(f"URL: {url}")
        
        response = self._make_request("GET", url, params)
        
        if response.status_code != 200:
            self.logger.warning(
                f"Primary endpoint failed: {response.status_code}"
            )
            self.logger.debug(f"Error response: {response.text[:500]}")
            
            # Try direct /chats endpoint as fallback
            alt_url = f"{self.config.graph_base_url}/chats/{chat_id}/messages"
            self.logger.debug(f"Trying fallback URL: {alt_url}")
            
            response = self._make_request("GET", alt_url, params)
            
            if response.status_code != 200:
                self.logger.warning(
                    f"Fallback endpoint also failed: {response.status_code}"
                )
                self.logger.debug(f"Error response: {response.text[:500]}")
                return []
        
        messages_data = response.json().get("value", [])
        
        # Reverse to get chronological order (oldest first) - matching notebook approach
        messages_data = list(reversed(messages_data))
        
        messages = [
            ChatMessage.from_api_response(msg, chat_id)
            for msg in messages_data
        ]
        
        # Filter out system messages if requested (matching notebook: messageType == 'message')
        if not include_system_messages:
            messages = [m for m in messages if m.is_user_message]
        
        self.logger.debug(f"Fetched {len(messages)} chat messages")
        
        return messages
    
    def get_all_chat_messages_paginated(
        self,
        chat_id: str,
        max_messages: int = 1000,
        include_system_messages: bool = False,
    ) -> List[ChatMessage]:
        """
        Get all messages from a chat thread with pagination support.
        
        Uses the /users/{userId}/chats/{chatId}/messages endpoint as primary
        (matching the working notebook approach).
        
        Args:
            chat_id: Chat thread ID (19:meeting_xxx@thread.v2 format)
            max_messages: Maximum total messages to fetch
            include_system_messages: Whether to include system event messages
            
        Returns:
            List of all ChatMessage objects (sorted chronologically, oldest first)
        """
        all_messages = []
        
        # Use user-context endpoint as primary (matching notebook)
        # Fallback to direct /chats endpoint if that fails
        endpoints_to_try = [
            f"{self.config.graph_base_url}/users/{self.config.graph_user_id}/chats/{chat_id}/messages",
            f"{self.config.graph_base_url}/chats/{chat_id}/messages",
        ]
        
        # Graph API only supports descending order for chat messages
        params = {
            "$top": min(50, max_messages),  # Graph API page size
            "$orderby": "createdDateTime desc"
        }
        
        self.logger.debug(f"Fetching paginated messages for chat: {chat_id[:50]}...")
        
        # Find a working endpoint
        next_page_url = None
        last_error = None
        endpoint_succeeded = False
        
        for endpoint in endpoints_to_try:
            response = self._make_request("GET", endpoint, params)
            
            if response.status_code == 200:
                endpoint_succeeded = True
                self.logger.debug(f"Endpoint succeeded: {endpoint[:60]}...")
                data = response.json()
                messages_data = data.get("value", [])
                
                self.logger.debug(f"Raw messages returned: {len(messages_data)}")
                
                # Debug: Show message types found
                if messages_data:
                    msg_types = {}
                    for msg in messages_data:
                        mt = msg.get("messageType", "unknown")
                        msg_types[mt] = msg_types.get(mt, 0) + 1
                    self.logger.debug(f"Message types found: {msg_types}")
                
                for msg in messages_data:
                    chat_msg = ChatMessage.from_api_response(msg, chat_id)
                    if include_system_messages or chat_msg.is_user_message:
                        all_messages.append(chat_msg)
                    else:
                        self.logger.debug(
                            f"Filtered out: type={chat_msg.message_type}, "
                            f"sender={chat_msg.sender_name}, content_len={len(chat_msg.content)}"
                        )
                
                self.logger.debug(f"User messages after filtering: {len(all_messages)}")
                
                # Get next page URL
                next_page_url = data.get("@odata.nextLink")
                break
            else:
                last_error = f"{response.status_code}: {response.text[:200]}"
                self.logger.debug(
                    f"Endpoint failed ({response.status_code}): {endpoint[:60]}..."
                )
        
        if not endpoint_succeeded:
            self.logger.warning(f"All endpoints failed to fetch chat messages. Last error: {last_error}")
            return []
        
        # Continue pagination with the working endpoint
        while next_page_url and len(all_messages) < max_messages:
            response = self._make_request("GET", next_page_url)  # nextLink has params built-in
            
            if response.status_code != 200:
                self.logger.warning(f"Failed to fetch next page: {response.status_code}")
                self.logger.debug(f"Error response: {response.text[:300]}")
                break
            
            data = response.json()
            messages_data = data.get("value", [])
            
            for msg in messages_data:
                chat_msg = ChatMessage.from_api_response(msg, chat_id)
                if include_system_messages or chat_msg.is_user_message:
                    all_messages.append(chat_msg)
            
            # Get next page URL
            next_page_url = data.get("@odata.nextLink")
        
        # Reverse to get chronological order (oldest first) - matching notebook approach
        # since we fetched with orderby=desc
        all_messages = list(reversed(all_messages[:max_messages]))
        
        return all_messages
    
    # -------------------------------------------------------------------------
    # HIGH-LEVEL OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_meetings_with_chats_in_range(
        self,
        start_datetime: datetime,
        end_datetime: datetime = None,
        limit: int = None,
        min_messages: int = 1,
    ) -> List[MeetingChatInfo]:
        """
        Get online meetings with chat messages within a date range.
        
        This method uses the simplified approach from the working notebook:
        1. Get calendar events with isOnlineMeeting=True
        2. Extract chat thread ID directly from join URL (regex extraction)
        3. Fetch messages using /users/{userId}/chats/{chatId}/messages
        
        Args:
            start_datetime: Start of the date range
            end_datetime: End of the date range (default: now)
            limit: Maximum number of meetings to fetch
            min_messages: Minimum number of messages required (default 1)
            
        Returns:
            List of MeetingChatInfo objects with populated messages
        """
        self.logger.info("Fetching online meetings with chat messages...")
        
        # Step 1: Get online meetings (chat_id already extracted from URL in from_calendar_event)
        meetings = self.get_online_meetings_in_range(start_datetime, end_datetime, limit)
        
        meetings_with_chats = []
        meetings_no_chat = 0
        
        for meeting in meetings:
            try:
                # Chat ID is already extracted from join URL by from_calendar_event
                chat_id = meeting.chat_id
                
                if not chat_id:
                    meetings_no_chat += 1
                    self.logger.debug(f"No chat thread ID in URL for meeting: {meeting.subject}")
                    continue
                
                self.logger.debug(f"Chat ID for '{meeting.subject}': {chat_id[:50]}...")
                
                # Fetch chat messages using the simplified approach
                messages = self.get_all_chat_messages_paginated(
                    chat_id=chat_id,
                    max_messages=500,  # Limit per meeting
                    include_system_messages=False,
                )
                
                meeting.messages = messages
                meeting.total_message_count = len(messages)
                
                if len(messages) >= min_messages:
                    self.logger.info(
                        f"  💬 {meeting.subject}: {len(messages)} message(s)"
                    )
                    meetings_with_chats.append(meeting)
                else:
                    self.logger.debug(
                        f"  Skipping {meeting.subject}: only {len(messages)} message(s)"
                    )
                    
            except Exception as e:
                self.logger.warning(f"Error processing meeting '{meeting.subject}': {e}")
                continue
        
        total_messages = sum(m.total_message_count for m in meetings_with_chats)
        self.logger.info(
            f"Found {len(meetings_with_chats)} meetings with chats "
            f"(total {total_messages} messages)"
        )
        
        if meetings_no_chat > 0:
            self.logger.debug(
                f"  ℹ️  Skipped {meetings_no_chat} meetings (no chat thread ID in URL)"
            )
        
        return meetings_with_chats


# =============================================================================
# MODULE-LEVEL CONVENIENCE
# =============================================================================

def create_chat_client(config: Config = None) -> ChatClient:
    """
    Create a ChatClient instance.
    
    Args:
        config: Optional Config instance (creates new one if not provided)
        
    Returns:
        ChatClient instance
    """
    if config is None:
        config = Config()
    return ChatClient(config)


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    from config import Config, ConfigurationError
    from datetime import timedelta
    import json
    import sys
    
    try:
        config = Config()
        config.validate()
        
        client = ChatClient(config)
        
        print("\n" + "=" * 60)
        print("TESTING CHAT CLIENT")
        print("=" * 60)
        
        # Test fetching meetings (last 30 days)
        end_date = datetime.now(timezone.utc)
        start_date = end_date - timedelta(days=30)
        
        print(f"\n1. Fetching online meetings from {start_date.date()} to {end_date.date()}...")
        meetings = client.get_online_meetings_in_range(
            start_datetime=start_date,
            end_datetime=end_date,
            limit=5,
        )
        
        print(f"   Found {len(meetings)} online meetings")
        
        if meetings:
            # Test chat access for first meeting
            meeting = meetings[0]
            print(f"\n2. Testing chat access for: {meeting.subject}")
            
            # Chat ID is now extracted from join URL by from_calendar_event
            chat_id = meeting.chat_id
            
            print(f"   Meeting ID: {meeting.meeting_id[:50] if meeting.meeting_id else 'N/A'}...")
            print(f"   Chat ID (from URL): {chat_id if chat_id else 'NOT FOUND'}")
            print(f"   Join URL: {meeting.join_url[:60] if meeting.join_url else 'N/A'}...")
            
            if chat_id:
                print(f"\n3. Testing chat access & permissions...")
                test_result = client.test_chat_access(chat_id)
                
                print(f"   Can access chat metadata: {test_result['can_access_chat']}")
                print(f"   Can read chat messages:   {test_result['can_read_messages']}")
                print(f"\n   Endpoints tested:")
                for ep in test_result["endpoints_tested"]:
                    status_icon = "✅" if ep["status"] == 200 else "❌"
                    print(f"     {status_icon} [{ep.get('purpose', 'N/A')}] {ep['endpoint']} -> {ep['status']}")
                    if ep.get("error"):
                        print(f"        Error: {ep['error'][:150]}...")
                
                if test_result.get("error_details"):
                    print(f"\n   {test_result['error_details']}")
                
                # Debug: Fetch ALL messages (including system) to see what's there
                print(f"\n   Fetching ALL messages (including system) for debugging...")
                all_msgs = client.get_all_chat_messages_paginated(
                    chat_id=chat_id,
                    max_messages=50,
                    include_system_messages=True,  # Include everything
                )
                print(f"   Total messages (including system): {len(all_msgs)}")
                
                # Show message breakdown by type
                msg_types = {}
                for msg in all_msgs:
                    msg_types[msg.message_type] = msg_types.get(msg.message_type, 0) + 1
                print(f"   Message types: {msg_types}")
                
                # Show first few messages
                user_msgs = [m for m in all_msgs if m.is_user_message]
                print(f"   User messages (filtered): {len(user_msgs)}")
                
                if all_msgs:
                    print(f"\n   Sample messages:")
                    for msg in all_msgs[:5]:
                        clean = re.sub(r'<[^>]+>', '', msg.content)[:60]
                        print(f"     [{msg.message_type}] {msg.sender_name}: {clean}...")
                
                # If can't read messages, skip step 4
                if not test_result['can_read_messages']:
                    print("\n" + "=" * 60)
                    print("⚠️  PERMISSION ISSUE DETECTED")
                    print("=" * 60)
                    print("Your Azure AD app can access chat metadata but NOT read messages.")
                    print("\nTO FIX: Add 'Chat.Read.All' Application permission in Azure Portal:")
                    print("  1. Go to Azure Portal → App Registrations")
                    print("  2. Select your app")
                    print("  3. API Permissions → Add permission → Microsoft Graph")
                    print("  4. Application permissions → Chat → Chat.Read.All")
                    print("  5. Grant admin consent")
                    print("\n✅ Chat Client test completed (with permission issues)")
                    sys.exit(0)  # Exit cleanly - permission issue detected
            else:
                print("   Could not extract chat thread ID from join URL")
        
        # Try fetching meetings with chats
        print(f"\n4. Fetching meetings with chat messages...")
        meetings_with_chats = client.get_meetings_with_chats_in_range(
            start_datetime=start_date,
            end_datetime=end_date,
            limit=5,
        )
        
        print(f"\nFound {len(meetings_with_chats)} meetings with chats:")
        for meeting in meetings_with_chats:
            print(f"\n  Meeting: {meeting.subject}")
            print(f"  Date: {meeting.start_datetime}")
            print(f"  Chat ID: {meeting.chat_id[:50] if meeting.chat_id else 'N/A'}...")
            print(f"  Messages: {meeting.total_message_count}")
            
            # Show first few messages
            for msg in meeting.messages[:3]:
                clean = re.sub(r'<[^>]+>', '', msg.content)[:50]
                print(f"    - [{msg.sender_name}]: {clean}...")
        
        print("\n✅ Chat Client test completed!")
        
    except ConfigurationError as e:
        print(f"\n❌ Configuration Error: {e}")
    except GraphAPIError as e:
        print(f"\n❌ Graph API Error: {e}")
