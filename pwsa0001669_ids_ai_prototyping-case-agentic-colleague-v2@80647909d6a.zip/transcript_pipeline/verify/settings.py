"""
Common settings module for verification scripts.

Fetches all configuration from AWS Secrets Manager instead of .env file.
This is the single source of truth for all pipeline configuration.

Usage (run from project root):
    from transcript_pipeline.verify.settings import get_config, get_config_value
    
    config = get_config()
    bucket_name = config.get("S3_BUCKET_NAME")
    
    # Or get individual value with default
    region = get_config_value("AWS_REGION", "us-east-1")
"""

import json
import os
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from functools import lru_cache
from dotenv import load_dotenv
load_dotenv()

# Default values (used if not found in Secrets Manager)
DEFAULTS = {
    "AWS_REGION": "us-east-1",
    "S3_BUCKET_NAME": "ids-aini-prototype-ai-analytics",
    "S3_PREFIX": "Agentic-Colleague-synthetic/meetings/",  # Base folder for meetings data
    "DYNAMODB_TABLE_NAME": "AgenticColleague_MeetingTracker",  # Shared table for transcripts and chats
    "MAX_RETRY_ATTEMPTS": "3",
    "MEETINGS_FETCH_LIMIT": "100",
    "LOG_LEVEL": "INFO",
}

# Secret Manager configuration (these can be overridden by environment variables)
SECRET_NAME = os.getenv("SECRET_NAME", "agentic-colleague/graph-api-config")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")


@lru_cache(maxsize=1)
def get_config() -> dict:
    """
    Fetch configuration from AWS Secrets Manager.
    
    Results are cached to avoid multiple API calls.
    
    Returns:
        dict: Configuration dictionary with all settings
        
    Raises:
        Exception: If unable to connect to Secrets Manager or retrieve secret
    """
    try:
        # Create Secrets Manager client
        client = boto3.client("secretsmanager", region_name=AWS_REGION)
        
        # Retrieve the secret
        response = client.get_secret_value(SecretId=SECRET_NAME)
        
        # Parse the secret value
        if "SecretString" in response:
            secret_data = json.loads(response["SecretString"])
        else:
            raise ValueError("Secret is binary, expected JSON string")
        
        # Merge with defaults (secret values take precedence)
        config = {**DEFAULTS, **secret_data}
        
        return config
        
    except NoCredentialsError:
        raise Exception(
            "No AWS credentials found. "
            "Ensure AWS credentials are configured (environment, ~/.aws/credentials, or IAM role)"
        )
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        if error_code == "ResourceNotFoundException":
            raise Exception(f"Secret '{SECRET_NAME}' not found in Secrets Manager")
        elif error_code == "AccessDeniedException":
            raise Exception(
                f"Access denied to secret '{SECRET_NAME}'. "
                "Check IAM permissions for secretsmanager:GetSecretValue"
            )
        else:
            raise Exception(f"Error retrieving secret: {error_code} - {e}")
    except json.JSONDecodeError:
        raise Exception("Secret value is not valid JSON")


def get_config_value(key: str, default: str = None) -> str:
    """
    Get a specific configuration value from Secrets Manager.
    
    Args:
        key: The configuration key to retrieve
        default: Default value if key not found
        
    Returns:
        str: The configuration value
    """
    try:
        config = get_config()
        return config.get(key, default or DEFAULTS.get(key))
    except Exception:
        # If we can't get config, return default
        return default or DEFAULTS.get(key)


def clear_config_cache():
    """Clear the cached configuration to force a fresh fetch."""
    get_config.cache_clear()


def print_config_summary():
    """Print a summary of the current configuration (with masked sensitive values)."""
    
    def mask_value(value: str, show_chars: int = 4) -> str:
        """Mask a sensitive value."""
        if not value or len(value) <= show_chars * 2:
            return "****"
        return f"{value[:show_chars]}...{value[-show_chars:]}"
    
    sensitive_keys = [
        "AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CERT_THUMBPRINT",
        "AZURE_CERT_CONTENT", "GRAPH_USER_ID"
    ]
    
    try:
        config = get_config()
        
        print("\nConfiguration from Secrets Manager:")
        print(f"  Secret Name: {SECRET_NAME}")
        print(f"  AWS Region: {AWS_REGION}")
        print("-" * 40)
        
        for key, value in sorted(config.items()):
            if key in sensitive_keys:
                print(f"  {key}: {mask_value(str(value))}")
            elif key == "AZURE_CERT_CONTENT":
                print(f"  {key}: [PEM CERTIFICATE - {len(str(value))} chars]")
            else:
                print(f"  {key}: {value}")
                
    except Exception as e:
        print(f"Error loading configuration: {e}")


# =============================================================================
# GENERIC HELPER FUNCTIONS FOR API USE
# =============================================================================

def get_all_dynamodb_records(dynamodb_client, table_name: str, record_type_filter: str = None) -> list:
    """
    Fetch all records from DynamoDB table.
    
    Args:
        dynamodb_client: boto3 DynamoDB client
        table_name: Name of the table
        record_type_filter: Optional filter for record_type (e.g., "TRANSCRIPT", "CHAT")
        
    Returns:
        List of all items in the table
    """
    from botocore.exceptions import ClientError
    
    all_items = []
    
    try:
        paginator = dynamodb_client.get_paginator('scan')
        
        if record_type_filter:
            for page in paginator.paginate(
                TableName=table_name,
                FilterExpression="record_type = :rt",
                ExpressionAttributeValues={":rt": {"S": record_type_filter}}
            ):
                items = page.get('Items', [])
                all_items.extend(items)
        else:
            for page in paginator.paginate(TableName=table_name):
                items = page.get('Items', [])
                all_items.extend(items)
        
        return all_items
        
    except ClientError as e:
        print(f"Error scanning table: {e}")
        return []


def get_all_s3_files(s3_client, bucket_name: str, prefix: str) -> list:
    """
    Fetch all files from S3 prefix using pagination.
    
    Args:
        s3_client: boto3 S3 client
        bucket_name: S3 bucket name
        prefix: S3 prefix (folder path)
        
    Returns:
        List of all objects in the prefix
    """
    from botocore.exceptions import ClientError
    
    all_files = []
    
    try:
        paginator = s3_client.get_paginator('list_objects_v2')
        
        for page in paginator.paginate(Bucket=bucket_name, Prefix=prefix):
            contents = page.get('Contents', [])
            all_files.extend(contents)
        
        return all_files
        
    except ClientError as e:
        print(f"Error listing files: {e}")
        return []
