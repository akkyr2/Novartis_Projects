"""
Run all transcript verification scripts in sequence.

Verifies:
1. AWS Secrets Manager - Configuration access and required keys validation
2. Transcript DynamoDB - Table access and CRUD operations (create, read, update, delete)
3. Transcript S3 - Bucket access, CRUD operations, and storage statistics

CLI (run from project root):
    python -m transcript_pipeline.verify.transcript.verify_all
"""

import sys
import os

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

# Import common settings
from transcript_pipeline.verify.settings import (
    get_config_value, 
    AWS_REGION, 
    SECRET_NAME,
)

# Import common verification
from transcript_pipeline.verify.verify_secrets import verify_secrets_manager

# Import transcript-specific verifications
from transcript_pipeline.verify.transcript.verify_dynamodb import verify_transcript_dynamodb
from transcript_pipeline.verify.transcript.verify_s3 import verify_transcript_s3


def print_banner():
    """Print the verification banner."""
    print("\n" + "=" * 60)
    print("   TRANSCRIPT PIPELINE - ENVIRONMENT VERIFICATION")
    print("=" * 60)
    
    # Print current configuration from Secrets Manager
    print("\nConfiguration (from Secrets Manager):")
    print(f"  AWS Region: {AWS_REGION}")
    print(f"  Secret Name: {SECRET_NAME}")
    
    try:
        base_prefix = get_config_value('S3_PREFIX').rstrip('/')
        print(f"  S3 Bucket: {get_config_value('S3_BUCKET_NAME')}")
        print(f"  S3 Base Prefix: {base_prefix}/")
        print(f"  S3 Transcript Prefix: {base_prefix}/transcripts/")
        print(f"  DynamoDB Table: {get_config_value('DYNAMODB_TABLE_NAME')}")
    except Exception as e:
        print(f"  ⚠️ Could not load config from Secrets Manager: {e}")


def verify_all_transcript() -> bool:
    """
    Run all transcript verification scripts in sequence.
    
    Returns:
        bool: True if all verifications pass, False otherwise
    """
    print_banner()
    
    results = {
        "secrets": False,
        "dynamodb": False,
        "s3": False
    }
    
    # Step 1: Verify Secrets Manager
    print("\n" + "=" * 60)
    print("[1/3] Verifying AWS Secrets Manager...")
    print("=" * 60)
    try:
        results["secrets"] = verify_secrets_manager()
    except Exception as e:
        print(f"  ❌ Secrets Manager verification failed with error: {e}")
        results["secrets"] = False
    
    # Step 2: Verify Transcript DynamoDB
    print("\n" + "=" * 60)
    print("[2/3] Verifying Transcript DynamoDB...")
    print("=" * 60)
    try:
        results["dynamodb"] = verify_transcript_dynamodb()
    except Exception as e:
        print(f"  ❌ Transcript DynamoDB verification failed with error: {e}")
        results["dynamodb"] = False
    
    # Step 3: Verify Transcript S3
    print("\n" + "=" * 60)
    print("[3/3] Verifying Transcript S3...")
    print("=" * 60)
    try:
        results["s3"] = verify_transcript_s3()
    except Exception as e:
        print(f"  ❌ Transcript S3 verification failed with error: {e}")
        results["s3"] = False
    
    # Print final summary
    print("\n" + "=" * 60)
    print("TRANSCRIPT PIPELINE VERIFICATION SUMMARY")
    print("=" * 60)
    
    print("\nResults:")
    print(f"  {'✅' if results['secrets'] else '❌'} AWS Secrets Manager: {'PASSED' if results['secrets'] else 'FAILED'}")
    print(f"  {'✅' if results['dynamodb'] else '❌'} Transcript DynamoDB: {'PASSED' if results['dynamodb'] else 'FAILED'}")
    print(f"  {'✅' if results['s3'] else '❌'} Transcript S3: {'PASSED' if results['s3'] else 'FAILED'}")
    
    all_passed = all(results.values())
    
    print("\n" + "=" * 60)
    if all_passed:
        print("✅ ALL TRANSCRIPT VERIFICATIONS PASSED")
        print("   Transcript pipeline is ready to run.")
        print("\n   Next step:")
        print("   python -m transcript_pipeline.main_v2 run --full --limit 5")
    else:
        print("❌ SOME TRANSCRIPT VERIFICATIONS FAILED")
        print("   Please fix the issues above before running the transcript pipeline.")
        
        # Provide hints based on what failed
        if not results["secrets"]:
            print("\n   Secrets Manager hints:")
            print("   - Ensure the secret exists in AWS Secrets Manager")
            print("   - Check IAM permissions for secretsmanager:GetSecretValue")
            
        if not results["dynamodb"]:
            print("\n   DynamoDB hints:")
            print("   - Check IAM permissions for DynamoDB operations")
            print("   - Verify the table name in configuration")
            
        if not results["s3"]:
            print("\n   S3 hints:")
            print("   - Ensure the bucket exists and is accessible")
            print("   - Check IAM permissions for s3:GetObject, s3:PutObject, s3:DeleteObject")
    
    print("=" * 60 + "\n")
    
    return all_passed


def main():
    """Main entry point for verify_all_transcript script."""
    try:
        success = verify_all_transcript()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\nVerification cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
