"""
Set Pipeline Start Date - Safety Mechanism for Transcript Pipeline.

This script allows you to manually set the `last_successful_run` timestamp
in the DynamoDB pipeline metadata. This controls from which date the cronjob
scheduler will start picking up meetings.

Use Cases:
- Avoid re-processing old test meetings
- Start fresh from a specific date after cleanup
- Reset the pipeline to a known good state
- Skip historical meetings during testing

CLI (run from project root):
    # Interactive mode - prompts for date
    python -m transcript_pipeline.verify.transcript.set_pipeline_start_date
    
    # Set specific date (ISO format)
    python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --date "2026-08-15T00:00:00Z"
    
    # Set to "now" (skip all meetings until this moment - accounts for 1h buffer)
    python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --now
    
    # Set to "now" with custom buffer (e.g., 2 hours)
    python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --now --buffer-hours 2
    
    # Set days ago (e.g., start from 7 days ago)
    python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --days-ago 7
    
    # View current metadata only (no changes)
    python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --view
    
    # Dry run - show what would happen without making changes
    python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --date "2026-08-15T00:00:00Z" --dry-run

Author: Agentic Colleague Team
"""

import sys
import os
import argparse
from datetime import datetime, timezone, timedelta

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.verify.settings import get_config_value, AWS_REGION


# ============================================================================
# CONSTANTS
# ============================================================================

TRANSCRIPT_PIPELINE_METADATA_ID = "__TRANSCRIPT_PIPELINE_METADATA__"


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_dynamodb_client():
    """Get a DynamoDB client."""
    return boto3.client("dynamodb", region_name=AWS_REGION)


def parse_datetime(date_str: str) -> datetime:
    """
    Parse a datetime string in various formats.
    
    Supports:
    - ISO format: 2026-08-15T00:00:00Z
    - ISO format with offset: 2026-08-15T00:00:00+00:00
    - Date only: 2026-08-15 (assumes 00:00:00 UTC)
    - Date with time: 2026-08-15 10:30:00
    """
    date_str = date_str.strip()
    
    # Try ISO format first
    for fmt in [
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S+00:00",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ]:
        try:
            dt = datetime.strptime(date_str, fmt)
            # Ensure timezone aware
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    
    # Try fromisoformat as last resort
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        pass
    
    raise ValueError(f"Could not parse date: {date_str}")


def get_current_metadata(client, table_name: str) -> dict:
    """Get current pipeline metadata from DynamoDB."""
    try:
        response = client.get_item(
            TableName=table_name,
            Key={"record_id": {"S": TRANSCRIPT_PIPELINE_METADATA_ID}},
        )
        
        item = response.get("Item")
        if not item:
            return None
        
        return {
            "last_successful_run": item.get("last_successful_run", {}).get("S"),
            "last_run_status": item.get("last_run_status", {}).get("S"),
            "total_runs": int(item.get("total_runs", {}).get("N", "0")),
            "total_processed": int(item.get("total_processed", {}).get("N", "0")),
            "total_failed": int(item.get("total_failed", {}).get("N", "0")),
            "created_at": item.get("created_at", {}).get("S"),
            "updated_at": item.get("updated_at", {}).get("S"),
        }
        
    except ClientError as e:
        print(f"❌ Error getting metadata: {e}")
        return None


def print_metadata(metadata: dict, title: str = "CURRENT PIPELINE METADATA"):
    """Pretty print pipeline metadata."""
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)
    
    if not metadata:
        print("  ℹ️  No metadata found (first run or table empty)")
    else:
        print(f"  📅 Last Successful Run: {metadata.get('last_successful_run', 'N/A')}")
        print(f"  📊 Last Run Status:     {metadata.get('last_run_status', 'N/A')}")
        print(f"  🔢 Total Runs:          {metadata.get('total_runs', 0)}")
        print(f"  ✅ Total Processed:     {metadata.get('total_processed', 0)}")
        print(f"  ❌ Total Failed:        {metadata.get('total_failed', 0)}")
        print(f"  📆 First Run:           {metadata.get('created_at', 'N/A')}")
        print(f"  🕒 Last Updated:        {metadata.get('updated_at', 'N/A')}")
    
    print("=" * 60)


def set_pipeline_start_date(
    client,
    table_name: str,
    new_date: datetime,
    dry_run: bool = False,
    preserve_stats: bool = True,
) -> bool:
    """
    Set the pipeline start date (last_successful_run) in DynamoDB.
    
    Args:
        client: DynamoDB client
        table_name: DynamoDB table name
        new_date: New datetime to set as last_successful_run
        dry_run: If True, only show what would happen
        preserve_stats: If True, preserve existing run statistics
        
    Returns:
        bool: True if successful, False otherwise
    """
    timestamp = datetime.now(timezone.utc).isoformat()
    date_str = new_date.isoformat()
    
    # Get existing metadata
    existing = get_current_metadata(client, table_name)
    
    if existing and preserve_stats:
        total_runs = existing.get("total_runs", 0)
        total_processed = existing.get("total_processed", 0)
        total_failed = existing.get("total_failed", 0)
        created_at = existing.get("created_at", timestamp)
    else:
        total_runs = 0
        total_processed = 0
        total_failed = 0
        created_at = timestamp
    
    print(f"\n📝 Setting last_successful_run to: {date_str}")
    
    if dry_run:
        print("  🔸 DRY RUN - No changes will be made")
        print(f"  🔸 Would set last_successful_run = {date_str}")
        print(f"  🔸 Would set last_run_status = MANUAL_SET")
        return True
    
    try:
        item = {
            "record_id": {"S": TRANSCRIPT_PIPELINE_METADATA_ID},
            "record_type": {"S": "TRANSCRIPT_METADATA"},
            "last_successful_run": {"S": date_str},
            "last_run_status": {"S": "MANUAL_SET"},
            "total_runs": {"N": str(total_runs)},
            "total_processed": {"N": str(total_processed)},
            "total_failed": {"N": str(total_failed)},
            "created_at": {"S": created_at},
            "updated_at": {"S": timestamp},
        }
        
        client.put_item(TableName=table_name, Item=item)
        
        print(f"  ✅ Successfully updated pipeline metadata")
        print(f"  ✅ Cronjob will now start fetching meetings from: {date_str}")
        return True
        
    except ClientError as e:
        print(f"  ❌ Failed to update metadata: {e}")
        return False


def interactive_date_prompt() -> datetime:
    """Prompt user to enter a date interactively."""
    print("\n" + "=" * 60)
    print("ENTER NEW START DATE")
    print("=" * 60)
    print("  Supported formats:")
    print("    - ISO: 2026-08-15T00:00:00Z")
    print("    - Date only: 2026-08-15 (assumes 00:00:00 UTC)")
    print("    - Date+time: 2026-08-15 10:30:00")
    print("=" * 60)
    
    while True:
        try:
            date_str = input("\n  Enter date (or 'q' to quit): ").strip()
            
            if date_str.lower() in ('q', 'quit', 'exit'):
                print("  Cancelled by user.")
                sys.exit(0)
            
            dt = parse_datetime(date_str)
            
            # Confirm with user
            print(f"\n  📅 Parsed date: {dt.isoformat()}")
            confirm = input("  Is this correct? (y/n): ").strip().lower()
            
            if confirm in ('y', 'yes'):
                return dt
            else:
                print("  Let's try again...")
                
        except ValueError as e:
            print(f"  ❌ Invalid date format: {e}")
            print("  Please try again.")


def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Set pipeline start date for transcript cronjob scheduler",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # View current metadata only
  python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --view
  
  # Set specific date (ISO format)
  python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --date "2026-08-15T00:00:00Z"
  
  # Set to current time (skip all historical meetings, accounts for 1h buffer)
  python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --now
  
  # Set to current time with 2h buffer (if pipeline uses 2h buffer)
  python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --now --buffer-hours 2
  
  # Set to 7 days ago
  python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --days-ago 7
  
  # Dry run to see what would happen
  python -m transcript_pipeline.verify.transcript.set_pipeline_start_date --date "2026-08-15T00:00:00Z" --dry-run
        """
    )
    
    # Mutually exclusive date options
    date_group = parser.add_mutually_exclusive_group()
    date_group.add_argument(
        "--date", "-d",
        type=str,
        help="Set start date (ISO format: 2026-08-15T00:00:00Z or 2026-08-15)"
    )
    date_group.add_argument(
        "--now", "-n",
        action="store_true",
        help="Set start date to current UTC time (skip all historical meetings)"
    )
    date_group.add_argument(
        "--days-ago",
        type=int,
        metavar="N",
        help="Set start date to N days ago from now"
    )
    date_group.add_argument(
        "--view", "-v",
        action="store_true",
        help="Only view current metadata without making changes"
    )
    
    # Other options
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would happen without making changes"
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Skip confirmation prompt (use with caution)"
    )
    parser.add_argument(
        "--reset-stats",
        action="store_true",
        help="Reset run statistics (total_runs, total_processed, total_failed) to zero"
    )
    parser.add_argument(
        "--buffer-hours",
        type=int,
        default=1,
        metavar="H",
        help="Buffer hours to add when using --now (default: 1). The pipeline subtracts this buffer, so we add it to compensate."
    )
    
    args = parser.parse_args()
    
    # Print header
    print("\n" + "=" * 60)
    print("SET PIPELINE START DATE - SAFETY MECHANISM")
    print("=" * 60)
    
    # Get configuration
    table_name = get_config_value("DYNAMODB_TABLE_NAME", "AgenticColleague_MeetingTracker")
    
    print(f"\nConfiguration:")
    print(f"  AWS Region:  {AWS_REGION}")
    print(f"  Table Name:  {table_name}")
    print(f"  Metadata ID: {TRANSCRIPT_PIPELINE_METADATA_ID}")
    
    # Initialize DynamoDB client
    try:
        client = get_dynamodb_client()
    except NoCredentialsError:
        print("\n❌ No AWS credentials found!")
        print("   Ensure AWS credentials are configured.")
        sys.exit(1)
    
    # Get and display current metadata
    current_metadata = get_current_metadata(client, table_name)
    print_metadata(current_metadata)
    
    # If view-only mode, exit here
    if args.view:
        print("\n✅ View-only mode complete. No changes made.")
        sys.exit(0)
    
    # Determine the new date
    if args.now:
        # Add buffer hours to compensate for pipeline's buffer subtraction
        # Pipeline does: start_datetime = last_run - buffer_hours
        # So we set: last_run = now + buffer_hours
        # Result: start_datetime = (now + buffer) - buffer = now
        buffer_hours = args.buffer_hours
        base_time = datetime.now(timezone.utc)
        new_date = base_time + timedelta(hours=buffer_hours)
        print(f"\n📅 Current UTC time: {base_time.isoformat()}")
        print(f"   Adding {buffer_hours}h buffer to compensate for pipeline's buffer subtraction")
        print(f"   Setting last_successful_run to: {new_date.isoformat()}")
        print(f"   ➡️  Pipeline will calculate: {new_date.isoformat()} - {buffer_hours}h = {base_time.isoformat()}")
        print(f"   ➡️  Meetings AFTER {base_time.isoformat()} will be picked up")
        
    elif args.days_ago:
        new_date = datetime.now(timezone.utc) - timedelta(days=args.days_ago)
        print(f"\n📅 Using {args.days_ago} days ago: {new_date.isoformat()}")
        
    elif args.date:
        try:
            new_date = parse_datetime(args.date)
            print(f"\n📅 Using provided date: {new_date.isoformat()}")
        except ValueError as e:
            print(f"\n❌ Invalid date format: {e}")
            sys.exit(1)
            
    else:
        # Interactive mode
        new_date = interactive_date_prompt()
    
    # Confirmation before proceeding (unless dry-run or force)
    if not args.dry_run and not args.force:
        print("\n" + "⚠️ " * 20)
        print("  WARNING: This will update the pipeline metadata in DynamoDB!")
        print(f"  New start date: {new_date.isoformat()}")
        print(f"  Cronjob will fetch meetings AFTER this date only.")
        print("⚠️ " * 20)
        
        confirm = input("\n  Proceed? (yes/no): ").strip().lower()
        if confirm not in ('yes', 'y'):
            print("\n  ❌ Cancelled by user.")
            sys.exit(0)
    
    # Perform the update
    preserve_stats = not args.reset_stats
    success = set_pipeline_start_date(
        client,
        table_name,
        new_date,
        dry_run=args.dry_run,
        preserve_stats=preserve_stats,
    )
    
    if success and not args.dry_run:
        # Show updated metadata
        updated_metadata = get_current_metadata(client, table_name)
        print_metadata(updated_metadata, "UPDATED PIPELINE METADATA")
        
        print("\n" + "=" * 60)
        print("✅ SUCCESS!")
        print("=" * 60)
        print(f"  The cronjob scheduler will now fetch meetings")
        print(f"  starting from: {new_date.isoformat()}")
        print("=" * 60)
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
