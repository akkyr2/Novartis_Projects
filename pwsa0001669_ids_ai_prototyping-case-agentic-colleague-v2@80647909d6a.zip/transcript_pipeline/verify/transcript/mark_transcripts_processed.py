"""
Mark Transcripts as Processed - Skip Old Meetings in Pipeline.

This script marks specific transcripts (or all transcripts from a date range)
as "COMPLETED" in DynamoDB so the pipeline will skip them even if they appear
in the date range query.

Use Cases:
- Mark old test meetings as processed to avoid re-processing
- Skip specific transcripts without deleting them
- Clean up after testing

CLI (run from project root):
    # Mark a specific transcript as processed
    python -m transcript_pipeline.verify.transcript.mark_transcripts_processed --transcript-id "ktVizInGAAAAi_B6lATZRTE5Om1lZX..."
    
    # Mark all transcripts from meetings before a certain date as processed
    python -m transcript_pipeline.verify.transcript.mark_transcripts_processed --before "2026-08-17T13:00:00Z"
    
    # List all pending/unprocessed transcript records
    python -m transcript_pipeline.verify.transcript.mark_transcripts_processed --list
    
    # Dry run - show what would be marked without making changes
    python -m transcript_pipeline.verify.transcript.mark_transcripts_processed --before "2026-08-17T13:00:00Z" --dry-run

Author: Agentic Colleague Team
"""

import sys
import os
import argparse
from datetime import datetime, timezone, timedelta
from typing import List, Optional

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.verify.settings import get_config_value, AWS_REGION
from transcript_pipeline.config import Config
from transcript_pipeline.dynamodb_tracker import (
    DynamoDBTracker,
    TranscriptStatus,
    RECORD_TYPE_TRANSCRIPT,
)


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def parse_datetime(date_str: str) -> datetime:
    """Parse a datetime string in various formats."""
    date_str = date_str.strip()
    
    for fmt in [
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S+00:00",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ]:
        try:
            dt = datetime.strptime(date_str, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        pass
    
    raise ValueError(f"Could not parse date: {date_str}")


def list_transcript_records(tracker: DynamoDBTracker) -> List[dict]:
    """List all transcript records from DynamoDB."""
    records = []
    
    for status in TranscriptStatus:
        status_records = tracker.get_records_by_status(status)
        records.extend(status_records)
    
    return records


def mark_transcript_completed(
    tracker: DynamoDBTracker,
    transcript_id: str,
    dry_run: bool = False,
) -> bool:
    """Mark a transcript as completed."""
    existing = tracker.get_record(transcript_id)
    
    if existing:
        if existing.status == TranscriptStatus.COMPLETED:
            print(f"  ℹ️  Already COMPLETED: {transcript_id[:50]}...")
            return True
        
        if dry_run:
            print(f"  🔸 Would mark as COMPLETED: {transcript_id[:50]}...")
            print(f"     Current status: {existing.status.value}")
            return True
        
        # Mark as completed with a dummy S3 path
        tracker.mark_completed(
            transcript_id=transcript_id,
            s3_path="MANUALLY_MARKED_SKIP",
        )
        print(f"  ✅ Marked as COMPLETED: {transcript_id[:50]}...")
        return True
    else:
        print(f"  ⚠️  Record not found: {transcript_id[:50]}...")
        return False


def create_and_mark_completed(
    tracker: DynamoDBTracker,
    transcript_id: str,
    meeting_subject: str = "MANUALLY_MARKED",
    dry_run: bool = False,
) -> bool:
    """Create a transcript record and mark it as completed."""
    if dry_run:
        print(f"  🔸 Would create and mark as COMPLETED: {transcript_id[:50]}...")
        return True
    
    # Create the record first
    tracker.create_record(
        transcript_id=transcript_id,
        meeting_id="MANUAL_SKIP",
        meeting_subject=meeting_subject,
        join_url="MANUAL_SKIP",
        status=TranscriptStatus.PROCESSING,
    )
    
    # Mark as completed
    tracker.mark_completed(
        transcript_id=transcript_id,
        s3_path="MANUALLY_MARKED_SKIP",
    )
    
    print(f"  ✅ Created and marked as COMPLETED: {transcript_id[:50]}...")
    return True


def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Mark transcripts as processed to skip them in future pipeline runs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List all transcript records
  python -m transcript_pipeline.verify.transcript.mark_transcripts_processed --list
  
  # Mark a specific transcript as processed
  python -m transcript_pipeline.verify.transcript.mark_transcripts_processed --transcript-id "ktVizInGAAAAi_B6lATZRTE5Om1lZXQ..."
  
  # Dry run
  python -m transcript_pipeline.verify.transcript.mark_transcripts_processed --transcript-id "xyz" --dry-run
        """
    )
    
    # Actions
    action_group = parser.add_mutually_exclusive_group(required=True)
    action_group.add_argument(
        "--list", "-l",
        action="store_true",
        help="List all transcript records in DynamoDB"
    )
    action_group.add_argument(
        "--transcript-id", "-t",
        type=str,
        help="Mark a specific transcript ID as completed"
    )
    action_group.add_argument(
        "--mark-all-pending",
        action="store_true",
        help="Mark all PENDING transcripts as COMPLETED"
    )
    action_group.add_argument(
        "--mark-all-failed",
        action="store_true",
        help="Mark all FAILED/PERMANENTLY_FAILED transcripts as COMPLETED"
    )
    
    # Options
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would happen without making changes"
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Skip confirmation prompt"
    )
    
    args = parser.parse_args()
    
    # Print header
    print("\n" + "=" * 60)
    print("MARK TRANSCRIPTS AS PROCESSED")
    print("=" * 60)
    
    # Initialize tracker
    try:
        config = Config()
        tracker = DynamoDBTracker(config)
        print(f"\nConnected to DynamoDB table: {config.dynamodb_table_name}")
    except Exception as e:
        print(f"\n❌ Failed to initialize: {e}")
        sys.exit(1)
    
    # Handle --list
    if args.list:
        print("\n📋 Transcript Records in DynamoDB:")
        print("-" * 60)
        
        records = list_transcript_records(tracker)
        
        if not records:
            print("  No transcript records found.")
        else:
            # Group by status
            by_status = {}
            for r in records:
                status = r.status.value
                if status not in by_status:
                    by_status[status] = []
                by_status[status].append(r)
            
            for status, recs in sorted(by_status.items()):
                print(f"\n  {status} ({len(recs)}):")
                for r in recs[:10]:  # Limit to 10 per status
                    print(f"    - {r.transcript_id[:50]}...")
                    print(f"      Subject: {r.meeting_subject[:40]}...")
                    if r.created_at:
                        print(f"      Created: {r.created_at}")
                if len(recs) > 10:
                    print(f"    ... and {len(recs) - 10} more")
        
        print("\n" + "=" * 60)
        tracker.print_stats()
        sys.exit(0)
    
    # Handle --transcript-id
    if args.transcript_id:
        print(f"\nMarking transcript: {args.transcript_id[:50]}...")
        
        existing = tracker.get_record(args.transcript_id)
        
        if existing:
            success = mark_transcript_completed(tracker, args.transcript_id, args.dry_run)
        else:
            # Create and mark if doesn't exist
            if not args.dry_run and not args.force:
                print(f"\n  ⚠️  Transcript record doesn't exist in DynamoDB.")
                print(f"  This will create a new record and mark it as COMPLETED.")
                confirm = input("  Proceed? (yes/no): ").strip().lower()
                if confirm not in ('yes', 'y'):
                    print("  ❌ Cancelled.")
                    sys.exit(0)
            
            success = create_and_mark_completed(
                tracker, args.transcript_id, dry_run=args.dry_run
            )
        
        if success:
            print("\n✅ Done!")
        else:
            print("\n❌ Failed!")
            sys.exit(1)
        
        sys.exit(0)
    
    # Handle --mark-all-pending
    if args.mark_all_pending:
        pending = tracker.get_records_by_status(TranscriptStatus.PENDING)
        
        if not pending:
            print("\n  ℹ️  No PENDING transcripts found.")
            sys.exit(0)
        
        print(f"\n  Found {len(pending)} PENDING transcript(s):")
        for r in pending:
            print(f"    - {r.transcript_id[:50]}... ({r.meeting_subject[:30]}...)")
        
        if not args.dry_run and not args.force:
            confirm = input(f"\n  Mark all {len(pending)} as COMPLETED? (yes/no): ").strip().lower()
            if confirm not in ('yes', 'y'):
                print("  ❌ Cancelled.")
                sys.exit(0)
        
        success_count = 0
        for r in pending:
            if mark_transcript_completed(tracker, r.transcript_id, args.dry_run):
                success_count += 1
        
        print(f"\n✅ Marked {success_count}/{len(pending)} transcripts as COMPLETED")
        sys.exit(0)
    
    # Handle --mark-all-failed
    if args.mark_all_failed:
        failed = tracker.get_records_by_status(TranscriptStatus.FAILED)
        perm_failed = tracker.get_records_by_status(TranscriptStatus.PERMANENTLY_FAILED)
        all_failed = failed + perm_failed
        
        if not all_failed:
            print("\n  ℹ️  No FAILED transcripts found.")
            sys.exit(0)
        
        print(f"\n  Found {len(all_failed)} FAILED transcript(s):")
        for r in all_failed:
            print(f"    - {r.transcript_id[:50]}... ({r.status.value})")
        
        if not args.dry_run and not args.force:
            confirm = input(f"\n  Mark all {len(all_failed)} as COMPLETED? (yes/no): ").strip().lower()
            if confirm not in ('yes', 'y'):
                print("  ❌ Cancelled.")
                sys.exit(0)
        
        success_count = 0
        for r in all_failed:
            if mark_transcript_completed(tracker, r.transcript_id, args.dry_run):
                success_count += 1
        
        print(f"\n✅ Marked {success_count}/{len(all_failed)} transcripts as COMPLETED")
        sys.exit(0)


if __name__ == "__main__":
    main()
