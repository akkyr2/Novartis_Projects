"""
Transcript Pipeline Verification Scripts.

This package contains verification and cleanup utilities for the transcript pipeline:
- verify_dynamodb.py - Verify transcript DynamoDB tracker
- verify_s3.py - Verify transcript S3 storage
- cleanup_dynamodb.py - Clean up transcript DynamoDB records
- cleanup_s3.py - Clean up transcript S3 files
- download_files.py - Download transcript files from S3
- verify_all.py - Run all transcript verifications

Usage (run from project root):
    # Run all transcript verifications
    python -m transcript_pipeline.verify.transcript.verify_all
    
    # Individual verifications
    python -m transcript_pipeline.verify.transcript.verify_dynamodb
    python -m transcript_pipeline.verify.transcript.verify_s3
    
    # Cleanup utilities
    python -m transcript_pipeline.verify.transcript.cleanup_dynamodb
    python -m transcript_pipeline.verify.transcript.cleanup_s3
    
    # Download files
    python -m transcript_pipeline.verify.transcript.download_files
"""

# Note: We intentionally do NOT import submodules here to avoid circular imports
# and dependency issues. Import directly from the specific module you need:
#   from transcript_pipeline.verify.transcript.verify_dynamodb import verify_transcript_dynamodb
#   from transcript_pipeline.verify.transcript.verify_s3 import verify_transcript_s3

__all__ = [
    "verify_transcript_dynamodb",
    "verify_transcript_s3",
    "cleanup_transcript_dynamodb",
    "cleanup_transcript_s3",
    "download_transcript_files",
    "verify_all_transcript",
]
