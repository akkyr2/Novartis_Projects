"""
Verify Transcript DynamoDB Tracker.

Test DynamoDB table creation and CRUD operations:
- Check if table exists → create if missing
- Wait for table to become ACTIVE
- Insert a test record
- Read the test record back
- Update the test record status
- Delete the test record
- Print success/failure for each operation

CLI (run from project root):
    python -m transcript_pipeline.verify.transcript.verify_dynamodb
"""

import sys
import os
import time
from datetime import datetime, timezone

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.verify.settings import get_config_value, AWS_REGION


def create_table_if_not_exists(dynamodb_client, table_name: str) -> bool:
    """
    Create DynamoDB table if it doesn't exist.
    
    Args:
        dynamodb_client: boto3 DynamoDB client
        table_name: Name of the table to create
        
    Returns:
        bool: True if table exists or was created successfully
    """
    try:
        # Check if table exists
        dynamodb_client.describe_table(TableName=table_name)
        print(f"  ✅ Table '{table_name}' already exists")
        return True
        
    except ClientError as e:
        if e.response["Error"]["Code"] == "ResourceNotFoundException":
            print(f"  ⚠️ Table '{table_name}' not found, creating...")
            
            try:
                # Create table with new schema (record_id as PK)
                dynamodb_client.create_table(
                    TableName=table_name,
                    KeySchema=[
                        {"AttributeName": "record_id", "KeyType": "HASH"}
                    ],
                    AttributeDefinitions=[
                        {"AttributeName": "record_id", "AttributeType": "S"},
                        {"AttributeName": "record_type", "AttributeType": "S"},
                        {"AttributeName": "status", "AttributeType": "S"}
                    ],
                    GlobalSecondaryIndexes=[
                        {
                            "IndexName": "record_type-status-index",
                            "KeySchema": [
                                {"AttributeName": "record_type", "KeyType": "HASH"},
                                {"AttributeName": "status", "KeyType": "RANGE"}
                            ],
                            "Projection": {"ProjectionType": "ALL"}
                        }
                    ],
                    BillingMode="PAY_PER_REQUEST"
                )
                print(f"  ✅ Table '{table_name}' creation initiated")
                return True
                
            except ClientError as create_error:
                print(f"  ❌ Failed to create table: {create_error}")
                return False
        else:
            print(f"  ❌ Error checking table: {e}")
            return False


def wait_for_table_active(dynamodb_client, table_name: str, timeout: int = 60) -> bool:
    """
    Wait for table to become ACTIVE.
    
    Args:
        dynamodb_client: boto3 DynamoDB client
        table_name: Name of the table
        timeout: Maximum seconds to wait
        
    Returns:
        bool: True if table is ACTIVE within timeout
    """
    print(f"  Waiting for table to become ACTIVE (timeout: {timeout}s)...")
    
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            response = dynamodb_client.describe_table(TableName=table_name)
            status = response["Table"]["TableStatus"]
            
            if status == "ACTIVE":
                print(f"  ✅ Table is ACTIVE")
                return True
            
            print(f"     Status: {status}...")
            time.sleep(2)
            
        except ClientError as e:
            print(f"  ❌ Error checking table status: {e}")
            return False
    
    print(f"  ❌ Timeout waiting for table to become ACTIVE")
    return False


def verify_transcript_dynamodb() -> bool:
    """
    Verify DynamoDB table access and CRUD operations for transcripts.
    
    Returns:
        bool: True if all verifications pass, False otherwise
    """
    print("\n" + "=" * 60)
    print("VERIFYING TRANSCRIPT DYNAMODB")
    print("=" * 60)
    
    # Get configuration from Secrets Manager via settings
    aws_region = AWS_REGION
    table_name = get_config_value("DYNAMODB_TABLE_NAME", "AgenticColleague_MeetingTracker")
    
    print(f"\nConfiguration:")
    print(f"  AWS Region: {aws_region}")
    print(f"  Table Name: {table_name}")
    
    test_record_id = "TEST_VERIFY_TRANSCRIPT_001"
    all_passed = True
    
    try:
        # Connect to DynamoDB
        print("\n[1/6] Connecting to DynamoDB...")
        dynamodb = boto3.client("dynamodb", region_name=aws_region)
        dynamodb_resource = boto3.resource("dynamodb", region_name=aws_region)
        print("  ✅ Connected to DynamoDB")
        
    except NoCredentialsError:
        print("  ❌ FAILED: No AWS credentials found")
        return False
    except Exception as e:
        print(f"  ❌ FAILED: Could not connect to DynamoDB - {e}")
        return False
    
    # Step 2: Check/Create table
    print(f"\n[2/6] Checking table '{table_name}'...")
    if not create_table_if_not_exists(dynamodb, table_name):
        return False
    
    # Wait for table to be active
    if not wait_for_table_active(dynamodb, table_name):
        return False
    
    # Get table resource for easier operations
    table = dynamodb_resource.Table(table_name)
    
    # Step 3: Insert test record (using new schema with record_id and record_type)
    print(f"\n[3/6] Inserting test record (record_id='{test_record_id}')...")
    try:
        test_item = {
            "record_id": test_record_id,
            "record_type": "TRANSCRIPT",  # Distinguish from chat records
            "meeting_id": "TEST_MEETING_001",
            "meeting_subject": "Verification Test Meeting",
            "status": "PENDING",
            "retry_count": 0,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        table.put_item(Item=test_item)
        print("  ✅ Insert test record: SUCCESS")
        
    except ClientError as e:
        print(f"  ❌ Insert test record: FAILED - {e}")
        all_passed = False
    
    # Step 4: Read test record
    print(f"\n[4/6] Reading test record...")
    try:
        response = table.get_item(Key={"record_id": test_record_id})
        
        if "Item" in response:
            item = response["Item"]
            print(f"  ✅ Read test record: SUCCESS")
            print(f"     - record_id: {item.get('record_id')}")
            print(f"     - record_type: {item.get('record_type')}")
            print(f"     - status: {item.get('status')}")
            print(f"     - meeting_subject: {item.get('meeting_subject')}")
        else:
            print("  ❌ Read test record: FAILED - Item not found")
            all_passed = False
            
    except ClientError as e:
        print(f"  ❌ Read test record: FAILED - {e}")
        all_passed = False
    
    # Step 5: Update test record
    print(f"\n[5/6] Updating test record status...")
    try:
        table.update_item(
            Key={"record_id": test_record_id},
            UpdateExpression="SET #status = :status, updated_at = :updated",
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={
                ":status": "COMPLETED",
                ":updated": datetime.now(timezone.utc).isoformat()
            }
        )
        
        # Verify update
        response = table.get_item(Key={"record_id": test_record_id})
        if response.get("Item", {}).get("status") == "COMPLETED":
            print("  ✅ Update test record: SUCCESS")
        else:
            print("  ❌ Update test record: FAILED - Status not updated")
            all_passed = False
            
    except ClientError as e:
        print(f"  ❌ Update test record: FAILED - {e}")
        all_passed = False
    
    # Step 6: Delete test record
    print(f"\n[6/6] Deleting test record...")
    try:
        table.delete_item(Key={"record_id": test_record_id})
        
        # Verify deletion
        response = table.get_item(Key={"record_id": test_record_id})
        if "Item" not in response:
            print("  ✅ Delete test record: SUCCESS")
        else:
            print("  ❌ Delete test record: FAILED - Item still exists")
            all_passed = False
            
    except ClientError as e:
        print(f"  ❌ Delete test record: FAILED - {e}")
        all_passed = False
    
    # Summary
    print("\n" + "-" * 60)
    if all_passed:
        print("✅ All Transcript DynamoDB operations completed successfully")
    else:
        print("❌ Some Transcript DynamoDB operations failed")
    
    return all_passed


def main():
    """Main entry point for verify_transcript_dynamodb script."""
    try:
        success = verify_transcript_dynamodb()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\nVerification cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
