# Verification scripts for transcript and chat pipelines
# Run these before the main pipelines to ensure AWS services are accessible
#
# Folder Structure:
#   verify/
#   ├── __init__.py          # This file
#   ├── settings.py          # Common settings and configuration
#   ├── verify_secrets.py    # Common AWS Secrets Manager verification
#   ├── chat/                # Chat pipeline verification scripts
#   │   ├── verify_all.py
#   │   ├── verify_dynamodb.py
#   │   ├── verify_s3.py
#   │   ├── cleanup_dynamodb.py
#   │   ├── cleanup_s3.py
#   │   └── download_files.py
#   └── transcript/          # Transcript pipeline verification scripts
#       ├── verify_all.py
#       ├── verify_dynamodb.py
#       ├── verify_s3.py
#       ├── cleanup_dynamodb.py
#       ├── cleanup_s3.py
#       └── download_files.py
#
# Usage (run from project root):
#   # Common verification
#   python -m transcript_pipeline.verify.verify_secrets
#
#   # Chat pipeline verification
#   python -m transcript_pipeline.verify.chat.verify_all
#   python -m transcript_pipeline.verify.chat.verify_dynamodb
#   python -m transcript_pipeline.verify.chat.verify_s3
#   python -m transcript_pipeline.verify.chat.cleanup_dynamodb
#   python -m transcript_pipeline.verify.chat.cleanup_s3
#   python -m transcript_pipeline.verify.chat.download_files
#
#   # Transcript pipeline verification
#   python -m transcript_pipeline.verify.transcript.verify_all
#   python -m transcript_pipeline.verify.transcript.verify_dynamodb
#   python -m transcript_pipeline.verify.transcript.verify_s3
#   python -m transcript_pipeline.verify.transcript.cleanup_dynamodb
#   python -m transcript_pipeline.verify.transcript.cleanup_s3
#   python -m transcript_pipeline.verify.transcript.download_files

# Note: We intentionally do NOT import submodules here to avoid circular imports
# and dependency issues. Import directly from the specific module you need:
#   from transcript_pipeline.verify.settings import get_config_value
#   from transcript_pipeline.verify.verify_secrets import verify_secrets_manager

__all__ = [
    # Common modules
    "settings",
    "verify_secrets",
    # Subpackages
    "chat",
    "transcript",
]