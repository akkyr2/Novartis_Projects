"""
Verify AWS Secrets Manager access and configuration.

Test loading configuration from AWS Secrets Manager:
- Connect to Secrets Manager using boto3
- Retrieve secret by name
- Parse JSON and validate required keys exist
- Print masked values (show first/last 4 chars only)
- Exit with success/failure code

CLI (run from project root):
    python -m transcript_pipeline.verify.verify_secrets
"""

import sys
import json
import os

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PIPELINE_DIR = os.path.dirname(_SCRIPT_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

# Import settings for secret name and region
from transcript_pipeline.verify.settings import SECRET_NAME, AWS_REGION


def mask_value(value: str, show_chars: int = 4) -> str:
    """Mask a sensitive value, showing only first and last N characters."""
    if not value or len(value) <= show_chars * 2:
        return "****"
    return f"{value[:show_chars]}...{value[-show_chars:]}"


def verify_secrets_manager() -> bool:
    """
    Verify AWS Secrets Manager access and validate required keys.
    
    Returns:
        bool: True if all verifications pass, False otherwise
    """
    print("\n" + "=" * 50)
    print("VERIFYING AWS SECRETS MANAGER")
    print("=" * 50)
    
    # Get configuration from settings
    aws_region = AWS_REGION
    secret_name = SECRET_NAME
    
    print(f"\nConfiguration:")
    print(f"  AWS Region: {aws_region}")
    print(f"  Secret Name: {secret_name}")
    
    # Required keys to validate
    required_keys = [
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID", 
        "AZURE_CERT_THUMBPRINT",
        "GRAPH_USER_ID",
        "AWS_REGION",
        "S3_BUCKET_NAME",
        "S3_PREFIX",
        "DYNAMODB_TABLE_NAME",
        "MAX_RETRY_ATTEMPTS",
        "MEETINGS_FETCH_LIMIT",
        "LOG_LEVEL"
    ]
    
    # Either AZURE_CERT_PATH or AZURE_CERT_CONTENT must exist
    cert_keys = ["AZURE_CERT_PATH", "AZURE_CERT_CONTENT"]
    
    all_passed = True
    
    try:
        # Step 1: Connect to Secrets Manager
        print("\n[1/3] Connecting to AWS Secrets Manager...")
        client = boto3.client("secretsmanager", region_name=aws_region)
        print("  ✅ Connected to Secrets Manager")
        
    except NoCredentialsError:
        print("  ❌ FAILED: No AWS credentials found")
        print("     Ensure AWS credentials are configured (environment, ~/.aws/credentials, or IAM role)")
        return False
    except Exception as e:
        print(f"  ❌ FAILED: Could not connect to Secrets Manager")
        print(f"     Error: {e}")
        return False
    
    try:
        # Step 2: Retrieve the secret
        print(f"\n[2/3] Retrieving secret '{secret_name}'...")
        response = client.get_secret_value(SecretId=secret_name)
        
        # Parse the secret value
        if "SecretString" in response:
            secret_data = json.loads(response["SecretString"])
        else:
            print("  ❌ FAILED: Secret is binary, expected JSON string")
            return False
            
        print(f"  ✅ Secret '{secret_name}' found")
        
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        if error_code == "ResourceNotFoundException":
            print(f"  ❌ FAILED: Secret '{secret_name}' not found")
        elif error_code == "AccessDeniedException":
            print(f"  ❌ FAILED: Access denied to secret '{secret_name}'")
            print("     Check IAM permissions for secretsmanager:GetSecretValue")
        else:
            print(f"  ❌ FAILED: {error_code} - {e}")
        return False
    except json.JSONDecodeError:
        print("  ❌ FAILED: Secret value is not valid JSON")
        return False
    
    # Step 3: Validate required keys
    print("\n[3/3] Validating required keys...")
    
    # Check required keys
    missing_keys = []
    for key in required_keys:
        if key in secret_data and secret_data[key]:
            masked = mask_value(str(secret_data[key]))
            print(f"  ✅ {key}: {masked}")
        else:
            print(f"  ❌ {key}: MISSING")
            missing_keys.append(key)
            all_passed = False
    
    # Check certificate keys (at least one required)
    cert_found = False
    for key in cert_keys:
        if key in secret_data and secret_data[key]:
            masked = mask_value(str(secret_data[key]))
            print(f"  ✅ {key}: {masked}")
            cert_found = True
            break
    
    if not cert_found:
        print(f"  ❌ Certificate: MISSING (need AZURE_CERT_PATH or AZURE_CERT_CONTENT)")
        all_passed = False
    
    # Summary
    print("\n" + "-" * 50)
    if all_passed:
        print("✅ All required keys present in Secrets Manager")
    else:
        print("❌ Some required keys are missing")
        if missing_keys:
            print(f"   Missing: {', '.join(missing_keys)}")
    
    return all_passed


def main():
    """Main entry point for verify_secrets script."""
    try:
        success = verify_secrets_manager()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\nVerification cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()