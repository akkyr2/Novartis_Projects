"""
Cleanup Chat S3 Files.

Deletes all chat DOCX files from S3.
Use this to reset the chat pipeline storage.

⚠️  WARNING: This is a destructive operation!

CLI (run from project root):
    python -m transcript_pipeline.verify.chat.cleanup_s3
"""

import sys
import os

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.verify.settings import get_config_value, AWS_REGION


def cleanup_chat_s3() -> bool:
    """
    Delete all chat files from S3 (preserves transcript files).
    
    Note: Chat files are in {base_prefix}/chats/
          Transcript files are in {base_prefix}/transcripts/
    This will only delete files in the /chats/ subfolder.
    
    Returns:
        bool: True if cleanup successful, False otherwise
    """
    print("\n" + "=" * 60)
    print("⚠️  CHAT S3 CLEANUP UTILITY")
    print("=" * 60)
    
    # Get configuration
    aws_region = AWS_REGION
    bucket_name = get_config_value("S3_BUCKET_NAME")
    base_prefix = get_config_value("S3_PREFIX").rstrip("/")
    
    # Chat files are in {base_prefix}/chats/
    chat_prefix = f"{base_prefix}/chats/"
    
    print(f"\nConfiguration:")
    print(f"  AWS Region: {aws_region}")
    print(f"  Bucket: {bucket_name}")
    print(f"  Base Prefix: {base_prefix}/")
    print(f"  Chat Prefix: {chat_prefix}")
    
    try:
        # Connect to S3
        s3_client = boto3.client("s3", region_name=aws_region)
        
    except NoCredentialsError:
        print("  ❌ FAILED: No AWS credentials found")
        return False
    except Exception as e:
        print(f"  ❌ FAILED: Could not connect to S3 - {e}")
        return False
    
    # List chat files
    print("\nFetching chat files...")
    
    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        
        chat_files = []
        
        for page in paginator.paginate(Bucket=bucket_name, Prefix=chat_prefix):
            for obj in page.get("Contents", []):
                key = obj.get("Key", "")
                size = obj.get("Size", 0)
                
                # Only include DOCX files
                if key.lower().endswith(".docx"):
                    chat_files.append({"key": key, "size": size})
        
        if not chat_files:
            print("  ℹ️  No chat files found. Nothing to delete.")
            return True
        
        # Calculate total size
        total_size = sum(f["size"] for f in chat_files)
        
        print(f"\n  Found {len(chat_files)} chat file(s)")
        print(f"  Total size: {total_size / (1024 * 1024):.2f} MB")
        
        # Show sample files
        print(f"\n  Sample files to be deleted:")
        for f in chat_files[:10]:
            print(f"    • {f['key']}")
        if len(chat_files) > 10:
            print(f"    ... and {len(chat_files) - 10} more files")
        
    except ClientError as e:
        print(f"  ❌ Error listing files: {e}")
        return False
    
    # Confirmation
    print("\n" + "=" * 60)
    print(f"⚠️  This will DELETE {len(chat_files)} chat file(s)!")
    print("    Transcript files will NOT be affected.")
    print("=" * 60)
    
    confirm = input("\nType 'DELETE CHATS' to confirm: ")
    
    if confirm != "DELETE CHATS":
        print("\n❌ Cancelled. No files were deleted.")
        return False
    
    # Delete files
    print("\n🗑️  Deleting chat files...")
    
    success_count = 0
    failure_count = 0
    
    for idx, file_info in enumerate(chat_files, 1):
        key = file_info["key"]
        
        try:
            s3_client.delete_object(Bucket=bucket_name, Key=key)
            success_count += 1
            
            # Progress indicator
            if idx % 10 == 0 or idx == len(chat_files):
                print(f"     Deleted {idx}/{len(chat_files)} files...")
                
        except ClientError as e:
            print(f"  ❌ Failed to delete {key}: {e}")
            failure_count += 1
    
    # Summary
    print("\n" + "=" * 60)
    print("CLEANUP SUMMARY")
    print("=" * 60)
    print(f"  ✅ Successfully deleted: {success_count}")
    print(f"  ❌ Failed to delete: {failure_count}")
    
    if failure_count == 0:
        print("\n✅ CHAT S3 CLEANUP COMPLETED SUCCESSFULLY")
    else:
        print("\n⚠️  CLEANUP COMPLETED WITH SOME FAILURES")
    
    print("=" * 60)
    
    return failure_count == 0


def main():
    """Main entry point."""
    success = cleanup_chat_s3()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
