"""
Verify Chat S3 Storage.

Checks that the S3 bucket for chat files is accessible and shows current statistics.

CLI (run from project root):
    python -m transcript_pipeline.verify.chat.verify_s3
"""

import sys
import os
from datetime import datetime, timezone

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.verify.settings import get_config_value, AWS_REGION


def verify_chat_s3() -> bool:
    """
    Verify chat S3 storage connectivity and CRUD operations.
    
    Tests:
    - Connect to S3
    - Check bucket accessibility
    - Upload test file
    - Read test file back
    - List files in folder
    - Delete test file
    - Show storage statistics
    
    Returns:
        bool: True if all verifications pass, False otherwise
    """
    print("\n" + "=" * 60)
    print("VERIFYING CHAT S3 STORAGE")
    print("=" * 60)
    
    # Get configuration
    aws_region = AWS_REGION
    bucket_name = get_config_value("S3_BUCKET_NAME")
    base_prefix = get_config_value("S3_PREFIX").rstrip("/")
    
    # Chat files are stored in {base_prefix}/chats/
    chat_prefix = f"{base_prefix}/chats/"
    
    # Test file details
    test_filename = "_verify_test_chat.txt"
    test_key = f"{chat_prefix}_verify/{test_filename}"
    test_content = f"Chat S3 verification test file - {datetime.now(timezone.utc).isoformat()}"
    verify_prefix = f"{chat_prefix}_verify/"
    
    print(f"\nConfiguration:")
    print(f"  AWS Region: {aws_region}")
    print(f"  Bucket: {bucket_name}")
    print(f"  Base Prefix: {base_prefix}/")
    print(f"  Chat Prefix: {chat_prefix}")
    
    all_passed = True
    
    # Step 1: Connect to S3
    try:
        print("\n[1/7] Connecting to S3...")
        s3_client = boto3.client("s3", region_name=aws_region)
        print("  ✅ Connected to S3")
        
    except NoCredentialsError:
        print("  ❌ FAILED: No AWS credentials found")
        return False
    except Exception as e:
        print(f"  ❌ FAILED: Could not connect to S3 - {e}")
        return False
    
    # Step 2: Check bucket exists and is accessible
    print(f"\n[2/7] Checking bucket '{bucket_name}' accessibility...")
    try:
        s3_client.head_bucket(Bucket=bucket_name)
        print(f"  ✅ Bucket '{bucket_name}' accessible")
        
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        if error_code == "404":
            print(f"  ❌ FAILED: Bucket '{bucket_name}' does not exist")
        elif error_code == "403":
            print(f"  ❌ FAILED: Access denied to bucket '{bucket_name}'")
            print("     Check IAM permissions for s3:ListBucket, s3:GetObject, s3:PutObject")
        else:
            print(f"  ❌ FAILED: {error_code} - {e}")
        return False
    
    # Step 3: Upload test file
    print(f"\n[3/7] Uploading test file '{test_filename}'...")
    try:
        s3_client.put_object(
            Bucket=bucket_name,
            Key=test_key,
            Body=test_content.encode("utf-8"),
            ContentType="text/plain"
        )
        print(f"  ✅ Upload test file: SUCCESS")
        print(f"     S3 URI: s3://{bucket_name}/{test_key}")
        
    except ClientError as e:
        print(f"  ❌ Upload test file: FAILED - {e}")
        all_passed = False
        # Can't continue without upload
        return False
    
    # Step 4: Read file back and verify content
    print(f"\n[4/7] Reading test file back...")
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=test_key)
        retrieved_content = response["Body"].read().decode("utf-8")
        
        if retrieved_content == test_content:
            print(f"  ✅ Read test file: SUCCESS")
            print(f"     Content matches original ✓")
        else:
            print(f"  ❌ Read test file: FAILED - Content mismatch")
            all_passed = False
            
    except ClientError as e:
        print(f"  ❌ Read test file: FAILED - {e}")
        all_passed = False
    
    # Step 5: List files in verify folder
    print(f"\n[5/7] Listing files in verify folder...")
    try:
        response = s3_client.list_objects_v2(
            Bucket=bucket_name,
            Prefix=verify_prefix,
            MaxKeys=10
        )
        
        files = response.get("Contents", [])
        print(f"  ✅ List files: SUCCESS")
        print(f"     Found {len(files)} file(s) in verify folder:")
        
        for file in files:
            key = file["Key"]
            size = file["Size"]
            filename = key.split("/")[-1]
            print(f"       - {filename} ({size} bytes)")
            
    except ClientError as e:
        print(f"  ❌ List files: FAILED - {e}")
        all_passed = False
    
    # Step 6: Delete test file
    print(f"\n[6/7] Deleting test file...")
    try:
        s3_client.delete_object(Bucket=bucket_name, Key=test_key)
        
        # Verify deletion by trying to get the object
        try:
            s3_client.head_object(Bucket=bucket_name, Key=test_key)
            print(f"  ❌ Delete test file: FAILED - File still exists")
            all_passed = False
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                print(f"  ✅ Delete test file: SUCCESS")
            else:
                raise
                
    except ClientError as e:
        print(f"  ❌ Delete test file: FAILED - {e}")
        all_passed = False
    
    # Step 7: List chat files and calculate stats
    print(f"\n[7/7] Fetching chat storage statistics...")
    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        
        total_files = 0
        docx_files = 0
        total_size = 0
        recent_files = []
        
        for page in paginator.paginate(Bucket=bucket_name, Prefix=chat_prefix):
            for obj in page.get("Contents", []):
                key = obj.get("Key", "")
                size = obj.get("Size", 0)
                
                # Skip verify folder files
                if "/_verify/" in key:
                    continue
                
                total_files += 1
                total_size += size
                
                if key.lower().endswith(".docx"):
                    docx_files += 1
                    if len(recent_files) < 5:
                        recent_files.append({"key": key, "size": size})
        
        print(f"\n📦 Chat S3 Storage Statistics:")
        print(f"   Total files: {total_files}")
        print(f"   DOCX files:  {docx_files}")
        print(f"   Total size:  {total_size / (1024 * 1024):.2f} MB")
        
        if recent_files:
            print(f"\n📄 Sample chat files:")
            for f in recent_files:
                print(f"   • {f['key']}")
                print(f"     Size: {f['size']} bytes")
        else:
            print(f"\n📄 No chat files found in S3 yet")
        
    except ClientError as e:
        print(f"  ❌ Error listing files: {e}")
        all_passed = False
    
    # Summary
    print("\n" + "-" * 60)
    if all_passed:
        print("✅ All Chat S3 operations completed successfully")
    else:
        print("❌ Some Chat S3 operations failed")
    
    return all_passed


def main():
    """Main entry point."""
    try:
        success = verify_chat_s3()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\nVerification cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
