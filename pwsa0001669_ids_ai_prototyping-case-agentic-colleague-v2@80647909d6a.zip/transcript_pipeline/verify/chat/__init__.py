"""
Chat Pipeline Verification Scripts.

This package contains verification and cleanup utilities for the chat pipeline:
- verify_dynamodb.py - Verify chat DynamoDB tracker
- verify_s3.py - Verify chat S3 storage
- cleanup_dynamodb.py - Clean up chat DynamoDB records
- cleanup_s3.py - Clean up chat S3 files
- download_files.py - Download chat files from S3
- verify_all.py - Run all chat verifications

Usage (run from project root):
    # Run all chat verifications
    python -m transcript_pipeline.verify.chat.verify_all
    
    # Individual verifications
    python -m transcript_pipeline.verify.chat.verify_dynamodb
    python -m transcript_pipeline.verify.chat.verify_s3
    
    # Cleanup utilities
    python -m transcript_pipeline.verify.chat.cleanup_dynamodb
    python -m transcript_pipeline.verify.chat.cleanup_s3
    
    # Download files
    python -m transcript_pipeline.verify.chat.download_files
"""

# Note: We intentionally do NOT import submodules here to avoid circular imports
# and dependency issues. Import directly from the specific module you need:
#   from transcript_pipeline.verify.chat.verify_dynamodb import verify_chat_dynamodb
#   from transcript_pipeline.verify.chat.verify_s3 import verify_chat_s3

__all__ = [
    "verify_chat_dynamodb",
    "verify_chat_s3",
    "cleanup_chat_dynamodb",
    "cleanup_chat_s3",
    "download_chat_files",
    "verify_all_chat",
]
