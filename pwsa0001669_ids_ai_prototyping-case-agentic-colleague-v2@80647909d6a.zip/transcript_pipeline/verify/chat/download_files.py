"""
Download Chat DOCX files from S3.

Downloads all chat DOCX files from S3 to a local folder and shows a preview.

CLI (run from project root):
    python -m transcript_pipeline.verify.chat.download_files
"""

import os
import sys
from io import BytesIO

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.verify.settings import get_config_value, AWS_REGION

# Try to import python-docx for reading DOCX content
try:
    from docx import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False
    print("⚠️  python-docx not installed. Content preview will be limited.")


def extract_docx_text(docx_bytes: bytes) -> str:
    """Extract text content from DOCX bytes."""
    if not DOCX_AVAILABLE:
        return "[python-docx not installed - cannot read content]"
    
    try:
        doc = Document(BytesIO(docx_bytes))
        paragraphs = []
        for para in doc.paragraphs:
            if para.text.strip():
                paragraphs.append(para.text)
        return '\n'.join(paragraphs)
    except Exception as e:
        return f"[Error reading DOCX: {e}]"


def download_chat_files() -> bool:
    """
    Download chat files from S3 and show preview.
    
    Note: Downloads files from {base_prefix}/chats/ subfolder only.
    
    Returns:
        bool: True if download successful, False otherwise
    """
    print("\n" + "=" * 60)
    print("DOWNLOAD CHAT FILES FROM S3")
    print("=" * 60)
    
    # Get configuration
    aws_region = AWS_REGION
    bucket_name = get_config_value("S3_BUCKET_NAME")
    base_prefix = get_config_value("S3_PREFIX").rstrip("/")
    
    # Chat files are in {base_prefix}/chats/
    chat_prefix = f"{base_prefix}/chats/"
    
    print(f"\nConfiguration:")
    print(f"  AWS Region: {aws_region}")
    print(f"  Bucket: {bucket_name}")
    print(f"  Base Prefix: {base_prefix}/")
    print(f"  Chat Prefix: {chat_prefix}")
    
    try:
        # Connect to S3
        s3_client = boto3.client("s3", region_name=aws_region)
        
    except NoCredentialsError:
        print("  ❌ FAILED: No AWS credentials found")
        return False
    except Exception as e:
        print(f"  ❌ FAILED: Could not connect to S3 - {e}")
        return False
    
    # Create download folder
    download_folder = os.path.join(os.path.dirname(__file__), "downloaded_chats")
    os.makedirs(download_folder, exist_ok=True)
    
    # List chat files
    print("\nFetching chat files...")
    
    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        
        chat_files = []
        
        for page in paginator.paginate(Bucket=bucket_name, Prefix=chat_prefix):
            for obj in page.get("Contents", []):
                key = obj.get("Key", "")
                size = obj.get("Size", 0)
                
                # Only include DOCX files
                if key.lower().endswith(".docx"):
                    chat_files.append({"key": key, "size": size})
        
        print(f"  Found {len(chat_files)} chat DOCX file(s)")
        
        if not chat_files:
            print("\n⚠️  No chat files found to download.")
            return True
        
    except ClientError as e:
        print(f"  ❌ Error listing files: {e}")
        return False
    
    # Download files (limit to first 10)
    max_download = min(len(chat_files), 10)
    print(f"\nDownloading {max_download} file(s)...")
    
    for i, file_info in enumerate(chat_files[:max_download], 1):
        s3_key = file_info["key"]
        filename = os.path.basename(s3_key)
        local_path = os.path.join(download_folder, filename)
        
        print(f"\n[{i}/{max_download}] Downloading: {filename}")
        
        try:
            # Download
            response = s3_client.get_object(Bucket=bucket_name, Key=s3_key)
            docx_bytes = response["Body"].read()
            
            # Save to local file
            with open(local_path, "wb") as f:
                f.write(docx_bytes)
            
            print(f"  ✅ Saved to: {local_path}")
            
            # Preview content
            content = extract_docx_text(docx_bytes)
            preview = content[:500] if len(content) > 500 else content
            
            print(f"\n  📄 Content Preview (first 500 chars):")
            print("  " + "-" * 50)
            for line in preview.split("\n")[:15]:
                print(f"  {line[:80]}")
            if len(content) > 500:
                print(f"  ... [{len(content) - 500} more characters]")
            print("  " + "-" * 50)
            
        except ClientError as e:
            print(f"  ❌ Failed to download: {e}")
        except Exception as e:
            print(f"  ⚠️  Downloaded but could not preview: {e}")
    
    if len(chat_files) > max_download:
        print(f"\n⚠️  Only downloaded first {max_download} files. {len(chat_files) - max_download} more available.")
    
    print(f"\n📁 All downloaded files saved to: {download_folder}")
    
    print("\n" + "=" * 60)
    print("✅ CHAT DOWNLOAD COMPLETE")
    print("=" * 60)
    return True


def main():
    """Main entry point."""
    success = download_chat_files()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
