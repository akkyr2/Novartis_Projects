"""
Cleanup Chat DynamoDB Table.

Deletes all CHAT records from DynamoDB (preserves transcript records).
Use this to reset the chat pipeline state.

⚠️  WARNING: This is a destructive operation!

CLI (run from project root):
    python -m transcript_pipeline.verify.chat.cleanup_dynamodb
"""

import sys
import os

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_VERIFY_DIR = os.path.dirname(_SCRIPT_DIR)
_PIPELINE_DIR = os.path.dirname(_VERIFY_DIR)
_PROJECT_ROOT = os.path.dirname(_PIPELINE_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.verify.settings import get_config_value, AWS_REGION


def get_chat_records(dynamodb_client, table_name: str) -> list:
    """
    Fetch all CHAT records from DynamoDB table.
    
    Args:
        dynamodb_client: boto3 DynamoDB client
        table_name: Name of the table
        
    Returns:
        List of chat record items
    """
    all_items = []
    
    try:
        paginator = dynamodb_client.get_paginator('scan')
        
        for page in paginator.paginate(
            TableName=table_name,
            FilterExpression="record_type IN (:chat, :chat_metadata)",
            ExpressionAttributeValues={
                ":chat": {"S": "CHAT"},
                ":chat_metadata": {"S": "CHAT_METADATA"},
            }
        ):
            items = page.get('Items', [])
            all_items.extend(items)
        
        return all_items
        
    except ClientError as e:
        print(f"  ❌ Error scanning table: {e}")
        return []


def cleanup_chat_dynamodb() -> bool:
    """
    Delete all chat records from DynamoDB (preserves transcript records).
    
    Returns:
        bool: True if cleanup successful, False otherwise
    """
    print("\n" + "=" * 60)
    print("⚠️  CHAT DYNAMODB CLEANUP UTILITY")
    print("=" * 60)
    
    # Get configuration
    aws_region = AWS_REGION
    table_name = get_config_value("DYNAMODB_TABLE_NAME", "AgenticColleague_MeetingTracker")
    
    print(f"\nConfiguration:")
    print(f"  AWS Region: {aws_region}")
    print(f"  Table Name: {table_name}")
    print(f"  Record Types to Delete: CHAT, CHAT_METADATA")
    
    try:
        # Connect to DynamoDB
        dynamodb_client = boto3.client("dynamodb", region_name=aws_region)
        
    except NoCredentialsError:
        print("  ❌ FAILED: No AWS credentials found")
        return False
    except Exception as e:
        print(f"  ❌ FAILED: Could not connect to DynamoDB - {e}")
        return False
    
    # Check if table exists
    try:
        response = dynamodb_client.describe_table(TableName=table_name)
        print(f"  ✅ Table exists")
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print(f"  ❌ Table '{table_name}' does not exist")
        else:
            print(f"  ❌ Error: {e}")
        return False
    
    # Fetch chat records
    print("\nFetching CHAT records...")
    items = get_chat_records(dynamodb_client, table_name)
    
    if not items:
        print("  ℹ️  No CHAT records found. Nothing to delete.")
        return True
    
    # Display records
    print(f"\n  Found {len(items)} CHAT record(s):\n")
    
    # Summary by status
    status_counts = {}
    for item in items:
        status = item.get('status', {}).get('S', 'UNKNOWN')
        status_counts[status] = status_counts.get(status, 0) + 1
    
    print("  📊 Summary by Status:")
    for status, count in sorted(status_counts.items()):
        print(f"     {status}: {count}")
    
    # Confirmation
    print("\n" + "=" * 60)
    print(f"⚠️  This will DELETE {len(items)} CHAT record(s)!")
    print("    Transcript records will NOT be affected.")
    print("=" * 60)
    
    confirm = input("\nType 'DELETE CHATS' to confirm: ")
    
    if confirm != "DELETE CHATS":
        print("\n❌ Cancelled. No records were deleted.")
        return False
    
    # Delete records
    print("\n🗑️  Deleting chat records...")
    
    success_count = 0
    failure_count = 0
    
    for idx, item in enumerate(items, 1):
        record_id = item.get('record_id', {}).get('S')
        
        if not record_id:
            failure_count += 1
            continue
        
        try:
            dynamodb_client.delete_item(
                TableName=table_name,
                Key={'record_id': {'S': record_id}}
            )
            success_count += 1
            
            # Progress indicator
            if idx % 10 == 0 or idx == len(items):
                print(f"     Deleted {idx}/{len(items)} records...")
                
        except ClientError as e:
            print(f"  ❌ Failed to delete {record_id[:30]}...: {e}")
            failure_count += 1
    
    # Summary
    print("\n" + "=" * 60)
    print("CLEANUP SUMMARY")
    print("=" * 60)
    print(f"  ✅ Successfully deleted: {success_count}")
    print(f"  ❌ Failed to delete: {failure_count}")
    
    if failure_count == 0:
        print("\n✅ CHAT DYNAMODB CLEANUP COMPLETED SUCCESSFULLY")
    else:
        print("\n⚠️  CLEANUP COMPLETED WITH SOME FAILURES")
    
    print("=" * 60)
    
    return failure_count == 0


def main():
    """Main entry point."""
    success = cleanup_chat_dynamodb()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
