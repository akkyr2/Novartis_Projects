"""
Main Pipeline Orchestrator for the Transcript Pipeline.

This is the main entry point that coordinates:
1. Connecting to AWS Secrets Manager for Graph API configuration
2. Authenticating with Microsoft Graph API
3. Fetching all online meetings with transcripts
4. Checking DynamoDB for processing status
5. Processing only new or failed transcripts
6. Converting VTT to DOCX and uploading to S3
7. Updating DynamoDB with completion status

CLI (run from project root):
    # Run full pipeline
    python -m transcript_pipeline.main run
    
    # Retry failed transcripts only
    python -m transcript_pipeline.main retry
    
    # Show processing statistics
    python -m transcript_pipeline.main status
    
    # Verify configuration
    python -m transcript_pipeline.main verify
"""

import argparse
import sys
import os
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional, Tuple

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

from transcript_pipeline.config import (
    Config,
    ConfigurationError,
    GraphAPIError,
    DynamoDBError,
    S3StorageError,
    TranscriptProcessingError,
    get_logger,
)
from transcript_pipeline.graph_client import GraphClient, MeetingInfo, TranscriptInfo
from transcript_pipeline.dynamodb_tracker import DynamoDBTracker, TranscriptStatus, TranscriptRecord
from transcript_pipeline.s3_storage import S3Storage


# =============================================================================
# PIPELINE RESULT DATA CLASS
# =============================================================================

@dataclass
class PipelineResult:
    """Result of a pipeline run."""
    
    total_meetings: int = 0
    total_transcripts: int = 0
    processed: int = 0
    skipped: int = 0
    failed: int = 0
    errors: List[str] = None
    duration_seconds: float = 0.0
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate percentage."""
        total = self.processed + self.failed
        if total == 0:
            return 100.0
        return round((self.processed / total) * 100, 1)
    
    def print_summary(self):
        """Print result summary."""
        print("\n" + "=" * 60)
        print("PIPELINE RUN SUMMARY")
        print("=" * 60)
        print(f"  ⏱️  Duration:        {self.duration_seconds:.1f} seconds")
        print(f"  📅 Meetings found:   {self.total_meetings}")
        print(f"  📝 Transcripts:      {self.total_transcripts}")
        print(f"  ✅ Processed:        {self.processed}")
        print(f"  ⏭️  Skipped:          {self.skipped}")
        print(f"  ❌ Failed:           {self.failed}")
        print(f"  📊 Success rate:     {self.success_rate}%")
        
        if self.errors:
            print("\n  Errors:")
            for error in self.errors[:5]:  # Show max 5 errors
                print(f"    • {error[:80]}...")
            if len(self.errors) > 5:
                print(f"    ... and {len(self.errors) - 5} more")
        
        print("=" * 60)


# =============================================================================
# TRANSCRIPT PIPELINE CLASS
# =============================================================================

class TranscriptPipeline:
    """
    Main pipeline orchestrator for transcript extraction.
    
    Coordinates all components to:
    1. Discover meetings with transcripts
    2. Filter based on processing status
    3. Download, convert, and store transcripts
    4. Track processing in DynamoDB
    """
    
    def __init__(self, config: Config = None):
        """
        Initialize the pipeline.
        
        Args:
            config: Optional Config instance (creates new one if not provided)
        """
        self.config = config or Config()
        self.logger = self.config.logger
        
        # Components will be initialized lazily
        self._graph_client: Optional[GraphClient] = None
        self._tracker: Optional[DynamoDBTracker] = None
        self._storage: Optional[S3Storage] = None
    
    # -------------------------------------------------------------------------
    # COMPONENT INITIALIZATION (Lazy Loading)
    # -------------------------------------------------------------------------
    
    @property
    def graph_client(self) -> GraphClient:
        """Get or create Graph API client."""
        if self._graph_client is None:
            self.logger.info("Initializing Graph API client...")
            self._graph_client = GraphClient(self.config)
        return self._graph_client
    
    @property
    def tracker(self) -> DynamoDBTracker:
        """Get or create DynamoDB tracker."""
        if self._tracker is None:
            self.logger.info("Initializing DynamoDB tracker...")
            self._tracker = DynamoDBTracker(self.config)
        return self._tracker
    
    @property
    def storage(self) -> S3Storage:
        """Get or create S3 storage."""
        if self._storage is None:
            self.logger.info("Initializing S3 storage...")
            self._storage = S3Storage(self.config)
        return self._storage
    
    # -------------------------------------------------------------------------
    # TRANSCRIPT PROCESSING
    # -------------------------------------------------------------------------
    
    def _process_single_transcript(
        self,
        meeting: MeetingInfo,
        transcript: TranscriptInfo,
        max_retries: int = 3,
    ) -> bool:
        """
        Process a single transcript.
        
        Args:
            meeting: Meeting information
            transcript: Transcript information
            max_retries: Maximum number of retries for transient failures
            
        Returns:
            True if successful, False if failed
        """
        transcript_id = transcript.transcript_id
        
        try:
            # Step 1: Mark as processing in DynamoDB
            self.tracker.mark_processing(
                transcript_id=transcript_id,
                meeting_id=meeting.meeting_id,
                meeting_subject=meeting.subject,
                join_url=meeting.join_url,
            )
            
            # Step 2: Download transcript content (with built-in retry logic)
            self.logger.info(f"  📥 Downloading transcript content...")
            try:
                content = self.graph_client.download_transcript_content(
                    meeting_id=meeting.meeting_id,
                    transcript_id=transcript_id,
                    max_retries=max_retries,
                )
            except Exception as download_error:
                # Check if this is a "not found" error - transcript may have been deleted
                error_str = str(download_error).lower()
                if "404" in error_str or "not found" in error_str:
                    self.logger.warning(
                        f"  ⚠️  Transcript no longer available (may have been deleted): {transcript_id[:30]}..."
                    )
                    # Mark as permanently failed - don't retry
                    self.tracker.mark_failed(
                        transcript_id=transcript_id,
                        error_message="Transcript not found (404) - may have been deleted",
                        increment_retry=False,  # Don't count this for retry
                    )
                    return False
                raise
            
            if not content or len(content.strip()) < 10:
                raise TranscriptProcessingError("Empty or invalid transcript content")
            
            # Step 3: Upload to S3 (converts VTT to DOCX internally)
            self.logger.info(f"  📤 Uploading to S3...")
            s3_path = self.storage.upload_transcript(
                transcript_content=content,
                transcript_id=transcript_id,
                meeting_subject=meeting.subject,
                meeting_date=meeting.start_datetime,
                meeting_id=meeting.meeting_id,
            )
            
            # Step 4: Mark as completed in DynamoDB
            self.tracker.mark_completed(
                transcript_id=transcript_id,
                s3_path=s3_path,
            )
            
            return True
            
        except Exception as e:
            # Mark as failed in DynamoDB
            error_msg = str(e)[:500]
            self.logger.error(f"  ❌ Error processing transcript: {error_msg}")
            
            try:
                self.tracker.mark_failed(
                    transcript_id=transcript_id,
                    error_message=error_msg,
                )
            except Exception as db_error:
                self.logger.error(f"  ❌ Error updating DynamoDB: {db_error}")
            
            return False
    
    # -------------------------------------------------------------------------
    # MAIN PIPELINE OPERATIONS
    # -------------------------------------------------------------------------
    
    def run(self, limit: int = None, retry_failed: bool = False) -> PipelineResult:
        """
        Run the main pipeline.
        
        Args:
            limit: Maximum number of meetings to process (default from config)
            retry_failed: Also process failed transcripts that can be retried
            
        Returns:
            PipelineResult with statistics
        """
        start_time = time.time()
        result = PipelineResult()
        
        self.logger.info("=" * 60)
        self.logger.info("STARTING TRANSCRIPT PIPELINE")
        self.logger.info("=" * 60)
        
        try:
            # Step 1: Validate configuration
            self.logger.info("\n[1/4] Validating configuration...")
            self.config.validate()
            self.logger.info("  ✅ Configuration valid")
            
            # Step 2: Fetch meetings with transcripts
            self.logger.info("\n[2/4] Fetching meetings with transcripts...")
            meetings = self.graph_client.get_online_meetings_with_transcripts(
                limit=limit or self.config.meetings_fetch_limit,
                completed_only=True,
            )
            
            result.total_meetings = len(meetings)
            result.total_transcripts = sum(len(m.transcripts) for m in meetings)
            
            if not meetings:
                self.logger.info("  ℹ️  No meetings with transcripts found")
                result.duration_seconds = time.time() - start_time
                return result
            
            # Step 3: Process each transcript
            self.logger.info(f"\n[3/4] Processing {result.total_transcripts} transcript(s)...")
            
            for meeting in meetings:
                self.logger.info(f"\n📅 Meeting: {meeting.subject}")
                self.logger.info(f"   Date: {meeting.start_datetime or 'Unknown'}")
                
                for transcript in meeting.transcripts:
                    transcript_id = transcript.transcript_id
                    
                    # Check if should process
                    if not self.tracker.should_process(transcript_id):
                        self.logger.info(f"  ⏭️  Skipping (already processed): {transcript_id[:30]}...")
                        result.skipped += 1
                        continue
                    
                    # Check if this is a retry
                    existing = self.tracker.get_record(transcript_id)
                    if existing and existing.status == TranscriptStatus.FAILED:
                        if not retry_failed:
                            self.logger.info(f"  ⏭️  Skipping (failed, use --retry): {transcript_id[:30]}...")
                            result.skipped += 1
                            continue
                        self.logger.info(f"  🔄 Retrying failed transcript...")
                    
                    # Process the transcript
                    success = self._process_single_transcript(meeting, transcript)
                    
                    if success:
                        result.processed += 1
                    else:
                        result.failed += 1
                        result.errors.append(
                            f"{meeting.subject}: {transcript_id[:30]}..."
                        )
            
            # Step 4: Complete
            self.logger.info("\n[4/4] Pipeline complete!")
            
        except ConfigurationError as e:
            self.logger.error(f"Configuration error: {e}")
            result.errors.append(f"Configuration: {e}")
        except GraphAPIError as e:
            self.logger.error(f"Graph API error: {e}")
            result.errors.append(f"Graph API: {e}")
        except DynamoDBError as e:
            self.logger.error(f"DynamoDB error: {e}")
            result.errors.append(f"DynamoDB: {e}")
        except S3StorageError as e:
            self.logger.error(f"S3 error: {e}")
            result.errors.append(f"S3: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}")
            result.errors.append(f"Unexpected: {e}")
        
        result.duration_seconds = time.time() - start_time
        return result
    
    def retry_failed(self) -> PipelineResult:
        """
        Retry only failed transcripts.
        
        Returns:
            PipelineResult with statistics
        """
        start_time = time.time()
        result = PipelineResult()
        
        self.logger.info("=" * 60)
        self.logger.info("RETRYING FAILED TRANSCRIPTS")
        self.logger.info("=" * 60)
        
        try:
            # Get failed records that can be retried
            failed_records = self.tracker.get_failed_for_retry()
            
            if not failed_records:
                self.logger.info("  ℹ️  No failed transcripts to retry")
                result.duration_seconds = time.time() - start_time
                return result
            
            self.logger.info(f"  Found {len(failed_records)} transcript(s) to retry")
            result.total_transcripts = len(failed_records)
            
            for record in failed_records:
                self.logger.info(f"\n🔄 Retrying: {record.meeting_subject[:50]}...")
                
                # Need to fetch the meeting info again
                try:
                    meeting_id = self.graph_client.get_meeting_id_by_join_url(record.join_url)
                    
                    if not meeting_id:
                        self.logger.warning(f"  ⚠️  Could not resolve meeting ID")
                        result.skipped += 1
                        continue
                    
                    # Create meeting and transcript info objects
                    meeting = MeetingInfo(
                        meeting_id=meeting_id,
                        subject=record.meeting_subject,
                        join_url=record.join_url,
                    )
                    
                    transcript = TranscriptInfo(
                        transcript_id=record.transcript_id,
                        meeting_id=meeting_id,
                    )
                    
                    # Process
                    success = self._process_single_transcript(meeting, transcript)
                    
                    if success:
                        result.processed += 1
                    else:
                        result.failed += 1
                        result.errors.append(record.meeting_subject[:50])
                        
                except Exception as e:
                    self.logger.error(f"  ❌ Error: {e}")
                    result.failed += 1
                    result.errors.append(f"{record.meeting_subject}: {e}")
            
        except Exception as e:
            self.logger.error(f"Error during retry: {e}")
            result.errors.append(str(e))
        
        result.duration_seconds = time.time() - start_time
        return result
    
    def show_status(self):
        """Show current processing statistics."""
        print("\n" + "=" * 60)
        print("TRANSCRIPT PIPELINE STATUS")
        print("=" * 60)
        
        # Configuration summary
        print("\n📌 Configuration:")
        print(f"   AWS Region: {self.config.aws_region}")
        print(f"   S3 Bucket: {self.config.s3_bucket_name}")
        print(f"   S3 Prefix: {self.config.s3_prefix}")
        print(f"   DynamoDB Table: {self.config.dynamodb_table_name}")
        
        # DynamoDB stats
        self.tracker.print_stats()
        
        # S3 stats
        storage_stats = self.storage.get_storage_stats()
        print("\n📦 S3 Storage:")
        print(f"   Total files: {storage_stats['total_files']}")
        print(f"   DOCX files: {storage_stats['docx_files']}")
        print(f"   Total size: {storage_stats['total_size_mb']} MB")
        
        print("\n" + "=" * 60)
    
    def verify(self) -> bool:
        """
        Verify all components are accessible.
        
        Returns:
            True if all verifications pass
        """
        print("\n" + "=" * 60)
        print("VERIFYING PIPELINE COMPONENTS")
        print("=" * 60)
        
        all_passed = True
        
        # 1. Configuration
        print("\n[1/4] Configuration...")
        try:
            self.config.validate()
            print("  ✅ Configuration valid")
        except Exception as e:
            print(f"  ❌ Configuration error: {e}")
            all_passed = False
        
        # 2. Graph API
        print("\n[2/4] Graph API connection...")
        try:
            _ = self.graph_client  # Triggers authentication
            print("  ✅ Graph API authenticated")
        except Exception as e:
            print(f"  ❌ Graph API error: {e}")
            all_passed = False
        
        # 3. DynamoDB
        print("\n[3/4] DynamoDB connection...")
        try:
            stats = self.tracker.get_processing_stats()
            print(f"  ✅ DynamoDB accessible (Table: {self.config.dynamodb_table_name})")
            print(f"     Total records: {stats['TOTAL']}")
        except Exception as e:
            print(f"  ❌ DynamoDB error: {e}")
            all_passed = False
        
        # 4. S3
        print("\n[4/4] S3 connection...")
        try:
            stats = self.storage.get_storage_stats()
            print(f"  ✅ S3 accessible (Bucket: {self.config.s3_bucket_name})")
            print(f"     Files in prefix: {stats['total_files']}")
        except Exception as e:
            print(f"  ❌ S3 error: {e}")
            all_passed = False
        
        print("\n" + "=" * 60)
        if all_passed:
            print("✅ ALL VERIFICATIONS PASSED")
        else:
            print("❌ SOME VERIFICATIONS FAILED")
        print("=" * 60)
        
        return all_passed


# =============================================================================
# CLI INTERFACE
# =============================================================================

def create_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="transcript_pipeline",
        description="Teams Meeting Transcript Pipeline - Extract, convert, and store transcripts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m main run              # Run full pipeline
  python -m main run --limit 10   # Process max 10 meetings
  python -m main run --retry      # Include failed transcripts
  python -m main retry            # Retry only failed transcripts
  python -m main status           # Show processing statistics
  python -m main verify           # Verify all components
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run the transcript pipeline")
    run_parser.add_argument(
        "--limit", "-l",
        type=int,
        help="Maximum number of meetings to process"
    )
    run_parser.add_argument(
        "--retry", "-r",
        action="store_true",
        help="Also retry failed transcripts"
    )
    
    # Retry command
    subparsers.add_parser("retry", help="Retry failed transcripts only")
    
    # Status command
    subparsers.add_parser("status", help="Show processing statistics")
    
    # Verify command
    subparsers.add_parser("verify", help="Verify all components are accessible")
    
    return parser


def main():
    """Main CLI entry point."""
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        pipeline = TranscriptPipeline()
        
        if args.command == "run":
            result = pipeline.run(
                limit=args.limit,
                retry_failed=args.retry,
            )
            result.print_summary()
            
            # Exit with error code if any failures
            if result.failed > 0:
                sys.exit(1)
                
        elif args.command == "retry":
            result = pipeline.retry_failed()
            result.print_summary()
            
            if result.failed > 0:
                sys.exit(1)
                
        elif args.command == "status":
            pipeline.show_status()
            
        elif args.command == "verify":
            success = pipeline.verify()
            sys.exit(0 if success else 1)
            
    except KeyboardInterrupt:
        print("\n\n⚠️  Pipeline interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
