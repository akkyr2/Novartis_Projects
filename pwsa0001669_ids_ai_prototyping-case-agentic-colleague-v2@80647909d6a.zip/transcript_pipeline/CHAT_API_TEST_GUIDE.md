# Meeting Chat Pipeline API - Test Guide

This document provides test data and examples for testing all meeting chat pipeline API endpoints via Swagger UI.

**Base URL:** `http://localhost:7007`  
**Swagger UI:** `http://localhost:7007/docs`

---

## Table of Contents

1. [GET /chat/config](#1-get-chatconfig)
2. [GET /chat/status](#2-get-chatstatus)
3. [GET /chat/verify](#3-get-chatverify)
4. [POST /chat/run](#4-post-chatrun)
5. [POST /chat/run-full](#5-post-chatrun-full)
6. [POST /chat/run-incremental](#6-post-chatrun-incremental)
7. [POST /chat/run-since](#7-post-chatrun-since)
8. [GET /chat/records](#8-get-chatrecords)
9. [GET /chat/files](#9-get-chatfiles)
10. [DELETE /chat/records](#10-delete-chatrecords)
11. [DELETE /chat/files](#11-delete-chatfiles)

---

## 1. GET /chat/config

**Description:** Get meeting chat pipeline configuration including AWS settings and incremental sync parameters.

**Request:** No parameters required

**Expected Response:**
```json
{
  "status": "success",
  "configuration": {
    "aws_region": "us-east-1",
    "s3_bucket_name": "ids-aini-prototype-ai-analytics",
    "s3_base_prefix": "Agentic-Colleague-synthetic/meetings",
    "s3_chat_prefix": "Agentic-Colleague-synthetic/meetings/chats/",
    "dynamodb_table_name": "AgenticColleague_MeetingTracker",
    "meetings_fetch_limit": 100,
    "max_retry_attempts": 3
  },
  "incremental_settings": {
    "default_lookback_days": 90,
    "incremental_buffer_hours": 2,
    "enable_auto_retry": true
  }
}
```

---

## 2. GET /chat/status

**Description:** Get the current status of the meeting chat pipeline including DynamoDB stats, S3 storage stats, and last run information.

**Request:** No parameters required

**Expected Response:**
```json
{
  "pipeline_status": "ready",
  "configuration": {
    "aws_region": "us-east-1",
    "s3_bucket_name": "ids-aini-prototype-ai-analytics",
    "s3_chat_prefix": "Agentic-Colleague-synthetic/meetings/chats/",
    "dynamodb_table_name": "AgenticColleague_MeetingTracker"
  },
  "incremental_settings": {
    "default_lookback_days": 90,
    "incremental_buffer_hours": 2,
    "enable_auto_retry": true
  },
  "dynamodb_stats": {
    "TOTAL": 15,
    "COMPLETED": 12,
    "FAILED": 2,
    "PROCESSING": 1
  },
  "s3_stats": {
    "total_files": 12,
    "docx_files": 12,
    "total_size_mb": 2.5
  },
  "last_run_info": {
    "last_successful_run": "2026-08-05T10:00:00Z",
    "last_run_mode": "incremental",
    "last_run_status": "SUCCESS",
    "last_run_processed": 3,
    "last_run_failed": 0
  }
}
```

---

## 3. GET /chat/verify

**Description:** Verifies all components of the meeting chat pipeline: Secrets Manager, DynamoDB, S3, and Graph API.

**Request:** No parameters required

**Expected Response:**
```json
{
  "all_passed": true,
  "secrets_manager": true,
  "dynamodb": true,
  "s3": true,
  "graph_api": true,
  "details": {
    "secrets_manager": "Configuration loaded successfully",
    "graph_api": "Graph API authenticated successfully (Chat Client)",
    "dynamodb": "DynamoDB accessible. Total chat records: 15",
    "s3": "S3 accessible. Chat files: 12"
  }
}
```

---

## 4. POST /chat/run

**Description:** Main endpoint to trigger the meeting chat extraction pipeline.

> **Run Modes:**
> - `full`: First run or reset - fetches all meeting chats from the last N days (configured lookback)
> - `incremental`: Only fetches new meeting chats since last successful run (default)
> - `since`: Fetches meeting chats from a specific date

### Test Case 4.1: Incremental Sync (Default Mode)
```json
{
  "mode": "incremental",
  "retry_failed": true,
  "min_messages": 1
}
```

### Test Case 4.2: Full Sync (First Run/Reset)
```json
{
  "mode": "full",
  "retry_failed": true,
  "min_messages": 1
}
```

### Test Case 4.3: Full Sync with Limit
```json
{
  "mode": "full",
  "limit": 10,
  "retry_failed": true,
  "min_messages": 1
}
```

### Test Case 4.4: Since Specific Date
```json
{
  "mode": "since",
  "since_date": "2026-08-01",
  "retry_failed": true,
  "min_messages": 1
}
```

### Test Case 4.5: Since Date with Limit
```json
{
  "mode": "since",
  "since_date": "2026-07-15",
  "limit": 5,
  "retry_failed": true,
  "min_messages": 1
}
```

### Test Case 4.6: Filter by Minimum Messages
```json
{
  "mode": "full",
  "min_messages": 5,
  "retry_failed": true
}
```
> Only meetings with 5 or more chat messages will be processed.

### Test Case 4.7: Incremental Without Retry
```json
{
  "mode": "incremental",
  "retry_failed": false,
  "min_messages": 1
}
```

---

## 5. POST /chat/run-full

**Description:** Shortcut endpoint to run a full sync of all meeting chats. Use for first run or reset.

### Test Case 5.1: Full Sync (All Meetings)
**Query Parameters:**
- `retry_failed`: `true`
- `min_messages`: `1`

> Leave `limit` empty to process all meetings.

### Test Case 5.2: Full Sync with Limit
**Query Parameters:**
- `limit`: `10`
- `retry_failed`: `true`
- `min_messages`: `1`

### Test Case 5.3: Full Sync with Message Filter
**Query Parameters:**
- `limit`: `20`
- `retry_failed`: `true`
- `min_messages`: `5`

---

## 6. POST /chat/run-incremental

**Description:** Shortcut endpoint to run an incremental sync. Only fetches new meeting chats since last successful run.

### Test Case 6.1: Incremental Sync (All New Meetings)
**Query Parameters:**
- `retry_failed`: `true`
- `min_messages`: `1`

> Leave `limit` empty to process all new meetings.

### Test Case 6.2: Incremental Sync with Limit
**Query Parameters:**
- `limit`: `5`
- `retry_failed`: `true`
- `min_messages`: `1`

---

## 7. POST /chat/run-since

**Description:** Shortcut endpoint to run sync from a specific date.

### Test Case 7.1: Sync Since August 1, 2026
**Query Parameters:**
- `since_date`: `2026-08-01`
- `retry_failed`: `true`
- `min_messages`: `1`

### Test Case 7.2: Sync Since July 15, 2026 with Limit
**Query Parameters:**
- `since_date`: `2026-07-15`
- `limit`: `10`
- `retry_failed`: `true`
- `min_messages`: `1`

### Test Case 7.3: Sync Last Week with Message Filter
**Query Parameters:**
- `since_date`: `2026-07-30` (adjust to 7 days ago)
- `retry_failed`: `true`
- `min_messages`: `3`

---

## 8. GET /chat/records

**Description:** Returns all meeting chat records from DynamoDB with their processing status.

### Test Case 8.1: List All Records
**Query Parameters:** (leave all empty)

### Test Case 8.2: Filter by Status - Completed
**Query Parameters:**
- `status_filter`: `COMPLETED`

### Test Case 8.3: Filter by Status - Failed
**Query Parameters:**
- `status_filter`: `FAILED`

### Test Case 8.4: List with Limit
**Query Parameters:**
- `limit`: `20`

### Test Case 8.5: Filter Failed with Limit
**Query Parameters:**
- `status_filter`: `FAILED`
- `limit`: `10`

---

## 9. GET /chat/files

**Description:** Returns all meeting chat files stored in S3 with their metadata.

### Test Case 9.1: List All Files
**Query Parameters:** (leave empty)

### Test Case 9.2: List with Limit
**Query Parameters:**
- `limit`: `10`

---

## 10. DELETE /chat/records

**Description:** ⚠️ DANGER: Deletes ALL meeting chat tracking records from DynamoDB (preserves transcript records).

### Test Case 10.1: Attempt Without Confirmation (Should Fail)
**Query Parameters:**
- `confirm`: `false`

**Expected Response:** 400 Error - "Set confirm=true to confirm deletion of all chat records"

### Test Case 10.2: Delete All Chat Records (Use with Caution!)
**Query Parameters:**
- `confirm`: `true`

**Expected Response:**
```json
{
  "status": "success",
  "message": "Deleted 15 chat records from DynamoDB",
  "deleted_count": 15
}
```

> **Note:** This only deletes CHAT records. Transcript records are preserved.

---

## 11. DELETE /chat/files

**Description:** ⚠️ DANGER: Deletes ALL meeting chat files from S3 (preserves transcript files).

### Test Case 11.1: Attempt Without Confirmation (Should Fail)
**Query Parameters:**
- `confirm`: `false`

**Expected Response:** 400 Error - "Set confirm=true to confirm deletion of all chat files"

### Test Case 11.2: Delete All Chat Files (Use with Caution!)
**Query Parameters:**
- `confirm`: `true`

**Expected Response:**
```json
{
  "status": "success",
  "message": "Deleted 12 chat files from S3",
  "deleted_count": 12
}
```

> **Note:** This only deletes files in the `/chats/` subfolder. Transcript files in `/transcripts/` are preserved.

---

## Quick Test Workflow

Follow this sequence to test the entire meeting chat pipeline:

### Step 1: Verify Components
```
GET /chat/verify
```
> Ensure all components (Secrets Manager, Graph API, DynamoDB, S3) are accessible.

### Step 2: Check Configuration
```
GET /chat/config
```
> Review pipeline configuration settings.

### Step 3: Check Current Status
```
GET /chat/status
```
> See DynamoDB stats, S3 stats, and last run information.

### Step 4: Run Full Sync (First Time)
```
POST /chat/run-full?limit=5&min_messages=1
```
> Start with a small limit to test the pipeline.

### Step 5: Check Records
```
GET /chat/records
```
> Verify chat records were created in DynamoDB.

### Step 6: Check Files
```
GET /chat/files
```
> Verify chat files were uploaded to S3.

### Step 7: Run Incremental Sync
```
POST /chat/run-incremental
```
> Test incremental mode (should only process new meetings).

### Step 8: Check Status Again
```
GET /chat/status
```
> Verify last run info was updated.

---

## Error Handling Test Cases

### Missing since_date for "since" mode
```json
{
  "mode": "since",
  "retry_failed": true,
  "min_messages": 1
}
```
**Expected:** 400 Error - "since_date is required when mode='since'"

### Invalid Date Format
```json
{
  "mode": "since",
  "since_date": "August 1, 2026",
  "retry_failed": true,
  "min_messages": 1
}
```
**Expected:** 400 Error - "Could not parse date: August 1, 2026. Use format YYYY-MM-DD"

### Delete Without Confirmation
```
DELETE /chat/records?confirm=false
```
**Expected:** 400 Error - "Set confirm=true to confirm deletion of all chat records"

---

## Notes

1. **Verify First**: Always run `/chat/verify` before running the pipeline to ensure all components are accessible.

2. **Full vs Incremental**: 
   - Use `full` mode for first run or when you want to reset and reprocess all meeting chats
   - Use `incremental` mode for regular runs to only fetch new meeting chats

3. **Since Mode**: Use when you want to fetch meeting chats from a specific date without resetting the entire pipeline.

4. **Limit Parameter**: The `limit` parameter is **OPTIONAL**. If omitted, ALL meetings will be processed.

5. **Minimum Messages**: Use `min_messages` to filter out meetings with too few chat messages (useful to skip meetings with no real discussion).

6. **Retry Failed**: Set `retry_failed=true` (default) to automatically retry previously failed chat extractions.

7. **Cleanup Operations**: The DELETE endpoints require `confirm=true` to prevent accidental data deletion. They only delete chat-related data, preserving transcript data.

8. **Graph API Rate Limits**: Microsoft Graph API has rate limits. If you encounter errors, wait a few minutes before retrying.

9. **Chat vs Transcript Separation**: 
   - Chat files are stored in `{base_prefix}/chats/`
   - Transcript files are stored in `{base_prefix}/transcripts/`
   - DynamoDB records use `record_type` field to distinguish ("CHAT" vs "TRANSCRIPT")

---

## Recommended Testing Order

1. `GET /chat/verify` - Check all connections
2. `GET /chat/config` - Review configuration
3. `GET /chat/status` - See current state
4. `POST /chat/run-full?limit=5` - Test full sync (small batch)
5. `GET /chat/records` - Verify records created
6. `GET /chat/files` - Verify files uploaded
7. `GET /chat/status` - Verify metadata saved
8. `POST /chat/run-incremental` - Test incremental mode
9. `POST /chat/run-since?since_date=2026-08-01` - Test since-date mode

---

## Comparison: Chat vs Transcript Pipeline

| Feature | Transcript Pipeline | Chat Pipeline |
|---------|---------------------|---------------|
| API Prefix | `/transcript/*` | `/chat/*` |
| S3 Prefix | `{base}/transcripts/` | `{base}/chats/` |
| Record Type | `TRANSCRIPT` | `CHAT` |
| Metadata ID | `__PIPELINE_METADATA__` | `__CHAT_PIPELINE_METADATA__` |
| Content | Meeting transcription | Chat messages |
| Extra Filter | - | `min_messages` |
| Graph API Endpoint | Online Meeting Transcripts | Chat Messages |
