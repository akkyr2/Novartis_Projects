# Transcript Pipeline Module

> **Version:** 2.0  
> **Last Updated:** August 2026  
> **Module Path:** `transcript_pipeline/`

---

## Table of Contents

1. [Module Overview](#1-module-overview)
2. [Business Context](#2-business-context)
3. [Functional Overview](#3-functional-overview)
4. [Architecture Overview](#4-architecture-overview)
5. [Folder Structure](#5-folder-structure)
6. [Technology Stack](#6-technology-stack)
7. [Dependencies](#7-dependencies)
8. [Configuration](#8-configuration)
9. [Environment Variables](#9-environment-variables)
10. [Installation Guide](#10-installation-guide)
11. [Build Process](#11-build-process)
12. [Running the Application](#12-running-the-application)
13. [API Documentation](#13-api-documentation)
14. [Database Documentation](#14-database-documentation)
15. [End-to-End Flow](#15-end-to-end-flow)
16. [Component Deep Dive](#16-component-deep-dive)
17. [Data Flow](#17-data-flow)
18. [Logging and Monitoring](#18-logging-and-monitoring)
19. [Error Handling Strategy](#19-error-handling-strategy)
20. [Security Considerations](#20-security-considerations)
21. [Testing](#21-testing)
22. [Deployment](#22-deployment)
23. [Troubleshooting Guide](#23-troubleshooting-guide)
24. [Performance Considerations](#24-performance-considerations)
25. [Assumptions and Limitations](#25-assumptions-and-limitations)
26. [Future Improvements](#26-future-improvements)
27. [Frequently Asked Questions](#27-frequently-asked-questions)
28. [Glossary](#28-glossary)
29. [Ownership and Support](#29-ownership-and-support)
30. [Quick Start Guide](#30-quick-start-guide)

---

## 1. Module Overview

### What This Module Does

The **Transcript Pipeline** is a data extraction and processing system that automatically retrieves Microsoft Teams meeting content (transcripts and chat messages) and stores them in AWS infrastructure for downstream analytics and AI-powered applications.

### Why It Exists

In enterprise environments, valuable knowledge is shared during Microsoft Teams meetings but often remains locked within the Teams platform. This module unlocks that knowledge by:

- **Extracting** meeting transcripts (spoken content) and chat messages
- **Converting** raw VTT (Video Text Track) content into readable DOCX documents
- **Storing** processed documents in AWS S3 for long-term storage and accessibility
- **Tracking** processing state in DynamoDB for reliability and auditability

### Business Value

- **Knowledge Capture**: Prevents loss of institutional knowledge from meetings
- **AI Enablement**: Provides training/context data for enterprise AI assistants
- **Time Savings**: Automates manual transcript retrieval (~200+ API calls reduced to ~10 with incremental sync)
- **Compliance**: Creates auditable records of meeting content

---

## 2. Business Context

### Business Purpose

The Agentic Colleague project aims to create an AI-powered assistant that understands organizational context from meetings. This pipeline is a critical data ingestion component that feeds meeting content to the AI system.

### Use Cases

1. **Daily Sync**: Hourly extraction of new meeting transcripts and chats
2. **Historical Backfill**: Initial population with 90 days of historical meeting data
3. **Retry Processing**: Automatic recovery of previously failed extractions
4. **Compliance Archival**: Long-term storage of meeting records in S3

### Real-World Examples

```
Scenario: Weekly Team Standup
1. Meeting occurs on Teams with transcription enabled
2. Pipeline runs via scheduled trigger (e.g., every hour)
3. Transcript is extracted, converted to DOCX, uploaded to S3
4. AI assistant can now answer: "What was discussed in last week's standup?"
```

### Expected Outcomes

| Metric | Target |
|--------|--------|
| Extraction Latency | < 1 hour from meeting end |
| Success Rate | > 95% for meetings with available transcripts |
| Data Coverage | 90 days lookback for historical data |
| Document Format | Professionally formatted DOCX with speaker attribution |

---

## 3. Functional Overview

### Core Responsibilities

| Responsibility | Description |
|----------------|-------------|
| **Authentication** | Certificate-based auth with Microsoft Graph API via MSAL |
| **Discovery** | Find meetings with transcripts/chats within date ranges |
| **Extraction** | Download VTT transcripts and JSON chat messages |
| **Conversion** | Transform VTT → DOCX, Chat JSON → DOCX |
| **Storage** | Upload to S3 with organized folder structure |
| **Tracking** | Maintain processing state in DynamoDB |
| **Retry Logic** | Automatic retry of failed extractions (up to 3 attempts) |

### Major Features

1. **Two Parallel Pipelines**:
   - **Transcript Pipeline**: Extracts meeting transcriptions (VTT format)
   - **Chat Pipeline**: Extracts in-meeting chat messages

2. **Three Run Modes**:
   - `full`: Historical backfill (last 90 days)
   - `incremental`: New meetings since last successful run
   - `since`: Custom date range extraction

3. **Intelligent Processing**:
   - Skip already-processed meetings
   - Retry failed extractions with exponential backoff
   - Filter chat by minimum message count

### Intentionally Excluded

- Real-time/streaming extraction (designed for batch processing)
- Meeting video/audio content (only text-based content)
- External Teams meetings (only user's calendar meetings)
- Meeting recordings download

---

## 4. Architecture Overview

### High-Level Architecture

```mermaid
flowchart TB
    subgraph "Microsoft 365"
        GraphAPI[Microsoft Graph API]
        Teams[Teams Meetings]
    end

    subgraph "Transcript Pipeline"
        Main[Pipeline Orchestrator]
        GraphClient[Graph Client]
        Tracker[DynamoDB Tracker]
        Storage[S3 Storage]
        
        Main --> GraphClient
        Main --> Tracker
        Main --> Storage
    end

    subgraph "AWS Services"
        SecretsManager[Secrets Manager]
        DynamoDB[(DynamoDB)]
        S3[(S3 Bucket)]
    end

    Teams --> GraphAPI
    GraphClient --> GraphAPI
    GraphClient --> SecretsManager
    Tracker --> DynamoDB
    Storage --> S3
```

### Component Relationships

```mermaid
classDiagram
    class Config {
        +azure_tenant_id
        +azure_client_id
        +s3_bucket_name
        +dynamodb_table_name
        +validate()
    }

    class GraphClient {
        +authenticate()
        +get_online_meetings()
        +list_transcripts()
        +download_transcript_content()
    }

    class ChatClient {
        +authenticate()
        +get_meetings_with_chats()
        +get_chat_messages()
    }

    class DynamoDBTracker {
        +mark_processing()
        +mark_completed()
        +mark_failed()
        +get_pipeline_metadata()
    }

    class S3Storage {
        +upload_transcript()
        +upload_chat()
        +get_storage_stats()
    }

    class TranscriptPipeline {
        +run()
        +verify()
        +show_status()
    }

    class ChatPipeline {
        +run()
        +verify()
        +show_status()
    }

    Config <-- GraphClient
    Config <-- ChatClient
    Config <-- DynamoDBTracker
    Config <-- S3Storage
    TranscriptPipeline --> Config
    TranscriptPipeline --> GraphClient
    TranscriptPipeline --> DynamoDBTracker
    TranscriptPipeline --> S3Storage
    ChatPipeline --> Config
    ChatPipeline --> ChatClient
    ChatPipeline --> DynamoDBTracker
    ChatPipeline --> S3Storage
```

### Data Storage Architecture

Both pipelines share infrastructure but maintain isolated data:

| Component | Transcript Pipeline | Chat Pipeline |
|-----------|---------------------|---------------|
| **S3 Prefix** | `{base}/transcripts/` | `{base}/chats/` |
| **DynamoDB Record Type** | `TRANSCRIPT` | `CHAT` |
| **Metadata ID** | `__TRANSCRIPT_PIPELINE_METADATA__` | `__CHAT_PIPELINE_METADATA__` |

---

## 5. Folder Structure

```
transcript_pipeline/
├── __init__.py                    # Package initialization
├── config.py                      # Centralized configuration (Secrets Manager)
├── main.py                        # Original CLI pipeline orchestrator
├── main_v2.py                     # Enhanced pipeline with incremental sync
├── main_chat.py                   # Chat extraction pipeline
├── graph_client.py                # Microsoft Graph API client (transcripts)
├── chat_client.py                 # Microsoft Graph API client (chats)
├── dynamodb_tracker.py            # Transcript DynamoDB tracker
├── chat_dynamodb_tracker.py       # Chat DynamoDB tracker
├── s3_storage.py                  # Transcript S3 storage + VTT→DOCX converter
├── chat_s3_storage.py             # Chat S3 storage + Chat→DOCX converter
├── API_TEST_GUIDE.md              # Transcript API testing guide
├── CHAT_API_TEST_GUIDE.md         # Chat API testing guide
├── README.md                      # This file
└── verify/                        # Verification scripts
    ├── __init__.py
    ├── settings.py                # Common verification settings
    ├── verify_secrets.py          # Secrets Manager verification
    ├── transcript/                # Transcript-specific verifications
    │   ├── __init__.py
    │   ├── verify_all.py          # Run all transcript verifications
    │   ├── verify_dynamodb.py     # DynamoDB verification
    │   ├── verify_s3.py           # S3 verification
    │   ├── cleanup_dynamodb.py    # DynamoDB cleanup utility
    │   ├── cleanup_s3.py          # S3 cleanup utility
    │   └── download_files.py      # Download transcripts from S3
    └── chat/                      # Chat-specific verifications
        ├── __init__.py
        ├── verify_all.py          # Run all chat verifications
        ├── verify_dynamodb.py     # DynamoDB verification
        ├── verify_s3.py           # S3 verification
        ├── cleanup_dynamodb.py    # DynamoDB cleanup utility
        └── cleanup_s3.py          # S3 cleanup utility
```

### Key File Purposes

| File | Purpose |
|------|---------|
| `config.py` | Single source of truth - fetches all settings from AWS Secrets Manager |
| `main_v2.py` | **Recommended** pipeline runner with incremental sync support |
| `graph_client.py` | Handles MSAL auth and Graph API calls for transcripts |
| `dynamodb_tracker.py` | State machine for transcript processing lifecycle |
| `s3_storage.py` | VTT parsing, DOCX generation, S3 uploads |

---

## 6. Technology Stack

### Programming Languages

| Language | Version | Usage |
|----------|---------|-------|
| Python | 3.9+ | Primary language |

### Frameworks & Libraries

| Library | Version | Purpose |
|---------|---------|---------|
| `boto3` | Latest | AWS SDK (S3, DynamoDB, Secrets Manager) |
| `msal` | Latest | Microsoft Authentication Library |
| `requests` | Latest | HTTP client for Graph API |
| `python-docx` | Latest | DOCX document generation |
| `python-dotenv` | Latest | Local environment variable loading |
| `pydantic-settings` | Latest | Configuration validation |

### Runtime Requirements

| Component | Requirement |
|-----------|-------------|
| Python Runtime | 3.9 or higher |
| AWS Credentials | Valid IAM credentials with appropriate permissions |
| Network | Access to Microsoft Graph API and AWS services |

### Build Tools

| Tool | Purpose |
|------|---------|
| `pip` | Package installation |
| `venv` | Virtual environment management |

---

## 7. Dependencies

### Internal Dependencies

| Module | Purpose |
|--------|---------|
| `config.py` | Shared by all components for configuration |
| `graph_client.py` | Used by `main.py`, `main_v2.py` |
| `chat_client.py` | Used by `main_chat.py` |
| `dynamodb_tracker.py` | Used by transcript pipelines |
| `chat_dynamodb_tracker.py` | Used by chat pipeline |
| `s3_storage.py` | Used by transcript pipelines |
| `chat_s3_storage.py` | Used by chat pipeline |

### External Dependencies

| Dependency | Why It's Needed |
|------------|-----------------|
| **AWS Secrets Manager** | Stores Graph API credentials and Azure AD configuration |
| **AWS DynamoDB** | Tracks processing state, enables incremental sync |
| **AWS S3** | Long-term storage for processed documents |
| **Microsoft Graph API** | Source of meeting data (transcripts, chats) |
| **Azure AD** | Authentication provider for Graph API access |

### Third-Party Services

| Service | Purpose | Required Credentials |
|---------|---------|----------------------|
| Microsoft Graph API | Meeting data source | Azure AD App Registration |
| AWS Secrets Manager | Credential storage | AWS IAM credentials |
| AWS DynamoDB | State tracking | AWS IAM credentials |
| AWS S3 | Document storage | AWS IAM credentials |

---

## 8. Configuration

### Configuration Files

| File | Format | Purpose |
|------|--------|---------|
| AWS Secrets Manager | JSON | Primary configuration source |
| `.env` (optional) | KEY=VALUE | Local development overrides |

### Secrets Manager Structure

The pipeline expects a secret named `agentic-colleague/graph-api-config` with this structure:

```json
{
  "AZURE_TENANT_ID": "your-tenant-id",
  "AZURE_CLIENT_ID": "your-app-client-id",
  "AZURE_CERT_THUMBPRINT": "certificate-thumbprint",
  "AZURE_CERT_CONTENT": "your-azure-cert-content",
  "GRAPH_USER_ID": "target-user-object-id",
  "AWS_REGION": "us-east-1",
  "S3_BUCKET_NAME": "ids-aini-prototype-ai-analytics",
  "S3_PREFIX": "Agentic-Colleague-synthetic/meetings/",
  "DYNAMODB_TABLE_NAME": "AgenticColleague_MeetingTracker",
  "MAX_RETRY_ATTEMPTS": "3",
  "MEETINGS_FETCH_LIMIT": "100",
  "LOG_LEVEL": "INFO",
  "DEFAULT_LOOKBACK_DAYS": "90",
  "INCREMENTAL_BUFFER_HOURS": "2",
  "ENABLE_AUTO_RETRY": "true"
}
```

### Configuration Priority

1. **AWS Secrets Manager** (Primary)
2. **Environment Variables** (Override)
3. **Default Values** (Fallback)

---

## 9. Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `SECRET_NAME` | No | `agentic-colleague/graph-api-config` | AWS Secrets Manager secret name |
| `AWS_REGION` | No | `us-east-1` | AWS region for all services |
| `AZURE_TENANT_ID` | Yes* | - | Azure AD tenant ID |
| `AZURE_CLIENT_ID` | Yes* | - | Azure AD application client ID |
| `AZURE_CERT_THUMBPRINT` | Yes* | - | Certificate thumbprint for auth |
| `AZURE_CERT_CONTENT` | Yes* | - | PEM certificate content |
| `AZURE_CERT_PATH` | Conditional | - | Path to certificate file (alternative to CERT_CONTENT) |
| `GRAPH_USER_ID` | Yes* | - | Target user's Azure AD object ID |
| `S3_BUCKET_NAME` | No | `ids-aini-prototype-ai-analytics` | S3 bucket for documents |
| `S3_PREFIX` | No | `Agentic-Colleague-synthetic/meetings/` | Base S3 folder path |
| `DYNAMODB_TABLE_NAME` | No | `AgenticColleague_MeetingTracker` | DynamoDB table name |
| `MAX_RETRY_ATTEMPTS` | No | `3` | Max retries for failed extractions |
| `MEETINGS_FETCH_LIMIT` | No | `100` | Max meetings per API call |
| `LOG_LEVEL` | No | `INFO` | Logging level |
| `DEFAULT_LOOKBACK_DAYS` | No | `90` | Days to look back for full sync |
| `INCREMENTAL_BUFFER_HOURS` | No | `2` | Safety buffer for incremental sync |
| `ENABLE_AUTO_RETRY` | No | `true` | Auto-retry failed transcripts |

> \* Typically stored in Secrets Manager rather than environment variables

---

## 10. Installation Guide

### Prerequisites

1. **Python 3.9+** installed
2. **AWS CLI** configured with appropriate credentials
3. **Access to AWS Secrets Manager** with the configuration secret
4. **Azure AD App Registration** with Graph API permissions

### Step-by-Step Setup

```powershell
# 1. Clone the repository (if not already done)
cd "c:\path\to\agentic-colleague-v2"

# 2. Create virtual environment
python -m venv venv

# 3. Activate virtual environment (Windows PowerShell)
.\venv\Scripts\Activate.ps1

# 4. Install dependencies
pip install -r requirements.txt

# 5. Verify AWS credentials
aws sts get-caller-identity

# 6. Verify Secrets Manager access
python -m transcript_pipeline.verify.verify_secrets

# 7. Verify all components
python -m transcript_pipeline.verify.transcript.verify_all
python -m transcript_pipeline.verify.chat.verify_all
```

### Azure AD App Registration Setup

1. Register an application in Azure AD
2. Add Graph API permissions:
   - `Calendars.Read`
   - `OnlineMeetings.Read.All`
   - `OnlineMeetingTranscript.Read.All`
   - `Chat.Read`
   - `ChatMessage.Read`
3. Create a certificate and upload to App Registration
4. Store credentials in AWS Secrets Manager

---

## 11. Build Process

This is a Python application that doesn't require a compilation step.

### Package Installation

```powershell
# Install all dependencies
pip install -r requirements.txt

# Install in development mode (editable)
pip install -e .
```

### Build Artifacts

| Artifact | Location | Description |
|----------|----------|-------------|
| Python packages | `venv/Lib/site-packages/` | Installed dependencies |
| Bytecode cache | `__pycache__/` | Compiled Python files |

---

## 12. Running the Application

### Command-Line Interface (CLI)

#### Transcript Pipeline (Recommended: main_v2.py)

```powershell
# Verify all components
python -m transcript_pipeline.main_v2 verify

# Show current status
python -m transcript_pipeline.main_v2 status

# Full sync (first run - fetches 90 days of history)
python -m transcript_pipeline.main_v2 run --full

# Full sync with limit (for testing)
python -m transcript_pipeline.main_v2 run --full --limit 5

# Incremental sync (default mode)
python -m transcript_pipeline.main_v2 run

# Fetch from specific date
python -m transcript_pipeline.main_v2 run --since "2026-07-01"

# Run without retry
python -m transcript_pipeline.main_v2 run --no-retry
```

#### Chat Pipeline

```powershell
# Verify chat components
python -m transcript_pipeline.main_chat verify

# Show chat pipeline status
python -m transcript_pipeline.main_chat status

# Full sync
python -m transcript_pipeline.main_chat run --full

# Incremental sync
python -m transcript_pipeline.main_chat run

# Filter by minimum messages
python -m transcript_pipeline.main_chat run --min-messages 5
```

### Run Modes Explained

| Mode | Use Case | Command |
|------|----------|---------|
| `full` | First run or reset | `run --full` |
| `incremental` | Regular scheduled runs | `run` |
| `since` | Custom date range | `run --since "2026-07-01"` |

### Development Mode

```powershell
# Run with debug logging
$env:LOG_LEVEL = "DEBUG"
python -m transcript_pipeline.main_v2 run --limit 1
```

### Production Mode

Production runs are typically scheduled via cron or a scheduler service:

```powershell
# Hourly incremental sync
python -m transcript_pipeline.main_v2 run

# Daily full sync for coverage verification
python -m transcript_pipeline.main_v2 run --full
```

---

## 13. API Documentation

This module is primarily a CLI-based pipeline, but it exposes endpoints when integrated with FastAPI in the main application.

### Transcript Pipeline Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/transcript/config` | GET | Get pipeline configuration |
| `/transcript/status` | GET | Get pipeline status and stats |
| `/transcript/verify` | GET | Verify all components |
| `/transcript/run` | POST | Trigger pipeline run |
| `/transcript/run-full` | POST | Trigger full sync |
| `/transcript/run-incremental` | POST | Trigger incremental sync |
| `/transcript/run-since` | POST | Trigger sync from date |
| `/transcript/records` | GET | List DynamoDB records |
| `/transcript/files` | GET | List S3 files |
| `/transcript/records` | DELETE | Delete all transcript records |
| `/transcript/files` | DELETE | Delete all transcript files |

### Chat Pipeline Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/chat/config` | GET | Get pipeline configuration |
| `/chat/status` | GET | Get pipeline status and stats |
| `/chat/verify` | GET | Verify all components |
| `/chat/run` | POST | Trigger pipeline run |
| `/chat/run-full` | POST | Trigger full sync |
| `/chat/run-incremental` | POST | Trigger incremental sync |
| `/chat/run-since` | POST | Trigger sync from date |
| `/chat/records` | GET | List DynamoDB records |
| `/chat/files` | GET | List S3 files |
| `/chat/records` | DELETE | Delete all chat records |
| `/chat/files` | DELETE | Delete all chat files |

### Request/Response Examples

#### POST /transcript/run

**Request Body:**
```json
{
  "mode": "incremental",
  "retry_failed": true,
  "limit": null
}
```

**Response:**
```json
{
  "status": "success",
  "mode": "incremental",
  "duration_seconds": 45.3,
  "total_meetings": 15,
  "total_transcripts": 12,
  "processed": 8,
  "skipped": 3,
  "failed": 1,
  "success_rate": 88.9
}
```

---

## 14. Database Documentation

### DynamoDB Table Schema

**Table Name:** `AgenticColleague_MeetingTracker`

**Key Schema:**

| Attribute | Type | Key Type |
|-----------|------|----------|
| `record_id` | String | Partition Key (HASH) |

**Global Secondary Indexes:**

| Index Name | Partition Key | Sort Key | Purpose |
|------------|---------------|----------|---------|
| `record_type-status-index` | `record_type` | `status` | Filter by type and status |
| `status-index` | `status` | - | Query by status only |

**Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `record_id` | String | Transcript ID or Chat ID |
| `record_type` | String | `TRANSCRIPT` or `CHAT` |
| `meeting_id` | String | Online meeting ID |
| `join_url` | String | Teams meeting join URL |
| `meeting_subject` | String | Meeting title |
| `status` | String | Processing status |
| `retry_count` | Number | Current retry attempt |
| `max_retries` | Number | Maximum retry attempts (default: 3) |
| `s3_path` | String | S3 URI of uploaded document |
| `error_message` | String | Last error message (if failed) |
| `message_count` | Number | Chat message count (chat only) |
| `created_at` | String | ISO timestamp |
| `updated_at` | String | ISO timestamp |
| `processed_at` | String | ISO timestamp (when completed) |

**Status Values:**

| Status | Description |
|--------|-------------|
| `PENDING` | Discovered but not yet processed |
| `PROCESSING` | Currently being processed |
| `COMPLETED` | Successfully processed and uploaded |
| `FAILED` | Failed, can be retried |
| `PERMANENTLY_FAILED` | Failed after max retries |

### Pipeline Metadata Records

Special records store pipeline run history:

| Metadata ID | Purpose |
|-------------|---------|
| `__TRANSCRIPT_PIPELINE_METADATA__` | Transcript pipeline last run info |
| `__CHAT_PIPELINE_METADATA__` | Chat pipeline last run info |

**Metadata Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `last_successful_run` | String | ISO timestamp of last successful run |
| `last_run_status` | String | `SUCCESS` or `PARTIAL` |
| `total_runs` | Number | Total pipeline executions |
| `total_processed` | Number | Cumulative processed count |
| `total_failed` | Number | Cumulative failed count |

### Data Flow

```mermaid
flowchart LR
    subgraph "Discovery"
        A[Graph API] --> B[Meeting List]
    end

    subgraph "Processing"
        B --> C{Already Processed?}
        C -- No --> D[Mark PROCESSING]
        C -- Yes --> E[Skip]
        D --> F[Download Content]
        F --> G[Convert to DOCX]
        G --> H[Upload to S3]
    end

    subgraph "Completion"
        H --> I[Mark COMPLETED]
        F -- Error --> J[Mark FAILED]
        I --> K[(DynamoDB)]
        J --> K
    end
```

---

## 15. End-to-End Flow

### Transcript Pipeline Flow

```mermaid
sequenceDiagram
    participant CLI as CLI/Scheduler
    participant Pipeline as TranscriptPipelineV2
    participant Config as Config
    participant Graph as GraphClient
    participant Tracker as DynamoDBTracker
    participant Storage as S3Storage

    CLI->>Pipeline: run(mode="incremental")
    Pipeline->>Config: validate()
    Config->>Config: Fetch from Secrets Manager
    Pipeline->>Tracker: get_last_successful_run()
    Tracker-->>Pipeline: last_run_timestamp

    Pipeline->>Graph: authenticate()
    Graph->>Graph: MSAL certificate auth
    Graph-->>Pipeline: access_token

    Pipeline->>Graph: get_online_meetings_with_transcripts_in_range()
    Graph->>Graph: GET /users/{id}/calendarView
    Graph->>Graph: Filter online meetings
    loop For each meeting
        Graph->>Graph: GET /onlineMeetings/{id}
        Graph->>Graph: GET /transcripts
    end
    Graph-->>Pipeline: meetings_with_transcripts

    loop For each transcript
        Pipeline->>Tracker: should_process(transcript_id)?
        alt Already processed
            Pipeline->>Pipeline: skip
        else New/Failed
            Pipeline->>Tracker: mark_processing()
            Pipeline->>Graph: download_transcript_content()
            Graph-->>Pipeline: VTT content
            Pipeline->>Storage: upload_transcript()
            Storage->>Storage: Convert VTT to DOCX
            Storage->>Storage: PUT to S3
            Storage-->>Pipeline: s3_uri
            Pipeline->>Tracker: mark_completed(s3_path)
        end
    end

    Pipeline->>Tracker: update_pipeline_metadata()
    Pipeline-->>CLI: PipelineResult
```

### Request-to-Response Lifecycle

1. **Initialization**: Load configuration from Secrets Manager
2. **Authentication**: Obtain Graph API access token via MSAL
3. **Discovery**: Query calendar events in date range
4. **Filtering**: Identify online meetings with transcripts
5. **State Check**: Verify each transcript against DynamoDB
6. **Processing**: Download VTT → Convert to DOCX → Upload to S3
7. **State Update**: Mark completed in DynamoDB
8. **Metadata Update**: Record pipeline run statistics
9. **Result**: Return summary with success/failure counts

---

## 16. Component Deep Dive

### Config (`config.py`)

**Purpose:** Centralized configuration management with AWS Secrets Manager integration.

**Key Features:**
- Lazy loading with caching (`@lru_cache`)
- Type-safe property access
- Validation of required keys
- Masked sensitive value printing

**Inputs:**
- AWS Secrets Manager secret
- Environment variables (overrides)

**Outputs:**
- Configuration dictionary
- Logger instance

**Internal Logic:**
```python
# Fetch and cache configuration
@lru_cache(maxsize=1)
def _fetch_secrets_from_aws() -> dict:
    client = boto3.client("secretsmanager")
    response = client.get_secret_value(SecretId=SECRET_NAME)
    return {**DEFAULTS, **json.loads(response["SecretString"])}
```

---

### GraphClient (`graph_client.py`)

**Purpose:** Authenticate with Azure AD and interact with Microsoft Graph API for transcript operations.

**Key Features:**
- Certificate-based authentication (MSAL)
- Calendar view queries for date ranges
- Transcript listing and content download
- Exponential backoff retry logic

**Data Classes:**
- `TranscriptInfo`: Represents a meeting transcript
- `MeetingInfo`: Represents an online meeting with transcripts

**Key Methods:**

| Method | Description |
|--------|-------------|
| `_authenticate()` | MSAL certificate-based auth |
| `get_calendar_view()` | Fetch events in date range |
| `get_online_meetings()` | Filter for Teams meetings |
| `list_transcripts()` | Get transcripts for a meeting |
| `download_transcript_content()` | Download VTT content |
| `get_online_meetings_with_transcripts_in_range()` | Combined discovery method |

---

### DynamoDBTracker (`dynamodb_tracker.py`)

**Purpose:** Manage transcript processing state in DynamoDB.

**Key Features:**
- Auto-create table if missing
- Status lifecycle management
- Retry count tracking
- Pipeline metadata storage

**Status State Machine:**

```mermaid
stateDiagram-v2
    [*] --> PENDING: New transcript discovered
    PENDING --> PROCESSING: Start processing
    PROCESSING --> COMPLETED: Success
    PROCESSING --> FAILED: Error (retryable)
    PROCESSING --> PERMANENTLY_FAILED: Max retries exceeded
    FAILED --> PROCESSING: Retry attempt
```

**Key Methods:**

| Method | Description |
|--------|-------------|
| `should_process()` | Check if transcript needs processing |
| `mark_processing()` | Update status to PROCESSING |
| `mark_completed()` | Update status to COMPLETED |
| `mark_failed()` | Update status to FAILED/PERMANENTLY_FAILED |
| `get_failed_for_retry()` | Get retryable failed records |
| `get_last_successful_run()` | Get timestamp for incremental sync |

---

### S3Storage (`s3_storage.py`)

**Purpose:** Handle VTT-to-DOCX conversion and S3 uploads.

**Key Features:**
- VTT parser with speaker extraction
- Professional DOCX formatting
- Organized folder structure (`{year}/{month}/`)
- Unicode-safe S3 metadata handling

**Internal Classes:**
- `VTTParser`: Parse WebVTT transcript format
- `DocxConverter`: Generate formatted DOCX documents

**S3 Path Format:**
```
s3://{bucket}/{prefix}/transcripts/{year}/{month}/{subject}_{transcript_id}.docx
```

**Example:**
```
s3://ids-aini-prototype/Agentic-Colleague-synthetic/meetings/transcripts/2026/08/Team_Standup_abc123def456.docx
```

---

### TranscriptPipelineV2 (`main_v2.py`)

**Purpose:** Orchestrate the complete transcript extraction workflow.

**Key Features:**
- Three run modes (full, incremental, since)
- Automatic retry of failed transcripts
- Pipeline metadata updates
- Comprehensive verification

**Orchestration Logic:**
1. Validate configuration
2. Calculate date range based on mode
3. Fetch meetings with transcripts
4. Process each transcript (skip completed)
5. Retry previously failed transcripts
6. Update pipeline metadata

---

## 17. Data Flow

### Source to Storage Flow

```mermaid
flowchart LR
    subgraph "Source"
        A[Teams Meeting]
        B[Transcription Service]
        C[Chat Messages]
    end

    subgraph "Extraction"
        D[Graph API]
        E[VTT Content]
        F[Chat JSON]
    end

    subgraph "Processing"
        G[VTT Parser]
        H[DOCX Converter]
        I[Chat Converter]
    end

    subgraph "Storage"
        J[(S3 Bucket)]
        K[(DynamoDB)]
    end

    A --> B
    B --> D
    C --> D
    D --> E
    D --> F
    E --> G
    G --> H
    F --> I
    H --> J
    I --> J
    H --> K
    I --> K
```

### Data Transformation

| Stage | Input Format | Output Format |
|-------|--------------|---------------|
| Extraction | Graph API JSON | VTT/Chat JSON |
| Parsing | VTT Text | VTTEntry objects |
| Conversion | VTTEntry objects | DOCX bytes |
| Storage | DOCX bytes | S3 object |

---

## 18. Logging and Monitoring

### Logging Framework

The module uses Python's built-in `logging` module with custom formatting.

**Log Format:**
```
2026-08-20 10:30:45 | INFO     | transcript_pipeline | Message here
```

**Log Levels:**

| Level | Usage |
|-------|-------|
| `DEBUG` | Detailed debugging information |
| `INFO` | General operational messages |
| `WARNING` | Non-critical issues |
| `ERROR` | Operation failures |
| `CRITICAL` | System-level failures |

### Configuring Log Level

```powershell
# Via Secrets Manager
# Set LOG_LEVEL: "DEBUG" in secret

# Via environment variable
$env:LOG_LEVEL = "DEBUG"
```

### Key Log Messages

| Event | Log Level | Message Pattern |
|-------|-----------|-----------------|
| Pipeline start | INFO | `STARTING TRANSCRIPT PIPELINE V2` |
| Authentication | INFO | `✅ Successfully authenticated with Graph API` |
| Processing | INFO | `▶️ Processing: {meeting_subject}` |
| Success | INFO | `✅ Completed: {transcript_id}` |
| Failure | ERROR | `❌ Error processing transcript: {error}` |
| Skip | INFO | `⏭️ Skipping (already processed)` |

### Monitoring Recommendations

1. **CloudWatch Logs**: Stream stdout to CloudWatch for centralized logging
2. **CloudWatch Metrics**: Create custom metrics for:
   - Transcripts processed per run
   - Failure rate
   - Processing duration
3. **Alarms**: Alert on:
   - High failure rates (>10%)
   - Pipeline not running (scheduled job missing)

---

## 19. Error Handling Strategy

### Error Types

| Error Type | Description | Recovery |
|------------|-------------|----------|
| `ConfigurationError` | Missing/invalid configuration | Manual fix required |
| `GraphAPIError` | Graph API failures | Automatic retry |
| `DynamoDBError` | DynamoDB failures | Automatic retry |
| `S3StorageError` | S3 upload failures | Automatic retry |
| `TranscriptProcessingError` | Processing logic errors | Logged and skipped |

### Retry Mechanisms

**Transcript Download Retry:**
```python
# Exponential backoff with max 3 attempts
for attempt in range(1, max_retries + 1):
    response = self._make_request("GET", url)
    if response.status_code == 200:
        return response.text
    elif response.status_code in (429, 500, 502, 503, 504):
        wait_time = retry_delay * (2 ** (attempt - 1))
        time.sleep(wait_time)
```

**Failed Record Retry:**
- Tracked in DynamoDB with `retry_count`
- Auto-retry on subsequent runs if `retry_count < max_retries`
- Mark as `PERMANENTLY_FAILED` after max retries

### Fallback Behavior

| Scenario | Fallback |
|----------|----------|
| Transcript not found (404) | Mark as permanently failed |
| Empty transcript content | Skip and mark failed |
| DOCX conversion error | Mark failed, retry later |
| S3 upload error | Mark failed, retry later |

### Recovery Approaches

1. **Automatic**: Most transient errors are retried automatically
2. **Manual Retry**: Use CLI to force retry of failed transcripts
3. **Full Resync**: Run `--full` mode to reprocess all transcripts

---

## 20. Security Considerations

### Authentication

| Component | Auth Method |
|-----------|-------------|
| Azure AD | Certificate-based authentication (MSAL) |
| AWS Services | IAM roles/credentials (boto3) |

### Authorization

| Service | Required Permissions |
|---------|---------------------|
| **AWS Secrets Manager** | `secretsmanager:GetSecretValue` |
| **AWS DynamoDB** | `dynamodb:*` on table |
| **AWS S3** | `s3:GetObject`, `s3:PutObject`, `s3:DeleteObject` |
| **Microsoft Graph** | Application permissions (not delegated) |

### Secrets Management

- **Never hardcode credentials** in source code
- Store all secrets in AWS Secrets Manager
- Certificate content stored as escaped string in secret
- Access keys managed via IAM roles (preferred) or credentials file

### Data Protection

| Data Type | Protection |
|-----------|------------|
| Credentials | Encrypted in Secrets Manager |
| Transcripts | Encrypted at rest in S3 (SSE) |
| DynamoDB records | Encrypted at rest (AWS managed) |
| Network traffic | TLS 1.2+ for all API calls |

### Security Best Practices

1. **Principle of Least Privilege**: Grant minimal required permissions
2. **Secret Rotation**: Rotate Azure AD certificates periodically
3. **Audit Logging**: Enable CloudTrail for AWS API calls
4. **Network Security**: Run in VPC with appropriate security groups
5. **Input Validation**: Sanitize meeting subjects before using in filenames

---

## 21. Testing

### Verification Scripts

The module includes comprehensive verification utilities:

```powershell
# Verify Secrets Manager access
python -m transcript_pipeline.verify.verify_secrets

# Verify all transcript components
python -m transcript_pipeline.verify.transcript.verify_all

# Verify all chat components
python -m transcript_pipeline.verify.chat.verify_all
```

### Manual Testing

```powershell
# Test with limited scope
python -m transcript_pipeline.main_v2 run --full --limit 1

# Verify results
python -m transcript_pipeline.main_v2 status
```

### Test Commands

| Test Type | Command |
|-----------|---------|
| Configuration | `python -m transcript_pipeline.verify.verify_secrets` |
| DynamoDB | `python -m transcript_pipeline.verify.transcript.verify_dynamodb` |
| S3 | `python -m transcript_pipeline.verify.transcript.verify_s3` |
| Full integration | `python -m transcript_pipeline.main_v2 verify` |

### Test Data Cleanup

```powershell
# Clear DynamoDB test records (use with caution!)
python -m transcript_pipeline.verify.transcript.cleanup_dynamodb

# Clear S3 test files (use with caution!)
python -m transcript_pipeline.verify.transcript.cleanup_s3
```

### Coverage Recommendations

| Component | Coverage Target |
|-----------|-----------------|
| VTT Parser | 100% |
| DOCX Converter | 90% |
| DynamoDB Tracker | 85% |
| S3 Storage | 85% |
| Pipeline Orchestrator | 80% |

---

## 22. Deployment

### Deployment Models

| Model | Description |
|-------|-------------|
| **Scheduled Job** | AWS Lambda + EventBridge, or cron on EC2/ECS |
| **API Server** | FastAPI with pipeline endpoints |
| **Container** | Docker container for portability |

### Infrastructure Requirements

| Component | Requirement |
|-----------|-------------|
| Compute | Python 3.9+ runtime |
| Memory | Minimum 512 MB |
| Network | Outbound HTTPS to Microsoft and AWS |
| IAM | Role with appropriate permissions |

### Deployment Process

1. **Package Application**:
   ```powershell
   pip freeze > requirements.txt
   ```

2. **Deploy to Target**:
   - Copy source code
   - Install dependencies
   - Configure AWS credentials

3. **Schedule Execution**:
   - Set up cron or EventBridge rule
   - Example: Every hour for incremental sync

### Rollback Process

1. Revert to previous code version
2. Pipeline state in DynamoDB is preserved
3. Failed records will be automatically retried

---

## 23. Troubleshooting Guide

| Problem | Possible Cause | Resolution |
|---------|----------------|------------|
| **Authentication failed** | Invalid certificate | Regenerate and upload certificate to Azure AD |
| **No meetings found** | Wrong date range or user ID | Verify `GRAPH_USER_ID` and check date range |
| **Empty transcripts** | Meeting had no transcription | Skip - this is expected behavior |
| **404 on transcript** | Transcript was deleted | Marked as permanently failed |
| **S3 upload failed** | Bucket permissions | Check IAM policy for S3 permissions |
| **DynamoDB access denied** | Missing IAM permissions | Add DynamoDB permissions to IAM role |
| **Rate limited (429)** | Too many API calls | Pipeline automatically retries with backoff |
| **Unicode errors in S3** | Non-ASCII in meeting subject | Pipeline sanitizes automatically |
| **Pipeline stuck on PROCESSING** | Crashed during processing | Manual status update or wait for retry |

### Diagnostic Commands

```powershell
# Check configuration
python -m transcript_pipeline.config

# Verify all connections
python -m transcript_pipeline.main_v2 verify

# View current stats
python -m transcript_pipeline.main_v2 status

# List failed records
python -c "from transcript_pipeline.dynamodb_tracker import *; from transcript_pipeline.config import *; t = DynamoDBTracker(Config()); print(t.get_failed_for_retry())"
```

---

## 24. Performance Considerations

### Bottlenecks

| Bottleneck | Impact | Mitigation |
|------------|--------|------------|
| Graph API rate limits | Throttled requests | Automatic backoff and retry |
| Large transcript downloads | Slow processing | Streaming not available |
| DynamoDB scan operations | Slow status queries | Use GSI for efficient queries |

### Scalability Concerns

| Concern | Limit | Mitigation |
|---------|-------|------------|
| Meetings per run | 100 (configurable) | Adjust `MEETINGS_FETCH_LIMIT` |
| DynamoDB throughput | Pay-per-request | Auto-scales |
| S3 storage | No practical limit | Monitor costs |

### Optimization Techniques

1. **Incremental Sync**: Reduces API calls from ~200+ to ~10 per hour
2. **GSI Queries**: Efficient status-based queries
3. **Lazy Component Loading**: Components initialized only when needed
4. **Caching**: Configuration cached for session lifetime

### Performance Metrics

| Metric | Typical Value |
|--------|---------------|
| Full sync (90 days, 50 meetings) | 5-10 minutes |
| Incremental sync (5 new meetings) | 30-60 seconds |
| Single transcript processing | 5-15 seconds |

---

## 25. Assumptions and Limitations

### Assumptions

| Assumption | Impact if False |
|------------|-----------------|
| User has calendar read permissions | No meetings discovered |
| Transcription enabled on meetings | No transcripts available |
| Azure AD app has admin consent | Authentication fails |
| AWS credentials available | Pipeline cannot connect to AWS |
| Network access to Graph API | Pipeline cannot extract data |

### Known Limitations

| Limitation | Description |
|------------|-------------|
| Single user scope | Only processes one user's calendar |
| No real-time sync | Batch processing only |
| VTT format only | No audio/video processing |
| 90-day lookback default | Configurable but limited by Graph API |
| No meeting recording | Transcripts only, not video |

### Technical Debt

| Item | Description | Priority |
|------|-------------|----------|
| Duplicate DynamoDB code | Transcript/Chat trackers share logic | Medium |
| No unit tests | Verification scripts only | High |
| Hardcoded retry delays | Should be configurable | Low |
| No pagination for large result sets | May miss meetings | Medium |

---

## 26. Future Improvements

### Architecture Improvements

1. **Unified Pipeline Base Class**: Reduce code duplication between transcript and chat pipelines
2. **Async Processing**: Use asyncio for concurrent transcript downloads
3. **Plugin Architecture**: Allow custom converters for different output formats

### Feature Improvements

1. **Multi-User Support**: Process multiple users' calendars
2. **Real-Time Streaming**: Webhook-based near-real-time extraction
3. **Custom Filters**: Filter by meeting organizer, attendees, etc.
4. **Output Formats**: Add PDF, Markdown, JSON export options

### Technical Improvements

1. **Unit Test Suite**: Comprehensive pytest test coverage
2. **Metrics Dashboard**: CloudWatch dashboard for monitoring
3. **Dead Letter Queue**: SQS for failed record processing
4. **Parallel Processing**: Process multiple transcripts concurrently

---

## 27. Frequently Asked Questions

### General Questions

**Q: How often should the pipeline run?**
A: Hourly incremental sync is recommended for near-real-time coverage without excessive API calls.

**Q: What happens if a meeting doesn't have a transcript?**
A: The meeting is simply skipped - no error is recorded.

**Q: Can I reprocess a completed transcript?**
A: Delete the record from DynamoDB and run the pipeline again.

### Technical Questions

**Q: Why use certificates instead of client secrets?**
A: Certificates are more secure and don't expire as frequently as client secrets.

**Q: How do I handle Graph API rate limits?**
A: The pipeline automatically handles rate limits with exponential backoff.

**Q: Can I run the transcript and chat pipelines simultaneously?**
A: Yes, they use separate metadata records and don't interfere with each other.

### Troubleshooting Questions

**Q: Why are some transcripts marked as PERMANENTLY_FAILED?**
A: They failed 3 times (max retries). Check error_message in DynamoDB for details.

**Q: Why is my incremental sync processing old meetings?**
A: The buffer hours setting causes overlap. This is intentional to prevent missing meetings.

**Q: How do I reset the pipeline state?**
A: Use the cleanup scripts to delete DynamoDB records, then run `--full` sync.

---

## 28. Glossary

| Term | Definition |
|------|------------|
| **VTT** | Video Text Track - subtitle/transcript format used by Teams |
| **MSAL** | Microsoft Authentication Library - handles Azure AD auth |
| **Graph API** | Microsoft's unified API for M365 services |
| **Incremental Sync** | Processing only new data since last run |
| **Full Sync** | Processing all data within lookback period |
| **GSI** | Global Secondary Index - DynamoDB query optimization |
| **Lookback Period** | How far back to fetch historical data |
| **Buffer Hours** | Safety overlap for incremental sync |
| **Transcript** | Text representation of meeting speech |
| **Chat** | Text messages sent during a meeting |
| **Record Type** | Distinguishes TRANSCRIPT from CHAT in shared table |
| **Pipeline Metadata** | Run history stored in DynamoDB |

---

## 29. Ownership and Support

### Team Ownership

| Role | Responsibility |
|------|----------------|
| **AI Platform Team** | Pipeline development and maintenance |
| **DevOps Team** | Infrastructure and scheduling |
| **Security Team** | Credential management and compliance |

### Support Process

1. **Check Documentation**: Review this README and API test guides
2. **Run Verification**: Execute `verify` commands to diagnose
3. **Check Logs**: Review pipeline output for errors
4. **Escalate**: Contact AI Platform Team with:
   - Error messages
   - Pipeline run logs
   - DynamoDB record details

### Escalation Path

1. **L1 Support**: Self-service troubleshooting
2. **L2 Support**: AI Platform Team (pipeline issues)
3. **L3 Support**: Microsoft Support (Graph API issues)

---

## 30. Quick Start Guide

### 5-Minute Setup

```powershell
# 1. Navigate to project
cd "c:\path\to\agentic-colleague-v2"

# 2. Activate virtual environment
.\venv\Scripts\Activate.ps1

# 3. Verify setup (should all pass)
python -m transcript_pipeline.main_v2 verify

# 4. Run first sync (limited to 5 meetings)
python -m transcript_pipeline.main_v2 run --full --limit 5

# 5. Check results
python -m transcript_pipeline.main_v2 status
```

### Common Operations

| Task | Command |
|------|---------|
| Check status | `python -m transcript_pipeline.main_v2 status` |
| Run incremental sync | `python -m transcript_pipeline.main_v2 run` |
| Run full sync | `python -m transcript_pipeline.main_v2 run --full` |
| Verify connections | `python -m transcript_pipeline.main_v2 verify` |

### Next Steps

1. ✅ Complete Quick Start above
2. 📖 Read [API_TEST_GUIDE.md](API_TEST_GUIDE.md) for API testing
3. 🔧 Configure scheduled runs for production
4. 📊 Set up monitoring and alerting

---

## Document Information

| Attribute | Value |
|-----------|-------|
| **Created** | August 2026 |
| **Author** | AI Platform Team |
| **Version** | 2.0 |
| **Status** | Production |

---

*This README was generated to provide comprehensive documentation for the Transcript Pipeline module. For questions or improvements, contact the AI Platform Team.*
