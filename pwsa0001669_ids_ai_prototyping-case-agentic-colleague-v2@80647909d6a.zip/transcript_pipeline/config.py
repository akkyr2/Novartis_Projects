"""
Centralized configuration module for the Transcript Pipeline.

Fetches all configuration from AWS Secrets Manager.
This is the single source of truth for all pipeline configuration.

Usage:
    from config import Config
    
    config = Config()
    tenant_id = config.azure_tenant_id
    bucket_name = config.s3_bucket_name
    
    # Or access the raw config dict
    raw_config = config.get_all()
"""

import json
import logging
import os
import sys
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Optional

import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from dotenv import load_dotenv

# Load .env file for local development (optional overrides)
load_dotenv()


# =============================================================================
# LOGGING SETUP
# =============================================================================

def setup_logging(level: str = "INFO") -> logging.Logger:
    """
    Set up logging configuration for the pipeline.
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        
    Returns:
        logging.Logger: Configured logger instance
    """
    log_level = getattr(logging, level.upper(), logging.INFO)
    
    # Create logger
    logger = logging.getLogger("transcript_pipeline")
    logger.setLevel(log_level)
    
    # Avoid adding handlers multiple times
    if not logger.handlers:
        # Console handler with formatting
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(log_level)
        
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    return logger


# =============================================================================
# DEFAULT VALUES
# =============================================================================

DEFAULTS = {
    # AWS Configuration
    "AWS_REGION": "us-east-1",
    "S3_BUCKET_NAME": "ids-aini-prototype-ai-analytics",
    "S3_PREFIX": "Agentic-Colleague-synthetic/meetings/",  # Base folder for meetings data
    "DYNAMODB_TABLE_NAME": "AgenticColleague_MeetingTracker",
    
    # Pipeline Settings
    "MAX_RETRY_ATTEMPTS": "3",
    "MEETINGS_FETCH_LIMIT": "100",
    "LOG_LEVEL": "INFO",
    
    # Incremental Pipeline Settings (for main_v2.py)
    "DEFAULT_LOOKBACK_DAYS": "90",           # Days to look back on first full sync
    "INCREMENTAL_BUFFER_HOURS": "1",         # Buffer hours for incremental runs
    "ENABLE_AUTO_RETRY": "true",             # Auto-retry failed transcripts
    
    # Graph API
    "GRAPH_BASE_URL": "https://graph.microsoft.com/v1.0",
}

# Secret Manager configuration (can be overridden by environment variables)
SECRET_NAME = os.getenv("SECRET_NAME", "agentic-colleague/graph-api-config")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")


# =============================================================================
# SECRETS MANAGER FUNCTIONS
# =============================================================================

@lru_cache(maxsize=1)
def _fetch_secrets_from_aws() -> dict:
    """
    Fetch configuration from AWS Secrets Manager.
    
    Results are cached to avoid multiple API calls within the same session.
    
    Returns:
        dict: Configuration dictionary with all settings
        
    Raises:
        ConfigurationError: If unable to connect to Secrets Manager or retrieve secret
    """
    try:
        # Create Secrets Manager client
        client = boto3.client("secretsmanager", region_name=AWS_REGION)
        
        # Retrieve the secret
        response = client.get_secret_value(SecretId=SECRET_NAME)
        
        # Parse the secret value
        if "SecretString" in response:
            secret_data = json.loads(response["SecretString"])
        else:
            raise ConfigurationError("Secret is binary, expected JSON string")
        
        # Merge with defaults (secret values take precedence)
        config = {**DEFAULTS, **secret_data}
        
        return config
        
    except NoCredentialsError:
        raise ConfigurationError(
            "No AWS credentials found. "
            "Ensure AWS credentials are configured (environment, ~/.aws/credentials, or IAM role)"
        )
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        if error_code == "ResourceNotFoundException":
            raise ConfigurationError(f"Secret '{SECRET_NAME}' not found in Secrets Manager")
        elif error_code == "AccessDeniedException":
            raise ConfigurationError(
                f"Access denied to secret '{SECRET_NAME}'. "
                "Check IAM permissions for secretsmanager:GetSecretValue"
            )
        else:
            raise ConfigurationError(f"Error retrieving secret: {error_code} - {e}")
    except json.JSONDecodeError:
        raise ConfigurationError("Secret value is not valid JSON")


def clear_config_cache():
    """Clear the cached configuration to force a fresh fetch."""
    _fetch_secrets_from_aws.cache_clear()


# =============================================================================
# CUSTOM EXCEPTIONS
# =============================================================================

class ConfigurationError(Exception):
    """Raised when configuration cannot be loaded or is invalid."""
    pass


class GraphAPIError(Exception):
    """Raised when Graph API operations fail."""
    pass


class DynamoDBError(Exception):
    """Raised when DynamoDB operations fail."""
    pass


class S3StorageError(Exception):
    """Raised when S3 storage operations fail."""
    pass


class TranscriptProcessingError(Exception):
    """Raised when transcript processing fails."""
    pass


# =============================================================================
# CONFIGURATION CLASS
# =============================================================================

@dataclass
class Config:
    """
    Configuration container for the Transcript Pipeline.
    
    Loads all configuration from AWS Secrets Manager and provides
    type-safe access to configuration values.
    
    Usage:
        config = Config()
        print(config.azure_tenant_id)
        print(config.s3_bucket_name)
    """
    
    _config_data: dict = field(default_factory=dict, repr=False)
    _logger: logging.Logger = field(default=None, repr=False)
    
    def __post_init__(self):
        """Initialize configuration by fetching from Secrets Manager."""
        self._config_data = _fetch_secrets_from_aws()
        self._logger = setup_logging(self.log_level)
        self._logger.debug("Configuration loaded successfully from Secrets Manager")
    
    # -------------------------------------------------------------------------
    # Azure AD / Graph API Configuration
    # -------------------------------------------------------------------------
    
    @property
    def azure_tenant_id(self) -> str:
        """Azure AD Tenant ID."""
        return self._config_data.get("AZURE_TENANT_ID", "")
    
    @property
    def azure_client_id(self) -> str:
        """Azure AD Application (Client) ID."""
        return self._config_data.get("AZURE_CLIENT_ID", "")
    
    @property
    def azure_cert_thumbprint(self) -> str:
        """Azure AD Certificate Thumbprint."""
        return self._config_data.get("AZURE_CERT_THUMBPRINT", "")
    
    @property
    def azure_cert_content(self) -> Optional[str]:
        """Azure AD Certificate PEM content (stored in Secrets Manager)."""
        return self._config_data.get("AZURE_CERT_CONTENT")
    
    @property
    def azure_cert_path(self) -> Optional[str]:
        """Azure AD Certificate file path (alternative to cert_content)."""
        return self._config_data.get("AZURE_CERT_PATH")
    
    @property
    def graph_user_id(self) -> str:
        """Target user ID for Graph API operations."""
        return self._config_data.get("GRAPH_USER_ID", "")
    
    @property
    def graph_base_url(self) -> str:
        """Microsoft Graph API base URL."""
        return self._config_data.get("GRAPH_BASE_URL", DEFAULTS["GRAPH_BASE_URL"])
    
    # -------------------------------------------------------------------------
    # AWS Configuration
    # -------------------------------------------------------------------------
    
    @property
    def aws_region(self) -> str:
        """AWS Region for all services."""
        return self._config_data.get("AWS_REGION", DEFAULTS["AWS_REGION"])
    
    @property
    def s3_bucket_name(self) -> str:
        """S3 bucket name for storing transcripts."""
        return self._config_data.get("S3_BUCKET_NAME", DEFAULTS["S3_BUCKET_NAME"])
    
    @property
    def s3_prefix(self) -> str:
        """S3 prefix (folder path) for transcripts."""
        prefix = self._config_data.get("S3_PREFIX", DEFAULTS["S3_PREFIX"])
        # Ensure prefix ends with /
        if prefix and not prefix.endswith("/"):
            prefix += "/"
        return prefix
    
    @property
    def dynamodb_table_name(self) -> str:
        """DynamoDB table name for tracking transcripts."""
        return self._config_data.get("DYNAMODB_TABLE_NAME", DEFAULTS["DYNAMODB_TABLE_NAME"])
    
    # -------------------------------------------------------------------------
    # Pipeline Settings
    # -------------------------------------------------------------------------
    
    @property
    def max_retry_attempts(self) -> int:
        """Maximum retry attempts for failed transcripts."""
        return int(self._config_data.get("MAX_RETRY_ATTEMPTS", DEFAULTS["MAX_RETRY_ATTEMPTS"]))
    
    @property
    def meetings_fetch_limit(self) -> int:
        """Maximum number of meetings to fetch per run."""
        return int(self._config_data.get("MEETINGS_FETCH_LIMIT", DEFAULTS["MEETINGS_FETCH_LIMIT"]))
    
    @property
    def log_level(self) -> str:
        """Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)."""
        return self._config_data.get("LOG_LEVEL", DEFAULTS["LOG_LEVEL"])
    
    @property
    def default_lookback_days(self) -> int:
        """Number of days to look back on first full sync."""
        return int(self._config_data.get("DEFAULT_LOOKBACK_DAYS", DEFAULTS["DEFAULT_LOOKBACK_DAYS"]))
    
    @property
    def incremental_buffer_hours(self) -> int:
        """Buffer hours to subtract from last run time for safety margin."""
        return int(self._config_data.get("INCREMENTAL_BUFFER_HOURS", DEFAULTS["INCREMENTAL_BUFFER_HOURS"]))
    
    @property
    def enable_auto_retry(self) -> bool:
        """Whether to auto-retry failed transcripts on incremental runs."""
        value = self._config_data.get("ENABLE_AUTO_RETRY", DEFAULTS["ENABLE_AUTO_RETRY"])
        return str(value).lower() in ("true", "1", "yes")
    
    @property
    def logger(self) -> logging.Logger:
        """Get the configured logger instance."""
        if self._logger is None:
            self._logger = setup_logging(self.log_level)
        return self._logger
    
    # -------------------------------------------------------------------------
    # Helper Methods
    # -------------------------------------------------------------------------
    
    def get_all(self) -> dict:
        """Get all configuration as a dictionary."""
        return self._config_data.copy()
    
    def get(self, key: str, default: str = None) -> str:
        """
        Get a specific configuration value by key.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Configuration value
        """
        return self._config_data.get(key, default or DEFAULTS.get(key))
    
    def validate(self) -> bool:
        """
        Validate that all required configuration values are present.
        
        Returns:
            bool: True if all required config is present
            
        Raises:
            ConfigurationError: If required configuration is missing
        """
        required_keys = [
            "AZURE_TENANT_ID",
            "AZURE_CLIENT_ID",
            "AZURE_CERT_THUMBPRINT",
            "GRAPH_USER_ID",
        ]
        
        missing_keys = []
        for key in required_keys:
            if not self._config_data.get(key):
                missing_keys.append(key)
        
        # Check that either cert content or cert path is provided
        if not self.azure_cert_content and not self.azure_cert_path:
            missing_keys.append("AZURE_CERT_CONTENT or AZURE_CERT_PATH")
        
        if missing_keys:
            raise ConfigurationError(
                f"Missing required configuration: {', '.join(missing_keys)}"
            )
        
        return True
    
    def print_summary(self, mask_sensitive: bool = True):
        """
        Print a summary of the current configuration.
        
        Args:
            mask_sensitive: Whether to mask sensitive values (default True)
        """
        def mask_value(value: str, show_chars: int = 4) -> str:
            """Mask a sensitive value."""
            if not value or len(value) <= show_chars * 2:
                return "****"
            return f"{value[:show_chars]}...{value[-show_chars:]}"
        
        sensitive_keys = [
            "AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CERT_THUMBPRINT",
            "GRAPH_USER_ID"
        ]
        
        print("\n" + "=" * 60)
        print("TRANSCRIPT PIPELINE CONFIGURATION")
        print("=" * 60)
        print(f"Secret Name: {SECRET_NAME}")
        print(f"AWS Region: {AWS_REGION}")
        print("-" * 60)
        
        # Group by category
        categories = {
            "Azure AD / Graph API": [
                "AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CERT_THUMBPRINT",
                "AZURE_CERT_PATH", "AZURE_CERT_CONTENT", "GRAPH_USER_ID", "GRAPH_BASE_URL"
            ],
            "AWS Services": [
                "AWS_REGION", "S3_BUCKET_NAME", "S3_PREFIX", "DYNAMODB_TABLE_NAME"
            ],
            "Pipeline Settings": [
                "MAX_RETRY_ATTEMPTS", "MEETINGS_FETCH_LIMIT", "LOG_LEVEL"
            ]
        }
        
        for category, keys in categories.items():
            print(f"\n📌 {category}")
            for key in keys:
                value = self._config_data.get(key, "N/A")
                if key == "AZURE_CERT_CONTENT" and value and value != "N/A":
                    print(f"   {key}: [PEM CERTIFICATE - {len(str(value))} chars]")
                elif mask_sensitive and key in sensitive_keys and value and value != "N/A":
                    print(f"   {key}: {mask_value(str(value))}")
                else:
                    print(f"   {key}: {value}")
        
        print("\n" + "=" * 60)


# =============================================================================
# MODULE-LEVEL CONVENIENCE FUNCTIONS
# =============================================================================

_config_instance: Optional[Config] = None


def get_config() -> Config:
    """
    Get the singleton Config instance.
    
    Returns:
        Config: Configuration instance
    """
    global _config_instance
    if _config_instance is None:
        _config_instance = Config()
    return _config_instance


def get_logger() -> logging.Logger:
    """
    Get the configured logger instance.
    
    Returns:
        logging.Logger: Logger instance
    """
    return get_config().logger


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    try:
        config = Config()
        config.print_summary()
        config.validate()
        print("\n✅ Configuration is valid!")
    except ConfigurationError as e:
        print(f"\n❌ Configuration Error: {e}")
        sys.exit(1)
