"""
Meeting Chat Pipeline Orchestrator (main_chat.py).

This pipeline fetches chat messages from Teams meetings via Microsoft Graph API
and stores them as DOCX files in S3. It follows the same incremental sync pattern
as main_v2.py for transcripts.

Features:
- Fetches chat messages from Teams meetings
- Converts chat to formatted DOCX documents
- Uploads to S3 with organized folder structure
- Tracks processing state in DynamoDB
- Supports incremental sync (only new meetings since last run)

CLI (run from project root):
    # ============================================================
    # VERIFY & STATUS
    # ============================================================
    python -m transcript_pipeline.main_chat verify           # Verify all components
    python -m transcript_pipeline.main_chat status           # Show stats including last run info
    
    # ============================================================
    # FULL SYNC - First run to fetch all historical meeting chats
    # ============================================================
    python -m transcript_pipeline.main_chat run --full                # Full sync (last 90 days)
    python -m transcript_pipeline.main_chat run --full --limit 5      # Full sync with limit
    python -m transcript_pipeline.main_chat run --full --no-retry     # Full sync without auto-retry
    
    # ============================================================
    # INCREMENTAL - Only fetch new meeting chats since last run
    # ============================================================
    python -m transcript_pipeline.main_chat run                       # Incremental (default mode)
    python -m transcript_pipeline.main_chat run --limit 10            # Incremental with limit
    python -m transcript_pipeline.main_chat run --no-retry            # Incremental without retry
    python -m transcript_pipeline.main_chat run --incremental         # Explicit incremental flag
    
    # ============================================================
    # SINCE DATE - Fetch from specific date
    # ============================================================
    python -m transcript_pipeline.main_chat run --since "2026-07-01"           # Since specific date
    python -m transcript_pipeline.main_chat run --since "2026-07-15" --limit 5 # Since date with limit
    
    # ============================================================
    # MINIMUM MESSAGES FILTER
    # ============================================================
    python -m transcript_pipeline.main_chat run --min-messages 5      # Only meetings with 5+ messages
    
    # ============================================================
    # HELP
    # ============================================================
    python -m transcript_pipeline.main_chat --help
    python -m transcript_pipeline.main_chat run --help

Recommended Testing Order:
    1. python -m transcript_pipeline.main_chat verify              # Check all connections
    2. python -m transcript_pipeline.main_chat status              # See current state
    3. python -m transcript_pipeline.main_chat run --full --limit 5  # Test full sync (small)
    4. python -m transcript_pipeline.main_chat status              # Verify metadata saved
    5. python -m transcript_pipeline.main_chat run --limit 5       # Test incremental
    6. python -m transcript_pipeline.main_chat run --since "2026-07-20"  # Test since-date mode
"""

import sys
import os
import time
import argparse
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import List, Optional

# ============================================================================
# PATH SETUP FOR IMPORTS
# ============================================================================
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

os.chdir(_PROJECT_ROOT)

from transcript_pipeline.config import (
    Config,
    ConfigurationError,
    GraphAPIError,
    DynamoDBError,
    S3StorageError,
    TranscriptProcessingError,
    get_logger,
)
from transcript_pipeline.chat_client import ChatClient, MeetingChatInfo, ChatMessage
from transcript_pipeline.chat_dynamodb_tracker import ChatDynamoDBTracker, ChatStatus, ChatRecord
from transcript_pipeline.chat_s3_storage import ChatS3Storage


# =============================================================================
# PIPELINE RESULT DATA CLASS
# =============================================================================

@dataclass
class ChatPipelineResult:
    """Result of a chat pipeline run."""
    
    total_meetings: int = 0
    total_messages: int = 0
    processed: int = 0
    skipped: int = 0
    failed: int = 0
    retried: int = 0
    errors: List[str] = None
    duration_seconds: float = 0.0
    mode: str = "incremental"
    start_datetime: Optional[datetime] = None
    end_datetime: Optional[datetime] = None
    
    def __post_init__(self):
        if self.errors is None:
            self.errors = []
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate percentage."""
        total = self.processed + self.failed
        if total == 0:
            return 100.0
        return round((self.processed / total) * 100, 1)
    
    def print_summary(self):
        """Print result summary."""
        print("\n" + "=" * 60)
        print("CHAT PIPELINE RUN SUMMARY")
        print("=" * 60)
        print(f"  🔄 Mode:             {self.mode.upper()}")
        if self.start_datetime:
            print(f"  📅 Date Range:       {self.start_datetime.strftime('%Y-%m-%d %H:%M')} to {self.end_datetime.strftime('%Y-%m-%d %H:%M') if self.end_datetime else 'now'}")
        print(f"  ⏱️  Duration:         {self.duration_seconds:.1f} seconds")
        print(f"  📅 Meetings found:   {self.total_meetings}")
        print(f"  💬 Total messages:   {self.total_messages}")
        print(f"  ✅ Processed:        {self.processed}")
        print(f"  🔄 Retried:          {self.retried}")
        print(f"  ⏭️  Skipped:          {self.skipped}")
        print(f"  ❌ Failed:           {self.failed}")
        print(f"  📊 Success rate:     {self.success_rate}%")
        
        if self.errors:
            print("\n  Errors:")
            for error in self.errors[:5]:
                print(f"    • {error[:80]}...")
            if len(self.errors) > 5:
                print(f"    ... and {len(self.errors) - 5} more")
        
        print("=" * 60)


# =============================================================================
# MEETING CHAT PIPELINE CLASS
# =============================================================================

class MeetingChatPipeline:
    """
    Pipeline orchestrator for meeting chat extraction.
    
    Supports three run modes:
    - full: Fetch all meeting chats (first run or reset)
    - incremental: Only fetch since last successful run
    - since: Fetch from specific date
    """
    
    def __init__(self, config: Config = None):
        """
        Initialize the pipeline.
        
        Args:
            config: Optional Config instance (creates new one if not provided)
        """
        self.config = config or Config()
        self.logger = self.config.logger
        
        # Components will be initialized lazily
        self._chat_client: Optional[ChatClient] = None
        self._tracker: Optional[ChatDynamoDBTracker] = None
        self._storage: Optional[ChatS3Storage] = None
    
    # -------------------------------------------------------------------------
    # COMPONENT INITIALIZATION (Lazy Loading)
    # -------------------------------------------------------------------------
    
    @property
    def chat_client(self) -> ChatClient:
        """Get or create Chat API client."""
        if self._chat_client is None:
            self.logger.info("Initializing Chat API client...")
            self._chat_client = ChatClient(self.config)
        return self._chat_client
    
    @property
    def tracker(self) -> ChatDynamoDBTracker:
        """Get or create DynamoDB tracker."""
        if self._tracker is None:
            self.logger.info("Initializing Chat DynamoDB tracker...")
            self._tracker = ChatDynamoDBTracker(self.config)
        return self._tracker
    
    @property
    def storage(self) -> ChatS3Storage:
        """Get or create S3 storage."""
        if self._storage is None:
            self.logger.info("Initializing Chat S3 storage...")
            self._storage = ChatS3Storage(self.config)
        return self._storage
    
    # -------------------------------------------------------------------------
    # DATE RANGE CALCULATION
    # -------------------------------------------------------------------------
    
    def _calculate_date_range(
        self,
        mode: str,
        since_date: datetime = None,
    ) -> tuple:
        """
        Calculate the date range for fetching meetings based on mode.
        
        Args:
            mode: Run mode (full, incremental, since)
            since_date: Specific date for 'since' mode
            
        Returns:
            Tuple of (start_datetime, end_datetime)
        """
        end_datetime = datetime.now(timezone.utc)
        
        if mode == "full":
            lookback_days = self.config.default_lookback_days
            start_datetime = end_datetime - timedelta(days=lookback_days)
            self.logger.info(f"📅 Full sync mode: Looking back {lookback_days} days")
            
        elif mode == "since":
            if since_date is None:
                raise ValueError("since_date is required for 'since' mode")
            start_datetime = since_date
            if start_datetime.tzinfo is None:
                start_datetime = start_datetime.replace(tzinfo=timezone.utc)
            self.logger.info(f"📅 Since mode: Fetching from {start_datetime.isoformat()}")
            
        else:  # incremental
            last_run = self.tracker.get_last_successful_run()
            
            if last_run is None:
                lookback_days = self.config.default_lookback_days
                start_datetime = end_datetime - timedelta(days=lookback_days)
                self.logger.info(
                    f"📅 First incremental run detected - using lookback of {lookback_days} days"
                )
            else:
                buffer_hours = self.config.incremental_buffer_hours
                start_datetime = last_run - timedelta(hours=buffer_hours)
                self.logger.info(
                    f"📅 Incremental mode: From {start_datetime.isoformat()} "
                    f"(last run: {last_run.isoformat()}, buffer: {buffer_hours}h)"
                )
        
        return start_datetime, end_datetime
    
    # -------------------------------------------------------------------------
    # CHAT PROCESSING
    # -------------------------------------------------------------------------
    
    def _process_single_chat(
        self,
        meeting: MeetingChatInfo,
    ) -> bool:
        """
        Process a single meeting chat.
        
        Args:
            meeting: Meeting information with chat messages
            
        Returns:
            True if successful, False if failed
        """
        chat_id = meeting.chat_id
        
        try:
            # Step 1: Mark as processing in DynamoDB
            self.tracker.mark_processing(
                chat_id=chat_id,
                meeting_id=meeting.meeting_id,
                meeting_subject=meeting.subject,
                join_url=meeting.join_url,
                message_count=len(meeting.messages),
            )
            
            # Step 2: Validate messages
            if not meeting.messages:
                self.logger.warning(f"  ⚠️  No messages in chat: {meeting.subject}")
                self.tracker.mark_failed(
                    chat_id=chat_id,
                    error_message="No messages in chat",
                    increment_retry=False,
                )
                return False
            
            # Step 3: Upload to S3
            self.logger.info(f"  📤 Uploading {len(meeting.messages)} messages to S3...")
            s3_path = self.storage.upload_chat(
                messages=meeting.messages,
                chat_id=chat_id,
                meeting_subject=meeting.subject,
                meeting_date=meeting.start_datetime,
                meeting_id=meeting.meeting_id,
            )
            
            # Step 4: Mark as completed
            self.tracker.mark_completed(
                chat_id=chat_id,
                s3_path=s3_path,
            )
            
            return True
            
        except Exception as e:
            error_msg = str(e)[:500]
            self.logger.error(f"  ❌ Error processing chat: {error_msg}")
            
            try:
                self.tracker.mark_failed(
                    chat_id=chat_id,
                    error_message=error_msg,
                )
            except Exception as db_error:
                self.logger.error(f"  ❌ Error updating DynamoDB: {db_error}")
            
            return False
    
    # -------------------------------------------------------------------------
    # RETRY FAILED CHATS
    # -------------------------------------------------------------------------
    
    def _retry_failed_chats(self, result: ChatPipelineResult) -> int:
        """
        Retry previously failed chats.
        
        Args:
            result: ChatPipelineResult to update with retry stats
            
        Returns:
            Number of successfully retried chats
        """
        if not self.config.enable_auto_retry:
            self.logger.debug("Auto-retry is disabled")
            return 0
        
        failed_records = self.tracker.get_failed_for_retry()
        
        if not failed_records:
            return 0
        
        self.logger.info(f"\n🔄 Retrying {len(failed_records)} failed chat(s)...")
        
        retried_success = 0
        
        for record in failed_records:
            self.logger.info(f"\n🔄 Retrying: {record.meeting_subject[:50]}...")
            
            try:
                # Re-fetch the chat messages
                chat_id = record.chat_id
                messages = self.chat_client.get_all_chat_messages_paginated(
                    chat_id=chat_id,
                    max_messages=500,
                )
                
                if not messages:
                    self.logger.warning(f"  ⚠️  No messages found on retry")
                    result.failed += 1
                    continue
                
                # Create meeting info for processing
                meeting = MeetingChatInfo(
                    meeting_id=record.meeting_id,
                    chat_id=chat_id,
                    subject=record.meeting_subject,
                    join_url=record.join_url,
                    messages=messages,
                    total_message_count=len(messages),
                )
                
                success = self._process_single_chat(meeting)
                
                if success:
                    retried_success += 1
                    result.retried += 1
                else:
                    result.failed += 1
                    result.errors.append(f"Retry failed: {record.meeting_subject[:50]}")
                    
            except Exception as e:
                self.logger.error(f"  ❌ Error during retry: {e}")
                result.failed += 1
                result.errors.append(f"Retry error: {record.meeting_subject}: {e}")
        
        return retried_success
    
    # -------------------------------------------------------------------------
    # MAIN PIPELINE OPERATIONS
    # -------------------------------------------------------------------------
    
    def run(
        self,
        mode: str = "incremental",
        since_date: datetime = None,
        limit: int = None,
        retry_failed: bool = True,
        min_messages: int = 1,
    ) -> ChatPipelineResult:
        """
        Run the chat pipeline in the specified mode.
        
        Args:
            mode: Run mode - "full", "incremental", or "since"
            since_date: Specific date for "since" mode
            limit: Maximum number of meetings to process
            retry_failed: Whether to retry failed chats (default True)
            min_messages: Minimum messages required per meeting (default 1)
            
        Returns:
            ChatPipelineResult with statistics
        """
        start_time = time.time()
        result = ChatPipelineResult(mode=mode)
        
        self.logger.info("=" * 60)
        self.logger.info("STARTING MEETING CHAT PIPELINE")
        self.logger.info("=" * 60)
        self.logger.info(f"Mode: {mode.upper()}")
        
        try:
            # Step 1: Validate configuration
            self.logger.info("\n[1/5] Validating configuration...")
            self.config.validate()
            self.logger.info("  ✅ Configuration valid")
            
            # Step 2: Calculate date range
            self.logger.info("\n[2/5] Calculating date range...")
            start_datetime, end_datetime = self._calculate_date_range(mode, since_date)
            result.start_datetime = start_datetime
            result.end_datetime = end_datetime
            
            # Step 3: Fetch meetings with chats in date range
            self.logger.info("\n[3/5] Fetching meetings with chat messages...")
            meetings = self.chat_client.get_meetings_with_chats_in_range(
                start_datetime=start_datetime,
                end_datetime=end_datetime,
                limit=limit or self.config.meetings_fetch_limit,
                min_messages=min_messages,
            )
            
            result.total_meetings = len(meetings)
            result.total_messages = sum(m.total_message_count for m in meetings)
            
            if not meetings:
                self.logger.info("  ℹ️  No meetings with chat messages found in date range")
            
            # Step 4: Process each chat
            self.logger.info(f"\n[4/5] Processing {result.total_meetings} meeting chat(s)...")
            
            for meeting in meetings:
                self.logger.info(f"\n📅 Meeting: {meeting.subject}")
                self.logger.info(f"   Date: {meeting.start_datetime or 'Unknown'}")
                self.logger.info(f"   Messages: {meeting.total_message_count}")
                
                chat_id = meeting.chat_id
                
                # Check if should process
                if not self.tracker.should_process(chat_id):
                    self.logger.info(f"  ⏭️  Skipping (already processed)")
                    result.skipped += 1
                    continue
                
                # Check if this is a retry
                existing = self.tracker.get_record(chat_id)
                if existing and existing.status == ChatStatus.FAILED:
                    self.logger.info(f"  🔄 Re-processing failed chat (retry #{existing.retry_count + 1})")
                
                # Process the chat
                success = self._process_single_chat(meeting)
                
                if success:
                    result.processed += 1
                else:
                    result.failed += 1
                    result.errors.append(f"Failed: {meeting.subject[:50]}")
            
            # Step 5: Retry previously failed chats (if enabled)
            self.logger.info("\n[5/5] Checking for failed chats to retry...")
            if retry_failed:
                self._retry_failed_chats(result)
            
            # Update pipeline metadata
            # Add buffer hours to last_successful_run so that when the next run
            # calculates start_datetime = last_run - buffer, it gets the actual
            # end time of this run. This prevents re-fetching chats that were
            # already in the current run's time range.
            run_status = "SUCCESS" if result.failed == 0 else "PARTIAL"
            buffer_hours = self.config.incremental_buffer_hours
            adjusted_last_run = datetime.now(timezone.utc) + timedelta(hours=buffer_hours)
            self.tracker.update_pipeline_metadata(
                last_successful_run=adjusted_last_run,
                last_run_status=run_status,
                processed_count=result.processed,
                failed_count=result.failed,
            )
            
            self.logger.info("\n✅ Chat Pipeline complete!")
            
        except ConfigurationError as e:
            self.logger.error(f"Configuration error: {e}")
            result.errors.append(f"Configuration: {e}")
        except GraphAPIError as e:
            self.logger.error(f"Graph API error: {e}")
            result.errors.append(f"Graph API: {e}")
        except DynamoDBError as e:
            self.logger.error(f"DynamoDB error: {e}")
            result.errors.append(f"DynamoDB: {e}")
        except S3StorageError as e:
            self.logger.error(f"S3 error: {e}")
            result.errors.append(f"S3: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}")
            result.errors.append(f"Unexpected: {e}")
        
        result.duration_seconds = time.time() - start_time
        return result
    
    def show_status(self):
        """Show current processing statistics including pipeline metadata."""
        print("\n" + "=" * 60)
        print("MEETING CHAT PIPELINE STATUS")
        print("=" * 60)
        
        # Configuration summary
        print("\n📌 Configuration:")
        print(f"   AWS Region: {self.config.aws_region}")
        print(f"   S3 Bucket: {self.config.s3_bucket_name}")
        print(f"   S3 Prefix: {self.storage.prefix}")
        print(f"   DynamoDB Table: {self.tracker.table_name}")
        
        # Incremental settings
        print("\n🔄 Incremental Settings:")
        print(f"   Default Lookback Days: {self.config.default_lookback_days}")
        print(f"   Incremental Buffer Hours: {self.config.incremental_buffer_hours}")
        print(f"   Auto-Retry Enabled: {self.config.enable_auto_retry}")
        
        # Pipeline run history
        self.tracker.print_pipeline_metadata()
        
        # DynamoDB stats
        self.tracker.print_stats()
        
        # S3 stats
        storage_stats = self.storage.get_storage_stats()
        print("\n📦 S3 Storage (Chats):")
        print(f"   Total files: {storage_stats['total_files']}")
        print(f"   DOCX files: {storage_stats['docx_files']}")
        print(f"   Total size: {storage_stats['total_size_mb']} MB")
        
        print("\n" + "=" * 60)
    
    def verify(self) -> bool:
        """
        Verify all components are accessible.
        
        Returns:
            True if all verifications pass
        """
        print("\n" + "=" * 60)
        print("VERIFYING CHAT PIPELINE COMPONENTS")
        print("=" * 60)
        
        all_passed = True
        
        # 1. Configuration
        print("\n[1/4] Configuration...")
        try:
            self.config.validate()
            print("  ✅ Configuration valid")
            print(f"     Lookback days: {self.config.default_lookback_days}")
            print(f"     Buffer hours: {self.config.incremental_buffer_hours}")
        except Exception as e:
            print(f"  ❌ Configuration error: {e}")
            all_passed = False
        
        # 2. Graph API (Chat Client)
        print("\n[2/4] Graph API connection (Chat Client)...")
        try:
            _ = self.chat_client
            print("  ✅ Graph API authenticated")
        except Exception as e:
            print(f"  ❌ Graph API error: {e}")
            all_passed = False
        
        # 3. DynamoDB
        print("\n[3/4] DynamoDB connection...")
        try:
            stats = self.tracker.get_processing_stats()
            metadata = self.tracker.get_pipeline_metadata()
            print(f"  ✅ DynamoDB accessible (Table: {self.tracker.table_name})")
            print(f"     Total records: {stats['TOTAL']}")
            if metadata:
                print(f"     Last run: {metadata.get('last_successful_run', 'N/A')}")
            else:
                print(f"     Last run: No previous runs (first run)")
        except Exception as e:
            print(f"  ❌ DynamoDB error: {e}")
            all_passed = False
        
        # 4. S3
        print("\n[4/4] S3 connection...")
        try:
            stats = self.storage.get_storage_stats()
            print(f"  ✅ S3 accessible (Bucket: {self.config.s3_bucket_name})")
            print(f"     Prefix: {self.storage.prefix}")
            print(f"     Files in prefix: {stats['total_files']}")
        except Exception as e:
            print(f"  ❌ S3 error: {e}")
            all_passed = False
        
        print("\n" + "=" * 60)
        if all_passed:
            print("✅ ALL VERIFICATIONS PASSED")
        else:
            print("❌ SOME VERIFICATIONS FAILED")
        print("=" * 60)
        
        return all_passed


# =============================================================================
# CLI INTERFACE
# =============================================================================

def parse_date(date_str: str) -> datetime:
    """Parse a date string into a datetime object."""
    formats = [
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
    ]
    
    for fmt in formats:
        try:
            dt = datetime.strptime(date_str, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    
    raise ValueError(f"Could not parse date: {date_str}. Use format YYYY-MM-DD")


def create_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="meeting_chat_pipeline",
        description="Teams Meeting Chat Pipeline - Extract and Store Meeting Chats",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m main_chat run --full        # First run: fetch all historical meeting chats
  python -m main_chat run               # Incremental: only new since last run
  python -m main_chat run --since 2026-07-01  # Fetch from specific date
  python -m main_chat run --limit 10    # Limit number of meetings
  python -m main_chat run --min-messages 5  # Only meetings with 5+ messages
  python -m main_chat status            # Show processing statistics
  python -m main_chat verify            # Verify all components
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run the chat pipeline")
    run_parser.add_argument(
        "--full", "-f",
        action="store_true",
        help="Full sync mode: fetch all meeting chats (use for first run or reset)"
    )
    run_parser.add_argument(
        "--incremental", "-i",
        action="store_true",
        help="Incremental mode: only fetch since last run (default)"
    )
    run_parser.add_argument(
        "--since", "-s",
        type=str,
        help="Fetch meeting chats since specific date (format: YYYY-MM-DD)"
    )
    run_parser.add_argument(
        "--limit", "-l",
        type=int,
        help="Maximum number of meetings to process"
    )
    run_parser.add_argument(
        "--min-messages", "-m",
        type=int,
        default=1,
        help="Minimum number of messages required per meeting (default: 1)"
    )
    run_parser.add_argument(
        "--no-retry",
        action="store_true",
        help="Disable auto-retry of failed chats"
    )
    
    # Status command
    subparsers.add_parser("status", help="Show processing statistics")
    
    # Verify command
    subparsers.add_parser("verify", help="Verify all components are accessible")
    
    return parser


def main():
    """Main CLI entry point."""
    parser = create_parser()
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        pipeline = MeetingChatPipeline()
        
        if args.command == "run":
            # Determine mode
            if args.full:
                mode = "full"
            elif args.since:
                mode = "since"
            else:
                mode = "incremental"
            
            # Parse since date if provided
            since_date = None
            if args.since:
                since_date = parse_date(args.since)
            
            result = pipeline.run(
                mode=mode,
                since_date=since_date,
                limit=args.limit,
                retry_failed=not args.no_retry,
                min_messages=args.min_messages,
            )
            result.print_summary()
            
            # Exit with error code if any failures
            if result.failed > 0:
                sys.exit(1)
                
        elif args.command == "status":
            pipeline.show_status()
            
        elif args.command == "verify":
            success = pipeline.verify()
            sys.exit(0 if success else 1)
            
    except KeyboardInterrupt:
        print("\n\n⚠️  Pipeline interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
