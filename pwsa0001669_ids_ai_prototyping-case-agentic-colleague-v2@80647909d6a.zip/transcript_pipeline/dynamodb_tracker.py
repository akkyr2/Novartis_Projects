"""
DynamoDB Tracker for the Transcript Pipeline.

Manages transcript processing state in DynamoDB with support for:
- Tracking transcript processing status (PENDING, PROCESSING, COMPLETED, FAILED, PERMANENTLY_FAILED)
- Retry logic with configurable max attempts
- Querying for unprocessed or failed transcripts
- Auto-creating the table if it doesn't exist

Usage:
    from dynamodb_tracker import DynamoDBTracker
    from config import Config
    
    config = Config()
    tracker = DynamoDBTracker(config)
    
    # Check if transcript is already processed
    if not tracker.is_processed(transcript_id):
        tracker.mark_processing(transcript_id, meeting_id, subject, join_url)
        # ... process transcript ...
        tracker.mark_completed(transcript_id, s3_path)
"""

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from transcript_pipeline.config import Config, DynamoDBError


# =============================================================================
# CONSTANTS
# =============================================================================

# Record type identifier for transcripts (used in shared table)
RECORD_TYPE_TRANSCRIPT = "TRANSCRIPT"

# Special record ID for transcript pipeline metadata
TRANSCRIPT_PIPELINE_METADATA_ID = "__TRANSCRIPT_PIPELINE_METADATA__"

# Keep for backward compatibility
PIPELINE_METADATA_ID = TRANSCRIPT_PIPELINE_METADATA_ID


# =============================================================================
# ENUMS AND DATA CLASSES
# =============================================================================

class TranscriptStatus(Enum):
    """Transcript processing status."""
    
    PENDING = "PENDING"                       # Discovered but not yet processed
    PROCESSING = "PROCESSING"                 # Currently being processed
    COMPLETED = "COMPLETED"                   # Successfully processed and uploaded
    FAILED = "FAILED"                         # Failed, can be retried
    PERMANENTLY_FAILED = "PERMANENTLY_FAILED" # Failed after max retries


@dataclass
class TranscriptRecord:
    """Represents a transcript tracking record in DynamoDB."""
    
    transcript_id: str
    meeting_id: str
    join_url: str
    meeting_subject: str
    status: TranscriptStatus
    record_type: str = RECORD_TYPE_TRANSCRIPT
    retry_count: int = 0
    max_retries: int = 3
    s3_path: Optional[str] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    processed_at: Optional[str] = None
    
    @classmethod
    def from_dynamodb_item(cls, item: dict) -> "TranscriptRecord":
        """Create TranscriptRecord from DynamoDB item."""
        # Support both old (transcript_id) and new (record_id) schema
        record_id = item.get("record_id", {}).get("S") or item.get("transcript_id", {}).get("S", "")
        return cls(
            transcript_id=record_id,
            meeting_id=item.get("meeting_id", {}).get("S", ""),
            join_url=item.get("join_url", {}).get("S", ""),
            meeting_subject=item.get("meeting_subject", {}).get("S", ""),
            status=TranscriptStatus(item.get("status", {}).get("S", "PENDING")),
            record_type=item.get("record_type", {}).get("S", RECORD_TYPE_TRANSCRIPT),
            retry_count=int(item.get("retry_count", {}).get("N", "0")),
            max_retries=int(item.get("max_retries", {}).get("N", "3")),
            s3_path=item.get("s3_path", {}).get("S"),
            error_message=item.get("error_message", {}).get("S"),
            created_at=item.get("created_at", {}).get("S"),
            updated_at=item.get("updated_at", {}).get("S"),
            processed_at=item.get("processed_at", {}).get("S"),
        )
    
    def to_dynamodb_item(self) -> dict:
        """Convert to DynamoDB item format."""
        item = {
            "record_id": {"S": self.transcript_id},
            "record_type": {"S": self.record_type},
            "meeting_id": {"S": self.meeting_id},
            "join_url": {"S": self.join_url},
            "meeting_subject": {"S": self.meeting_subject},
            "status": {"S": self.status.value},
            "retry_count": {"N": str(self.retry_count)},
            "max_retries": {"N": str(self.max_retries)},
        }
        
        # Add optional fields
        if self.s3_path:
            item["s3_path"] = {"S": self.s3_path}
        if self.error_message:
            item["error_message"] = {"S": self.error_message}
        if self.created_at:
            item["created_at"] = {"S": self.created_at}
        if self.updated_at:
            item["updated_at"] = {"S": self.updated_at}
        if self.processed_at:
            item["processed_at"] = {"S": self.processed_at}
        
        return item
    
    @property
    def can_retry(self) -> bool:
        """Check if this record can be retried."""
        return (
            self.status == TranscriptStatus.FAILED 
            and self.retry_count < self.max_retries
        )
    
    @property
    def is_processable(self) -> bool:
        """Check if this transcript should be processed."""
        return self.status in [
            TranscriptStatus.PENDING,
            TranscriptStatus.FAILED,
        ] and self.retry_count < self.max_retries


# =============================================================================
# DYNAMODB TRACKER CLASS
# =============================================================================

class DynamoDBTracker:
    """
    DynamoDB Tracker for managing transcript processing state.
    
    Uses a shared table (AgenticColleague_MeetingTracker) that stores both
    transcript and chat records, filtered by 'record_type'.
    
    Handles:
    - Creating/checking DynamoDB table existence
    - Tracking transcript processing status
    - Retry logic for failed transcripts
    - Querying for unprocessed transcripts
    """
    
    def __init__(self, config: Config, auto_create_table: bool = True):
        """
        Initialize the DynamoDB Tracker.
        
        Args:
            config: Configuration instance
            auto_create_table: Whether to auto-create the table if missing (default True)
            
        Raises:
            DynamoDBError: If connection fails or table cannot be created
        """
        self.config = config
        self.logger = config.logger
        self.table_name = config.dynamodb_table_name
        self.max_retries = config.max_retry_attempts
        self.record_type = RECORD_TYPE_TRANSCRIPT
        
        try:
            self._client = boto3.client("dynamodb", region_name=config.aws_region)
            self._resource = boto3.resource("dynamodb", region_name=config.aws_region)
            self._table = self._resource.Table(self.table_name)
            self.logger.debug(f"Connected to DynamoDB in region {config.aws_region}")
            
        except NoCredentialsError:
            raise DynamoDBError(
                "No AWS credentials found. "
                "Ensure AWS credentials are configured (environment, ~/.aws/credentials, or IAM role)"
            )
        except Exception as e:
            raise DynamoDBError(f"Failed to connect to DynamoDB: {e}")
        
        # Ensure table exists
        if auto_create_table:
            self._ensure_table_exists()
    
    # -------------------------------------------------------------------------
    # TABLE MANAGEMENT
    # -------------------------------------------------------------------------
    
    def _ensure_table_exists(self):
        """Ensure the DynamoDB table exists, creating it if necessary."""
        try:
            self._client.describe_table(TableName=self.table_name)
            self.logger.debug(f"DynamoDB table '{self.table_name}' exists")
            
        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                self.logger.info(f"Creating DynamoDB table '{self.table_name}'...")
                self._create_table()
            else:
                raise DynamoDBError(f"Error checking table: {e}")
    
    def _create_table(self):
        """Create the DynamoDB table with required schema for shared use."""
        try:
            # Shared table schema with record_id as primary key
            # GSI on record_type+status for filtering by type and status
            self._client.create_table(
                TableName=self.table_name,
                KeySchema=[
                    {"AttributeName": "record_id", "KeyType": "HASH"}
                ],
                AttributeDefinitions=[
                    {"AttributeName": "record_id", "AttributeType": "S"},
                    {"AttributeName": "record_type", "AttributeType": "S"},
                    {"AttributeName": "status", "AttributeType": "S"},
                ],
                GlobalSecondaryIndexes=[
                    {
                        "IndexName": "record_type-status-index",
                        "KeySchema": [
                            {"AttributeName": "record_type", "KeyType": "HASH"},
                            {"AttributeName": "status", "KeyType": "RANGE"},
                        ],
                        "Projection": {"ProjectionType": "ALL"},
                    },
                    {
                        "IndexName": "status-index",
                        "KeySchema": [
                            {"AttributeName": "status", "KeyType": "HASH"}
                        ],
                        "Projection": {"ProjectionType": "ALL"},
                    },
                ],
                BillingMode="PAY_PER_REQUEST",
            )
            
            # Wait for table to become active
            self._wait_for_table_active()
            self.logger.info(f"✅ DynamoDB table '{self.table_name}' created successfully")
            
        except ClientError as e:
            raise DynamoDBError(f"Failed to create table: {e}")
    
    def _wait_for_table_active(self, timeout: int = 60):
        """Wait for the table to become active."""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                response = self._client.describe_table(TableName=self.table_name)
                status = response["Table"]["TableStatus"]
                
                if status == "ACTIVE":
                    return
                
                self.logger.debug(f"Table status: {status}, waiting...")
                time.sleep(2)
                
            except ClientError:
                time.sleep(2)
        
        raise DynamoDBError(f"Timeout waiting for table to become active")
    
    # -------------------------------------------------------------------------
    # TIMESTAMP HELPERS
    # -------------------------------------------------------------------------
    
    @staticmethod
    def _get_timestamp() -> str:
        """Get current UTC timestamp in ISO format."""
        return datetime.now(timezone.utc).isoformat()
    
    # -------------------------------------------------------------------------
    # RECORD OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_record(self, transcript_id: str) -> Optional[TranscriptRecord]:
        """
        Get a transcript record by ID.
        
        Args:
            transcript_id: Transcript ID
            
        Returns:
            TranscriptRecord or None if not found
        """
        try:
            response = self._client.get_item(
                TableName=self.table_name,
                Key={"record_id": {"S": transcript_id}},
            )
            
            item = response.get("Item")
            if item:
                # Verify it's a transcript record (not a chat record)
                item_type = item.get("record_type", {}).get("S", RECORD_TYPE_TRANSCRIPT)
                if item_type == RECORD_TYPE_TRANSCRIPT:
                    return TranscriptRecord.from_dynamodb_item(item)
            return None
            
        except ClientError as e:
            self.logger.error(f"Error getting record {transcript_id}: {e}")
            return None
    
    def is_processed(self, transcript_id: str) -> bool:
        """
        Check if a transcript has been successfully processed.
        
        Args:
            transcript_id: Transcript ID
            
        Returns:
            True if transcript is COMPLETED, False otherwise
        """
        record = self.get_record(transcript_id)
        return record is not None and record.status == TranscriptStatus.COMPLETED
    
    def should_process(self, transcript_id: str) -> bool:
        """
        Check if a transcript should be processed.
        
        A transcript should be processed if:
        - It doesn't exist in DynamoDB (new)
        - It's in PENDING status
        - It's in FAILED status with retry_count < max_retries
        
        Args:
            transcript_id: Transcript ID
            
        Returns:
            True if transcript should be processed
        """
        record = self.get_record(transcript_id)
        
        if record is None:
            return True  # New transcript
        
        return record.is_processable
    
    def create_record(
        self,
        transcript_id: str,
        meeting_id: str,
        meeting_subject: str,
        join_url: str,
        status: TranscriptStatus = TranscriptStatus.PENDING,
    ) -> TranscriptRecord:
        """
        Create a new transcript tracking record.
        
        Args:
            transcript_id: Transcript ID
            meeting_id: Meeting ID
            meeting_subject: Meeting subject/title
            join_url: Teams meeting join URL
            status: Initial status (default PENDING)
            
        Returns:
            Created TranscriptRecord
        """
        timestamp = self._get_timestamp()
        
        record = TranscriptRecord(
            transcript_id=transcript_id,
            meeting_id=meeting_id,
            meeting_subject=meeting_subject,
            join_url=join_url,
            status=status,
            record_type=RECORD_TYPE_TRANSCRIPT,
            retry_count=0,
            max_retries=self.max_retries,
            created_at=timestamp,
            updated_at=timestamp,
        )
        
        try:
            self._client.put_item(
                TableName=self.table_name,
                Item=record.to_dynamodb_item(),
                ConditionExpression="attribute_not_exists(record_id)",
            )
            
            self.logger.debug(f"Created record for transcript {transcript_id[:30]}...")
            return record
            
        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                # Record already exists, return existing
                return self.get_record(transcript_id)
            raise DynamoDBError(f"Failed to create record: {e}")
    
    def mark_processing(
        self,
        transcript_id: str,
        meeting_id: str,
        meeting_subject: str,
        join_url: str,
    ) -> TranscriptRecord:
        """
        Mark a transcript as currently being processed.
        
        Creates the record if it doesn't exist, or updates existing record.
        
        Args:
            transcript_id: Transcript ID
            meeting_id: Meeting ID
            meeting_subject: Meeting subject
            join_url: Teams meeting join URL
            
        Returns:
            Updated TranscriptRecord
        """
        existing = self.get_record(transcript_id)
        timestamp = self._get_timestamp()
        
        if existing:
            # Update existing record
            try:
                self._client.update_item(
                    TableName=self.table_name,
                    Key={"record_id": {"S": transcript_id}},
                    UpdateExpression=(
                        "SET #status = :status, "
                        "updated_at = :updated_at, "
                        "meeting_subject = :subject"
                    ),
                    ExpressionAttributeNames={"#status": "status"},
                    ExpressionAttributeValues={
                        ":status": {"S": TranscriptStatus.PROCESSING.value},
                        ":updated_at": {"S": timestamp},
                        ":subject": {"S": meeting_subject},
                    },
                )
                
                existing.status = TranscriptStatus.PROCESSING
                existing.updated_at = timestamp
                
                self.logger.info(f"▶️  Processing: {meeting_subject[:50]}...")
                return existing
                
            except ClientError as e:
                raise DynamoDBError(f"Failed to update record: {e}")
        else:
            # Create new record
            record = self.create_record(
                transcript_id=transcript_id,
                meeting_id=meeting_id,
                meeting_subject=meeting_subject,
                join_url=join_url,
                status=TranscriptStatus.PROCESSING,
            )
            
            self.logger.info(f"▶️  Processing (new): {meeting_subject[:50]}...")
            return record
    
    def mark_completed(
        self,
        transcript_id: str,
        s3_path: str,
    ) -> TranscriptRecord:
        """
        Mark a transcript as successfully completed.
        
        Args:
            transcript_id: Transcript ID
            s3_path: S3 URI where transcript was stored
            
        Returns:
            Updated TranscriptRecord
        """
        timestamp = self._get_timestamp()
        
        try:
            self._client.update_item(
                TableName=self.table_name,
                Key={"record_id": {"S": transcript_id}},
                UpdateExpression=(
                    "SET #status = :status, "
                    "s3_path = :s3_path, "
                    "processed_at = :processed_at, "
                    "updated_at = :updated_at, "
                    "error_message = :empty"
                ),
                ExpressionAttributeNames={"#status": "status"},
                ExpressionAttributeValues={
                    ":status": {"S": TranscriptStatus.COMPLETED.value},
                    ":s3_path": {"S": s3_path},
                    ":processed_at": {"S": timestamp},
                    ":updated_at": {"S": timestamp},
                    ":empty": {"S": ""},
                },
            )
            
            record = self.get_record(transcript_id)
            self.logger.info(f"✅ Completed: {transcript_id[:30]}... -> {s3_path}")
            return record
            
        except ClientError as e:
            raise DynamoDBError(f"Failed to mark completed: {e}")
    
    def mark_failed(
        self,
        transcript_id: str,
        error_message: str,
        increment_retry: bool = True,
    ) -> TranscriptRecord:
        """
        Mark a transcript as failed.
        
        Increments retry count and marks as PERMANENTLY_FAILED if max retries exceeded.
        
        Args:
            transcript_id: Transcript ID
            error_message: Error message describing the failure
            increment_retry: Whether to increment retry count (default True).
                           Set to False for permanent failures that shouldn't be retried.
            
        Returns:
            Updated TranscriptRecord
        """
        timestamp = self._get_timestamp()
        existing = self.get_record(transcript_id)
        
        if not existing:
            raise DynamoDBError(f"Cannot mark as failed: record not found for {transcript_id}")
        
        if increment_retry:
            new_retry_count = existing.retry_count + 1
        else:
            # For permanent failures (like 404), set to max to prevent retries
            new_retry_count = existing.max_retries
        
        # Determine if permanently failed
        if new_retry_count >= existing.max_retries:
            new_status = TranscriptStatus.PERMANENTLY_FAILED
            self.logger.error(
                f"❌ Permanently failed (max retries): {transcript_id[:30]}... - {error_message}"
            )
        else:
            new_status = TranscriptStatus.FAILED
            self.logger.warning(
                f"⚠️  Failed (retry {new_retry_count}/{existing.max_retries}): "
                f"{transcript_id[:30]}... - {error_message}"
            )
        
        try:
            self._client.update_item(
                TableName=self.table_name,
                Key={"record_id": {"S": transcript_id}},
                UpdateExpression=(
                    "SET #status = :status, "
                    "retry_count = :retry_count, "
                    "error_message = :error_message, "
                    "updated_at = :updated_at"
                ),
                ExpressionAttributeNames={"#status": "status"},
                ExpressionAttributeValues={
                    ":status": {"S": new_status.value},
                    ":retry_count": {"N": str(new_retry_count)},
                    ":error_message": {"S": error_message[:500]},  # Limit error message length
                    ":updated_at": {"S": timestamp},
                },
            )
            
            return self.get_record(transcript_id)
            
        except ClientError as e:
            raise DynamoDBError(f"Failed to mark as failed: {e}")
    
    # -------------------------------------------------------------------------
    # QUERY OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_records_by_status(self, status: TranscriptStatus) -> List[TranscriptRecord]:
        """
        Get all transcript records with a specific status.
        
        Args:
            status: Status to filter by
            
        Returns:
            List of TranscriptRecords
        """
        try:
            # Use the composite GSI to filter by record_type and status
            response = self._client.query(
                TableName=self.table_name,
                IndexName="record_type-status-index",
                KeyConditionExpression="record_type = :type AND #status = :status",
                ExpressionAttributeNames={"#status": "status"},
                ExpressionAttributeValues={
                    ":type": {"S": RECORD_TYPE_TRANSCRIPT},
                    ":status": {"S": status.value},
                },
            )
            
            items = response.get("Items", [])
            return [TranscriptRecord.from_dynamodb_item(item) for item in items]
            
        except ClientError as e:
            self.logger.error(f"Error querying by status: {e}")
            return []
    
    def get_failed_for_retry(self) -> List[TranscriptRecord]:
        """
        Get all failed records that can still be retried.
        
        Returns:
            List of TranscriptRecords that are FAILED and retry_count < max_retries
        """
        failed_records = self.get_records_by_status(TranscriptStatus.FAILED)
        return [r for r in failed_records if r.can_retry]
    
    def get_pending(self) -> List[TranscriptRecord]:
        """
        Get all pending records.
        
        Returns:
            List of TranscriptRecords in PENDING status
        """
        return self.get_records_by_status(TranscriptStatus.PENDING)
    
    def get_processing_stats(self) -> Dict[str, int]:
        """
        Get statistics about transcript processing.
        
        Returns:
            Dictionary with counts for each status
        """
        stats = {}
        
        for status in TranscriptStatus:
            records = self.get_records_by_status(status)
            stats[status.value] = len(records)
        
        stats["TOTAL"] = sum(stats.values())
        stats["RETRYABLE"] = len(self.get_failed_for_retry())
        
        return stats
    
    # -------------------------------------------------------------------------
    # PIPELINE METADATA OPERATIONS (for incremental sync)
    # -------------------------------------------------------------------------
    
    def get_pipeline_metadata(self) -> Optional[Dict[str, Any]]:
        """
        Get pipeline run metadata (last run timestamp, stats, etc.).
        
        The pipeline metadata is stored as a special record in the same table
        with record_id = TRANSCRIPT_PIPELINE_METADATA_ID.
        
        Returns:
            Dictionary with pipeline metadata or None if not found
        """
        try:
            response = self._client.get_item(
                TableName=self.table_name,
                Key={"record_id": {"S": TRANSCRIPT_PIPELINE_METADATA_ID}},
            )
            
            item = response.get("Item")
            if not item:
                return None
            
            # Parse the metadata record
            metadata = {
                "last_successful_run": item.get("last_successful_run", {}).get("S"),
                "last_run_status": item.get("last_run_status", {}).get("S"),
                "total_runs": int(item.get("total_runs", {}).get("N", "0")),
                "total_processed": int(item.get("total_processed", {}).get("N", "0")),
                "total_failed": int(item.get("total_failed", {}).get("N", "0")),
                "created_at": item.get("created_at", {}).get("S"),
                "updated_at": item.get("updated_at", {}).get("S"),
            }
            
            return metadata
            
        except ClientError as e:
            self.logger.error(f"Error getting pipeline metadata: {e}")
            return None
    
    def get_last_successful_run(self) -> Optional[datetime]:
        """
        Get the timestamp of the last successful pipeline run.
        
        Returns:
            datetime object or None if no previous run exists
        """
        metadata = self.get_pipeline_metadata()
        
        if not metadata or not metadata.get("last_successful_run"):
            return None
        
        try:
            # Parse ISO format timestamp
            timestamp_str = metadata["last_successful_run"]
            # Handle both with and without timezone
            if timestamp_str.endswith("Z"):
                timestamp_str = timestamp_str[:-1] + "+00:00"
            return datetime.fromisoformat(timestamp_str)
        except (ValueError, TypeError) as e:
            self.logger.error(f"Error parsing last_successful_run timestamp: {e}")
            return None
    
    def update_pipeline_metadata(
        self,
        last_successful_run: datetime = None,
        last_run_status: str = "SUCCESS",
        processed_count: int = 0,
        failed_count: int = 0,
    ) -> Dict[str, Any]:
        """
        Update pipeline metadata after a run.
        
        Args:
            last_successful_run: Timestamp of this run (default: now)
            last_run_status: Status of this run (SUCCESS, PARTIAL, FAILED)
            processed_count: Number of transcripts processed in this run
            failed_count: Number of transcripts that failed in this run
            
        Returns:
            Updated metadata dictionary
        """
        timestamp = self._get_timestamp()
        
        if last_successful_run is None:
            last_successful_run = datetime.now(timezone.utc)
        
        # Format datetime as ISO string
        if isinstance(last_successful_run, datetime):
            last_run_str = last_successful_run.isoformat()
        else:
            last_run_str = str(last_successful_run)
        
        # Get existing metadata to update counters
        existing = self.get_pipeline_metadata()
        
        if existing:
            # Update existing record
            new_total_runs = existing.get("total_runs", 0) + 1
            new_total_processed = existing.get("total_processed", 0) + processed_count
            new_total_failed = existing.get("total_failed", 0) + failed_count
            created_at = existing.get("created_at", timestamp)
        else:
            # First run
            new_total_runs = 1
            new_total_processed = processed_count
            new_total_failed = failed_count
            created_at = timestamp
        
        try:
            self._client.put_item(
                TableName=self.table_name,
                Item={
                    "record_id": {"S": TRANSCRIPT_PIPELINE_METADATA_ID},
                    "record_type": {"S": "TRANSCRIPT_METADATA"},
                    "last_successful_run": {"S": last_run_str},
                    "last_run_status": {"S": last_run_status},
                    "total_runs": {"N": str(new_total_runs)},
                    "total_processed": {"N": str(new_total_processed)},
                    "total_failed": {"N": str(new_total_failed)},
                    "created_at": {"S": created_at},
                    "updated_at": {"S": timestamp},
                },
            )
            
            self.logger.info(f"📊 Updated pipeline metadata (run #{new_total_runs})")
            
            return {
                "last_successful_run": last_run_str,
                "last_run_status": last_run_status,
                "total_runs": new_total_runs,
                "total_processed": new_total_processed,
                "total_failed": new_total_failed,
                "created_at": created_at,
                "updated_at": timestamp,
            }
            
        except ClientError as e:
            raise DynamoDBError(f"Failed to update pipeline metadata: {e}")
    
    def is_first_run(self) -> bool:
        """
        Check if this is the first pipeline run (no metadata exists).
        
        Returns:
            True if no previous runs exist, False otherwise
        """
        return self.get_pipeline_metadata() is None
    
    def print_pipeline_metadata(self):
        """Print pipeline metadata summary."""
        metadata = self.get_pipeline_metadata()
        
        print("\n" + "=" * 50)
        print("PIPELINE RUN HISTORY")
        print("=" * 50)
        
        if not metadata:
            print("  ℹ️  No previous runs found (first run)")
        else:
            print(f"  📅 Last Successful Run: {metadata.get('last_successful_run', 'N/A')}")
            print(f"  📊 Last Run Status:     {metadata.get('last_run_status', 'N/A')}")
            print(f"  🔢 Total Runs:          {metadata.get('total_runs', 0)}")
            print(f"  ✅ Total Processed:     {metadata.get('total_processed', 0)}")
            print(f"  ❌ Total Failed:        {metadata.get('total_failed', 0)}")
            print(f"  📆 First Run:           {metadata.get('created_at', 'N/A')}")
        
        print("=" * 50)
    
    def print_stats(self):
        """Print processing statistics."""
        stats = self.get_processing_stats()
        
        print("\n" + "=" * 50)
        print("TRANSCRIPT PROCESSING STATISTICS")
        print("=" * 50)
        print(f"  📝 Total Records:      {stats['TOTAL']}")
        print(f"  ⏳ Pending:            {stats['PENDING']}")
        print(f"  ▶️  Processing:         {stats['PROCESSING']}")
        print(f"  ✅ Completed:          {stats['COMPLETED']}")
        print(f"  ⚠️  Failed (retryable): {stats['RETRYABLE']}")
        print(f"  ❌ Permanently Failed: {stats['PERMANENTLY_FAILED']}")
        print("=" * 50)


# =============================================================================
# MODULE-LEVEL CONVENIENCE
# =============================================================================

def create_tracker(config: Config = None) -> DynamoDBTracker:
    """
    Create a DynamoDBTracker instance.
    
    Args:
        config: Optional Config instance (creates new one if not provided)
        
    Returns:
        DynamoDBTracker instance
    """
    if config is None:
        config = Config()
    return DynamoDBTracker(config)


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    from config import Config, ConfigurationError
    
    try:
        config = Config()
        
        print("\n" + "=" * 60)
        print("TESTING DYNAMODB TRACKER")
        print("=" * 60)
        
        tracker = DynamoDBTracker(config)
        
        # Print current stats
        tracker.print_stats()
        
        print("\n✅ DynamoDB Tracker test completed!")
        
    except ConfigurationError as e:
        print(f"\n❌ Configuration Error: {e}")
    except DynamoDBError as e:
        print(f"\n❌ DynamoDB Error: {e}")
