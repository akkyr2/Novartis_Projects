"""
Transcript Pipeline Package

A pipeline for extracting Microsoft Teams meeting transcripts via Graph API
and storing them as DOCX files in AWS S3, with processing state tracked in DynamoDB.

Usage (run from project root):
    # Run the pipeline from command line
    python -m transcript_pipeline.main run
    python -m transcript_pipeline.main_v2 run --full
    python -m transcript_pipeline.main_chat run --full
    
    # Verify environment
    python -m transcript_pipeline.verify.verify_all
    python -m transcript_pipeline.verify.verify_secrets

Modules:
    - config: Configuration management (AWS Secrets Manager)
    - graph_client: Microsoft Graph API client
    - dynamodb_tracker: DynamoDB state tracking
    - s3_storage: S3 file storage with VTT to DOCX conversion
    - main: Pipeline orchestrator and CLI
    - main_v2: Incremental pipeline orchestrator
    - main_chat: Chat pipeline orchestrator
"""

__version__ = "2.0.0"
__author__ = "Transcript Pipeline Team"

# Note: We intentionally do NOT import modules here to avoid circular imports
# and dependency issues when running as a module (-m flag).
# 
# To use this package programmatically, import directly:
#   from transcript_pipeline.config import Config, get_logger
#   from transcript_pipeline.main import TranscriptPipeline
#   from transcript_pipeline.main_v2 import IncrementalPipeline
#   from transcript_pipeline.main_chat import ChatPipeline

# Define public API
__all__ = [
    "__version__",
]
