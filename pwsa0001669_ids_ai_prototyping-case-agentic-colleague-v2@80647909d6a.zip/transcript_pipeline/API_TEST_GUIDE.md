# Transcript Pipeline API - Test Guide

This document provides test data and examples for testing all transcript pipeline API endpoints via Swagger UI.

**Base URL:** `http://localhost:7007`  
**Swagger UI:** `http://localhost:7007/docs`

---

## Table of Contents

1. [GET /transcript/config](#1-get-transcriptconfig)
2. [GET /transcript/status](#2-get-transcriptstatus)
3. [GET /transcript/verify](#3-get-transcriptverify)
4. [POST /transcript/run](#4-post-transcriptrun)
5. [POST /transcript/run-full](#5-post-transcriptrun-full)
6. [POST /transcript/run-incremental](#6-post-transcriptrun-incremental)
7. [POST /transcript/run-since](#7-post-transcriptrun-since)
8. [GET /transcript/records](#8-get-transcriptrecords)
9. [GET /transcript/files](#9-get-transcriptfiles)
10. [DELETE /transcript/records](#10-delete-transcriptrecords)
11. [DELETE /transcript/files](#11-delete-transcriptfiles)

---

## 1. GET /transcript/config

**Description:** Get transcript pipeline configuration including AWS settings and incremental sync parameters.

**Request:** No parameters required

**Expected Response:**
```json
{
  "status": "success",
  "configuration": {
    "aws_region": "us-east-1",
    "s3_bucket_name": "ids-aini-prototype-ai-analytics",
    "s3_base_prefix": "Agentic-Colleague-synthetic/meetings",
    "s3_transcript_prefix": "Agentic-Colleague-synthetic/meetings/transcripts/",
    "dynamodb_table_name": "AgenticColleague_MeetingTracker",
    "meetings_fetch_limit": 100,
    "max_retry_attempts": 3
  },
  "incremental_settings": {
    "default_lookback_days": 90,
    "incremental_buffer_hours": 2,
    "enable_auto_retry": true
  }
}
```

---

## 2. GET /transcript/status

**Description:** Get the current status of the transcript pipeline including DynamoDB stats, S3 storage stats, and last run information.

**Request:** No parameters required

**Expected Response:**
```json
{
  "pipeline_status": "ready",
  "configuration": {
    "aws_region": "us-east-1",
    "s3_bucket_name": "ids-aini-prototype-ai-analytics",
    "s3_transcript_prefix": "Agentic-Colleague-synthetic/meetings/transcripts/",
    "dynamodb_table_name": "AgenticColleague_MeetingTracker"
  },
  "incremental_settings": {
    "default_lookback_days": 90,
    "incremental_buffer_hours": 2,
    "enable_auto_retry": true
  },
  "dynamodb_stats": {
    "TOTAL": 25,
    "COMPLETED": 20,
    "FAILED": 3,
    "PROCESSING": 2
  },
  "s3_stats": {
    "total_files": 20,
    "docx_files": 20,
    "total_size_mb": 5.5
  },
  "last_run_info": {
    "last_successful_run": "2026-08-06T10:00:00Z",
    "last_run_mode": "incremental",
    "last_run_processed": 5,
    "last_run_failed": 0
  }
}
```

---

## 3. GET /transcript/verify

**Description:** Verifies all components of the transcript pipeline: Secrets Manager, DynamoDB, S3, and Graph API.

**Request:** No parameters required

**Expected Response:**
```json
{
  "all_passed": true,
  "secrets_manager": true,
  "dynamodb": true,
  "s3": true,
  "graph_api": true,
  "details": {
    "secrets_manager": "Configuration loaded successfully",
    "graph_api": "Graph API authenticated successfully (Transcript Client)",
    "dynamodb": "DynamoDB accessible. Total transcript records: 25",
    "s3": "S3 accessible. Transcript files: 20 (prefix: Agentic-Colleague-synthetic/meetings/transcripts/)"
  }
}
```

---

## 4. POST /transcript/run

**Description:** Main endpoint to trigger the transcript extraction pipeline.

> **Run Modes:**
> - `full`: First run or reset - fetches all meetings from the last N days (configured lookback)
> - `incremental`: Only fetches new meetings since last successful run (default)
> - `since`: Fetches meetings from a specific date

### Test Case 4.1: Incremental Sync (Default Mode)
```json
{
  "mode": "incremental",
  "retry_failed": true
}
```

### Test Case 4.2: Full Sync (First Run/Reset)
```json
{
  "mode": "full",
  "retry_failed": true
}
```

### Test Case 4.3: Full Sync with Limit
```json
{
  "mode": "full",
  "limit": 10,
  "retry_failed": true
}
```

### Test Case 4.4: Since Specific Date
```json
{
  "mode": "since",
  "since_date": "2026-07-01",
  "retry_failed": true
}
```

### Test Case 4.5: Since Date with Limit
```json
{
  "mode": "since",
  "since_date": "2026-07-15",
  "limit": 5,
  "retry_failed": true
}
```

### Test Case 4.6: Incremental Without Retry
```json
{
  "mode": "incremental",
  "retry_failed": false
}
```

---

## 5. POST /transcript/run-full

**Description:** Shortcut endpoint to run a full sync of all transcripts. Use for first run or reset.

### Test Case 5.1: Full Sync (All Transcripts)
**Query Parameters:**
- `retry_failed`: `true`

> Leave `limit` empty to process all meetings.

### Test Case 5.2: Full Sync with Limit
**Query Parameters:**
- `limit`: `10`
- `retry_failed`: `true`

---

## 6. POST /transcript/run-incremental

**Description:** Shortcut endpoint to run an incremental sync. Only fetches new meetings since last successful run.

### Test Case 6.1: Incremental Sync (All New Meetings)
**Query Parameters:**
- `retry_failed`: `true`

> Leave `limit` empty to process all new meetings.

### Test Case 6.2: Incremental Sync with Limit
**Query Parameters:**
- `limit`: `5`
- `retry_failed`: `true`

---

## 7. POST /transcript/run-since

**Description:** Shortcut endpoint to run sync from a specific date.

### Test Case 7.1: Sync Since July 1, 2026
**Query Parameters:**
- `since_date`: `2026-07-01`
- `retry_failed`: `true`

### Test Case 7.2: Sync Since July 15, 2026 with Limit
**Query Parameters:**
- `since_date`: `2026-07-15`
- `limit`: `10`
- `retry_failed`: `true`

### Test Case 7.3: Sync Last Week
**Query Parameters:**
- `since_date`: `2026-07-23` (adjust to 7 days ago)
- `retry_failed`: `true`

---

## 8. GET /transcript/records

**Description:** Returns all transcript records from DynamoDB with their processing status.

### Test Case 8.1: List All Records
**Query Parameters:** (leave all empty)

### Test Case 8.2: Filter by Status - Completed
**Query Parameters:**
- `status_filter`: `COMPLETED`

### Test Case 8.3: Filter by Status - Failed
**Query Parameters:**
- `status_filter`: `FAILED`

### Test Case 8.4: List with Limit
**Query Parameters:**
- `limit`: `20`

### Test Case 8.5: Filter Failed with Limit
**Query Parameters:**
- `status_filter`: `FAILED`
- `limit`: `10`

---

## 9. GET /transcript/files

**Description:** Returns all transcript files stored in S3 with their metadata.

### Test Case 9.1: List All Files
**Query Parameters:** (leave empty)

### Test Case 9.2: List with Limit
**Query Parameters:**
- `limit`: `10`

---

## 10. DELETE /transcript/records

**Description:** ⚠️ DANGER: Deletes ALL transcript tracking records from DynamoDB (preserves chat records).

### Test Case 10.1: Attempt Without Confirmation (Should Fail)
**Query Parameters:**
- `confirm`: `false`

**Expected Response:** 400 Error - "Set confirm=true to confirm deletion of all transcript records"

### Test Case 10.2: Delete All Transcript Records (Use with Caution!)
**Query Parameters:**
- `confirm`: `true`

**Expected Response:**
```json
{
  "status": "success",
  "message": "Deleted 25 transcript records from DynamoDB",
  "deleted_count": 25
}
```

> **Note:** This only deletes TRANSCRIPT records. Chat records are preserved.

---

## 11. DELETE /transcript/files

**Description:** ⚠️ DANGER: Deletes ALL transcript files from S3 (preserves chat files).

### Test Case 11.1: Attempt Without Confirmation (Should Fail)
**Query Parameters:**
- `confirm`: `false`

**Expected Response:** 400 Error - "Set confirm=true to confirm deletion of all transcript files"

### Test Case 11.2: Delete All Transcript Files (Use with Caution!)
**Query Parameters:**
- `confirm`: `true`

**Expected Response:**
```json
{
  "status": "success",
  "message": "Deleted 20 transcript files from S3",
  "deleted_count": 20
}
```

> **Note:** This only deletes files in the `/transcripts/` subfolder. Chat files in `/chats/` are preserved.

---

## Quick Test Workflow

Follow this sequence to test the entire transcript pipeline:

### Step 1: Verify Components
```
GET /transcript/verify
```
> Ensure all components (Secrets Manager, Graph API, DynamoDB, S3) are accessible.

### Step 2: Check Configuration
```
GET /transcript/config
```
> Review pipeline configuration settings.

### Step 3: Check Current Status
```
GET /transcript/status
```
> See DynamoDB stats, S3 stats, and last run information.

### Step 4: Run Full Sync (First Time)
```
POST /transcript/run-full?limit=5
```
> Start with a small limit to test the pipeline.

### Step 5: Check Records
```
GET /transcript/records
```
> Verify transcript records were created in DynamoDB.

### Step 6: Check Files
```
GET /transcript/files
```
> Verify transcript files were uploaded to S3.

### Step 7: Run Incremental Sync
```
POST /transcript/run-incremental
```
> Test incremental mode (should only process new meetings).

### Step 8: Check Status Again
```
GET /transcript/status
```
> Verify last run info was updated.

---

## Error Handling Test Cases

### Missing since_date for "since" mode
```json
{
  "mode": "since",
  "retry_failed": true
}
```
**Expected:** 400 Error - "since_date is required when mode='since'"

### Invalid Date Format
```json
{
  "mode": "since",
  "since_date": "July 1, 2026",
  "retry_failed": true
}
```
**Expected:** 400 Error - "Could not parse date: July 1, 2026. Use format YYYY-MM-DD"

### Delete Without Confirmation
```
DELETE /transcript/records?confirm=false
```
**Expected:** 400 Error - "Set confirm=true to confirm deletion of all records"

---

## Notes

1. **Verify First**: Always run `/transcript/verify` before running the pipeline to ensure all components are accessible.

2. **Full vs Incremental**: 
   - Use `full` mode for first run or when you want to reset and reprocess all transcripts
   - Use `incremental` mode for regular runs to only fetch new meetings

3. **Since Mode**: Use when you want to fetch transcripts from a specific date without resetting the entire pipeline.

4. **Limit Parameter**: The `limit` parameter is **OPTIONAL**. If omitted, ALL meetings will be processed.

5. **Retry Failed**: Set `retry_failed=true` (default) to automatically retry previously failed transcripts.

6. **Cleanup Operations**: The DELETE endpoints require `confirm=true` to prevent accidental data deletion. They only delete transcript-related data, preserving chat data.

7. **Graph API Rate Limits**: Microsoft Graph API has rate limits. If you encounter errors, wait a few minutes before retrying.

8. **Transcript Availability**: Transcripts are only available for meetings where transcription was enabled. Not all meetings will have transcripts.

9. **Data Separation (Transcript vs Chat)**:
   - **S3 Storage**: Transcript files are stored in `{base_prefix}/transcripts/`, chat files in `{base_prefix}/chats/`
   - **DynamoDB**: Records are separated by `record_type` field (`TRANSCRIPT` vs `CHAT`)
   - Cleanup operations only affect their respective data types

---

## Recommended Testing Order

1. `GET /transcript/verify` - Check all connections
2. `GET /transcript/config` - Review configuration
3. `GET /transcript/status` - See current state
4. `POST /transcript/run-full?limit=5` - Test full sync (small batch)
5. `GET /transcript/records` - Verify records created
6. `GET /transcript/files` - Verify files uploaded
7. `GET /transcript/status` - Verify metadata saved
8. `POST /transcript/run-incremental` - Test incremental mode
9. `POST /transcript/run-since?since_date=2026-08-01` - Test since-date mode

---

## Architecture: Data Separation (Chat vs Transcript)

Both pipelines share the same base infrastructure but store data separately:

| Component | Transcript Pipeline | Chat Pipeline |
|-----------|---------------------|---------------|
| **API Prefix** | `/transcript/*` | `/chat/*` |
| **S3 Base Prefix** | `{base}/` | `{base}/` |
| **S3 Subfolder** | `{base}/transcripts/` | `{base}/chats/` |
| **DynamoDB Table** | `AgenticColleague_MeetingTracker` (shared) | `AgenticColleague_MeetingTracker` (shared) |
| **Record Type** | `TRANSCRIPT` | `CHAT` |
| **Metadata ID** | `__TRANSCRIPT_PIPELINE_METADATA__` | `__CHAT_PIPELINE_METADATA__` |
| **Content Source** | Meeting Transcriptions (VTT) | Chat Messages (Graph API) |
| **Extra Filters** | - | `min_messages` |

### Cleanup Safety

- `DELETE /transcript/records` → Only deletes records where `record_type = "TRANSCRIPT"`
- `DELETE /transcript/files` → Only deletes files in `/transcripts/` prefix
- `DELETE /chat/records` → Only deletes records where `record_type = "CHAT"`
- `DELETE /chat/files` → Only deletes files in `/chats/` prefix

This ensures that transcript and chat data are **completely isolated** and cleanup operations are **safe**.
