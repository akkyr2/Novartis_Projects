"""
Microsoft Graph API Client for the Transcript Pipeline.

Handles authentication via MSAL with certificate-based credentials
and provides methods to interact with Microsoft Graph API for:
- Fetching calendar events and online meetings
- Listing meeting transcripts
- Downloading transcript content

Usage:
    from graph_client import GraphClient
    from config import Config
    
    config = Config()
    client = GraphClient(config)
    
    # Get all online meetings with transcripts
    meetings = client.get_online_meetings_with_transcripts()
    
    # Download a specific transcript
    content = client.download_transcript_content(meeting_id, transcript_id)
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any

import msal
import requests

from transcript_pipeline.config import Config, GraphAPIError


# =============================================================================
# DATA CLASSES FOR TYPE SAFETY
# =============================================================================

@dataclass
class TranscriptInfo:
    """Represents a meeting transcript."""
    
    transcript_id: str
    meeting_id: str
    call_id: Optional[str] = None
    created_datetime: Optional[str] = None
    end_datetime: Optional[str] = None
    content_url: Optional[str] = None
    organizer_id: Optional[str] = None
    organizer_name: Optional[str] = None
    is_complete: bool = False
    
    @classmethod
    def from_api_response(cls, data: dict, meeting_id: str) -> "TranscriptInfo":
        """Create TranscriptInfo from Graph API response."""
        organizer = data.get("meetingOrganizer", {})
        user = organizer.get("user", {})
        
        end_datetime = data.get("endDateTime", "")
        # Transcript is complete if endDateTime doesn't start with 0001-01-01 (draft indicator)
        is_complete = bool(end_datetime) and not end_datetime.startswith("0001-01-01")
        
        return cls(
            transcript_id=data.get("id", ""),
            meeting_id=meeting_id,
            call_id=data.get("callId"),
            created_datetime=data.get("createdDateTime"),
            end_datetime=end_datetime,
            content_url=data.get("transcriptContentUrl"),
            organizer_id=user.get("id"),
            organizer_name=user.get("displayName"),
            is_complete=is_complete,
        )


@dataclass
class MeetingInfo:
    """Represents an online meeting."""
    
    meeting_id: str
    subject: str
    join_url: str
    start_datetime: Optional[str] = None
    end_datetime: Optional[str] = None
    provider: Optional[str] = None
    event_id: Optional[str] = None
    transcripts: List[TranscriptInfo] = field(default_factory=list)
    
    @classmethod
    def from_calendar_event(cls, event: dict) -> Optional["MeetingInfo"]:
        """Create MeetingInfo from a calendar event."""
        online_meeting = event.get("onlineMeeting", {})
        join_url = online_meeting.get("joinUrl") if online_meeting else None
        
        if not join_url:
            return None
        
        return cls(
            meeting_id="",  # Will be populated later
            subject=event.get("subject", "Untitled Meeting"),
            join_url=join_url,
            start_datetime=event.get("start", {}).get("dateTime"),
            end_datetime=event.get("end", {}).get("dateTime"),
            provider=event.get("onlineMeetingProvider"),
            event_id=event.get("id"),
        )


# =============================================================================
# GRAPH API CLIENT CLASS
# =============================================================================

class GraphClient:
    """
    Microsoft Graph API Client.
    
    Handles authentication and provides methods to interact with
    Microsoft Graph API for fetching meetings and transcripts.
    """
    
    def __init__(self, config: Config):
        """
        Initialize the Graph Client.
        
        Args:
            config: Configuration instance with Azure AD credentials
            
        Raises:
            GraphAPIError: If authentication fails
        """
        self.config = config
        self.logger = config.logger
        self._access_token: Optional[str] = None
        self._token_expires: Optional[datetime] = None
        
        # Authenticate on initialization
        self._authenticate()
    
    # -------------------------------------------------------------------------
    # AUTHENTICATION
    # -------------------------------------------------------------------------
    
    def _get_certificate_content(self) -> str:
        """
        Get certificate content either from config or file.
        
        Returns:
            str: PEM certificate content
            
        Raises:
            GraphAPIError: If certificate cannot be loaded
        """
        # First, try to get from Secrets Manager (AZURE_CERT_CONTENT)
        if self.config.azure_cert_content:
            self.logger.debug("Using certificate content from Secrets Manager")
            return self.config.azure_cert_content.strip()
        
        # Fallback to file path
        if self.config.azure_cert_path:
            try:
                self.logger.debug(f"Loading certificate from file: {self.config.azure_cert_path}")
                with open(self.config.azure_cert_path, "r") as f:
                    return f.read().strip()
            except Exception as e:
                raise GraphAPIError(f"Failed to load certificate file: {e}")
        
        raise GraphAPIError(
            "No certificate available. Set AZURE_CERT_CONTENT in Secrets Manager "
            "or AZURE_CERT_PATH to a valid certificate file."
        )
    
    def _authenticate(self):
        """
        Authenticate with Azure AD using certificate-based credentials.
        
        Raises:
            GraphAPIError: If authentication fails
        """
        self.logger.info("Authenticating with Microsoft Graph API...")
        
        try:
            # Get certificate content
            private_key = self._get_certificate_content()
            
            # Validate certificate format (must be PEM format)
            # PEM files start with a 5-dash header marker
            pem_header_marker = "-" * 5 + "BEGIN"
            if not private_key.startswith(pem_header_marker):
                raise GraphAPIError(
                    "Invalid certificate format. Expected PEM format. "
                    "Ensure the certificate content starts with a valid PEM header."
                )
            
            # Set up MSAL client
            authority_url = f"https://login.microsoftonline.com/{self.config.azure_tenant_id}"
            scopes = ["https://graph.microsoft.com/.default"]
            
            client_credential = {
                "private_key": private_key,
                "thumbprint": self.config.azure_cert_thumbprint,
            }
            
            # Create MSAL confidential client application
            app = msal.ConfidentialClientApplication(
                client_id=self.config.azure_client_id,
                authority=authority_url,
                client_credential=client_credential,
            )
            
            # Acquire token
            token_response = app.acquire_token_for_client(scopes=scopes)
            
            if "access_token" in token_response:
                self._access_token = token_response["access_token"]
                self.logger.info("✅ Successfully authenticated with Graph API")
            else:
                error = token_response.get("error", "Unknown error")
                error_desc = token_response.get("error_description", "No description")
                raise GraphAPIError(f"Authentication failed: {error} - {error_desc}")
                
        except GraphAPIError:
            raise
        except Exception as e:
            raise GraphAPIError(f"Authentication error: {e}")
    
    def _get_headers(self, accept: str = "application/json") -> dict:
        """
        Get HTTP headers for API requests.
        
        Args:
            accept: Accept header value
            
        Returns:
            dict: HTTP headers
        """
        return {
            "Authorization": f"Bearer {self._access_token}",
            "Content-Type": "application/json",
            "Accept": accept,
        }
    
    def _make_request(
        self, 
        method: str, 
        url: str, 
        params: dict = None, 
        accept: str = "application/json"
    ) -> requests.Response:
        """
        Make an HTTP request to the Graph API.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            params: Query parameters
            accept: Accept header value
            
        Returns:
            requests.Response: Response object
            
        Raises:
            GraphAPIError: If request fails
        """
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._get_headers(accept),
                params=params,
                timeout=30,
            )
            
            # Log request details for debugging
            self.logger.debug(f"{method} {url} -> {response.status_code}")
            
            return response
            
        except requests.exceptions.RequestException as e:
            raise GraphAPIError(f"Request failed: {e}")
    
    # -------------------------------------------------------------------------
    # MEETINGS OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_calendar_events(self, limit: int = None) -> List[dict]:
        """
        Get calendar events for the configured user.
        
        Args:
            limit: Maximum number of events to fetch (default from config)
            
        Returns:
            List of calendar event dictionaries
        """
        limit = limit or self.config.meetings_fetch_limit
        
        url = f"{self.config.graph_base_url}/users/{self.config.graph_user_id}/events"
        params = {
            "$select": "id,subject,start,end,isOnlineMeeting,onlineMeeting,onlineMeetingProvider",
            "$top": limit,
            "$orderby": "start/dateTime desc",
        }
        
        self.logger.info(f"Fetching calendar events (limit: {limit})...")
        
        response = self._make_request("GET", url, params)
        
        if response.status_code != 200:
            raise GraphAPIError(
                f"Failed to fetch calendar events: {response.status_code} - {response.text}"
            )
        
        events = response.json().get("value", [])
        self.logger.info(f"Found {len(events)} calendar events")
        
        return events
    
    def get_calendar_view(
        self,
        start_datetime: datetime,
        end_datetime: datetime = None,
        limit: int = None,
    ) -> List[dict]:
        """
        Get calendar events within a specific date range using calendarView endpoint.
        
        This is more efficient than get_calendar_events() for incremental syncing
        as it only fetches events within the specified time window.
        
        Args:
            start_datetime: Start of the date range (inclusive)
            end_datetime: End of the date range (inclusive, default: now)
            limit: Maximum number of events to fetch (default from config)
            
        Returns:
            List of calendar event dictionaries within the date range
            
        Note:
            The calendarView endpoint requires both startDateTime and endDateTime.
            Times should be in UTC or include timezone offset.
        """
        from datetime import timezone as tz
        
        limit = limit or self.config.meetings_fetch_limit
        
        # Ensure datetime objects have timezone info (use UTC if naive)
        if start_datetime.tzinfo is None:
            start_datetime = start_datetime.replace(tzinfo=tz.utc)
        
        if end_datetime is None:
            end_datetime = datetime.now(tz.utc)
        elif end_datetime.tzinfo is None:
            end_datetime = end_datetime.replace(tzinfo=tz.utc)
        
        # Format as ISO 8601 strings
        start_str = start_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
        end_str = end_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
        
        url = f"{self.config.graph_base_url}/users/{self.config.graph_user_id}/calendarView"
        params = {
            "startDateTime": start_str,
            "endDateTime": end_str,
            "$select": "id,subject,start,end,isOnlineMeeting,onlineMeeting,onlineMeetingProvider",
            "$top": limit,
            "$orderby": "start/dateTime desc",
        }
        
        self.logger.info(
            f"Fetching calendar events from {start_str} to {end_str} (limit: {limit})..."
        )
        
        response = self._make_request("GET", url, params)
        
        if response.status_code != 200:
            raise GraphAPIError(
                f"Failed to fetch calendar view: {response.status_code} - {response.text}"
            )
        
        events = response.json().get("value", [])
        self.logger.info(f"Found {len(events)} calendar events in date range")
        
        return events
    
    def get_online_meetings_in_range(
        self,
        start_datetime: datetime,
        end_datetime: datetime = None,
        limit: int = None,
    ) -> List[MeetingInfo]:
        """
        Get online meetings (Teams meetings) within a specific date range.
        
        This is the incremental version of get_online_meetings() that only
        fetches meetings within the specified time window.
        
        Args:
            start_datetime: Start of the date range
            end_datetime: End of the date range (default: now)
            limit: Maximum number of events to fetch
            
        Returns:
            List of MeetingInfo objects for online meetings in the range
        """
        events = self.get_calendar_view(start_datetime, end_datetime, limit)
        
        # Filter for online meetings only
        online_meetings = []
        for event in events:
            if event.get("isOnlineMeeting", False):
                meeting = MeetingInfo.from_calendar_event(event)
                if meeting:
                    online_meetings.append(meeting)
        
        self.logger.info(
            f"Found {len(online_meetings)} online meetings in date range "
            f"(out of {len(events)} events)"
        )
        
        return online_meetings
    
    def get_online_meetings(self, limit: int = None) -> List[MeetingInfo]:
        """
        Get online meetings (Teams meetings) for the configured user.
        
        Args:
            limit: Maximum number of events to fetch
            
        Returns:
            List of MeetingInfo objects for online meetings
        """
        events = self.get_calendar_events(limit)
        
        # Filter for online meetings only
        online_meetings = []
        for event in events:
            if event.get("isOnlineMeeting", False):
                meeting = MeetingInfo.from_calendar_event(event)
                if meeting:
                    online_meetings.append(meeting)
        
        self.logger.info(
            f"Found {len(online_meetings)} online meetings out of {len(events)} events"
        )
        
        return online_meetings
    
    def get_meeting_id_by_join_url(self, join_url: str) -> Optional[str]:
        """
        Get the online meeting ID by its join URL.
        
        Args:
            join_url: Teams meeting join URL
            
        Returns:
            Online meeting ID or None if not found
            
        Note:
            404 errors are expected for old/deleted/cancelled meetings
            and are handled silently to avoid cluttering logs.
        """
        # Escape single quotes for OData filter
        escaped_url = join_url.strip().replace("'", "''")
        
        url = (
            f"{self.config.graph_base_url}/users/{self.config.graph_user_id}/onlineMeetings"
            f"?$filter=JoinWebUrl eq '{escaped_url}'"
        )
        
        response = self._make_request("GET", url)
        
        if response.status_code == 404:
            # 404 is expected for old/deleted/cancelled meetings - handle silently
            self.logger.debug(f"Meeting not found (404) - likely deleted or expired")
            return None
        
        if response.status_code != 200:
            # Log other errors at debug level to avoid clutter
            self.logger.debug(
                f"Failed to get meeting ID for join URL: {response.status_code}"
            )
            return None
        
        meetings = response.json().get("value", [])
        
        if meetings:
            meeting_id = meetings[0].get("id")
            self.logger.debug(f"Found meeting ID: {meeting_id[:20]}...")
            return meeting_id
        
        return None
    
    # -------------------------------------------------------------------------
    # TRANSCRIPT OPERATIONS
    # -------------------------------------------------------------------------
    
    def list_transcripts(self, meeting_id: str) -> List[TranscriptInfo]:
        """
        List all transcripts for a given online meeting.
        
        Args:
            meeting_id: Online meeting ID
            
        Returns:
            List of TranscriptInfo objects
        """
        url = (
            f"{self.config.graph_base_url}/users/{self.config.graph_user_id}"
            f"/onlineMeetings/{meeting_id}/transcripts"
        )
        
        response = self._make_request("GET", url)
        
        if response.status_code != 200:
            self.logger.warning(
                f"Failed to list transcripts for meeting: {response.status_code}"
            )
            return []
        
        transcripts_data = response.json().get("value", [])
        
        transcripts = [
            TranscriptInfo.from_api_response(t, meeting_id) 
            for t in transcripts_data
        ]
        
        return transcripts
    
    def list_completed_transcripts(self, meeting_id: str) -> List[TranscriptInfo]:
        """
        List only completed transcripts for a meeting (excludes drafts).
        
        Args:
            meeting_id: Online meeting ID
            
        Returns:
            List of completed TranscriptInfo objects
        """
        all_transcripts = self.list_transcripts(meeting_id)
        completed = [t for t in all_transcripts if t.is_complete]
        
        self.logger.debug(
            f"Meeting {meeting_id[:20]}...: {len(completed)}/{len(all_transcripts)} completed transcripts"
        )
        
        return completed
    
    def download_transcript_content(
        self, 
        meeting_id: str, 
        transcript_id: str,
        format: str = "text/vtt",
        max_retries: int = 3,
        retry_delay: float = 1.0
    ) -> str:
        """
        Download the content of a specific transcript.
        
        Args:
            meeting_id: Online meeting ID
            transcript_id: Transcript ID
            format: Content format (text/vtt or text/plain)
            max_retries: Maximum number of retry attempts for transient errors
            retry_delay: Delay between retries in seconds
            
        Returns:
            Transcript content as string
            
        Raises:
            GraphAPIError: If download fails after all retries
        """
        import time
        
        url = (
            f"{self.config.graph_base_url}/users/{self.config.graph_user_id}"
            f"/onlineMeetings/{meeting_id}/transcripts/{transcript_id}/content"
        )
        
        self.logger.debug(f"Downloading transcript {transcript_id[:20]}...")
        
        last_error = None
        for attempt in range(1, max_retries + 1):
            response = self._make_request("GET", url, accept=format)
            
            if response.status_code == 200:
                content = response.text
                self.logger.debug(f"Downloaded transcript content ({len(content)} characters)")
                return content
            
            # Handle specific error codes
            if response.status_code == 404:
                # 404 means the transcript doesn't exist or was deleted
                # Check if this might be a transient issue (retry once)
                if attempt < max_retries:
                    self.logger.debug(
                        f"Transcript not found (404), retrying in {retry_delay}s... (attempt {attempt}/{max_retries})"
                    )
                    time.sleep(retry_delay)
                    continue
                else:
                    raise GraphAPIError(
                        f"Transcript not found (404) - may have been deleted or is unavailable. "
                        f"Transcript ID: {transcript_id[:30]}..."
                    )
            
            elif response.status_code in (429, 500, 502, 503, 504):
                # Transient errors - retry with backoff
                if attempt < max_retries:
                    wait_time = retry_delay * (2 ** (attempt - 1))  # Exponential backoff
                    self.logger.warning(
                        f"Transient error ({response.status_code}), retrying in {wait_time}s... (attempt {attempt}/{max_retries})"
                    )
                    time.sleep(wait_time)
                    continue
            
            # Store the error for final exception
            last_error = f"{response.status_code} - {response.text}"
        
        raise GraphAPIError(f"Failed to download transcript after {max_retries} attempts: {last_error}")
    
    # -------------------------------------------------------------------------
    # HIGH-LEVEL OPERATIONS
    # -------------------------------------------------------------------------
    
    def get_online_meetings_with_transcripts(
        self, 
        limit: int = None,
        completed_only: bool = True
    ) -> List[MeetingInfo]:
        """
        Get all online meetings and populate their transcript information.
        
        This is the main method for the pipeline to discover what transcripts
        are available to process.
        
        Args:
            limit: Maximum number of meetings to fetch
            completed_only: Only include completed transcripts (default True)
            
        Returns:
            List of MeetingInfo objects with populated transcripts
        """
        self.logger.info("Fetching online meetings with transcripts...")
        
        # Get online meetings
        meetings = self.get_online_meetings(limit)
        
        return self._populate_transcripts(meetings, completed_only)
    
    def get_online_meetings_with_transcripts_in_range(
        self,
        start_datetime: datetime,
        end_datetime: datetime = None,
        limit: int = None,
        completed_only: bool = True,
    ) -> List[MeetingInfo]:
        """
        Get online meetings within a date range and populate their transcript information.
        
        This is the incremental version that only fetches meetings within the
        specified time window, making it more efficient for hourly runs.
        
        Args:
            start_datetime: Start of the date range
            end_datetime: End of the date range (default: now)
            limit: Maximum number of meetings to fetch
            completed_only: Only include completed transcripts (default True)
            
        Returns:
            List of MeetingInfo objects with populated transcripts
        """
        self.logger.info(f"Fetching online meetings with transcripts in date range...")
        
        # Get online meetings in the date range
        meetings = self.get_online_meetings_in_range(start_datetime, end_datetime, limit)
        
        return self._populate_transcripts(meetings, completed_only)
    
    def _populate_transcripts(
        self,
        meetings: List[MeetingInfo],
        completed_only: bool = True,
    ) -> List[MeetingInfo]:
        """
        Populate transcript information for a list of meetings.
        
        Args:
            meetings: List of MeetingInfo objects
            completed_only: Only include completed transcripts
            
        Returns:
            List of MeetingInfo objects with populated transcripts
        """
        meetings_with_transcripts = []
        meetings_not_found = 0
        meetings_no_transcripts = 0
        
        for meeting in meetings:
            try:
                # Get the actual meeting ID from the join URL
                meeting_id = self.get_meeting_id_by_join_url(meeting.join_url)
                
                if not meeting_id:
                    # Meeting not found via API - likely old/deleted/cancelled
                    meetings_not_found += 1
                    self.logger.debug(f"Could not resolve meeting ID for: {meeting.subject}")
                    continue
                
                meeting.meeting_id = meeting_id
                
                # Get transcripts for this meeting
                if completed_only:
                    transcripts = self.list_completed_transcripts(meeting_id)
                else:
                    transcripts = self.list_transcripts(meeting_id)
                
                meeting.transcripts = transcripts
                
                if transcripts:
                    self.logger.info(
                        f"  📝 {meeting.subject}: {len(transcripts)} transcript(s)"
                    )
                    meetings_with_transcripts.append(meeting)
                else:
                    meetings_no_transcripts += 1
                    
            except Exception as e:
                self.logger.warning(f"Error processing meeting '{meeting.subject}': {e}")
                continue
        
        # Log summary including skipped meetings
        total_transcripts = sum(len(m.transcripts) for m in meetings_with_transcripts)
        self.logger.info(
            f"Found {len(meetings_with_transcripts)} meetings with transcripts "
            f"(total {total_transcripts} transcripts)"
        )
        if meetings_not_found > 0:
            self.logger.debug(
                f"  ℹ️  Skipped {meetings_not_found} meetings (not found/deleted/expired)"
            )
        if meetings_no_transcripts > 0:
            self.logger.debug(
                f"  ℹ️  Skipped {meetings_no_transcripts} meetings (no transcripts available)"
            )
        
        return meetings_with_transcripts


# =============================================================================
# MODULE-LEVEL CONVENIENCE
# =============================================================================

def create_graph_client(config: Config = None) -> GraphClient:
    """
    Create a GraphClient instance.
    
    Args:
        config: Optional Config instance (creates new one if not provided)
        
    Returns:
        GraphClient instance
    """
    if config is None:
        config = Config()
    return GraphClient(config)


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    from config import Config, ConfigurationError
    
    try:
        config = Config()
        config.validate()
        
        client = GraphClient(config)
        
        print("\n" + "=" * 60)
        print("TESTING GRAPH CLIENT")
        print("=" * 60)
        
        # Test fetching meetings
        meetings = client.get_online_meetings_with_transcripts(limit=10)
        
        print(f"\nFound {len(meetings)} meetings with transcripts:")
        for meeting in meetings:
            print(f"\n  Meeting: {meeting.subject}")
            print(f"  Date: {meeting.start_datetime}")
            print(f"  Transcripts: {len(meeting.transcripts)}")
            for t in meeting.transcripts:
                print(f"    - {t.transcript_id[:30]}... (Complete: {t.is_complete})")
        
        print("\n✅ Graph Client test completed!")
        
    except ConfigurationError as e:
        print(f"\n❌ Configuration Error: {e}")
    except GraphAPIError as e:
        print(f"\n❌ Graph API Error: {e}")
