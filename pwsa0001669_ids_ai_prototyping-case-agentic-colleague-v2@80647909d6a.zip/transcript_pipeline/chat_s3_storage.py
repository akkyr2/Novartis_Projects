"""
S3 Storage module for the Meeting Chat Pipeline.

Handles:
- Converting chat messages to DOCX format
- Uploading chat documents to S3 with proper naming and folder structure
- Managing chat files in S3

Path format: s3://{bucket}/{prefix}/chats/{year}/{month}/{sanitized_subject}_{chat_id_hash}.docx

Usage:
    from chat_s3_storage import ChatS3Storage
    from config import Config
    
    config = Config()
    storage = ChatS3Storage(config)
    
    # Upload chat
    s3_path = storage.upload_chat(
        messages=messages,
        chat_id="19:meeting_abc123@thread.v2",
        meeting_subject="Team Standup",
        meeting_date="2024-01-15T10:00:00"
    )
"""

import io
import re
import hashlib
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Tuple

import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE

from transcript_pipeline.config import Config, S3StorageError
from transcript_pipeline.chat_client import ChatMessage


# =============================================================================
# HTML TO TEXT CONVERTER
# =============================================================================

class HTMLToText:
    """
    Simple HTML to plain text converter for Teams chat messages.
    
    Handles common HTML elements found in Teams messages.
    """
    
    # Regex patterns for HTML processing
    TAG_PATTERN = re.compile(r"<[^>]+>")
    MENTION_PATTERN = re.compile(r'<at id="[^"]*">([^<]*)</at>')
    BR_PATTERN = re.compile(r"<br\s*/?>", re.IGNORECASE)
    DIV_PATTERN = re.compile(r"</div>", re.IGNORECASE)
    P_PATTERN = re.compile(r"</p>", re.IGNORECASE)
    
    # HTML entities
    ENTITIES = {
        "&nbsp;": " ",
        "&amp;": "&",
        "&lt;": "<",
        "&gt;": ">",
        "&quot;": '"',
        "&#39;": "'",
        "&apos;": "'",
    }
    
    @classmethod
    def convert(cls, html_content: str) -> str:
        """
        Convert HTML content to plain text.
        
        Args:
            html_content: HTML string from Teams message
            
        Returns:
            Plain text content
        """
        if not html_content:
            return ""
        
        text = html_content
        
        # Preserve @mentions
        text = cls.MENTION_PATTERN.sub(r"@\1", text)
        
        # Convert line break elements to newlines
        text = cls.BR_PATTERN.sub("\n", text)
        text = cls.DIV_PATTERN.sub("\n", text)
        text = cls.P_PATTERN.sub("\n", text)
        
        # Remove all other HTML tags
        text = cls.TAG_PATTERN.sub("", text)
        
        # Decode HTML entities
        for entity, char in cls.ENTITIES.items():
            text = text.replace(entity, char)
        
        # Clean up whitespace
        lines = [line.strip() for line in text.split("\n")]
        text = "\n".join(line for line in lines if line)
        
        return text.strip()


# =============================================================================
# DOCX CONVERTER FOR CHAT
# =============================================================================

class ChatDocxConverter:
    """
    Converts chat messages to DOCX format.
    
    Creates a professionally formatted document with:
    - Title and metadata
    - Chronological message list with timestamps
    - Speaker names and formatting
    """
    
    @classmethod
    def convert(
        cls,
        messages: List[ChatMessage],
        meeting_subject: str,
        meeting_date: Optional[str] = None,
        meeting_id: Optional[str] = None,
        chat_id: Optional[str] = None,
    ) -> bytes:
        """
        Convert chat messages to DOCX bytes.
        
        Args:
            messages: List of ChatMessage objects
            meeting_subject: Meeting subject/title
            meeting_date: Meeting date (ISO format)
            meeting_id: Online meeting ID
            chat_id: Chat thread ID
            
        Returns:
            DOCX file content as bytes
        """
        doc = Document()
        
        # Add title
        title = doc.add_heading(f"Meeting Chat: {meeting_subject}", level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add metadata section
        cls._add_metadata(doc, meeting_subject, meeting_date, meeting_id, chat_id, len(messages))
        
        # Add separator
        doc.add_paragraph("─" * 60)
        
        # Add chat messages section
        doc.add_heading("Chat Messages", level=1)
        
        if not messages:
            doc.add_paragraph("No messages in this meeting chat.", style="Intense Quote")
        else:
            cls._add_messages(doc, messages)
        
        # Add footer
        doc.add_paragraph()
        doc.add_paragraph("─" * 60)
        footer = doc.add_paragraph(
            f"Generated by Meeting Chat Pipeline | "
            f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}"
        )
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Save to bytes
        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        
        return buffer.getvalue()
    
    @classmethod
    def _add_metadata(
        cls,
        doc: Document,
        subject: str,
        meeting_date: Optional[str],
        meeting_id: Optional[str],
        chat_id: Optional[str],
        message_count: int,
    ):
        """Add metadata section to the document."""
        meta_para = doc.add_paragraph()
        
        # Format meeting date
        if meeting_date:
            try:
                dt = datetime.fromisoformat(meeting_date.replace("Z", "+00:00"))
                formatted_date = dt.strftime("%B %d, %Y at %I:%M %p")
            except ValueError:
                formatted_date = meeting_date
        else:
            formatted_date = "Unknown"
        
        meta_para.add_run("Meeting: ").bold = True
        meta_para.add_run(f"{subject}\n")
        
        meta_para.add_run("Date: ").bold = True
        meta_para.add_run(f"{formatted_date}\n")
        
        meta_para.add_run("Total Messages: ").bold = True
        meta_para.add_run(f"{message_count}\n")
        
        if meeting_id:
            meta_para.add_run("Meeting ID: ").bold = True
            meta_para.add_run(f"{meeting_id[:50]}...\n")
    
    @classmethod
    def _add_messages(cls, doc: Document, messages: List[ChatMessage]):
        """Add chat messages to the document."""
        current_date = None
        
        for msg in messages:
            # Parse timestamp
            try:
                dt = datetime.fromisoformat(msg.created_datetime.replace("Z", "+00:00"))
                msg_date = dt.strftime("%Y-%m-%d")
                msg_time = dt.strftime("%I:%M %p")
            except ValueError:
                msg_date = "Unknown"
                msg_time = "Unknown"
            
            # Add date header if new day
            if msg_date != current_date:
                current_date = msg_date
                date_para = doc.add_paragraph()
                date_run = date_para.add_run(f"\n📅 {msg_date}")
                date_run.bold = True
                date_run.font.size = Pt(11)
            
            # Add message
            msg_para = doc.add_paragraph()
            
            # Timestamp
            time_run = msg_para.add_run(f"[{msg_time}] ")
            time_run.font.size = Pt(9)
            time_run.font.color.rgb = RGBColor(128, 128, 128)
            
            # Speaker name
            speaker_run = msg_para.add_run(f"{msg.sender_name}: ")
            speaker_run.bold = True
            speaker_run.font.size = Pt(10)
            
            # Message content
            content = msg.content
            if msg.content_type == "html":
                content = HTMLToText.convert(content)
            
            content_run = msg_para.add_run(content)
            content_run.font.size = Pt(10)
    
    @classmethod
    def to_plain_text(cls, messages: List[ChatMessage]) -> str:
        """
        Convert chat messages to plain text format.
        
        Args:
            messages: List of ChatMessage objects
            
        Returns:
            Plain text representation of the chat
        """
        lines = []
        current_date = None
        
        for msg in messages:
            # Parse timestamp
            try:
                dt = datetime.fromisoformat(msg.created_datetime.replace("Z", "+00:00"))
                msg_date = dt.strftime("%Y-%m-%d")
                msg_time = dt.strftime("%H:%M:%S")
            except ValueError:
                msg_date = "Unknown"
                msg_time = "Unknown"
            
            # Add date header if new day
            if msg_date != current_date:
                current_date = msg_date
                lines.append(f"\n=== {msg_date} ===\n")
            
            # Get content
            content = msg.content
            if msg.content_type == "html":
                content = HTMLToText.convert(content)
            
            lines.append(f"[{msg_time}] {msg.sender_name}: {content}")
        
        return "\n".join(lines)


# =============================================================================
# S3 STORAGE CLASS FOR CHAT
# =============================================================================

class ChatS3Storage:
    """
    S3 Storage handler for meeting chat files.
    
    Handles:
    - Converting chat messages to DOCX format
    - Uploading to S3 with proper naming and folder structure
    - Managing chat files in S3
    """
    
    def __init__(self, config: Config):
        """
        Initialize the Chat S3 Storage handler.
        
        Args:
            config: Configuration instance
            
        Raises:
            S3StorageError: If S3 connection fails
        """
        self.config = config
        self.logger = config.logger
        self.bucket_name = config.s3_bucket_name
        
        # Use "chats" subfolder under the configured prefix
        base_prefix = config.s3_prefix.rstrip("/")
        self.prefix = f"{base_prefix}/chats/"
        
        try:
            self._client = boto3.client("s3", region_name=config.aws_region)
            self._resource = boto3.resource("s3", region_name=config.aws_region)
            self._bucket = self._resource.Bucket(self.bucket_name)
            self.logger.debug(f"Connected to S3 bucket: {self.bucket_name}")
            
        except NoCredentialsError:
            raise S3StorageError(
                "No AWS credentials found. "
                "Ensure AWS credentials are configured."
            )
        except Exception as e:
            raise S3StorageError(f"Failed to connect to S3: {e}")
    
    # -------------------------------------------------------------------------
    # FILE NAMING AND PATH UTILITIES
    # -------------------------------------------------------------------------
    
    @staticmethod
    def sanitize_filename(name: str, max_length: int = 50) -> str:
        """
        Sanitize a string for use in a filename.
        
        Args:
            name: Original string
            max_length: Maximum length for the result
            
        Returns:
            Sanitized filename-safe string
        """
        # Remove or replace invalid characters
        sanitized = re.sub(r'[<>:"/\\|?*]', "", name)
        sanitized = re.sub(r"\s+", "_", sanitized)
        sanitized = re.sub(r"[^\w\-_]", "", sanitized)
        
        # Truncate if needed
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length]
        
        return sanitized or "meeting_chat"
    
    @staticmethod
    def hash_chat_id(chat_id: str, length: int = 8) -> str:
        """
        Create a short hash of the chat ID for the filename.
        
        Args:
            chat_id: Full chat thread ID
            length: Length of the hash to return
            
        Returns:
            Short hash string
        """
        return hashlib.md5(chat_id.encode()).hexdigest()[:length]
    
    def generate_s3_key(
        self,
        chat_id: str,
        meeting_subject: str,
        meeting_date: Optional[str] = None,
    ) -> str:
        """
        Generate the S3 object key for a chat document.
        
        Format: {prefix}{year}/{month}/{sanitized_subject}_{chat_hash}.docx
        
        Args:
            chat_id: Chat thread ID
            meeting_subject: Meeting subject
            meeting_date: Meeting date (ISO format)
            
        Returns:
            S3 object key
        """
        # Extract year and month from meeting date
        if meeting_date:
            try:
                dt = datetime.fromisoformat(meeting_date.replace("Z", "+00:00"))
                year = dt.strftime("%Y")
                month = dt.strftime("%m")
            except ValueError:
                year = datetime.now().strftime("%Y")
                month = datetime.now().strftime("%m")
        else:
            year = datetime.now().strftime("%Y")
            month = datetime.now().strftime("%m")
        
        # Create filename
        safe_subject = self.sanitize_filename(meeting_subject)
        chat_hash = self.hash_chat_id(chat_id)
        filename = f"{safe_subject}_{chat_hash}.docx"
        
        # Combine into full key
        key = f"{self.prefix}{year}/{month}/{filename}"
        
        return key
    
    # -------------------------------------------------------------------------
    # UPLOAD OPERATIONS
    # -------------------------------------------------------------------------
    
    def upload_chat(
        self,
        messages: List[ChatMessage],
        chat_id: str,
        meeting_subject: str,
        meeting_date: Optional[str] = None,
        meeting_id: Optional[str] = None,
    ) -> str:
        """
        Convert chat messages to DOCX and upload to S3.
        
        Args:
            messages: List of ChatMessage objects
            chat_id: Chat thread ID
            meeting_subject: Meeting subject
            meeting_date: Meeting date (ISO format)
            meeting_id: Online meeting ID
            
        Returns:
            S3 path where document was uploaded
            
        Raises:
            S3StorageError: If conversion or upload fails
        """
        self.logger.info(f"Preparing chat document for: {meeting_subject}")
        
        try:
            # Convert to DOCX
            docx_content = ChatDocxConverter.convert(
                messages=messages,
                meeting_subject=meeting_subject,
                meeting_date=meeting_date,
                meeting_id=meeting_id,
                chat_id=chat_id,
            )
            
            # Generate S3 key
            s3_key = self.generate_s3_key(chat_id, meeting_subject, meeting_date)
            
            # Upload to S3
            self.logger.debug(f"Uploading to s3://{self.bucket_name}/{s3_key}")
            
            self._client.put_object(
                Bucket=self.bucket_name,
                Key=s3_key,
                Body=docx_content,
                ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                Metadata={
                    "chat_id": chat_id[:256],
                    "meeting_subject": meeting_subject[:256],
                    "meeting_date": meeting_date or "",
                    "message_count": str(len(messages)),
                    "generated_at": datetime.now().isoformat(),
                },
            )
            
            s3_path = f"s3://{self.bucket_name}/{s3_key}"
            self.logger.info(f"  ✅ Uploaded chat document: {s3_key}")
            
            return s3_path
            
        except ClientError as e:
            raise S3StorageError(f"Failed to upload chat to S3: {e}")
        except Exception as e:
            raise S3StorageError(f"Error processing chat document: {e}")
    
    # -------------------------------------------------------------------------
    # QUERY OPERATIONS
    # -------------------------------------------------------------------------
    
    def list_chat_files(self, prefix: str = None) -> List[dict]:
        """
        List all chat files in the S3 bucket.
        
        Args:
            prefix: Optional prefix to filter files
            
        Returns:
            List of file info dictionaries
        """
        search_prefix = prefix or self.prefix
        
        try:
            files = []
            paginator = self._client.get_paginator("list_objects_v2")
            
            for page in paginator.paginate(Bucket=self.bucket_name, Prefix=search_prefix):
                for obj in page.get("Contents", []):
                    files.append({
                        "key": obj["Key"],
                        "size": obj["Size"],
                        "last_modified": obj["LastModified"].isoformat(),
                    })
            
            return files
            
        except ClientError as e:
            raise S3StorageError(f"Failed to list chat files: {e}")
    
    def get_storage_stats(self) -> dict:
        """
        Get statistics about chat storage.
        
        Returns:
            Dictionary with storage statistics
        """
        files = self.list_chat_files()
        
        docx_files = [f for f in files if f["key"].endswith(".docx")]
        total_size = sum(f["size"] for f in files)
        
        return {
            "total_files": len(files),
            "docx_files": len(docx_files),
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "prefix": self.prefix,
        }
    
    def file_exists(self, s3_key: str) -> bool:
        """
        Check if a file exists in S3.
        
        Args:
            s3_key: S3 object key
            
        Returns:
            True if file exists
        """
        try:
            self._client.head_object(Bucket=self.bucket_name, Key=s3_key)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                return False
            raise S3StorageError(f"Error checking file existence: {e}")
    
    # -------------------------------------------------------------------------
    # DELETE OPERATIONS
    # -------------------------------------------------------------------------
    
    def delete_file(self, s3_key: str) -> bool:
        """
        Delete a file from S3.
        
        Args:
            s3_key: S3 object key
            
        Returns:
            True if deletion was successful
        """
        try:
            self._client.delete_object(Bucket=self.bucket_name, Key=s3_key)
            self.logger.debug(f"Deleted: {s3_key}")
            return True
        except ClientError as e:
            raise S3StorageError(f"Failed to delete file: {e}")
    
    def delete_all_chat_files(self, confirm: bool = False) -> int:
        """
        Delete all chat files from S3.
        
        Args:
            confirm: Must be True to actually delete
            
        Returns:
            Number of files deleted
        """
        if not confirm:
            raise S3StorageError("Must pass confirm=True to delete all files")
        
        self.logger.warning(f"Deleting all chat files with prefix: {self.prefix}")
        
        files = self.list_chat_files()
        deleted = 0
        
        for file_info in files:
            try:
                self.delete_file(file_info["key"])
                deleted += 1
            except Exception as e:
                self.logger.error(f"Failed to delete {file_info['key']}: {e}")
        
        self.logger.info(f"Deleted {deleted} chat files")
        return deleted


# =============================================================================
# MODULE-LEVEL CONVENIENCE
# =============================================================================

def create_chat_storage(config: Config = None) -> ChatS3Storage:
    """Create a ChatS3Storage instance."""
    if config is None:
        config = Config()
    return ChatS3Storage(config)


# =============================================================================
# MAIN (for testing)
# =============================================================================

if __name__ == "__main__":
    from config import Config, ConfigurationError
    
    try:
        config = Config()
        storage = ChatS3Storage(config)
        
        print("\n" + "=" * 60)
        print("CHAT S3 STORAGE STATUS")
        print("=" * 60)
        print(f"Bucket: {storage.bucket_name}")
        print(f"Prefix: {storage.prefix}")
        
        stats = storage.get_storage_stats()
        print(f"\n📦 Storage Stats:")
        print(f"   Total files: {stats['total_files']}")
        print(f"   DOCX files: {stats['docx_files']}")
        print(f"   Total size: {stats['total_size_mb']} MB")
        
        print("\n✅ Chat S3 Storage test completed!")
        
    except ConfigurationError as e:
        print(f"\n❌ Configuration Error: {e}")
    except S3StorageError as e:
        print(f"\n❌ S3 Error: {e}")
