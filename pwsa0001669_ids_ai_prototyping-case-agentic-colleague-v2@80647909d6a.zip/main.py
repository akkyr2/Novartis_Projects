#!/usr/bin/env python
# coding: utf-8
"""
==============================================================================
AGENTIC COLLEAGUE - MAIN APPLICATION (v2.0 Refactored)
==============================================================================
An AI-powered project management assistant that ingests collaboration content
(meetings, chats, emails) and extracts structured project signals.

This application uses:
- LangGraph for workflow orchestration
- FastAPI for REST API endpoints
- OpenSearch for vector search (RAG)
- DynamoDB for work items storage
- Amazon Bedrock (Claude) for LLM inference
- Amazon Titan for embeddings

Architecture:
- decision_node: Parses user intent and routes to appropriate handler
- inference_node: Handles retrieval queries with RAG
- update_node: Handles work item updates
- create_node: Handles work item creation
- clarify_node: Handles clarification requests

Key Improvements in v2.0:
- Improved project name extraction to prevent hallucination
- Enhanced intent detection with multi-intent support
- Better RAG retrieval with hybrid search
- Cleaner code structure with proper documentation
==============================================================================
"""

# ==============================================================================
# SECTION 1: IMPORTS
# ==============================================================================
import os
import json
import copy
import hashlib
import math
import re
import uuid
import logging
import base64
import asyncio
import markdown
from typing import TypedDict, List, Optional, Literal, Any, Dict
from datetime import datetime, timezone, timedelta
from io import BytesIO
from decimal import Decimal
from enum import Enum
from concurrent.futures import ThreadPoolExecutor

# Third-party imports
import boto3
import requests
import numpy as np
import pandas as pd
from requests_aws4auth import AWS4Auth
from boto3.dynamodb.conditions import Key
from sklearn.metrics.pairwise import cosine_similarity
from pydantic import BaseModel, Field
from docx import Document

# LangChain and LangGraph imports
from langgraph.graph import StateGraph, END
from langgraph.types import Command
from langchain_aws import ChatBedrock

# FastAPI imports
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# Local imports
from eval import evaluation, load_records


# ==============================================================================
# SECTION 2: LOGGING CONFIGURATION
# ==============================================================================
logging.basicConfig(
    filename="eval_logs.txt",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)
logger = logging.getLogger(__name__)


# ==============================================================================
# SECTION 3: AWS CONFIGURATION & CONSTANTS
# ==============================================================================
AWS_REGION = "us-east-1"
S3_BUCKET_NAME = "ids-aini-prototype-ai-analytics"
OPENSEARCH_HOST = "https://oqjh772goqkmg0mlp7gg.us-east-1.aoss.amazonaws.com"
OPENSEARCH_INDEX = "work_evidence_test"
DYNAMODB_WORK_ITEMS_TABLE = "AgenticColleague_WorkItems_Test"

# AWS Clients (initialized once at module load)
s3_client = boto3.client('s3', region_name=AWS_REGION)
bedrock_client = boto3.client("bedrock-runtime", region_name=AWS_REGION)
dynamodb_resource = boto3.resource("dynamodb", region_name=AWS_REGION)

# Model IDs
EMBEDDING_MODEL_ID = "amazon.titan-embed-text-v2:0"
LLM_MODEL_ID = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"


# ==============================================================================
# SECTION 4: IPST FUNCTION MAP
# Maps team member names to their functional role for automatic assignment.
# ==============================================================================
IPST_FUNCTION_MAP: dict = {
    "Tom Barry": "GM", "Tom": "GM",
    "Stan Tsvirko": "Sponsor", "Stan": "Sponsor",
    "Saburi Mohan": "IMO", "Saburi": "IMO",
    "Satya Shukla": "CE", "Satya": "CE",
    "Ash": "Medical",
    "Revath": "Regulatory",
    "Mohan Dhanalakota": "Market Access", "Mohan": "Market Access",
    "Sarah Chen": "Business Lead", "Sarah": "Business Lead",
    "Nina Patel": "Bus. Excellence", "Nina": "Bus. Excellence",
    "Dr. Priya Nair": "Medical", "Dr Priya Nair": "Medical",
    "Priya Nair": "Medical", "Priya": "Medical",
    "Luis Martinez": "Market Access", "Luis": "Market Access",
    "Mark Davidson": "Finance", "Mark": "Finance",
    "Jake Reynolds": "Marketing", "Jake": "Marketing",
    "Rachel Kim": "Field Strategy", "Rachel": "Field Strategy",
    "Pawan Mane": "Developer", "Pawan": "Developer",
    "Ayush Shaw": "Project Manager", "Ayush": "Project Manager",
    "Shyam Vora": "Product Owner", "Shyam": "Product Owner",
    "Anita": "Analytics",
}


# ==============================================================================
# SECTION 5: PROJECT NAME NORMALIZATION
# Dynamic project detection - projects are loaded from DynamoDB at runtime.
# ==============================================================================

# Cache for loaded projects (refreshed periodically)
_PROJECTS_CACHE = {
    "projects": [],
    "last_loaded": None,
    "cache_ttl_seconds": 300  # 5 minutes
}


def get_known_projects(force_refresh: bool = False) -> List[str]:
    """
    Get list of known projects from DynamoDB.
    Caches results to avoid repeated DB calls.
    
    Returns:
        List of unique project names from work items
    """
    now = datetime.now(timezone.utc)
    last_loaded = _PROJECTS_CACHE["last_loaded"]
    
    # Check if cache is still valid
    if not force_refresh and last_loaded:
        age = (now - last_loaded).total_seconds()
        if age < _PROJECTS_CACHE["cache_ttl_seconds"] and _PROJECTS_CACHE["projects"]:
            return _PROJECTS_CACHE["projects"]
    
    # Load from DynamoDB
    try:
        table = dynamodb_resource.Table(DYNAMODB_WORK_ITEMS_TABLE)
        items = []
        
        response = table.scan(
            ProjectionExpression="project_name"
        )
        items.extend(response.get("Items", []))
        
        while "LastEvaluatedKey" in response:
            response = table.scan(
                ProjectionExpression="project_name",
                ExclusiveStartKey=response["LastEvaluatedKey"]
            )
            items.extend(response.get("Items", []))
        
        # Extract unique project names
        projects = set()
        for item in items:
            pname = item.get("project_name", "").strip()
            if pname and pname.lower() not in ["unassigned", "", "none"]:
                projects.add(pname)
        
        project_list = sorted(list(projects))
        
        # Update cache
        _PROJECTS_CACHE["projects"] = project_list
        _PROJECTS_CACHE["last_loaded"] = now
        
        print(f"[PROJECTS] Loaded {len(project_list)} projects from DynamoDB: {project_list}")
        return project_list
        
    except Exception as e:
        print(f"[PROJECTS] Error loading projects: {e}")
        # Return cached if available, else empty
        return _PROJECTS_CACHE["projects"] or []


# ==============================================================================
# SECTION 6: FASTAPI APPLICATION SETUP
# ==============================================================================
def get_root_path() -> str:
    """Get root path for FastAPI when behind proxy."""
    return os.environ.get("ROOT_PATH", "")


app = FastAPI(
    title="Agentic Colleague API",
    description="API for Agentic Colleague - Work Item Management and RAG-based Q&A",
    version="2.0.0",
    root_path=get_root_path(),
    openapi_url="/openapi.json",
    docs_url="/docs",
    redoc_url="/redoc",
)


@app.middleware("http")
async def add_root_path_from_headers(request, call_next):
    """Middleware for proxy header handling."""
    return await call_next(request)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500", "http://localhost:5500",
                   "http://localhost:3000", "http://localhost:8000", "*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==============================================================================
# SECTION 7: LANGGRAPH STATE DEFINITION
# ==============================================================================
class GraphState(TypedDict, total=False):
    """
    State object passed through the LangGraph workflow.
    Contains all information needed for intent processing and response generation.
    """
    # Session info
    user_input: str
    user_id: str
    session_id: str
    chat_history: List[str]
    result_payload: dict

    # Project context
    workspace_id: str
    project_id: str
    project_name: str

    # Work item fields
    reporter: str
    assignee: str
    assignees: List[str]
    intent: str
    work_item_id: str
    title: str
    description: str
    status: str
    priority: str
    due_date: str
    lifecycle_state: str
    is_deleted: bool
    blocker: str
    dependency: str
    issue: str
    summary: str
    decision: str
    action: str

    # Retrieval context
    retrieval_query: str
    retrieval_plan: Dict[str, Any]
    work_items_results: List[Dict[str, Any]]
    work_evidence_results: List[Dict[str, Any]]
    retrieval_results: Any

    # Resolution tracking
    resolved_work_item_id: str
    resolution_confidence: float
    conflict_flag: bool
    conflict_reason: str
    clarification_needed: bool
    clarification_question: str
    clarification_received: bool

    # Decision and response
    decision_type: str
    decision_reason: str
    action_plan: List[Dict[str, Any]]
    final_response: str


# ==============================================================================
# SECTION 8: AWS AUTHENTICATION HELPERS
# ==============================================================================
def get_fresh_awsauth():
    """
    Get fresh AWS4Auth credentials for OpenSearch Serverless.

    AWS temporary credentials expire, so we must refresh them before each
    OpenSearch request rather than using static credentials.

    Returns:
        AWS4Auth: Fresh authentication object
    """
    session = boto3.Session()
    credentials = session.get_credentials()
    return AWS4Auth(
        credentials.access_key,
        credentials.secret_key,
        AWS_REGION,
        "aoss",
        session_token=credentials.token
    )


# ==============================================================================
# SECTION 9: LLM CONFIGURATION
# ==============================================================================
llm = ChatBedrock(
    model=LLM_MODEL_ID,
    region_name=AWS_REGION,
    model_kwargs={
        "temperature": 0.1,
        "max_tokens": 2056,
    },
)


def clean_llm_output(text: str) -> str:
    """
    Clean LLM output by removing markdown code fences.

    Args:
        text: Raw LLM output

    Returns:
        Cleaned string suitable for JSON parsing
    """
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    if text.lower().startswith("json"):
        text = text[4:].strip()
    return text.strip()


# ==============================================================================
# SECTION 10: EMBEDDING FUNCTIONS
# ==============================================================================
def vectorize_with_titan(text: str, model_id: str = EMBEDDING_MODEL_ID) -> List[float]:
    """
    Generate vector embedding using Amazon Titan v2.

    Args:
        text: Text to embed (max ~8000 chars recommended)
        model_id: Titan model ID

    Returns:
        List of floats (1024 dimensions for Titan v2)
    """
    payload = {"inputText": text[:8000]}  # Titan limit
    response = bedrock_client.invoke_model(
        modelId=model_id,
        body=json.dumps(payload),
        accept="application/json",
        contentType="application/json"
    )
    response_body = json.loads(response["body"].read())
    return response_body["embedding"]


# ==============================================================================
# SECTION 11: PROJECT NAME EXTRACTION AND NORMALIZATION
# ==============================================================================
def normalize_project_name(project_name: str) -> str:
    """
    Normalize project name to canonical form.
    
    Handles common variations like underscores, hyphens, case differences.
    Tries to match against known projects from DynamoDB.

    Args:
        project_name: Raw project name from user input or LLM

    Returns:
        Normalized project name
    """
    if not project_name:
        return ""
    
    # Clean up the input
    name = project_name.strip()
    
    # Try to match against known projects using fuzzy matching
    # This works for ANY project naming convention (IPST, CamelCase, etc.)
    known = get_known_projects()
    for proj in known:
        if _fuzzy_project_match(name, proj):
            print(f"[PROJECT] Normalized '{name}' -> '{proj}' via fuzzy match")
            return proj
    
    # No match found - return cleaned version with proper title case
    # This preserves the user's input while cleaning separators
    cleaned = re.sub(r'[_\-]+', ' ', name)  # Replace separators with spaces
    cleaned = ' '.join(word.capitalize() for word in cleaned.split())  # Title case
    return cleaned


def _normalize_for_comparison(text: str) -> str:
    """
    Normalize text for comparison by removing special chars and lowercasing.
    Handles underscores, hyphens, spaces uniformly.
    """
    if not text:
        return ""
    # Convert to lowercase, replace separators with space, collapse multiple spaces
    normalized = text.lower()
    normalized = re.sub(r'[_\-]+', ' ', normalized)  # underscores/hyphens -> space
    normalized = re.sub(r'\s+', ' ', normalized)  # collapse spaces
    return normalized.strip()


def _fuzzy_project_match(query_project: str, db_project: str, threshold: float = 0.7) -> bool:
    """
    Fuzzy match two project names, handling underscores/spaces/hyphens.
    
    Returns True if projects are likely the same.
    """
    if not query_project or not db_project:
        return False
    
    # Normalize both for comparison
    q_norm = _normalize_for_comparison(query_project)
    d_norm = _normalize_for_comparison(db_project)
    
    # Exact match after normalization
    if q_norm == d_norm:
        return True
    
    # One contains the other
    if q_norm in d_norm or d_norm in q_norm:
        return True
    
    # Check word overlap (for multi-word project names)
    q_words = set(q_norm.split())
    d_words = set(d_norm.split())
    
    if q_words and d_words:
        # If all query words are in db project (or vice versa)
        if q_words.issubset(d_words) or d_words.issubset(q_words):
            return True
        
        # Calculate Jaccard similarity
        intersection = len(q_words & d_words)
        union = len(q_words | d_words)
        if union > 0 and intersection / union >= threshold:
            return True
    
    return False


def extract_project_name_from_query(query: str) -> Optional[str]:
    """
    Extract project name from user query.
    
    Uses multiple strategies:
    1. Match against known projects from DynamoDB
    2. IPST prefix patterns (IPST Dexavir, IPST_Dexavir, etc.)
    3. Explicit "project X" patterns
    4. CamelCase names

    Args:
        query: User's query string

    Returns:
        Extracted and normalized project name, or None
    """
    query_clean = query.strip()
    query_lower = query_clean.lower()
    
    # Words to ignore - these are NOT project names
    ignore_words = {
        'the', 'this', 'that', 'our', 'my', 'a', 'an', 'project', 'team',
        'meeting', 'discussion', 'launch', 'happened', 'on', 'for', 'about',
        'what', 'when', 'where', 'how', 'why', 'which', 'last', 'recent',
        'was', 'is', 'are', 'were', 'been', 'have', 'has', 'had'
    }
    
    # Strategy 1: Check against known projects from DynamoDB (highest priority)
    known_projects = get_known_projects()
    for proj in known_projects:
        proj_lower = proj.lower()
        # Check various forms
        proj_variants = [
            proj_lower,
            proj_lower.replace(" ", "_"),
            proj_lower.replace(" ", "-"),
            proj_lower.replace(" ", ""),
        ]
        for variant in proj_variants:
            if variant in query_lower:
                print(f"[PROJECT] Matched known project: {proj}")
                return proj
    
    # Strategy 2: "project X" or "X project" patterns
    # Be more strict - only match after "project" keyword
    project_match = re.search(r'project\s+([A-Za-z][A-Za-z0-9]+)', query, re.IGNORECASE)
    if project_match:
        candidate = project_match.group(1).strip()
        if candidate.lower() not in ignore_words:
            print(f"[PROJECT] Explicit 'project X' pattern: {candidate}")
            return normalize_project_name(candidate)
    
    # Strategy 3: CamelCase names (e.g., GlucoAlpha, GlucoNova)
    camel_case = re.findall(r'\b([A-Z][a-z]+[A-Z][a-zA-Z]*)', query_clean)
    for name in camel_case:
        if name.lower() not in ignore_words:
            print(f"[PROJECT] CamelCase name found: {name}")
            return name
    
    return None


# ==============================================================================
# SECTION 12: OPENSEARCH FUNCTIONS
# ==============================================================================
def knn_search_work_evidence(
    query_text: str,
    k: int = 10,
    project_filter: str = None
) -> List[dict]:
    """
    Search work evidence using text matching.
    
    NOTE: Originally designed for KNN vector search, but the OpenSearch index
    field 'vector_embedding' is not configured as knn_vector type.
    Now uses text-based search instead.

    Args:
        query_text: Search query
        k: Number of results
        project_filter: Optional project name filter

    Returns:
        List of matching documents with scores
    """
    # Delegate to text search since KNN is not supported on this index
    return text_search_work_evidence(query_text, k, project_filter)


def text_search_work_evidence(
    query_text: str,
    k: int = 10,
    project_filter: str = None
) -> List[dict]:
    """
    Fallback text-based search when KNN fails.
    Uses match query on text fields instead of vector search.
    """
    try:
        awsauth = get_fresh_awsauth()
        
        # Build a simpler text-based query
        should_clauses = [
            {"match": {"clean_text": {"query": query_text, "boost": 2.0}}},
            {"match": {"summary": {"query": query_text, "boost": 1.5}}},
        ]
        
        if project_filter:
            should_clauses.append({
                "match": {"clean_text": {"query": project_filter, "boost": 3.0}}
            })
            should_clauses.append({
                "match": {"summary": {"query": project_filter, "boost": 2.0}}
            })
        
        query_body = {
            "size": k,
            "query": {
                "bool": {
                    "should": should_clauses,
                    "minimum_should_match": 1
                }
            },
            "_source": [
                "summary", "clean_text", "source_uri", "source_type",
                "metadata", "action_items_detected", "decisions_detected",
                "project_name", "evidence_id"
            ]
        }
        
        print(f"[OPENSEARCH] Text search fallback for: {query_text[:50]}...")
        
        response = requests.post(
            f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_search",
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            json=query_body,
            timeout=30
        )
        
        if response.status_code != 200:
            print(f"[OPENSEARCH] Text search also failed: {response.status_code}")
            print(f"[OPENSEARCH] Error: {response.text[:300]}")
            return []
        
        hits = response.json().get("hits", {}).get("hits", [])
        print(f"[OPENSEARCH] Text search returned {len(hits)} hits")
        
        results = []
        for hit in hits:
            source = hit.get("_source", {})
            results.append({
                "score": hit.get("_score"),
                "summary": source.get("summary", ""),
                "clean_text": source.get("clean_text", ""),
                "source_uri": source.get("source_uri", ""),
                "source_type": source.get("source_type", ""),
                "metadata": source.get("metadata", {}),
                "action_items_detected": source.get("action_items_detected", []),
                "decisions_detected": source.get("decisions_detected", []),
            })
        
        return results
        
    except Exception as e:
        print(f"[OPENSEARCH] Text search error: {e}")
        return []


def hybrid_search_opensearch(
    query_text: str,
    project_name: str = None,
    k: int = 15
) -> List[dict]:
    """
    Perform text-based search with project boosting.
    
    NOTE: KNN is disabled because the index field 'vector_embedding' is not 
    configured as knn_vector type. Using text-only search instead.

    Args:
        query_text: Search query
        project_name: Optional project for boosting
        k: Number of results

    Returns:
        List of matching documents
    """
    try:
        awsauth = get_fresh_awsauth()
        
        print(f"[OPENSEARCH] Text search: {query_text[:50]}... (project: {project_name})")

        # Build bool query with text matching only (no KNN - index doesn't support it)
        should_clauses = []

        if project_name:
            # Generate project name variants for fuzzy matching
            project_variants = _generate_project_variants(project_name)
            print(f"[OPENSEARCH] Project variants for search: {project_variants[:5]}...")
            
            # Add high-boost clauses for each variant
            for variant in project_variants[:6]:  # Limit to avoid query bloat
                should_clauses.append({
                    "match": {
                        "metadata.matched_project.project_name": {
                            "query": variant,
                            "boost": 10.0  # Highest priority for exact project match
                        }
                    }
                })
            
            # Add phrase matches for primary project name
            should_clauses.append({
                "match_phrase": {
                    "clean_text": {"query": project_name, "boost": 5.0}
                }
            })
            should_clauses.append({
                "match_phrase": {
                    "summary": {"query": project_name, "boost": 5.0}
                }
            })
            
            # Also try with underscores/spaces swapped
            alt_name = project_name.replace(' ', '_') if ' ' in project_name else project_name.replace('_', ' ')
            if alt_name != project_name:
                should_clauses.append({
                    "match_phrase": {
                        "clean_text": {"query": alt_name, "boost": 5.0}
                    }
                })
                should_clauses.append({
                    "match_phrase": {
                        "summary": {"query": alt_name, "boost": 5.0}
                    }
                })
            
            should_clauses.append({
                "match": {
                    "clean_text": {"query": project_name, "boost": 3.0}
                }
            })

        # Add query text matching
        should_clauses.append({
            "match": {"summary": {"query": query_text, "boost": 2.0}}
        })
        should_clauses.append({
            "match": {"clean_text": {"query": query_text, "boost": 1.5}}
        })

        query_body = {
            "size": k,
            "query": {
                "bool": {
                    "should": should_clauses,
                    "minimum_should_match": 1
                }
            },
            "_source": [
                "summary", "clean_text", "source_uri", "source_type",
                "metadata", "action_items_detected", "decisions_detected",
                "project_name", "evidence_id"
            ],
            "sort": [
                {"_score": {"order": "desc"}}
            ]
        }

        response = requests.post(
            f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_search",
            auth=awsauth,
            headers={"Content-Type": "application/json"},
            json=query_body,
            timeout=30
        )

        if response.status_code != 200:
            print(f"[OPENSEARCH] Text search failed: {response.status_code}")
            print(f"[OPENSEARCH] Error: {response.text[:300]}")
            return []

        hits = response.json().get("hits", {}).get("hits", [])
        print(f"[OPENSEARCH] Text search returned {len(hits)} hits")
        
        results = []
        for hit in hits:
            source = hit.get("_source", {})
            results.append({
                "score": hit.get("_score"),
                "summary": source.get("summary", ""),
                "clean_text": source.get("clean_text", ""),
                "source_uri": source.get("source_uri", ""),
                "source_type": source.get("source_type", ""),
                "metadata": source.get("metadata", {}),
                "action_items_detected": source.get("action_items_detected", []),
                "decisions_detected": source.get("decisions_detected", []),
                "project_name": source.get("project_name", ""),
            })

        return results

    except Exception as e:
        print(f"[OPENSEARCH] Text search error: {e}")
        import traceback
        traceback.print_exc()
        return []


def index_document(doc: dict) -> dict:
    """Index a document into OpenSearch."""
    awsauth = get_fresh_awsauth()
    response = requests.post(
        f"{OPENSEARCH_HOST}/{OPENSEARCH_INDEX}/_doc",
        auth=awsauth,
        headers={"Content-Type": "application/json"},
        data=json.dumps(doc),
        timeout=30
    )
    return {"status_code": response.status_code, "text": response.text}


# ==============================================================================
# SECTION 13: DYNAMODB FUNCTIONS
# ==============================================================================
def get_all_work_items(
    project_name: str = None,
    status_filter: str = None
) -> pd.DataFrame:
    """
    Retrieve work items from DynamoDB, optionally filtered by project and status.

    Args:
        project_name: Optional project filter (fuzzy matched)
        status_filter: Optional status filter (pending, in progress, done, etc.)

    Returns:
        DataFrame of work items
    """
    table = dynamodb_resource.Table(DYNAMODB_WORK_ITEMS_TABLE)
    items = []

    if project_name:
        # Generate variants with different separators
        variants = _generate_project_variants(project_name)
        print(f"[DYNAMODB] Querying with variants: {variants}")
        
        for variant in variants:
            try:
                response = table.query(
                    KeyConditionExpression=Key("PK").eq(f"PROJECT#{variant}")
                )
                items.extend(response.get("Items", []))
                while "LastEvaluatedKey" in response:
                    response = table.query(
                        KeyConditionExpression=Key("PK").eq(f"PROJECT#{variant}"),
                        ExclusiveStartKey=response["LastEvaluatedKey"],
                    )
                    items.extend(response.get("Items", []))
                if items:
                    print(f"[DYNAMODB] Found {len(items)} items with variant: {variant}")
                    break
            except Exception as e:
                print(f"[DYNAMODB] Query error for {variant}: {e}")
    else:
        response = table.scan()
        items.extend(response.get("Items", []))
        while "LastEvaluatedKey" in response:
            response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
            items.extend(response.get("Items", []))

    df = pd.DataFrame(items)

    if df.empty:
        return pd.DataFrame(columns=[
            "work_item_id", "project_name", "task", "assignee",
            "due_date", "status", "summary"
        ])

    # Apply status filter if specified (filter by UI column: todo, in_progress, done)
    if status_filter and "status" in df.columns:
        total_before = len(df)
        target_column = status_filter  # Already normalized to 'todo', 'in_progress', or 'done'
        
        # Filter: keep items where raw status maps to the target column
        df = df[df["status"].fillna("").apply(get_status_column) == target_column]
        
        # Log the statuses we kept
        if not df.empty:
            raw_statuses = df["status"].value_counts().to_dict()
            print(f"[DYNAMODB] Status filter '{status_filter}' ({target_column}): {total_before} -> {len(df)} items")
            print(f"[DYNAMODB] Raw statuses kept: {raw_statuses}")
        else:
            print(f"[DYNAMODB] Status filter '{status_filter}': {total_before} -> 0 items")

    return df.reset_index(drop=True)


def _generate_project_variants(project_name: str) -> List[str]:
    """
    Generate multiple variants of a project name for querying.
    
    Works generically for ANY project naming convention:
    - Handles underscores, spaces, hyphens interchangeably
    - Generates case variations (title, upper, lower)
    - Handles multi-word projects (e.g., "IPST Dexavir", "Project Apollo")
    - No hardcoded patterns for specific projects
    """
    if not project_name:
        return []
    
    name = project_name.strip()
    variants = set()
    
    # Original
    variants.add(name)
    
    # Case variants
    variants.add(name.title())
    variants.add(name.upper())
    variants.add(name.lower())
    
    # Separator variants (space <-> underscore <-> hyphen)
    # This works for ANY project, not just IPST
    for sep_from, sep_to in [(' ', '_'), ('_', ' '), (' ', '-'), ('-', ' '), ('_', '-'), ('-', '_')]:
        variant = name.replace(sep_from, sep_to)
        variants.add(variant)
        variants.add(variant.title())
        variants.add(variant.lower())
        variants.add(variant.upper())
    
    # For multi-word projects, also try with no separator (e.g., "IPSTDexavir")
    words = re.split(r'[\s_\-]+', name)
    if len(words) > 1:
        # No separator
        no_sep = ''.join(words)
        variants.add(no_sep)
        variants.add(no_sep.title())
        variants.add(no_sep.lower())
        
        # First word uppercase, rest title case (common pattern like "IPST Dexavir")
        if len(words[0]) <= 5:  # Short prefix like IPST, AWS, etc.
            prefix_upper = words[0].upper() + '_' + '_'.join(w.title() for w in words[1:])
            prefix_space = words[0].upper() + ' ' + ' '.join(w.title() for w in words[1:])
            variants.add(prefix_upper)
            variants.add(prefix_space)
    
    return list(variants)


# ==============================================================================
# STATUS COLUMN MAPPING
# Maps raw statuses from ingestion to UI columns (To Do, In Progress, Done)
# ==============================================================================

# Statuses that go into "To Do" column (pending/not started)
TODO_STATUSES = {
    'pending', 'to do', 'todo', 'not started', 'open', 'new',
    'confirmed',  # From ingestion - confirmed action item not yet started
    'uncertain',  # From ingestion - uncertain action item
    'backlog', 'planned', 'queued'
}

# Statuses that go into "In Progress" column  
IN_PROGRESS_STATUSES = {
    'in progress', 'in-progress', 'inprogress', 'in_progress',
    'active', 'started', 'working', 'ongoing', 'wip',
    'in review', 'reviewing', 'testing', 'blocked', 'on hold', 'on-hold',
    'at risk', 'at-risk', 'at_risk'
}

# Statuses that go into "Done" column
DONE_STATUSES = {
    'done', 'completed', 'complete', 'finished', 'closed',
    'resolved', 'verified', 'shipped', 'deployed', 'released'
}

# Combined mapping for quick lookup
STATUS_TO_COLUMN = {}
for s in TODO_STATUSES:
    STATUS_TO_COLUMN[s] = 'todo'
for s in IN_PROGRESS_STATUSES:
    STATUS_TO_COLUMN[s] = 'in_progress'
for s in DONE_STATUSES:
    STATUS_TO_COLUMN[s] = 'done'


def get_status_column(status: str) -> str:
    """
    Map a raw status to its UI column (todo, in_progress, done).
    
    Args:
        status: Raw status string from database
        
    Returns:
        Column name: 'todo', 'in_progress', or 'done'
    """
    if not status:
        return 'todo'  # Default to todo
    
    status_lower = status.lower().strip().replace('-', ' ').replace('_', ' ')
    
    # Direct lookup
    if status_lower in STATUS_TO_COLUMN:
        return STATUS_TO_COLUMN[status_lower]
    
    # Fuzzy matching for variations
    for todo_status in TODO_STATUSES:
        if todo_status in status_lower or status_lower in todo_status:
            return 'todo'
    
    for progress_status in IN_PROGRESS_STATUSES:
        if progress_status.replace('-', ' ').replace('_', ' ') in status_lower:
            return 'in_progress'
    
    for done_status in DONE_STATUSES:
        if done_status in status_lower or status_lower in done_status:
            return 'done'
    
    # Default to todo for unknown statuses
    return 'todo'


def _normalize_status(status: str) -> str:
    """
    Normalize status string for comparison.
    Maps all variations to canonical column names (todo, in_progress, done).
    """
    if not status:
        return "todo"
    
    return get_status_column(status)


def search_work_items_by_project(
    project_name: str,
    fuzzy: bool = True,
    status_filter: str = None
) -> pd.DataFrame:
    """
    Search work items by project name with fuzzy matching.

    Args:
        project_name: Project to search for
        fuzzy: Enable fuzzy matching
        status_filter: Optional status filter

    Returns:
        DataFrame of matching work items
    """
    # First try direct query with project variants
    all_items = get_all_work_items(project_name=project_name, status_filter=status_filter)
    
    if not all_items.empty:
        print(f"[DYNAMODB] Direct project query returned {len(all_items)} items")
        return all_items
    
    # If no results, fall back to scan + fuzzy filter
    print(f"[DYNAMODB] Direct query empty, trying fuzzy scan...")
    all_items = get_all_work_items(status_filter=status_filter)

    if all_items.empty:
        return all_items

    if fuzzy:
        project_norm = _normalize_for_comparison(project_name)
        
        def matches_project(row):
            # Check project_name field with fuzzy matching
            row_project = _safe_str(row.get("project_name"))
            if _fuzzy_project_match(project_name, row_project):
                return True
            
            # Check if normalized project name appears in task/summary
            row_task = _normalize_for_comparison(_safe_str(row.get("task")))
            row_summary = _normalize_for_comparison(_safe_str(row.get("summary")))
            
            if project_norm in row_task or project_norm in row_summary:
                return True
            
            return False
        
        mask = all_items.apply(matches_project, axis=1)
        result = all_items[mask].reset_index(drop=True)
        print(f"[DYNAMODB] Fuzzy filter: {len(all_items)} total -> {len(result)} matched")
        return result

    return all_items[
        all_items["project_name"].str.lower() == project_name.lower()
    ].reset_index(drop=True)


def keyword_search_work_items(
    work_items_df: pd.DataFrame,
    query_text: str,
    max_results: int = 15
) -> pd.DataFrame:
    """
    Keyword-based search across work items (fallback for RAG).

    Args:
        work_items_df: DataFrame to search
        query_text: Search query
        max_results: Max results to return

    Returns:
        Filtered and scored DataFrame
    """
    if work_items_df.empty or not query_text:
        return work_items_df

    stop_words = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'what', 'who',
        'how', 'when', 'where', 'which', 'and', 'or', 'in', 'on',
        'at', 'to', 'for', 'of', 'with', 'from', 'by', 'this', 'that'
    }

    words = [w for w in query_text.lower().split()
             if len(w) > 2 and w not in stop_words]

    if not words:
        return work_items_df.head(max_results)

    searchable = ['task', 'summary', 'task_evidence', 'project_name', 'assignee']
    available = [c for c in searchable if c in work_items_df.columns]

    combined = work_items_df[available].fillna('').astype(str).agg(
        ' '.join, axis=1).str.lower()

    scores = pd.Series(0, index=work_items_df.index)
    for word in words:
        scores += combined.str.contains(word, na=False).astype(int)

    matched = work_items_df[scores > 0].copy()
    matched['_score'] = scores[scores > 0]
    matched = matched.sort_values('_score', ascending=False).head(max_results)
    matched = matched.drop(columns=['_score'])

    return matched.reset_index(drop=True)


def apply_confirmed_update_dynamodb(updated_item: dict) -> dict:
    """Apply update to DynamoDB work items table."""
    if not updated_item:
        return None

    table = dynamodb_resource.Table(DYNAMODB_WORK_ITEMS_TABLE)
    project_name = updated_item.get("project_name") or "Unassigned"
    work_item_id = updated_item.get("work_item_id") or ""

    pk = f"PROJECT#{project_name}"
    sk = f"TASK#{work_item_id}"

    update_values = {k: v for k, v in {
        "evidence_id": updated_item.get("evidence_id"),
        "source_uri": updated_item.get("source_uri"),
        "source_type": updated_item.get("source_type"),
        "project_name": project_name,
        "task": updated_item.get("task"),
        "assignee": updated_item.get("assignee"),
        "due_date": updated_item.get("due_date"),
        "status": updated_item.get("status"),
        "task_evidence": updated_item.get("task_evidence"),
        "summary": updated_item.get("summary"),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }.items() if v is not None}

    parts = []
    names = {}
    values = {}

    for idx, (field, value) in enumerate(update_values.items()):
        parts.append(f"#f{idx} = :v{idx}")
        names[f"#f{idx}"] = field
        values[f":v{idx}"] = value

    response = table.update_item(
        Key={"PK": pk, "SK": sk},
        UpdateExpression="SET " + ", ".join(parts),
        ExpressionAttributeNames=names,
        ExpressionAttributeValues=values,
        ReturnValues="ALL_NEW",
    )

    return response.get("Attributes")


# ==============================================================================
# SECTION 14: INTENT PARSING WITH REACT REASONING
# ==============================================================================
def build_intent_parser_prompt(user_text: str) -> str:
    """
    Build prompt for intent parsing using ReAct-style reasoning.
    
    This prompt:
    1. Extracts project names EXACTLY as mentioned by user
    2. Does NOT hallucinate or invent project names
    3. Uses reasoning to identify intent and entities
    4. Includes known projects from database for context
    5. Extracts assignee for filtering (works for retrieve, update, create intents)
    """
    # Get known projects dynamically from DynamoDB
    known_projects = get_known_projects()
    known_str = ", ".join(f'"{p}"' for p in known_projects) if known_projects else "No projects loaded yet"
    
    return f"""You are an intelligent intent parser for a project management assistant.

TASK: Analyze the user's input and extract structured information for task management.

KNOWN PROJECTS IN DATABASE (for reference):
{known_str}

REASONING STEPS (think through each):
1. What is the user asking for? (information, action, update, creation)
2. Is there a project name mentioned? Match against known projects if possible.
3. Is there a task title/name mentioned? Extract it exactly.
4. Is there a PERSON NAME mentioned for filtering or assignment? (very important!)
5. Are there any field updates? (assignee, due_date, status, priority)
6. What search terms would help find relevant data?

FIELD EXTRACTION RULES:
- "title": Extract the exact task name/title being referenced (in quotes or after "task")
- "assignee": Extract person name for ANY of these cases:
  * User asks about tasks "assigned to X" or "for X" -> assignee = X (for filtering)
  * User says "assign to X" or "give to X" -> assignee = X (for update/create)
  * User mentions a person in context of tasks -> assignee = that person
- "due_date": Extract date if user mentions "due date", "by", "due", "deadline" (format: YYYY-MM-DD or as stated)
- "status": Extract if user says "move to", "mark as", "set status to" (done/in progress/pending/todo)
- "priority": Extract if user mentions "priority", "urgent", "high priority", "low priority"

STATUS KEYWORDS:
- "done", "complete", "completed", "finished" -> status = "done"
- "in progress", "start", "working on", "move to in progress" -> status = "in progress"
- "pending", "todo", "to do", "not started" -> status = "pending"

INTENT CATEGORIES:
- "retrieve" = questions, information requests, status checks, "what", "when", "how many", "tell me about"
- "update" = changing ANY field on existing items: status, assignee, due_date, moving tasks, assigning tasks
- "create" = explicitly adding NEW tasks (user says "create", "add", "new task")
- "unknown" = unclear intent, treat as retrieve

EXAMPLES:
- "Move task X to done" -> intent=update, title=X, status=done
- "Assign task X to John" -> intent=update, title=X, assignee=John
- "Update task X - assign to John, due August 15" -> intent=update, title=X, assignee=John, due_date=2026-08-15
- "Create task Y for project Z" -> intent=create, title=Y, project_name=Z
- "What tasks are assigned to Pawan?" -> intent=retrieve, assignee=Pawan
- "Show me action items for Sarah from project Dexavir" -> intent=retrieve, assignee=Sarah, project_name=Dexavir
- "Which items are assigned to pawan from project dexavir" -> intent=retrieve, assignee=Pawan, project_name=IPST_Dexavir
- "mark it done — task: \"Medical Evidence Review\", assignee: Dr. Priya Nair, project: Noventra IPST" -> intent=update, title="Medical Evidence Review", status=done, assignee=Dr. Priya Nair, project_name=Noventra IPST
- "set status to in progress — task: \"Launch Readiness\", assignee: Sarah, project: Noventra" -> intent=update, title="Launch Readiness", status=in progress, assignee=Sarah
- "set status to to do — task: \"Forecast Update\"" -> intent=update, title="Forecast Update", status=pending

USER INPUT: "{user_text}"

Think step by step, then return ONLY valid JSON:
{{
  "reasoning": "Brief explanation of what you understood",
  "intent": "retrieve|update|create|unknown",
  "project_name": null or "exact project name from user input",
  "retrieval_query": "optimized search query including project name and key terms",
  "work_item_id": null,
  "title": null or "exact task title being referenced",
  "assignee": null or "person name to assign to",
  "status": null or "done|in progress|pending",
  "due_date": null or "date string as mentioned or YYYY-MM-DD",
  "priority": null or "high|medium|low",
  "clarification_needed": false,
  "clarification_question": null
}}"""


def parse_user_intent(user_text: str, chat_history: List[str] = None) -> dict:
    """
    Parse user input using ReAct-style reasoning.
    
    Uses LLM for intent classification. Rule-based extraction is used as backup
    only for project names (which benefit from fuzzy matching against DB).
    
    Assignee, due_date, status, priority are all handled by LLM for flexibility.

    Args:
        user_text: User's input
        chat_history: Conversation history

    Returns:
        Parsed intent dict with project_name, intent, retrieval_query, etc.
    """
    # First, try to extract project name using rules (more reliable for DB matching)
    extracted_project = extract_project_name_from_query(user_text)
    print(f"[INTENT] Rule-based project extraction: {extracted_project}")
    
    # Due date extraction as backup (format normalization)
    rule_due_date = _extract_due_date_from_text(user_text)
    print(f"[INTENT] Rule-based due_date: {rule_due_date}")
    
    prompt = build_intent_parser_prompt(user_text)

    try:
        response = llm.invoke(prompt)
        cleaned = clean_llm_output(response.content)
        parsed = json.loads(cleaned)
        
        print(f"[INTENT] LLM reasoning: {parsed.get('reasoning', 'N/A')}")
        print(f"[INTENT] LLM extracted - intent: {parsed.get('intent')}, title: {parsed.get('title')}")
        print(f"[INTENT] LLM extracted - assignee: {parsed.get('assignee')}, due_date: {parsed.get('due_date')}, status: {parsed.get('status')}, priority: {parsed.get('priority')}")

        # Use rule-based extraction if LLM missed it or got it wrong
        llm_project = parsed.get("project_name")
        if extracted_project:
            # Rule-based extraction takes priority for project (fuzzy DB matching)
            parsed["project_name"] = extracted_project
        elif llm_project:
            # Normalize LLM's project name
            parsed["project_name"] = normalize_project_name(llm_project)
        
        # LLM handles assignee extraction - no rule-based override needed
        # This allows LLM to properly parse complex queries like:
        # "which tasks are assigned to pawan from project dexavir"
        
        # Use rule-based due_date only if LLM missed it (for format normalization)
        if not parsed.get("due_date") and rule_due_date:
            parsed["due_date"] = rule_due_date
            print(f"[INTENT] Using rule-based due_date: {rule_due_date}")
        
        # Ensure retrieval query includes project name
        retrieval_query = parsed.get("retrieval_query") or user_text
        if parsed.get("project_name") and parsed["project_name"].lower() not in retrieval_query.lower():
            retrieval_query = f"{parsed['project_name']} {retrieval_query}"
        parsed["retrieval_query"] = retrieval_query

        parsed["chat_history"] = chat_history or [user_text]

        print(f"[INTENT] Final: intent={parsed.get('intent')}, "
              f"project={parsed.get('project_name')}, "
              f"assignee={parsed.get('assignee')}, "
              f"due_date={parsed.get('due_date')}, "
              f"query={parsed.get('retrieval_query', '')[:60]}...")
        return parsed

    except Exception as e:
        print(f"[INTENT] Parse error: {e}")
        import traceback
        traceback.print_exc()
        
        # Fallback to rule-based parsing (minimal - let LLM handle most fields)
        return {
            "intent": "retrieve",
            "project_name": extracted_project,
            "assignee": "",  # Let LLM handle assignee extraction
            "due_date": rule_due_date,
            "retrieval_query": f"{extracted_project} {user_text}" if extracted_project else user_text,
            "chat_history": chat_history or [user_text],
            "clarification_needed": False,
            "reasoning": "Fallback parsing due to error"
        }


# ==============================================================================
# SECTION 15: RETRIEVAL FUNCTIONS
# ==============================================================================
def build_enriched_query(user_text: str, project_name: str = None) -> str:
    """
    Build enriched query for better RAG retrieval.

    Adds keywords based on detected intent type.
    """
    user_lower = user_text.lower()
    enrichments = []

    if project_name:
        enrichments.append(project_name)

    # Intent-based enrichment
    if any(w in user_lower for w in ["decision", "decided", "agreed"]):
        enrichments.extend(["decisions", "agreed", "resolved"])
    if any(w in user_lower for w in ["blocker", "blocked", "stuck"]):
        enrichments.extend(["blocked", "impediment", "dependency"])
    if any(w in user_lower for w in ["risk", "at risk", "concern"]):
        enrichments.extend(["risk", "concern", "delay"])
    if any(w in user_lower for w in ["action item", "todo", "task"]):
        enrichments.extend(["action items", "tasks", "owner"])
    if any(w in user_lower for w in ["last meeting", "recent", "discussion"]):
        enrichments.extend(["meeting", "transcript", "latest"])
    if any(w in user_lower for w in ["status", "update", "progress"]):
        enrichments.extend(["status", "progress", "update"])

    return f"{user_text} {' '.join(enrichments)}".strip()


def _extract_status_filter_from_query(query: str) -> Optional[str]:
    """
    Extract status filter from user query if they're asking about specific status.
    Maps to UI column names: 'todo', 'in_progress', 'done'.
    
    Examples:
    - "What tasks are pending?" -> "todo"
    - "Show me in progress items" -> "in_progress"
    - "Which tasks are done?" -> "done"
    - "What's confirmed?" -> "todo" (confirmed = todo column)
    """
    query_lower = query.lower()
    
    # Patterns that map to "To Do" column
    todo_patterns = [
        r'\b(pending|to[- ]?do|not started|open|new)\b',
        r'\b(confirmed|uncertain)\b',  # Ingestion statuses -> todo
        r'\b(backlog|planned|queued)\b',
    ]
    
    # Patterns that map to "In Progress" column
    in_progress_patterns = [
        r'\b(in[- ]?progress|active|started|working|ongoing|wip)\b',
        r'\b(in review|reviewing|testing)\b',
        r'\b(blocked|on[- ]?hold|stuck)\b',
        r'\b(at[- ]?risk)\b',
    ]
    
    # Patterns that map to "Done" column
    done_patterns = [
        r'\b(done|completed?|finished|closed)\b',
        r'\b(resolved|verified|shipped|deployed|released)\b',
    ]
    
    # Check for "done" first (most specific)
    for pattern in done_patterns:
        if re.search(pattern, query_lower):
            print(f"[INTENT] Detected status filter: done")
            return 'done'
    
    # Check for "in progress"
    for pattern in in_progress_patterns:
        if re.search(pattern, query_lower):
            print(f"[INTENT] Detected status filter: in_progress")
            return 'in_progress'
    
    # Check for "todo"
    for pattern in todo_patterns:
        if re.search(pattern, query_lower):
            print(f"[INTENT] Detected status filter: todo")
            return 'todo'
    
    return None


def handle_retrieve_intent(intent_result: dict) -> dict:
    """
    Handle retrieval intent with multi-strategy RAG search.
    
    Uses ReAct-style approach:
    1. Try primary search (KNN or hybrid)
    2. If no results, try text-based search
    3. If still no results, try DynamoDB
    4. Combine all results and build answer
    5. Apply filters (assignee, status) from LLM-parsed intent

    Args:
        intent_result: Parsed intent with project_name, retrieval_query, assignee, etc.

    Returns:
        Dict with evidence, work items, and answer
    """
    project_name = intent_result.get("project_name", "")
    user_query = " ".join(intent_result.get("chat_history", []))
    retrieval_query = intent_result.get("retrieval_query") or user_query
    
    # Extract filters from LLM-parsed intent (LLM handles extraction)
    status_filter = _extract_status_filter_from_query(user_query)
    assignee_filter = intent_result.get("assignee", "")  # LLM extracts assignee

    enriched = build_enriched_query(retrieval_query, project_name)

    print(f"[RETRIEVE] === Starting Retrieval ===")
    print(f"[RETRIEVE] Original query: {user_query}")
    print(f"[RETRIEVE] Enriched query: {enriched[:100]}...")
    print(f"[RETRIEVE] Project filter: {project_name or 'None'}")
    print(f"[RETRIEVE] Assignee filter (from LLM): {assignee_filter or 'None'}")

    evidence_raw = []
    
    # Strategy 1: Try KNN/hybrid search first
    try:
        if project_name:
            print(f"[RETRIEVE] Strategy 1: Hybrid search with project filter")
            evidence_raw = hybrid_search_opensearch(enriched, project_name, k=15)
        else:
            print(f"[RETRIEVE] Strategy 1: KNN search (no project filter)")
            evidence_raw = knn_search_work_evidence(enriched, k=15)
        print(f"[RETRIEVE] Strategy 1 returned: {len(evidence_raw)} results")
    except Exception as e:
        print(f"[RETRIEVE] Strategy 1 failed: {e}")
    
    # Strategy 2: If no results, try with just project name
    if not evidence_raw and project_name:
        print(f"[RETRIEVE] Strategy 2: Search with just project name")
        try:
            evidence_raw = text_search_work_evidence(project_name, k=15)
            print(f"[RETRIEVE] Strategy 2 returned: {len(evidence_raw)} results")
        except Exception as e:
            print(f"[RETRIEVE] Strategy 2 failed: {e}")
    
    # Strategy 3: Try simple text search
    if not evidence_raw:
        print(f"[RETRIEVE] Strategy 3: Text search fallback")
        try:
            search_terms = f"{project_name} {user_query}" if project_name else user_query
            evidence_raw = text_search_work_evidence(search_terms, k=15)
            print(f"[RETRIEVE] Strategy 3 returned: {len(evidence_raw)} results")
        except Exception as e:
            print(f"[RETRIEVE] Strategy 3 failed: {e}")

    # Format evidence
    evidence = []
    for item in evidence_raw:
        # Extract project info from metadata
        matched_project = item.get("metadata", {}).get("matched_project", {})
        item_project = matched_project.get("project_name", "") or item.get("project_name", "")
        
        evidence.append({
            "evidence_id": item.get("source_uri", ""),
            "document": item.get("clean_text") or item.get("summary", ""),
            "summary": item.get("summary", ""),
            "source_type": item.get("source_type", ""),
            "metadata": item.get("metadata", {}),
            "project_name": item_project,
            "action_items": item.get("action_items_detected", []),
            "decisions": item.get("decisions_detected", []),
            "score": item.get("score")
        })
    
    # Filter evidence by project if specified (using fuzzy matching)
    if project_name and evidence:
        total_before = len(evidence)
        
        # Use fuzzy matching for project filtering
        filtered = []
        for e in evidence:
            e_project = e.get("project_name") or ""
            e_document = e.get("document") or ""
            e_summary = e.get("summary") or ""
            
            # Check fuzzy match on project name field
            if _fuzzy_project_match(project_name, e_project):
                filtered.append(e)
                continue
            
            # Check if project name appears in document/summary (normalized)
            q_norm = _normalize_for_comparison(project_name)
            if q_norm in _normalize_for_comparison(e_document) or q_norm in _normalize_for_comparison(e_summary):
                filtered.append(e)
                continue
        
        print(f"[RETRIEVE] Project filter: {total_before} total -> {len(filtered)} matched for '{project_name}'")
        
        # Only use filtered results if we found matches; otherwise keep all
        # (user might be asking about a project mentioned in the content)
        if filtered:
            evidence = filtered
        else:
            print(f"[RETRIEVE] WARNING: No fuzzy matches found, keeping all {total_before} results")

    # Search DynamoDB for work items (with status filter if detected)
    print(f"[RETRIEVE] Searching DynamoDB... (status_filter={status_filter})")
    if project_name:
        work_items_df = search_work_items_by_project(project_name, fuzzy=True, status_filter=status_filter)
    else:
        work_items_df = get_all_work_items(status_filter=status_filter)
    
    print(f"[RETRIEVE] DynamoDB returned: {len(work_items_df)} work items")
    
    # Apply assignee filter if LLM extracted one from user query
    if assignee_filter and not work_items_df.empty:
        total_before = len(work_items_df)
        assignee_lower = assignee_filter.lower().strip()
        
        # Filter by assignee (check both 'assignee' and 'assigned_to' columns)
        def matches_assignee(row):
            for col in ['assignee', 'assigned_to']:
                val = row.get(col)
                if val and not (isinstance(val, float) and pd.isna(val)):
                    if assignee_lower in str(val).lower():
                        return True
            return False
        
        mask = work_items_df.apply(matches_assignee, axis=1)
        work_items_df = work_items_df[mask].reset_index(drop=True)
        print(f"[RETRIEVE] Assignee filter '{assignee_filter}': {total_before} -> {len(work_items_df)} items")
    
    # Log work item details for debugging
    if not work_items_df.empty and len(work_items_df) <= 10:
        statuses = work_items_df["status"].value_counts().to_dict() if "status" in work_items_df.columns else {}
        print(f"[RETRIEVE] Work items by status: {statuses}")

    # Fallback to keyword search if OpenSearch empty
    if len(evidence) == 0 and not work_items_df.empty:
        work_items_df = keyword_search_work_items(work_items_df, user_query, 15)
        print(f"[RETRIEVE] Keyword filtered: {len(work_items_df)} items")

    # Build answer based on what we found
    if evidence:
        # Use the best evidence
        best = evidence[0]
        answer = best.get("document") or best.get("summary") or "Found relevant evidence but no text content."
    elif not work_items_df.empty:
        answer = "Found work items:\n" + "\n".join(
            f"- {row.get('task', '')} ({row.get('assignee', 'Unassigned')}, {row.get('status', 'pending')})"
            for _, row in work_items_df.head(5).iterrows()
            if row.get('task')
        )
    else:
        if project_name:
            answer = f"No information found for project '{project_name}'. The project may not have any indexed content yet."
        else:
            answer = "No relevant information found for your query."

    print(f"[RETRIEVE] === Retrieval Complete ===")
    print(f"[RETRIEVE] Evidence count: {len(evidence)}, Work items: {len(work_items_df)}")

    return {
        "mode": "retrieve",
        "retrieved_evidence": evidence,
        "work_item_matches": work_items_df.to_dict(orient="records") if not work_items_df.empty else [],
        "answer": answer,
        "project_name": project_name,
        "query_used": enriched
    }


# ==============================================================================
# SECTION 16: HELPER FUNCTIONS
# ==============================================================================
def _safe_str(value) -> str:
    """
    Safely convert a value to string, handling NaN/None/float from pandas.
    
    Args:
        value: Any value that might be a string, None, NaN, or other type
        
    Returns:
        String representation or empty string if null/NaN
    """
    if value is None:
        return ""
    if isinstance(value, float):
        if pd.isna(value) or math.isnan(value):
            return ""
        return str(value)
    if isinstance(value, str):
        return value
    return str(value) if value else ""


def _sanitize_for_json(obj):
    """Sanitize object for JSON serialization."""
    if isinstance(obj, dict):
        return {k: _sanitize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_sanitize_for_json(v) for v in obj]
    elif isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    return obj


def _json_serializer(obj):
    """Custom JSON serializer."""
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    return str(obj)


def _trim_context(context: dict, max_evidence: int = 5, max_items: int = 10) -> dict:
    """Trim context to avoid LLM token limits."""
    if not isinstance(context, dict):
        return context

    evidence = context.get("retrieved_evidence", [])
    trimmed_evidence = []
    for ev in evidence[:max_evidence]:
        trimmed_ev = dict(ev)
        if trimmed_ev.get("document"):
            trimmed_ev["document"] = trimmed_ev["document"][:800]
        trimmed_evidence.append(trimmed_ev)

    items = context.get("work_item_matches", [])
    trimmed_items = []
    for wi in items[:max_items]:
        trimmed_wi = dict(wi)
        if trimmed_wi.get("task_evidence"):
            trimmed_wi["task_evidence"] = trimmed_wi["task_evidence"][:600]
        trimmed_items.append(trimmed_wi)

    return {
        **{k: v for k, v in context.items()
           if k not in ("retrieved_evidence", "work_item_matches")},
        "retrieved_evidence": trimmed_evidence,
        "work_item_matches": trimmed_items,
    }


def format_work_items_as_html_table(
    work_items: List[dict],
    project_name: str = None,
    title: str = None,
    max_items: int = 15
) -> str:
    """
    Format work items as a standardized HTML table.
    
    This creates a consistent table format for displaying action items in chat responses.
    Each row is clickable and links to the Kanban board with the task highlighted.
    
    Args:
        work_items: List of work item dictionaries
        project_name: Optional project name for table title
        title: Custom title for the table (overrides project_name)
        max_items: Maximum items to show
        
    Returns:
        HTML string with formatted table
    """
    if not work_items:
        return ""
    
    # Determine table title
    if title:
        table_title = title
    elif project_name:
        table_title = f"{project_name} - Action Items"
    else:
        # Try to get project from first item
        first_project = work_items[0].get("project_name", "")
        table_title = f"{first_project} - Action Items" if first_project else "Action Items"
    
    # Build HTML table
    html_parts = [
        f'<h2 class="action-items-title">{_escape_html(table_title)}</h2>',
        '<table class="md-table action-items-table">',
        '<thead><tr>',
        '<th>Action Item</th>',
        '<th>Owner</th>',
        '<th>Function</th>',
        '<th>Due Date</th>',
        '<th>Status</th>',
        '<th>Source</th>',
        '</tr></thead>',
        '<tbody>'
    ]
    
    items_shown = 0
    for item in work_items[:max_items]:
        task = _safe_str(item.get("task", ""))
        if not task:
            continue
            
        # Get owner/assignee
        owner = _safe_str(item.get("assigned_to") or item.get("assignee", ""))
        owner_display = owner if owner and owner.lower() not in ["unassigned", "tbd", "none", "n/a", ""] else "Not assigned"
        
        # Get IPST function
        ipst_function = _safe_str(item.get("ipst_function", ""))
        if not ipst_function and owner and owner_display != "Not assigned":
            ipst_function = IPST_FUNCTION_MAP.get(owner.strip(), IPST_FUNCTION_MAP.get(owner.strip().title(), ""))
        function_display = ipst_function if ipst_function else "—"
        
        # Get due date
        due_date = _safe_str(item.get("due_date", ""))
        due_display = due_date if due_date else "Not specified"
        
        # Get status with proper formatting
        status = _safe_str(item.get("status", ""))
        status_display = status.title() if status else "Pending"
        
        # Get source info
        source_type = _safe_str(item.get("source_type", ""))
        source_uri = _safe_str(item.get("source_uri", ""))
        event_timestamp = _safe_str(item.get("event_timestamp", ""))
        
        # Format source display
        if source_type.lower() in ["meeting_transcript", "transcript"]:
            source_display = f"Meeting Transcript"
            if event_timestamp:
                try:
                    dt = datetime.fromisoformat(event_timestamp.replace("Z", "+00:00"))
                    source_display += f" ({dt.strftime('%b %d, %Y')})"
                except:
                    pass
        elif source_type.lower() in ["user_chat", "chat"]:
            source_display = "User Chat"
            if event_timestamp:
                try:
                    dt = datetime.fromisoformat(event_timestamp.replace("Z", "+00:00"))
                    source_display += f" ({dt.strftime('%b %d, %Y')})"
                except:
                    pass
        elif source_type:
            source_display = source_type.replace("_", " ").title()
        else:
            source_display = "—"
        
        # Build URL params for task highlighting (matches checkHighlight() in script.js)
        # Use task title as the highlight parameter (not work_item_id) for better matching
        import urllib.parse
        url_params = {
            'highlight': task,
            'assignee': owner_display,
            'status': status_display
        }
        query_string = urllib.parse.urlencode(url_params)
        
        # Make task name clickable (links to Kanban board)
        # Use '../?' to go up from /static/chat.html to root where index.html is served
        task_link = f'<a class="chat-task-link" href="../?{query_string}" onclick="return navigateToTask(this.href)">{_escape_html(task)} <span class="link-icon">↗</span></a>'
        
        html_parts.append(f'''<tr>
            <td>{task_link}</td>
            <td>{_escape_html(owner_display)}</td>
            <td><span class="function-badge">{_escape_html(function_display)}</span></td>
            <td>{_escape_html(due_display)}</td>
            <td>{_escape_html(status_display)}</td>
            <td>{_escape_html(source_display)}</td>
        </tr>''')
        items_shown += 1
    
    html_parts.append('</tbody></table>')
    
    if items_shown == 0:
        return ""
    
    if len(work_items) > max_items:
        html_parts.append(f'<p class="table-note">Showing {max_items} of {len(work_items)} items</p>')
    
    return "\n".join(html_parts)


def _escape_html(text: str) -> str:
    """Escape HTML special characters."""
    if not text:
        return ""
    return (text
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;"))


def _extract_status_from_text(text: str) -> str:
    """
    Extract status from user text.
    
    Handles various formats including:
    - Direct status words: "done", "in progress", "pending"
    - Action phrases: "mark it done", "set status to in progress"
    - Drag-drop format: "mark it done — task: X"
    - Natural language: "move to done", "set as completed"
    """
    text_lower = text.lower()
    
    # First try to find explicit target status in "to/as <status>" patterns
    # This handles drag-drop format: "mark it done — task: X" or "set status to in progress"
    target_match = re.search(
        r'(?:mark(?:\s+it)?|set(?:\s+status)?(?:\s+to)?|move(?:\s+to)?|change(?:\s+to)?)[\s\-—]+'
        r'(done|completed?|finished|in[\s\-]?progress|to[\s\-]?do|todo|pending|blocked|at[\s\-]?risk)',
        text_lower, re.IGNORECASE
    )
    if target_match:
        status_str = target_match.group(1).strip()
        if status_str in ('done', 'completed', 'complete', 'finished'):
            return "done"
        elif 'progress' in status_str or status_str in ('active', 'started'):
            return "in progress"
        elif status_str in ('to do', 'todo', 'to-do', 'pending', 'not started'):
            return "pending"
        elif 'blocked' in status_str:
            return "blocked"
        elif 'risk' in status_str:
            return "At Risk"
    
    # Also try "move X to <status>" pattern
    move_to_match = re.search(
        r'\bto\s+(done|completed?|finished|in[\s\-]?progress|to[\s\-]?do|todo|pending|blocked|at[\s\-]?risk)\b',
        text_lower, re.IGNORECASE
    )
    if move_to_match:
        status_str = move_to_match.group(1).strip()
        if status_str in ('done', 'completed', 'complete', 'finished'):
            return "done"
        elif 'progress' in status_str:
            return "in progress"
        elif status_str in ('to do', 'todo', 'to-do', 'pending'):
            return "pending"
        elif 'blocked' in status_str:
            return "blocked"
        elif 'risk' in status_str:
            return "At Risk"
    
    # Fallback: simple keyword matching
    patterns = [
        (r'\b(done|completed?|finished)\b', "done"),
        (r'\b(in[- ]?progress|active|started)\b', "in progress"),
        (r'\b(to[- ]?do|pending|not started)\b', "pending"),
        (r'\b(blocked|on[- ]hold)\b', "blocked"),
        (r'\b(at[- ]risk)\b', "At Risk"),
    ]
    for pattern, status in patterns:
        if re.search(pattern, text_lower):
            return status
    return ""


def _extract_due_date_from_text(text: str) -> str:
    """
    Extract due date from user text.
    Handles formats like:
    - "August 15, 2026" or "August 15 2026"
    - "15 August 2026"
    - "2026-08-15"
    - "08/15/2026"
    - "due by next Friday"
    """
    import re
    from datetime import datetime, timedelta
    
    text_lower = text.lower()
    
    # Pattern for "Month DD, YYYY" or "Month DD YYYY"
    month_names = r'(january|february|march|april|may|june|july|august|september|october|november|december)'
    pattern1 = rf'{month_names}\s+(\d{{1,2}})[\s,]+(\d{{4}})'
    match1 = re.search(pattern1, text_lower)
    if match1:
        month_str, day, year = match1.groups()
        months = {'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5, 'june': 6,
                  'july': 7, 'august': 8, 'september': 9, 'october': 10, 'november': 11, 'december': 12}
        month = months.get(month_str, 1)
        return f"{year}-{month:02d}-{int(day):02d}"
    
    # Pattern for "DD Month YYYY"
    pattern2 = rf'(\d{{1,2}})\s+{month_names}[\s,]+(\d{{4}})'
    match2 = re.search(pattern2, text_lower)
    if match2:
        day, month_str, year = match2.groups()
        months = {'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5, 'june': 6,
                  'july': 7, 'august': 8, 'september': 9, 'october': 10, 'november': 11, 'december': 12}
        month = months.get(month_str, 1)
        return f"{year}-{month:02d}-{int(day):02d}"
    
    # Pattern for ISO date: YYYY-MM-DD
    pattern3 = r'(\d{4})-(\d{2})-(\d{2})'
    match3 = re.search(pattern3, text)
    if match3:
        return match3.group(0)
    
    # Pattern for MM/DD/YYYY
    pattern4 = r'(\d{1,2})/(\d{1,2})/(\d{4})'
    match4 = re.search(pattern4, text)
    if match4:
        month, day, year = match4.groups()
        return f"{year}-{int(month):02d}-{int(day):02d}"
    
    return ""


# ==============================================================================
# SECTION 17: LANGGRAPH NODES
# ==============================================================================
def decision_node(state: GraphState) -> Command:
    """
    Decision node: Entry point for workflow.

    Parses intent and routes to appropriate handler.
    """
    user_text = "\n".join(state.get("chat_history", []))
    parsed = parse_user_intent(user_text, state.get("chat_history"))
    intent = parsed.get("intent", "retrieve")

    # Handle clarification flow
    if state.get("clarification_received"):
        if intent == "create":
            return Command(
                update={**parsed, "clarification_needed": False,
                        "clarification_received": True},
                goto="create"
            )
        return Command(
            update={**parsed, "clarification_needed": False,
                    "clarification_received": True},
            goto="update"
        )

    # Route by intent
    if intent in ["retrieve", "unknown"]:
        context = handle_retrieve_intent(parsed)
        context = _sanitize_for_json(context)
        return Command(
            update={**parsed, "clarification_needed": False,
                    "retrieval_results": context},
            goto="inference"
        )
    elif intent == "create":
        return Command(update={**parsed}, goto="create")
    else:
        return Command(update={**parsed}, goto="update")


def inference_node(state: GraphState) -> Command:
    """
    Inference node: Generate response from RAG context.
    
    When work items are found, displays them in a standardized HTML table.
    Combines LLM narrative with structured table display.
    """
    context = state.get("retrieval_results", {})
    user_query = "\n".join(state.get('chat_history', []))
    project_name = state.get("project_name", "")
    
    # Get work items from context
    work_items = context.get("work_item_matches", [])
    evidence = context.get("retrieved_evidence", [])

    trimmed = _trim_context(context)

    try:
        context_str = json.dumps(trimmed, default=_json_serializer)
    except Exception:
        context_str = str(trimmed)

    # Determine if this is primarily a task/action item query
    user_lower = user_query.lower()
    is_task_query = any(term in user_lower for term in [
        "task", "action item", "action items", "pending", "done", "in progress",
        "assigned", "assignee", "owner", "due", "status", "what tasks", 
        "show me", "list", "work item", "blockers", "at risk"
    ])
    
    # Build prompt based on query type
    if is_task_query and work_items:
        # For task queries with work items, ask LLM for a brief summary only
        prompt = f"""You are a project assistant{f' for {project_name}' if project_name else ''}.

The user asked about tasks/action items. I will show them in a structured table.
Your job is to provide a BRIEF contextual introduction (1-2 sentences max) before the table.

RULES:
1. Write a SHORT title/header (e.g., "## IPST_Dexavir Project - Action Items")
2. Add ONE sentence of context if helpful (optional)
3. Do NOT list the tasks - they will be shown in a table
4. Do NOT include any bullet points with task details
5. If there's important context from evidence (meetings, decisions), mention it briefly
6. End with something like "Here are the action items:" or similar transition

USER QUERY: {user_query}
PROJECT: {project_name or 'Multiple Projects'}
NUMBER OF TASKS FOUND: {len(work_items)}

EVIDENCE CONTEXT (for background only):
{json.dumps([e.get('summary', '')[:200] for e in evidence[:3]], default=str)}

Provide ONLY the brief introduction (no task list):"""
    else:
        # For non-task queries or when no work items, use standard RAG prompt
        prompt = f"""You are a project assistant{f' for {project_name}' if project_name else ''}.
Answer using ONLY the provided context.

RULES:
1. Only use facts from the context - don't invent information
2. If project not in context, say "I don't have information about that project"
3. Be concise - 3-5 bullet points max
4. Include names, dates, statuses when available
5. If no relevant info, say so clearly
6. When listing tasks, use a markdown table with columns: Task, Owner, Due Date, Status

CONTEXT STRUCTURE:
- "retrieved_evidence": Source documents (check summary, action_items, decisions fields)
- "work_item_matches": Task records from database

USER QUERY: {user_query}

CONTEXT:
{context_str}

Format response with markdown headers and bullet points."""

    try:
        response = llm.invoke(prompt)
        llm_response = response.content
        
        # If this is a task query with work items, append the HTML table
        if is_task_query and work_items:
            # Generate the HTML table
            table_html = format_work_items_as_html_table(
                work_items=work_items,
                project_name=project_name,
                title=None,  # LLM provides the title
                max_items=15
            )
            
            # Combine LLM intro with table
            if table_html:
                final_response = f"{llm_response}\n\n{table_html}"
            else:
                final_response = llm_response
                
            # Add key notes if there's relevant evidence
            key_notes = _extract_key_notes_from_evidence(evidence)
            if key_notes:
                final_response += f"\n\n<div class='key-notes'><strong>Key Notes:</strong>\n{key_notes}</div>"
        else:
            final_response = llm_response
        
        return Command(update={"final_response": final_response}, goto=END)
        
    except Exception as e:
        print(f"[INFERENCE] Error: {e}")
        import traceback
        traceback.print_exc()
        return Command(
            update={"final_response": "Error processing request. Please try again."},
            goto=END
        )


def _extract_key_notes_from_evidence(evidence: List[dict]) -> str:
    """Extract key notes from evidence for display below the table."""
    notes = []
    for ev in evidence[:3]:
        # Check for decisions
        decisions = ev.get("decisions", []) or ev.get("decisions_detected", [])
        for dec in decisions[:2]:
            if isinstance(dec, dict):
                desc = dec.get("description", "")
            else:
                desc = str(dec)
            if desc and len(desc) > 20:
                notes.append(f"• {desc[:150]}")
        
        # Check for action items mentioned in summary
        summary = ev.get("summary", "")
        if "action" in summary.lower() or "decision" in summary.lower():
            if summary and len(summary) > 30 and summary not in notes:
                notes.append(f"• {summary[:150]}")
    
    return "\n".join(notes[:3]) if notes else ""


def update_node(state: GraphState) -> Command:
    """
    Update node: Handle work item updates.

    First call: Find matching item and prepare update (goes to clarify for yes/no)
    Second call (after user confirms): Apply the confirmed update
    """
    user_text = "\n".join(state.get('chat_history', []))
    clarification_received = state.get("clarification_received", False)
    clarification_needed = state.get("clarification_needed", False)
    result_payload = state.get("result_payload", {})
    
    print(f"[UPDATE_NODE] === Update Node Entry ===")
    print(f"[UPDATE_NODE] clarification_received={clarification_received}, clarification_needed={clarification_needed}")
    print(f"[UPDATE_NODE] result_payload has updated_item: {bool(result_payload.get('updated_item'))}")
    print(f"[UPDATE_NODE] State assignee: {state.get('assignee')}, due_date: {state.get('due_date')}, status: {state.get('status')}")
    print(f"[UPDATE_NODE] User text (first 200 chars): {user_text[:200]}...")
    
    # Fallback status extraction if state.status is empty
    fallback_status = _extract_status_from_text(user_text)
    print(f"[UPDATE_NODE] Fallback status extraction: {fallback_status}")

    # Check if this is a confirmation call (user said "yes" to previous clarification)
    # This happens when: clarification_received=True AND we have a result_payload with updated_item
    is_confirmation = clarification_received and result_payload.get("updated_item")
    
    if not is_confirmation:
        # First call: Find matching item and prepare update
        print(f"[UPDATE_NODE] First call - finding matching item...")
        result = _handle_update_adjudication(state)
        result = _sanitize_for_json(result)
        
        # Debug: log what changes were detected
        changes = result.get("changes", [])
        print(f"[UPDATE_NODE] Changes detected: {changes}")
        
        return Command(update={"final_response": result}, goto="clarify")

    # Second call: Apply confirmed update
    print(f"[UPDATE_NODE] Confirmation call - applying update...")
    updated = result_payload.get("updated_item")
    if not updated:
        return Command(
            update={"final_response": "Couldn't find matching task."},
            goto=END
        )

    _apply_work_item_update(updated, result_payload)

    task_name = updated.get("task", "task")
    
    # Build list of all changes made
    changes = result_payload.get("changes") or []
    if not changes:
        # Fallback: detect changes from updated item
        if updated.get("status"):
            changes.append(f"status → **{updated['status']}**")
        if updated.get("assigned_to") or updated.get("assignee"):
            assignee = updated.get("assigned_to") or updated.get("assignee")
            changes.append(f"assigned to → **{assignee}**")
        if updated.get("due_date"):
            changes.append(f"due date → **{updated['due_date']}**")
        if updated.get("priority"):
            changes.append(f"priority → **{updated['priority']}**")

    result = f"✅ **{task_name}** updated: {', '.join(changes) or 'changes applied'}."
    return Command(update={"final_response": result}, goto=END)


def create_node(state: GraphState) -> Command:
    """
    Create node: Handle work item creation with all fields.
    """
    clarification_received = state.get("clarification_received", False)
    clarification_needed = state.get("clarification_needed", False)
    result_payload = state.get("result_payload", {})

    # First call: Prepare
    if not clarification_received or clarification_needed:
        result = _handle_create_adjudication(state)
        result = _sanitize_for_json(result)
        return Command(update={"final_response": result}, goto="clarify")

    # Second call: Create
    proposed = result_payload.get("proposed_item", {})
    table = dynamodb_resource.Table(DYNAMODB_WORK_ITEMS_TABLE)
    work_item_id = proposed.get("work_item_id") or f"WI_{uuid.uuid4().hex[:8]}"

    assignee = (proposed.get("assignee") or "Unassigned").strip()
    project_name = proposed.get("project_name") or "Unassigned"
    task_title = proposed.get("task") or ""

    item = {
        "PK": f"PROJECT#{project_name}",
        "SK": f"TASK#{work_item_id}",
        "work_item_id": work_item_id,
        "project_name": project_name,
        "task": task_title,
        "assignee": assignee,
        "assigned_to": assignee,
        "due_date": proposed.get("due_date") or "",
        "status": proposed.get("status") or "pending",
        "priority": proposed.get("priority") or "",
        "summary": proposed.get("summary") or "",
        "source_type": "user_chat",
        "source_uri": "chat",
        "event_timestamp": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "ipst_function": IPST_FUNCTION_MAP.get(assignee.title(), ""),
    }

    table.put_item(Item=item)
    print(f"[CREATE] Created: {task_title} for {project_name}")

    # Build confirmation message with details
    details = []
    if assignee and assignee != "Unassigned":
        details.append(f"assigned to **{assignee}**")
    if proposed.get("due_date"):
        details.append(f"due **{proposed['due_date']}**")
    if proposed.get("priority"):
        details.append(f"priority **{proposed['priority']}**")
    
    details_str = f" ({', '.join(details)})" if details else ""
    result = f"✅ Created **{task_title}** in **{project_name}**{details_str}."
    return Command(update={"final_response": result}, goto=END)


def clarify_node(state: GraphState) -> Command:
    """
    Clarify node: Generate clarification or confirmation prompt.
    Shows all pending changes (status, assignee, due_date, priority).
    Handles both UPDATE and CREATE modes.
    """
    user_text = "\n".join(state.get("chat_history", []))
    fr = state.get("final_response") or {}

    adjudication = {}
    updated_item = None
    proposed_item = None
    changes = []
    mode = ""

    if isinstance(fr, dict):
        adjudication = fr.get("adjudication") or {}
        updated_item = fr.get("updated_item")
        proposed_item = fr.get("proposed_item")
        changes = fr.get("changes") or []
        mode = fr.get("mode", "")

    # Handle CREATE mode
    if mode == "create_review" and proposed_item:
        task_name = proposed_item.get("task", "new task")
        project = proposed_item.get("project_name", "Unassigned")
        assignee = proposed_item.get("assignee", "Unassigned")
        due_date = proposed_item.get("due_date", "")
        priority = proposed_item.get("priority", "")
        
        details = [f"project: **{project}**"]
        if assignee and assignee != "Unassigned":
            details.append(f"assignee: **{assignee}**")
        if due_date:
            details.append(f"due: **{due_date}**")
        if priority:
            details.append(f"priority: **{priority}**")
        
        details_str = ", ".join(details)
        question = f"Create task **\"{task_name}\"** ({details_str})? (yes/no)"
        
        return Command(
            update={"clarification_question": question,
                    "clarification_received": False,
                    "clarification_needed": True},
            goto=END
        )

    # Handle UPDATE mode - No item found
    if updated_item is None and mode == "update_review":
        ir = fr.get("intent_result") or {}
        title = ir.get("title") or ir.get("summary") or ""
        msg = f"Couldn't find task matching \"{title}\". Please provide more details."
        return Command(
            update={"clarification_question": msg,
                    "clarification_received": False,
                    "clarification_needed": False},
            goto=END
        )

    # Handle UPDATE mode - Build confirmation showing ALL changes
    task_name = (updated_item or {}).get("task", "")
    
    if task_name and changes:
        # Show all the changes being made
        changes_str = ", ".join(changes)
        question = f"Found **\"{task_name}\"** - update: {changes_str}? (yes/no)"
    elif task_name:
        # Task found but no changes detected
        question = f"Found **\"{task_name}\"** but no changes detected. What would you like to update?"
    elif adjudication.get("next_action"):
        question = f"{adjudication['next_action']} Proceed? (yes/no)"
    else:
        try:
            prompt = f'User said: "{user_text}"\nAsk ONE clarifying question about which task to update.'
            question = llm.invoke(prompt).content.strip()
        except Exception:
            question = "Which task would you like to update?"

    return Command(
        update={"clarification_question": question,
                "clarification_received": False,
                "clarification_needed": True},
        goto=END
    )


def _handle_update_adjudication(state: GraphState) -> dict:
    """
    Find matching work item for update.
    
    Uses multi-strategy approach:
    1. Extract fields from LLM-parsed state
    2. Fallback to regex parsing from user text (handles drag-drop format)
    3. Fuzzy match against work items in DynamoDB
    """
    user_text = "\n".join(state.get("chat_history", []))
    project_name = state.get("project_name")

    if project_name:
        work_items_df = search_work_items_by_project(project_name, fuzzy=True)
    else:
        work_items_df = get_all_work_items()

    # Extract title from state or fallback to regex
    title_hint = (state.get("title") or state.get("summary") or "").lower()
    assignee_hint = (state.get("assignee") or "").lower()
    
    # Fallback regex parsing for title (handles drag-drop format)
    if not title_hint:
        # Try quoted title first (straight and curly quotes)
        match = re.search(r'["\'“‘’”]([^"\'\u201c\u2018\u2019\u201d]{5,})["\'“‘’”]', user_text, re.IGNORECASE)
        if match:
            title_hint = match.group(1).strip().lower()
        else:
            # Try drag-drop format: "mark it done — task: X, assignee: Y"
            task_match = re.search(r'task[:\s]+([^,\-\u2014\n]+)', user_text, re.IGNORECASE)
            if task_match:
                title_hint = task_match.group(1).strip().strip('"').lower()
            else:
                # Try "move/update/change <title> to <status>" pattern
                move_match = re.search(
                    r'(?:move|update|change|set|mark)\s+(.+?)\s+to\s+(?:to[\s\-]?do|todo|in[\s\-]?progress|done|at[\s\-]?risk|blocked|pending)',
                    user_text, re.IGNORECASE
                )
                if move_match:
                    title_hint = move_match.group(1).strip().strip('"').lower()
    
    # Clean title hint - remove trailing status phrases
    if title_hint:
        title_hint = re.sub(
            r'\s+to\s+(to[\s\-]?do|todo|in[\s\-]?progress|done|at[\s\-]?risk|blocked|pending)\s*$',
            '', title_hint, flags=re.IGNORECASE
        ).strip()
    
    # Fallback regex parsing for assignee (handles drag-drop format)
    if not assignee_hint:
        # Try drag-drop format: "assignee: X" or "assigned to: X"
        assignee_match = re.search(r'(?:assign(?:ed)?(?:\s+to)?|assignee)[:\s]+([^,\-\u2014\n]+)', user_text, re.IGNORECASE)
        if assignee_match:
            assignee_hint = assignee_match.group(1).strip().lower()

    best_match = None
    best_score = 0

    for _, row in work_items_df.iterrows():
        score = 0
        # Safely get string values - handle NaN/float values from pandas
        task_val = row.get("task")
        task_str = str(task_val).lower() if task_val and not (isinstance(task_val, float) and pd.isna(task_val)) else ""
        
        assigned_to_val = row.get("assigned_to")
        assignee_val = row.get("assignee")
        assignee_str = ""
        if assigned_to_val and not (isinstance(assigned_to_val, float) and pd.isna(assigned_to_val)):
            assignee_str = str(assigned_to_val).lower()
        elif assignee_val and not (isinstance(assignee_val, float) and pd.isna(assignee_val)):
            assignee_str = str(assignee_val).lower()

        if title_hint and title_hint in task_str:
            score += 100
        elif title_hint:
            words = [w for w in title_hint.split() if len(w) > 3]
            score += sum(1 for w in words if w in task_str)

        if assignee_hint and assignee_hint in assignee_str:
            score += 10

        if score > best_score:
            best_score = score
            best_match = row.to_dict()

    if best_match and best_score >= 1:
        updated_item = dict(best_match)
        changes = []
        
        # Extract status from user text or state
        new_status = state.get("status") or _extract_status_from_text(user_text)
        if new_status:
            updated_item["status"] = new_status
            changes.append(f"status → {new_status}")
        
        # Extract assignee from state (parsed by LLM)
        new_assignee = state.get("assignee")
        if new_assignee:
            updated_item["assignee"] = new_assignee
            updated_item["assigned_to"] = new_assignee
            changes.append(f"assignee → {new_assignee}")
        
        # Extract due_date from state or user text
        new_due_date = state.get("due_date") or _extract_due_date_from_text(user_text)
        if new_due_date:
            updated_item["due_date"] = new_due_date
            changes.append(f"due date → {new_due_date}")
        
        # Extract priority from state
        new_priority = state.get("priority")
        if new_priority:
            updated_item["priority"] = new_priority
            changes.append(f"priority → {new_priority}")
        
        changes_str = ", ".join(changes) if changes else "no changes detected"
        
        return {
            "mode": "update_review",
            "intent_result": dict(state),
            "previous_item": best_match,
            "updated_item": updated_item,
            "changes": changes,
            "adjudication": {
                "next_action": f"Found \"{best_match.get('task')}\" - will update: {changes_str}."
            }
        }

    return {
        "mode": "update_review",
        "intent_result": dict(state),
        "previous_item": None,
        "updated_item": None,
        "changes": [],
        "adjudication": {}
    }


def _handle_create_adjudication(state: GraphState) -> dict:
    """Prepare work item for creation with all extracted fields."""
    user_text = "\n".join(state.get("chat_history", []))
    
    # Extract due_date from state or text if not provided
    due_date = state.get("due_date") or _extract_due_date_from_text(user_text)

    return {
        "mode": "create_review",
        "intent_result": dict(state),
        "proposed_item": {
            "work_item_id": f"WI_{uuid.uuid4().hex[:10]}",
            "project_name": state.get("project_name") or "Unassigned",
            "task": state.get("title") or state.get("summary") or user_text[:100],
            "assignee": state.get("assignee") or "Unassigned",
            "due_date": due_date or "",
            "status": state.get("status") or "pending",
            "priority": state.get("priority") or "",
            "summary": state.get("summary") or "",
        },
        "adjudication": {
            "next_action": f"Will create task for {state.get('project_name') or 'Unassigned'}."
        }
    }


def _apply_work_item_update(updated_item: dict, result_payload: dict):
    """
    Apply work item update to DynamoDB including all field changes.
    
    Normalizes status values and handles IPST function mapping.
    """
    table = dynamodb_resource.Table(DYNAMODB_WORK_ITEMS_TABLE)

    previous = result_payload.get("previous_item", {})
    pk = previous.get("PK") or updated_item.get("PK") or \
         f"PROJECT#{updated_item.get('project_name', 'Unassigned')}"
    sk = previous.get("SK") or updated_item.get("SK") or \
         f"TASK#{updated_item.get('work_item_id', '')}"

    work_item = dict(previous) if previous else {}
    work_item.update({
        "PK": pk,
        "SK": sk,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    })
    
    # Apply status change with normalization
    if updated_item.get("status"):
        new_status = updated_item["status"]
        # Normalize status at write time — ensure clean values stored in DynamoDB
        _ns = new_status.lower().strip()
        if _ns in ("to do", "todo", "to-do"):
            new_status = "pending"
        elif _ns in ("in progress", "in-progress", "inprogress", "active"):
            new_status = "in progress"
        elif _ns in ("done", "completed", "complete", "finished"):
            new_status = "done"
        work_item["status"] = new_status

    # Apply assignee change
    if updated_item.get("assigned_to") or updated_item.get("assignee"):
        assignee = updated_item.get("assigned_to") or updated_item.get("assignee")
        # Title-case the assignee name for consistency
        if assignee and isinstance(assignee, str) and assignee.strip():
            assignee = assignee.strip().title()
            work_item["assigned_to"] = assignee
            work_item["assignee"] = assignee
            
            # Update ipst_function based on assignee using IPST_FUNCTION_MAP
            ipst_func = IPST_FUNCTION_MAP.get(assignee, IPST_FUNCTION_MAP.get(assignee.split()[0] if assignee else "", ""))
            if ipst_func:
                work_item["ipst_function"] = ipst_func

    # Apply due_date change
    if updated_item.get("due_date"):
        work_item["due_date"] = updated_item["due_date"]
    
    # Apply priority change
    if updated_item.get("priority"):
        work_item["priority"] = updated_item["priority"]
    
    # Preserve other required fields from updated_item that might not be in previous
    for field in ["task", "project_name", "work_item_id", "task_id", "source_type", "source_uri", "summary", "task_evidence"]:
        if updated_item.get(field) and not work_item.get(field):
            work_item[field] = updated_item[field]

    table.put_item(Item=work_item)
    
    changes = []
    if updated_item.get("status"):
        changes.append(f"status={work_item['status']}")
    if updated_item.get("assigned_to") or updated_item.get("assignee"):
        changes.append(f"assignee={work_item.get('assigned_to') or work_item.get('assignee')}")
    if updated_item.get("due_date"):
        changes.append(f"due_date={updated_item['due_date']}")
    if updated_item.get("priority"):
        changes.append(f"priority={updated_item['priority']}")
    
    print(f"[UPDATE] Applied: {work_item.get('task')} -> {', '.join(changes) or 'no changes'}")


# ==============================================================================
# SECTION 18: GRAPH BUILDER
# ==============================================================================
def build_graph():
    """Build and compile the LangGraph workflow."""
    builder = StateGraph(GraphState)

    builder.add_node("decision", decision_node)
    builder.add_node("inference", inference_node)
    builder.add_node("create", create_node)
    builder.add_node("update", update_node)
    builder.add_node("clarify", clarify_node)

    builder.set_entry_point("decision")

    return builder.compile()


# ==============================================================================
# SECTION 19: API MODELS
# ==============================================================================
class ChatRequest(BaseModel):
    chat_history: List[str]
    clarification_received: bool
    result_payload: dict


def clean_nan(obj):
    """Clean NaN values for JSON."""
    if isinstance(obj, dict):
        return {k: clean_nan(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan(v) for v in obj]
    elif isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    return obj


# ==============================================================================
# SECTION 20: MAIN CHAT ENDPOINT
# ==============================================================================
@app.post("/agent")
def agent(req: ChatRequest):
    """Main chat endpoint."""
    try:
        print(f"[AGENT] === New Request ===")
        print(f"[AGENT] chat_history: {req.chat_history}")
        print(f"[AGENT] clarification_received: {req.clarification_received}")
        print(f"[AGENT] result_payload keys: {list(req.result_payload.keys()) if req.result_payload else 'empty'}")
        
        initial_state = {
            "chat_history": req.chat_history,
            "final_response": None,
            "clarification_received": req.clarification_received,
            "clarification_needed": False,
            "result_payload": req.result_payload
        }

        graph = build_graph()
        result = graph.invoke(initial_state)
        
        print(f"[AGENT] Result clarification_needed: {result.get('clarification_needed')}")
        print(f"[AGENT] Result has clarification_question: {bool(result.get('clarification_question'))}")

        # Evaluation logging
        try:
            records = load_records()
            evaluation_response = evaluation(
                bedrock=bedrock_client,
                model_id=LLM_MODEL_ID,
                user_query=req.chat_history[-1],
                ai_response=result.get('final_response'),
                eval_records=records
            )
            logger.info(f"evaluation: {json.dumps(evaluation_response)}")
        except Exception:
            pass

        # Format response
        if result.get("clarification_needed"):
            q = result.get("clarification_question") or ""
            if not q and result.get("final_response"):
                fr = result["final_response"]
                if isinstance(fr, dict):
                    q = fr.get("answer") or fr.get("next_action") or ""
                elif isinstance(fr, str):
                    q = fr
            return {
                "response": f"<p>{q or 'Could you clarify?'}</p>",
                "result_payload": clean_nan(result.get("final_response", {})),
                "clarification_needed": True
            }

        fr = result.get("final_response", "")
        if isinstance(fr, dict):
            fr = fr.get("answer") or fr.get("message") or json.dumps(fr)
        fr = str(fr) if fr else "No response generated."

        return {
            "response": markdown.markdown(fr, extensions=['tables', 'fenced_code']),
            "result_payload": {},
            "clarification_needed": False
        }

    except Exception as e:
        print(f"Error in /agent: {e}")
        import traceback
        traceback.print_exc()
        return {
            "response": "<p>Something went wrong. Please try again.</p>",
            "result_payload": {},
            "clarification_needed": False
        }


# ==============================================================================
# SECTION 21: TASKS ENDPOINTS
# ==============================================================================
@app.get("/tasks")
def get_tasks():
    """Get all tasks from DynamoDB with normalized status columns."""
    def decimal_to_json(obj):
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return obj

    table = dynamodb_resource.Table(DYNAMODB_WORK_ITEMS_TABLE)

    items = []
    response = table.scan()
    items.extend(response.get("Items", []))

    while "LastEvaluatedKey" in response:
        response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
        items.extend(response.get("Items", []))

    clean_items = json.loads(json.dumps(items, default=decimal_to_json))

    # Add status_column field for UI categorization
    for item in clean_items:
        raw_status = item.get("status", "")
        item["status_column"] = get_status_column(raw_status)
        item["status_display"] = raw_status.title() if raw_status else "Pending"

    # Deduplicate
    seen = {}
    for item in clean_items:
        key = (
            (item.get("task") or "").strip().lower(),
            (item.get("project_name") or "").strip().lower(),
        )
        if key not in seen:
            seen[key] = item
        else:
            new_ts = item.get("updated_at") or item.get("event_timestamp") or ""
            prev_ts = seen[key].get("updated_at") or seen[key].get("event_timestamp") or ""
            if str(new_ts) > str(prev_ts):
                seen[key] = item

    final = sorted(
        list(seen.values()),
        key=lambda x: x.get("updated_at") or x.get("event_timestamp") or "",
        reverse=True
    )

    # Log status distribution
    status_dist = {}
    for item in final:
        col = item.get("status_column", "todo")
        status_dist[col] = status_dist.get(col, 0) + 1
    print(f"[TASKS] Returning {len(final)} tasks - Distribution: {status_dist}")
    
    return final


@app.delete("/tasks")
def delete_task(pk: str, sk: str):
    """Delete a work item."""
    try:
        table = dynamodb_resource.Table(DYNAMODB_WORK_ITEMS_TABLE)
        table.delete_item(Key={"PK": pk, "SK": sk})
        return {"status": "deleted", "PK": pk, "SK": sk}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==============================================================================
# SECTION 22: FILE UPLOAD ENDPOINT
# ==============================================================================
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(_BASE_DIR, "user_uploads_from_UI")
UPLOAD_HASH_REGISTRY = os.path.join(UPLOAD_DIR, ".upload_hashes")


def _load_hash_registry() -> set:
    try:
        if os.path.exists(UPLOAD_HASH_REGISTRY):
            with open(UPLOAD_HASH_REGISTRY, "r") as f:
                return set(line.strip() for line in f if line.strip())
    except Exception:
        pass
    return set()


def _save_hash_to_registry(content_hash: str):
    try:
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        with open(UPLOAD_HASH_REGISTRY, "a") as f:
            f.write(content_hash + "\n")
    except Exception:
        pass


@app.post("/upload")
async def upload_files(
    files: List[UploadFile] = File(...),
    categories: List[str] = Form(...),
    force_reindex: str = Form(default="false")
):
    """Upload and process files."""
    try:
        processed = 0
        skipped = 0
        force = force_reindex.lower() == "true"

        category_map = {
            "Meeting Transcript": "meeting_transcript",
            "Team Chat": "teams_chat",
            "Outlook": "email",
        }

        for file, category in zip(files, categories):
            contents = await file.read()
            content_hash = hashlib.md5(contents).hexdigest()

            if not force:
                registry = _load_hash_registry()
                if content_hash in registry:
                    skipped += 1
                    continue

            os.makedirs(UPLOAD_DIR, exist_ok=True)
            file_path = os.path.join(UPLOAD_DIR, file.filename)
            with open(file_path, "wb") as f:
                f.write(contents)

            text = _extract_text_from_file(file_path)
            if not text:
                continue

            source_type = category_map.get(category, "email")
            cleaned = _clean_text_with_llm(text, source_type)

            evidence_id = f"EV_{uuid.uuid4().hex[:10]}"
            now = datetime.now(timezone.utc).isoformat()

            doc = {
                "evidence_id": evidence_id,
                "workspace_id": "default-workspace",
                "source_type": source_type,
                "source_uri": f"upload:{file.filename}",
                "content_hash": content_hash,
                "clean_text": cleaned.get("clean_text", text),
                "summary": cleaned.get("summary", text[:300]),
                "embedding_text": cleaned.get("clean_text", text)[:8000],
                "action_items_detected": cleaned.get("action_items", []),
                "decisions_detected": cleaned.get("decisions", []),
                "created_at": now,
                "updated_at": now,
                "vector_embedding": vectorize_with_titan(
                    cleaned.get("clean_text", text)[:8000]
                )
            }

            index_document(doc)
            _save_hash_to_registry(content_hash)

            for action in cleaned.get("action_items", []):
                if not action.get("title"):
                    continue

                work_item_id = f"WI_{uuid.uuid4().hex[:8]}"
                projects = cleaned.get("entities", {}).get("projects", [])
                project = projects[0] if projects else "Unassigned"

                apply_confirmed_update_dynamodb({
                    "work_item_id": work_item_id,
                    "project_name": project,
                    "task": action.get("title") or action.get("description", ""),
                    "assignee": action.get("owner") or "Unassigned",
                    "due_date": action.get("due_date") or "",
                    "status": action.get("status") or "pending",
                    "source_type": source_type,
                    "source_uri": f"upload:{file.filename}",
                    "summary": action.get("description") or "",
                })

            processed += 1

        if processed == 0 and skipped > 0:
            return {"response": f"⚠️ {skipped} file(s) already uploaded."}
        elif skipped > 0:
            return {"response": f"✅ Processed {processed}. {skipped} skipped."}
        return {"response": f"✅ Processed {processed} file(s)."}

    except Exception as e:
        print(f"Upload error: {e}")
        import traceback
        traceback.print_exc()
        return {"response": f"Upload failed: {str(e)}"}


def _extract_text_from_file(file_path: str) -> str:
    """Extract text from file."""
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".docx":
        doc = Document(file_path)
        return "\n".join([p.text for p in doc.paragraphs])

    elif ext in [".png", ".jpg", ".jpeg", ".webp"]:
        with open(file_path, "rb") as f:
            image_data = base64.b64encode(f.read()).decode("utf-8")

        media_type = {
            ".png": "image/png", ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg", ".webp": "image/webp"
        }.get(ext, "image/png")

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "image", "source": {
                        "type": "base64", "media_type": media_type, "data": image_data}},
                    {"type": "text", "text": "Extract all text from this image."}
                ]
            }]
        }

        response = bedrock_client.invoke_model(
            modelId=LLM_MODEL_ID, body=json.dumps(body))
        result = json.loads(response["body"].read().decode("utf-8"))
        return "".join(
            block.get("text", "")
            for block in result.get("content", [])
            if block.get("type") == "text"
        )

    return ""


def _clean_text_with_llm(text: str, source_type: str) -> dict:
    """Clean text using LLM."""
    prompt = f"""Parse this {source_type} into JSON:

{{
  "clean_text": "<cleaned text>",
  "summary": "<2-3 sentence summary>",
  "action_items": [{{"title": "", "description": "", "owner": "", "due_date": "", "status": "pending"}}],
  "decisions": [{{"description": "", "confidence": 0.9}}],
  "entities": {{"projects": [], "people": [], "dates": []}}
}}

Content:
{text[:4000]}
"""

    try:
        response = llm.invoke(prompt)
        return json.loads(clean_llm_output(response.content))
    except Exception:
        return {
            "clean_text": text,
            "summary": text[:300],
            "action_items": [],
            "decisions": [],
            "entities": {}
        }


# ==============================================================================
# SECTION 23: PIPELINE IMPORTS (CONDITIONAL)
# ==============================================================================
PIPELINES_AVAILABLE = False
BATCH_INGESTION_AVAILABLE = False
PROJECTS_SERVICE_AVAILABLE = False

try:
    from transcript_pipeline.main_v2 import TranscriptPipelineV2
    from transcript_pipeline.config import Config as TranscriptConfig
    from transcript_pipeline.main_chat import MeetingChatPipeline
    PIPELINES_AVAILABLE = True
except ImportError:
    print("[INFO] Pipeline modules not available")

try:
    from batch_data_ingestion.core import (
        list_s3_files, extract_text_from_s3_file,
        BUCKET_NAME as INGESTION_BUCKET_NAME,
        TRANSCRIPT_PREFIX as INGESTION_TRANSCRIPT_PREFIX,
        CHAT_PREFIX as INGESTION_CHAT_PREFIX,
    )
    from batch_data_ingestion.transcript.ingestion import process_transcript_folder
    from batch_data_ingestion.chat.ingestion import process_chat_folder
    BATCH_INGESTION_AVAILABLE = True
except ImportError:
    print("[INFO] Batch ingestion modules not available")

try:
    from project_seeding.projects_service import (
        create_project as service_create_project,
        get_project as service_get_project,
        get_all_projects as service_get_all_projects,
        update_project as service_update_project,
        delete_project as service_delete_project,
    )
    PROJECTS_SERVICE_AVAILABLE = True
except ImportError:
    print("[INFO] Projects service not available")


# Thread pools
_transcript_executor = ThreadPoolExecutor(max_workers=2)
_chat_executor = ThreadPoolExecutor(max_workers=2)
_ingestion_executor = ThreadPoolExecutor(max_workers=2)


# ==============================================================================
# SECTION 24: PIPELINE ENDPOINTS (CONDITIONAL)
# ==============================================================================
class TranscriptRunMode(str, Enum):
    FULL = "full"
    INCREMENTAL = "incremental"
    SINCE = "since"


class TranscriptRunRequest(BaseModel):
    mode: TranscriptRunMode = Field(default=TranscriptRunMode.INCREMENTAL)
    since_date: Optional[str] = None
    limit: Optional[int] = None
    retry_failed: bool = True


if PIPELINES_AVAILABLE:
    @app.get("/transcript/config", tags=["Transcript Pipeline"])
    def get_transcript_config():
        pipeline = TranscriptPipelineV2()
        return {
            "status": "success",
            "configuration": {
                "aws_region": pipeline.config.aws_region,
                "s3_bucket_name": pipeline.config.s3_bucket_name,
            }
        }

    @app.post("/transcript/run", tags=["Transcript Pipeline"])
    async def run_transcript_pipeline(request: TranscriptRunRequest):
        since_date = None
        if request.mode == TranscriptRunMode.SINCE and request.since_date:
            since_date = datetime.strptime(
                request.since_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)

        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            _transcript_executor,
            lambda: TranscriptPipelineV2().run(
                mode=request.mode.value,
                since_date=since_date,
                limit=request.limit,
                retry_failed=request.retry_failed,
            )
        )

        return {
            "status": "success",
            "mode": request.mode.value,
            "processed": result.processed,
            "failed": result.failed,
        }


class BatchIngestionRequest(BaseModel):
    dry_run: bool = False
    verbose: bool = False
    limit: Optional[int] = None
    skip_existing: bool = True


if BATCH_INGESTION_AVAILABLE:
    @app.get("/batch/transcript/config", tags=["Batch Ingestion"])
    def get_transcript_batch_config():
        return {
            "bucket_name": INGESTION_BUCKET_NAME,
            "s3_prefix": INGESTION_TRANSCRIPT_PREFIX,
        }

    @app.post("/batch/transcript/run", tags=["Batch Ingestion"])
    async def run_transcript_batch_ingestion(
        request: BatchIngestionRequest = BatchIngestionRequest()
    ):
        loop = asyncio.get_event_loop()
        stats = await loop.run_in_executor(
            _ingestion_executor,
            lambda: process_transcript_folder(
                prefix=INGESTION_TRANSCRIPT_PREFIX,
                dry_run=request.dry_run,
                limit=request.limit,
                skip_existing=request.skip_existing,
            )
        )
        return {"status": "success", "statistics": stats}

    @app.get("/batch/chat/config", tags=["Batch Ingestion"])
    def get_chat_batch_config():
        return {
            "bucket_name": INGESTION_BUCKET_NAME,
            "s3_prefix": INGESTION_CHAT_PREFIX,
        }

    @app.post("/batch/chat/run", tags=["Batch Ingestion"])
    async def run_chat_batch_ingestion(
        request: BatchIngestionRequest = BatchIngestionRequest()
    ):
        loop = asyncio.get_event_loop()
        stats = await loop.run_in_executor(
            _ingestion_executor,
            lambda: process_chat_folder(
                prefix=INGESTION_CHAT_PREFIX,
                dry_run=request.dry_run,
                limit=request.limit,
                skip_existing=request.skip_existing,
            )
        )
        return {"status": "success", "statistics": stats}


# ==============================================================================
# SECTION 25: PROJECTS ENDPOINTS (CONDITIONAL)
# ==============================================================================
class ProjectCreateRequest(BaseModel):
    project_name: str = Field(..., min_length=1, max_length=500)
    project_description: str = Field(..., min_length=1, max_length=10000)


class ProjectUpdateRequest(BaseModel):
    project_name: Optional[str] = Field(None, min_length=1, max_length=500)
    project_description: Optional[str] = Field(None, min_length=1, max_length=10000)
    status: Optional[str] = Field(None, pattern="^(Active|Inactive)$")


if PROJECTS_SERVICE_AVAILABLE:
    @app.post("/projects", tags=["Projects"])
    def create_project_endpoint(request: ProjectCreateRequest):
        return service_create_project(
            project_name=request.project_name,
            project_description=request.project_description,
        )

    @app.get("/projects", tags=["Projects"])
    def list_projects_endpoint(limit: Optional[int] = None):
        projects = service_get_all_projects(limit=limit)
        return {"total": len(projects), "projects": projects}

    @app.get("/projects/{project_id}", tags=["Projects"])
    def get_project_endpoint(project_id: str):
        project = service_get_project(project_id)
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        return project

    @app.put("/projects/{project_id}", tags=["Projects"])
    def update_project_endpoint(project_id: str, request: ProjectUpdateRequest):
        # Check project exists
        existing = service_get_project(project_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Project not found")
        
        # Update project
        updated = service_update_project(
            project_id=project_id,
            project_name=request.project_name,
            project_description=request.project_description,
            status=request.status
        )
        return updated

    @app.delete("/projects/{project_id}", tags=["Projects"])
    def delete_project_endpoint(project_id: str):
        service_delete_project(project_id)
        return {"status": "deleted", "project_id": project_id}


# ==============================================================================
# SECTION 26: STATIC FILES & ROOT
# ==============================================================================
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def serve_index():
    return FileResponse("static/onboarding.html")


@app.on_event("startup")
async def startup_event():
    """Initialize caches on startup."""
    print("[STARTUP] Initializing application...")
    # Preload projects cache
    projects = get_known_projects(force_refresh=True)
    print(f"[STARTUP] Loaded {len(projects)} projects: {projects}")
    print("[STARTUP] Application ready!")


@app.get("/health")
def health_check():
    """Health check endpoint."""
    projects = get_known_projects()
    return {
        "status": "healthy",
        "projects_loaded": len(projects),
        "known_projects": projects
    }


# ==============================================================================
# SECTION 27: MAIN ENTRY POINT
# ==============================================================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

