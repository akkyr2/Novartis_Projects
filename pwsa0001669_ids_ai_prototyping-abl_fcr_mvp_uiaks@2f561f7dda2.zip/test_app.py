"""
ABL Coaching Agent — Full End-to-End Flow Test
================================================
Tests the ENTIRE app flow from login to FCR generation.

Run after every code change:
    python test_app.py

What it tests:
    1. Server health
    2. Guest login
    3. Full chat flow: ABL → TAS → Month → SEAM → Observations → Competencies
    4. Evaluation coaching (question flow)
    5. FCR generation (deep dive skip path)
    6. FCR approval
    7. Static files served
    8. Patterns API
"""

import json
import time
import sys
import os
import subprocess
import signal
import requests
from typing import Dict, Any, Optional, Tuple

# ==============================================================================
# CONFIG
# ==============================================================================
TEST_PORT = 8039
BASE_URL = f"http://127.0.0.1:{TEST_PORT}"
TIMEOUT = 15  # seconds per request
FCR_TIMEOUT = 180  # seconds for FCR generation (calls LLM)

# Unset proxies for localhost
os.environ.pop("http_proxy", None)
os.environ.pop("https_proxy", None)
os.environ.pop("HTTP_PROXY", None)
os.environ.pop("HTTPS_PROXY", None)

# ==============================================================================
# TEST HELPERS
# ==============================================================================
PASS = 0
FAIL = 0
ERRORS = []


def pass_test(name: str, detail: str = ""):
    global PASS
    PASS += 1
    detail_str = f" — {detail}" if detail else ""
    print(f"  ✅ PASS: {name}{detail_str}")


def fail_test(name: str, detail: str = ""):
    global FAIL
    FAIL += 1
    ERRORS.append(f"{name}: {detail}")
    print(f"  ❌ FAIL: {name}")
    print(f"       → {detail[:200]}")


def chat(session_id: str, message: str, coaching_level: int = 3, role: str = "guest") -> Dict[str, Any]:
    """Send a chat message and return the response."""
    payload = {
        "session_id": session_id,
        "message": message,
        "coaching_level": coaching_level,
        "role": role,
    }
    resp = requests.post(f"{BASE_URL}/api/chat/", json=payload, timeout=TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def chat_with_polling(session_id: str, message: str, coaching_level: int = 3, role: str = "guest") -> Dict[str, Any]:
    """Send a chat message and poll if it triggers background processing."""
    result = chat(session_id, message, coaching_level, role)

    # If processing in background, poll for result
    if result.get("processing") and result.get("task_id"):
        task_id = result["task_id"]
        print(f"       ⏳ Background task: {task_id} — polling...")
        start = time.time()
        while time.time() - start < FCR_TIMEOUT:
            time.sleep(3)
            status_resp = requests.get(f"{BASE_URL}/api/chat/status/{task_id}", timeout=TIMEOUT)
            status = status_resp.json()
            progress = status.get("progress", "")
            if progress:
                print(f"       ⏳ {progress}")
            if status.get("status") == "done":
                return status.get("result", {})
            elif status.get("status") == "error":
                return status.get("result", {"reply": f"ERROR: {status}"})
        return {"reply": "TIMEOUT waiting for background task", "intake_complete": False}

    return result


# ==============================================================================
# SERVER MANAGEMENT
# ==============================================================================
def start_server() -> subprocess.Popen:
    """Start the FastAPI server for testing."""
    print(f"🚀 Starting test server on port {TEST_PORT}...")
    proc = subprocess.Popen(
        ["uvicorn", "app.src.main:app", "--host", "0.0.0.0", "--port", str(TEST_PORT)],
        cwd="/home/sagemaker-user/pwsa0001669_ids_ai_prototyping",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    # Wait for server to be ready
    for i in range(10):
        time.sleep(1)
        try:
            r = requests.get(f"{BASE_URL}/health", timeout=2)
            if r.status_code == 200:
                print(f"   Server ready (PID: {proc.pid})")
                return proc
        except Exception:
            pass
    print("   ⚠️  Server might not be ready, continuing anyway...")
    return proc


def stop_server(proc: subprocess.Popen):
    """Stop the test server."""
    print("\n🧹 Stopping test server...")
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()


# ==============================================================================
# TESTS
# ==============================================================================
def test_health():
    """Test 1: Health endpoints."""
    print("\n🔍 Test 1: Health endpoints")

    # Main health
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    if r.status_code == 200 and "ok" in r.text:
        pass_test("GET /health")
    else:
        fail_test("GET /health", f"HTTP {r.status_code}: {r.text[:100]}")

    # FCR health
    r = requests.get(f"{BASE_URL}/api/fcr/health", timeout=TIMEOUT)
    if r.status_code == 200:
        pass_test("GET /api/fcr/health")
    else:
        fail_test("GET /api/fcr/health", f"HTTP {r.status_code}")


def test_auth():
    """Test 2: Authentication."""
    print("\n🔍 Test 2: Authentication")

    # Guest login
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"username": "guest"}, timeout=TIMEOUT)
    if r.status_code == 200 and r.json().get("role") == "guest":
        pass_test("Guest login")
    else:
        fail_test("Guest login", f"HTTP {r.status_code}: {r.text[:100]}")

    # Invalid login rejected
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"username": "hacker", "password": "wrong"}, timeout=TIMEOUT)
    if r.status_code == 401:
        pass_test("Invalid login rejected (401)")
    else:
        fail_test("Invalid login rejected", f"Expected 401, got {r.status_code}")


def test_static_files():
    """Test 3: Static files served."""
    print("\n🔍 Test 3: Static files")

    files = ["login.html", "chat.html", "styles.css", "scripts.js", "patterns.html"]
    for f in files:
        r = requests.get(f"{BASE_URL}/static/{f}", timeout=TIMEOUT)
        if r.status_code == 200:
            pass_test(f"GET /static/{f}")
        else:
            fail_test(f"GET /static/{f}", f"HTTP {r.status_code}")


def test_patterns_api():
    """Test 4: Patterns API."""
    print("\n🔍 Test 4: Patterns API")

    r = requests.get(f"{BASE_URL}/api/patterns/names", timeout=TIMEOUT)
    if r.status_code == 200 and "abls" in r.text:
        pass_test("GET /api/patterns/names")
    else:
        fail_test("GET /api/patterns/names", f"HTTP {r.status_code}: {r.text[:100]}")


def test_full_chat_flow():
    """Test 5: Full chat flow — the critical E2E test."""
    print("\n🔍 Test 5: Full Chat Flow (E2E)")

    session_id = f"e2e_test_{int(time.time())}"

    # Step 1: Start chat — should ask for ABL selection
    print("   Step 1: Start chat...")
    r = chat(session_id, "hello", role="guest")
    reply = r.get("reply", "")
    if "action:" in reply or "assisting" in reply.lower():
        pass_test("Chat start → asks for ABL selection")
    else:
        fail_test("Chat start", f"Expected ABL options, got: {reply[:100]}")
        return  # Can't continue

    # Step 2: Select ABL (pick first action from reply)
    print("   Step 2: Select ABL...")
    # Extract first ABL name from [[action:Name]]
    import re
    actions = re.findall(r'\[\[action:([^\]]+)\]\]', reply)
    if not actions:
        fail_test("No ABL actions found in reply", reply[:100])
        return
    abl_name = actions[0]
    r = chat(session_id, abl_name, role="guest")
    reply = r.get("reply", "")
    if "action:" in reply or "coach" in reply.lower() or "whom" in reply.lower():
        pass_test(f"Select ABL '{abl_name}' → asks for TAS")
    else:
        fail_test("Select ABL", f"Got: {reply[:100]}")
        return

    # Step 3: Select TAS
    print("   Step 3: Select TAS...")
    actions = re.findall(r'\[\[action:([^\]]+)\]\]', reply)
    if not actions:
        fail_test("No TAS actions found in reply", reply[:100])
        return
    tas_name = actions[0]
    r = chat(session_id, tas_name, role="guest")
    reply = r.get("reply", "")
    if "month" in reply.lower() or "seam" in reply.lower() or "pre-work" in reply.lower():
        pass_test(f"Select TAS '{tas_name}' → asks for month or SEAM")
    else:
        fail_test("Select TAS", f"Got: {reply[:100]}")
        return

    # Step 4: Enter month
    print("   Step 4: Enter month...")
    # Check if it's asking for SEAM first or month
    if "seam" in reply.lower() or "pre-work" in reply.lower():
        # Skip SEAM
        r = chat(session_id, "skip", role="guest")
        reply = r.get("reply", "")

    if "month" in reply.lower():
        r = chat(session_id, "July 2026", role="guest")
        reply = r.get("reply", "")
        if "observ" in reply.lower() or "field day" in reply.lower() or "seam" in reply.lower():
            pass_test("Enter month → asks for observations or SEAM")
        else:
            fail_test("Enter month", f"Got: {reply[:100]}")
            return
    else:
        pass_test("Month step (skipped — already past)")

    # Step 5: Handle SEAM if asked
    if "seam" in reply.lower() or "pre-work" in reply.lower():
        print("   Step 5: Skip SEAM...")
        r = chat(session_id, "skip", role="guest")
        reply = r.get("reply", "")
        pass_test("SEAM skipped")

    # Step 6: Enter observations
    print("   Step 6: Enter observations...")
    observation = """During the field visit with Dr. Smith, the TAS demonstrated strong product knowledge 
    about Rhapsido but struggled with handling the doctor's objection about side effects. The TAS 
    did not directly address the concern and moved quickly to another topic. The TAS was hesitant 
    when asked about comparative efficacy data versus Dupixent. Pre-call planning was evident but 
    follow-up steps were not clearly established with the physician."""

    r = chat(session_id, observation, role="guest")
    reply = r.get("reply", "")
    if "competenc" in reply.lower() or "proceed" in reply.lower() or "action:" in reply.lower():
        pass_test("Observations accepted → shows competencies")
    else:
        fail_test("Enter observations", f"Got: {reply[:100]}")
        return

    # Step 7: Proceed with detected competencies
    print("   Step 7: Confirm competencies...")
    r = chat(session_id, "Proceed", role="guest")
    reply = r.get("reply", "")
    if "generate" in reply.lower() or "evaluation" in reply.lower() or "question" in reply.lower():
        pass_test("Competencies confirmed → evaluation options shown")
    else:
        fail_test("Confirm competencies", f"Got: {reply[:100]}")
        return

    # Step 8: Generate evaluation directly (skip questions for speed)
    print("   Step 8: Generate evaluation note...")
    r = chat_with_polling(session_id, "Generate Evaluation Now", role="guest")
    reply = r.get("reply", "")
    if "evaluation" in reply.lower() or "approve" in reply.lower() or "draft" in reply.lower():
        pass_test("Evaluation note generated")
    else:
        fail_test("Generate evaluation", f"Got: {reply[:150]}")
        return

    # Step 9: Approve evaluation
    print("   Step 9: Approve evaluation...")
    r = chat(session_id, "Approve", role="guest")
    reply = r.get("reply", "")
    if "kpi" in reply.lower() or "skip" in reply.lower() or "draft" in reply.lower() or "discuss" in reply.lower():
        pass_test("Evaluation approved → deep dive choice")
    else:
        fail_test("Approve evaluation", f"Got: {reply[:100]}")
        return

    # Step 10: Skip to FCR draft (faster path)
    print("   Step 10: Generate FCR (Skip to Draft)...")
    r = chat_with_polling(session_id, "Skip to Draft", coaching_level=3, role="guest")
    reply = r.get("reply", "")
    if "fcr" in reply.lower() or "draft" in reply.lower() or "competenc" in reply.lower() or "observation" in reply.lower() or "smart" in reply.lower():
        pass_test("🎉 FCR Draft generated successfully!")
    elif "error" in reply.lower() or "timeout" in reply.lower():
        fail_test("FCR generation failed", f"Got: {reply[:200]}")
    else:
        # Might still be a valid response
        if len(reply) > 100:
            pass_test("FCR Draft generated (response received)")
        else:
            fail_test("FCR generation — unexpected response", f"Got: {reply[:200]}")

    # Step 11: Check FCR result in response
    fcr_result = r.get("fcr_result")
    if fcr_result and fcr_result.get("draft"):
        draft = fcr_result["draft"]
        has_competencies = "competencies" in draft or "competency_scores" in str(fcr_result)
        has_smart = "smart_actions" in draft
        has_observations = "observations" in draft

        if has_competencies:
            pass_test("FCR has competency scores")
        else:
            fail_test("FCR missing competencies", str(list(draft.keys()))[:100])

        if has_smart:
            pass_test("FCR has SMART actions")
        else:
            fail_test("FCR missing SMART actions", str(list(draft.keys()))[:100])

        if has_observations:
            pass_test("FCR has observations")
        else:
            fail_test("FCR missing observations", str(list(draft.keys()))[:100])
    else:
        # FCR might be in the reply text (formatted), that's also fine
        if "SMART" in reply or "Observation" in reply:
            pass_test("FCR content present in reply")
        else:
            fail_test("FCR result not found in response", f"Keys: {list(r.keys())}")


# ==============================================================================
# MAIN
# ==============================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  ABL Coaching Agent — Full E2E Test Suite")
    print("=" * 60)

    # Start server
    server_proc = start_server()

    try:
        # Run all tests
        test_health()
        test_auth()
        test_static_files()
        test_patterns_api()
        test_full_chat_flow()

    except KeyboardInterrupt:
        print("\n\n⚠️  Tests interrupted by user.")
    except Exception as e:
        fail_test("UNEXPECTED ERROR", str(e))
        import traceback
        traceback.print_exc()
    finally:
        stop_server(server_proc)

    # Print summary
    print("\n" + "=" * 60)
    print(f"  RESULTS: ✅ {PASS} passed, ❌ {FAIL} failed")
    print("=" * 60)

    if ERRORS:
        print("\n  FAILURES:")
        for err in ERRORS:
            print(f"    - {err}")

    print("")
    sys.exit(0 if FAIL == 0 else 1)
