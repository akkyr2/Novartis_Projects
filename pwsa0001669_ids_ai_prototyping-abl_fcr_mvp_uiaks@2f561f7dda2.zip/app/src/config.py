"""
Centralized configuration for ABL Coaching Agent.

All environment-specific values live here. Import `settings` from this module
instead of using os.getenv() or hardcoding values in individual files.

Usage:
    from app.src.config import settings

    bedrock = BedrockClient(region_name=settings.aws_region)
    model_id = settings.bedrock_model_id
"""

import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables or .env file."""

    # ─── AWS ────────────────────────────────────────────────────────────────────
    aws_region: str = "us-east-1"

    # ─── Amazon Bedrock ─────────────────────────────────────────────────────────
    bedrock_model_id: str = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    bedrock_embed_model_id: str = "amazon.titan-embed-text-v2:0"

    # ─── S3 — FCR Storage ──────────────────────────────────────────────────────
    fcr_s3_bucket: str = "abl-field-coaching-reports"
    fcr_s3_prefix: str = "abl_app_fcr_extracted_json"

    # ─── S3 — KPI Data ─────────────────────────────────────────────────────────
    kpi_s3_bucket: str = "abl-kpi-data"
    kpi_s3_prefix: str = "kpi_reports"

    # ─── S3 — SEAM Pre-work ────────────────────────────────────────────────────
    seam_s3_bucket: str = "abl-field-coaching-reports"
    seam_s3_prefix: str = "seam_prework/"

    # ─── S3 — Memory (patterns, profiles) ──────────────────────────────────────
    memory_s3_bucket: str = "abl-field-coaching-reports"
    memory_prefix: str = "memory"

    # ─── OpenSearch Serverless ──────────────────────────────────────────────────
    opensearch_host: str = ""
    opensearch_index: str = "fcr-guidelines"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


settings = Settings()
