import json
import os
from typing import Optional, Dict, Any
 
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
 
 
from app.src.config import settings

DEFAULT_MODEL_ID = settings.bedrock_model_id
 
BOTO_CONFIG = Config(read_timeout=180, connect_timeout=10, retries={"max_attempts": 2})
 
 
class BedrockClient:
    def __init__(self, region_name: str = None):
        self.region_name = region_name or settings.aws_region
 
        self.runtime_client = boto3.client(
            "bedrock-runtime",
            region_name=region_name,
            config=BOTO_CONFIG,
        )
 
        self.bedrock_client = boto3.client(
            "bedrock",
            region_name=region_name,
        )
 
    def invoke_claude(
        self,
        prompt: str,
        model_id: Optional[str] = None,
        max_tokens: int = 2000,
        temperature: float = 0.0,
    ) -> str:
        selected_model_id = model_id or DEFAULT_MODEL_ID
 
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt,
                        }
                    ],
                }
            ],
        }
 
        try:
            response = self.runtime_client.invoke_model(
                modelId=selected_model_id,
                body=json.dumps(body),
                contentType="application/json",
                accept="application/json",
            )
 
            response_body = json.loads(response["body"].read())
 
            content = response_body.get("content", [])
 
            if content and isinstance(content, list):
                text_parts = []
 
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
 
                return "\n".join(text_parts).strip()
 
            return json.dumps(response_body)
 
        except ClientError as e:
            error = e.response.get("Error", {})
            code = error.get("Code", "UnknownClientError")
            message = error.get("Message", str(e))
 
            raise RuntimeError(
                f"Bedrock invoke failed. "
                f"Region: {self.region_name}. "
                f"Model ID: {selected_model_id}. "
                f"Error code: {code}. "
                f"Message: {message}"
            ) from e
 
        except Exception as e:
            raise RuntimeError(
                f"Unexpected Bedrock invoke error. "
                f"Region: {self.region_name}. "
                f"Model ID: {selected_model_id}. "
                f"Message: {str(e)}"
            ) from e
 
    def get_model_info(self, model_id: str) -> Optional[Dict[str, Any]]:
        try:
            response = self.bedrock_client.get_foundation_model(
                modelIdentifier=model_id,
            )
            return response
 
        except ClientError as e:
            error = e.response.get("Error", {})
            code = error.get("Code", "UnknownClientError")
            message = error.get("Message", str(e))
 
            raise RuntimeError(
                f"Get model info failed. "
                f"Region: {self.region_name}. "
                f"Model ID: {model_id}. "
                f"Error code: {code}. "
                f"Message: {message}"
            ) from e