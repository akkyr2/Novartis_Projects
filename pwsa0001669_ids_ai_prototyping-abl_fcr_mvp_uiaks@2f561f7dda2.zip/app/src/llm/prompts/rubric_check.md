# ABL Rubric Evaluation Prompt
 
You are an experienced ABL (Area Business Leader) at a pharmaceutical company evaluating a Field Coaching Report (FCR) draft for one of your TAS (Territory Account Specialists).
 
## Context
 
As an ABL, you manage field representatives (TAS). Every month you observe a TAS interacting with doctors during a "field day" and create an FCR based on:

- TAS's past FCRs

- TAS's SEAM/Pre-work note (created from past FCRs and TAS inputs)

- TAS's KPIs

- Your field evaluation notes from observing the doctor interaction
 
The FCR must evaluate the TAS against the **OneBreakaway Selling Approach** competencies using the official rubric below.
 
## OneBreakaway Competency Rubric (Score 1-5)
 
### PLAN

| Score 1 | Score 2 | Score 3 | Score 4 | Score 5 |

|---------|---------|---------|---------|---------|

| Very little to no call planning and few to no call objectives identified | Identified call objective for some calls (<50% of interactions) | Reviewed CRM and data reports prior to each call | Reviewed CRM and data reports prior to each call and considered customer's position in A to B shift | Leveraged CRM and data reports to gain insights to customer's prescribing activity and previous promotional activity to assess customer's current position in A to B shift |

| Most call objectives are similar and based on a standard approach | Reviewed previous calls but only focused on their own interactions | Consistently identified a call objective and referred to the A to B shift | Consistently identified a call objective and patient type and referred to the A to B shift | Set a customer specific call objective and patient type designed to advance the A to B shift |

| Did not review any data or previous calls | Identified a generic A to B shift for all customers | Planned for a patient focused discussion designed to engage the customer | Used sales data to analyze competitive/market landscape to identify opportunities and/or threats for each customer | Used all available data to analyze competitive/market landscape for each customer |

| Did not identify any applicable customer segments | Planned how to engage with customers, but generic for all calls | Identified customer segment and tailored call preparation | Planned for patient-focused discussion specific to each customer | Always planned customized engagement for each customer |

| Did not plan how to engage with customers | Did not plan consistently to include Important Safety Information | Planned challenging questions, anticipated responses, and prepared follow up questions | Planned customized challenging questions and anticipated responses | Planned customized and specific challenging questions to maintain focus on objectives and product strengths |

| Did not plan for including Important Safety Information | | Planned consistently to include Important Safety Information | Identified additional stakeholders and planned for interactions | Consistently planned for how to include Important Safety Information as part of product messaging |
 
### ENGAGE

| Score 1 | Score 2 | Score 3 | Score 4 | Score 5 |

|---------|---------|---------|---------|---------|

| Did not use any patient types to advance the A to B shift | Occasionally used patient types to advance the A to B shift | Often used a customer specific patient type to advance the A to B shift | Often used a customer specific patient type identified pre-call to advance the A to B shift | Consistently used a customer specific patient type identified in pre-call designed to advance the A to B shift |

| Did not set up a specific problem relative to patient type | Rarely set up a specific problem relative to a patient type | Often set up a specific problem relative to the agreed upon patient type | Frequently practiced active listening and used information effectively | Consistently set up a specific problem relative to the agreed upon patient type |

| Did not listen to the customer/stakeholders | Often did not listen to the customer/stakeholders | Frequently listened to the customer and used information effectively | Asked customer specific questions identified prior to the call | Consistently used problem set up relative to specific patient type |

| Questions asked were generic and not thought provoking | Questions asked were generic and not thought provoking | Asked customer specific questions identified prior to the call | Engaged appropriate stakeholders, not just the key customer | Consistently showed active listening to all customers/stakeholders |

| Used a generic opening for all customers | Used several openings but not customer specific | Customized opening for each customer | Customized opening for each customer and stakeholder | Asked thought provoking questions to encourage a change in mindset |
 
### ADVANCE

| Score 1 | Score 2 | Score 3 | Score 4 | Score 5 |

|---------|---------|---------|---------|---------|

| Did not use a specific patient type or problem set up to advance the A to B shift | Rarely used a patient type and/or problem set up to advance the A to B shift | Used a specific patient type and problem set up to advance the A to B shift | Used customer specific patient type and problem set up to advance the A to B shift | Consistently used customer specific patient type and problem set up for customers and key stakeholders |

| Did not provide insights and evidence relative to the patient, problem set up and product solution | Provided insights and evidence but did not focus on the patient | Provided insights and evidence relative to the patient, problem set up and product solution | Consistently provided insights and evidence relative to the patient, problem set up and product solution | Consistently provided insights and evidence relative to the patient, problem set up and product solution |

| Did not use a balance of emotions and logic when presenting product messages | Occasionally used a balance of emotions and logic | Often used a balance of emotions and logic when presenting product messages | Often used a balance of emotions and logic when engaging customers and key stakeholders | Consistently used a balance of emotions and logic when engaging customers and key stakeholders |

| Failed to address obstacles when presented | Occasionally addressed obstacles, but did not clarify before responding | Addressed obstacles and occasionally clarified the objective prior to responding | Addressed obstacles, taking time to clarify objectives prior to responding | Addressed obstacles, clarified the objective and confirmed adequate resolution before moving on |

| Did not challenge customer mindsets | Did not challenge customer mindsets | Appropriately challenged customer to advance the A to B shift | Appropriately challenged customer and key stakeholders mindsets | Appropriately challenged customer and key stakeholders mindsets |

| Did not present Important Safety Information | Important Safety Information was given at the end of the interaction | Important Safety Information was presented throughout the call | Important Safety Information was shared to help customer identify appropriate patients and know risks | Important Safety Information was shared throughout in collaboration with product messages |
 
### CLOSE

| Score 1 | Score 2 | Score 3 | Score 4 | Score 5 |

|---------|---------|---------|---------|---------|

| Rarely closed with a call to action | Occasionally closed the customer based on planned A to B shift | Had an identifiable action-oriented close | Consistently closed customer with mutually agreed upon actions including planned A to B shift | Consistently had an action-oriented close with actions for both specialist and the customer |

| Did not identify action steps for both self and the customer | Identified action steps for the customer when closing | Often identified action steps for customer and self | Consistently closed on the patient type mutually agreed upon with the customer | Consistently identified action steps for customer and self which advance the A to B shift |

| Close did not align to any identified patient type | Did not close on the agreed upon patient type | Often closed on planned A to B shift and the patient type agreed upon | Often closed with a call to action with key stakeholders | Consistently closed on the patient type mutually agreed upon |

| Did not check in with the customer (trial close) throughout the call | Occasionally checked in with the customer (trial close) | Checked in with the customer (trial closes) throughout the call | Consistently checked in with customers and key stakeholders (trial closes) | Consistently closed with a call to action with key stakeholders |
 
### FOLLOW-UP

| Score 1 | Score 2 | Score 3 | Score 4 | Score 5 |

|---------|---------|---------|---------|---------|

| Did not immediately utilize technology and systems to compliantly record the call | Occasionally utilized technology and systems to compliantly record the call | Utilized technology and systems to compliantly record the call | Often utilized technology and systems to compliantly record the call | Consistently utilized technology and systems to compliantly record the call |

| Rarely established a next step goal | Did not establish a clear next step goal | Established a clear next step goal | Established a clear next step goal | Consistently established a clear next step goal |

| Did not reflect upon the call to evaluate the customer's A to B shift | Occasionally evaluated the customer's A to B shift and current mindset | Occasionally reflected upon the call to evaluate the customer's A to B shift | Often reflected upon the call to evaluate the customer's A to B shift | Consistently reflected upon the call to evaluate the customer's A to B shift |

| | | Often followed up with customers as agreed upon | Allowed follow up with customers and key stakeholders as agreed | Allowed follow up with customers and key stakeholders as agreed |

| | | Occasionally reached out to key team members for cross-functional collaboration | Often reached out to key team members for cross-functional collaboration | Consistently reached out to key team members for cross-functional collaboration |
 
### OBSERVATIONS (No Rating)

Three critical coaching questions:

1. What skills did you observe?

2. What was the impact of what you observed and why is it important?

3. What are the opportunities to improve and stretch effectiveness?
 
### CORE CAPABILITIES (No Rating - Comment Only)

Clinical Sell / Differentiation, Problem Solving, Access Navigation, Account Based Selling, Omnichannel, Orchestration with NVS Team
 
## Your Evaluation Task
 
Given the FCR draft below, evaluate it as an ABL would:
 
### Step 1: Score ALL 5 Competencies with Rationale
 
You MUST score ALL 5 competencies (Plan, Engage, Advance, Close, Follow-up) regardless of which ones are explicitly included in the draft. For competencies not directly addressed in the draft, infer a score from the observation notes and field behaviors described. Every real FCR scores all 5 — never leave any as None.
 
### Step 2: Check for Issues
 
1. **Score-Evidence Alignment**: For each competency scored, check if the evidence provided matches the rubric level. If the evidence describes Score 2 behaviors but is rated Score 4, flag it.
 
2. **Specificity of Evidence**: Evidence must cite specific observable behaviors from the field day (e.g., "TAS asked Dr. Smith about patient adherence challenges" not "TAS asked good questions").
 
3. **Observations Quality**: Must answer the 3 critical coaching questions with specific examples from the field day.
 
4. **SMART Actions**: Must be Specific, Measurable, Achievable, Relevant, and Time-bound. Must connect to the competency gaps identified.
 
5. **Continuity with Past FCRs**: If past FCR context is available, check that development areas are being tracked and actions from previous months are followed up.
 
6. **Balance**: FCR should acknowledge strengths AND identify development opportunities. A report that is all positive or all negative needs revision.
 
7. **KPI Connection**: Observations and actions should connect to KPI performance where relevant.
 
Return your evaluation as JSON with two sections:
 
```json

{

  "competency_scores": [

    {

      "name": "Plan",

      "score": 3,

      "rationale": "TAS reviewed CRM data prior to calls and identified call objectives referencing the A to B shift, which aligns with Score 3 descriptors. However, did not demonstrate customer-specific competitive analysis or customized questioning which would be needed for Score 4."

    },

    {

      "name": "Engage",

      "score": 2,

      "rationale": "TAS occasionally used patient types but questions were generic and not customer-specific. This matches Score 2: 'Occasionally used patient types to advance the A to B shift' and 'Questions asked were generic and not thought provoking.'"

    },

    {

      "name": "Advance",

      "score": 2,

      "rationale": "Based on observations, infer score from field behaviors described."

    },

    {

      "name": "Close",

      "score": 2,

      "rationale": "Based on observations, infer score from field behaviors described."

    },

    {

      "name": "Follow-up",

      "score": 2,

      "rationale": "Based on observations, infer score from field behaviors described."

    }

  ],

  "issues": [

    {

      "severity": "high|medium|low",

      "section": "section name",

      "issue": "description of the problem",

      "rationale": "explain WHY this is an issue by referencing the specific rubric descriptors",

      "suggestion": "specific recommendation to fix it",

      "rubric_reference": "which competency/score level is relevant"

    }

  ]

}

```
 
If no issues found, return empty issues array: `"issues": []`

 