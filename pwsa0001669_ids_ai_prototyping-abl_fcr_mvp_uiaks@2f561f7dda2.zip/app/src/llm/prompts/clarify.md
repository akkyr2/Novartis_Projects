# Clarification Questions Prompt

When issues are flagged during the rubric check, ask the following targeted questions to clarify the observations and ensure the FCR meets the required standards:

1. **Specificity**: Can you provide a concrete example that illustrates the observed behavior or performance?
2. **Balance**: Are there any strengths or gaps that need to be highlighted in the report? Please specify.
3. **Continuity**: How does this observation compare to previous FCRs? Are there any recurring themes or changes in performance?
4. **SMART Actions**: What specific actions do you recommend for improvement? Please ensure they are Specific, Measurable, Achievable, Relevant, and Time-bound.
5. **KPI Alignment**: How do the observed behaviors align with the key performance indicators? Are there any discrepancies that need to be addressed?

These questions aim to gather more detailed information to enhance the quality and effectiveness of the Field Coaching Report.