const chatBox = document.getElementById("chatBox");
const messageInput = document.getElementById("messageInput");
const sendButton = document.getElementById("sendButton");
const voiceButton = document.getElementById("voiceButton");
const voiceIcon = document.getElementById("voiceIcon");
const sessionIdInput = document.getElementById("sessionId");
const debugOutput = document.getElementById("debugOutput");
const apiUrlDisplay = document.getElementById("apiUrlDisplay");

// Auth check — redirect to login if not authenticated
if (!sessionStorage.getItem("abl_logged_in")) {
  var basePath = window.location.pathname.replace(/\/static\/chat\.html.*/, "");
  window.location.href = basePath + "/static/login.html";
}
// Display logged-in user name
var _ablName = sessionStorage.getItem("abl_name") || "";
var _userNameEl = document.getElementById("userName");
if (_userNameEl && _ablName) { _userNameEl.textContent = _ablName; }
var _sidebarNameEl = document.getElementById("sidebarUserName");
if (_sidebarNameEl && _ablName) { _sidebarNameEl.textContent = _ablName; }

function logout() {
  sessionStorage.removeItem("abl_logged_in");
  sessionStorage.removeItem("abl_name");
  var basePath = window.location.pathname.replace(/\/static\/chat\.html.*/, "");
  window.location.href = basePath + "/static/login.html";
}

let recognition = null;
let isListening = false;
let finalVoiceTranscript = "";

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function normalizeMarkdown(value) {
  return String(value || "")
    .replace(/\r\n/g, "\n")
    .replace(/\\n/g, "\n")
    .replace(/\\\*/g, "*")
    .replace(/\\_/g, "_")
    .replace(/\\#/g, "#")
    .replace(/\\-/g, "-")
    .replace(/\\`/g, "`");
}

function renderInlineMarkdown(text) {
  // Extract [[action:...]] and [[more:...]] markers BEFORE escaping HTML
  var actions = [];
  var mores = [];
  var processed = String(text || "");
  processed = processed.replace(/\[\[action:([^\]]+)\]\]/g, function(match, p1, offset) {
    var placeholder = '%%ACTION' + actions.length + '%%';
    actions.push(p1);
    return placeholder;
  });
  processed = processed.replace(/\[\[more:([\s\S]*?)\]\]/g, function(match, p1, offset) {
    var placeholder = '%%MORE' + mores.length + '%%';
    mores.push(p1);
    return placeholder;
  });
  // Extract checkboxes
  var checkboxes = [];
  processed = processed.replace(/\[\[checkbox:([^\]]+)\]\]/g, function(match, p1) {
    var placeholder = '%%CHECKBOX' + checkboxes.length + '%%';
    checkboxes.push(p1);
    return placeholder;
  });

  let html = escapeHtml(processed);

  // Restore action buttons
  actions.forEach(function(p1, i) {
    var escaped = p1.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
    html = html.replace('%%ACTION' + i + '%%', '<button class="quick-chip inline-chip" onclick="useQuickPrompt(\'' + escaped + '\')">' + escapeHtml(p1) + '</button>');
  });

  // Restore more toggles
  mores.forEach(function(fullText, i) {
    var id = 'exp_' + Math.random().toString(36).substr(2, 8);
    var decoded = fullText.replace(/¦/g, '|');
    html = html.replace('%%MORE' + i + '%%', '<span class="expand-toggle" onclick="this.style.display=\'none\';document.getElementById(\'' + id + '\').style.display=\'inline\'">▼ more</span><span id="' + id + '" style="display:none">' + escapeHtml(decoded) + '</span>');
  });

  // Restore checkboxes
  checkboxes.forEach(function(name, i) {
    html = html.replace('%%CHECKBOX' + i + '%%', '<input type="checkbox" id="cb_' + name + '" checked style="width:16px;height:16px;accent-color:#7c3aed;cursor:pointer;vertical-align:middle;margin-right:6px;">');
  });

  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
  html = html.replace(/\*\*([\s\S]+?)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/__([\s\S]+?)__/g, "<strong>$1</strong>");
  html = html.replace(/(^|[\s(])_([^_\n]+?)_(?=$|[\s).,!?:;])/g, "$1<em>$2</em>");
  html = html.replace(/(^|[\s(])\*([^*\n]+?)\*(?=$|[\s).,!?:;])/g, "$1<em>$2</em>");

  return html;
}

function renderMarkdownLite(content) {
  const text = normalizeMarkdown(content);
  const lines = text.split("\n");

  let html = "";
  let paragraph = [];
  let inUl = false;
  let inOl = false;
  let inCodeBlock = false;
  let codeBlockContent = [];

  function flushParagraph() {
    if (paragraph.length > 0) {
      html += "<p>" + renderInlineMarkdown(paragraph.join(" ")) + "</p>";
      paragraph = [];
    }
  }

  function closeLists() {
    if (inUl) {
      html += "</ul>";
      inUl = false;
    }

    if (inOl) {
      html += "</ol>";
      inOl = false;
    }
  }

  function closeCodeBlock() {
    if (inCodeBlock) {
      html += "<pre><code>" + escapeHtml(codeBlockContent.join("\n")) + "</code></pre>";
      codeBlockContent = [];
      inCodeBlock = false;
    }
  }

  for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
    const rawLine = lines[lineIdx];
    const line = rawLine.trim();

    if (line.startsWith("```")) {
      if (inCodeBlock) {
        closeCodeBlock();
      } else {
        flushParagraph();
        closeLists();
        inCodeBlock = true;
        codeBlockContent = [];
      }
      continue;
    }

    if (inCodeBlock) {
      codeBlockContent.push(rawLine);
      continue;
    }

    if (!line) {
      flushParagraph();
      closeLists();
      // Close table if we were in one
      if (html.includes('<tbody>') && html.lastIndexOf('</table>') < html.lastIndexOf('<tbody>')) {
        html += '</tbody></table>';
      }
      continue;
    }

    if (/^####\s+/.test(line)) {
      flushParagraph();
      closeLists();
      html += "<h4>" + renderInlineMarkdown(line.replace(/^####\s+/, "")) + "</h4>";
      continue;
    }

    if (/^---+$/.test(line)) {
      flushParagraph();
      closeLists();
      // Close table if open before rendering hr
      if (html.includes('<tbody>') && html.lastIndexOf('</table>') < html.lastIndexOf('<tbody>')) {
        html += '</tbody></table>';
      }
      html += "<hr>";
      continue;
    }

    if (/^###\s+/.test(line)) {
      flushParagraph();
      closeLists();
      html += "<h3>" + renderInlineMarkdown(line.replace(/^###\s+/, "")) + "</h3>";
      continue;
    }

    if (/^##\s+/.test(line)) {
      flushParagraph();
      closeLists();
      html += "<h2>" + renderInlineMarkdown(line.replace(/^##\s+/, "")) + "</h2>";
      continue;
    }

    if (/^#\s+/.test(line)) {
      flushParagraph();
      closeLists();
      html += "<h1>" + renderInlineMarkdown(line.replace(/^#\s+/, "")) + "</h1>";
      continue;
    }

    if (/^>\s+/.test(line)) {
      flushParagraph();
      closeLists();
      html += "<blockquote>" + renderInlineMarkdown(line.replace(/^>\s+/, "")) + "</blockquote>";
      continue;
    }

    if (/^([-*+•])\s+/.test(line)) {
      flushParagraph();

      if (inOl) {
        html += "</ol>";
        inOl = false;
      }

      if (!inUl) {
        html += "<ul>";
        inUl = true;
      }

      html += "<li>" + renderInlineMarkdown(line.replace(/^([-*+•])\s+/, "")) + "</li>";
      continue;
    }

    if (/^\d+\.\s+/.test(line)) {
      flushParagraph();

      if (inUl) {
        html += "</ul>";
        inUl = false;
      }

      if (!inOl) {
        html += "<ol>";
        inOl = true;
      }

      html += "<li>" + renderInlineMarkdown(line.replace(/^\d+\.\s+/, "")) + "</li>";
      continue;
    }

    closeLists();

    // Table row detection
    if (line.startsWith("|") && line.endsWith("|")) {
      flushParagraph();
      // Check if this is a separator row (|---|---|)
      if (/^\|[\s\-:]+\|/.test(line) && line.replace(/[\s|:\-]/g, "") === "") {
        // Skip separator row, it's just formatting
        continue;
      }
      // Parse table cells
      const cells = line.split("|").slice(1, -1).map(c => c.trim());
      // Determine if this is a header (first table row before separator)
      const nextLineIdx = lineIdx + 1;
      const isHeader = nextLineIdx < lines.length && /^\|[\s\-:]+\|/.test(lines[nextLineIdx].trim());
      if (isHeader) {
        html += '<table><thead><tr>';
        cells.forEach(c => { html += '<th>' + renderInlineMarkdown(c) + '</th>'; });
        html += '</tr></thead><tbody>';
      } else {
        // Check if table body is already open
        if (!html.includes('<tbody>') || html.lastIndexOf('</table>') > html.lastIndexOf('<tbody>')) {
          html += '<table><tbody>';
        }
        html += '<tr>';
        cells.forEach(c => { html += '<td>' + renderInlineMarkdown(c) + '</td>'; });
        html += '</tr>';
      }
      continue;
    }

    // Close table if we were in one and hit a non-table line
    if (html.includes('<tbody>') && html.lastIndexOf('</table>') < html.lastIndexOf('<tbody>')) {
      html += '</tbody></table>';
    }

    paragraph.push(line);
  }

  flushParagraph();
  closeLists();
  closeCodeBlock();

  // Close any open table
  if (html.includes('<tbody>') && html.lastIndexOf('</table>') < html.lastIndexOf('<tbody>')) {
    html += '</tbody></table>';
  }

  return html;
}

function getDisplayTime() {
  return new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
}

function removeWelcomePanel() {
  const welcomePanel = document.getElementById("welcomePanel");

  if (welcomePanel && welcomePanel.parentNode) {
    welcomePanel.remove();
  }
}

function createTypingHtml() {
  return '<div class="typing"><span></span><span></span><span></span></div>';
}

function scrollChatToBottom() {
  requestAnimationFrame(function() {
    chatBox.scrollTop = chatBox.scrollHeight;
  });
}

function typeAssistantText(row, content, options = {}) {
  const bubble = row.querySelector(".message.assistant");

  if (!bubble) {
    return;
  }

  const fullText = String(content || "");

  // Render instantly (no typewriter animation)
  bubble.innerHTML = renderMarkdownLite(fullText);
  scrollChatToBottom();
  makeExpandableCells(row);
  if (typeof saveChatSession === "function") saveChatSession();
}

function addMessage(role, content, options = {}) {
  if (!options.keepWelcome) {
    removeWelcomePanel();
  }

  const row = document.createElement("div");
  row.classList.add("message-row");
  row.classList.add(role + "-row");

  const avatar = document.createElement("div");
  avatar.classList.add("avatar");

  const stack = document.createElement("div");
  stack.classList.add("message-stack");

  const meta = document.createElement("div");
  meta.classList.add("message-meta");

  const bubble = document.createElement("div");
  bubble.classList.add("message");
  bubble.dataset.role = role;

  if (role === "user") {
    avatar.classList.add("user-avatar");
    avatar.textContent = "ABL";
    meta.textContent = "You · " + getDisplayTime();
    bubble.classList.add("user");
    bubble.textContent = content;
  } else if (role === "assistant") {
    avatar.classList.add("assistant-avatar");
    avatar.textContent = "AI";
    meta.textContent = "Coaching Assistant · " + getDisplayTime();
    bubble.classList.add("assistant");

    if (options.loading) {
      bubble.innerHTML = createTypingHtml();
      row.dataset.loading = "true";
    } else if (options.typewriter) {
      bubble.innerHTML = "";
    } else {
      bubble.innerHTML = renderMarkdownLite(content);
      setTimeout(function() { makeExpandableCells(row); }, 50);
    }
  } else {
    avatar.classList.add("system-avatar");
    avatar.textContent = "i";
    meta.textContent = "System · " + getDisplayTime();
    bubble.classList.add("system");
    bubble.textContent = content;
  }

  stack.appendChild(meta);
  stack.appendChild(bubble);

  if (role === "user") {
    row.appendChild(stack);
    row.appendChild(avatar);
  } else {
    row.appendChild(avatar);
    row.appendChild(stack);
  }

  chatBox.appendChild(row);
  scrollChatToBottom();

  if (role === "assistant" && options.typewriter && !options.loading) {
    typeAssistantText(row, content, {
      speed: options.speed || 10,
      chunkSize: options.chunkSize || 2
    });
  }

  return row;
}

function useQuickPrompt(text) {
  // B1: "Edit FCR" opens the editor instead of sending to the backend.
  if (text === "Edit FCR") {
    openFcrEditor();
    return;
  }
  // #11: "Edit Goal N" opens the SMART Goal editor popup (no backend send).
  if (text === "Edit Goal 1" || text === "Edit Goal 2") {
    var gi = (text === "Edit Goal 1") ? 0 : 1;
    openGoalEditor(gi);
    return;
  }
  // #14: "Help Me Prepare for the Field Ride" now starts the real prep flow (handled backend).
  // (falls through to the normal send below)

  // Disable all inline action chips to prevent double-clicks
  document.querySelectorAll(".inline-chip").forEach(function(btn) {
    btn.disabled = true;
    btn.style.opacity = "0.5";
    btn.style.pointerEvents = "none";
  });

  messageInput.value = text;
  autoResizeTextarea();
  sendMessage();
}

// ─── Editable Final FCR (structured form + PDF preview) ─────────────────────
var _fcrFields = null;                 // current editable fields
var _editedFcrPending = null;          // holds edited fields until Save is clicked
var _fcrPreviewUrl = null;             // object URL for the PDF preview iframe

function _chatApiBase() {
  // /api/chat is where these endpoints live
  return getApiBasePath() + "/api/chat";
}

// Build the structured form HTML from the fields object.
function _buildFcrForm(f) {
  function inp(id, val) {
    return '<input id="' + id + '" value="' + escapeHtml(val || "") + '" ' +
      'style="width:100%;padding:6px 8px;border-radius:6px;border:1px solid rgba(168,85,247,0.3);background:#0b0f12;color:#f8fafc;font-family:inherit;font-size:13px;"/>';
  }
  function area(id, val, rows) {
    return '<textarea id="' + id + '" rows="' + (rows || 3) + '" ' +
      'style="width:100%;padding:8px;border-radius:6px;border:1px solid rgba(168,85,247,0.3);background:#0b0f12;color:#f8fafc;font-family:inherit;font-size:13px;line-height:1.5;resize:vertical;">' +
      escapeHtml(val || "") + '</textarea>';
  }
  function lbl(t) { return '<div style="font-size:11px;color:#c4b5fd;text-transform:uppercase;letter-spacing:0.5px;margin:12px 0 4px;">' + escapeHtml(t) + '</div>'; }

  var comp = f.competency_scores || {};
  var compRows = ["Plan", "Engage", "Advance", "Close", "Follow-up"].map(function (c) {
    return '<div style="display:flex;gap:8px;align-items:center;margin-bottom:4px;">' +
      '<span style="width:90px;font-size:12px;color:#a1a1aa;">' + c + '</span>' +
      inp("fcr_comp_" + c, comp[c]) + '</div>';
  }).join("");

  var smart = f.smart_actions || [];
  var smartRows = smart.map(function (a, i) {
    return lbl("SMART Action " + (i + 1) + " - Detail") + area("fcr_smart_detail_" + i, a.detail, 3) +
      lbl("SMART Action " + (i + 1) + " - Due Date") + inp("fcr_smart_due_" + i, a.due);
  }).join("");

  var prev = f.previous_smart || {};

  return '' +
    lbl("Coachee") + inp("fcr_coachee", f.coachee) +
    lbl("Reports To") + inp("fcr_reports_to", f.reports_to) +
    lbl("Status") + inp("fcr_status", f.status) +
    lbl("Session Type") + inp("fcr_session_type", f.session_type) +
    lbl("Previous SMART - Description") + area("fcr_prev_desc", prev.description, 2) +
    lbl("Previous SMART - Due Date") + inp("fcr_prev_due", prev.due_date) +
    lbl("Previous SMART - Status") + inp("fcr_prev_status", prev.status) +
    lbl("Performance & KPIs") + area("fcr_kpi", f.kpi_narrative, 5) +
    lbl("Selling Approach Scores") + compRows +
    lbl("Observations") + area("fcr_obs", f.observations, 4) +
    lbl("Core Capabilities") + area("fcr_cc", f.core_capabilities, 3) +
    smartRows +
    lbl("Specialist Comments") + area("fcr_specialist", f.specialist_comments, 2);
}

// Read the edited values back out of the form into a fields object.
function _readFcrForm() {
  var f = JSON.parse(JSON.stringify(_fcrFields || {}));
  function v(id) { var el = document.getElementById(id); return el ? el.value : ""; }
  f.coachee = v("fcr_coachee");
  f.reports_to = v("fcr_reports_to");
  f.status = v("fcr_status");
  f.session_type = v("fcr_session_type");
  f.previous_smart = { description: v("fcr_prev_desc"), due_date: v("fcr_prev_due"), status: v("fcr_prev_status") };
  f.kpi_narrative = v("fcr_kpi");
  f.competency_scores = {};
  ["Plan", "Engage", "Advance", "Close", "Follow-up"].forEach(function (c) { f.competency_scores[c] = v("fcr_comp_" + c); });
  f.observations = v("fcr_obs");
  f.core_capabilities = v("fcr_cc");
  (f.smart_actions || []).forEach(function (a, i) {
    a.detail = v("fcr_smart_detail_" + i);
    a.due = v("fcr_smart_due_" + i);
  });
  f.specialist_comments = v("fcr_specialist");
  return f;
}

async function openFcrEditor() {
  var overlay = document.getElementById("fcrEditOverlay");
  var formBox = document.getElementById("fcrEditForm");
  if (!overlay || !formBox) return;
  overlay.style.display = "flex";
  formBox.innerHTML = '<div style="color:#a1a1aa;padding:20px;">Loading FCR fields...</div>';

  try {
    var sid = sessionIdInput.value.trim();
    var resp = await fetch(_chatApiBase() + "/fcr_fields/" + encodeURIComponent(sid));
    var data = await resp.json();
    _fcrFields = data.fields || {};
    formBox.innerHTML = _buildFcrForm(_fcrFields);
    await refreshFcrPreview();
  } catch (e) {
    formBox.innerHTML = '<div style="color:#f87171;padding:20px;">Could not load FCR fields.</div>';
  }
}

function closeFcrEditor() {
  var overlay = document.getElementById("fcrEditOverlay");
  if (overlay) overlay.style.display = "none";
  if (_fcrPreviewUrl) { URL.revokeObjectURL(_fcrPreviewUrl); _fcrPreviewUrl = null; }
}

// Regenerate the PDF preview from the current form values.
async function refreshFcrPreview() {
  var frame = document.getElementById("fcrPreviewFrame");
  if (!frame) return;
  try {
    var fields = _readFcrForm();
    var resp = await fetch(_chatApiBase() + "/fcr_pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fields: fields })
    });
    var blob = await resp.blob();
    if (_fcrPreviewUrl) URL.revokeObjectURL(_fcrPreviewUrl);
    _fcrPreviewUrl = URL.createObjectURL(blob);
    frame.src = _fcrPreviewUrl;
  } catch (e) {
    // preview failure is non-fatal
  }
}

// Download the PDF built from the current (edited) fields.
async function downloadEditedFcr() {
  try {
    var fields = _readFcrForm();
    var resp = await fetch(_chatApiBase() + "/fcr_pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fields: fields })
    });
    var blob = await resp.blob();
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = "Coaching_Report.pdf";
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  } catch (e) {
    alert("Could not generate the PDF for download.");
  }
}

// "Done & Save": capture edited fields and save them (same format -> S3).
function confirmFcrEdit() {
  _editedFcrPending = _readFcrForm();
  closeFcrEditor();
  messageInput.value = "Save";
  autoResizeTextarea();
  sendMessage();
}

// ─── #11: Editable SMART Goal popup (simple form, no PDF) ───────────────────
var _goalEditIndex = null;          // which goal is being edited (0 or 1)
var _editedGoalPending = null;      // {index, fields} sent with the next message

var _GOAL_FIELDS = [
  ["goal_headline", "Goal Headline"],
  ["specific", "Specific"],
  ["measurable", "Measurable"],
  ["achievable", "Achievable"],
  ["relevant", "Relevant"],
  ["time_bound", "Time-Bound"],
  ["impact", "Impact"],
];

async function openGoalEditor(goalIndex) {
  var overlay = document.getElementById("goalEditOverlay");
  var formBox = document.getElementById("goalEditForm");
  var title = document.getElementById("goalEditTitle");
  if (!overlay || !formBox) return;
  _goalEditIndex = goalIndex;
  title.textContent = "Edit SMART Goal " + (goalIndex + 1);
  overlay.style.display = "flex";
  formBox.innerHTML = '<div style="color:#a1a1aa;padding:20px;">Loading goal...</div>';

  try {
    var sid = sessionIdInput.value.trim();
    var resp = await fetch(_chatApiBase() + "/goal_fields/" + encodeURIComponent(sid) + "/" + goalIndex);
    var data = await resp.json();
    var f = data.fields;
    if (!f) {
      formBox.innerHTML = '<div style="color:#f87171;padding:20px;">Goal not found.</div>';
      return;
    }
    formBox.innerHTML = _GOAL_FIELDS.map(function (pair) {
      var id = "goal_" + pair[0];
      var lbl = '<div style="font-size:11px;color:#c4b5fd;text-transform:uppercase;letter-spacing:0.5px;margin:12px 0 4px;">' + escapeHtml(pair[1]) + '</div>';
      var val = escapeHtml(f[pair[0]] || "");
      var rows = (pair[0] === "goal_headline") ? 2 : 2;
      return lbl + '<textarea id="' + id + '" rows="' + rows + '" style="width:100%;padding:8px;border-radius:6px;border:1px solid rgba(168,85,247,0.3);background:#0b0f12;color:#f8fafc;font-family:inherit;font-size:13px;line-height:1.5;resize:vertical;">' + val + '</textarea>';
    }).join("");
  } catch (e) {
    formBox.innerHTML = '<div style="color:#f87171;padding:20px;">Could not load goal.</div>';
  }
}

function closeGoalEditor() {
  var overlay = document.getElementById("goalEditOverlay");
  if (overlay) overlay.style.display = "none";
}

function saveGoalEdit() {
  function v(id) { var el = document.getElementById(id); return el ? el.value : ""; }
  var fields = {};
  _GOAL_FIELDS.forEach(function (pair) { fields[pair[0]] = v("goal_" + pair[0]); });
  _editedGoalPending = { index: _goalEditIndex, fields: fields };
  closeGoalEditor();
  // Send a normal message; the backend applies edited_goal at the eval-confirmation step.
  messageInput.value = "Save edited goal";
  autoResizeTextarea();
  sendMessage();
}

function autoResizeTextarea() {
  messageInput.style.height = "auto";
  messageInput.style.height = Math.min(messageInput.scrollHeight, 150) + "px";
}

function getApiBasePath() {
  const path = window.location.pathname;

  if (path.includes("/static/chat.html")) {
    return path.split("/static/chat.html")[0];
  }

  if (path.endsWith("/static/")) {
    return path.replace("/static/", "");
  }

  return "";
}

function getChatApiUrl() {
  const basePath = getApiBasePath();
  return basePath + "/api/chat/";
}

function createWelcomePanel(title, description) {
  const welcome = document.createElement("div");
  welcome.className = "welcome-panel";
  welcome.id = "welcomePanel";
  welcome.innerHTML = `
    <h3>${escapeHtml(title)}</h3>
    <p>${escapeHtml(description)}</p>
    <div class="quick-actions">
      <button class="quick-chip" onclick="useQuickPrompt('Start FCR draft')">📝 Draft an FCR</button>
      <button class="quick-chip" onclick="useQuickPrompt('Help Me Prepare for the Field Ride')">🚗 Help Me Prepare for the Field Ride</button>
    </div>
  `;

  return welcome;
}

function makeExpandableCells(container) {
  var cells = (container || chatBox).querySelectorAll(".assistant td");
  cells.forEach(function(td) {
    if (td.dataset.expandable) return;
    if (td.cellIndex !== 2) return;
    var table = td.closest("table");
    if (!table) return;
    var headerRow = table.querySelector("th:nth-child(3)");
    if (!headerRow || !headerRow.textContent.match(/Rationale/i)) return;

    var fullText = td.innerHTML;
    var words = td.textContent.trim().split(/\s+/);
    if (words.length <= 20) return;

    var shortText = words.slice(0, 20).join(" ") + "...";
    td.dataset.expandable = "true";
    td.dataset.fullHtml = fullText;
    td.innerHTML = '<span class="cell-short">' + escapeHtml(shortText) + '</span><span class="cell-toggle"> ▼ more</span>';
    td.style.cursor = "pointer";

    td.addEventListener("click", function() {
      if (td.classList.contains("expanded")) {
        td.innerHTML = '<span class="cell-short">' + escapeHtml(shortText) + '</span><span class="cell-toggle"> ▼ more</span>';
        td.classList.remove("expanded");
      } else {
        td.innerHTML = td.dataset.fullHtml + '<span class="cell-toggle"> ▲ less</span>';
        td.classList.add("expanded");
      }
    });
  });
}

function onCoachingLevelChange() {
  var level = document.getElementById("coachingLevel").value;
  saveChatSession();
}

function toggleMenu() {
  document.getElementById("navMenu").classList.toggle("open");
}

document.addEventListener("click", function(e) {
  if (!e.target.closest(".hamburger-wrap")) {
    document.getElementById("navMenu").classList.remove("open");
  }
});

function startNewChat() {
  var ablPrefix = (sessionStorage.getItem("abl_name") || "anon").replace(/\s+/g, "");
  const newSessionId = ablPrefix + "_CHAT" + Date.now();
  sessionStorage.removeItem(_chatKey("chat_session_id"));
  sessionStorage.removeItem(_chatKey("chat_messages"));
  sessionStorage.removeItem(_chatKey("chat_steps"));
  sessionStorage.removeItem(_chatKey("chat_coaching_level"));

  document.getElementById("coachingLevel").disabled = false;
  document.getElementById("coachingLevel").value = "";

  if (isListening && recognition) {
    recognition.stop();
  }

  sessionIdInput.value = newSessionId;
  chatBox.innerHTML = "";
  debugOutput.textContent = "No response yet.";
  apiUrlDisplay.textContent = "API URL not called yet.";

  // Reset progress steps to step 1
  document.querySelectorAll(".info-item").forEach(el => {
    const s = parseInt(el.dataset.step);
    const icon = el.querySelector(".info-icon");
    el.classList.remove("active", "completed");
    if (s === 1) {
      el.classList.add("active");
    }
    icon.textContent = s;
  });

  const welcome = createWelcomePanel(
    "New coaching session started",
    "Use this session to type or speak ABL observations, TAS inputs, SEAM notes, and coaching discussion points for the current month FCR."
  );

  chatBox.appendChild(welcome);

  addMessage("system", "New chat started. Session ID: " + newSessionId, { keepWelcome: true });

  addMessage(
    "assistant",
    "Hello. I am ready to help you draft a professional Field Coaching Report. Type or speak `Start FCR draft` to begin.",
    {
      keepWelcome: true,
      typewriter: true,
      speed: 12,
      chunkSize: 2
    }
  );

  messageInput.value = "";
  autoResizeTextarea();
  messageInput.focus();
  scrollChatToBottom();
}

function setupVoiceRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    if (voiceButton) {
      voiceButton.disabled = true;
      voiceButton.title = "Voice input is not supported in this browser";
      voiceIcon.textContent = "Off";
    }

    return null;
  }

  const recognitionInstance = new SpeechRecognition();

  recognitionInstance.lang = "en-US";
  recognitionInstance.continuous = true;
  recognitionInstance.interimResults = true;

  recognitionInstance.onstart = function() {
    isListening = true;
    finalVoiceTranscript = messageInput.value.trim();

    voiceButton.classList.add("listening");
    voiceIcon.textContent = "Stop";
    voiceButton.title = "Stop voice input";
    messageInput.placeholder = "Listening. Speak now...";
  };

  recognitionInstance.onresult = function(event) {
    let interimTranscript = "";

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;

      if (event.results[i].isFinal) {
        finalVoiceTranscript += " " + transcript.trim();
      } else {
        interimTranscript += transcript;
      }
    }

    const combinedText = (finalVoiceTranscript + " " + interimTranscript).trim();

    messageInput.value = combinedText;
    autoResizeTextarea();
  };

  recognitionInstance.onerror = function(event) {
    console.warn("Voice recognition error:", event.error);

    isListening = false;
    voiceButton.classList.remove("listening");
    voiceIcon.textContent = "Mic";
    voiceButton.title = "Start voice input";
    messageInput.placeholder = "Type or speak your coaching observation, TAS note, or FCR request...";

    if (event.error === "not-allowed") {
      addMessage("system", "Microphone permission was denied. Please allow microphone access in your browser settings to use voice input.");
    } else if (event.error === "no-speech") {
      addMessage("system", "No speech was detected. Please try again.");
    } else {
      addMessage("system", "Voice input stopped. You can try again or type your message.");
    }
  };

  recognitionInstance.onend = function() {
    isListening = false;
    voiceButton.classList.remove("listening");
    voiceIcon.textContent = "Mic";
    voiceButton.title = "Start voice input";
    messageInput.placeholder = "Type or speak your coaching observation, TAS note, or FCR request...";
  };

  return recognitionInstance;
}

function toggleVoiceInput() {
  if (!recognition) {
    recognition = setupVoiceRecognition();
  }

  if (!recognition) {
    addMessage("system", "Voice input is not supported in this browser. Please use Chrome, Edge, or another compatible browser.");
    return;
  }

  if (isListening) {
    recognition.stop();
    return;
  }

  try {
    recognition.start();
  } catch (error) {
    console.warn("Voice recognition start failed:", error);
  }
}

function updateProgressStep(data) {
  const field = data.current_field;
  const complete = data.intake_complete;
  const hasFcr = !!data.fcr_result;
  const processing = data.processing;
  const reply = (data.reply || "").toLowerCase();
  const stage = (data.intake_stage || "").toLowerCase();

  let step = 1;
  let allDone = false;

  if (hasFcr || processing || reply.includes("fcr draft") || reply.includes("compliance") || reply.includes("smart action") || reply.includes("revised fcr") || stage === "generating_draft") {
    step = 5;
    if (reply.includes("saved to memory") || reply.includes("not saved") || reply.includes("final field coaching report") || reply.includes("✅ final")) {
      allDone = true;
    }
  } else if (stage === "analyzing" || stage === "retrieving" || stage === "planning_questions" || stage === "waiting_for_first_answer" || stage === "waiting_for_answer" || stage === "asking_questions" || stage === "awaiting_deep_dive") {
    step = 4;
  } else if (complete || stage === "eval_coaching") {
    step = 3;
  } else if (field === "abl_eval_text" || field === "selected_competencies") {
    step = 2;
  } else {
    step = 1;
  }

  document.querySelectorAll(".info-item").forEach(el => {
    const s = parseInt(el.dataset.step);
    const icon = el.querySelector(".info-icon");
    el.classList.remove("active", "completed");
    if (allDone) {
      el.classList.add("completed");
      icon.textContent = "✓";
    } else if (s < step) {
      el.classList.add("completed");
      icon.textContent = "✓";
    } else if (s === step) {
      el.classList.add("active");
      icon.textContent = s;
    } else {
      icon.textContent = s;
    }
  });
}

async function pollForResult(taskId) {
  const basePath = getApiBasePath();
  const pollUrl = basePath + "/api/chat/status/" + encodeURIComponent(taskId);

  while (true) {
    await new Promise(resolve => setTimeout(resolve, 3000));

    try {
      const res = await fetch(pollUrl);
      const data = await res.json();

      if (data.status === "done" || data.status === "error") {
        debugOutput.textContent = JSON.stringify(data, null, 2);
        if (data.result) updateProgressStep(data.result);

        const loadingRows = chatBox.querySelectorAll('.message-row[data-loading="true"]');
        const lastLoadingRow = loadingRows[loadingRows.length - 1];

        if (lastLoadingRow) {
          lastLoadingRow.remove();
        }

        if (data.result && data.result.reply) {
          if (data.result.reply.includes("[[trigger:new_session]]")) {
            startNewChat();
          } else {
            addMessage("assistant", data.result.reply, {
              typewriter: true,
              speed: 9,
              chunkSize: 3
            });
          }
        } else if (data.status === "error") {
          addMessage("system", "Processing failed. Please try again.");
        } else {
          addMessage("assistant", "No reply received from assistant.", {
            typewriter: true,
            speed: 10,
            chunkSize: 2
          });
        }

        return;
      }

      // Still processing — update loading bubble with progress from backend
      if (data.progress) {
        var loadingRows = chatBox.querySelectorAll('.message-row[data-loading="true"]');
        var activeRow = loadingRows[loadingRows.length - 1];
        if (activeRow) {
          var bubble = activeRow.querySelector(".message.assistant");
          if (bubble) {
            bubble.innerHTML = '<div class="progress-status">' + escapeHtml(data.progress) + '</div>' + createTypingHtml();
          }
        }
      }
    } catch (error) {
      console.warn("Polling failed, retrying:", error);
    }
  }
}

async function sendMessage() {
  if (sendMessage._sending) return;
  sendMessage._sending = true;

  // Take any pending edited FCR fields for THIS send, then clear so they
  // never leak into subsequent messages.
  const editedFcrFields = _editedFcrPending;
  _editedFcrPending = null;
  // #11: same for an edited SMART goal.
  const editedGoal = _editedGoalPending;
  _editedGoalPending = null;

  const sessionId = sessionIdInput.value.trim();
  const message = messageInput.value.trim();

  if (!sessionId) {
    addMessage("system", "Please enter a session ID.");
    sendMessage._sending = false;
    return;
  }

  var coachingLevel = document.getElementById("coachingLevel").value;
  if (!coachingLevel) coachingLevel = "3";

  if (!message) {
    sendMessage._sending = false;
    return;
  }

  // Lock coaching level after first message
  document.getElementById("coachingLevel").disabled = true;

  if (isListening && recognition) {
    recognition.stop();
  }

  // Disable all action chips to prevent stale clicks
  document.querySelectorAll(".inline-chip").forEach(function(btn) {
    btn.disabled = true;
    btn.style.opacity = "0.5";
    btn.style.pointerEvents = "none";
  });

  addMessage("user", message);

  messageInput.value = "";
  finalVoiceTranscript = "";
  autoResizeTextarea();

  sendButton.disabled = true;
  voiceButton.disabled = true;
  sendButton.textContent = "Sending";

  let loadingRow = null;

  try {
    const apiUrl = getChatApiUrl();
    apiUrlDisplay.textContent = "Calling API URL: " + apiUrl;

    loadingRow = addMessage("assistant", "", { loading: true });
    const loadingStartTime = Date.now();

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        session_id: sessionId,
        message: message,
        coaching_level: parseInt(coachingLevel),
        abl_name: sessionStorage.getItem("abl_name") || null,
        role: sessionStorage.getItem("abl_role") || null,
        edited_fcr_fields: editedFcrFields || null,
        edited_goal: editedGoal || null
      })
    });

    const responseText = await response.text();

    let data;

    try {
      data = JSON.parse(responseText);
    } catch (parseError) {
      debugOutput.textContent = responseText;

      if (loadingRow) {
        loadingRow.remove();
      }

      throw new Error("API returned non JSON response: " + responseText);
    }

    debugOutput.textContent = JSON.stringify(data, null, 2);

    if (!response.ok) {
      if (loadingRow) {
        loadingRow.remove();
      }

      addMessage("system", "API error: " + JSON.stringify(data, null, 2));
      return;
    }

    if (data.processing && data.task_id) {
      updateProgressStep(data);
      sendButton.textContent = "Processing";
      // Replace dots with processing message, keep a new loading row for polling
      if (loadingRow) {
        loadingRow.remove();
      }
      addMessage("assistant", data.reply || "⏳ Processing your request...", { typewriter: false });
      loadingRow = addMessage("assistant", "", { loading: true });
      await pollForResult(data.task_id);
    } else if (data.reply) {
      updateProgressStep(data);
      // Ensure dots show for at least 600ms
      const elapsed = Date.now() - loadingStartTime;
      if (elapsed < 600) {
        await new Promise(r => setTimeout(r, 600 - elapsed));
      }
      if (loadingRow) {
        loadingRow.remove();
      }

      // Check for new session trigger
      if (data.reply && data.reply.includes("[[trigger:new_session]]")) {
        if (loadingRow) { loadingRow.remove(); }
        startNewChat();
      } else {
        addMessage("assistant", data.reply, {
          typewriter: true,
          speed: 9,
          chunkSize: 3
        });
      }
    } else {
      if (loadingRow) {
        loadingRow.remove();
      }

      addMessage("assistant", "No reply received from assistant.", {
        typewriter: true,
        speed: 10,
        chunkSize: 2
      });
    }
  } catch (error) {
    if (loadingRow) {
      loadingRow.remove();
    }

    addMessage("system", "Request failed: " + error.message);
  } finally {
    sendMessage._sending = false;
    sendButton.disabled = false;

    if (recognition) {
      voiceButton.disabled = false;
    }

    sendButton.textContent = "Send";
    messageInput.focus();
    scrollChatToBottom();
  }
}

messageInput.addEventListener("input", autoResizeTextarea);

messageInput.addEventListener("keydown", function(event) {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});

// --- Session persistence ---
function _chatKey(key) {
  var user = sessionStorage.getItem("abl_name") || "anon";
  return user + "_" + key;
}

function saveChatSession() {
  sessionStorage.setItem(_chatKey("chat_session_id"), sessionIdInput.value);
  sessionStorage.setItem(_chatKey("chat_messages"), chatBox.innerHTML);
  sessionStorage.setItem(_chatKey("chat_coaching_level"), document.getElementById("coachingLevel").value);
  var steps = [];
  document.querySelectorAll(".info-item").forEach(function(el) {
    steps.push(el.className);
  });
  sessionStorage.setItem(_chatKey("chat_steps"), JSON.stringify(steps));
}

function restoreChatSession() {
  var savedId = sessionStorage.getItem(_chatKey("chat_session_id"));
  var savedMessages = sessionStorage.getItem(_chatKey("chat_messages"));
  if (savedId && savedMessages) {
    sessionIdInput.value = savedId;
    chatBox.innerHTML = savedMessages;
    var savedLevel = sessionStorage.getItem(_chatKey("chat_coaching_level"));
    if (savedLevel) {
      document.getElementById("coachingLevel").value = savedLevel;
      document.getElementById("coachingLevel").disabled = true;
    }
    var steps = JSON.parse(sessionStorage.getItem(_chatKey("chat_steps")) || "[]");
    document.querySelectorAll(".info-item").forEach(function(el, i) {
      if (steps[i]) el.className = steps[i];
    });
    scrollChatToBottom();
    return true;
  }
  return false;
}

// Wrap addMessage to auto-save after each message
var _origAddMessage = addMessage;
addMessage = function(role, content, options) {
  var row = _origAddMessage(role, content, options);
  // Save after render (let typewriter finish for non-loading messages)
  if (!options || !options.loading) {
    setTimeout(saveChatSession, 200);
  }
  return row;
};

// Initialize
recognition = setupVoiceRecognition();

if (!restoreChatSession()) {
  var ablPrefix = (sessionStorage.getItem("abl_name") || "anon").replace(/\s+/g, "");
  sessionIdInput.value = ablPrefix + "_CHAT" + Date.now();
  addMessage(
    "assistant",
    "Hello. I am your ABL Coaching Agent. You can type or click **Mic** to speak your input. Type or say `Start FCR draft` to begin.",
    {
      keepWelcome: true,
      typewriter: true,
      speed: 12,
      chunkSize: 2
    }
  );
}

// Save chat before navigating away (patterns page, etc.)
window.addEventListener("beforeunload", function() { saveChatSession(); });

console.log("ABL Coaching Agent loaded.");
