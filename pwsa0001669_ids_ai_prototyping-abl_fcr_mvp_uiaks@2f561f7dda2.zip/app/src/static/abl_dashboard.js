// ABL Dashboard - team roll-up view.
// Additive page: reuses the existing read-only /api/patterns/dashboard/data endpoint
// (same data contract as patterns.html). No backend or shared-file changes.

function getApiBasePath() {
  // Mirror patterns.html: strip the /static/<page>.html suffix to find the API root.
  const path = window.location.pathname;
  if (path.includes("/static/abl_dashboard.html")) return path.split("/static/abl_dashboard.html")[0];
  if (path.includes("/static/")) return path.split("/static/")[0];
  return "";
}

// ---- small helpers (same behavior as patterns.html) ----
function freq(arr) { const f = {}; arr.forEach(x => { if (x) f[x] = (f[x] || 0) + 1; }); return f; }
function topItem(o) { const s = Object.entries(o).sort((a, b) => b[1] - a[1]); return s.length ? s[0][0] : "-"; }
function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

// A session's date can be a "YYYY-MM" month string or a full DATETIME.
function sessionDateObj(s) {
  const raw = s.DATETIME || s.month;
  if (!raw) return null;
  if (typeof raw === "string" && /^\d{4}-\d{2}$/.test(raw)) {
    const [y, m] = raw.split("-").map(Number);
    return new Date(y, m - 1, 1);
  }
  const d = new Date(raw);
  return isNaN(d.getTime()) ? null : d;
}

function daysSince(dateObj) {
  if (!dateObj) return null;
  const ms = Date.now() - dateObj.getTime();
  return Math.max(0, Math.floor(ms / (1000 * 60 * 60 * 24)));
}

function countThisYear(sessions) {
  const year = new Date().getFullYear();
  return sessions.filter(s => {
    const d = sessionDateObj(s);
    return d && d.getFullYear() === year;
  }).length;
}

function daysLabel(n) {
  if (n === null) return { text: "No data", cls: "" };
  if (n <= 14) return { text: n + " days", cls: "positive" };
  if (n <= 30) return { text: n + " days", cls: "warning" };
  return { text: n + " days", cls: "negative" };
}

async function loadDashboard() {
  // #13: optional RD drill-down. If opened with ?abl=<name> (from the RD Dashboard),
  // show THAT ABL's team. Without the param, behaves exactly as before (logged-in ABL).
  const urlAbl = new URLSearchParams(window.location.search).get("abl");
  const role = urlAbl ? "abl" : (sessionStorage.getItem("abl_role") || "abl");
  const targetAbl = urlAbl || sessionStorage.getItem("abl_name");
  const content = document.getElementById("content");

  // When arrived from the RD Dashboard, point the Back link there.
  if (urlAbl) {
    const back = document.getElementById("backLink");
    if (back) { back.textContent = "\u2190 Back to RD Dashboard"; back.setAttribute("href", "rd_dashboard.html"); }
  }

  try {
    const resp = await fetch(getApiBasePath() + "/api/patterns/dashboard/data?role=" + role);
    if (!resp.ok) {
      content.innerHTML = '<div class="empty-state">Could not load team data (server responded ' + resp.status + ').</div>';
      return;
    }
    let allData = await resp.json();

    // Filter to the target ABL's team (RD-selected ABL, or logged-in ABL).
    // Normalize (trim + lowercase) so minor encoding/whitespace differences still match.
    let team = allData;
    if (role !== "guest" && targetAbl) {
      const norm = s => String(s == null ? "" : s).trim().toLowerCase();
      const t = norm(targetAbl);
      team = allData.filter(d => norm(d.ABL_NAME) === t);
    }

    renderTeam(team, targetAbl, role);
  } catch (e) {
    content.innerHTML = '<div class="empty-state">Error loading team data. Please try again.</div>';
  }
}

function renderTeam(team, ablName, role) {
  const content = document.getElementById("content");
  const sub = document.getElementById("teamSub");

  if (ablName && role !== "guest") {
    sub.textContent = ablName + "'s Team - coaching overview";
  } else {
    sub.textContent = "Team coaching overview";
  }

  if (!team || !team.length) {
    content.innerHTML = '<div class="empty-state">No team members found for this account.</div>';
    return;
  }

  let teamFcrYtd = 0;
  let teamSessions = 0;
  const cards = team.map(rec => {
    const sessions = (rec.SESSION_MEMORY || []);
    const latest = sessions.length ? sessions[sessions.length - 1] : null;

    // Strengths / gaps aggregated across this rep's sessions.
    const allStr = sessions.flatMap(s => (s["FCR note Strengths"] || "").split(",").map(x => x.trim()).filter(x => x));
    const allGaps = sessions.flatMap(s => (s["FCR note Areas of Improvement"] || "").split(",").map(x => x.trim()).filter(x => x));
    const topStr = topItem(freq(allStr));
    const topGap = topItem(freq(allGaps));
    const focus = (latest && latest["Key Coaching Topics"] && latest["Key Coaching Topics"][0]) || "-";

    const lastDate = latest ? sessionDateObj(latest) : null;
    const dSince = daysSince(lastDate);
    const dLabel = daysLabel(dSince);
    const fcrYtd = countThisYear(sessions);

    teamFcrYtd += fcrYtd;
    teamSessions += sessions.length;

    return `
      <div class="rep-card">
        <div class="rep-head">
          <div class="rep-name">${escapeHtml(rec.TAS_NAME || "Unknown")}</div>
          <div class="rep-sessions">${sessions.length} session${sessions.length === 1 ? "" : "s"}</div>
        </div>
        <div class="rep-row"><span class="k">Coaching focus</span><span class="v">${escapeHtml(focus)}</span></div>
        <div class="patterns-box">
          <span class="patterns-box-title">Coaching Patterns</span>
          <div class="rep-row"><span class="k">Strength</span><span class="v positive">${escapeHtml(topStr)}</span></div>
          <div class="rep-row"><span class="k">Development area</span><span class="v negative">${escapeHtml(topGap)}</span></div>
        </div>
        <div class="rep-metrics">
          <div class="metric"><div class="m-value ${dLabel.cls}">${dLabel.text}</div><div class="m-label">Days since last coaching</div></div>
          <div class="metric"><div class="m-value">${fcrYtd}</div><div class="m-label">No. of FCRs this year</div></div>
        </div>
        <a class="view-link" href="patterns.html">View full profile &rarr;</a>
      </div>`;
  }).join("");

  // Team summary strip.
  document.getElementById("sumReps").textContent = team.length;
  document.getElementById("sumFcrYtd").textContent = teamFcrYtd;
  document.getElementById("sumSessions").textContent = teamSessions;
  document.getElementById("teamSummary").style.display = "flex";

  content.innerHTML = '<div class="cards-grid">' + cards + '</div>';
}

loadDashboard();
