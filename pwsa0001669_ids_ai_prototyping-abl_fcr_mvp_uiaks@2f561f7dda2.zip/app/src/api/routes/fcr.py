from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import traceback


router = APIRouter()


class DraftRequest(BaseModel):
    session_id: str
    tas_id: Optional[str] = None
    month: Optional[str] = None
    tas_prework_text: str
    abl_eval_text: str
    selected_competencies: List[str] = Field(default_factory=list)


class KPI(BaseModel):
    name: str
    value: str
    period: str
    as_of: str


class CompetencyScore(BaseModel):
    one_breakaway_area: str
    score: int
    evidence: str


class Observation(BaseModel):
    area: str
    what_i_saw: str
    impact: str


class SMARTAction(BaseModel):
    action: str
    measure: str
    due: str


class FCR(BaseModel):
    fcr_id: str
    tas_name: str
    abl_name: str
    date_of_field_day: str
    kpis: List[KPI]
    competencies: List[CompetencyScore]
    observations: List[Observation]
    smart_actions: List[SMARTAction]


def pydantic_to_dict(model: BaseModel) -> Dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()

    return model.dict()


@router.get("/health")
def fcr_health() -> Dict[str, Any]:
    return {
        "status": "fcr router is working"
    }


@router.post("/draft-test")
def draft_test(req: DraftRequest) -> Dict[str, Any]:
    return {
        "message": "Request received successfully",
        "data": pydantic_to_dict(req),
    }


@router.post("/draft")
def draft_fcr(req: DraftRequest) -> Dict[str, Any]:
    try:
        from app.src.graph.batch_workflow import graph

        initial_state = {
            "session_id": req.session_id,
            "tas_id": req.tas_id,
            "month": req.month,
            "tas_prework_text": req.tas_prework_text,
            "abl_eval_text": req.abl_eval_text,
            "selected_competencies": req.selected_competencies,
        }

        print("Initial state:")
        print(initial_state)

        final_state = graph.invoke(initial_state)

        print("Final state:")
        print(final_state)

        intake = final_state.get("intake", {})
        qa = final_state.get("qa", {})

        return {
            "session_id": final_state.get("session_id"),
            "tas_id": final_state.get("tas_id"),
            "month": final_state.get("month"),
            "intake_valid": intake.get("valid"),
            "intake_questions": intake.get("questions", []),
            "questions_to_user": qa.get("questions_to_user", []),
            "draft": final_state.get("draft"),
            "rubric_issues": final_state.get("rubric_issues", []),
            "final_state": final_state,
        }

    except Exception as e:
        print("ERROR INSIDE /api/fcr/draft")
        traceback.print_exc()

        return {
            "error": str(e),
            "error_type": type(e).__name__,
        }


@router.post("/submit")
async def submit_fcr(fcr_id: str):
    return {
        "status": "submitted",
        "fcr_id": fcr_id,
    }


@router.get("/records/{fcr_id}", response_model=FCR)
async def get_fcr(fcr_id: str):
    return {
        "fcr_id": fcr_id,
        "tas_name": "Sample TAS",
        "abl_name": "Sample ABL",
        "date_of_field_day": "2023-10-01",
        "kpis": [],
        "competencies": [],
        "observations": [],
        "smart_actions": [],
    }