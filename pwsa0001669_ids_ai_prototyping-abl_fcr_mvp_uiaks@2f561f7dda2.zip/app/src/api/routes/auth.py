"""Demo authentication — ABL login with profiles."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

# Demo credentials: ABL name → password (first name lowercase + 123)
DEMO_CREDENTIALS = {
    "Arthur Dornik": "arthur123",
    "Kylee Hay": "kylee123",
    "Lucas Russo": "lucas123",
    "Terrence Barrett": "terrence123",
}

# Demo RD credentials
RD_CREDENTIALS = {
    "Demo RD": "demo123",
}


class LoginRequest(BaseModel):
    username: str
    password: str = ""
    role: str = "abl"  # "abl" or "rd"


@router.post("/login")
def login(req: LoginRequest):
    """Validate credentials and return name + role."""
    # Guest login
    if req.username.lower().strip() == "guest":
        return {"abl_name": "Guest", "role": "guest", "status": "ok"}

    # RD login
    if req.role == "rd":
        for rd_name, pwd in RD_CREDENTIALS.items():
            if req.username.lower().strip() == rd_name.lower() and req.password == pwd:
                return {"abl_name": rd_name, "role": "rd", "status": "ok"}
        raise HTTPException(status_code=401, detail="Invalid RD username or password")

    # ABL login (default)
    for abl_name, pwd in DEMO_CREDENTIALS.items():
        if req.username.lower().strip() == abl_name.lower() and req.password == pwd:
            return {"abl_name": abl_name, "role": "abl", "status": "ok"}

    raise HTTPException(status_code=401, detail="Invalid username or password")
