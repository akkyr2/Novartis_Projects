"""
Patterns API - Serves TAS coaching profile data from S3 memory.

Endpoints:
  GET /api/patterns/names             - ABL/TAS names for dropdowns
  GET /api/patterns/dashboard/data    - Full dashboard data
  GET /api/patterns/{tas_id}          - Full coaching profile
  GET /api/patterns/{tas_id}/summary  - AI coaching summary only
  GET /api/patterns/{tas_id}/timeline - Month-by-month coaching journey
"""

import json
import os
from typing import Dict, Any, List, Optional

import boto3
from botocore.exceptions import ClientError
from fastapi import APIRouter, HTTPException

from app.src.services.name_masking import mask_name, mask_text

from app.src.config import settings

router = APIRouter()

S3_BUCKET = settings.memory_s3_bucket
MEMORY_PREFIX = "memory"


def _get_s3_client():
    return boto3.client("s3", region_name=settings.aws_region)


def _load_index(tas_id: str) -> Optional[Dict[str, Any]]:
    s3 = _get_s3_client()
    try:
        response = s3.get_object(Bucket=S3_BUCKET, Key=f"{MEMORY_PREFIX}/{tas_id}/index.json")
        return json.loads(response["Body"].read().decode("utf-8"))
    except ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchKey":
            return None
        raise


def _load_pattern(tas_id: str, month: str) -> Optional[Dict[str, Any]]:
    s3 = _get_s3_client()
    try:
        response = s3.get_object(Bucket=S3_BUCKET, Key=f"{MEMORY_PREFIX}/{tas_id}/patterns/{month}.json")
        return json.loads(response["Body"].read().decode("utf-8"))
    except ClientError:
        return None


def _list_tas_ids() -> List[str]:
    s3 = _get_s3_client()
    tas_ids = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=S3_BUCKET, Prefix=f"{MEMORY_PREFIX}/", Delimiter="/"):
            for prefix in page.get("CommonPrefixes", []):
                tas_id = prefix["Prefix"].replace(f"{MEMORY_PREFIX}/", "").rstrip("/")
                if tas_id:
                    tas_ids.append(tas_id)
    except Exception:
        pass
    return tas_ids


# ─── Static-path endpoints (must be before /{tas_id}) ────────────────────────


@router.get("/names")
async def get_abl_tas_names(role: str = "abl"):
    """Return ABL and TAS names from territory mapping file."""
    import pandas as pd
    from pathlib import Path

    DIRECT_LOGIN_ABLS = {"Arthur Dornik", "Kylee Hay", "Lucas Russo", "Terrence Barrett"}
    mapping_path = Path(__file__).resolve().parents[3] / "data" / "tas_territory_mapping.xlsx"

    if not mapping_path.exists():
        return {"abls": [], "abl_tas_map": {}, "error": "Territory mapping file not found"}

    try:
        df = pd.read_excel(str(mapping_path))
        abl_tas_map: Dict[str, List[str]] = {}
        for _, row in df.iterrows():
            abl = str(row.get("ABL", "")).strip()
            tas = str(row.get("TAS Name", "")).strip()
            if abl and tas:
                abl_tas_map.setdefault(abl, []).append(tas)

        # Filter based on role
        if role == "guest":
            abl_tas_map = {k: v for k, v in abl_tas_map.items() if k not in DIRECT_LOGIN_ABLS}
            # Mask names for guest
            abl_tas_map = {mask_name(k): [mask_name(t) for t in v] for k, v in abl_tas_map.items()}
        else:
            abl_tas_map = {k: v for k, v in abl_tas_map.items() if k in DIRECT_LOGIN_ABLS}

        return {"abls": sorted(abl_tas_map.keys()), "abl_tas_map": abl_tas_map}
    except Exception as e:
        return {"abls": [], "abl_tas_map": {}, "error": str(e)}


def _truncate_at_sentence(text: str, max_len: int) -> str:
    """Truncate text at a sentence boundary within max_len."""
    if not text or len(text) <= max_len:
        return text
    truncated = text[:max_len]
    # Find last sentence-ending punctuation
    for i in range(len(truncated) - 1, max(0, max_len - 80), -1):
        if truncated[i] in '.!?\n':
            return truncated[:i + 1].strip()
    # No sentence boundary found — truncate at last space
    last_space = truncated.rfind(' ')
    if last_space > max_len // 2:
        return truncated[:last_space] + "..."
    return truncated + "..."


@router.get("/dashboard/data")
async def get_dashboard_data(role: str = "abl"):
    """
    Returns TAS coaching profiles from S3.
    role=abl: reads from patterns_profiles/ (pre-built rich data) + memory/profile.json
    role=guest: reads from extracted_json/ (ED_RD_ABL_TAS_FCR_date)
    """
    import re
    from datetime import datetime
    from collections import defaultdict

    s3 = _get_s3_client()
    DIRECT_LOGIN_ABLS = {"Arthur Dornik", "Kylee Hay", "Lucas Russo", "Terrence Barrett"}

    # ─── For ABL role: read from patterns_profiles/ + memory/profile.json ────
    if role != "guest":
        results = []
        def _norm(name):
            return name.lower().replace(" ", "").strip()

        # Load from patterns_profiles/ (built from abl_app_fcr_extracted_json/)
        patterns_profiles = _load_patterns_profiles(s3)
        for pp in patterns_profiles:
            if pp.get("ABL_NAME") in DIRECT_LOGIN_ABLS:
                results.append(pp)

        # Merge memory/profile.json data (from live chat saves)
        profile_results = _load_profile_data(s3)
        existing_tas = {_norm(r["TAS_NAME"]): i for i, r in enumerate(results)}
        for pr in profile_results:
            if pr.get("ABL_NAME") not in DIRECT_LOGIN_ABLS:
                continue
            tas_key = _norm(pr["TAS_NAME"])
            if tas_key in existing_tas:
                existing = results[existing_tas[tas_key]]
                existing_months = set()
                for s in existing["SESSION_MEMORY"]:
                    m = s.get("month") or (s.get("DATETIME") or "")[:7]
                    if m:
                        existing_months.add(m)
                for s in pr["SESSION_MEMORY"]:
                    m = s.get("month") or (s.get("DATETIME") or "")[:7]
                    if not m or m not in existing_months:
                        existing["SESSION_MEMORY"].append(s)
                        if m:
                            existing_months.add(m)
                existing["SESSION_MEMORY"].sort(key=lambda s: s.get("DATETIME") or s.get("month") or "")
                if pr.get("Territory"):
                    existing["Territory"] = pr["Territory"]
            else:
                results.append(pr)
                existing_tas[tas_key] = len(results) - 1

        return results

    # ─── For guest role: use extracted_json/ as primary ────
    results = _load_extracted_json_data(s3, "extracted_json/", role="guest")
    results = [r for r in results if r.get("ABL_NAME") not in DIRECT_LOGIN_ABLS]

    # Merge profile.json data for richer sessions
    profile_results = _load_profile_data(s3)
    if profile_results:
        def _norm(name):
            return name.lower().replace(" ", "").strip()
        existing_tas = {_norm(r["TAS_NAME"]): i for i, r in enumerate(results)}
        for pr in profile_results:
            if pr.get("ABL_NAME") in DIRECT_LOGIN_ABLS:
                continue
            tas_key = _norm(pr["TAS_NAME"])
            if tas_key in existing_tas:
                existing = results[existing_tas[tas_key]]
                if pr.get("TAS_NAME") and " " in pr["TAS_NAME"]:
                    existing["TAS_NAME"] = pr["TAS_NAME"]
                existing_months = set()
                for s in existing["SESSION_MEMORY"]:
                    m = s.get("month") or (s.get("DATETIME") or "")[:7]
                    if m:
                        existing_months.add(m)
                for s in pr["SESSION_MEMORY"]:
                    m = s.get("month") or (s.get("DATETIME") or "")[:7]
                    if not m or m not in existing_months:
                        existing["SESSION_MEMORY"].append(s)
                        if m:
                            existing_months.add(m)
                existing["SESSION_MEMORY"].sort(key=lambda s: s.get("DATETIME") or s.get("month") or "")
            else:
                results.append(pr)

    # Mask names for guest mode
    for r in results:
        r["TAS_NAME"] = mask_name(r["TAS_NAME"])
        r["ABL_NAME"] = mask_name(r["ABL_NAME"])
        for s in r.get("SESSION_MEMORY", []):
            for key in ("Evaluation note summary", "FCR note summary"):
                if s.get(key):
                    s[key] = mask_text(s[key])

    return results


def _load_extracted_json_data(s3, prefix: str, role: str) -> List[Dict[str, Any]]:
    """Load and parse FCR data from extracted JSON files in S3."""
    import re
    from datetime import datetime
    from collections import defaultdict

    all_files = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=S3_BUCKET, Prefix=prefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(".json"):
                    all_files.append(obj["Key"])
    except Exception:
        return []

    # Group by ABL_TAS
    tas_groups: Dict[str, List] = defaultdict(list)
    for key in all_files:
        filename = key.replace(prefix, "").replace(".json", "")
        parts = filename.split("_FCR_")
        if len(parts) != 2:
            continue
        name_part = parts[0]
        date_part = parts[1].strip()
        segments = name_part.split("_")

        if role == "guest":
            if len(segments) < 4:
                continue
            abl_raw = segments[-2]
            tas_raw = segments[-1]
        else:
            if len(segments) < 2:
                continue
            abl_raw = segments[0]
            tas_raw = segments[1]

        date_clean = re.sub(r'[\s-]', '_', date_part)
        date_match = re.match(r'(\d{1,2})_(\d{1,2})_(\d{4})', date_clean)
        if not date_match:
            continue
        try:
            a, b, y = int(date_match.group(1)), int(date_match.group(2)), int(date_match.group(3))
            if a > 12:
                fcr_date = datetime(y, b, a)
            else:
                fcr_date = datetime(y, a, b) if b <= 31 else datetime(y, b, a)
        except (ValueError, TypeError):
            continue

        group_key = f"{abl_raw}_{tas_raw}"
        tas_groups[group_key].append({"key": key, "date": fcr_date, "abl": abl_raw, "tas": tas_raw})

    # Build results
    results = []
    for group_key, files in tas_groups.items():
        files.sort(key=lambda x: x["date"])
        abl_raw = files[0]["abl"]
        tas_raw = files[0]["tas"]
        abl_display = re.sub(r'([a-z])([A-Z])', r'\1 \2', abl_raw)
        tas_display = re.sub(r'([a-z])([A-Z])', r'\1 \2', tas_raw)

        session_memory = []
        for f in files:
            try:
                resp = s3.get_object(Bucket=S3_BUCKET, Key=f["key"])
                fcr = json.loads(resp["Body"].read().decode("utf-8"))
            except Exception:
                continue

            observations = fcr.get("observations", {})
            if isinstance(observations, dict):
                obs_content = observations.get("content", "")
            elif isinstance(observations, list):
                obs_content = " ".join(o.get("what_i_saw", "") for o in observations if isinstance(o, dict))
            else:
                obs_content = ""

            competencies = fcr.get("competencies", {})
            scores = competencies.get("scores", {}) if isinstance(competencies, dict) else {}
            if isinstance(competencies, list):
                scores = {}
                for c in competencies:
                    if isinstance(c, dict) and c.get("name"):
                        scores[c["name"]] = {"coachee": str(c.get("score", ""))}

            # All scored competencies count as "coached"
            coached_comps = list(scores.keys())

            # Determine strengths and areas of improvement from scores
            strengths = []
            areas_of_improvement = []

            coach_vals = []
            coachee_vals = []
            for comp, score in scores.items():
                try:
                    coach_vals.append(int(score.get("coach", "").strip()))
                except (ValueError, TypeError):
                    pass
                try:
                    coachee_vals.append(int(score.get("coachee", "").strip()))
                except (ValueError, TypeError):
                    pass

            coach_varied = len(coach_vals) > 1 and len(set(coach_vals)) > 1
            coachee_varied = len(coachee_vals) > 1 and len(set(coachee_vals)) > 1
            use_field = "coach" if coach_varied else ("coachee" if coachee_varied else None)

            if use_field:
                for comp, score in scores.items():
                    try:
                        val = int(score.get(use_field, "").strip())
                        if val >= 3:
                            strengths.append(comp)
                        else:
                            areas_of_improvement.append(comp)
                    except (ValueError, TypeError):
                        pass
            else:
                # Scores uniform — use SMART actions + observation to infer
                focus_comps = set()
                smart_actions = fcr.get("smart_action_steps", [])
                for action in smart_actions:
                    cat = action.get("category", "")
                    if "|" in cat:
                        cat = cat.split("|")[0].strip()
                    for comp in scores.keys():
                        if cat and (cat.lower() == comp.lower() or comp.lower() in cat.lower()):
                            focus_comps.add(comp)
                area_match = re.search(r"Area of Observation:\s*(\w[\w\-]*)", obs_content)
                if area_match:
                    obs_area = area_match.group(1).strip()
                    if obs_area.lower() == "closing":
                        obs_area = "Close"
                    for comp in scores.keys():
                        if obs_area.lower() == comp.lower():
                            focus_comps.add(comp)

                for comp in coached_comps:
                    if comp in focus_comps:
                        areas_of_improvement.append(comp)
                    else:
                        strengths.append(comp)

            session_memory.append({
                "DATETIME": f["date"].isoformat(),
                "Evaluation note summary": _truncate_at_sentence(obs_content, 250),
                "Evaluation note Strengths": ", ".join(strengths),
                "Evaluation note Areas of Improvement": ", ".join(areas_of_improvement),
                "SEAM note summary": "",
                "SEAM note Strengths": ", ".join(strengths),
                "SEAM note Areas of Improvement": ", ".join(areas_of_improvement),
                "FCR note summary": _truncate_at_sentence(obs_content, 150),
                "FCR note Strengths": ", ".join(strengths),
                "FCR note Areas of Improvement": ", ".join(areas_of_improvement),
                "Areas coached": "|".join(coached_comps),
                "Key Coaching Topics": coached_comps[:3],
            })

        if session_memory:
            results.append({
                "TAS_NAME": tas_display,
                "ABL_NAME": abl_display,
                "Territory": "",
                "Therapy_Area": "",
                "SESSION_MEMORY": session_memory,
            })

    return results


def _load_patterns_profiles(s3) -> List[Dict[str, Any]]:
    """Load all patterns_profiles/{TAS_NAME}.json files — pre-built from abl_app_fcr_extracted_json/."""
    results = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=S3_BUCKET, Prefix="patterns_profiles/"):
            for obj in page.get("Contents", []):
                if not obj["Key"].endswith(".json"):
                    continue
                try:
                    resp = s3.get_object(Bucket=S3_BUCKET, Key=obj["Key"])
                    profile = json.loads(resp["Body"].read().decode("utf-8"))
                    if profile.get("SESSION_MEMORY"):
                        results.append({
                            "TAS_NAME": profile.get("TAS_NAME", ""),
                            "ABL_NAME": profile.get("ABL_NAME", ""),
                            "Territory": profile.get("Territory", ""),
                            "Therapy_Area": profile.get("Therapy_Area", ""),
                            "SESSION_MEMORY": profile["SESSION_MEMORY"],
                        })
                except Exception:
                    continue
    except Exception:
        pass
    return results


def _load_profile_data(s3) -> List[Dict[str, Any]]:
    """Load all memory/{tas_id}/profile.json files — rich data from Pattern Mining."""
    results = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=S3_BUCKET, Prefix=f"{MEMORY_PREFIX}/", Delimiter="/"):
            for prefix in page.get("CommonPrefixes", []):
                tas_folder = prefix["Prefix"]  # e.g. "memory/Brigid Kettenburg/"
                profile_key = f"{tas_folder}profile.json"
                try:
                    resp = s3.get_object(Bucket=S3_BUCKET, Key=profile_key)
                    profile = json.loads(resp["Body"].read().decode("utf-8"))
                    if profile.get("SESSION_MEMORY"):
                        results.append({
                            "TAS_NAME": profile.get("TAS_NAME", ""),
                            "ABL_NAME": profile.get("ABL_NAME", ""),
                            "Territory": profile.get("Territory", ""),
                            "Therapy_Area": profile.get("Therapy_Area", ""),
                            "SESSION_MEMORY": profile["SESSION_MEMORY"],
                        })
                except Exception:
                    continue
    except Exception:
        pass
    return results


# ─── Parameterized endpoints ─────────────────────────────────────────────────


@router.get("/{tas_id}")
async def get_coaching_profile(tas_id: str):
    """Full TAS coaching profile — supports the coaching pattern dashboard."""
    index = _load_index(tas_id)
    if not index:
        raise HTTPException(status_code=404, detail=f"No coaching data found for TAS: {tas_id}")

    latest_patterns = None
    if index.get("fcr_history"):
        latest_month = index["fcr_history"][-1].get("month")
        if latest_month:
            latest_patterns = _load_pattern(tas_id, latest_month)

    return {
        "tas_id": tas_id,
        "total_fcrs": index.get("total_fcrs", 0),
        "last_updated": index.get("last_updated"),
        "coaching_status": _derive_coaching_status(index),
        "recurring_strengths": index.get("recurring_strengths", {}),
        "recurring_development_areas": {k: v for k, v in index.get("recurring_development_areas", {}).items() if k not in index.get("recurring_strengths", {})},
        "next_coaching_focus": index.get("next_coaching_focus", {}),
        "latest_summary": _get_latest_summary(index),
        "latest_patterns": latest_patterns,
        "progress_history": index.get("progress_history", []),
        "coaching_theme_history": index.get("coaching_theme_history", {}),
    }


@router.get("/{tas_id}/summary")
async def get_coaching_summary(tas_id: str):
    """AI coaching summary for TAS."""
    index = _load_index(tas_id)
    if not index:
        raise HTTPException(status_code=404, detail=f"No coaching data found for TAS: {tas_id}")

    strengths = index.get("recurring_strengths", {})
    dev_areas = {k: v for k, v in index.get("recurring_development_areas", {}).items() if k not in strengths}

    return {
        "tas_id": tas_id,
        "total_fcrs": index.get("total_fcrs", 0),
        "coaching_status": _derive_coaching_status(index),
        "latest_summary": _get_latest_summary(index),
        "next_coaching_focus": index.get("next_coaching_focus", {}),
        "top_strength": _get_top_item(strengths),
        "top_development_area": _get_top_item(dev_areas),
    }


@router.get("/{tas_id}/timeline")
async def get_coaching_timeline(tas_id: str, months: int = 6):
    """Month-by-month coaching journey."""
    index = _load_index(tas_id)
    if not index:
        raise HTTPException(status_code=404, detail=f"No coaching data found for TAS: {tas_id}")

    fcr_history = index.get("fcr_history", [])[-months:]
    timeline = []

    for entry in fcr_history:
        month = entry.get("month")
        patterns = _load_pattern(tas_id, month)

        month_data = {"month": month, "created_at": entry.get("created_at")}

        if patterns:
            month_data["strengths"] = [s.get("area", "") for s in patterns.get("strengths", []) if isinstance(s, dict)]
            month_data["development_areas"] = [d.get("area", "") for d in patterns.get("development_areas", []) if isinstance(d, dict)]
            month_data["coaching_focus"] = patterns.get("next_coaching_focus", {}).get("primary", "")
            month_data["overall_trend"] = patterns.get("progress_vs_past", {}).get("overall_trend", "unknown")
            month_data["summary"] = patterns.get("ai_coaching_summary", "")
        else:
            month_data["strengths"] = []
            month_data["development_areas"] = []
            month_data["coaching_focus"] = ""
            month_data["overall_trend"] = "unknown"
            month_data["summary"] = ""

        timeline.append(month_data)

    return {"tas_id": tas_id, "timeline": timeline}


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _derive_coaching_status(index: Dict[str, Any]) -> str:
    progress = index.get("progress_history", [])
    if not progress:
        return "baseline"
    return progress[-1].get("overall_trend", "unknown")


def _get_latest_summary(index: Dict[str, Any]) -> str:
    summaries = index.get("coaching_summaries", [])
    if summaries:
        return summaries[-1].get("summary", "")
    return ""


def _get_top_item(freq_dict: Dict[str, int]) -> str:
    if not freq_dict:
        return ""
    return max(freq_dict, key=freq_dict.get)
