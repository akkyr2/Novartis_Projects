from fastapi import APIRouter

router = APIRouter()

from . import sessions, fcr, patterns

router.include_router(sessions.router, prefix="/sessions", tags=["sessions"])
router.include_router(fcr.router, prefix="/fcr", tags=["fcr"])
router.include_router(patterns.router, prefix="/patterns", tags=["patterns"])