import json
import threading
import uuid
from fastapi import APIRouter
from fastapi.responses import Response
from pydantic import BaseModel
from typing import Dict, Any, List, Optional

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from app.src.graph.chat_workflow import intake_chat_graph, _build_kpi_flash_cards
from app.src.services.fcr_pdf_service import build_fields_from_draft, render_coaching_report_pdf
from app.src.graph.intent_classifier import is_skip, classify_intent
from app.src.services.name_masking import mask_text


router = APIRouter()

# In-memory store for background tasks
_tasks: Dict[str, Dict[str, Any]] = {}


class ChatRequest(BaseModel):
    session_id: str
    message: str
    coaching_level: Optional[int] = 5
    abl_name: Optional[str] = None
    role: Optional[str] = None
    edited_fcr_fields: Optional[dict] = None  # user-edited structured FCR fields (sent with Save)
    edited_goal: Optional[dict] = None  # #11: {index, fields} — edited SMART goal from popup


class ChatResponse(BaseModel):
    session_id: str
    reply: str
    intake_complete: bool
    current_field: Optional[str] = None
    collected_details: Dict[str, Any]
    fcr_result: Optional[Dict[str, Any]] = None
    messages: List[Dict[str, Any]]
    task_id: Optional[str] = None
    processing: bool = False
    intake_stage: Optional[str] = ""


class TaskStatusResponse(BaseModel):
    task_id: str
    status: str  # "processing" | "done" | "error" | "not_found"
    progress: Optional[str] = None
    result: Optional[ChatResponse] = None


def serialize_message(message) -> Dict[str, Any]:
    if isinstance(message, HumanMessage):
        role = "user"
    elif isinstance(message, AIMessage):
        role = "assistant"
    elif isinstance(message, SystemMessage):
        role = "system"
    else:
        role = "unknown"
    return {"role": role, "content": message.content}


def get_last_ai_message(messages) -> str:
    for message in reversed(messages):
        if isinstance(message, AIMessage):
            return message.content
    return ""


def _build_response(result, session_id, role=None) -> ChatResponse:
    """Build ChatResponse from graph result."""
    messages = result.get("messages", [])
    reply = get_last_ai_message(messages)
    collected_details = {
        "tas_id": result.get("tas_id"),
        "month": result.get("month"),
        "tas_prework_text": result.get("tas_prework_text"),
        "abl_eval_text": result.get("abl_eval_text"),
        "selected_competencies": result.get("selected_competencies", []),
    }
    fcr_result = result.get("fcr_result")
    serialized_msgs = [serialize_message(m) for m in messages]

    # Mask all names for guest mode
    if role == "guest":
        reply = mask_text(reply)
        if collected_details.get("tas_id"):
            collected_details["tas_id"] = mask_text(str(collected_details["tas_id"]))
        if fcr_result:
            fcr_result = json.loads(mask_text(json.dumps(fcr_result, default=str)))
        serialized_msgs = [{"role": m["role"], "content": mask_text(m["content"])} for m in serialized_msgs]

    return ChatResponse(
        session_id=session_id,
        reply=reply,
        intake_complete=result.get("intake_complete", False),
        current_field=result.get("current_field"),
        collected_details=collected_details,
        fcr_result=fcr_result,
        messages=serialized_msgs,
        intake_stage=result.get("intake_stage", ""),
    )


def _run_graph_in_background(task_id: str, session_id: str, message: str, coaching_level: int = 5, abl_name: str = None, role: str = None, edited_fcr_fields: dict = None, edited_goal: dict = None):
    """Run the graph invoke in a background thread with progress tracking."""
    import builtins
    _original_print = builtins.print

    # Intercept print statements from nodes to extract progress
    def _tracking_print(*args, **kwargs):
        text = " ".join(str(a) for a in args)
        if "KPI Analysis" in text and "failed" not in text:
            _tasks[task_id]["progress"] = "📊 Analyzing territory KPI data..."
        elif "Retrieval" in text and "failed" not in text:
            _tasks[task_id]["progress"] = "📂 Retrieving past coaching reports & guidelines..."
        elif "Drafting FCR" in text or "Drafting Field" in text:
            _tasks[task_id]["progress"] = "✍️ Drafting Field Coaching Report..."
        elif "Drafting Evaluation" in text:
            _tasks[task_id]["progress"] = "📝 Generating Draft..."
        elif "Evaluation Coaching Planner" in text:
            _tasks[task_id]["progress"] = "🧠 Planning coaching questions..."
        elif "PatternMining" in text or "Mining coaching" in text:
            _tasks[task_id]["progress"] = "🎯 Mining coaching patterns..."
        elif "Rubric" in text or "rubric" in text:
            _tasks[task_id]["progress"] = "✅ Running quality check..."
        elif "Question Planner" in text:
            _tasks[task_id]["progress"] = "🔍 Planning coaching questions..."
        elif "Router check" in text:
            pass  # Don't update progress for router checks
        _original_print(*args, **kwargs)

    try:
        builtins.print = _tracking_print
        config = {"configurable": {"thread_id": session_id}}
        invoke_input = {"session_id": session_id, "messages": [HumanMessage(content=message)], "max_questions": coaching_level}
        if abl_name and abl_name not in ("Guest", "guest"):
            invoke_input["abl_id"] = abl_name
        if role:
            invoke_input["role"] = role
        if edited_fcr_fields:
            invoke_input["edited_fcr_fields"] = edited_fcr_fields
        if edited_goal:
            invoke_input["edited_goal"] = edited_goal
        result = intake_chat_graph.invoke(invoke_input, config=config)
        _tasks[task_id] = {"status": "done", "result": _build_response(result, session_id, role)}
    except Exception as e:
        import traceback
        _original_print(f"❌ Background task error: {e}")
        traceback.print_exc()
        _tasks[task_id] = {"status": "error", "result": ChatResponse(
            session_id=session_id,
            reply=f"Error: {str(e)}",
            intake_complete=False,
            collected_details={},
            messages=[],
        )}
    finally:
        builtins.print = _original_print


def _will_trigger_fcr(session_id: str, message: str) -> bool:
    """Check if this message will trigger a long-running generation."""
    config = {"configurable": {"thread_id": session_id}}
    try:
        snapshot = intake_chat_graph.get_state(config)
        state = snapshot.values if snapshot else {}

        # #14: while in field-ride prep mode, a TAS selection triggers LLM briefing generation.
        if state and state.get("field_ride_mode") and state.get("field_ride_stage") == "awaiting_tas":
            return True  # generating the Field Ride Note is LLM-based (long-running)

        # New session or no intake started yet — never triggers FCR
        if not state or not state.get("tas_id"):
            return False

        # FCR triggers when intake is about to complete (this is the competencies message)
        # and fcr_result doesn't exist yet
        if state.get("fcr_result"):
            # Already have FCR - check if this is feedback that triggers revise
            if state.get("awaiting_feedback"):
                return True  # Revise also takes time
            return False

        # Evaluation note generation (direct or after questions)
        eval_stage = state.get("eval_coaching_stage", "")
        if eval_stage == "flow_selection":
            # "Generate Draft Now" triggers eval draft generation
            intent = classify_intent(message, {
                "generate_now": "User wants to generate the draft directly from notes, without questions",
                "ask_questions": "User wants to be asked coaching questions first before generating",
            }, context="User was asked: Ask Coaching Questions First OR Generate Draft Now")
            if intent == "generate_now":
                return True

        # Last eval coaching question answer triggers eval draft generation
        if eval_stage == "coaching":
            max_q = int(state.get("max_questions", 5))
            asked_count = len(state.get("eval_questions_asked", []))
            # eval_questions_asked includes all questions ASKED so far (including the one
            # the user is now answering). The planner will check eval_question_count >= max_q.
            # So if asked_count >= max_q, this answer will be the last → triggers eval draft.
            if asked_count >= max_q:
                return True

        # Deep dive "Skip to Draft" triggers long-running draft generation
        # "Include KPI Analysis" also triggers long-running (KPI + retrieval + questions + draft)
        if state.get("intake_stage") == "awaiting_deep_dive":
            return True  # Both paths are long-running

        # Last KPI question answer triggers FCR draft generation
        if state.get("intake_stage") in ("waiting_for_answer", "waiting_for_first_answer"):
            max_q = int(state.get("max_questions", 5))
            asked_count = int(state.get("asked_question_count", 0))
            if asked_count >= max_q:
                return True  # This answer will trigger draft generation

        # Check if all fields except competencies are filled
        if (state.get("tas_id") and state.get("month") and
            state.get("tas_prework_text") and state.get("abl_eval_text") and
            not state.get("selected_competencies")):
            return True  # This message is the competencies → will trigger FCR

        return False
    except Exception as e:
        print(f"⚠️ Error checking if will trigger FCR: {e}")
        return False


@router.post("/")
def chat(req: ChatRequest) -> ChatResponse:
    """
    Main chat endpoint with background task support for long-running operations.
    """
    # Check if this request will trigger a long-running operation
    if _will_trigger_fcr(req.session_id, req.message):
        task_id = str(uuid.uuid4())[:8]
        _tasks[task_id] = {"status": "processing"}

        # Read state BEFORE starting background thread to avoid race condition
        config = {"configurable": {"thread_id": req.session_id}}
        snapshot = intake_chat_graph.get_state(config)
        state = snapshot.values if snapshot else {}

        thread = threading.Thread(
            target=_run_graph_in_background,
            args=(task_id, req.session_id, req.message, req.coaching_level, req.abl_name, req.role, req.edited_fcr_fields, req.edited_goal),
            daemon=True,
        )
        thread.start()

        # Context-aware processing message
        eval_stage = state.get("eval_coaching_stage", "")
        if state.get("field_ride_mode") and state.get("field_ride_stage") == "awaiting_tas":
            processing_msg = "🚗 Preparing your Field Ride briefing... Please wait."
        elif eval_stage == "flow_selection" or eval_stage == "drafting":
            processing_msg = "⏳ Generating Draft... Please wait."
        elif eval_stage == "coaching":
            processing_msg = "⏳ Thanks for your answers! Generating Draft... Please wait."
        elif state.get("intake_stage") == "awaiting_deep_dive":
            lower_msg = req.message.lower().strip()
            is_skip_choice = any(k in lower_msg for k in ["skip to draft", "skip", "observations only"])
            if is_skip_choice:
                processing_msg = "⏳ Generating FCR draft from observations... Please wait."
            else:
                processing_msg = "⏳ Analyzing KPIs and preparing coaching questions... Please wait."
        elif state.get("intake_stage") in ("waiting_for_answer", "waiting_for_first_answer"):
            processing_msg = "⏳ Thanks for your insights! Generating FCR draft... Please wait."
        else:
            processing_msg = "⏳ Generating FCR draft... This may take a minute. Please wait."

        # Add KPI flash cards to processing message if available
        kpi = state.get("kpi_analysis", {})
        kpi_analysis_data = kpi.get("analysis", {})
        kpi_territory = kpi.get("territory", "")
        if kpi_analysis_data and state.get("intake_stage") in ("waiting_for_answer", "waiting_for_first_answer", "generating_draft"):
            flash_cards = _build_kpi_flash_cards(kpi_analysis_data, kpi_territory)
            if flash_cards:
                processing_msg += f"\n\n📊 **Territory Performance Snapshot** — {kpi_territory}\n\n{flash_cards}"

        return ChatResponse(
            session_id=req.session_id,
            reply=processing_msg,
            intake_complete=False,
            collected_details={},
            messages=[],
            task_id=task_id,
            processing=True,
        )

    # Normal fast path — run synchronously
    config = {"configurable": {"thread_id": req.session_id}}
    try:
        invoke_input = {"session_id": req.session_id, "messages": [HumanMessage(content=req.message)], "max_questions": req.coaching_level}
        if req.abl_name and req.abl_name not in ("Guest", "guest"):
            invoke_input["abl_id"] = req.abl_name
        if req.role:
            invoke_input["role"] = req.role
        if req.edited_fcr_fields:
            invoke_input["edited_fcr_fields"] = req.edited_fcr_fields
        if req.edited_goal:
            invoke_input["edited_goal"] = req.edited_goal
        result = intake_chat_graph.invoke(invoke_input, config=config)
    except Exception as exc:
        import traceback
        print(f"❌ Chat endpoint error: {exc}")
        traceback.print_exc()
        raise

    return _build_response(result, req.session_id, req.role)


@router.get("/status/{task_id}")
def get_task_status(task_id: str) -> TaskStatusResponse:
    """
    Get the status of a background task.

    Returns:
        - processing: Task is still running
        - done: Task completed successfully
        - error: Task failed with error
        - not_found: Task ID doesn't exist
    """
    task = _tasks.get(task_id)
    if not task:
        return TaskStatusResponse(task_id=task_id, status="not_found")
    if task["status"] == "processing":
        return TaskStatusResponse(task_id=task_id, status="processing", progress=task.get("progress"))
    # Task complete — return result and clean up
    result = TaskStatusResponse(task_id=task_id, status=task["status"], result=task.get("result"))
    _tasks.pop(task_id, None)
    return result




# ─── Editable FCR (structured form) — powers the edit popup ──────────────────

def _get_session_draft(session_id: str) -> Dict[str, Any]:
    """Fetch the current graph state for a session and return its FCR draft + identity."""
    config = {"configurable": {"thread_id": session_id}}
    try:
        snapshot = intake_chat_graph.get_state(config)
        state = snapshot.values if snapshot else {}
    except Exception:
        state = {}
    fcr_result = state.get("fcr_result", {}) or {}
    draft = fcr_result.get("draft", {}) or state.get("draft", {}) or {}
    return {
        "draft": draft,
        "tas_id": state.get("tas_id", ""),
        "abl_id": state.get("abl_id", ""),
        "month": state.get("month", ""),
    }


@router.get("/fcr_fields/{session_id}")
def get_fcr_fields(session_id: str):
    """Return the editable Coaching Report fields for the popup form."""
    info = _get_session_draft(session_id)
    fields = build_fields_from_draft(
        info["draft"], tas_name=info["tas_id"], abl_name=info["abl_id"], month=info["month"]
    )
    return {"fields": fields}


class FcrFieldsBody(BaseModel):
    fields: Dict[str, Any]


@router.post("/fcr_pdf")
def render_fcr_pdf(body: FcrFieldsBody):
    """Render the Coaching Report PDF from posted (edited) fields — for preview/download."""
    pdf_bytes = render_coaching_report_pdf(body.fields)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": "inline; filename=coaching_report.pdf"},
    )


# ─── #11: Editable SMART Goal (evaluation note) — powers the goal edit popup ──
@router.get("/goal_fields/{session_id}/{goal_index}")
def get_goal_fields(session_id: str, goal_index: int):
    """Return the editable fields for a single SMART Goal from the evaluation note."""
    config = {"configurable": {"thread_id": session_id}}
    try:
        snapshot = intake_chat_graph.get_state(config)
        state = snapshot.values if snapshot else {}
    except Exception:
        state = {}
    eval_draft = state.get("evaluation_draft", {}) or {}
    goals = eval_draft.get("how_to_improve", []) or []
    if 0 <= goal_index < len(goals):
        g = goals[goal_index]
        fields = {
            "goal_headline": g.get("goal_headline", ""),
            "specific": g.get("specific", ""),
            "measurable": g.get("measurable", ""),
            "achievable": g.get("achievable", ""),
            "relevant": g.get("relevant", ""),
            "time_bound": g.get("time_bound", ""),
            "impact": g.get("impact", ""),
        }
        return {"index": goal_index, "fields": fields}
    return {"index": goal_index, "fields": None}
