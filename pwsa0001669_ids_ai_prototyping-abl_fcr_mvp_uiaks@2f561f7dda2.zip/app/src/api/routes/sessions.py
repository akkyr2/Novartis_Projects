from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional

router = APIRouter()

class SessionCreate(BaseModel):
    tas_id: str
    month: str

class SessionResponse(BaseModel):
    session_id: str
    tas_id: str
    month: str

sessions = {}

@router.post("/session", response_model=SessionResponse)
async def create_session(session: SessionCreate):
    session_id = f"{session.tas_id}-{session.month}"
    if session_id in sessions:
        raise HTTPException(status_code=400, detail="Session already exists")
    
    sessions[session_id] = session
    return SessionResponse(session_id=session_id, tas_id=session.tas_id, month=session.month)

@router.get("/session/{session_id}", response_model=SessionResponse)
async def get_session(session_id: str):
    session = sessions.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return SessionResponse(session_id=session_id, tas_id=session.tas_id, month=session.month)