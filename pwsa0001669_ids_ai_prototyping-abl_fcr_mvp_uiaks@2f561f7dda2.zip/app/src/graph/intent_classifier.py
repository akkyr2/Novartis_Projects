"""Lightweight LLM-based intent classifier for conversational decision points."""

from app.src.llm.bedrock_client import BedrockClient

_client = None

def _get_client():
    global _client
    if _client is None:
        _client = BedrockClient()
    return _client


def classify_intent(user_message: str, intents: dict, context: str = "") -> str:
    """
    Classify user message into one of the given intents using LLM.
    
    Args:
        user_message: What the user said
        intents: Dict mapping intent_name -> description
            e.g. {"skip": "User wants to skip this step", "continue": "User wants to proceed with questions"}
        context: Optional context about what was just asked
    
    Returns:
        The intent_name that best matches, or "unknown" if unclear.
    """
    intent_list = "\n".join([f"- {name}: {desc}" for name, desc in intents.items()])
    
    prompt = f"""You are classifying user intent in a coaching conversation.

Context: {context}

The user said: "{user_message}"

Classify into exactly ONE of these intents:
{intent_list}
- unknown: The message doesn't clearly match any intent above

Reply with ONLY the intent name (single word, no explanation)."""

    try:
        result = _get_client().invoke_claude(prompt, max_tokens=20, temperature=0.0)
        intent = result.strip().lower().replace('"', '').replace("'", "")
        # Validate it's one of our intents
        if intent in intents or intent == "unknown":
            return intent
        # Fuzzy match
        for key in intents:
            if key in intent:
                return key
        return "unknown"
    except Exception as e:
        print(f"[IntentClassifier] Failed: {e}, falling back to unknown")
        return "unknown"


def is_affirmative(user_message: str, context: str = "") -> bool:
    """Check if user message means yes/agree/confirm."""
    result = classify_intent(user_message, {
        "yes": "User agrees, confirms, approves, or wants to proceed",
        "no": "User disagrees, declines, rejects, or wants changes",
    }, context)
    return result == "yes"


def is_skip(user_message: str, context: str = "") -> bool:
    """Check if user message means skip/bypass/move on."""
    result = classify_intent(user_message, {
        "skip": "User wants to skip this step, bypass it, move on, go directly to next step",
        "continue": "User wants to engage with this step, answer questions, do the deep dive",
    }, context)
    return result == "skip"
