from typing import Annotated, TypedDict, Optional, List, Dict, Any
import re

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

from app.src.graph.nodes.kpi_analysis_node import KPIAnalysisNode
from app.src.graph.nodes.retrieval_node import retrieval_node
from app.src.graph.nodes.answer_ingest_node import answer_ingest_node
from app.src.graph.nodes.question_planner_node import question_planner_node
from app.src.graph.nodes.evaluation_coaching_node import evaluation_coaching_node
from app.src.graph.nodes.evaluation_answer_ingest_node import evaluation_answer_ingest_node
from app.src.graph.nodes.evaluation_draft_node import evaluation_draft_node
from app.src.graph.batch_workflow import draft_fcr_node
from app.src.graph.intent_classifier import classify_intent, is_affirmative, is_skip


class IntakeChatState(TypedDict, total=False):
    session_id: str
    max_questions: int
    role: Optional[str]

    tas_id: Optional[str]
    tas_name: Optional[str]
    abl_id: Optional[str]
    month: Optional[str]
    territory: Optional[str]
    tas_prework_text: Optional[str]
    abl_eval_text: Optional[str]
    selected_competencies: List[str]

    current_field: Optional[str]
    intake: Dict[str, Any]
    intake_complete: bool

    # SEAM generation flow
    seam_generated: bool  # True once SEAM is created/found
    seam_show_pending: bool  # True when waiting for user yes/no to view SEAM
    _seam_text_pending: Optional[str]  # Holds generated SEAM text until confirmed

    # Evaluation coaching flow (Phase 1: Field Day Evaluation)
    eval_coaching_stage: str  # "not_started", "coaching", "drafting", "awaiting_confirmation", "confirmed"
    eval_questions_asked: List[str]
    eval_question_count: int
    next_eval_question: Optional[Dict[str, Any]]
    last_eval_question: Optional[Dict[str, Any]]
    eval_answers: Dict[str, Any]
    evaluation_draft: Optional[Dict[str, Any]]
    evaluation_full_text: Optional[str]
    evaluation_confirmed: bool
    direct_eval_flow: bool
    
    # Question flow (Phase 2: KPI/FCR Questions)
    intake_stage: str  # "intake", "eval_coaching", "analyzing", "asking_questions", "generating_draft", "complete"
    questions_needed: List[Dict[str, Any]]
    current_question_index: int
    user_answers: Dict[str, str]
    gap_analysis: Dict[str, Any]

    asked_question_ids: List[str]
    asked_question_count: int
    next_question: Optional[Dict[str, Any]]
    last_asked_question: Optional[Dict[str, Any]]
    last_user_answer: Optional[str]

    # Retrieval and analysis
    kpi_analysis: Dict[str, Any]
    context_bundle: Dict[str, Any]

    # Pattern mining and memory
    pattern_mining: Dict[str, Any]
    memory_update: Dict[str, Any]

    # Enriched from answers
    observation_notes: Optional[str]
    observed_strengths: Optional[str]
    development_opportunities: Optional[str]
    impact_statement: Optional[str]
    action_items: Optional[str]
    seam_notes: Optional[str]
    developmental_context: Optional[str]

    # Final output
    draft: Optional[Dict[str, Any]]
    fcr_result: Dict[str, Any]
    awaiting_feedback: bool
    awaiting_revision_confirm: bool
    awaiting_memory_save: bool
    awaiting_new_session: bool
    user_feedback: Optional[str]
    edited_fcr_fields: Optional[dict]  # user-edited structured FCR fields carried into memory save
    edited_goal: Optional[dict]  # #11: {index, fields} — user-edited SMART goal from the popup
    # #4 Historical Context
    prior_action_plan: Optional[dict]      # the TAS's previous plan (desc/due/status/month)
    awaiting_history_choice: Optional[bool]  # waiting for Continue/Review/Start New
    history_choice_made: Optional[bool]      # a choice was already made this session
    continue_prior_plan: Optional[bool]      # user chose to continue the prior plan
    # #14 Field Ride Prep
    field_ride_mode: Optional[bool]          # in the field-ride prep flow
    field_ride_stage: Optional[str]          # "awaiting_abl" | "awaiting_tas"
    field_ride_note: Optional[str]           # generated briefing text
    rubric_issues: List[Any]

    messages: Annotated[list[BaseMessage], add_messages]





def get_last_user_message(messages: list[BaseMessage]) -> str:
    for message in reversed(messages):
        if isinstance(message, HumanMessage):
            return message.content.strip()

    return ""


def parse_competencies(text: str) -> List[str]:
    items = []

    for item in text.replace("\n", ",").split(","):
        cleaned = item.strip()

        if cleaned:
            items.append(cleaned)

    return items


# --- #14 Field Ride helper ---
def _frp_retext(picker_msg: str, new_question: str) -> str:
    """Replace the generic FCR picker question with field-ride-specific wording, keeping the
    clickable [[action:...]] options intact. The picker functions format as
    '<question>\n\n<options>' — we swap only the question part."""
    if "\n\n" in picker_msg:
        _q, options = picker_msg.split("\n\n", 1)
        return new_question + "\n\n" + options
    return new_question + "\n\n" + picker_msg


# --- #4 Historical Context helpers ---
FIELD_QUESTIONS_MONTH = "What month is this FCR for? (e.g., 2026-04)"


def _format_history_review(tas_name: str, prior: Dict[str, Any]) -> str:
    """Build the 'Review Progress' message for a TAS's prior plan."""
    desc = prior.get("description", "N/A")
    due = prior.get("due_date", "N/A")
    status = prior.get("status", "Pending")
    month = prior.get("month", "")
    txt = f"🔍 **Progress review for {tas_name}**\n\n"
    if month:
        txt += f"From: {month}\n\n"
    txt += f"**Previous Goal:** _{desc}_\n\nDue: {due}  ·  Status: **{status}**\n\n"
    txt += "---\n\nReady to continue?\n\n[[action:Continue Previous Plan]] [[action:Start New]]"
    return txt


def intake_chat_node(state: IntakeChatState) -> Dict[str, Any]:
    """Dispatcher — routes to the appropriate handler node based on current stage."""
    from app.src.graph.nodes.post_fcr_node import post_fcr_node
    from app.src.graph.nodes.competency_node import competency_node
    from app.src.graph.nodes.field_collection_node import field_collection_node

    messages = state.get("messages", [])
    last_user_message = get_last_user_message(messages)

    eval_stage = state.get("eval_coaching_stage", "")
    intake_stage = state.get("intake_stage", "")

    # 0. #14 FIELD RIDE PREP
    # Entry: user clicks "Help Me Prepare for the Field Ride" -> show TAS picker.
    lower_frp = last_user_message.lower().strip()
    if lower_frp in ["help me prepare for the field ride", "prepare for the field ride", "field ride prep"]:
        from app.src.graph.nodes.field_collection_node import _get_tas_options, _load_mapping
        role = state.get("role")
        abl_id = state.get("abl_id")
        # Field-ride-specific wording (do NOT reuse the FCR "coach today" text).
        if abl_id:
            picker = _frp_retext(_get_tas_options(abl_id, role=role),
                                 "Which TAS are you riding with? Select to see their prep briefing.")
        else:
            from app.src.graph.nodes.field_collection_node import _get_abl_options
            picker = _frp_retext(_get_abl_options(role=role),
                                 "First, which ABL's team?")
        return {
            "field_ride_mode": True,
            "field_ride_stage": "awaiting_tas" if abl_id else "awaiting_abl",
            "messages": [AIMessage(content="🚗 **Field Ride Prep** — let's get you ready.\n\n" + picker)],
        }

    # If in field ride prep mode, capture ABL/TAS selection then generate the briefing.
    if state.get("field_ride_mode"):
        from app.src.graph.nodes.field_collection_node import _get_tas_options, _load_mapping
        role = state.get("role")
        stage = state.get("field_ride_stage", "awaiting_tas")

        if stage == "awaiting_abl":
            # User just picked an ABL -> resolve and show that ABL's TAS list.
            df = _load_mapping()
            abl_match = None
            for abl in df["ABL"].unique().tolist():
                if last_user_message.strip().lower() in abl.lower() or abl.lower() in last_user_message.strip().lower():
                    abl_match = abl
                    break
            abl_match = abl_match or last_user_message.strip()
            return {
                "field_ride_mode": True,
                "field_ride_stage": "awaiting_tas",
                "abl_id": abl_match,
                "messages": [AIMessage(content=_frp_retext(_get_tas_options(abl_match, role=role),
                                       "Which TAS are you riding with? Select to see their prep briefing."))],
            }

        # awaiting_tas: user picked a TAS -> resolve name, run the prep node.
        from app.src.services.name_masking import unmask_name, mask_name
        df = _load_mapping()
        tas_names = df["TAS Name"].tolist()
        input_name = unmask_name(last_user_message.strip())
        matched = None
        for tas in tas_names:
            if input_name.lower() in tas.lower() or tas.lower() in input_name.lower():
                matched = tas
                break
        tas_id = matched or last_user_message.strip()
        tas_name = mask_name(tas_id) if role == "guest" else tas_id

        from app.src.graph.nodes.field_ride_prep_node import field_ride_prep_node
        prep_state = {**dict(state), "tas_id": tas_id, "tas_name": tas_name}
        result = field_ride_prep_node(prep_state)
        reply = result.get("messages_reply") or "⚠️ Could not generate the Field Ride Prep. Please try again."
        # Clear field-ride mode so the next action (e.g. Draft an FCR) flows normally.
        return {
            "field_ride_mode": False,
            "field_ride_stage": None,
            "messages": [AIMessage(content=reply)],
        }

    # 1. DEEP DIVE HANDLER (inline — only ~20 lines)
    if intake_stage == "awaiting_deep_dive":
        lower = last_user_message.lower().strip()
        is_skip_choice = any(k in lower for k in ["skip to draft", "skip", "observations only", "no kpi", "no questions"])
        is_include_choice = any(k in lower for k in ["let's discuss", "discuss kpi", "kpi performance", "include kpi", "kpi analysis", "include", "yes", "data-driven", "add kpi"])

        if is_skip_choice and not is_include_choice:
            return {
                "intake_stage": "analyzing",
                "direct_eval_flow": True,
                "intake_complete": True,
            }
        else:
            return {
                "intake_stage": "analyzing",
                "direct_eval_flow": False,
                "intake_complete": True,
            }


    # 1b. #4 HISTORICAL CONTEXT CHOICE HANDLER
    # After a TAS with prior coaching is selected, handle Continue / Review / Start New.
    if state.get("awaiting_history_choice"):
        lower = last_user_message.lower().strip()
        prior = state.get("prior_action_plan", {}) or {}
        if "review" in lower:
            # Show progress against the prior plan, then offer Continue / Start New again.
            summary = _format_history_review(state.get("tas_name", "this TAS"), prior)
            return {
                "awaiting_history_choice": True,
                "messages": [AIMessage(content=summary)],
            }
        if "continue" in lower:
            # Carry the prior plan forward; it becomes previous_smart_action in the FCR.
            return {
                "awaiting_history_choice": False,
                "history_choice_made": True,
                "continue_prior_plan": True,
                "current_field": "month",
                "intake_complete": False,
                "intake_stage": "intake",
                "messages": [AIMessage(content="Got it — carrying forward the previous plan. " + FIELD_QUESTIONS_MONTH)],
            }
        if "start new" in lower or "new" in lower:
            return {
                "awaiting_history_choice": False,
                "history_choice_made": True,
                "continue_prior_plan": False,
                "current_field": "month",
                "intake_complete": False,
                "intake_stage": "intake",
                "messages": [AIMessage(content="Starting a fresh coaching session. " + FIELD_QUESTIONS_MONTH)],
            }
        # Unrecognized — re-show the choice.
        return {
            "awaiting_history_choice": True,
            "messages": [AIMessage(content="Please choose:\n\n[[action:Continue Previous Plan]] [[action:Review Progress]] [[action:Start New]]")],
        }

    # 2. POST-FCR HANDLER
    if state.get("fcr_result") and state.get("fcr_result", {}).get("draft"):
        return post_fcr_node(state)

    # 3. EVAL COACHING PASSTHROUGH
    if eval_stage in ["coaching", "drafting", "awaiting_confirmation"]:
        return {"intake_complete": True}

    # 4. FLOW SELECTION
    if eval_stage == "flow_selection" and state.get("intake_complete"):
        return competency_node(state)

    # 5. COMPETENCY MODIFICATION
    if eval_stage == "not_started" and state.get("intake_complete"):
        return competency_node(state)

    # 6. QUESTION FLOW PASSTHROUGH
    if intake_stage in ["waiting_for_first_answer", "waiting_for_answer", "asking_questions"]:
        return {"intake_complete": True}

    # 7. FIELD COLLECTION (default)
    return field_collection_node(state)



def should_proceed_to_analysis(state: IntakeChatState) -> str:
    """Route after intake based on stage."""
    intake_complete = state.get("intake_complete", False)
    intake_stage = state.get("intake_stage", "N/A")
    eval_stage = state.get("eval_coaching_stage", "not_started")

    print(f"🔍 Router check: intake_complete={intake_complete}, stage={intake_stage}, eval_stage={eval_stage}")

    # Route to evaluation coaching first
    if intake_complete and intake_stage == "eval_coaching":
        if eval_stage == "not_started":
            # First time here — the competency confirmation message was just shown, wait for user
            print("⏸️  Showing competency confirmation, waiting for user")
            return END
        elif eval_stage == "flow_selection":
            # Flow selection message shown, wait for user choice
            print("⏸️  Showing flow selection, waiting for user")
            return END
        elif eval_stage == "ready_to_start":
            print("✅ Starting evaluation coaching")
            return "eval_coaching_planner_node"
        elif eval_stage == "drafting":
            print("✅ Drafting evaluation note")
            return "eval_draft_node"
        elif eval_stage == "coaching":
            print("✅ Continuing evaluation coaching")
            return "eval_answer_handler_node"
        elif eval_stage == "awaiting_confirmation":
            print("✅ Waiting for evaluation confirmation")
            return "eval_confirmation_node"
    
    # After evaluation confirmed, proceed to KPI analysis then draft
    if intake_complete and intake_stage == "analyzing":
        if state.get("direct_eval_flow"):
            print("✅ Direct eval flow — loading KPI data then going to FCR draft (no questions)")
            return "kpi_then_draft_node"
        print("✅ Proceeding to KPI analysis")
        return "kpi_analysis_chat_node"
    elif intake_stage in ["waiting_for_first_answer", "waiting_for_answer", "asking_questions"]:
        print("✅ Routing to ask_questions (user needs to answer)")
        return "ask_questions_chat_node"
    elif intake_stage == "generating_draft":
        print("✅ Routing to draft FCR generation")
        return "draft_fcr_chat_node"

    print(f"⏹️  Returning END")
    return END


def eval_coaching_planner_node(state: IntakeChatState) -> Dict[str, Any]:
    """Plan the next evaluation coaching question."""
    print("🔷 Running Evaluation Coaching Planner")
    
    plan = evaluation_coaching_node(dict(state))
    next_q = plan.get("next_eval_question")
    
    if not next_q:
        # No more questions needed, draft the evaluation
        print("✅ Evaluation coaching complete, drafting evaluation note")
        return {
            **plan,
            "eval_coaching_stage": "drafting",
            "messages": [
                AIMessage(content="Thanks for those details. Let me put together your evaluation note...")
            ],
        }
    
    # Ask the question
    question_text = next_q.get("question_text", "")
    prompts = next_q.get("coaching_prompts", [])
    target_comp = next_q.get("target_competency", "")
    
    parts = [question_text]
    if target_comp:
        parts.append(f"\n_This helps evaluate: **{target_comp}**_")
    if prompts:
        parts.append("\n_Think about:_")
        for p in prompts[:2]:
            parts.append(f"• {p}")
    
    # Track asked questions
    asked = list(state.get("eval_questions_asked", []))
    asked.append(next_q.get("id", ""))
    
    return {
        **plan,
        "next_eval_question": next_q,
        "eval_questions_asked": asked,
        "eval_question_count": len(asked),
        "eval_coaching_stage": "coaching",
        "messages": [AIMessage(content="\n".join(parts))],
    }


def eval_answer_handler_node(state: IntakeChatState) -> Dict[str, Any]:
    """Handle answer to evaluation coaching question."""
    print("🔷 Processing Evaluation Answer")
    
    messages = state.get("messages", [])
    last_user_message = get_last_user_message(messages)
    
    # Light validation — only reject truly empty/trivial responses
    last_q = state.get("next_eval_question")
    if last_q and last_user_message:
        stripped = last_user_message.strip()
        if len(stripped) < 10:
            return {
                "eval_coaching_stage": "coaching",
                "messages": [AIMessage(content="Please provide a bit more detail in your response.\n\nPlease try again.")],
            }

    # Store the answer
    updates: Dict[str, Any] = {}
    if last_user_message:
        updates["last_user_answer"] = last_user_message
    
    # Mark question as answered
    last_q = state.get("next_eval_question")
    if last_q:
        updates["last_eval_question"] = last_q
    
    # Ingest the answer — exclude messages to avoid state bloat
    ingest_state = {k: v for k, v in state.items() if k != "messages"}
    ingest_state.update(updates)
    ingest_updates = evaluation_answer_ingest_node(ingest_state)

    # Merge only the relevant field updates (NOT the full state or messages)
    all_updates = {**updates, **ingest_updates}
    
    # Plan next question using a clean state dict
    planning_state = {k: v for k, v in state.items() if k != "messages"}
    planning_state.update(all_updates)
    plan = evaluation_coaching_node(planning_state)
    next_q = plan.get("next_eval_question")
    
    if not next_q:
        # Check if we have enough data to draft
        eval_answers = all_updates.get("eval_answers") or state.get("eval_answers") or {}
        if len(eval_answers) < 1:
            # Not enough data — ask a generic follow-up
            print("⚠️ No next question generated but insufficient data, asking generic follow-up")
            return {
                **all_updates,
                "eval_coaching_stage": "coaching",
                "messages": [
                    AIMessage(content="Can you share any other observations from the field day — what went well or what could be improved?")
                ],
            }
        # Done with questions, draft evaluation
        print("✅ Evaluation coaching complete, drafting evaluation note")
        return {
            **all_updates,
            "should_ask_eval_questions": False,
            "next_eval_question": None,
            "eval_coaching_stage": "drafting",
            "messages": [
                AIMessage(content="Thanks — I have what I need. Drafting your evaluation note now...")
            ],
        }
    
    # Ask next question
    question_text = next_q.get("question_text", "")
    prompts = next_q.get("coaching_prompts", [])
    target_comp = next_q.get("target_competency", "")
    
    parts = [question_text]
    if target_comp:
        parts.append(f"\n_This helps evaluate: **{target_comp}**_")
    if prompts:
        parts.append("\n_Think about:_")
        for p in prompts[:2]:
            parts.append(f"\u2022 {p}")
    
    asked = list(state.get("eval_questions_asked", []))
    asked.append(next_q.get("id", ""))
    
    return {
        **all_updates,
        "next_eval_question": next_q,
        "eval_questions_asked": asked,
        "eval_question_count": len(asked),
        "eval_coaching_stage": "coaching",
        "messages": [AIMessage(content="\n".join(parts))],
    }


def eval_draft_node(state: IntakeChatState) -> Dict[str, Any]:
    """Generate evaluation note draft."""
    print("🔷 Drafting Evaluation Note")
    
    try:
        draft_result = evaluation_draft_node(dict(state))
    except Exception as e:
        print(f"❌ Evaluation draft generation failed: {e}")
        draft_result = {"evaluation_draft": None, "evaluation_draft_status": "failed"}
    
    eval_draft = draft_result.get("evaluation_draft")
    full_text = draft_result.get("evaluation_full_text", "")
    
    if not eval_draft:
        return {
            **draft_result,
            "eval_coaching_stage": "coaching",
            "messages": [
                AIMessage(content="I wasn't able to generate the evaluation note with the current information. Could you provide a bit more detail about what you observed during the field day?")
            ],
        }
    
    # Format the evaluation note for display
    reply = "**📝 FCR Draft:**\n\n"
    reply += full_text
    reply += _eval_goal_controls(eval_draft)
    reply += "\n\n---\n\nDoes this evaluation note look good?\n\n[[action:Approve]] [[action:Revise]]"
    
    return {
        **draft_result,
        "eval_coaching_stage": "awaiting_confirmation",
        "messages": [AIMessage(content=reply)],
    }


# --- #11: Select / Remove controls for SMART Goals (evaluation note flow) ---
def _eval_goal_controls(eval_draft: Dict[str, Any]) -> str:
    """Render SMART Goal controls.
    - Edit is available per existing goal (even when only 1 goal remains).
    - Keep/Remove are shown only when 2+ goals exist (nothing to select/remove otherwise).
    """
    goals = (eval_draft or {}).get("how_to_improve", []) or []
    if not goals:
        return ""
    txt = "\n\n---\n\n_Manage the SMART Goals:_\n\n"
    # Edit — one button per existing goal
    edit_buttons = " ".join(f"[[action:Edit Goal {i + 1}]]" for i in range(len(goals)))
    txt += edit_buttons + "\n\n"
    # Keep / Remove — only meaningful with 2+ goals
    if len(goals) >= 2:
        txt += "[[action:Remove Goal 1]] [[action:Remove Goal 2]]\n\n"
        txt += "[[action:Keep Goal 1]] [[action:Keep Goal 2]] [[action:Keep Both Goals]]\n"
    return txt


def _rebuild_eval_full_text(eval_draft: Dict[str, Any]) -> str:
    """Rebuild the evaluation note text (Observation, Impact, How to Improve) from the
    current goals, so Keep/Remove changes are reflected in the displayed/saved note."""
    note = eval_draft.get("evaluation_note", eval_draft) if isinstance(eval_draft, dict) else {}
    observation = note.get("observation", eval_draft.get("observation", ""))
    impact = note.get("impact", eval_draft.get("impact", ""))
    goals = eval_draft.get("how_to_improve", note.get("how_to_improve", [])) or []

    parts = []
    if observation:
        parts.append(f"**Observation:** {observation}")
    if impact:
        parts.append(f"**Impact:** {impact}")
    if goals:
        parts.append("**How to Improve:**")
        for g in goals:
            head = g.get("goal_headline", "SMART Goal")
            parts.append(f"\n{head}")
            if g.get("specific"):    parts.append(f"- Specific: {g['specific']}")
            if g.get("measurable"):  parts.append(f"- Measurable: {g['measurable']}")
            if g.get("achievable"):  parts.append(f"- Achievable: {g['achievable']}")
            if g.get("relevant"):    parts.append(f"- Relevant: {g['relevant']}")
            if g.get("time_bound"):  parts.append(f"- Time-Bound: {g['time_bound']}")
            if g.get("impact"):      parts.append(f"- Impact: {g['impact']}")
    return "\n".join(parts)
# --- end #11 helpers ---


def eval_confirmation_node(state: IntakeChatState) -> Dict[str, Any]:
    """Handle confirmation or revision of evaluation note."""
    print("🔷 Handling Evaluation Confirmation")
    
    messages = state.get("messages", [])
    last_user_message = get_last_user_message(messages)
    lower_msg = last_user_message.lower().strip()

    # --- #11: Edit a SMART Goal (from the popup) ---
    edited_goal = state.get("edited_goal")
    if edited_goal is not None:
        eval_draft = dict(state.get("evaluation_draft", {}) or {})
        goals = list(eval_draft.get("how_to_improve", []) or [])
        idx = edited_goal.get("index", -1)
        fields = edited_goal.get("fields", {}) or {}
        if 0 <= idx < len(goals):
            updated = dict(goals[idx])
            for k in ["goal_headline", "specific", "measurable", "achievable",
                      "relevant", "time_bound", "impact"]:
                if k in fields:
                    updated[k] = fields[k]
            goals[idx] = updated
            eval_draft["how_to_improve"] = goals
            note = f"Updated **SMART Goal {idx + 1}**."
        else:
            note = "Could not update that goal."
        new_full_text = _rebuild_eval_full_text(eval_draft)
        reply = note + "\n\n**📝 FCR Draft:**\n\n" + new_full_text
        reply += _eval_goal_controls(eval_draft)
        reply += "\n\n---\n\nDoes this evaluation note look good?\n\n[[action:Approve]] [[action:Revise]]"
        return {
            "evaluation_draft": eval_draft,
            "evaluation_full_text": new_full_text,
            "edited_goal": None,
            "eval_coaching_stage": "awaiting_confirmation",
            "messages": [AIMessage(content=reply)],
        }
    # --- end #11 edit ---

    # --- #11: Select / Remove a SMART Goal (evaluation note flow) ---
    if lower_msg in ["keep goal 1", "keep goal 2", "keep both goals",
                     "remove goal 1", "remove goal 2"]:
        eval_draft = dict(state.get("evaluation_draft", {}) or {})
        goals = list(eval_draft.get("how_to_improve", []) or [])
        note = ""
        if lower_msg == "keep both goals":
            note = "Kept **both** SMART Goals."
        elif lower_msg in ["keep goal 1", "keep goal 2"] and len(goals) > 1:
            idx = 0 if lower_msg == "keep goal 1" else 1
            eval_draft["how_to_improve"] = [goals[idx]]
            note = f"Kept **SMART Goal {idx + 1}**."
        elif lower_msg in ["remove goal 1", "remove goal 2"]:
            idx = 0 if lower_msg == "remove goal 1" else 1
            if 0 <= idx < len(goals):
                goals.pop(idx)
                eval_draft["how_to_improve"] = goals
                note = f"Removed **SMART Goal {idx + 1}**."
            else:
                note = "That goal does not exist."
        # Rebuild the note text and re-show with controls + Approve/Revise.
        new_full_text = _rebuild_eval_full_text(eval_draft)
        reply = note + "\n\n**📝 FCR Draft:**\n\n" + new_full_text
        reply += _eval_goal_controls(eval_draft)
        reply += "\n\n---\n\nDoes this evaluation note look good?\n\n[[action:Approve]] [[action:Revise]]"
        return {
            "evaluation_draft": eval_draft,
            "evaluation_full_text": new_full_text,
            "eval_coaching_stage": "awaiting_confirmation",
            "messages": [AIMessage(content=reply)],
        }
    # --- end #11 ---

    intent = classify_intent(last_user_message, {
        "approve": "User approves, accepts, confirms the evaluation note is good",
        "revise": "User wants changes, corrections, or has feedback on the evaluation note",
    }, context="User was shown an evaluation note and asked if it's acceptable")

    if intent == "approve":
        # Evaluation confirmed, ask about deep dive
        print("✅ Evaluation confirmed, asking about deep dive")
        return {
            "evaluation_confirmed": True,
            "intake_stage": "awaiting_deep_dive",
            "eval_coaching_stage": "confirmed",
            "messages": [
                AIMessage(content="Would you like to discuss TAS performance KPIs before drafting the FCR?\n\n[[action:Let's Discuss KPI Performance]] [[action:Skip to Draft]]")
            ],
        }
    elif lower_msg in ["no", "n", "revise"]:
        # Plain no or Revise button — ask what to change
        return {
            "eval_coaching_stage": "awaiting_confirmation",
            "messages": [AIMessage(content="What would you like me to change? You can:\n- Provide feedback on the evaluation text\n- Correct the competencies (e.g., \"remove Engage, add Close\")")],
        }
    else:
        # Check if user is correcting competencies
        existing = list(state.get("selected_competencies", []))
        all_comps = ["Plan", "Engage", "Advance", "Close", "Follow-up"]
        changed = False

        # Handle removals
        for comp in all_comps:
            if any(k in lower_msg for k in [f"remove {comp.lower()}", f"not {comp.lower()}", f"isn't {comp.lower()}", f"isn\\'t {comp.lower()}"]):
                if comp in existing:
                    existing.remove(comp)
                    changed = True

        # Handle additions
        for comp in all_comps:
            if any(k in lower_msg for k in [f"add {comp.lower()}", f"it is {comp.lower()}", f"it's {comp.lower()}", f"should be {comp.lower()}"]):
                if comp not in existing:
                    existing.append(comp)
                    changed = True

        if changed:
            comp_list = ", ".join(existing)
            # Re-draft with updated competencies
            revised_state = {
                **dict(state),
                "selected_competencies": existing,
                "evaluation_revision_feedback": f"Update competencies to: {comp_list}. {last_user_message}"
            }
            draft_result = evaluation_draft_node(revised_state)
            full_text = draft_result.get("evaluation_full_text", "")
            if not full_text:
                return {"messages": [AIMessage(content="⚠️ Failed to revise. Please try again.")]}
            reply = f"Updated competencies to: **{comp_list}**\n\n**📝 Revised FCR Draft:**\n\n"
            reply += full_text
            reply += _eval_goal_controls(draft_result.get("evaluation_draft", {}))
            reply += "\n\n---\n\nDoes this evaluation note look good?\n\n[[action:Approve]] [[action:Revise]]"
            return {
                **draft_result,
                "selected_competencies": existing,
                "eval_coaching_stage": "awaiting_confirmation",
                "messages": [AIMessage(content=reply)],
            }

        # User wants to revise text - re-draft with feedback
        print("🔄 Revising evaluation note based on feedback")
        
        # Re-run draft with feedback context
        revised_state = {
            **dict(state),
            "evaluation_revision_feedback": last_user_message
        }
        
        draft_result = evaluation_draft_node(revised_state)
        eval_draft = draft_result.get("evaluation_draft")
        full_text = draft_result.get("evaluation_full_text", "")
        
        if not eval_draft:
            return {
                "eval_coaching_stage": "awaiting_confirmation",
                "messages": [
                    AIMessage(content="⚠️ Failed to revise evaluation note. Please provide more specific feedback.")
                ],
            }
        
        reply = "**📝 Revised FCR Draft:**\n\n"
        reply += full_text
        reply += _eval_goal_controls(draft_result.get("evaluation_draft", {}))
        reply += "\n\n---\n\nDoes this evaluation note look good?\n\n[[action:Approve]] [[action:Revise]]"
        
        return {
            **draft_result,
            "eval_coaching_stage": "awaiting_confirmation",
            "messages": [AIMessage(content=reply)],
        }


def kpi_analysis_chat_node(state: IntakeChatState) -> Dict[str, Any]:
    """Run KPI analysis."""
    print("🔷 Running KPI Analysis Node")
    try:
        kpi_result = KPIAnalysisNode(dict(state)).run()
    except Exception as e:
        print(f"⚠️ KPI Analysis failed: {e}")
        kpi_result = {"kpi_analysis": {}}
    print(f"✅ KPI Analysis Complete")
    return {
        **kpi_result,
        "intake_stage": "retrieving",
    }


def kpi_then_draft_node(state: IntakeChatState) -> Dict[str, Any]:
    """Load KPI data + past FCRs and go straight to draft (no questions)."""
    print("🔷 Running KPI Analysis + Retrieval (skip questions path)")
    try:
        kpi_result = KPIAnalysisNode(dict(state)).run()
    except Exception as e:
        print(f"⚠️ KPI Analysis failed: {e}")
        kpi_result = {"kpi_analysis": {}}
    print("🔷 Running Retrieval — fetching past FCRs and guidelines")
    try:
        retrieval_result = retrieval_node(dict(state))
    except Exception as e:
        print(f"⚠️ Retrieval failed: {e}")
        retrieval_result = {"context_bundle": {}}
    print("✅ Retrieval Complete — proceeding to Draft")
    return {
        **kpi_result,
        **retrieval_result,
        "intake_stage": "generating_draft",
    }


def retrieval_chat_node(state: IntakeChatState) -> Dict[str, Any]:
    """Run enhanced retrieval (FCRs, guidelines, KPIs)."""
    print("🔷 Running Retrieval Node")
    try:
        retrieval_result = retrieval_node(dict(state))
    except Exception as e:
        print(f"⚠️ Retrieval failed: {e}")
        retrieval_result = {"context_bundle": {}}
    context_bundle = retrieval_result.get("context_bundle", {})
    print(f"✅ Retrieval Complete: {len(context_bundle)} context types retrieved")
    return {
        **retrieval_result,
        "intake_stage": "planning_questions",
    }


def question_planning_chat_node(state: IntakeChatState) -> Dict[str, Any]:
    """Plan ONE best next question (adaptive)."""
    print("🔷 Running Question Planner Node (adaptive)")

    # Ensure counters exist (safe defaults)
    asked_ids = list(state.get("asked_question_ids", []))
    asked_count = int(state.get("asked_question_count", 0))

    seed = {
        **dict(state),
        "asked_question_ids": asked_ids,
        "asked_question_count": asked_count,
        # optional cap
        "max_questions": int(state.get("max_questions", 7)),
    }

    plan = question_planner_node(seed)

    # Adaptive planner returns next_question (or None)
    next_q = plan.get("next_question")

    if not next_q:
        return {
            **plan,
            "asked_question_ids": asked_ids,
            "asked_question_count": asked_count,
            "intake_stage": "generating_draft",
            "messages": [
                AIMessage(content="I have enough to work with — generating your FCR draft now...")
            ],
        }

    # Store the question into state so ask_questions_chat_node can mark it answered
    msg = _render_question(next_q)

    return {
        **plan,
        "asked_question_ids": asked_ids,
        "asked_question_count": asked_count,
        "next_question": next_q,
        "intake_stage": "waiting_for_first_answer",
        "user_answers": state.get("user_answers", {}) or {},
        "messages": [AIMessage(content=msg)],
    }


def _build_kpi_flash_cards(analysis: Dict[str, Any], territory: str) -> str:
    """Build a compact KPI flash card display from territory analysis data."""
    if not analysis:
        return ""

    cards = {}  # Use dict to deduplicate by metric name

    for key, val in analysis.items():
        if val is None or val == "":
            continue
        k_lower = str(key).lower()

        # Skip non-metric fields
        if k_lower in ("territory",):
            continue

        # Rhapsido TRx (latest - pick first match only)
        if "rhapsido" in k_lower and "trx" in k_lower and "growth" not in k_lower and "writer" not in k_lower:
            if "Rhapsido TRx" not in cards:
                cards["Rhapsido TRx"] = str(val)
        elif "rhapsido" in k_lower and "nbrx" in k_lower and "growth" not in k_lower:
            if "Rhapsido NBRx" not in cards:
                cards["Rhapsido NBRx"] = str(val)
        elif "rhapsido" in k_lower and "trx" in k_lower and "growth" in k_lower:
            if "TRx Growth" not in cards:
                cards["TRx Growth"] = f"{float(val)*100:.1f}%" if isinstance(val, (int, float)) else str(val)
        elif "rhapsido" in k_lower and "nbrx" in k_lower and "growth" in k_lower:
            if "NBRx Growth" not in cards:
                cards["NBRx Growth"] = f"{float(val)*100:.1f}%" if isinstance(val, (int, float)) else str(val)
        elif "rhapsido" in k_lower and "start form" in k_lower and "growth" not in k_lower:
            if "Start Forms" not in cards:
                cards["Start Forms"] = str(val)
        elif "top 2" in k_lower and "reach" in k_lower:
            cards["Top 2 Tier Reach"] = f"{float(val)*100:.1f}%" if isinstance(val, (int, float)) and val <= 1 else str(val)
        elif "trx writer" in k_lower and "growth" not in k_lower:
            cards["# Writers"] = str(val)
        elif k_lower == "reach %" or (k_lower.startswith("reach") and "%" in k_lower):
            if "Reach %" not in cards:
                cards["Reach %"] = f"{float(val)*100:.1f}%" if isinstance(val, (int, float)) and val <= 1 else str(val)

    if not cards:
        return ""

    header = "| Metric | Value |\n|:-------|:------|\n"
    rows = "\n".join(f"| {k} | {v} |" for k, v in cards.items())
    return header + rows


def _render_question(q: Dict[str, Any]) -> str:
    question_text = q.get("question_text") or "Please provide additional details."
    prompts = q.get("follow_up_prompts") or []

    parts = [question_text]

    if prompts:
        parts.append("\n_Think about:_")
        for p in prompts[:2]:
            parts.append(f"• {p}")

    return "\n".join(parts)


def ask_questions_chat_node(state: Dict[str, Any]) -> Dict[str, Any]:
    messages = state.get("messages", [])
    last_user_message = get_last_user_message(messages)

    # Validate the answer against the current question
    last_q = state.get("next_question") or state.get("last_asked_question")
    if last_q and last_user_message:
        from app.src.graph.nodes.answer_validation_node import validate_answer
        expected_type = "list" if "competenc" in last_q.get("purpose", "").lower() else "narrative"
        is_valid, feedback = validate_answer(last_user_message, expected_type, last_q)
        if not is_valid:
            return {
                "intake_stage": state.get("intake_stage"),
                "messages": [AIMessage(content=f"⚠️ {feedback}\n\nPlease try again.")],
            }

    # Persist the latest answer so answer_ingest_node can read it
    updates = {}
    if last_user_message:
        updates["last_user_answer"] = last_user_message

    # Mark previous question as answered, update asked ids
    last_q = state.get("next_question") or state.get("last_asked_question")
    asked_ids = list(state.get("asked_question_ids", []))
    asked_count = int(state.get("asked_question_count", 0))

    if last_q:
        updates["last_asked_question"] = last_q
        qid = last_q.get("id")
        if qid and qid not in asked_ids:
            asked_ids.append(qid)
            asked_count += 1

    # First: your existing lightweight enrichment (purpose-based)
    enriched = {}
    if last_q and last_user_message:
        enriched = _enrich_state_with_answer(state, last_q, last_user_message)

    # Second: stronger extraction/slot filling
    ingest_updates = {}
    if last_q and last_user_message:
        ingest_state = {**state, **updates, **enriched, "asked_question_ids": asked_ids, "asked_question_count": asked_count}
        ingest_updates = answer_ingest_node(ingest_state)

    merged_state = {**state, **updates, **enriched, **ingest_updates, "asked_question_ids": asked_ids, "asked_question_count": asked_count}

    # Re-run planner NOW (this is the key change)
    plan = question_planner_node(merged_state)
    next_q = plan.get("next_question")

    if not next_q:
        return {
            **merged_state,
            "intake_stage": "generating_draft",
            "messages": [AIMessage(content="Thanks — I have enough detail now. Generating the FCR draft...")],
        }

    # Ask only ONE next question
    question_text = next_q.get("question_text", "Please provide more details.")
    prompts = next_q.get("follow_up_prompts", [])
    parts = [question_text]
    if prompts:
        parts.append("\n_Think about:_")
        for p in prompts[:2]:
            parts.append(f"• {p}")

    return {
        **merged_state,
        "next_question": next_q,
        "intake_stage": "waiting_for_answer",
        "messages": [AIMessage(content="\n".join(parts))],
    }


def _enrich_state_with_answer(state: Dict[str, Any], question: Dict[str, Any], answer: str) -> Dict[str, Any]:
    """Map answer to appropriate state field based on question purpose."""
    updates = {}
    purpose_lower = question.get("purpose", "").lower()

    if "observation" in purpose_lower:
        updates["observation_notes"] = answer
    elif "competency" in purpose_lower:
        updates["selected_competencies"] = parse_competencies(answer)
    elif "strength" in purpose_lower:
        updates["observed_strengths"] = answer
    elif "opportunity" in purpose_lower or "develop" in purpose_lower:
        updates["development_opportunities"] = answer
    elif "impact" in purpose_lower:
        updates["impact_statement"] = answer
    elif "action" in purpose_lower:
        updates["action_items"] = answer
    elif "seam" in purpose_lower:
        updates["seam_notes"] = answer
    else:
        # Default: add to developmental_context
        existing = state.get("developmental_context", "")
        updates["developmental_context"] = f"{existing}\n\n{answer}".strip()

    return updates


def _route_after_retrieval(state: IntakeChatState) -> str:
    """Skip questions and go straight to FCR draft if user chose direct eval flow."""
    if state.get("direct_eval_flow"):
        print("✅ Direct eval flow — skipping questions, going to FCR draft")
        return "draft_fcr_chat_node"
    return "question_planning_chat_node"


def should_ask_more_questions(state: IntakeChatState) -> str:
    """Route based on question stage."""
    if state.get("intake_stage") == "asking_questions":
        return "ask_questions_chat_node"
    elif state.get("intake_stage") == "generating_draft":
        return "draft_fcr_chat_node"
    return END


def draft_fcr_chat_node(state: IntakeChatState) -> Dict[str, Any]:
    """Generate FCR draft using all collected information."""
    draft_result = draft_fcr_node(dict(state))

    draft = draft_result.get("draft")

    # Ensure all FCR components exist with defaults
    if draft and isinstance(draft, dict):
        if "previous_smart_action" not in draft:
            # Get smart_actions from the last FCR's OWN actions (not its previous_smart_action)
            context_bundle = state.get("context_bundle", {})
            past_fcrs = context_bundle.get("past_fcr_context", {}).get("latest_3_fcrs_as_is", [])
            if past_fcrs:
                last_fcr = past_fcrs[0] if isinstance(past_fcrs[0], dict) else {}
                fcr_content = last_fcr.get("fcr_json", last_fcr)
                # Use the last FCR's own smart_actions — those become "previous" for current FCR
                smart_actions = fcr_content.get("smart_actions", [])
                if smart_actions and isinstance(smart_actions[0], dict):
                    action = smart_actions[0]
                    draft["previous_smart_action"] = {
                        "description": action.get("action", action.get("content", "Review and apply coaching from previous field visit")),
                        "due_date": action.get("time_bound", action.get("due", action.get("due_date", "N/A"))),
                        "status": "Completed"
                    }
        if "compliance" not in draft:
            draft["compliance"] = {
                "ae_reporting": "",
                "fair_balance": "",
                "prescribing_info": "",
                "materials_approved": "",
                "samples_managed": ""
            }
        if "core_capabilities" not in draft:
            draft["core_capabilities"] = {
                "categories": ["Clinical Sell/Differentiation"],
                "comments": ""
            }

    # Also run rubric check
    from app.src.graph.nodes.rubric_check_node import RubricCheckNode
    rubric_state = {"draft": draft, "context_bundle": state.get("context_bundle", {})}
    rubric_result = RubricCheckNode(rubric_state).run()
    rubric_issues = rubric_result.get("rubric_issues", [])
    competency_scores = rubric_result.get("competency_scores", [])

    # Extract patterns from the FCR
    from app.src.graph.nodes.pattern_mining_node import PatternMiningNode
    pattern_state = {
        **dict(state),
        "draft": draft,
    }
    pattern_result = PatternMiningNode(pattern_state).run()

    print(f"[Draft] Pattern mining: {pattern_result.get('pattern_mining', {}).get('status')}")

    if not draft:
        reply = "⚠️ FCR draft generation failed."
    else:
        reply = _format_fcr_with_rubric(draft, rubric_issues, is_revision=False, competency_scores=competency_scores)

    return {
        **draft_result,
        "rubric_issues": rubric_issues,
        "competency_scores": competency_scores,
        "pattern_mining": pattern_result.get("pattern_mining", {}),
        "intake_stage": "complete",
        "fcr_result": {
            "draft": draft,
            "rubric_issues": rubric_issues,
            "competency_scores": competency_scores,
            "kpi_analysis": state.get("kpi_analysis", {}),
        },
        "messages": [
            AIMessage(content=reply)
        ],
    }


def _format_fcr_with_rubric(draft: Dict[str, Any], rubric_issues: List[Any], is_revision: bool, competency_scores: List[Any] = None) -> str:
    """Format FCR draft: Metadata → Previous SMART → KPIs → Observations → Core Capabilities → New SMART → Compliance → Rubric."""

    if is_revision:
        reply = "**Revised FCR Draft**\n\n"
    else:
        reply = "**📋 FCR Draft**\n\n"

    # Metadata
    metadata = draft.get("metadata", {})
    if metadata:
        reply += f"| Field | Value |\n|:------|:------|\n"
        reply += f"| Coachee | {metadata.get('coachee', draft.get('tas_id', ''))} |\n"
        reply += f"| Coach | {metadata.get('coach', 'ABL')} |\n"
        reply += f"| Session Date | {metadata.get('session_date', draft.get('month', ''))} |\n"
        reply += f"| Session Type | {metadata.get('session_type', 'Coaching HCP - Live')} |\n\n"
    else:
        tas_id = draft.get("tas_id", "")
        month = draft.get("month", "")
        if tas_id or month:
            reply += f"| Field | Value |\n|:------|:------|\n"
            reply += f"| Coachee | {tas_id} |\n"
            reply += f"| Month | {month} |\n"
            reply += f"| Session Type | Coaching HCP - Live |\n\n"

    # Summary
    summary = draft.get("summary", "")
    if summary and summary != "N/A":
        reply += f"---\n\n**Summary**\n\n{summary}\n\n"

    # Previous SMART Action (from last FCR)
    prev_smart = draft.get("previous_smart_action", {})
    if prev_smart:
        reply += f"---\n\n**Previous SMART Action Review**\n\n"
        reply += f"_{prev_smart.get('description', 'N/A')}_\n"
        reply += f"Due: {prev_smart.get('due_date', 'N/A')} | Status: **{prev_smart.get('status', 'Pending')}**\n\n"

    # Performance & KPIs
    kpi_narrative = draft.get("kpi_narrative", "")
    if kpi_narrative:
        reply += f"---\n\n**Performance & KPIs**\n\n{kpi_narrative}\n\n"

    # Selling Approach Scores (above observations)
    reply += "---\n\n**Selling Approach Scores**\n\n"
    reply += "| Competency | Score | Rationale |\n"
    reply += "|:-----------|:-----:|:----------|\n"

    if competency_scores:
        for cs in competency_scores:
            name = cs.get("name", "")
            score = cs.get("score")
            if score is None or score == "":
                score = "—"
            rationale = cs.get("rationale", "")
            reply += f"| {name} | {score}/5 | {rationale} |\n"
    else:
        competencies = draft.get("competencies", [])
        for comp in competencies:
            if isinstance(comp, dict):
                name = comp.get("name", "")
                score = comp.get("score")
                if score is None or score == "":
                    score = "—"
                evidence = comp.get("evidence", "")
                reply += f"| {name} | {score}/5 | {evidence} |\n"

    # Observations
    observations = draft.get("observations", [])
    if observations:
        reply += "\n---\n\n**Observations**\n\n"
        for obs in observations:
            area = obs.get("area", "")
            what = obs.get("what_i_saw", "")
            impact = obs.get("impact", "")
            reply += f"**{area}**: {what}\n"
            if impact:
                reply += f"_Impact: {impact}_\n"
            reply += "\n"

    # Core Capabilities
    core_caps = draft.get("core_capabilities", {})
    if core_caps:
        categories = core_caps.get("categories", [])
        comments = core_caps.get("comments", "")
        if categories or comments:
            reply += "---\n\n**Core Capabilities**\n\n"
            if categories:
                reply += f"Areas: {', '.join(categories)}\n\n"
            if comments:
                reply += f"{comments}\n\n"

    # New SMART Actions
    smart_actions = draft.get("smart_actions", [])
    if smart_actions:
        reply += "---\n\n**SMART Action Steps**\n\n"
        for i, action in enumerate(smart_actions[:2], 1):
            reply += f"**Action {i}:**\n"
            reply += f"| Component | Detail |\n"
            reply += f"|:----------|:-------|\n"
            reply += f"| **S** - Specific | {action.get('action', '')} |\n"
            reply += f"| **M** - Measurable | {action.get('measurable', action.get('measure', ''))} |\n"
            reply += f"| **A** - Achievable | {action.get('achievable', '')} |\n"
            reply += f"| **R** - Relevant | {action.get('relevant', '')} |\n"
            reply += f"| **T** - Time-bound | {action.get('time_bound', action.get('due', ''))} |\n\n"

        # If more than one action, let the user narrow to a single preferred action.
        if len(smart_actions[:2]) > 1:
            reply += "_Would you like to keep only one preferred action?_\n\n"
            reply += "[[action:Keep Action 1]] [[action:Keep Action 2]] [[action:Keep Both Actions]]\n\n"

    # Compliance
    compliance = draft.get("compliance", {})
    if not compliance:
        compliance = {
            "ae_reporting": "",
            "fair_balance": "",
            "prescribing_info": "",
            "materials_approved": "",
            "samples_managed": "",
        }
    reply += "---\n\n**Compliance** _(to be completed by ABL)_\n\n"
    reply += "| Item | Status |\n|:-----|:-------|\n"
    for key, val in compliance.items():
        label = key.replace("_", " ").title()
        display_val = val if val else "— _Insufficient data_"
        reply += f"| {label} | {display_val} |\n"
    reply += "\n"

    reply += "\n---\n\nDoes this FCR draft look good?\n\n[[action:Approve]] [[action:Revise]]"

    return reply


def _format_finalized_fcr(draft: Dict[str, Any]) -> str:
    """Format finalized FCR — clean, readable, no JSON."""
    reply = "**📋 Final Field Coaching Report**\n\n"

    summary = draft.get("summary", "")
    if summary and summary != "N/A":
        reply += f"{summary}\n\n"

    kpi_narrative = draft.get("kpi_narrative", "")
    if kpi_narrative:
        reply += f"---\n\n**Territory Performance**\n\n{kpi_narrative}\n\n"

    # Competencies with scores
    competencies = draft.get("competencies", [])
    if competencies:
        reply += "---\n\n**Competencies**\n\n"
        for comp in competencies:
            name = comp.get("name", "")
            score = comp.get("score", "—")
            evidence = comp.get("evidence", "")
            reply += f"**{name}** ({score}/5): {evidence}\n\n"

    # Observations
    observations = draft.get("observations", [])
    if observations:
        reply += "---\n\n**Observations**\n\n"
        for obs in observations:
            area = obs.get("area", "")
            what = obs.get("what_i_saw", "")
            impact = obs.get("impact", "")
            reply += f"**{area}**\n{what}\n"
            if impact:
                reply += f"_Impact: {impact}_\n"
            reply += "\n"

    # SMART Actions
    smart_actions = draft.get("smart_actions", [])
    if smart_actions:
        reply += "---\n\n**SMART Actions**\n\n"
        for i, action in enumerate(smart_actions[:2], 1):
            reply += f"**Action {i}:**\n"
            reply += f"| Component | Detail |\n"
            reply += f"|:----------|:-------|\n"
            reply += f"| **S** - Specific | {action.get('action', '')} |\n"
            reply += f"| **M** - Measurable | {action.get('measurable', action.get('measure', ''))} |\n"
            reply += f"| **A** - Achievable | {action.get('achievable', '')} |\n"
            reply += f"| **R** - Relevant | {action.get('relevant', '')} |\n"
            reply += f"| **T** - Time-bound | {action.get('time_bound', action.get('due', ''))} |\n\n"

    return reply


def create_intake_chat_graph():
    workflow = StateGraph(IntakeChatState)

    # Add all nodes - Two-phase flow: 1) Evaluation Coaching, 2) KPI/FCR Questions
    workflow.add_node("intake_chat_node", intake_chat_node)
    
    # Phase 1: Evaluation Coaching nodes
    workflow.add_node("eval_coaching_planner_node", eval_coaching_planner_node)
    workflow.add_node("eval_answer_handler_node", eval_answer_handler_node)
    workflow.add_node("eval_draft_node", eval_draft_node)
    workflow.add_node("eval_confirmation_node", eval_confirmation_node)
    
    # Phase 2: KPI/FCR nodes
    workflow.add_node("kpi_analysis_chat_node", kpi_analysis_chat_node)
    workflow.add_node("kpi_then_draft_node", kpi_then_draft_node)
    workflow.add_node("retrieval_chat_node", retrieval_chat_node)
    workflow.add_node("question_planning_chat_node", question_planning_chat_node)
    workflow.add_node("ask_questions_chat_node", ask_questions_chat_node)
    workflow.add_node("draft_fcr_chat_node", draft_fcr_chat_node)

    # Build flow - TWO PHASES
    workflow.add_edge(START, "intake_chat_node")

    # After intake, route to evaluation coaching or other stages
    workflow.add_conditional_edges(
        "intake_chat_node",
        should_proceed_to_analysis,
        {
            "eval_coaching_planner_node": "eval_coaching_planner_node",
            "eval_answer_handler_node": "eval_answer_handler_node",
            "eval_draft_node": "eval_draft_node",
            "eval_confirmation_node": "eval_confirmation_node",
            "kpi_analysis_chat_node": "kpi_analysis_chat_node",
            "kpi_then_draft_node": "kpi_then_draft_node",
            "ask_questions_chat_node": "ask_questions_chat_node",
            "draft_fcr_chat_node": "draft_fcr_chat_node",
            END: END,
        },
    )
    
    # Evaluation coaching flow
    workflow.add_conditional_edges(
        "eval_coaching_planner_node",
        lambda s: "eval_draft_node" if s.get("eval_coaching_stage") == "drafting" else END,
        {
            "eval_draft_node": "eval_draft_node",
            END: END,
        },
    )
    
    workflow.add_conditional_edges(
        "eval_answer_handler_node",
        lambda s: "eval_draft_node" if s.get("eval_coaching_stage") == "drafting" else END,
        {
            "eval_draft_node": "eval_draft_node",
            END: END,
        },
    )
    workflow.add_edge("eval_draft_node", END)
    workflow.add_edge("eval_confirmation_node", END)

    # Linear chain: KPI → Retrieval → Question Planning
    workflow.add_edge("kpi_analysis_chat_node", "retrieval_chat_node")
    workflow.add_edge("kpi_then_draft_node", "draft_fcr_chat_node")
    workflow.add_conditional_edges(
        "retrieval_chat_node",
        _route_after_retrieval,
        {
            "question_planning_chat_node": "question_planning_chat_node",
            "draft_fcr_chat_node": "draft_fcr_chat_node",
        },
    )

    # Question planning presents first question, then END (wait for user answer)
    workflow.add_edge("question_planning_chat_node", END)

    # Question asking loop - keep asking until all questions answered
    workflow.add_conditional_edges(
        "ask_questions_chat_node",
        should_ask_more_questions,
        {
            "ask_questions_chat_node": "ask_questions_chat_node",
            "draft_fcr_chat_node": "draft_fcr_chat_node",
            END: END,
        },
    )

    # After draft, done
    workflow.add_edge("draft_fcr_chat_node", END)

    checkpointer = MemorySaver()

    return workflow.compile(checkpointer=checkpointer)


intake_chat_graph = create_intake_chat_graph()
