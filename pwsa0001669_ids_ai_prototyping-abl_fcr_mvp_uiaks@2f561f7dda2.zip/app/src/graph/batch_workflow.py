import json
import re
from pathlib import Path
from typing import TypedDict, Dict, Any, List, Optional

from langgraph.graph import StateGraph, START, END

from app.src.graph.nodes.intake_node import IntakeNodeInput, validate_inputs
from app.src.graph.nodes.kpi_analysis_node import KPIAnalysisNode
from app.src.graph.nodes.rubric_check_node import RubricCheckNode
from app.src.graph.nodes.clarify_node import ClarifyNode
from app.src.graph.nodes.revise_node import ReviseNode
from app.src.graph.nodes.retrieval_node import retrieval_node as enhanced_retrieval_node
from app.src.graph.nodes.question_planner_node import question_planner_node
from app.src.graph.nodes.ask_user_node import ask_user_node
from app.src.llm.bedrock_client import BedrockClient


class WorkflowState(TypedDict, total=False):
    session_id: str
    tas_id: Optional[str]
    tas_name: Optional[str]
    abl_id: Optional[str]
    month: Optional[str]
    territory: Optional[str]

    tas_prework_text: str
    abl_eval_text: str
    selected_competencies: List[str]

    # Intake and QA
    intake: Dict[str, Any]
    qa: Dict[str, Any]

    # KPI Analysis
    kpi_analysis: Dict[str, Any]

    # Enhanced Retrieval (RAG)
    context_bundle: Dict[str, Any]
    latest_3_past_fcrs: List[Dict[str, Any]]
    older_fcr_summary: str
    historical_fcr_count: int
    retrieval_status: str
    retrieved_context: Dict[str, Any]  # Keep for backward compatibility

    # Question Flow
    questions_needed: List[Dict[str, Any]]
    gap_analysis: Dict[str, Any]
    should_ask_questions: bool
    questions_to_ask: List[Dict[str, Any]]
    awaiting_user_input: bool
    user_answers: Dict[str, str]
    questions_already_asked: bool

    asked_question_ids: List[str]
    asked_question_count: int
    next_question: Optional[Dict[str, Any]]
    last_asked_question: Optional[Dict[str, Any]]
    last_user_answer: Optional[str]

    # Enriched from answers
    observation_notes: Optional[str]
    observed_strengths: Optional[str]
    development_opportunities: Optional[str]
    impact_statement: Optional[str]
    action_items: Optional[str]
    seam_notes: Optional[str]
    developmental_context: Optional[str]

    # Draft and downstream
    draft: Optional[Dict[str, Any]]
    rubric_issues: List[Any]
    user_feedback: Optional[str]
    memory_update: Dict[str, Any]
    pattern_mining: Dict[str, Any]


def load_prompt(prompt_name: str) -> str:
    prompt_path = Path(__file__).resolve().parents[1] / "llm" / "prompts" / prompt_name
    if not prompt_path.exists():
        raise FileNotFoundError(f"Prompt file not found: {prompt_path}")
    return prompt_path.read_text(encoding="utf-8")


def clean_json_text(text: str) -> str:
    text = text.strip()
    # Remove markdown code fences (handles ```json and ``` variants)
    text = re.sub(r"^```(?:json)?\s*\n?", "", text)
    text = re.sub(r"\n?\s*```\s*$", "", text)
    return text.strip()


def _format_memory_context(memory_context: Dict[str, Any]) -> str:
    """Format memory context for inclusion in the draft prompt."""
    if not memory_context or memory_context.get("status") != "success":
        return memory_context.get("instruction", "No prior coaching memory available.") if memory_context else "No prior coaching memory available."

    parts = [memory_context.get("instruction", "")]
    parts.append(f"Total past FCRs in memory: {memory_context.get('total_fcrs_in_memory', 0)}")
    parts.append(f"Latest progress trend: {memory_context.get('latest_progress_trend', 'unknown')}")

    strengths = memory_context.get("recurring_strengths", {})
    if strengths:
        top = sorted(strengths.items(), key=lambda x: x[1], reverse=True)[:5]
        parts.append(f"Recurring strengths: {', '.join(f'{k} ({v}x)' for k, v in top)}")

    gaps = memory_context.get("recurring_development_areas", {})
    if gaps:
        top = sorted(gaps.items(), key=lambda x: x[1], reverse=True)[:5]
        parts.append(f"Recurring development areas: {', '.join(f'{k} ({v}x)' for k, v in top)}")

    focus = memory_context.get("previous_coaching_focus", {})
    if focus:
        parts.append(f"Previous coaching focus: {focus.get('primary', '')} — check if addressed this month.")

    summary = memory_context.get("latest_coaching_summary", "")
    if summary:
        parts.append(f"Last session AI summary: {summary}")

    return "\n".join(parts)


def intake_node(state: WorkflowState) -> Dict[str, Any]:
    intake_input = IntakeNodeInput(
        tas_prework_text=state.get("tas_prework_text", ""),
        abl_eval_text=state.get("abl_eval_text", ""),
        selected_competencies=state.get("selected_competencies", []),
    )
    result = validate_inputs(intake_input)
    return {
        "intake": {
            "valid": result.valid,
            "questions": result.questions,
        },
        "qa": {
            "issues": result.questions,
        },
    }


def kpi_analysis_node(state: WorkflowState) -> Dict[str, Any]:
    return KPIAnalysisNode(dict(state)).run()


def retrieval_node_wrapper(state: WorkflowState) -> Dict[str, Any]:
    """
    Enhanced retrieval node with RAG for guidelines, historical FCRs, and KPIs.
    """
    # Call the enhanced retrieval node
    result = enhanced_retrieval_node(dict(state))

    # Keep backward compatibility
    result["retrieved_context"] = {
        "status": result.get("retrieval_status", "completed"),
        "message": "Context retrieved via RAG (guidelines, FCRs, KPIs)",
    }

    return result


def draft_fcr_node(state: WorkflowState) -> Dict[str, Any]:
    intake = state.get("intake", {})

    if not intake.get("valid"):
        return {
            "draft": None,
        }

    base_prompt = load_prompt("draft_fcr.md")

    # Extract context bundle
    context_bundle = state.get("context_bundle", {})
    past_fcr_context = context_bundle.get("past_fcr_context", {})
    guideline_context = context_bundle.get("guideline_context", {})

    # Extract question answers
    observation_notes = state.get("observation_notes", "")
    observed_strengths = state.get("observed_strengths", "")
    development_opportunities = state.get("development_opportunities", "")
    impact_statement = state.get("impact_statement", "")
    action_items = state.get("action_items", "")

    tas_name = state.get("tas_name") or state.get("tas_id") or "TAS"

    # --- #4 Historical Context: if the ABL chose "Continue Previous Plan", pass the prior
    # plan to the model as CONTEXT (not an override) so the new FCR builds on it. ---
    prior_plan_context = ""
    if state.get("continue_prior_plan") and state.get("prior_action_plan"):
        _pp = state.get("prior_action_plan", {})
        prior_plan_context = (
            "\n\nPrevious Coaching Plan (the ABL chose to CONTINUE this plan — treat it as "
            "context and build on it; do NOT ignore it, but do NOT copy it verbatim):\n"
            f"- Previous SMART Goal: {_pp.get('description', 'N/A')}\n"
            f"- Due: {_pp.get('due_date', 'N/A')}\n"
            f"- Status: {_pp.get('status', 'N/A')}\n"
            f"- From month: {_pp.get('month', 'N/A')}\n"
        )

    user_context = f"""
CRITICAL NAME RULE: The TAS name is "{tas_name}". You MUST use ONLY this name when referring to the TAS throughout the entire FCR. Do NOT substitute, infer, or use any other name from context or historical records.

Input data:

Session ID:
{state.get("session_id")}

TAS Name:
{tas_name}

Selected Month:
{state.get("month")}

TAS Pre-work:
{state.get("tas_prework_text")}

ABL Observations:
{state.get("abl_eval_text")}

Detailed Observation Notes (from questions):
{observation_notes if observation_notes else "Not provided"}

Observed Strengths (from questions):
{observed_strengths if observed_strengths else "Not provided"}

Development Opportunities (from questions):
{development_opportunities if development_opportunities else "Not provided"}

Impact Statement (from questions):
{impact_statement if impact_statement else "Not provided"}

Action Items (from questions):
{action_items if action_items else "Not provided"}

Selected Competencies (PRIMARY focus, but include ALL 5 in output):
{state.get("selected_competencies", [])}

KPI Data:
{json.dumps(state.get("kpi_analysis", {}).get("analysis", {}), indent=2)}

KPI Narrative Analysis:
{state.get("kpi_analysis", {}).get("narrative", "No narrative available.")}

Historical FCR Context:
{past_fcr_context.get("instruction_for_draft_node", "")}
Number of Historical FCRs: {past_fcr_context.get("historical_fcr_count", 0)}
{prior_plan_context}

Latest 3 FCRs (full records):
{json.dumps(past_fcr_context.get("latest_3_fcrs_as_is", []), indent=2)[:2000]}

Older FCR Pattern Summary:
{past_fcr_context.get("older_fcr_summary", "No older FCRs available")}

Guideline References (top 3):
{json.dumps([g.get("content", "")[:300] for g in guideline_context.get("guidelines", [])[:3]], indent=2) if guideline_context.get("guidelines") else "No guidelines retrieved"}

Coaching Memory (patterns from past FCRs):
{_format_memory_context(context_bundle.get("memory_context", {}))}

Return only valid JSON in this structure:

{{
  "fcr_id": "string",
  "tas_id": "string",
  "month": "string",
  "summary": "string (3-5 sentence executive summary of the field day)",
  "previous_smart_action": {{
    "description": "string (the SMART action from the most recent prior FCR, if available)",
    "due_date": "string",
    "status": "string (Completed/In Progress/Not Started)"
  }},
  "performance_kpis": [
    {{
      "name": "string",
      "value": "string",
      "period": "string",
      "as_of": "string"
    }}
  ],
  "kpi_narrative": "string (3-5 sentences MAX. Concise territory performance summary with key metrics. No repetition.)",
  "competencies": [
    {{
      "name": "string (MUST include ALL 5: Plan, Engage, Advance, Close, Follow-up)",
      "score": null,
      "evidence": "string (1-2 sentences: specific field behaviors observed for this competency)"
    }}
  ],
  "observations": [
    {{
      "area": "string",
      "what_i_saw": "string (2-3 sentences MAX: specific behaviors observed, factual and concise)",
      "impact": "string (1-2 sentences MAX: why this matters for HCP engagement or patient outcomes)"
    }}
  ],
  "core_capabilities": {{
    "categories": ["string (relevant from: Clinical Sell/Differentiation, Problem Solving, Access Navigation, Account Based Selling, Omnichannel, Orchestration with NVS Team)"],
    "comments": "string (1-2 sentences: brief observation on core capability demonstrated or needing development)"
  }},
  "smart_actions": [
    {{
      "action": "string (1 sentence: what exactly will be done, with whom)",
      "measurable": "string (1 sentence: how success is quantified)",
      "achievable": "string (1 sentence: why realistic)",
      "relevant": "string (1 sentence: connection to gap)",
      "time_bound": "string (specific date)",
      "due": "string (date)"
    }}
  ],
  "compliance": {{
    "ae_reporting": "— Insufficient data",
    "fair_balance": "— Insufficient data",
    "prescribing_info": "— Insufficient data",
    "materials_approved": "— Insufficient data",
    "samples_managed": "— Insufficient data"
  }},
  "status": "draft_created"
}}

Important:
- Always assign scores (1-5) for all competencies based on observed evidence. Use the OneBreakaway scoring rubric: 1=not observed/critical gap, 2=inconsistent/developing, 3=meets expectations, 4=exceeds/role model, 5=exceptional/coaches others.
- Be CONCISE. Observations: 2-3 sentences for what_i_saw, 1-2 for impact. Evidence/rationale: 1-2 sentences max. No repetition, no filler.
- Do NOT fill in compliance fields — leave them as "— Insufficient data". Compliance is entered separately by the ABL after the field visit.
- Return only JSON.
"""

    final_prompt = f"{base_prompt}\n\n{user_context}"

    print("🔷 Drafting FCR — calling LLM (this is the longest step)")
    bedrock = BedrockClient()
    model_id = None

    llm_output = bedrock.invoke_claude(
        prompt=final_prompt,
        model_id=model_id,
        max_tokens=8192,
        temperature=0.0,
    )

    if not llm_output:
        return {
            "draft": {
                "fcr_id": f"FCR-{state.get('session_id')}",
                "status": "draft_failed",
                "error": "LLM returned no output",
            }
        }

    cleaned_output = clean_json_text(llm_output)

    try:
        draft = json.loads(cleaned_output)
    except json.JSONDecodeError:
        # Try to fix truncated JSON (LLM hit max_tokens)
        attempt = cleaned_output.rstrip().rstrip(',')
        open_braces = attempt.count('{') - attempt.count('}')
        open_brackets = attempt.count('[') - attempt.count(']')
        attempt += ']' * open_brackets + '}' * open_braces
        try:
            draft = json.loads(attempt)
        except json.JSONDecodeError:
            draft = {
                "fcr_id": f"FCR-{state.get('session_id')}",
                "status": "draft_created_with_raw_output",
                "raw_llm_output": llm_output,
            }

    return {
        "draft": draft,
    }


def rubric_check_node(state: WorkflowState) -> Dict[str, Any]:
    return RubricCheckNode(dict(state)).run()


def clarify_node(state: WorkflowState) -> Dict[str, Any]:
    return ClarifyNode(dict(state)).run()


def revise_node(state: WorkflowState) -> Dict[str, Any]:
    return ReviseNode(dict(state)).run()


def finalize_export_node(state: WorkflowState) -> Dict[str, Any]:
    draft = state.get("draft")

    if not draft:
        return {}

    if draft.get("error"):
        return {
            "draft": draft,
        }

    if draft.get("status") in ["draft_failed", "draft_created_with_raw_output"]:
        return {
            "draft": draft,
        }

    updated_draft = dict(draft)
    updated_draft["status"] = "finalized"

    return {
        "draft": updated_draft,
    }


def pattern_mining_node(state: WorkflowState) -> Dict[str, Any]:
    from app.src.graph.nodes.pattern_mining_node import PatternMiningNode
    return PatternMiningNode(dict(state)).run()


def memory_update_node(state: WorkflowState) -> Dict[str, Any]:
    from app.src.graph.nodes.memory_update_node import MemoryUpdateNode
    return MemoryUpdateNode(dict(state)).run()


def should_revise(state: WorkflowState) -> str:
    """Determine if draft needs revision or can be finalized."""
    qa = state.get("qa", {})
    if qa.get("user_response") == "no" or not qa.get("has_issues"):
        return "finalize_export_node"
    return "revise_node"


def create_workflow():
    workflow = StateGraph(WorkflowState)

    # Add all nodes
    workflow.add_node("intake_node", intake_node)
    workflow.add_node("kpi_analysis_node", kpi_analysis_node)
    workflow.add_node("retrieval_node", retrieval_node_wrapper)
    workflow.add_node("question_planner_node", question_planner_node)
    workflow.add_node("ask_user_node", ask_user_node)
    workflow.add_node("draft_fcr_node", draft_fcr_node)
    workflow.add_node("rubric_check_node", rubric_check_node)
    workflow.add_node("clarify_node", clarify_node)
    workflow.add_node("revise_node", revise_node)
    workflow.add_node("finalize_export_node", finalize_export_node)
    workflow.add_node("memory_update_node", memory_update_node)
    workflow.add_node("pattern_mining_node", pattern_mining_node)

    # Build flow - Questions are SKIPPED for chat interface (handled separately)
    workflow.add_edge(START, "intake_node")
    workflow.add_edge("intake_node", "kpi_analysis_node")
    workflow.add_edge("kpi_analysis_node", "retrieval_node")
    workflow.add_edge("retrieval_node", "draft_fcr_node")  # Skip questions, go direct to draft

    # Rest of the workflow continues as before
    workflow.add_edge("draft_fcr_node", "rubric_check_node")
    workflow.add_edge("rubric_check_node", "clarify_node")

    # Conditional routing: revise if issues found, otherwise finalize
    workflow.add_conditional_edges(
        "clarify_node",
        should_revise,
        {
            "revise_node": "revise_node",
            "finalize_export_node": "finalize_export_node",
        },
    )

    workflow.add_edge("revise_node", "finalize_export_node")
    workflow.add_edge("finalize_export_node", "memory_update_node")
    workflow.add_edge("memory_update_node", "pattern_mining_node")
    workflow.add_edge("pattern_mining_node", END)

    return workflow.compile()


graph = create_workflow()
