"""
Pattern Mining Node - Uses LLM to extract coaching patterns from finalized FCRs.
 
Extracts rich coaching intelligence for TAS coaching profile:
- Consistent strengths
- Development areas
- Coaching themes with status
- Progress indicators vs past FCRs
- Suggested next coaching focus
- Action plan tracking
"""
 
import json
import re
from typing import Dict, Any, List
from datetime import datetime
 
from app.src.llm.bedrock_client import BedrockClient
 
 
PATTERN_EXTRACTION_PROMPT = """You are a pharmaceutical field coaching analyst. Analyze this Field Coaching Report (FCR) and extract coaching patterns.
 
**Current FCR:**
```json
{fcr_json}
```
 
**Past FCRs (last 3, most recent first):**
```json
{past_fcrs_json}
```
 
**TAS ID:** {tas_id}
**Month:** {month}

CRITICAL NAME RULE: Use ONLY the name "{tas_id}" when referring to the TAS. Do NOT use any other name.
 
Extract the following in JSON format:
 
{{
  "strengths": [
    {{
      "area": "string (e.g., Doctor Engagement, Product Knowledge)",
      "evidence": "string (specific observation from FCR)",
      "consistency": "sustained|emerging|new"
    }}
  ],
  "development_areas": [
    {{
      "area": "string (e.g., Objection Handling, Closing)",
      "evidence": "string (specific observation from FCR)",
      "pattern_status": "repeated_gap|new_gap|improving|worsened"
    }}
  ],
  "coaching_themes": [
    {{
      "theme": "string (e.g., Call Planning, Scientific Discussion, Closing)",
      "status": "needs_work|improving|improved|sustained_strength|not_observed",
      "evidence": "string (brief evidence)"
    }}
  ],
  "competency_scores": [
    {{
      "name": "string (competency name)",
      "trend": "strength|improving|needs_development|declining",
      "current_evidence": "string"
    }}
  ],
  "progress_vs_past": {{
    "improved_areas": ["string"],
    "continued_gaps": ["string"],
    "new_issues": ["string"],
    "resolved_areas": ["string"],
    "overall_trend": "improving|stable|declining|mixed"
  }},
  "action_plan_status": [
    {{
      "action": "string (from previous FCR SMART actions)",
      "status": "completed|in_progress|not_started|repeated|not_observed",
      "evidence": "string (what was observed this month)"
    }}
  ],
  "next_coaching_focus": {{
    "primary": "string (top priority for next month)",
    "secondary": "string (secondary focus)",
    "rationale": "string (why these were chosen)"
  }},
  "ai_coaching_summary": "string (3-5 sentence narrative summary of TAS coaching status, progress, and recommendation)"
}}
 
Rules:
- Base everything on evidence in the FCR, not assumptions.
- A competency/area CANNOT appear in both strengths and development_areas. If it improved to a strength in the current FCR, it is a strength ONLY — remove it from development areas. If it still needs work, it is a development area ONLY.
- For progress_vs_past, compare current FCR against past FCRs provided. If something was previously a development area but is now strong, list it in "resolved_areas" and "improved_areas", NOT in development_areas.
- If no past FCRs exist, set overall_trend to "baseline" and note this is the first FCR.
- For action_plan_status, look at previous FCR SMART actions and assess if they were addressed.
- Keep the AI coaching summary business-friendly and actionable.
- Return only valid JSON.
"""
 
 
def clean_json_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*\n?", "", text)
    text = re.sub(r"\n?\s*```\s*$", "", text)
    return text.strip()
 
 
class PatternMiningNode:
    """Mines coaching patterns from finalized FCR using LLM."""
 
    def __init__(self, state: Dict[str, Any]):
        self.state = state
        self.draft = state.get("draft", {})
        self.tas_id = state.get("tas_id")
        self.month = state.get("month")
        self.context_bundle = state.get("context_bundle", {})
 
    def run(self) -> Dict[str, Any]:
        if not self.draft or not self.tas_id:
            return {
                "pattern_mining": {
                    "status": "skipped",
                    "reason": "Missing draft or TAS ID",
                }
            }
 
        try:
            patterns = self._extract_patterns_with_llm()
            patterns["tas_id"] = self.tas_id
            patterns["month"] = self.month
            patterns["extracted_at"] = datetime.now().isoformat()
 
            print(f"[PatternMining] Extracted patterns for {self.tas_id}")
            print(f"  Strengths: {len(patterns.get('strengths', []))}")
            print(f"  Development areas: {len(patterns.get('development_areas', []))}")
            print(f"  Next focus: {patterns.get('next_coaching_focus', {}).get('primary', 'N/A')}")
 
            return {
                "pattern_mining": {
                    "status": "completed",
                    "patterns": patterns,
                }
            }
        except Exception as e:
            print(f"[PatternMining] LLM extraction failed: {e}, falling back to basic extraction")
            import traceback
            traceback.print_exc()
            patterns = self._fallback_extraction()
            return {
                "pattern_mining": {
                    "status": "completed_fallback",
                    "patterns": patterns,
                }
            }
 
    def _extract_patterns_with_llm(self) -> Dict[str, Any]:
        # Load memory index for historical context
        from app.src.graph.nodes.memory_update_node import MemoryUpdateNode
        memory_index = MemoryUpdateNode.load_memory_for_tas(self.tas_id)

        # Build past context from memory index (richer) or fall back to context_bundle
        past_fcrs_trimmed = []
        if memory_index and memory_index.get("sessions"):
            # Use memory index sessions for richer history
            for session in memory_index["sessions"][-3:]:
                past_fcrs_trimmed.append({
                    "month": session.get("month", ""),
                    "coaching_focus": session.get("coaching_focus", ""),
                    "strengths": session.get("strengths", []),
                    "dev_areas": session.get("dev_areas", []),
                    "theme_statuses": session.get("theme_statuses", {}),
                    "trajectory": session.get("trajectory", ""),
                })
        else:
            # Fall back to context_bundle past FCRs
            past_fcr_context = self.context_bundle.get("past_fcr_context", {})
            past_fcrs = past_fcr_context.get("latest_3_fcrs_as_is", [])
            for fcr in past_fcrs[:3]:
                fcr_json = fcr.get("fcr_json", {})
                if isinstance(fcr_json, dict):
                    # Handle both nested (Andie Miller) and flat (Eddie Bahri) FCR formats
                    competencies = fcr_json.get("competencies", [])
                    if not competencies and "OneBreakaway Selling Approach" in fcr_json:
                        competencies = fcr_json["OneBreakaway Selling Approach"]
                    observations = fcr_json.get("observations", [])
                    if not observations and "Observations" in fcr_json:
                        observations = fcr_json["Observations"]
                    smart_actions = fcr_json.get("smart_actions", [])
                    if not smart_actions and "SMART Action Steps" in fcr_json:
                        smart_actions = fcr_json["SMART Action Steps"]
                    summary = fcr_json.get("summary", "")
                    if not summary:
                        # Flat format: try metadata or observations for summary
                        meta = fcr_json.get("metadata", {})
                        summary = meta.get("coachee", fcr_json.get("Coachee", ""))
                    past_fcrs_trimmed.append({
                        "month": fcr.get("fcr_date") or fcr_json.get("month", ""),
                        "summary": summary,
                        "competencies": competencies,
                        "observations": observations,
                        "smart_actions": smart_actions,
                    })

        # Include frequency data and pattern tracker if available
        memory_context = ""
        if memory_index:
            recurring_str = memory_index.get("recurring_strengths", {})
            recurring_dev = memory_index.get("recurring_development_areas", {})
            pattern_tracker = memory_index.get("pattern_tracker", {})
            if recurring_str or recurring_dev or pattern_tracker:
                memory_context = f"""
MEMORY CONTEXT (frequency across {memory_index.get('total_fcrs', 0)} FCRs):
- Recurring strengths: {json.dumps(recurring_str, default=str)}
- Recurring development areas: {json.dumps(recurring_dev, default=str)}
- Pattern tracker: {json.dumps(pattern_tracker, default=str)[:500]}
- Latest trajectory: {memory_index.get('trajectory', 'unknown')}
"""
 
        prompt = PATTERN_EXTRACTION_PROMPT.format(
            fcr_json=json.dumps(self.draft, indent=2, default=str)[:4000],
            past_fcrs_json=json.dumps(past_fcrs_trimmed, indent=2, default=str)[:3000] + memory_context,
            tas_id=self.tas_id,
            month=self.month or "current",
        )
 
        bedrock = BedrockClient()
        llm_output = bedrock.invoke_claude(
            prompt=prompt,
            model_id=None,
            max_tokens=4096,
            temperature=0.0,
        )
 
        cleaned = clean_json_text(llm_output)
        result = json.loads(cleaned)

        # Enforce: a competency CANNOT appear in both strengths and development_areas
        strength_areas = {s.get("area", "").lower().strip() for s in result.get("strengths", []) if isinstance(s, dict) and s.get("area")}
        result["development_areas"] = [
            d for d in result.get("development_areas", [])
            if (d.get("area", "") if isinstance(d, dict) else str(d)).lower().strip() not in strength_areas
        ]

        return result
 
    def _fallback_extraction(self) -> Dict[str, Any]:
        """Basic extraction if LLM fails."""
        return {
            "tas_id": self.tas_id,
            "month": self.month,
            "extracted_at": datetime.now().isoformat(),
            "strengths": [],
            "development_areas": [],
            "coaching_themes": [],
            "competency_scores": [],
            "progress_vs_past": {"overall_trend": "unknown"},
            "action_plan_status": [],
            "next_coaching_focus": {"primary": "Review needed", "secondary": "", "rationale": "LLM extraction failed"},
            "ai_coaching_summary": "Pattern extraction was not available for this FCR. Manual review recommended.",
        }