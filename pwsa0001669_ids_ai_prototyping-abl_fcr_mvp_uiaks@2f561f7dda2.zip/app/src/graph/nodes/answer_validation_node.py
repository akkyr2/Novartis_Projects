"""
Answer Validation Node - Ensures answers are complete and sufficient.
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple


def validate_answer(answer: str, expected_type: str, question: Dict) -> Tuple[bool, str]:
    """
    Validate a single answer for completeness and quality.

    Args:
        answer: The user's answer text
        expected_type: "narrative" or "list"
        question: The question dictionary with purpose and prompts

    Returns:
        (is_valid, feedback_message)
    """
    answer = answer.strip()

    if not answer:
        return False, "Please provide an answer"

    # Minimum length checks
    if expected_type == "narrative":
        if len(answer) < 30:
            return False, "Please provide more detail (at least 30 characters). Share specific observations or examples."

        # Check for specific content based on question purpose
        purpose_lower = question.get("purpose", "").lower()
        track = question.get("track", "").lower()

        # Only enforce strict observation rules for Phase 1 field observation questions
        # Phase 2 (kpi, seam_prework) questions should NOT require medical context words
        is_field_observation = track not in ("kpi", "seam_prework") and ("observation" in purpose_lower or "coaching" in purpose_lower or "field" in purpose_lower)

        if is_field_observation:
            # Should mention customer, doctor, visit, or specific interaction
            if not any(word in answer.lower() for word in ["customer", "doctor", "visit", "call", "meeting", "dr.", "clinic", "hospital", "hcp", "physician", "rep", "tas"]):
                return False, "Please describe the specific customer interaction or field visit context"

            # Should have some specificity (not just "did well")
            vague_only = all(phrase in answer.lower() for phrase in ["did well", "good", "fine"])
            if len(answer) < 80 and vague_only:
                return False, "Please provide specific examples of what you observed (behaviors, interactions, outcomes)"

        if "strength" in purpose_lower:
            # Should have at least 2 distinct strengths or substantial detail
            if len(answer) < 50 and answer.count(",") < 1 and answer.count(" and ") < 1:
                return False, "Please mention at least 2 specific strengths or provide more detail about the strength observed"

            # Should not be too generic
            if any(generic in answer.lower() for generic in ["did good", "was fine", "ok", "adequate"]) and len(answer) < 60:
                return False, "Please be more specific about what strengths you observed (e.g., 'Strong clinical knowledge - cited recent studies')"

        if "opportunity" in purpose_lower or "improve" in purpose_lower:
            # Should be constructive and specific
            if len(answer) < 40:
                return False, "Please provide specific details about the development opportunity"

            # Should not be overly negative without constructiveness
            if "bad" in answer.lower() or "poor" in answer.lower():
                if not any(word in answer.lower() for word in ["could", "would", "improve", "develop", "enhance"]):
                    return False, "Please frame as a development opportunity (what they could do differently) rather than just what was wrong"

        if "action" in purpose_lower or "next step" in purpose_lower:
            # Should have actionable items with verbs
            if not any(word in answer.lower() for word in ["will", "practice", "review", "improve", "work on", "complete", "schedule", "meet"]):
                return False, "Please include specific action items with clear next steps (e.g., 'Will practice closing scenarios in next team meeting')"

            # Should have some specificity
            if len(answer) < 40:
                return False, "Please provide more detail about the action items (what, when, how)"

        if "impact" in purpose_lower:
            # Should explain consequences or importance
            if not any(word in answer.lower() for word in ["because", "impact", "result", "affect", "improve", "increase", "decrease", "help", "enable"]):
                return False, "Please explain why this matters - how it impacts performance or results"

    elif expected_type == "list":
        # For competencies or lists
        items = [item.strip() for item in answer.replace("\n", ",").split(",") if item.strip()]

        if len(items) < 1:
            return False, "Please provide at least one item"

        # Check if asking for competencies
        if "competenc" in question.get("purpose", "").lower():
            if len(items) < 1:
                return False, "Please select at least 1-2 competencies"

            # Items should be substantial (not just "good" or "ok")
            if all(len(item) < 5 for item in items):
                return False, "Please provide full competency names (e.g., 'Selling Skills', 'Clinical Knowledge')"

    # Passed all checks
    return True, ""


def get_answer_improvement_suggestion(answer: str, expected_type: str, question: Dict) -> str:
    """
    Provide a helpful suggestion to improve the answer.

    Returns:
        Improvement suggestion text
    """
    purpose_lower = question.get("purpose", "").lower()

    if "observation" in purpose_lower:
        return "💡 Tip: Include details like: Where was the visit? Who was the customer? What product/topic was discussed? What specific behaviors did you observe?"

    elif "strength" in purpose_lower:
        return "💡 Tip: Be specific. Instead of 'good presenter', say 'confidently presented clinical data, cited 3 recent studies, answered physician questions thoroughly'"

    elif "opportunity" in purpose_lower:
        return "💡 Tip: Frame constructively. Instead of 'bad at closing', say 'could improve closing by asking direct commitment questions'"

    elif "action" in purpose_lower:
        return "💡 Tip: Make it SMART. Instead of 'practice more', say 'Will practice 3 closing scenarios in Friday team meeting and schedule role-play with manager by next week'"

    elif "competenc" in purpose_lower:
        return "💡 Tip: List 2-3 competencies like: Selling Skills, Clinical Knowledge, Territory Management, Customer Engagement"

    return "💡 Tip: Provide more specific details and examples"
