# Retrieval Node - Enhanced Implementation

## Overview

The `retrieval_node` is responsible for gathering all contextual information needed to draft a high-quality Field Coaching Report (FCR). It acts as the **RAG (Retrieval-Augmented Generation) orchestrator** that assembles:

1. **Historical FCR Context** - Past coaching reports for pattern recognition
2. **Guideline Context** - Writing guidelines, rubrics, and example FCRs (via RAG)
3. **KPI Context** - Performance metrics to ground coaching observations

---

## Architecture

```
retrieval_node
    ├── Historical FCR Retrieval (S3FCRService)
    │   ├── Fetch past FCR JSON records from S3
    │   ├── Sort by date (latest → oldest)
    │   ├── Keep latest 3 FCRs as-is
    │   └── Summarize older FCRs
    │
    ├── Guideline Retrieval (GuidelineRetrievalService)
    │   ├── Generate query embedding via Bedrock Titan
    │   ├── Search OpenSearch vector store
    │   ├── Retrieve:
    │   │   ├── FCR writing guidelines
    │   │   ├── Rubric evaluation criteria
    │   │   ├── Example FCR snippets
    │   │   └── Coaching framework guidance
    │   └── Return curated references
    │
    └── KPI Retrieval (KPIRetrievalService)
        ├── Fetch TAS performance metrics from S3
        ├── Aggregate metrics (calls, sales, coverage, etc.)
        ├── Analyze trends (improving vs declining)
        └── Build KPI summary
```

---

## Components

### 1. Historical FCR Retrieval

**Service:** `S3FCRService`

**Purpose:** Retrieve past FCRs for the TAS to identify coaching patterns and developmental trends.

**Data Flow:**
```python
tas_id → S3FCRService.fetch_past_fcrs() → 
    [FCR records sorted by date] → 
    latest_3_fcrs_as_is + older_fcr_summary
```

**Output:**
- `latest_3_fcrs_as_is`: Full JSON of 3 most recent FCRs
- `older_fcr_summary`: Summarized patterns from older FCRs
- `historical_fcr_count`: Total FCRs found

---

### 2. Guideline Retrieval (RAG)

**Service:** `GuidelineRetrievalService`

**Purpose:** Retrieve relevant FCR writing guidelines, rubric criteria, and example snippets to ensure quality and alignment.

**Components:**

#### a. Bedrock Embeddings Service
- **Model:** Amazon Titan Embeddings v2 (`amazon.titan-embed-text-v2:0`)
- **Dimension:** 1024-dimensional vectors
- **Purpose:** Generate embeddings for semantic search

#### b. OpenSearch Vector Store
- **Index:** `fcr-guidelines`
- **Search Methods:**
  - **Semantic Search:** k-NN vector similarity
  - **Hybrid Search:** Vector + keyword matching

**Document Types Indexed:**
1. `guideline` - FCR writing guidelines
2. `rubric` - Evaluation criteria and rubric standards
3. `example` - Good FCR examples
4. `coaching_framework` - Coaching approach guidance (e.g., SEAM, strength/opportunity framing)

**Retrieval Query:**
```python
coaching_context = build_summary(prework, eval_text, observation, SEAM notes)
competencies = extract_competencies(state)

guideline_service.retrieve_comprehensive_context(
    coaching_context=coaching_context,
    competencies=competencies,
    coaching_type="developmental",
    include_examples=True
)
```

**Output:**
- `guidelines`: Relevant writing guideline chunks
- `rubric_criteria`: Applicable rubric evaluation criteria
- `coaching_framework`: Coaching approach guidance
- `examples`: Similar FCR example snippets
- `retrieval_counts`: Number of chunks retrieved per category

---

### 3. KPI Retrieval

**Service:** `KPIRetrievalService`

**Purpose:** Fetch TAS performance metrics to provide data-driven context for coaching observations.

**Data Flow:**
```python
(tas_id, month, territory) → KPIRetrievalService.fetch_tas_kpis() →
    [KPI records from S3] →
    kpi_summary + trend_analysis
```

**Metrics Tracked:**
- `calls_completed`, `call_target`, `call_completion_rate`
- `customer_coverage`, `new_customer_acquisitions`
- `product_presentations`, `samples_distributed`
- `territory_sales`, `sales_target`, `sales_attainment`
- `customer_satisfaction_score`, `compliance_score`

**Output:**
- `kpi_summary`: Aggregated metrics with averages and totals
- `highlights`: Strong performance areas (≥90%)
- `areas_of_concern`: Below-target metrics (<70%)
- `trends`: Direction (improving/declining/stable) with narrative

---

## Context Bundle Structure

The retrieval node outputs a comprehensive `context_bundle` to state:

```python
{
    "past_fcr_context": {
        "status": "success",
        "tas_id": "TAS_12345",
        "abl_id": "ABL_67890",
        "month": "2026-05",
        "territory": "NY_METRO",
        "historical_fcr_count": 8,
        "latest_3_fcrs_as_is": [...],  # Full JSON of 3 recent FCRs
        "older_fcr_summary": "...",     # Summarized patterns
        "instruction_for_draft_node": "..."
    },
    
    "guideline_context": {
        "status": "success",
        "guidelines": [
            {
                "id": "...",
                "score": 0.89,
                "content": "FCR writing guideline text...",
                "document_type": "guideline",
                "source": "Writing Effective Field Coaching Reports_Job Aid Final V1.0 (002).pdf",
                "section": null,
                "metadata": {...}
            },
            ...
        ],
        "rubric_criteria": [...],      # Rubric evaluation chunks
        "coaching_framework": [...],   # Coaching approach guidance
        "examples": [...],              # Example FCR snippets
        "retrieval_counts": {
            "guidelines": 5,
            "rubric_criteria": 3,
            "coaching_framework": 3,
            "examples": 3
        },
        "instruction": "..."
    },
    
    "kpi_context": {
        "status": "success",
        "tas_id": "TAS_12345",
        "month": "2026-05",
        "territory": "NY_METRO",
        "kpi_summary": {
            "tas_id": "TAS_12345",
            "month": "2026-05",
            "record_count": 3,
            "metrics": {
                "call_completion_rate": {
                    "values": [92, 88, 90],
                    "average": 90.0,
                    "latest": 90
                },
                "sales_attainment": {
                    "values": [78, 82, 85],
                    "average": 81.7,
                    "latest": 85
                },
                ...
            },
            "highlights": [
                "Strong call_completion_rate: 90.0%"
            ],
            "areas_of_concern": [],
            "trends": {
                "direction": "improving",
                "improving_metrics": ["sales_attainment"],
                "declining_metrics": [],
                "analysis": "Showing improvement in: sales attainment."
            }
        },
        "metrics": [...],  # Raw KPI records
        "instruction": "..."
    }
}
```

---

## Setup Instructions

### 1. Environment Variables

Set the following environment variables:

```bash
# AWS Configuration
AWS_REGION=us-east-1

# FCR S3 Storage
FCR_S3_BUCKET=abl-field-coaching-reports
FCR_S3_PREFIX=extracted_json

# KPI S3 Storage
KPI_S3_BUCKET=abl-kpi-data
KPI_S3_PREFIX=kpi_reports

# OpenSearch Vector Store
OPENSEARCH_HOST=your-opensearch-endpoint.us-east-1.aoss.amazonaws.com
```

### 2. Index Guideline PDFs

Run the indexing script to populate the OpenSearch vector store:

```bash
cd app/scripts
python index_guidelines.py
```

This will:
1. Extract text from PDFs in `app/data/`
2. Chunk content into semantic sections
3. Generate embeddings using Bedrock Titan v2
4. Index into OpenSearch with metadata

**Expected PDFs:**
- `Final RD_FCR_2-Pager_WEB_F.pdf` - FCR guideline
- `Good example of FCR.pdf` - Example FCRs
- `Writing Effective Field Coaching Reports_Job Aid Final V1.0 (002).pdf` - Writing guidelines
- `One BA Coaching Guide v1_6.8.23.pdf` - Coaching framework

### 3. Verify Setup

Test the retrieval node:

```python
from graph.nodes.retrieval_node import retrieval_node

state = {
    "tas_id": "TAS_12345",
    "abl_id": "ABL_67890",
    "month": "2026-05",
    "territory": "NY_METRO",
    "tas_prework_text": "Customer call with Dr. Smith...",
    "abl_eval_text": "TAS demonstrated strong selling skills...",
    "selected_competencies": ["Selling Skills", "Clinical Knowledge"]
}

result = retrieval_node(state)

print("Retrieval Status:", result["retrieval_status"])
print("Historical FCRs:", result["historical_fcr_count"])
print("Guidelines Retrieved:", result["context_bundle"]["guideline_context"]["retrieval_counts"])
print("KPI Summary:", result["context_bundle"]["kpi_context"]["kpi_summary"])
```

---

## Dependencies

### Python Packages

```bash
pip install boto3 opensearch-py PyPDF2
```

### AWS Services

1. **Amazon Bedrock** - Titan Embeddings v2 model access
2. **Amazon OpenSearch Serverless** - Vector store
3. **Amazon S3** - FCR and KPI storage
4. **IAM Permissions:**
   - `bedrock:InvokeModel` (for Titan Embeddings)
   - `aoss:*` (for OpenSearch Serverless)
   - `s3:GetObject`, `s3:ListBucket` (for S3 access)

---

## Error Handling

The retrieval node is **resilient** and continues even if individual components fail:

- **Historical FCR failure**: Returns empty context, node proceeds
- **Guideline RAG failure**: Falls back to general best practices
- **KPI retrieval failure**: Proceeds with behavioral observations only

Each component returns a `status` field:
- `"success"` - Retrieved successfully
- `"error"` - Failed with error details
- `"missing_tas_id"` - Required identifier missing
- `"no_kpis_found"` - No KPI data available

---

## Next Steps

1. **Test the retrieval node** with real TAS data
2. **Validate guideline retrieval** quality and relevance
3. **Monitor KPI data coverage** across territories
4. **Tune RAG parameters** (top_k, min_score, chunk_size)
5. **Integrate with draft_fcr_node** to consume context_bundle

---

## Related Nodes

- **preprocess_node** → Normalizes inputs before retrieval
- **question_planner_node** → Uses context_bundle to detect gaps
- **draft_fcr_node** → Consumes context_bundle to generate FCR
- **rubric_check_node** → Uses guideline_context for quality validation
