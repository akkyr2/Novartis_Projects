from typing import List, Dict, Any

class ClarifyNode:
    def __init__(self, state: Dict[str, Any]):
        self.state = state

    def run(self) -> Dict[str, Any]:
        issues = self.state.get("qa", {}).get("issues", [])
        questions_to_user = [self.generate_question(issue) for issue in issues]

        return {
            "qa": {
                **self.state.get("qa", {}),
                "questions_to_user": questions_to_user,
            }
        }

    def generate_question(self, issue: str) -> str:
        return f"What clarification can you provide regarding the issue: {issue}?"