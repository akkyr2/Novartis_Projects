"""
Ask User Node - Interactively collects missing information from ABL.

This node presents questions to the ABL and captures their responses.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def ask_user_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Present questions to ABL and collect responses.

    This node:
    1. Takes questions from question_planner_node
    2. Presents them to the user (ABL) for answers
    3. Stores answers back into state
    4. Enriches state with collected information

    In a real implementation, this would integrate with:
    - Web UI form
    - Chat interface
    - Voice input system
    - API endpoint

    For now, this returns a structure indicating questions to ask.

    Returns:
        State update with:
        - questions_to_ask: Formatted questions for UI
        - questions_asked: Flag that questions were presented
        - awaiting_user_input: Flag for orchestrator
    """
    questions_needed = state.get("questions_needed") or []

    if not questions_needed:
        return {
            "questions_to_ask": [],
            "questions_asked": False,
            "awaiting_user_input": False,
            "ask_user_status": "no_questions_needed",
        }

    # Format questions for presentation
    formatted_questions = _format_questions_for_user(questions_needed, state)

    # Check if user has already provided answers
    user_answers = state.get("user_answers") or {}

    if user_answers:
        # User has provided answers, enrich state
        enriched_state = _enrich_state_with_answers(state, questions_needed, user_answers)
        enriched_state.update({
            "questions_asked": True,
            "awaiting_user_input": False,
            "ask_user_status": "answers_received",
        })
        return enriched_state

    # Questions need to be asked
    return {
        "questions_to_ask": formatted_questions,
        "questions_asked": True,
        "awaiting_user_input": True,
        "ask_user_status": "questions_presented",
        "user_answers": {},  # Initialize empty answers dict
    }


def _format_questions_for_user(
    questions: List[Dict[str, Any]],
    state: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    Format questions for user-friendly presentation.

    Returns:
        List of formatted question dictionaries ready for UI
    """
    tas_name = state.get("tas_name") or "TAS"
    month = state.get("month") or "this month"

    formatted = []

    for idx, question in enumerate(questions, start=1):
        formatted.append({
            "question_id": f"q{idx}",
            "question_number": idx,
            "question_text": question.get("question", ""),
            "purpose": question.get("purpose", ""),
            "expected_answer_type": question.get("expected_answer_type", "narrative"),
            "prompts": question.get("prompts", []),
            "context": {
                "tas_name": tas_name,
                "month": month,
            },
            "ui_hints": {
                "multiline": question.get("expected_answer_type") == "narrative",
                "min_length": 50 if question.get("expected_answer_type") == "narrative" else 10,
                "placeholder": _generate_placeholder(question),
            },
        })

    return formatted


def _generate_placeholder(question: Dict[str, Any]) -> str:
    """
    Generate placeholder text for question input field.

    Returns:
        Placeholder string
    """
    answer_type = question.get("expected_answer_type", "narrative")

    if answer_type == "list":
        return "Enter items separated by commas or new lines..."
    elif answer_type == "narrative":
        return "Describe your observations and details here..."
    else:
        return "Enter your answer..."


def _enrich_state_with_answers(
    state: Dict[str, Any],
    questions: List[Dict[str, Any]],
    user_answers: Dict[str, str],
) -> Dict[str, Any]:
    """
    Enrich state with user-provided answers.

    Maps answers to appropriate state keys based on question types.

    Returns:
        State updates with enriched information
    """
    updates = {}

    for idx, question in enumerate(questions, start=1):
        question_id = f"q{idx}"
        answer = user_answers.get(question_id, "").strip()

        if not answer:
            continue

        # Map answer to appropriate state key based on question purpose
        purpose_lower = question.get("purpose", "").lower()

        if "observation" in purpose_lower or "field visit" in purpose_lower:
            updates["observation_notes"] = answer
            updates["abl_eval_text"] = updates.get("abl_eval_text", "") + f"\n\n{answer}"

        elif "competency" in purpose_lower or "skill" in purpose_lower:
            # Parse competencies (could be comma-separated or newline-separated)
            competencies = _parse_list_answer(answer)
            updates["selected_competencies"] = competencies

        elif "strength" in purpose_lower:
            updates["observed_strengths"] = answer

        elif "opportunity" in purpose_lower or "improve" in purpose_lower:
            updates["development_opportunities"] = answer

        elif "impact" in purpose_lower:
            updates["impact_statement"] = answer

        elif "action" in purpose_lower or "next steps" in purpose_lower:
            updates["action_items"] = answer

        elif "seam" in purpose_lower or "conversation" in purpose_lower:
            updates["seam_notes"] = answer

        elif "context" in purpose_lower or "developmental" in purpose_lower:
            updates["developmental_context"] = answer

        elif "kpi" in purpose_lower or "metric" in purpose_lower:
            updates["kpi_notes"] = answer

        # Also store in a structured answers collection
        if "collected_answers" not in updates:
            updates["collected_answers"] = {}

        updates["collected_answers"][question_id] = {
            "question": question.get("question", ""),
            "answer": answer,
            "purpose": question.get("purpose", ""),
        }

    return updates


def _parse_list_answer(answer: str) -> List[str]:
    """
    Parse a list-type answer (comma or newline separated).

    Returns:
        List of parsed items
    """
    # Try newline first
    if "\n" in answer:
        items = [item.strip() for item in answer.split("\n")]
    # Then comma
    elif "," in answer:
        items = [item.strip() for item in answer.split(",")]
    # Otherwise treat as single item
    else:
        items = [answer.strip()]

    # Filter out empty items
    return [item for item in items if item]


# Utility function for external orchestrator to set answers
def set_user_answers(
    state: Dict[str, Any],
    answers: Dict[str, str],
) -> Dict[str, Any]:
    """
    Utility function to inject user answers into state.

    This would typically be called by the orchestrator/UI layer after
    collecting answers from the ABL.

    Args:
        state: Current state
        answers: Dictionary mapping question_id to answer text

    Returns:
        Updated state with user_answers set
    """
    state["user_answers"] = answers
    return state
