"""Post-FCR node — handles approve/revise/memory-save/new-session after FCR is generated."""
from typing import Dict, Any

from langchain_core.messages import AIMessage, HumanMessage

from app.src.graph.nodes.revise_node import ReviseNode
from app.src.graph.intent_classifier import is_affirmative


def _get_last_user_message(messages: list) -> str:
    for message in reversed(messages):
        if isinstance(message, HumanMessage):
            return message.content.strip()
    return ""


def post_fcr_node(state: dict) -> Dict[str, Any]:
    """Handle approve/revise/memory-save/new-session after FCR is generated."""
    # Import here to avoid circular imports
    from app.src.graph.chat_workflow import _format_fcr_with_rubric

    messages = state.get("messages", [])
    last_user_message = _get_last_user_message(messages)
    lower_msg = last_user_message.lower().strip()

    # ── #2 Request-2: narrow SMART actions to a single preferred action ──────
    # User picked which action to keep from the draft. We only FILTER the existing
    # smart_actions list (no AI/content change) then re-show the draft.
    if lower_msg in ["keep action 1", "keep action 2", "keep both actions"]:
        fcr_result = state.get("fcr_result", {})
        draft = dict(fcr_result.get("draft", {}) or {})
        actions = list(draft.get("smart_actions", []) or [])
        if len(actions) > 1 and lower_msg != "keep both actions":
            idx = 0 if lower_msg == "keep action 1" else 1
            draft["smart_actions"] = [actions[idx]]
            note = f"Kept **Action {idx + 1}** as the final SMART action."
        else:
            note = "Kept **both** SMART actions."

        updated_fcr_result = dict(fcr_result)
        updated_fcr_result["draft"] = draft
        rubric_issues = fcr_result.get("rubric_issues", [])
        competency_scores = fcr_result.get("competency_scores", []) or state.get("competency_scores", [])
        reply = note + "\n\n" + _format_fcr_with_rubric(
            draft, rubric_issues, is_revision=False, competency_scores=competency_scores
        )
        return {
            "fcr_result": updated_fcr_result,
            "awaiting_memory_save": False,
            "awaiting_feedback": False,
            "awaiting_revision_confirm": False,
            "messages": [AIMessage(content=reply)],
        }

    # If waiting for memory save confirmation
    if state.get("awaiting_memory_save"):
        if lower_msg in ["don't save", "dont save", "no", "n", "skip"]:
            return {
                "awaiting_memory_save": False,
                "awaiting_new_session": True,
                "messages": [AIMessage(content="Okay, not saved to memory.\n\n---\n\nWould you like to start coaching another TAS?\n\n[[action:Coach another TAS]]")],
            }
        if lower_msg in ["save", "yes", "y"]:
            # Explicit match for Save button
            pass  # Fall through to is_affirmative below
        if lower_msg in ["save", "yes", "y"] or is_affirmative(last_user_message, context="User was asked whether to save the FCR to memory for coaching pattern tracking"):
            # Save to memory now
            from app.src.graph.nodes.memory_update_node import MemoryUpdateNode
            memory_state = {
                **dict(state),
                "draft": state.get("fcr_result", {}).get("draft", {}),
                "pattern_mining": state.get("pattern_mining", {}),
                # carry the user-edited structured FCR fields (if any) into the memory save
                "edited_fcr_fields": state.get("edited_fcr_fields"),
            }
            memory_result = MemoryUpdateNode(memory_state).run()
            status = memory_result.get("memory_update", {}).get("status")
            print(f"[Memory] Save result: {status}")
            if status == "completed":
                msg = "✅ Saved to memory successfully.\n\n---\n\nWould you like to start coaching another TAS?\n\n[[action:Coach another TAS]]"
            elif status == "skipped":
                reason = memory_result.get("memory_update", {}).get("reason", "unknown")
                msg = f"⚠️ Memory save skipped: {reason}\n\n---\n\nWould you like to start coaching another TAS?\n\n[[action:Coach another TAS]]"
            else:
                error = memory_result.get("memory_update", {}).get("error", "unknown error")
                msg = f"❌ Memory save failed: {error}\n\n---\n\nWould you like to start coaching another TAS?\n\n[[action:Coach another TAS]]"
            return {
                "awaiting_memory_save": False,
                "awaiting_new_session": True,
                "memory_update": memory_result.get("memory_update", {}),
                "messages": [AIMessage(content=msg)],
            }
        else:
            return {
                "awaiting_memory_save": False,
                "awaiting_new_session": True,
                "messages": [AIMessage(content="Okay, not saved to memory.\n\n---\n\nWould you like to start coaching another TAS?\n\n[[action:Coach another TAS]]")],
            }

    # If waiting for new session decision
    if state.get("awaiting_new_session"):
        lower_session = last_user_message.lower().strip()
        if lower_session in ["coach another tas", "start new session", "new session", "yes", "y", "start"]:
            return {
                "awaiting_new_session": False,
                "messages": [AIMessage(content="[[trigger:new_session]]")],
            }
        else:
            return {
                "awaiting_new_session": False,
                "messages": [AIMessage(content="[[trigger:new_session]]")],
            }

    # If we're waiting for user to confirm revision
    if state.get("awaiting_revision_confirm"):
        lower_confirm = last_user_message.lower().strip()
        if lower_confirm in ["yes", "y"]:
            # User confirmed — run revision with stored feedback
            import json
            from app.src.graph.nodes.rubric_check_node import RubricCheckNode

            fcr_result = state.get("fcr_result", {})
            stored_feedback = state.get("user_feedback", last_user_message)
            revise_state = {
                "draft": fcr_result.get("draft", {}),
                "rubric_issues": fcr_result.get("rubric_issues", []),
                "user_feedback": stored_feedback,
                "kpi_analysis": fcr_result.get("kpi_analysis", {}),
            }

            revised_result = ReviseNode(revise_state).run()
            revised_draft = revised_result.get("draft", {})

            if revised_draft.get("status") in ("revision_failed", "revision_failed_parse"):
                reply = "⚠️ **Revision timed out.** The draft is unchanged. You can try again with shorter feedback, or say **yes** to accept the current draft.\n"
                return {
                    "awaiting_revision_confirm": False,
                    "awaiting_feedback": False,
                    "messages": [AIMessage(content=reply)],
                }

            rubric_state = {"draft": revised_draft, "context_bundle": state.get("context_bundle", {})}
            new_rubric_result = RubricCheckNode(rubric_state).run()
            new_rubric_issues = new_rubric_result.get("rubric_issues", [])
            new_competency_scores = new_rubric_result.get("competency_scores", [])

            updated_fcr_result = dict(fcr_result)
            updated_fcr_result["draft"] = revised_draft
            updated_fcr_result["rubric_issues"] = new_rubric_issues

            reply = _format_fcr_with_rubric(revised_draft, new_rubric_issues, is_revision=True, competency_scores=new_competency_scores)

            return {
                "fcr_result": updated_fcr_result,
                "awaiting_revision_confirm": False,
                "awaiting_feedback": False,
                "messages": [AIMessage(content=reply)],
            }
        else:
            # User said No — go back to showing the current FCR
            return {
                "awaiting_revision_confirm": False,
                "awaiting_feedback": False,
                "user_feedback": None,
                "messages": [AIMessage(content="No problem — the FCR remains as is.\n\nDoes this FCR draft look good?\n\n[[action:Approve]] [[action:Revise]]")],
            }

    # If we're waiting for feedback after user said "no"
    if state.get("awaiting_feedback"):
        import json
        from app.src.graph.nodes.rubric_check_node import RubricCheckNode

        # User has provided feedback — run revise
        fcr_result = state.get("fcr_result", {})
        revise_state = {
            "draft": fcr_result.get("draft", {}),
            "rubric_issues": fcr_result.get("rubric_issues", []),
            "user_feedback": last_user_message,
            "kpi_analysis": fcr_result.get("kpi_analysis", {}),
        }

        revised_result = ReviseNode(revise_state).run()
        revised_draft = revised_result.get("draft", {})

        # Check for revision failure
        if revised_draft.get("status") in ("revision_failed", "revision_failed_parse"):
            reply = "⚠️ **Revision timed out.** The draft is unchanged. You can try again with shorter feedback, or say **yes** to accept the current draft.\n"
            return {
                "awaiting_feedback": False,
                "messages": [AIMessage(content=reply)],
            }

        # Run rubric check on revised draft
        rubric_state = {"draft": revised_draft, "context_bundle": state.get("context_bundle", {})}
        new_rubric_result = RubricCheckNode(rubric_state).run()
        new_rubric_issues = new_rubric_result.get("rubric_issues", [])
        new_competency_scores = new_rubric_result.get("competency_scores", [])

        # Update fcr_result
        updated_fcr_result = dict(fcr_result)
        updated_fcr_result["draft"] = revised_draft
        updated_fcr_result["rubric_issues"] = new_rubric_issues

        # Show revised FCR + new rubric + yes/no
        reply = _format_fcr_with_rubric(revised_draft, new_rubric_issues, is_revision=True, competency_scores=new_competency_scores)

        return {
            "fcr_result": updated_fcr_result,
            "awaiting_feedback": False,
            "messages": [AIMessage(content=reply)],
        }

    if is_affirmative(last_user_message, context="User was asked if the FCR draft is okay or wants to revise"):
        # User accepts — show the final FCR and ask about memory save
        fcr_result = state.get("fcr_result", {})
        draft = fcr_result.get("draft", {})
        rubric_issues = fcr_result.get("rubric_issues", [])
        competency_scores = fcr_result.get("competency_scores", []) or state.get("competency_scores", [])
        reply = "**✅ Final Field Coaching Report**\n\n"
        body = _format_fcr_with_rubric(draft, rubric_issues, is_revision=False, competency_scores=competency_scores)
        body = body.replace("**📋 FCR Draft**\n\n", "")
        body = body.replace("\n---\n\nDoes this FCR draft look good?\n\n[[action:Approve]] [[action:Revise]]", "")
        reply += body
        reply += "\n\n---\n\nSave this FCR to memory for coaching pattern tracking?\n\n[[action:Edit FCR]] [[action:Save]] [[action:Don't Save]]"

        return {
            "awaiting_memory_save": True,
            "messages": [AIMessage(content=reply)],
        }
    elif lower_msg in ["no", "n", "revise"]:
        return {
            "awaiting_feedback": True,
            "messages": [AIMessage(content="What changes would you like me to make to the FCR?")],
        }
    else:
        # Treat as revision feedback — ask for confirmation before calling LLM
        return {
            "awaiting_revision_confirm": True,
            "awaiting_feedback": False,
            "user_feedback": last_user_message,
            "messages": [AIMessage(content="Should I go ahead and use that as feedback to revise the FCR?\n\n[[action:Yes]] [[action:No]]")],
        }
