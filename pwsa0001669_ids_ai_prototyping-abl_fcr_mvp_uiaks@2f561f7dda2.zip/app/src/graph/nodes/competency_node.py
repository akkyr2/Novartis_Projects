"""Competency node — handles competency modification and flow selection."""
from typing import Dict, Any, List

from langchain_core.messages import AIMessage, HumanMessage

from app.src.graph.intent_classifier import classify_intent


def parse_competencies(text: str) -> List[str]:
    items = []

    for item in text.replace("\n", ",").split(","):
        cleaned = item.strip()

        if cleaned:
            items.append(cleaned)

    return items


def _get_last_user_message(messages: list) -> str:
    for message in reversed(messages):
        if isinstance(message, HumanMessage):
            return message.content.strip()
    return ""


def competency_node(state: dict) -> Dict[str, Any]:
    """Handle competency modification and flow selection."""
    messages = state.get("messages", [])
    last_user_message = _get_last_user_message(messages)
    eval_stage = state.get("eval_coaching_stage", "")

    # Handle flow selection choice
    if eval_stage == "flow_selection" and state.get("intake_complete"):
        lower_msg = last_user_message.lower().strip()
        intent = classify_intent(last_user_message, {
            "generate_now": "User wants to generate the evaluation directly from notes, without questions",
            "ask_questions": "User wants to be asked coaching questions first before generating",
        }, context="User was asked: Ask Coaching Questions First OR Generate Draft Now")
        if intent == "generate_now":
            return {
                "intake_complete": True,
                "eval_coaching_stage": "drafting",
                "direct_eval_flow": True,
                "messages": [AIMessage(content="Got it — generating your evaluation note directly from the observation notes...")],
            }
        elif intent == "ask_questions":
            return {
                "intake_complete": True,
                "eval_coaching_stage": "ready_to_start",
            }
        else:
            msg = ("Please select an option:\n\n"
                   "**[[action:Ask Coaching Questions First]]** — I'll ask questions to strengthen it\n\n"
                   "**[[action:Generate Draft Now]]** — Draft directly from your notes")
            return {
                "intake_complete": True,
                "eval_coaching_stage": "flow_selection",
                "messages": [AIMessage(content=msg)],
            }

    # User confirmed competencies — start eval coaching
    if eval_stage == "not_started" and state.get("intake_complete"):
        lower_msg = last_user_message.lower().strip()
        
        # First check if any competency name is mentioned — likely a modify action
        existing = list(state.get("selected_competencies", []))
        all_comps = ["Plan", "Engage", "Advance", "Close", "Follow-up"]
        mentions_competency = any(comp.lower() in lower_msg for comp in all_comps)
        
        if not mentions_competency:
            # No competency mentioned — classify intent
            intent = classify_intent(last_user_message, {
                "proceed": "User wants to proceed, continue, move on, is happy with the competencies as they are",
                "modify": "User wants to change something about the competencies",
            }, context="User was shown detected competencies and asked if they want to add, remove, or proceed")
            if intent == "proceed":
                msg = ("How would you like to generate the draft?\n\n"
                       "**[[action:Ask Coaching Questions First]]** — I'll ask a few targeted questions to strengthen the evaluation\n\n"
                       "**[[action:Generate Draft Now]]** — I'll draft it directly from your observation notes")
                return {
                    "intake_complete": True,
                    "eval_coaching_stage": "flow_selection",
                    "messages": [AIMessage(content=msg)],
                }

        # Handle competency modifications (add/remove)
        # Use LLM to understand what user wants for each mentioned competency
        removed = []
        added = None
        for comp in all_comps:
            if comp.lower() in lower_msg:
                # Determine if user wants to add or remove this competency
                comp_intent = classify_intent(last_user_message, {
                    "remove": f"User does NOT want {comp}, wants to remove it, says it doesn't fit or isn't relevant",
                    "add": f"User wants to ADD {comp} to the coaching list",
                }, context=f"User is modifying competency list. Current list: {', '.join(existing)}. User mentioned {comp}.")
                if comp_intent == "remove" and comp in existing:
                    existing.remove(comp)
                    removed.append(comp)
                elif comp_intent == "add" and comp not in existing:
                    existing.append(comp)
                    added = comp
        
        if added or removed:
            # Show updated list with remaining options
            all_comps = ["Plan", "Engage", "Advance", "Close", "Follow-up"]
            remaining = [c for c in all_comps if c not in existing]
            comp_list = ", ".join(existing)
            if remaining:
                add_options = " ".join([f"[[action:Add {c}]]" for c in remaining])
                changes = []
                if removed:
                    changes.append(f"Removed **{', '.join(removed)}**")
                if added:
                    changes.append(f"Added **{added}**")
                change_text = ". ".join(changes)
                msg = f"{change_text}. Now coaching: **{comp_list}**.\n\nAdd, remove, or proceed?\n\n{add_options} [[action:Proceed]]"
            else:
                msg = (f"All competencies selected: **{comp_list}**.\n\n"
                       "How would you like to generate the draft?\n\n"
                       "**[[action:Ask Coaching Questions First]]** — I'll ask a few targeted questions to strengthen the evaluation\n\n"
                       "**[[action:Generate Draft Now]]** — I'll draft it directly from your observation notes")
                return {
                    "intake_complete": True,
                    "selected_competencies": existing,
                    "eval_coaching_stage": "flow_selection",
                    "messages": [AIMessage(content=msg)],
                }
            return {
                "intake_complete": True,
                "selected_competencies": existing,
                "eval_coaching_stage": "not_started",
                "messages": [AIMessage(content=msg)],
            }
        else:
            # Unrecognized input — try parsing as competencies
            additional = parse_competencies(last_user_message)
            for comp in additional:
                if comp not in existing:
                    existing.append(comp)
            comp_list = ", ".join(existing)
            return {
                "intake_complete": True,
                "selected_competencies": existing,
                "eval_coaching_stage": "ready_to_start",
                "messages": [AIMessage(content=f"Updated — coaching on: **{comp_list}**. Let's go.")],
            }

    # Fallback — should not normally reach here
    return {"intake_complete": True}
