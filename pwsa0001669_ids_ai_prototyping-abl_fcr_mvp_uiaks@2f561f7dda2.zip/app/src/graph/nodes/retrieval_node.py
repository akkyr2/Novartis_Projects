from __future__ import annotations
 
from collections import Counter
from typing import Any, Dict, List, Optional

from app.src.config import settings
from app.src.services.s3_fcr_service import S3FCRService
from app.src.services.guideline_retrieval_service import GuidelineRetrievalService
from app.src.services.kpi_retrieval_service import KPIRetrievalService
 
 
def retrieval_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Retrieval node for ABL Coaching Agent.
 
    Responsibilities:
        1. Read TAS, ABL, month, and territory identifiers from state.
        2. Fetch historical FCR JSON records from S3.
        3. Sort historical FCRs from latest to oldest.
        4. Keep latest 3 FCRs as-is.
        5. Summarize older FCRs.
        6. Retrieve relevant FCR guidelines, rubrics, and examples via RAG.
        7. Fetch KPI metrics for the TAS/month/territory.
        8. Build comprehensive context_bundle for draft_fcr_node.
 
    Output keys added to state:
        context_bundle (includes past_fcr_context, guideline_context, kpi_context)
        latest_3_past_fcrs
        older_fcr_summary
        historical_fcr_count
        retrieval_status
    """
 
    tas_id = _get_first_state_value(
        state,
        [
            "tas_id",
            "tasId",
            "tas_employee_id",
            "tasEmployeeId",
            "tas_name",
            "tasName",
        ],
    )
 
    abl_id = _get_first_state_value(
        state,
        [
            "abl_id",
            "ablId",
            "abl_employee_id",
            "ablEmployeeId",
            "abl_name",
            "ablName",
        ],
    )
 
    month = _get_first_state_value(
        state,
        [
            "month",
            "coaching_month",
            "coachingMonth",
            "fcr_month",
            "fcrMonth",
        ],
    )
 
    territory = _get_first_state_value(
        state,
        [
            "territory",
            "territory_id",
            "territoryId",
            "region",
        ],
    )
 
    existing_context_bundle = state.get("context_bundle") or {}
 
    if not tas_id:
        context_bundle = {
            **existing_context_bundle,
            "past_fcr_context": {
                "status": "missing_tas_id",
                "latest_3_fcrs_as_is": [],
                "older_fcr_summary": "No historical FCRs could be retrieved because TAS identifier is missing.",
                "historical_fcr_count": 0,
            },
        }
 
        return {
            "context_bundle": context_bundle,
            "latest_3_past_fcrs": [],
            "older_fcr_summary": "No historical FCRs could be retrieved because TAS identifier is missing.",
            "historical_fcr_count": 0,
            "retrieval_status": "missing_tas_id",
            "missing_items": _append_missing_item(
                state.get("missing_items"),
                "tas_id",
            ),
        }
 
    role = state.get("role") or state.get("abl_role")
    s3_service = S3FCRService(role=role)
 
    try:
        historical_fcrs = s3_service.fetch_past_fcrs(
            tas_id=str(tas_id),
            abl_id=str(abl_id) if abl_id else None,
            territory=str(territory) if territory else None,
            max_records=100,
        )
    except Exception as exc:
        context_bundle = {
            **existing_context_bundle,
            "past_fcr_context": {
                "status": "retrieval_error",
                "latest_3_fcrs_as_is": [],
                "older_fcr_summary": "Historical FCR retrieval failed. Draft should proceed only if enough current coaching details are available.",
                "historical_fcr_count": 0,
                "error": str(exc),
            },
        }
 
        return {
            "context_bundle": context_bundle,
            "latest_3_past_fcrs": [],
            "older_fcr_summary": "Historical FCR retrieval failed.",
            "historical_fcr_count": 0,
            "retrieval_status": "retrieval_error",
            "retrieval_error": str(exc),
        }
 
    latest_3_fcrs = historical_fcrs[:3]
    older_fcrs = historical_fcrs[3:]
 
    latest_3_as_is = [
        {
            "fcr_id": fcr.get("fcr_id"),
            "fcr_date": fcr.get("fcr_date"),
            "s3_key": fcr.get("s3_key"),
            "fcr_json": fcr.get("fcr_json"),
        }
        for fcr in latest_3_fcrs
    ]
 
    older_fcr_summary = _summarize_older_fcrs(
        older_fcrs=older_fcrs,
        tas_id=str(tas_id),
    )
 
    past_fcr_context = {
        "status": "success",
        "tas_id": tas_id,
        "abl_id": abl_id,
        "month": month,
        "territory": territory,
        "historical_fcr_count": len(historical_fcrs),
        "latest_3_fcrs_as_is": latest_3_as_is,
        "older_fcr_summary": older_fcr_summary,
        "instruction_for_draft_node": (
            "Use the latest_3_fcrs_as_is as direct historical reference. "
            "Use older_fcr_summary only for longer-term coaching patterns. "
            "Do not copy old wording blindly. Keep the current FCR grounded in the current observation. "
            "ABL remains the rating authority. AI may only suggest or flag rating alignment issues."
        ),
    }
 
    # Retrieve guidelines, rubrics, and examples via RAG
    guideline_context = _retrieve_guideline_context(state, tas_id, month)
 
    # Retrieve KPI metrics
    kpi_context = _retrieve_kpi_context(state, tas_id, month, territory)
 
    # Retrieve coaching patterns from memory
    memory_context = _retrieve_memory_patterns(tas_id)
 
    context_bundle = {
        **existing_context_bundle,
        "past_fcr_context": past_fcr_context,
        "guideline_context": guideline_context,
        "kpi_context": kpi_context,
        "memory_context": memory_context,
    }
 
    return {
        "context_bundle": context_bundle,
        "latest_3_past_fcrs": latest_3_as_is,
        "older_fcr_summary": older_fcr_summary,
        "historical_fcr_count": len(historical_fcrs),
        "retrieval_status": "success",
    }
 
 
def _summarize_older_fcrs(
    older_fcrs: List[Dict[str, Any]],
    tas_id: str,
) -> str:
    """
    Creates a concise summary of FCRs older than the latest 3.
 
    This version is deterministic and does not require an LLM call.
    If you already have fcr_summary_service.py wired to Bedrock, you can replace
    this function body with that service call.
    """
 
    if not older_fcrs:
        return (
            "No older FCRs beyond the latest 3 were found for this TAS. "
            "Use only the latest 3 FCRs and current observation details."
        )
 
    date_range = _get_date_range(older_fcrs)
 
    strengths = []
    opportunities = []
    actions = []
    ratings = []
    themes = []
 
    for record in older_fcrs:
        fcr_json = record.get("fcr_json") or {}
 
        strengths.extend(
            _extract_text_values(
                fcr_json,
                [
                    "strengths",
                    "strength",
                    "key_strengths",
                    "observed_strengths",
                    "what_went_well",
                    "positive_observations",
                ],
            )
        )
 
        opportunities.extend(
            _extract_text_values(
                fcr_json,
                [
                    "opportunities",
                    "opportunity",
                    "development_opportunities",
                    "areas_for_improvement",
                    "coaching_opportunities",
                    "development_area",
                    "development_areas",
                ],
            )
        )
 
        actions.extend(
            _extract_text_values(
                fcr_json,
                [
                    "action_items",
                    "next_steps",
                    "next_step",
                    "commitments",
                    "development_plan",
                    "coaching_plan",
                    "follow_up_actions",
                ],
            )
        )
 
        themes.extend(
            _extract_text_values(
                fcr_json,
                [
                    "themes",
                    "coaching_themes",
                    "summary",
                    "manager_summary",
                    "overall_summary",
                    "observation_summary",
                ],
            )
        )
 
        rating = _find_first_value(
            fcr_json,
            [
                "rating",
                "overall_rating",
                "selected_rating",
                "performance_rating",
                "fcr_rating",
            ],
        )
 
        if rating:
            ratings.append(str(rating))
 
    top_strengths = _top_phrases(strengths, limit=5)
    top_opportunities = _top_phrases(opportunities, limit=5)
    top_actions = _top_phrases(actions, limit=5)
    top_themes = _top_phrases(themes, limit=5)
    top_ratings = _top_phrases(ratings, limit=3)
 
    summary_lines = [
        f"Historical FCR summary for TAS {tas_id}.",
        f"Older FCR count summarized: {len(older_fcrs)}.",
    ]
 
    if date_range:
        summary_lines.append(f"Historical date range: {date_range}.")
 
    if top_themes:
        summary_lines.append(
            "Recurring coaching themes: " + "; ".join(top_themes) + "."
        )
 
    if top_strengths:
        summary_lines.append(
            "Recurring strengths observed: " + "; ".join(top_strengths) + "."
        )
 
    if top_opportunities:
        summary_lines.append(
            "Recurring development opportunities: "
            + "; ".join(top_opportunities)
            + "."
        )
 
    if top_actions:
        summary_lines.append(
            "Common prior action items or next steps: " + "; ".join(top_actions) + "."
        )
 
    if top_ratings:
        summary_lines.append(
            "Prior rating references found: "
            + "; ".join(top_ratings)
            + ". AI should not assign the new rating; ABL remains the rating authority."
        )
 
    summary_lines.append(
        "Use this summary to identify development patterns only. The current FCR should be based primarily on the current field observation, current pre-work, KPI context, and ABL input."
    )
 
    return "\n".join(summary_lines)
 
 
def _get_first_state_value(
    state: Dict[str, Any],
    keys: List[str],
) -> Optional[Any]:
    for key in keys:
        value = state.get(key)
 
        if value not in [None, ""]:
            return value
 
    intake = state.get("intake") or {}
 
    if isinstance(intake, dict):
        for key in keys:
            value = intake.get(key)
 
            if value not in [None, ""]:
                return value
 
    metadata = state.get("metadata") or {}
 
    if isinstance(metadata, dict):
        for key in keys:
            value = metadata.get(key)
 
            if value not in [None, ""]:
                return value
 
    return None
 
 
def _append_missing_item(
    existing_missing_items: Optional[List[str]],
    item: str,
) -> List[str]:
    missing_items = list(existing_missing_items or [])
 
    if item not in missing_items:
        missing_items.append(item)
 
    return missing_items
 
 
def _extract_text_values(
    payload: Any,
    candidate_keys: List[str],
) -> List[str]:
    values: List[str] = []
 
    if isinstance(payload, dict):
        for key, value in payload.items():
            normalized_key = _normalize_key(key)
 
            if normalized_key in [_normalize_key(candidate) for candidate in candidate_keys]:
                values.extend(_flatten_text(value))
 
            if isinstance(value, (dict, list)):
                values.extend(_extract_text_values(value, candidate_keys))
 
    elif isinstance(payload, list):
        for item in payload:
            values.extend(_extract_text_values(item, candidate_keys))
 
    return values
 
 
def _find_first_value(
    payload: Any,
    candidate_keys: List[str],
) -> Optional[Any]:
    if isinstance(payload, dict):
        for key, value in payload.items():
            normalized_key = _normalize_key(key)
 
            if normalized_key in [_normalize_key(candidate) for candidate in candidate_keys]:
                return value
 
            if isinstance(value, (dict, list)):
                nested_value = _find_first_value(value, candidate_keys)
 
                if nested_value:
                    return nested_value
 
    elif isinstance(payload, list):
        for item in payload:
            nested_value = _find_first_value(item, candidate_keys)
 
            if nested_value:
                return nested_value
 
    return None
 
 
def _flatten_text(value: Any) -> List[str]:
    if value in [None, ""]:
        return []
 
    if isinstance(value, str):
        cleaned = value.strip()
        return [cleaned] if cleaned else []
 
    if isinstance(value, (int, float, bool)):
        return [str(value)]
 
    if isinstance(value, list):
        results: List[str] = []
 
        for item in value:
            results.extend(_flatten_text(item))
 
        return results
 
    if isinstance(value, dict):
        results = []
 
        for nested_value in value.values():
            results.extend(_flatten_text(nested_value))
 
        return results
 
    return []
 
 
def _top_phrases(
    values: List[str],
    limit: int = 5,
) -> List[str]:
    cleaned_values = []
 
    for value in values:
        cleaned = " ".join(str(value).split())
 
        if not cleaned:
            continue
 
        if len(cleaned) > 280:
            cleaned = cleaned[:277] + "..."
 
        cleaned_values.append(cleaned)
 
    if not cleaned_values:
        return []
 
    counter = Counter(cleaned_values)
 
    return [
        phrase
        for phrase, _ in counter.most_common(limit)
    ]
 
 
def _get_date_range(records: List[Dict[str, Any]]) -> Optional[str]:
    dates = [
        record.get("fcr_date")
        for record in records
        if record.get("fcr_date")
    ]
 
    if not dates:
        return None
 
    sorted_dates = sorted(dates)
 
    if sorted_dates[0] == sorted_dates[-1]:
        return sorted_dates[0]
 
    return f"{sorted_dates[0]} to {sorted_dates[-1]}"
 
 
def _normalize_key(value: str) -> str:
    return str(value).lower().replace("_", "").replace("-", "").replace(" ", "")
 
 
def _retrieve_guideline_context(
    state: Dict[str, Any],
    tas_id: Optional[str],
    month: Optional[str],
) -> Dict[str, Any]:
    """
    Retrieve FCR guidelines, rubrics, and examples via RAG.
 
    Returns:
        Dictionary with guideline references and retrieval status
    """
    try:
        guideline_service = GuidelineRetrievalService()
 
        # Build coaching context from state
        coaching_context = _build_coaching_context_summary(state)
 
        # Extract competencies if available
        competencies = _extract_competencies(state)
 
        # Determine coaching type
        coaching_type = state.get("coaching_type", "developmental")
 
        # Retrieve comprehensive guideline context
        guideline_result = guideline_service.retrieve_comprehensive_context(
            coaching_context=coaching_context,
            competencies=competencies,
            coaching_type=coaching_type,
            include_examples=True,
        )
 
        return {
            "status": guideline_result.get("status", "success"),
            "guidelines": guideline_result.get("guidelines", []),
            "rubric_criteria": guideline_result.get("rubric_criteria", []),
            "coaching_framework": guideline_result.get("coaching_framework", []),
            "examples": guideline_result.get("examples", []),
            "retrieval_counts": guideline_result.get("retrieval_counts", {}),
            "instruction": guideline_result.get("instruction", ""),
        }
 
    except Exception as exc:
        return {
            "status": "error",
            "guidelines": [],
            "rubric_criteria": [],
            "coaching_framework": [],
            "examples": [],
            "retrieval_counts": {},
            "error": str(exc),
            "instruction": (
                "Guideline retrieval failed. "
                "Draft FCR using general best practices and historical FCR patterns."
            ),
        }
 
 
def _retrieve_kpi_context(
    state: Dict[str, Any],
    tas_id: Optional[str],
    month: Optional[str],
    territory: Optional[str],
) -> Dict[str, Any]:
    """
    Retrieve KPI metrics for the TAS.
 
    Returns:
        Dictionary with KPI summary and metrics
    """
    if not tas_id:
        return {
            "status": "missing_tas_id",
            "kpi_summary": {},
            "metrics": [],
            "message": "TAS ID required for KPI retrieval",
        }
 
    try:
        kpi_service = KPIRetrievalService()
 
        kpi_result = kpi_service.fetch_tas_kpis(
            tas_id=str(tas_id),
            month=str(month) if month else None,
            territory=str(territory) if territory else None,
            include_trends=True,
        )
 
        return {
            "status": kpi_result.get("status", "success"),
            "tas_id": tas_id,
            "month": month,
            "territory": territory,
            "kpi_summary": kpi_result.get("kpi_summary", {}),
            "metrics": kpi_result.get("metrics", []),
            "message": kpi_result.get("message", ""),
            "instruction": (
                "Use KPI data as supporting context for coaching observations. "
                "Reference specific metrics when identifying strengths or opportunities. "
                "Ensure action items are data-driven where applicable."
            ),
        }
 
    except Exception as exc:
        return {
            "status": "error",
            "tas_id": tas_id,
            "kpi_summary": {},
            "metrics": [],
            "error": str(exc),
            "message": f"KPI retrieval failed: {str(exc)}",
            "instruction": "KPI data unavailable. Ground coaching in observed behaviors only.",
        }
 
 
def _build_coaching_context_summary(state: Dict[str, Any]) -> str:
    """
    Build a concise summary of the coaching context from state.
 
    Extracts key details from:
        - tas_prework_text
        - abl_eval_text
        - observation_notes
        - seam_notes
    """
    parts = []
 
    # Extract from various state keys
    prework = state.get("tas_prework_text") or state.get("prework") or ""
    eval_text = state.get("abl_eval_text") or state.get("evaluation") or ""
    observation = state.get("observation_notes") or state.get("observation") or ""
    seam_notes = state.get("seam_notes") or state.get("seam") or ""
 
    if prework:
        parts.append(f"Pre-work: {str(prework)[:200]}")
 
    if eval_text:
        parts.append(f"Evaluation: {str(eval_text)[:200]}")
 
    if observation:
        parts.append(f"Observation: {str(observation)[:200]}")
 
    if seam_notes:
        parts.append(f"SEAM: {str(seam_notes)[:200]}")
 
    if not parts:
        return "Coaching observation and evaluation context"
 
    return " | ".join(parts)
 
 
def _extract_competencies(state: Dict[str, Any]) -> Optional[List[str]]:
    """
    Extract competencies from state.
 
    Looks for:
        - selected_competencies
        - competencies
        - competency_areas
    """
    competency_keys = [
        "selected_competencies",
        "competencies",
        "competency_areas",
        "one_breakaway_areas",
    ]
 
    for key in competency_keys:
        value = state.get(key)
 
        if value and isinstance(value, list):
            return [str(c).strip() for c in value if c]
 
    # Check nested intake
    intake = state.get("intake") or {}
    if isinstance(intake, dict):
        for key in competency_keys:
            value = intake.get(key)
            if value and isinstance(value, list):
                return [str(c).strip() for c in value if c]
 
    return None
 
 
def _retrieve_memory_patterns(tas_id: Optional[str]) -> Dict[str, Any]:
    """
    Retrieve coaching patterns from S3 memory for this TAS.
 
    Reads memory/{tas_id}/index.json to get:
    - Recurring strengths and development areas
    - Coaching theme history
    - Previous coaching summaries
    - Next coaching focus from last session
    """
    if not tas_id:
        return {"status": "missing_tas_id"}
 
    import json
    import os
    import boto3
    from botocore.exceptions import ClientError
 
    bucket = settings.memory_s3_bucket
    key = f"memory/{tas_id}/index.json"
 
    try:
        s3 = boto3.client("s3", region_name=settings.aws_region)
        response = s3.get_object(Bucket=bucket, Key=key)
        index = json.loads(response["Body"].read().decode("utf-8"))
 
        # Build instruction for draft node
        recurring_strengths = index.get("recurring_strengths", {})
        recurring_gaps = index.get("recurring_development_areas", {})
        last_focus = index.get("next_coaching_focus", {})
        summaries = index.get("coaching_summaries", [])
        progress = index.get("progress_history", [])
 
        instruction = (
            "Coaching memory is available for this TAS. "
            "Use recurring patterns to inform the new FCR: "
            "reinforce sustained strengths, flag continued gaps, "
            "and check if the previous coaching focus was addressed. "
            "Do not just repeat old observations — ground in current field day evidence."
        )
 
        return {
            "status": "success",
            "total_fcrs_in_memory": index.get("total_fcrs", 0),
            "recurring_strengths": recurring_strengths,
            "recurring_development_areas": recurring_gaps,
            "coaching_theme_history": index.get("coaching_theme_history", {}),
            "previous_coaching_focus": last_focus,
            "latest_coaching_summary": summaries[-1].get("summary", "") if summaries else "",
            "latest_progress_trend": progress[-1].get("overall_trend", "unknown") if progress else "baseline",
            "instruction": instruction,
        }
 
    except ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchKey":
            return {
                "status": "no_memory",
                "message": "First FCR for this TAS — no coaching memory exists yet.",
                "instruction": "No prior coaching patterns available. This is the baseline FCR.",
            }
        return {"status": "error", "error": str(e)}
    except Exception as e:
        return {"status": "error", "error": str(e)}