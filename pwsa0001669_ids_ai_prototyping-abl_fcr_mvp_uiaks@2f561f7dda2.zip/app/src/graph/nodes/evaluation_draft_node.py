"""
Evaluation Draft Node
Creates a concise evaluation note in OII + SMART format.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, Optional

from app.src.llm.bedrock_client import BedrockClient


def evaluation_draft_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a concise evaluation note using OII framework with crisp SMART goals."""
    tas_name = state.get("tas_name") or state.get("tas_id") or "TAS"
    revision_feedback = state.get("evaluation_revision_feedback", "")

    context = {
        "abl_eval_text": state.get("abl_eval_text") or "",
        "observation_notes": state.get("observation_notes") or "",
        "observed_strengths": state.get("observed_strengths") or "",
        "development_opportunities": state.get("development_opportunities") or "",
        "impact_statement": state.get("impact_statement") or "",
        "action_items": state.get("action_items") or "",
        "selected_competencies": state.get("selected_competencies") or [],
        "eval_answers": state.get("eval_answers", {}),
    }

    revision_instruction = ""
    if revision_feedback:
        current_note = state.get("evaluation_full_text", "")
        revision_instruction = f"""

CURRENT EVALUATION NOTE (already approved structure — modify ONLY what the feedback asks):
---
{current_note}
---

REVISION FEEDBACK FROM ABL:
{revision_feedback}

IMPORTANT: Only change what the feedback specifically asks for. Keep everything else exactly the same."""

    prompt = f"""

An ABL is a manager for a Pharma companies field representatives and field representatives are called TAS. Every month An ABL gets to see a TAS interacting with Doctors (during what they call as field day) and makes a note of his observation. Next day both TAS and ABL come together where TAS brings a Field Pre-work note or SEAM Note which is created based on Past FCRs (Field Coaching Report) and TAS's inputs. While ABL brings in evaluation notes from the meeting with doctor (from the field day) where they both discuss on finalize on current month FCR. Final an ABL is responsible for creating FCR using TAS Past FCR, TAS created SEAM, TAS KPIs and Report from Field day i.e., field evaluation note and share it TAS.
    
You are an expert coaching facilitator helping an ABL (Area Business Leader) create a high-quality Field Evaluation Note after observing a TAS (Territory Account Specialist) during a field day with doctors; TAS NAME: {tas_name}.

CRITICAL NAME RULE: You MUST use ONLY the name "{tas_name}" when referring to the TAS throughout the evaluation note. Do NOT use any other name.

CONTEXT:
An ABL observed this TAS during a field day. Create a concise, evidence-based evaluation note using the OII structure (Observation → Impact → Improve).

COLLECTED FIELD-DAY INFORMATION:
{json.dumps(context, indent=2, default=str)}{revision_instruction}

RULES:
- Observation: 2-3 crisp sentences of SPECIFIC behaviors observed. No filler.
- Impact: 2-3 sentences on WHY it matters (HCP engagement, patient outcomes, A→B shift).
- How to Improve: EXACTLY 2 SMART Goals. Each goal must be ONE concise block — no lengthy paragraphs.

SMART GOAL FORMAT (keep each sub-bullet to ONE sentence max):
SMART Goal N: [Goal statement with metric and deadline]
• Specific: [One sentence — what to do differently]
• Measurable: [One sentence — how to track]
• Achievable: [One sentence — why realistic]
• Relevant: [One sentence — why it matters for this TAS]
• Time-Bound: [Deadline or cadence]
• Impact: [One sentence — expected outcome]

CRITICAL:
- The wording of the evaluation note should be human like it shoudn't be like a bot. Keep healthy positive and encouraging tone. TAS shouldnt feel like he is being coached by a Bot. Use the words like You etc., not like bot summarization
- Goals must be SPECIFIC to THIS TAS 
- Each sub-bullet is ONE short sentence, not a paragraph
- Total "How to Improve" section should be ~150-200 words max for both goals combined
- No repetition, no filler, no generic coaching language
- Competencies: {', '.join(context.get('selected_competencies', []))}


Return ONLY this JSON:
{{
  "evaluation_note": {{
    "observation": "string (2-3 sentences, specific behaviors only)",
    "impact": "string (2-3 sentences, business/patient impact)",
    "how_to_improve": [
      {{
        "goal_headline": "SMART Goal 1: [concise goal with metric and deadline]",
        "specific": "one sentence",
        "measurable": "one sentence",
        "achievable": "one sentence",
        "relevant": "one sentence",
        "time_bound": "one sentence",
        "impact": "one sentence"
      }},
      {{
        "goal_headline": "SMART Goal 2: [concise goal with metric and deadline]",
        "specific": "one sentence",
        "measurable": "one sentence",
        "achievable": "one sentence",
        "relevant": "one sentence",
        "time_bound": "one sentence",
        "impact": "one sentence"
      }}
    ],
    "competencies_addressed": ["string"]
  }},
  "full_text": "string (the formatted note as clean text: Observation paragraph, Impact paragraph, then How to Improve with 2 SMART goals in bullet format)"
}}
"""

    bedrock = BedrockClient()
    try:
        raw = bedrock.invoke_claude(prompt=prompt, max_tokens=2000, temperature=0.3)
    except Exception as e:
        print(f"❌ Evaluation draft LLM call failed: {e}")
        return {"evaluation_draft": None, "evaluation_draft_status": "failed"}

    parsed = _safe_json(raw)

    if not parsed or "evaluation_note" not in parsed:
        return {"evaluation_draft": None, "evaluation_draft_status": "failed"}

    # If LLM full_text is missing or too long, build a clean one from structured data
    eval_note = parsed["evaluation_note"]
    full_text = parsed.get("full_text", "")
    if not full_text or len(full_text) > 2000:
        full_text = _format_clean_text(eval_note)

    return {
        "evaluation_draft": eval_note,
        "evaluation_full_text": full_text,
        "evaluation_draft_status": "complete",
    }


def _format_clean_text(note: Dict[str, Any]) -> str:
    """Format evaluation note as clean, crisp text."""
    parts = []

    parts.append(f"**Observation:**\n{note.get('observation', '')}")
    parts.append(f"\n**Impact:**\n{note.get('impact', '')}")
    parts.append("\n**How to Improve:**")

    goals = note.get("how_to_improve", [])
    for goal in goals[:2]:
        if not isinstance(goal, dict):
            continue
        parts.append(f"\n{goal.get('goal_headline', '')}")
        parts.append(f"• Specific: {goal.get('specific', '')}")
        parts.append(f"• Measurable: {goal.get('measurable', '')}")
        parts.append(f"• Achievable: {goal.get('achievable', '')}")
        parts.append(f"• Relevant: {goal.get('relevant', '')}")
        parts.append(f"• Time-Bound: {goal.get('time_bound', '')}")
        parts.append(f"• Impact: {goal.get('impact', '')}")

    return "\n".join(parts)


def _safe_json(text: str) -> Optional[Dict[str, Any]]:
    """Safely parse JSON from LLM response."""
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?", "", cleaned).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r'\{.*\}', cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass
        return None
