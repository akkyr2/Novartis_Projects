from __future__ import annotations
import json
import re
from typing import Any, Dict, Optional

from app.src.llm.bedrock_client import BedrockClient


def answer_ingest_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract structured fields from the latest user answer (Phase 2: KPI & SEAM only).

    NOTE: Field observation extraction (observation_notes, observed_strengths,
    development_opportunities, impact_statement, action_items) is handled in
    Phase 1 by evaluation_answer_ingest_node.

    This node focuses on:
    - seam_notes: SEAM/pre-work developmental context
    - developmental_context: General contextual information
    - (Could extend with kpi_insights, territory_challenges, etc.)
    """
    last_answer = (state.get("last_user_answer") or "").strip()
    last_question = state.get("last_asked_question") or {}

    if not last_answer or not last_question:
        return {}

    track = last_question.get("track", "abl_evaluation")
    missing_slot = (last_question.get("grounding", {}) or {}).get("missing_slot", "")
    purpose = (last_question.get("purpose") or "").lower()

    # Fast path: if answer is very short, don't try to parse
    if len(last_answer) < 10:
        return {}

    prompt = f"""
You are an information extraction engine for an ABL (Area Business Leader) coaching workflow (Phase 2: KPI & Context).

BUSINESS CONTEXT:
- ABL is analyzing TAS (Territory Account Specialist) performance
- TAS sells Rhapsido (Novartis brand for moderate-to-severe CSU/allergy). Dupixent and Xolair are competitor brands.
- Phase 2 focuses on KPI performance analysis and territory context (NOT field observations)

NOTE: Field observation data (observation_notes, strengths, opportunities, impact, actions)
was already collected in Phase 1. Do NOT extract field observations here.

Given:
- track: {track}
- missing_slot: {missing_slot}
- purpose: {purpose}

User answer (ABL's response):
\"\"\"{last_answer}\"\"\"

Extract ONLY what is present. Do not invent. Be precise.

Return JSON with any of these keys if you find them:
{{
  "seam_notes": "string",
  "developmental_context": "string",
  "kpi_insights": "string",
  "territory_challenges": "string"
}}

EXTRACTION RULES:

**seam_notes**: TAS's pre-work or self-reflection content
- TAS's stated goals (e.g., "improve POA skills")
- TAS's self-assessment
- What TAS wrote in SEAM prework

**kpi_insights**: Performance analysis, root causes, interpretation
- Why KPIs are above/below target (e.g., "low call volume due to territory restructuring")
- Performance trends explanation
- Segmentation insights (Treatment Escalators vs Conventional Cyclers behavior)
- Prescription patterns (NBRx/TRx trends)

**territory_challenges**: Systemic or market barriers
- Access issues (e.g., "hospital systems require 2-week advance scheduling")
- Competitive landscape
- Geographic challenges
- Payer restrictions
- Structural issues (vacant adjacent territories, staffing)

**developmental_context**: General background or contextual info
- TAS experience level (e.g., "first year in role")
- Territory history
- Market dynamics
- Any other relevant context not fitting above categories

Return ONLY JSON.
"""

    bedrock = BedrockClient()
    raw = bedrock.invoke_claude(prompt=prompt, max_tokens=600, temperature=0.0)
    parsed = _safe_json(raw)
    if not parsed:
        return {}

    # Merge-only (do not overwrite good existing data with empty strings)
    updates = {}
    for k, v in parsed.items():
        if isinstance(v, str) and v.strip():
            # Append if field already exists and new content differs
            existing = (state.get(k) or "").strip()
            if existing and v.strip() not in existing:
                updates[k] = (existing + "\n\n" + v.strip()).strip()
            else:
                updates[k] = v.strip()

    return updates


def _safe_json(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?", "", cleaned).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except Exception:
        return None