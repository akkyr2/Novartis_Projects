from pydantic import BaseModel, Field
from typing import List, Optional

class IntakeNodeInput(BaseModel):
    tas_prework_text: str = Field(..., description="Text input from TAS pre-work (SEAM note)")
    abl_eval_text: str = Field(..., description="Text input from ABL evaluation/observation note")
    selected_competencies: List[str] = Field(..., description="List of selected competencies for evaluation")

class IntakeNodeOutput(BaseModel):
    questions: List[str] = Field(..., description="List of questions generated based on missing inputs")
    valid: bool = Field(..., description="Indicates if the input is valid")

def validate_inputs(inputs: IntakeNodeInput) -> IntakeNodeOutput:
    questions = []
    
    # tas_prework_text is optional (user can skip SEAM pre-work)
    
    if not inputs.abl_eval_text.strip():
        questions.append("Please provide the ABL evaluation text.")
    
    if not inputs.selected_competencies:
        questions.append("Please select at least one competency.")
    
    valid = len(questions) == 0
    
    return IntakeNodeOutput(questions=questions, valid=valid)