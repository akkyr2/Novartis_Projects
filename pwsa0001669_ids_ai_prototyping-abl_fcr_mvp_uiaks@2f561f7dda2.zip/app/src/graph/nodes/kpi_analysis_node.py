from typing import Dict, Any, List
from pathlib import Path
import json
import openpyxl
import pandas as pd
from app.src.llm.bedrock_client import BedrockClient

class KPIAnalysisNode:
    """Loads territory data from all relevant sources and feeds to LLM for comprehensive analysis."""
    DATA_DIR = Path(__file__).resolve().parents[3] / "data"
    MAPPING_FILE = "tas_territory_mapping.xlsx"
    ANALYSIS_PROMPT = """You are a pharmaceutical sales performance analyst and coaching strategist.
Below is comprehensive territory data from multiple sources. Analyze it and provide:
1. **Performance Summary** (3-4 sentences): Overall territory health — what's strong, what's lagging, how they compare to goals.
2. **HCP Insights** (2-3 sentences): Key findings from the doctor-level data — who should be prioritized, where are the gaps in engagement.
3. **Trend & Goal Attainment** (2-3 sentences): How the territory is tracking against goals and recent momentum.
4. **Actionable Recommendations** (3-4 bullet points): Specific, concrete actions the TAS should take to improve performance. Reference actual metrics and HCPs where possible.
---
METRIC DEFINITIONS (use these to interpret the data correctly):
{metric_definitions}
---
TERRITORY: {territory}
---
SOURCE 1 — TERRITORY-LEVEL KPIs (recent weekly snapshot with growth %):
{data_20}
---
SOURCE 2 — CUMULATIVE/LTD PERFORMANCE (Prime KPIs):
{prime_kpis}
---
SOURCE 3 — WEEKLY GOALS vs ACTUALS (from Performance Tracker):
{weekly_tracker}
---
SOURCE 4 — HCP-LEVEL BREAKDOWN (top opportunities and gaps):
{data_21_summary}
---
Write in a direct, business-friendly tone. Be specific — reference actual numbers, HCP tiers, and metrics. Do not be generic."""
    def __init__(self, state: Dict[str, Any]):
        self.state = state
        self.tas_id = state.get("tas_id", "").strip()
        self.territory = state.get("territory", "").strip() or self._resolve_territory()
 
    def _resolve_territory(self) -> str:
        """Resolve TAS name/ID to territory using tas_territory_mapping.xlsx."""
        path = self.DATA_DIR / self.MAPPING_FILE
        if not path.exists() or not self.tas_id:
            return ""
        try:
            df = pd.read_excel(str(path))
            tas_lower = self.tas_id.lower().replace(" ", "")
            for _, row in df.iterrows():
                # Match against TAS Name or S3 Key
                tas_name = str(row.get("TAS Name", "")).lower().replace(" ", "")
                s3_key = str(row.get("S3 Key", "")).lower().replace(" ", "")
                if tas_lower == tas_name or tas_lower == s3_key or tas_lower in tas_name or tas_name in tas_lower:
                    return str(row.get("Territory", ""))
            return ""
        except Exception:
            return ""
 
    def run(self) -> Dict[str, Any]:
        if not self.tas_id:
            return {"kpi_analysis": {"status": "completed", "message": "No TAS ID provided", "analysis": {}, "narrative": ""}}
        # Load from all sources using resolved territory
        data_20 = self._load_data_20()
        if not data_20:
            return {"kpi_analysis": {"status": "completed", "message": f"No territory data found for '{self.tas_id}' (territory: '{self.territory}')", "analysis": {}, "narrative": ""}}
        territory = data_20.get("Territory", self.territory or self.tas_id)
        prime_kpis = self._load_prime_kpis()
        weekly_tracker = self._load_weekly_tracker()
        data_21_summary = self._load_data_21_summary()
        metric_definitions = self._load_metric_definitions()
        # Generate LLM narrative
        narrative = self._generate_narrative(
            territory=territory,
            data_20=data_20,
            prime_kpis=prime_kpis,
            weekly_tracker=weekly_tracker,
            data_21_summary=data_21_summary,
            metric_definitions=metric_definitions,
        )
        return {
            "kpi_analysis": {
                "status": "completed",
                "territory": territory,
                "analysis": {k: v for k, v in data_20.items() if k != "Territory"},
                "narrative": narrative,
            }
        }
    def _load_data_20(self) -> Dict[str, Any]:
        """Territory-level KPIs with growth %."""
        path = self.DATA_DIR / "data_20_modified_territory_level_kpis.xlsx"
        if not path.exists():
            return {}
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        ws = wb.active
        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
 
        # Search by resolved territory first, then fall back to tas_id
        search_terms = [t for t in [self.territory, self.tas_id] if t]
 
        for row in ws.iter_rows(min_row=2, values_only=True):
            row_dict = dict(zip(headers, row))
            territory = str(row_dict.get("Territory", ""))
            for term in search_terms:
                if term.lower() in territory.lower():
                    wb.close()
                    print(row_dict)
                    return row_dict
        wb.close()
        return {}
    def _load_prime_kpis(self) -> Dict[str, Any]:
        """Cumulative/LTD KPIs from Prime KPIs file."""
        path = self.DATA_DIR / "Prime KPIs.xlsx"
        if not path.exists():
            return {}
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        ws = wb.active
        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
 
        search_terms = [t for t in [self.territory, self.tas_id] if t]
 
        for row in ws.iter_rows(min_row=2, values_only=True):
            row_dict = dict(zip(headers, row))
            territory = str(row_dict.get("Territory", ""))
            for term in search_terms:
                if term.lower() in territory.lower():
                    wb.close()
                    return row_dict
        wb.close()
        return {}
    def _load_weekly_tracker(self) -> Dict[str, Any]:
        """Weekly goals vs actuals from Performance Tracker."""
        path = self.DATA_DIR / "Rhapsido Allergy Weekly Performance Tracker - WE 03_27_2026.xlsx"
        if not path.exists():
            return {}
        search_terms = [t for t in [self.territory, self.tas_id] if t]
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        ws = wb.active
        headers = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]

        for row in ws.iter_rows(min_row=2, values_only=True):
            row_dict = dict(zip(headers, row))
            territory = str(row_dict.get("Territory", ""))
            for term in search_terms:
                if term.lower() in territory.lower():
                    wb.close()
                    # Remove None key if present from blank header columns
                    row_dict.pop(None, None)
                    return row_dict
        wb.close()
        return {}
    def _load_data_21_summary(self) -> str:
        """HCP-level summary for the territory."""
        path = self.DATA_DIR / "data_21_modified_KPIs_of_HCP_mapped_to_territory.xlsx"
        if not path.exists():
            return "No HCP data available."
        try:
            df = pd.read_excel(str(path))
            # Search by resolved territory first, then tas_id
            search_terms = [t for t in [self.territory, self.tas_id] if t]
            territory_df = pd.DataFrame()
            for term in search_terms:
                territory_df = df[df["Territory"].str.contains(term, case=False, na=False)]
                if not territory_df.empty:
                    break
            if territory_df.empty:
                return "No HCP data available for this territory."
            # If all Calls are zero, the data is missing — not real zeros
            if "Calls" not in territory_df.columns or territory_df["Calls"].fillna(0).sum() == 0:
                return "HCP-level call data not available for this territory."
            total_hcps = len(territory_df)
            tier_counts = territory_df["Tier"].value_counts().to_dict()
            # Find date-stamped columns dynamically
            trx_col = next((c for c in territory_df.columns if c.startswith("Rhapsido TRx")), None)
            nbrx_col = next((c for c in territory_df.columns if c.startswith("Rhapsido NBRx")), None)
            if not trx_col:
                return "HCP-level Rx data columns not found."
            # HCPs with zero calls (engagement gaps)
            zero_call_hcps = territory_df[territory_df["Calls"].fillna(0) == 0]
            zero_call_t1 = zero_call_hcps[zero_call_hcps["Tier"] == "T1"]
            # Top prescribers
            display_cols = ["HCP", "Tier", trx_col, "Calls"] + ([nbrx_col] if nbrx_col else [])
            top_writers = territory_df.nlargest(5, trx_col)[
                [c for c in display_cols if c in territory_df.columns]
            ].to_dict("records")
            # T1 HCPs with no Rhapsido TRx (opportunity)
            t1_no_trx = territory_df[
                (territory_df["Tier"] == "T1") &
                (territory_df[trx_col].fillna(0) == 0)
            ]
            summary = (
                f"Total HCPs: {total_hcps} | Tier breakdown: {tier_counts}\n"
                f"HCPs with zero calls: {len(zero_call_hcps)} (of which {len(zero_call_t1)} are Tier-1)\n"
                f"Tier-1 HCPs with zero Rhapsido TRx: {len(t1_no_trx)} (untapped opportunity)\n"
                f"Top 5 prescribers: {json.dumps(top_writers, default=str)}"
            )
            return summary
        except Exception as e:
            return f"Error loading HCP data: {str(e)}"
    def _load_metric_definitions(self) -> str:
        """Load metric definitions for LLM context."""
        path = self.DATA_DIR / "Power BI KPI Metric Definitions.xlsx"
        if not path.exists():
            return "No metric definitions available."
        try:
            df = pd.read_excel(str(path))
            df = df.dropna(subset=["Metric"])
            definitions = [f"- {row['Metric']}: {row['Definition']}" for _, row in df.iterrows()]
            return "\n".join(definitions)
        except Exception:
            return "No metric definitions available."
    def _generate_narrative(self, territory: str, data_20: Dict, prime_kpis: Dict,
                           weekly_tracker: Dict, data_21_summary: str, metric_definitions: str) -> str:
        # Build prompt dynamically — only include sections with real data
        has_hcp = data_21_summary and "not available" not in data_21_summary.lower()

        sections = f"""METRIC DEFINITIONS (use these to interpret the data correctly):
{metric_definitions}
---
TERRITORY: {territory}
---
SOURCE 1 — TERRITORY-LEVEL KPIs (recent weekly snapshot with growth %):
{json.dumps({k: v for k, v in data_20.items() if k != "Territory"}, indent=2, default=str)}
---
SOURCE 2 — CUMULATIVE/LTD PERFORMANCE (Prime KPIs):
{json.dumps({k: v for k, v in prime_kpis.items() if k != "Territory"}, indent=2, default=str) if prime_kpis else "Not available"}
---
SOURCE 3 — WEEKLY GOALS vs ACTUALS (from Performance Tracker):
{json.dumps(weekly_tracker, indent=2, default=str) if weekly_tracker else "Not available"}"""

        if has_hcp:
            sections += f"""
---
SOURCE 4 — HCP-LEVEL BREAKDOWN (top opportunities and gaps):
{data_21_summary}"""

        output_format = """1. **Performance Summary** (3-4 sentences): Overall territory health — what's strong, what's lagging, how they compare to goals."""
        if has_hcp:
            output_format += """
2. **HCP Insights** (2-3 sentences): Key findings from the doctor-level data — who should be prioritized, where are the gaps in engagement."""
        output_format += """
3. **Trend & Goal Attainment** (2-3 sentences): How the territory is tracking against goals and recent momentum.
4. **Actionable Recommendations** (3-4 bullet points): Specific, concrete actions the TAS should take to improve performance. Reference actual metrics where possible."""

        prompt = f"""You are a pharmaceutical sales performance analyst and coaching strategist.
Below is comprehensive territory data. Analyze it and provide:
{output_format}
---
{sections}
---
Write in a direct, business-friendly tone. Be specific — reference actual numbers and metrics. Do not be generic."""

        try:
            bedrock = BedrockClient()
            return bedrock.invoke_claude(prompt=prompt, max_tokens=1500, temperature=0.3)
        except Exception as e:
            return f"Narrative generation failed: {str(e)}"