"""Field Ride Preparation node (#14).

Builds a PRE-visit briefing ("Field Ride Note") for a TAS by assembling existing data:
- Coaching history: _retrieve_memory_patterns (retrieval_node) + _get_prior_action_plan
- Territory / KPI snapshot: KPIAnalysisNode
- Relevant context: prior plan status, latest coaching summary, progress trend

Read-only: generates fresh each time, does NOT persist (v1 decision).
"""
from typing import Dict, Any
from pathlib import Path

from app.src.llm.bedrock_client import BedrockClient


def _load_prompt() -> str:
    path = Path(__file__).resolve().parents[1] / "llm" / "prompts" / "field_ride_prep.md"
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return "Prepare a concise pre-visit Field Ride briefing for the TAS from the data below."


def field_ride_prep_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a Field Ride Prep briefing for the selected TAS."""
    tas_id = (state.get("tas_id") or "").strip()
    tas_name = state.get("tas_name") or tas_id or "TAS"

    if not tas_id:
        return {"field_ride_note": None,
                "field_ride_status": "missing_tas"}

    # 1) Coaching history (recurring strengths/gaps, focus, progress) + prior plan.
    try:
        from app.src.graph.nodes.retrieval_node import _retrieve_memory_patterns
        memory = _retrieve_memory_patterns(tas_id) or {}
    except Exception as e:
        print(f"[#14] memory patterns failed: {e}")
        memory = {}

    try:
        from app.src.graph.nodes.field_collection_node import _get_prior_action_plan
        prior_plan = _get_prior_action_plan(tas_id) or {}
    except Exception as e:
        print(f"[#14] prior plan failed: {e}")
        prior_plan = {}

    # 2) Territory / KPI snapshot (reuse existing analysis node).
    try:
        from app.src.graph.nodes.kpi_analysis_node import KPIAnalysisNode
        kpi_result = KPIAnalysisNode(dict(state)).run() or {}
        kpi = kpi_result.get("kpi_analysis", {}) or {}
    except Exception as e:
        print(f"[#14] KPI analysis failed: {e}")
        kpi = {}

    # 3) Assemble the context for the LLM.
    import json
    context = f"""
TAS Name: {tas_name}

--- COACHING HISTORY ---
Recurring strengths: {json.dumps(memory.get("recurring_strengths", {}))}
Recurring development areas: {json.dumps(memory.get("recurring_development_areas", {}))}
Previous coaching focus: {json.dumps(memory.get("previous_coaching_focus", {}))}
Latest coaching summary: {memory.get("latest_coaching_summary", "None")}
Latest progress trend: {memory.get("latest_progress_trend", "unknown")}
Total FCRs in memory: {memory.get("total_fcrs_in_memory", 0)}

--- PREVIOUS ACTION PLAN (open items) ---
Goal: {prior_plan.get("description", "None on record")}
Due: {prior_plan.get("due_date", "N/A")}
Status: {prior_plan.get("status", "N/A")}
From month: {prior_plan.get("month", "N/A")}

--- TERRITORY / KPI SNAPSHOT ---
Territory: {kpi.get("territory", "N/A")}
Performance narrative:
{kpi.get("narrative", "No territory narrative available.")}
Key metrics:
{json.dumps(kpi.get("analysis", {}), indent=2, default=str)[:1500]}
"""

    prompt = _load_prompt() + "\n\n--- INPUT DATA ---\n" + context

    try:
        note = BedrockClient().invoke_claude(prompt=prompt, max_tokens=1500, temperature=0.4)
    except Exception as e:
        print(f"[#14] LLM generation failed: {e}")
        return {"field_ride_note": None, "field_ride_status": "failed"}

    reply = f"**🚗 Field Ride Prep — {tas_name}**\n\n{note}\n\n---\n\n[[action:Draft an FCR]]"

    return {
        "field_ride_note": note,
        "field_ride_status": "done",
        "messages_reply": reply,
    }
