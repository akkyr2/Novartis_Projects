"""Field collection node — handles intake field gathering (ABL, TAS, month, observations, SEAM)."""
from typing import Dict, Any, Optional, List
import re

from langchain_core.messages import AIMessage

from app.src.graph.nodes.intake_node import IntakeNodeInput, validate_inputs
from app.src.graph.nodes.input_validator import validate_field
from app.src.services.seam_generation_service import SEAMGenerationService


# ---------------------------------------------------------------------------
# Helper functions used ONLY by field collection
# ---------------------------------------------------------------------------

FIELD_QUESTIONS = {
    "abl_id": "_select_abl_",
    "tas_id": "_select_tas_",
    "month": "What month is this FCR for? (e.g., 2026-04)",
    "abl_eval_text": "**Now, tell me about your field day — what did you observe? Paste your notes or just describe what you saw.**",
    "selected_competencies": "Which competencies did you focus on observing today? (e.g., Plan, Engage, Advance, Follow-up)",
}


def _load_mapping():
    """Load TAS-Territory mapping."""
    import pandas as pd
    from pathlib import Path
    path = Path(__file__).resolve().parents[3] / "data" / "tas_territory_mapping.xlsx"
    if not path.exists():
        return pd.DataFrame()
    return pd.read_excel(str(path))


# --- #4 Historical Context: read the TAS's latest prior action plan from S3 memory ---
def _get_prior_action_plan(tas_id: str) -> Optional[Dict[str, Any]]:
    """Return the most recent prior SMART action/plan for this TAS, or None if no history.

    Reads memory/{tas_id}/index.json (fcr_history / action_plan_history) and the latest
    fcrs.json entry to surface the previous plan text, due date and status.
    """
    if not tas_id:
        return None
    import json
    import boto3
    from app.src.config import settings
    try:
        s3 = boto3.client("s3", region_name=settings.aws_region)
        bucket = settings.memory_s3_bucket

        # 1) Pull the latest FCR's own SMART action (becomes the "previous" plan).
        try:
            resp = s3.get_object(Bucket=bucket, Key=f"memory/{tas_id}/fcrs.json")
            fcrs = json.loads(resp["Body"].read().decode("utf-8"))
            if isinstance(fcrs, list) and fcrs:
                last = fcrs[-1]
                draft = last.get("fcr_json", {}) or {}
                actions = draft.get("smart_actions", []) or []
                if actions:
                    a = actions[0]
                    desc = a.get("action") or a.get("content") or ""
                    due = a.get("time_bound") or a.get("due") or a.get("due_date") or "N/A"
                    if desc:
                        return {
                            "description": desc,
                            "due_date": due,
                            "status": "In Progress",
                            "month": last.get("month", ""),
                        }
        except Exception:
            pass

        # 2) Fallback: index.json action_plan_history / next_coaching_focus.
        try:
            resp = s3.get_object(Bucket=bucket, Key=f"memory/{tas_id}/index.json")
            index = json.loads(resp["Body"].read().decode("utf-8"))
            hist = index.get("action_plan_history", []) or []
            if hist:
                last = hist[-1]
                actions = last.get("actions", []) or []
                if actions:
                    a = actions[0]
                    return {
                        "description": a.get("action", a.get("content", "")),
                        "due_date": a.get("due", a.get("due_date", "N/A")),
                        "status": a.get("status", "In Progress"),
                        "month": last.get("month", ""),
                    }
        except Exception:
            pass
    except Exception as e:
        print(f"[#4 history] lookup failed for {tas_id}: {e}")
    return None


def _get_abl_options(role: str = None) -> str:
    """Get formatted ABL selection message with clickable options."""
    from app.src.services.name_masking import mask_name
    DIRECT_LOGIN_ABLS = {"Arthur Dornik", "Kylee Hay", "Lucas Russo", "Terrence Barrett"}
    df = _load_mapping()
    if df.empty:
        return "Who are we coaching today? Give me the TAS name."
    abls = df["ABL"].unique().tolist()
    if role == "guest":
        abls = [a for a in abls if a not in DIRECT_LOGIN_ABLS]
        abls = [mask_name(a) for a in abls]
    else:
        abls = [a for a in abls if a in DIRECT_LOGIN_ABLS]
    options = " ".join([f"[[action:{abl}]]" for abl in abls])
    return f"Whom am I assisting today?\n\n{options}"


def _get_tas_options(abl_name: str, role: str = None) -> str:
    """Get formatted TAS selection message with clickable options."""
    from app.src.services.name_masking import mask_name
    df = _load_mapping()
    if df.empty:
        return "Who are we coaching today? Give me the TAS name."
    abl_lower = abl_name.lower().replace(" ", "")
    tas_list = df[df["ABL"].str.lower().str.replace(" ", "") == abl_lower]
    if tas_list.empty:
        tas_list = df[df["ABL"].str.lower().str.contains(abl_lower[:5])]
    if tas_list.empty:
        return "Who are we coaching today? Give me the TAS name."
    names = [row['TAS Name'] for _, row in tas_list.iterrows()]
    if role == "guest":
        names = [mask_name(n) for n in names]
    options = " ".join([f"[[action:{n}]]" for n in names])
    return f"Whom do you want to coach today?\n\n{options}"


def parse_competencies(text: str) -> List[str]:
    items = []

    for item in text.replace("\n", ",").split(","):
        cleaned = item.strip()

        if cleaned:
            items.append(cleaned)

    return items


def _detect_competencies(observation_text: str) -> List[str]:
    """Auto-detect competencies that NEED COACHING based on gaps in ABL observation text."""
    text_lower = observation_text.lower()
    detected = []

    # Plan: gaps in preparation, not anticipating questions, no pre-call planning
    plan_gap_keywords = ["not.*prepar", "didn't plan", "lack.*preparation", "no.*objective", "without.*plan", "didn't anticipat"]
    if any(re.search(k, text_lower) for k in plan_gap_keywords):
        detected.append("Plan")

    # Engage: gaps in dialogue, one-directional, hesitant, not comfortable, struggled with questions
    engage_gap_keywords = ["hesitant", "not.*comfortable", "one-directional", "struggled", "didn't.*engage", "lack.*confidence", "general response", "not fully comfortable", "relied heavily", "uncertainty"]
    if any(k in text_lower for k in engage_gap_keywords):
        detected.append("Engage")

    # Advance: couldn't handle objections, missed opportunity, didn't address concern, moved quickly past
    advance_gap_keywords = ["missed opportunity", "didn't.*address", "did not.*answer", "moved quickly", "didn't.*respond", "not.*directly", "couldn't.*advance", "did not directly"]
    if any(k in text_lower for k in advance_gap_keywords) or any(re.search(k, text_lower) for k in advance_gap_keywords):
        detected.append("Advance")

    # Close: no commitment sought, didn't ask for next steps, no close attempted
    close_gap_keywords = ["no.*commitment", "didn't.*close", "no.*next step", "failed.*close", "did not.*ask for"]
    if any(re.search(k, text_lower) for k in close_gap_keywords):
        detected.append("Close")

    # Follow-up: no follow-up planned, didn't establish next steps, no documentation
    followup_gap_keywords = ["no follow.?up plan", "didn't.*establish.*next step", "no.*documentation", "didn't.*document", "no.*recap", "did not.*follow up"]
    if any(re.search(k, text_lower) for k in followup_gap_keywords):
        detected.append("Follow-up")

    # Default: if nothing detected, at least Engage (most common coaching need)
    if not detected:
        detected = ["Engage"]

    return detected


def get_next_missing_field(state: dict) -> Optional[str]:
    if not state.get("abl_id") or state.get("abl_id") in ("ABL_DEFAULT", "Guest"):
        return "abl_id"

    if not state.get("tas_id"):
        return "tas_id"

    if not state.get("month"):
        return "month"

    if not state.get("abl_eval_text"):
        return "abl_eval_text"

    # Competencies are auto-detected from abl_eval_text, no need to ask
    return None


# ---------------------------------------------------------------------------
# Main node function
# ---------------------------------------------------------------------------

def field_collection_node(state: dict) -> Dict[str, Any]:
    """Collect intake fields: ABL, TAS, month, SEAM, observations."""
    from langchain_core.messages import HumanMessage

    messages = state.get("messages", [])
    last_user_message = ""
    for message in reversed(messages):
        if isinstance(message, HumanMessage):
            last_user_message = message.content.strip()
            break

    updates: Dict[str, Any] = {}

    # If FCR generation is complete, don't fall through to field collection
    intake_stage = state.get("intake_stage", "")
    if intake_stage == "complete" and not (state.get("fcr_result") and state.get("fcr_result", {}).get("draft")):
        return {"intake_complete": True}

    current_field = state.get("current_field")

    # Save answer from previous question
    if current_field and last_user_message:
        # Validate the input before accepting it
        is_valid, error_msg = validate_field(current_field, last_user_message)
        if not is_valid:
            return {
                "current_field": current_field,
                "intake_complete": False,
                "intake_stage": "intake",
                "messages": [AIMessage(content=f"⚠️ {error_msg}")],
            }

        if current_field == "selected_competencies":
            updates["selected_competencies"] = parse_competencies(last_user_message)
        elif current_field == "seam_notes":
            if last_user_message.lower().strip() in ["skip", "no", "n", "none"]:
                updates["seam_notes"] = ""
                updates["tas_prework_text"] = ""
            else:
                updates["seam_notes"] = last_user_message
                updates["tas_prework_text"] = last_user_message
            updates["seam_generated"] = True
        elif current_field == "abl_eval_text":
            updates["abl_eval_text"] = last_user_message
            # Auto-detect competencies from observation text
            detected = _detect_competencies(last_user_message)
            updates["selected_competencies"] = detected
            print(f"🔍 Auto-detected competencies: {detected}")
        elif current_field == "abl_id":
            # Match user input to ABL name from mapping
            df = _load_mapping()
            abls = df["ABL"].unique().tolist()
            matched = None
            # Unmask guest input (e.g. "Robert Downey" → "Andie Miller")
            from app.src.services.name_masking import unmask_name
            input_name = unmask_name(last_user_message.strip())
            for abl in abls:
                if input_name.lower() in abl.lower() or abl.lower() in input_name.lower():
                    matched = abl
                    break
            updates["abl_id"] = matched or last_user_message.strip()
        elif current_field == "tas_id":
            # Match user input to TAS name from mapping
            df = _load_mapping()
            tas_names = df["TAS Name"].tolist()
            matched = None
            # Unmask guest input (e.g. "Tony Stark" → "Devon Seibert")
            from app.src.services.name_masking import unmask_name, mask_name
            input_name = unmask_name(last_user_message.strip())
            for tas in tas_names:
                if input_name.lower() in tas.lower() or tas.lower() in input_name.lower():
                    matched = tas
                    break
            updates["tas_id"] = matched or last_user_message.strip()
            # For guest: set tas_name to masked name so LLM uses it in prompts
            if state.get("role") == "guest":
                updates["tas_name"] = mask_name(updates["tas_id"])
            else:
                updates["tas_name"] = updates["tas_id"]

            # --- #4 Historical Context: if this TAS has a prior plan, offer to
            # Continue / Review / Start New before continuing intake. ---
            prior = _get_prior_action_plan(updates["tas_id"])
            if prior and not state.get("history_choice_made"):
                msg = (
                    f"📋 I found a previous coaching plan for **{updates['tas_name']}**.\n\n"
                    f"**Previous SMART Goal:**\n_{prior.get('description', 'N/A')}_\n\n"
                    f"Due: {prior.get('due_date', 'N/A')}  ·  Status: **{prior.get('status', 'Pending')}**\n\n"
                    "How would you like to proceed?\n\n"
                    "[[action:Continue Previous Plan]] [[action:Review Progress]] [[action:Start New]]"
                )
                return {
                    **updates,
                    "prior_action_plan": prior,
                    "awaiting_history_choice": True,
                    "current_field": "tas_id",  # stay here until the user chooses
                    "intake_complete": False,
                    "intake_stage": "intake",
                    "messages": [AIMessage(content=msg)],
                }
        elif current_field == "month":
            from app.src.graph.nodes.input_validator import normalize_month
            import re as _re
            parsed = normalize_month(last_user_message)
            if not parsed or not _re.match(r'^\d{4}-\d{2}$', parsed):
                return {
                    "current_field": "month",
                    "intake_complete": False,
                    "intake_stage": "intake",
                    "messages": [AIMessage(content="⚠️ I couldn't understand that date. Please try again (e.g., 'June 2026').")],
                }
            updates["month"] = parsed
        else:
            updates[current_field] = last_user_message

    updated_state = {
        **state,
        **updates,
    }

    # After TAS ID + month are collected, ask for SEAM if not already provided
    if updated_state.get("tas_id") and updated_state.get("month") and not updated_state.get("seam_generated"):
        # Handle yes/no response for viewing SEAM (legacy — kept for backward compat)
        if state.get("seam_show_pending"):
            lower_msg = last_user_message.lower().strip()
            seam_text = state.get("_seam_text_pending", "")
            if lower_msg in ["yes", "y"]:
                return {
                    **updates,
                    "seam_show_pending": False,
                    "tas_prework_text": seam_text,
                    "current_field": "abl_eval_text",
                    "intake_complete": False,
                    "intake_stage": "intake",
                    "messages": [AIMessage(content=f"📝 **SEAM Pre-work:**\n\n{seam_text}\n\n---\n\n**Now, tell me about your field day — what did you observe?** Paste your notes or just describe what you saw.")],
                }
            else:
                return {
                    **updates,
                    "seam_show_pending": False,
                    "tas_prework_text": seam_text,
                    "current_field": "abl_eval_text",
                    "intake_complete": False,
                    "intake_stage": "intake",
                    "messages": [AIMessage(content="No problem. Tell me about your field day — what did you observe?")],
                }

        # Ask ABL for TAS-submitted SEAM pre-work
        tas_id = updated_state["tas_id"]

        # Resolve territory from mapping for downstream KPI lookups
        seam_service = SEAMGenerationService()
        resolved_territory = seam_service._resolve_territory(tas_id)
        if resolved_territory:
            updates["territory"] = resolved_territory

        return {
            **updates,
            "seam_generated": False,
            "seam_show_pending": False,
            "current_field": "seam_notes",
            "intake_complete": False,
            "intake_stage": "intake",
            "messages": [AIMessage(content=f"Can you please share **{tas_id}**'s SEAM Pre-Work or [[action:skip]] to continue.")],
        }

    next_missing_field = get_next_missing_field(updated_state)

    if next_missing_field:
        if next_missing_field == "abl_id":
            question = _get_abl_options(role=updated_state.get("role"))
        elif next_missing_field == "tas_id":
            question = _get_tas_options(updated_state.get("abl_id", ""), role=updated_state.get("role"))
        else:
            question = FIELD_QUESTIONS[next_missing_field]

        return {
            **updates,
            "current_field": next_missing_field,
            "intake_complete": False,
            "intake_stage": "intake",
            "messages": [
                AIMessage(content=question)
            ],
        }

    intake_input = IntakeNodeInput(
        tas_prework_text=updated_state.get("tas_prework_text", "") or "",
        abl_eval_text=updated_state.get("abl_eval_text", "") or "",
        selected_competencies=updated_state.get("selected_competencies", []) or [],
    )

    intake_result = validate_inputs(intake_input)

    if not intake_result.valid:
        question_text = "\n".join(intake_result.questions)

        return {
            **updates,
            "current_field": None,
            "intake_complete": False,
            "intake_stage": "intake",
            "intake": {
                "valid": intake_result.valid,
                "questions": intake_result.questions,
            },
            "messages": [
                AIMessage(content=question_text)
            ],
        }

    # Basic intake complete - check if already complete from previous
    already_complete = state.get("intake_complete", False)

    if already_complete:
        # Preserve state
        return {
            "intake_complete": True,
        }

    # First time completing intake - start evaluation coaching
    detected_comps = updated_state.get("selected_competencies", [])
    comp_list = ", ".join(detected_comps) if detected_comps else "Engage"

    # Build clickable options for competencies NOT yet detected
    all_comps = ["Plan", "Engage", "Advance", "Close", "Follow-up"]
    remaining = [c for c in all_comps if c not in detected_comps]
    add_options = " ".join([f"[[action:Add {c}]]" for c in remaining])
    
    msg = f"Based on your observations, these competencies need coaching: **{comp_list}**.\n\nYou can add, remove, or proceed as-is.\n\n{add_options} [[action:Proceed]]"

    return {
        **updates,
        "current_field": None,
        "intake_complete": True,
        "intake_stage": "eval_coaching",
        "eval_coaching_stage": "not_started",
        "eval_questions_asked": [],
        "eval_question_count": 0,
        "eval_answers": {},
        "evaluation_confirmed": False,
        "tas_name": updated_state.get("tas_id"),
        "intake": {
            "valid": True,
            "questions": [],
        },
        "messages": [
            AIMessage(content=msg)
        ],
    }
