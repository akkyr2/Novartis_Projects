import json
from typing import Dict, Any, List

from app.src.llm.bedrock_client import BedrockClient


class ReviseNode:
    """
    Revises the FCR draft based on user feedback or rubric issues.
    """

    def __init__(self, state: Dict[str, Any]):
        self.state = state

    def run(self) -> Dict[str, Any]:
        """
        Revise the draft based on user feedback and rubric issues.

        Returns:
            Dict with updated 'draft' key
        """
        draft = self.state.get("draft", {})
        rubric_issues = self.state.get("rubric_issues", [])
        user_feedback = self.state.get("user_feedback", "")
        kpi_analysis = self.state.get("kpi_analysis", {})

        if not draft:
            return {"draft": None}

        # Build revision prompt
        prompt = self._build_revision_prompt(draft, rubric_issues, user_feedback, kpi_analysis)

        # Call LLM to revise
        try:
            bedrock = BedrockClient()
            model_id = None

            llm_output = bedrock.invoke_claude(
                prompt=prompt,
                model_id=model_id,
                max_tokens=4096,
                temperature=0.0,
            )

            if not llm_output:
                return {
                    "draft": {
                        **draft,
                        "status": "revision_failed",
                        "error": "LLM returned no output",
                    }
                }

            # Parse revised draft
            revised_draft = self._parse_revised_draft(llm_output, draft)

            return {"draft": revised_draft}

        except Exception as e:
            print(f"❌ Revision failed: {e}")
            import traceback
            traceback.print_exc()
            return {
                "draft": {
                    **draft,
                    "status": "revision_failed",
                    "error": str(e),
                }
            }

    def _build_revision_prompt(
        self,
        draft: Dict[str, Any],
        rubric_issues: List[Any],
        user_feedback: str,
        kpi_analysis: Dict[str, Any],
    ) -> str:
        """Build prompt for revising the draft."""

        # Format rubric issues
        issues_text = ""
        if rubric_issues:
            issues_text = "**Rubric Issues Found:**\n"
            for issue in rubric_issues:
                if isinstance(issue, dict):
                    severity = issue.get("severity", "").upper()
                    section = issue.get("section", "")
                    desc = issue.get("issue", "")
                    suggestion = issue.get("suggestion", "")
                    issues_text += f"- [{severity}] {section}: {desc}\n"
                    if suggestion:
                        issues_text += f"  Suggestion: {suggestion}\n"
                else:
                    issues_text += f"- {issue}\n"

        # Format user feedback
        feedback_text = ""
        if user_feedback:
            feedback_text = f"**User Feedback:**\n{user_feedback}\n"

        tas_name = self.state.get("tas_name") or self.state.get("tas_id") or "TAS"

        prompt = f"""You are revising a Field Coaching Report (FCR) draft based on quality issues and user feedback.

CRITICAL NAME RULE: The TAS name is "{tas_name}". You MUST use ONLY this name. Do NOT change it or substitute any other name.

**Current Draft:**
{json.dumps(draft, indent=2)}

{issues_text}

{feedback_text}

**Instructions:**
1. Address ALL rubric issues listed above
2. Incorporate user feedback if provided
3. Maintain the same JSON structure
4. Keep all good elements from the original draft
5. Ensure competency evidence is specific and actionable
6. Ensure observations follow "What I Saw" + "Impact" format
7. Ensure SMART actions are Specific, Measurable, Achievable, Relevant, Time-bound
8. Update the status to "revised"

**Return the complete revised FCR in JSON format:**

{{
  "fcr_id": "string",
  "tas_id": "string",
  "month": "string",
  "summary": "string",
  "performance_kpis": [...],
  "kpi_narrative": "string",
  "competencies": [...],
  "observations": [...],
  "smart_actions": [...],
  "status": "revised"
}}

Return ONLY the JSON, no other text."""

        return prompt

    def _parse_revised_draft(self, llm_output: str, original_draft: Dict[str, Any]) -> Dict[str, Any]:
        """Parse the revised draft from LLM output."""
        try:
            # Clean JSON from markdown
            cleaned = llm_output.strip()
            if "```json" in cleaned:
                cleaned = cleaned.split("```json")[1].split("```")[0].strip()
            elif "```" in cleaned:
                cleaned = cleaned.split("```")[1].split("```")[0].strip()

            revised_draft = json.loads(cleaned)

            # Ensure status is set
            if "status" not in revised_draft:
                revised_draft["status"] = "revised"

            return revised_draft

        except json.JSONDecodeError as e:
            print(f"❌ Failed to parse revised draft JSON: {e}")
            print(f"LLM output: {llm_output[:500]}")
            return {
                **original_draft,
                "status": "revision_failed_parse",
                "raw_llm_output": llm_output,
            }