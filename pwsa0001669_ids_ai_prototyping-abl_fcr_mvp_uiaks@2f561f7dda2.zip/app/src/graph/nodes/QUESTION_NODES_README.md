# Question Nodes - Interactive Information Collection

## Overview

The question nodes implement an **intelligent gap analysis and interactive questioning system** that ensures the ABL provides all necessary information before drafting the FCR.

This prevents incomplete FCRs and ensures high-quality coaching reports grounded in specific observations.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    QUESTION FLOW                            │
└─────────────────────────────────────────────────────────────┘

retrieval_node
    ↓
    [context_bundle with past FCRs, guidelines, KPIs]
    ↓
question_planner_node
    ↓
    [Analyzes available info, identifies gaps]
    ↓
    ┌──────────────┐
    │ Gaps found?  │
    └──────────────┘
         │
    ┌────┴────┐
    │         │
   Yes       No
    │         │
    ↓         ↓
ask_user_node  draft_fcr_node
    ↓
[Present questions to ABL]
    ↓
[ABL provides answers]
    ↓
[Enrich state with answers]
    ↓
draft_fcr_node
```

---

## Components

### 1. Question Planner Node

**File:** [`question_planner_node.py`](question_planner_node.py)

**Purpose:** Analyzes available information and identifies gaps that would prevent drafting a high-quality FCR.

#### How It Works

1. **Assess Available Information**
   - Checks state for key FCR elements
   - Evaluates completeness of coaching details
   - Considers context bundle (historical FCRs, KPIs)

2. **Identify Gaps**
   - **Critical gaps**: Must-have for FCR (e.g., observation details, competencies)
   - **Important gaps**: Quality indicators (e.g., strengths, opportunities, impact)
   - **Helpful gaps**: Enhancement factors (e.g., SEAM notes, KPI references)

3. **Generate Questions**
   - Prioritizes by severity (critical → important → helpful)
   - Generates up to 3 targeted questions
   - Uses AI (Claude via Bedrock) or template-based generation

#### Input

```python
state = {
    "tas_id": "TAS_12345",
    "tas_name": "John Smith",
    "month": "May 2026",
    "context_bundle": {...},  # From retrieval_node
    # ... other coaching details
}
```

#### Output

```python
{
    "questions_needed": [
        {
            "question": "Can you describe the key observations...",
            "purpose": "Capture foundational coaching details",
            "expected_answer_type": "narrative",
            "prompts": ["What was the context?", "What stood out?"]
        },
        # ... up to 3 questions
    ],
    "gap_analysis": {
        "total_gaps_identified": 5,
        "critical_gaps": 2,
        "important_gaps": 2,
        "helpful_gaps": 1,
        "analysis_summary": "..."
    },
    "should_ask_questions": true,
    "identified_gaps": [...],
    "planner_status": "complete"
}
```

#### Gap Types

| Gap Type | Severity | Description | Required For |
|----------|----------|-------------|--------------|
| `missing_observation` | Critical | No field visit details | FCR narrative foundation |
| `missing_competencies` | Critical | No skill areas identified | Targeted coaching focus |
| `missing_strengths` | Important | Strengths not identified | Balanced coaching |
| `missing_opportunities` | Important | Development areas unclear | Actionable guidance |
| `missing_impact` | Important | No performance impact stated | TAS understanding |
| `missing_actions` | Important | No next steps defined | Developmental roadmap |
| `missing_seam` | Helpful | SEAM framework not documented | Structured approach |
| `missing_context` | Helpful | No developmental context | Personalized coaching |
| `missing_kpis` | Helpful | No metrics referenced | Data-driven observations |

---

### 2. Ask User Node

**File:** [`ask_user_node.py`](ask_user_node.py)

**Purpose:** Presents questions to the ABL and captures their responses.

#### How It Works

1. **Format Questions**
   - Prepares questions for UI presentation
   - Adds context (TAS name, month)
   - Provides UI hints (multiline, placeholders)

2. **Check for Answers**
   - If `user_answers` exists in state → enrich state
   - If no answers → return questions and set `awaiting_user_input`

3. **Enrich State**
   - Maps answers to appropriate state keys
   - Parses list-type answers (competencies)
   - Stores in structured `collected_answers`

#### Input

```python
state = {
    "questions_needed": [...],  # From question_planner_node
    "tas_name": "John Smith",
    "month": "May 2026",
    # Optional:
    "user_answers": {
        "q1": "Field visit with Dr. Martinez...",
        "q2": "Selling Skills, Clinical Knowledge",
        "q3": "Strong rapport, good preparation..."
    }
}
```

#### Output (Without Answers)

```python
{
    "questions_to_ask": [
        {
            "question_id": "q1",
            "question_number": 1,
            "question_text": "Can you describe...",
            "purpose": "...",
            "expected_answer_type": "narrative",
            "prompts": [...],
            "context": {"tas_name": "John Smith", "month": "May 2026"},
            "ui_hints": {
                "multiline": true,
                "min_length": 50,
                "placeholder": "..."
            }
        }
    ],
    "awaiting_user_input": true,
    "ask_user_status": "questions_presented"
}
```

#### Output (With Answers)

```python
{
    "observation_notes": "Field visit with Dr. Martinez...",
    "selected_competencies": ["Selling Skills", "Clinical Knowledge"],
    "observed_strengths": "Strong rapport, good preparation...",
    "collected_answers": {
        "q1": {"question": "...", "answer": "...", "purpose": "..."}
    },
    "awaiting_user_input": false,
    "ask_user_status": "answers_received"
}
```

#### Answer Mapping

Questions are automatically mapped to state keys based on their purpose:

| Purpose Keywords | State Key | Type |
|-----------------|-----------|------|
| "observation", "field visit" | `observation_notes`, `abl_eval_text` | narrative |
| "competency", "skill" | `selected_competencies` | list |
| "strength" | `observed_strengths` | narrative |
| "opportunity", "improve" | `development_opportunities` | narrative |
| "impact" | `impact_statement` | narrative |
| "action", "next steps" | `action_items` | narrative |
| "seam", "conversation" | `seam_notes` | narrative |
| "context", "developmental" | `developmental_context` | narrative |
| "kpi", "metric" | `kpi_notes` | narrative |

---

### 3. Question Generation Service (AI-Powered)

**File:** [`question_generation_service.py`](../../services/question_generation_service.py)

**Purpose:** Generates contextual, high-quality questions using Claude via Bedrock.

#### Why AI-Generated Questions?

**Template-based questions:**
- Generic, one-size-fits-all
- Don't adapt to context
- May ask irrelevant questions

**AI-generated questions:**
- Contextual and specific to the situation
- Adapt to available information
- More natural phrasing
- Better coaching alignment

#### Example Comparison

**Template-based:**
> "What specific strengths did the TAS demonstrate?"

**AI-generated (with context):**
> "Based on your field visit with John Smith in May, what specific strengths did he demonstrate when presenting Allergy Solution X to Dr. Martinez? Consider his clinical knowledge, rapport building, and preparation."

#### Configuration

Enable/disable in state:

```python
state["use_ai_question_generation"] = True  # Default
# or
state["use_ai_question_generation"] = False  # Use templates
```

---

## Integration with Graph Flow

### Option 1: Linear Flow (Questions Always Asked)

```python
from langgraph.graph import StateGraph

workflow = StateGraph(state_schema)

workflow.add_node("retrieval", retrieval_node)
workflow.add_node("question_planner", question_planner_node)
workflow.add_node("ask_user", ask_user_node)
workflow.add_node("draft_fcr", draft_fcr_node)

workflow.add_edge("retrieval", "question_planner")
workflow.add_edge("question_planner", "ask_user")
workflow.add_edge("ask_user", "draft_fcr")
```

### Option 2: Conditional Flow (Skip if Complete)

```python
def should_ask_questions(state):
    """Route to ask_user or directly to draft based on completeness."""
    return "ask_user" if state.get("should_ask_questions") else "draft_fcr"

workflow.add_node("retrieval", retrieval_node)
workflow.add_node("question_planner", question_planner_node)
workflow.add_node("ask_user", ask_user_node)
workflow.add_node("draft_fcr", draft_fcr_node)

workflow.add_edge("retrieval", "question_planner")
workflow.add_conditional_edges(
    "question_planner",
    should_ask_questions,
    {
        "ask_user": "ask_user",
        "draft_fcr": "draft_fcr"
    }
)
workflow.add_edge("ask_user", "draft_fcr")
```

### Option 3: Retry Loop (Re-ask if Insufficient)

```python
def needs_more_info(state):
    """Check if we need to ask more questions after initial answers."""
    if state.get("awaiting_user_input"):
        return "wait_for_input"
    elif state.get("questions_already_asked"):
        return "draft_fcr"
    else:
        return "question_planner"

workflow.add_edge("retrieval", "question_planner")
workflow.add_edge("question_planner", "ask_user")
workflow.add_conditional_edges(
    "ask_user",
    needs_more_info,
    {
        "wait_for_input": END,  # Pause for UI to collect answers
        "question_planner": "question_planner",  # Re-plan if needed
        "draft_fcr": "draft_fcr"
    }
)
```

---

## UI Integration Patterns

### Web Form Pattern

```python
# Backend: Generate questions
state = question_planner_node(state)
questions = ask_user_node(state)["questions_to_ask"]

# Frontend: Render form
for q in questions:
    render_question_field(
        id=q["question_id"],
        label=q["question_text"],
        type="textarea" if q["ui_hints"]["multiline"] else "text",
        placeholder=q["ui_hints"]["placeholder"],
        help_text=q["purpose"]
    )

# Backend: Process submission
user_answers = request.form.to_dict()
state = set_user_answers(state, user_answers)
result = ask_user_node(state)
```

### Chat Interface Pattern

```python
# Present questions one at a time
questions = state["questions_to_ask"]

for q in questions:
    # Send question to chat
    send_message(f"**Question {q['question_number']}/{len(questions)}:**\n{q['question_text']}")
    
    # Show prompts
    if q["prompts"]:
        send_message(f"_Consider: {', '.join(q['prompts'])}_")
    
    # Wait for user response
    answer = await get_user_message()
    
    # Store answer
    user_answers[q["question_id"]] = answer

# Enrich state
state = set_user_answers(state, user_answers)
```

### Voice Input Pattern

```python
# Convert questions to speech
for q in questions["questions_to_ask"]:
    text_to_speech(q["question_text"])
    
    # Record answer
    audio = record_audio()
    answer_text = speech_to_text(audio)
    
    user_answers[q["question_id"]] = answer_text

state = set_user_answers(state, user_answers)
```

---

## Configuration

### Environment Variables

```bash
# For AI-powered question generation
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=us.anthropic.claude-sonnet-4-20250514-v1:0

# Optional: Disable AI questions (use templates)
USE_AI_QUESTION_GENERATION=false
```

### State Configuration

```python
# Set in state to override defaults
state["use_ai_question_generation"] = True  # or False
state["max_questions"] = 3  # Default: 3
state["questions_already_asked"] = False  # Track if already asked
```

---

## Testing

### Run Examples

```bash
cd app/examples
python question_flow_example.py
```

### Unit Tests

```python
def test_complete_info_no_questions():
    """Test that complete info generates no questions."""
    state = {
        "tas_id": "TAS_123",
        "observation_notes": "Field visit details...",
        "selected_competencies": ["Selling Skills"],
        "observed_strengths": "Strong rapport...",
        "development_opportunities": "Improve closing...",
        "impact_statement": "Would increase sales...",
        "action_items": "Practice closing scenarios...",
    }
    
    result = question_planner_node(state)
    assert result["should_ask_questions"] == False
    assert len(result["questions_needed"]) == 0

def test_minimal_info_generates_questions():
    """Test that minimal info generates 3 questions."""
    state = {
        "tas_id": "TAS_123",
        "tas_name": "John Smith",
    }
    
    result = question_planner_node(state)
    assert result["should_ask_questions"] == True
    assert len(result["questions_needed"]) == 3
    assert result["gap_analysis"]["critical_gaps"] > 0
```

---

## Best Practices

### 1. **Question Quality**
- Keep questions specific and actionable
- Frame in coaching context (not interrogative)
- Provide helpful prompts to guide thinking
- Limit to 3 questions maximum (cognitive load)

### 2. **Gap Prioritization**
- Always address critical gaps first
- Don't ask for information already available
- Consider historical FCR patterns (available in context_bundle)

### 3. **Answer Validation**
- Check minimum length for narrative answers
- Validate list-type answers are parseable
- Provide clear feedback if answer insufficient

### 4. **User Experience**
- Show purpose of each question
- Display progress (Question 1 of 3)
- Offer prompts to guide answers
- Allow saving partial answers

### 5. **Error Handling**
- Fallback to template questions if AI fails
- Continue with partial info if questions skipped
- Flag missing critical info in draft FCR

---

## Troubleshooting

### No Questions Generated Despite Missing Info

**Check:**
- `questions_already_asked` flag not set incorrectly
- Gap identification logic working correctly
- State keys match expected format

### AI Question Generation Failing

**Check:**
- Bedrock model access enabled
- Correct model ID configured
- AWS credentials valid
- Fallback to template questions works

### Answers Not Enriching State

**Check:**
- `user_answers` dict keys match `question_id` (q1, q2, q3)
- Answer mapping logic recognizes purpose keywords
- State updates returned and merged correctly

---

## Next Steps

1. **Integrate with UI** - Implement form/chat interface
2. **Test with real ABLs** - Validate question quality and relevance
3. **Tune AI prompts** - Refine question generation for better context
4. **Add validation** - Check answer quality before proceeding
5. **Track metrics** - Monitor questions asked, skip rate, answer quality

---

## Related Documentation

- [Retrieval Node README](RETRIEVAL_NODE_README.md) - Context gathering before questions
- [Draft FCR Node](draft_fcr_node.py) - Uses enriched state to generate FCR
- [Question Generation Service](../../services/question_generation_service.py) - AI-powered question generation
