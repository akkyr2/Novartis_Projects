"""
Memory Update Node - Stores FCR, patterns, and coaching profile to S3.

Storage structure:
  s3://bucket/memory/{tas_id}/fcrs/{month}.json        — Raw FCR snapshot
  s3://bucket/memory/{tas_id}/patterns/{month}.json    — Raw pattern mining output
  s3://bucket/memory/{tas_id}/sessions/{month}.json    — Rich session record (dashboard)
  s3://bucket/memory/{tas_id}/index.json               — Continuity index (all sections)

The index powers the TAS Coaching Profile dashboard:
1. TAS Coaching Snapshot (FCRs reviewed, status, top strength, recurring dev area)
2. AI Coaching Summary (progress, strengths, gaps, next focus, risks)
3. Coaching Journey Timeline (month-by-month progression)
4. Strengths & Development Areas (categorized with frequency counts)
5. Coaching Theme Trend (theme status per month)
6. Repeated Pattern Cards (recurring patterns with evidence + frequency)
7. Field Day vs Past FCR Comparison (current observation vs history)
8. Action Plan Tracking (SMART action completion over time)
9. Progress History (trend, improved, continued gaps, new issues)
"""

from typing import Dict, Any, List, Optional
import json
import boto3
import os
from datetime import datetime

from app.src.config import settings


class MemoryUpdateNode:
    """Stores coaching memory powering the TAS Coaching Profile and pattern mining."""

    def __init__(self, state: Dict[str, Any]):
        self.state = state
        self.tas_id = state.get("tas_id")
        self.tas_name = self.tas_id or "TAS"  # Always use real name for storage
        self.abl_id = state.get("abl_id")
        self.month = state.get("month")
        self.territory = state.get("territory")
        self.draft = state.get("draft", {})
        self.edited_fcr_fields = state.get("edited_fcr_fields")  # edited structured fields from popup
        self.pattern_mining = state.get("pattern_mining", {})
        self.context_bundle = state.get("context_bundle", {})
        self.evaluation_draft = state.get("evaluation_draft")
        self.seam_notes = state.get("seam_notes")

        self.s3_client = boto3.client("s3", region_name=settings.aws_region)
        self.bucket_name = settings.memory_s3_bucket
        self.memory_prefix = "memory"

    def run(self) -> Dict[str, Any]:
        if not self.tas_id or not self.draft:
            return {"memory_update": {"status": "skipped", "reason": "Missing TAS ID or draft"}}

        try:
            # Store raw artifacts (for independent retrieval)
            fcr_stored = self._store_fcr()
            patterns_stored = self._store_patterns()

            # Build and store rich session record (for dashboard)
            session = self._build_session_record()
            self._store_session(session)

            # Update the master index (powers dashboard + pattern node)
            index_updated = self._update_index(session)

            # Append to TAS profile (powers patterns page directly)
            self._update_profile()

            # If the user edited the FCR in the popup, save it as a Coaching Report PDF
            # in a dedicated edited_FCR/ subfolder (structured-field driven).
            if self.edited_fcr_fields:
                self._store_edited_pdf()

            print(f"[MemoryUpdate] Stored memory for {self.tas_id} ({self.tas_name})")
            return {
                "memory_update": {
                    "status": "completed",
                    "fcr_stored": fcr_stored,
                    "patterns_stored": patterns_stored,
                    "index_updated": index_updated,
                    "total_sessions": index_updated.get("total_sessions", 0) if isinstance(index_updated, dict) else 0,
                    "trajectory": index_updated.get("trajectory", "new_baseline") if isinstance(index_updated, dict) else "new_baseline",
                    "s3_path": f"s3://{self.bucket_name}/{self.memory_prefix}/{self.tas_id}/",
                }
            }
        except Exception as e:
            print(f"[MemoryUpdate] Failed: {e}")
            import traceback
            traceback.print_exc()
            return {"memory_update": {"status": "failed", "error": str(e)}}

    # ─── Raw Artifact Storage ─────────────────────────────────────────────

    def _store_fcr(self) -> bool:
        """Append FCR to single fcrs.json array — never overwrites."""
        try:
            key = f"{self.memory_prefix}/{self.tas_id}/fcrs.json"
            # Load existing
            try:
                resp = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
                fcrs = json.loads(resp["Body"].read().decode("utf-8"))
                if isinstance(fcrs, dict):
                    fcrs = [fcrs]
            except Exception:
                fcrs = []

            fcrs.append({
                "tas_id": self.tas_id,
                "month": self.month,
                "created_at": datetime.now().isoformat(),
                "session_id": self.state.get("session_id"),
                "fcr_json": self.draft,
            })

            self.s3_client.put_object(
                Bucket=self.bucket_name, Key=key,
                Body=json.dumps(fcrs, indent=2, default=str),
                ContentType="application/json",
            )
            return True
        except Exception as e:
            print(f"[MemoryUpdate] Failed to store FCR: {e}")
            return False

    def _store_edited_pdf(self) -> bool:
        """Save the user-edited FCR as a Novartis Coaching Report PDF in a dedicated
        edited_FCR/ subfolder, named month + current date-time.

        Key: memory/{tas_id}/edited_FCR/{month}_{YYYYmmdd_HHMMSS}.pdf
        Uses the shared fcr_pdf_service so the format matches the popup preview/download.
        """
        try:
            from app.src.services.fcr_pdf_service import render_coaching_report_pdf

            fields = self.edited_fcr_fields
            if not fields:
                return False

            month = self.month or datetime.now().strftime("%Y-%m")
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            key = f"{self.memory_prefix}/{self.tas_id}/edited_FCR/{month}_{timestamp}.pdf"
            pdf_bytes = render_coaching_report_pdf(fields)

            self.s3_client.put_object(
                Bucket=self.bucket_name, Key=key,
                Body=pdf_bytes,
                ContentType="application/pdf",
            )
            print(f"[MemoryUpdate] Stored edited FCR PDF: {key}")
            return True
        except Exception as e:
            print(f"[MemoryUpdate] Failed to store edited FCR PDF: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _store_patterns(self) -> bool:
        """Append patterns to single patterns.json array — never overwrites."""
        try:
            patterns = self.pattern_mining.get("patterns", {})
            if not patterns:
                return False
            key = f"{self.memory_prefix}/{self.tas_id}/patterns.json"
            # Load existing
            try:
                resp = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
                all_patterns = json.loads(resp["Body"].read().decode("utf-8"))
                if isinstance(all_patterns, dict):
                    all_patterns = [all_patterns]
            except Exception:
                all_patterns = []

            patterns["month"] = self.month
            patterns["created_at"] = datetime.now().isoformat()
            all_patterns.append(patterns)

            self.s3_client.put_object(
                Bucket=self.bucket_name, Key=key,
                Body=json.dumps(all_patterns, indent=2, default=str),
                ContentType="application/json",
            )
            return True
        except Exception as e:
            print(f"[MemoryUpdate] Failed to store patterns: {e}")
            return False

    def _store_session(self, session: Dict[str, Any]):
        """Append session to single sessions.json array — never overwrites."""
        key = f"{self.memory_prefix}/{self.tas_id}/sessions.json"
        try:
            resp = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
            all_sessions = json.loads(resp["Body"].read().decode("utf-8"))
            if isinstance(all_sessions, dict):
                all_sessions = [all_sessions]
        except Exception:
            all_sessions = []

        session["created_at"] = datetime.now().isoformat()
        all_sessions.append(session)

        self.s3_client.put_object(
            Bucket=self.bucket_name, Key=key,
            Body=json.dumps(all_sessions, indent=2, default=str),
            ContentType="application/json",
        )

    def _update_profile(self):
        """Append this session to the TAS profile.json (single file powering patterns page)."""
        key = f"{self.memory_prefix}/{self.tas_id}/profile.json"

        # Load existing profile or create new
        try:
            resp = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
            profile = json.loads(resp["Body"].read().decode("utf-8"))
        except Exception:
            profile = {
                "TAS_NAME": self.tas_name,
                "ABL_NAME": self.abl_id or "",
                "Territory": self.territory or "",
                "SESSION_MEMORY": [],
            }

        # Update metadata
        profile["TAS_NAME"] = self.tas_name
        profile["ABL_NAME"] = self.abl_id or profile.get("ABL_NAME", "")
        profile["Territory"] = self.territory or profile.get("Territory", "")

        # Build session entry from patterns + FCR data
        patterns = self.pattern_mining.get("patterns", {})
        raw_strengths = patterns.get("strengths", [])
        raw_dev = patterns.get("development_areas", [])
        pat_strengths = [s.get("area", "") if isinstance(s, dict) else str(s) for s in raw_strengths if s]
        pat_dev_areas = [d.get("area", "") if isinstance(d, dict) else str(d) for d in raw_dev if d]
        # Deduplicate: remove dev areas that also appear in strengths
        str_lower = {s.lower().strip() for s in pat_strengths}
        pat_dev_areas = [d for d in pat_dev_areas if d.lower().strip() not in str_lower]

        # Coaching themes
        themes = patterns.get("coaching_themes", [])
        theme_names = [t.get("theme", "") if isinstance(t, dict) else str(t) for t in themes if t]
        if not theme_names:
            theme_names = patterns.get("action_themes", [])

        # Competency names from competency_scores
        comp_scores = patterns.get("competency_scores", [])
        comp_names = [c.get("name", "") if isinstance(c, dict) else str(c) for c in comp_scores if c]

        # Coaching topics from FCR competencies
        draft_comps = self.draft.get("competencies", [])
        coaching_topics = [c.get("name", "") for c in draft_comps if isinstance(c, dict) and c.get("name")]

        # Evaluation summary
        eval_text = self.evaluation_draft or ""
        eval_summary = eval_text[:300] if isinstance(eval_text, str) else ""

        session_entry = {
            "DATETIME": datetime.now().isoformat(),
            "month": self.month,
            "Evaluation note summary": eval_summary,
            "Evaluation note Strengths": ", ".join(pat_strengths[:3]),
            "Evaluation note Areas of Improvement": ", ".join(pat_dev_areas[:3]),
            "SEAM note summary": str(self.seam_notes or "")[:200],
            "SEAM note Strengths": ", ".join(pat_strengths[:2]),
            "SEAM note Areas of Improvement": ", ".join(pat_dev_areas[:2]),
            "FCR note summary": self.draft.get("summary", ""),
            "FCR note Strengths": ", ".join(pat_strengths),
            "FCR note Areas of Improvement": ", ".join(pat_dev_areas),
            "Areas coached": "|".join(comp_names) if comp_names else "|".join(coaching_topics),
            "Key Coaching Topics": coaching_topics[:3] if coaching_topics else [""],
        }

        profile["SESSION_MEMORY"].append(session_entry)

        # Save back
        self.s3_client.put_object(
            Bucket=self.bucket_name,
            Key=key,
            Body=json.dumps(profile, indent=2, default=str),
            ContentType="application/json",
        )

    # ─── Session Record Builder ───────────────────────────────────────────

    def _build_session_record(self) -> Dict[str, Any]:
        """Build rich session record for dashboard and pattern node."""
        now = datetime.now()
        patterns = self.pattern_mining.get("patterns", {})
        comp_patterns = patterns.get("competency_patterns", {})
        continuity = patterns.get("coaching_continuity", {})
        progress = patterns.get("progress_since_last", {})
        recommendations = patterns.get("coaching_recommendations", {})

        strengths = [c for c, v in comp_patterns.items() if isinstance(v, dict) and v.get("status") == "strength"]
        dev_areas = [c for c, v in comp_patterns.items() if isinstance(v, dict) and v.get("status") in ("needs_focus", "developing")]
        coaching_focus = dev_areas[0] if dev_areas else ""

        return {
            # Metadata
            "tas_id": self.tas_id,
            "tas_name": self.tas_name,
            "abl_id": self.abl_id,
            "territory": self.territory,
            "coaching_date": now.strftime("%Y-%m-%d"),
            "coaching_time": now.strftime("%H:%M"),
            "month": self.month,

            # Section 1: Snapshot
            "snapshot": {
                "coaching_status": continuity.get("trajectory", "new_baseline"),
                "top_strength": strengths[0] if strengths else "",
                "recurring_dev_area": dev_areas[0] if dev_areas else "",
                "fcr_approved": True,
                "open_action_items": len(self._get_smart_actions()),
            },

            # Section 2: AI Summary
            "ai_summary": {
                "eval_observation": self._get_eval_observation(),
                "eval_impact": self._get_eval_impact(),
                "eval_smart_goals": self._get_eval_smart_goals(),
                "seam_summary": str(self.seam_notes or "")[:500],
                "consistent_strengths": strengths,
                "repeated_dev_areas": dev_areas,
                "recent_improvements": progress.get("improvements", [])[:3],
                "persisting_gaps": progress.get("persisting_gaps", [])[:3],
                "resolved_areas": progress.get("resolved", [])[:3],
                "next_coaching_focus": continuity.get("next_session_focus", "")[:200],
                "what_worked": continuity.get("what_worked", "")[:200],
                "what_to_change": continuity.get("what_to_change", "")[:200],
                "risks": recommendations.get("stretch_goal", "")[:150],
            },

            # Section 3: Timeline entry
            "timeline_entry": {
                "month": self.month,
                "coaching_focus": coaching_focus,
                "strength_observed": strengths[0] if strengths else "",
                "development_area": dev_areas[0] if dev_areas else "",
                "progress_status": continuity.get("trajectory", "new_baseline"),
            },

            # Section 4: Strengths & Development Areas
            "strengths_and_gaps": {
                "strengths": [
                    {"competency": c, "description": comp_patterns.get(c, {}).get("strength_description", "")[:150],
                     "evidence": comp_patterns.get(c, {}).get("evidence_summary", "")[:200]}
                    for c in strengths
                ],
                "development_areas": [
                    {"competency": c, "evidence": comp_patterns.get(c, {}).get("evidence_summary", "")[:200],
                     "smart_goal": self._compact_smart_goal(comp_patterns.get(c, {}).get("smart_goal"))}
                    for c in dev_areas
                ],
            },

            # Section 5: Theme statuses
            "theme_statuses": {
                comp: self._theme_status(comp_patterns.get(comp, {}))
                for comp in comp_patterns
                if isinstance(comp_patterns.get(comp), dict) and comp_patterns[comp].get("status") != "not_observed"
            },

            # Section 6: Pattern cards
            "pattern_cards": self._build_pattern_cards(comp_patterns, continuity, recommendations),

            # Section 7: Field vs past
            "field_vs_past": self._build_field_vs_past(comp_patterns, progress),

            # Section 8: Action plan status
            "action_plan_status": self._get_smart_actions(),

            # Section 9: Progress vs past
            "progress_vs_past": {
                "overall_trend": continuity.get("trajectory", "new_baseline"),
                "improved_areas": progress.get("improvements", [])[:5],
                "continued_gaps": progress.get("persisting_gaps", [])[:5],
                "new_issues": [c for c in dev_areas if comp_patterns.get(c, {}).get("trend") == "new"],
            },

            # Raw data for pattern node
            "fcr_observations": self._get_fcr_observations(),
            "fcr_smart_actions": self._get_smart_actions(),
        }

    # ─── Index Update ─────────────────────────────────────────────────────

    def _update_index(self, session: Dict[str, Any]) -> Dict[str, Any]:
        """Update the master index — powers dashboard and pattern node."""
        try:
            index_key = f"{self.memory_prefix}/{self.tas_id}/index.json"
            index = self._load_or_create_index(index_key)

            # FCR history (tracks each session)
            index["fcr_history"].append({
                "month": self.month,
                "created_at": datetime.now().isoformat(),
                "session_id": self.state.get("session_id"),
            })

            # Section 1: Snapshot
            index["snapshot"] = session["snapshot"]
            index["snapshot"]["fcrs_reviewed"] = len(index["fcr_history"])

            # Section 3: Timeline
            index["timeline"].append(session["timeline_entry"])
            index["timeline"] = index["timeline"][-12:]

            # Section 4: Frequency-based strength/dev tracking
            for s in session["strengths_and_gaps"]["strengths"]:
                comp = s["competency"]
                index["recurring_strengths"][comp] = index["recurring_strengths"].get(comp, 0) + 1
            for d in session["strengths_and_gaps"]["development_areas"]:
                comp = d["competency"]
                index["recurring_development_areas"][comp] = index["recurring_development_areas"].get(comp, 0) + 1

            # Section 5: Theme trends (per theme, per month)
            for theme, status in session["theme_statuses"].items():
                if theme not in index["theme_trends"]:
                    index["theme_trends"][theme] = []
                index["theme_trends"][theme].append({"month": self.month, "status": status})
                index["theme_trends"][theme] = index["theme_trends"][theme][-12:]

            # Section 6: Pattern tracker (frequency + evidence)
            self._update_pattern_tracker(index, session)

            # Section 7: Latest field vs past
            index["field_vs_past"] = session["field_vs_past"]

            # Section 8: Action plan history
            if session["action_plan_status"]:
                index["action_plan_history"].append({
                    "month": self.month,
                    "actions": session["action_plan_status"],
                })
                index["action_plan_history"] = index["action_plan_history"][-12:]

            # Section 9: Progress history
            index["progress_history"].append({
                "month": self.month,
                "overall_trend": session["progress_vs_past"]["overall_trend"],
                "improved_areas": session["progress_vs_past"]["improved_areas"],
                "continued_gaps": session["progress_vs_past"]["continued_gaps"],
                "new_issues": session["progress_vs_past"]["new_issues"],
            })
            index["progress_history"] = index["progress_history"][-12:]

            # AI coaching summary history
            index["coaching_summaries"].append({
                "month": self.month,
                "summary": session["ai_summary"],
            })
            index["coaching_summaries"] = index["coaching_summaries"][-6:]

            # Session history (compact, for pattern node)
            index["sessions"].append({
                "month": self.month,
                "date": session["coaching_date"],
                "coaching_focus": session["timeline_entry"]["coaching_focus"],
                "strengths": session["ai_summary"]["consistent_strengths"],
                "dev_areas": session["ai_summary"]["repeated_dev_areas"],
                "theme_statuses": session["theme_statuses"],
                "trajectory": session["snapshot"]["coaching_status"],
            })
            index["sessions"] = index["sessions"][-12:]

            # Top-level fields
            index["total_sessions"] = len(index["sessions"])
            index["total_fcrs"] = len(index["fcr_history"])
            index["trajectory"] = session["snapshot"]["coaching_status"]
            index["last_updated"] = datetime.now().isoformat()
            index["latest_ai_summary"] = session["ai_summary"]
            index["latest_strengths_and_gaps"] = session["strengths_and_gaps"]
            index["next_coaching_focus"] = {
                "focus": session["ai_summary"]["next_coaching_focus"],
                "what_worked": session["ai_summary"]["what_worked"],
                "what_to_change": session["ai_summary"]["what_to_change"],
            }

            self.s3_client.put_object(
                Bucket=self.bucket_name,
                Key=index_key,
                Body=json.dumps(index, indent=2, default=str),
                ContentType="application/json",
            )
            return {"total_sessions": index["total_sessions"], "trajectory": index["trajectory"]}

        except Exception as e:
            print(f"[MemoryUpdate] Failed to update index: {e}")
            import traceback
            traceback.print_exc()
            return {"total_sessions": 0, "trajectory": "unknown"}

    def _update_pattern_tracker(self, index: Dict[str, Any], session: Dict[str, Any]):
        """Track pattern frequency with evidence across sessions."""
        for card in session["pattern_cards"]:
            comp = card["competency"]
            if comp not in index["pattern_tracker"]:
                index["pattern_tracker"][comp] = {
                    "type": card["type"],
                    "count": 0,
                    "months_seen": [],
                    "latest_evidence": "",
                    "latest_recommendation": "",
                }
            tracker = index["pattern_tracker"][comp]
            tracker["count"] += 1
            tracker["months_seen"].append(self.month)
            tracker["months_seen"] = tracker["months_seen"][-12:]
            tracker["type"] = card["type"]
            tracker["latest_evidence"] = card["evidence"]
            tracker["latest_recommendation"] = card["recommendation"]
            tracker["pattern_status"] = card["pattern_status"]

    # ─── Extraction Helpers ───────────────────────────────────────────────

    def _get_eval_observation(self) -> str:
        if not self.evaluation_draft or not isinstance(self.evaluation_draft, dict):
            return ""
        return self.evaluation_draft.get("observation", "")[:400]

    def _get_eval_impact(self) -> str:
        if not self.evaluation_draft or not isinstance(self.evaluation_draft, dict):
            return ""
        return self.evaluation_draft.get("impact", "")[:300]

    def _get_eval_smart_goals(self) -> List[Dict[str, str]]:
        if not self.evaluation_draft or not isinstance(self.evaluation_draft, dict):
            return []
        goals = self.evaluation_draft.get("how_to_improve", [])
        if not isinstance(goals, list):
            return []
        result = []
        for g in goals[:2]:
            if isinstance(g, dict):
                result.append({
                    "goal_headline": g.get("goal_headline", "")[:150],
                    "specific": g.get("specific", "")[:150],
                    "measurable": g.get("measurable", "")[:100],
                    "time_bound": g.get("time_bound", "")[:80],
                })
        return result

    def _get_fcr_observations(self) -> List[Dict[str, Any]]:
        if not self.draft:
            return []
        observations = self.draft.get("observations", self.draft.get("competency_observations", []))
        result = []
        if isinstance(observations, list):
            for obs in observations:
                if isinstance(obs, dict):
                    result.append({
                        "competency": obs.get("competency", obs.get("name", "")),
                        "observation": obs.get("observation", obs.get("text", ""))[:250],
                        "rating": obs.get("rating", obs.get("score", "")),
                    })
        elif isinstance(observations, dict):
            for comp, detail in list(observations.items())[:6]:
                text = detail if isinstance(detail, str) else json.dumps(detail, default=str)
                result.append({"competency": comp, "observation": text[:250]})
        return result

    def _get_smart_actions(self) -> List[Dict[str, str]]:
        if not self.draft:
            return []
        raw = self.draft.get("smart_actions", self.draft.get("smart_action_steps", []))
        result = []
        if isinstance(raw, list):
            for action in raw[:4]:
                if isinstance(action, dict):
                    result.append({
                        "action": action.get("action", action.get("description", ""))[:200],
                        "competency": action.get("competency", ""),
                        "measurable": action.get("measurable", action.get("metric", ""))[:100],
                        "timeline": action.get("timeline", action.get("time_bound", ""))[:80],
                    })
                elif isinstance(action, str):
                    result.append({"action": action[:200]})
        return result

    def _compact_smart_goal(self, goal) -> Optional[Dict[str, str]]:
        if not goal or not isinstance(goal, dict):
            return None
        return {
            "goal_headline": goal.get("goal_headline", "")[:150],
            "specific": goal.get("specific", "")[:150],
            "measurable": goal.get("measurable", "")[:100],
            "time_bound": goal.get("time_bound", "")[:80],
        }

    def _theme_status(self, comp_data: Dict[str, Any]) -> str:
        status = comp_data.get("status", "not_observed")
        trend = comp_data.get("trend", "new")
        if status == "strength":
            return "Strong"
        elif status == "needs_focus":
            return "Improving" if trend == "improving" else "Needs Work"
        elif status == "developing":
            return "Improving" if trend == "improving" else "In Progress"
        return "Not Observed"

    def _build_pattern_cards(self, comp_patterns: Dict, continuity: Dict, recommendations: Dict) -> List[Dict[str, Any]]:
        cards = []
        for comp, data in comp_patterns.items():
            if not isinstance(data, dict) or data.get("status") == "not_observed":
                continue
            status = data.get("status")
            trend = data.get("trend", "new")
            if status == "strength":
                cards.append({
                    "type": "sustained_strength",
                    "competency": comp,
                    "pattern_status": "Consistent strength",
                    "evidence": data.get("evidence_summary", "")[:200],
                    "recommendation": "Leverage this strength to improve other areas",
                })
            elif status in ("needs_focus", "developing"):
                cards.append({
                    "type": "repeated_development" if trend != "new" else "emerging_gap",
                    "competency": comp,
                    "pattern_status": "Improving but still active" if trend == "improving" else "Active gap",
                    "evidence": data.get("evidence_summary", "")[:200],
                    "recommendation": data.get("smart_goal", {}).get("goal_headline", "")[:150] if isinstance(data.get("smart_goal"), dict) else "",
                })
        return cards

    def _build_field_vs_past(self, comp_patterns: Dict, progress: Dict) -> List[Dict[str, Any]]:
        improvements = progress.get("improvements", []) if progress else []
        persisting = progress.get("persisting_gaps", []) if progress else []
        resolved = progress.get("resolved", []) if progress else []

        comparisons = []
        for comp, data in comp_patterns.items():
            if not isinstance(data, dict) or data.get("status") == "not_observed":
                continue
            status = data.get("status")
            trend = data.get("trend", "new")

            if comp in resolved:
                comparison_status = "Improved"
            elif status == "strength" and trend in ("stable", "improving"):
                comparison_status = "Sustained Strength"
            elif comp in persisting or (status == "needs_focus" and trend in ("stable", "declining")):
                comparison_status = "Continued Gap"
            elif status == "needs_focus" and trend == "new":
                comparison_status = "New Gap"
            elif trend == "improving":
                comparison_status = "Improving"
            else:
                comparison_status = "In Progress"

            if trend == "new":
                past_pattern = "Not previously observed"
            elif status == "strength":
                past_pattern = "Consistent strength"
            elif trend == "improving":
                past_pattern = "Previous gap"
            else:
                past_pattern = "Repeated gap"

            comparisons.append({
                "competency": comp,
                "past_fcr_pattern": past_pattern,
                "current_observation": data.get("evidence_summary", "")[:200],
                "status": comparison_status,
            })
        return comparisons

    # ─── Index Load/Create ────────────────────────────────────────────────

    def _load_or_create_index(self, index_key: str) -> Dict[str, Any]:
        default = {
            "tas_id": self.tas_id,
            "tas_name": self.tas_name,
            "abl_id": self.abl_id,
            "territory": self.territory,
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
            "total_sessions": 0,
            "total_fcrs": 0,
            "trajectory": "new_baseline",
            "snapshot": {},
            "fcr_history": [],
            "timeline": [],
            "recurring_strengths": {},
            "recurring_development_areas": {},
            "theme_trends": {},
            "pattern_tracker": {},
            "field_vs_past": [],
            "action_plan_history": [],
            "progress_history": [],
            "coaching_summaries": [],
            "sessions": [],
            "next_coaching_focus": {},
            "latest_ai_summary": {},
            "latest_strengths_and_gaps": {},
        }
        try:
            resp = self.s3_client.get_object(Bucket=self.bucket_name, Key=index_key)
            index = json.loads(resp["Body"].read().decode("utf-8"))
            # Backfill missing keys for schema evolution
            for key, val in default.items():
                index.setdefault(key, val)
            return index
        except self.s3_client.exceptions.NoSuchKey:
            return default
        except Exception:
            return default

    # ─── Public API ───────────────────────────────────────────────────────

    @classmethod
    def load_memory_for_tas(cls, tas_id: str) -> Optional[Dict[str, Any]]:
        """Load index for a TAS — used by pattern node and dashboard API."""
        try:
            s3 = boto3.client("s3", region_name=settings.aws_region)
            bucket = settings.memory_s3_bucket
            key = f"memory/{tas_id}/index.json"
            resp = s3.get_object(Bucket=bucket, Key=key)
            return json.loads(resp["Body"].read().decode("utf-8"))
        except Exception:
            return None

    @classmethod
    def load_continuity_for_tas(cls, tas_id: str) -> Optional[Dict[str, Any]]:
        """Alias for backward compatibility."""
        return cls.load_memory_for_tas(tas_id)
