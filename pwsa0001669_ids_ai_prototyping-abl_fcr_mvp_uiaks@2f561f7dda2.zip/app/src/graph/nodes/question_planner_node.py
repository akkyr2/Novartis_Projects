from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional, Tuple

from app.src.llm.bedrock_client import BedrockClient

# NOTE: abl_evaluation track removed - already covered by eval_coaching_planner_node in Phase 1
TRACK_SEAM = "seam_prework"
TRACK_KPI = "kpi"

DEFAULT_MAX_QUESTIONS = 3  # Reduced from 5 since field observations handled in Phase 1


def question_planner_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Adaptive planner for Phase 2 (KPI & SEAM questions only).

    NOTE: Field observation questions (observation_notes, observed_strengths,
    development_opportunities, impact_statement, action_items) are already
    collected in Phase 1 by eval_coaching_planner_node.

    This planner focuses on:
    - KPI analysis and performance insights
    - SEAM/pre-work context and developmental background

    - Evaluates what's missing NOW (after latest answer ingestion).
    - Generates only the next best question.
    - Does NOT output a static list.
    """
    tas_name = state.get("tas_name") or state.get("tas_id") or "TAS"
    asked_ids = set(state.get("asked_question_ids", []))
    max_total = int(state.get("max_questions", DEFAULT_MAX_QUESTIONS))
    asked_count = int(state.get("asked_question_count", 0))

    # stop condition: asked too many already
    if asked_count >= max_total:
        return {"next_question": None, "should_ask_questions": False, "planner_status": "complete"}

    context = _build_context_snapshot(state)

    prompt = f"""
You are an Intelligent assistant who looks at the current performance of TAS and ask Thought provoking questions to ABL for better coaching a TAS.

BUSINESS CONTEXT:
- ABL is coaching a TAS (Territory Account Specialist) at Novartis
- TAS sells **Rhapsido** (Novartis's own brand for moderate-to-severe CSU/allergy)
- **Dupixent** (Sanofi/Regeneron) and **Xolair** (Genentech/Novartis legacy) are COMPETITOR brands
- TAS goal: grow Rhapsido prescriptions (NBRx/TRx) by converting HCPs from competitor products
- TAS manages a territory: educates HCPs (physicians) on Rhapsido's clinical differentiation
- Field day already complete - Phase 1 collected field observations
- Now analyzing KPI performance and territory context to complete FCR (Field Coaching Report)

KPI CATEGORIES TO ASSESS:
1. Rhapsido Performance (OUR BRAND): Rhapsido TRx/NBRx, Start Forms, Growth %
2. Competitor Tracking: Dupixent TRx/NBRx, Xolair TRx/NBRx (track share shifts)
3. HCP Engagement: Reach%, Calls, CPD (Calls Per Day), Key Messages Delivered, Top 2 Tier Reach%
4. HCP Segmentation: Treatment Escalators vs Conventional Cyclers, #Writers, Moderate-to-Severe CSU Patients
5. Territory Coverage: Breadth (TRx per writer), Geography gaps, Zero Call Days
6. Coaching: F2F Coaching Days, NBA engagement %, Samples Dispensed

PHASE 1 ALREADY COLLECTED (DO NOT RE-ASK):
✅ Field observation notes (specific behaviors during HCP calls)
✅ Observed strengths from field day
✅ Development opportunities from field observations
✅ Impact statement (why observations matter)
✅ Action items (how to improve from field day)

PHASE 2 SCOPE - ONLY ask questions about:
✅ KPI ANALYSIS:
   - Performance metrics vs targets (e.g., "Dupixent TRx 15% below target - why?")
   - Root cause analysis (territory challenges, market dynamics, HCP access)
   - Trend interpretation (growth/decline patterns)
   - Segmentation insights (Treatment Escalators vs Conventional Cyclers)

✅ SEAM/PRE-WORK CONTEXT:
   - TAS's self-identified developmental goals
   - Territory-specific challenges (access barriers, competitive landscape)
   - Systemic issues affecting performance (vacant territories, restructuring)
   - TAS background/experience level
   - Market dynamics (hospital systems, payer restrictions)

IMPORTANT:
- This is a COACHING CONVERSATION, not a test — you are helping the ABL think through KPI insights to strengthen the FCR
- Do NOT ask questions that test the ABL's knowledge (e.g., "What is Devon's NBRx?" — we already have the data!)
- Instead, ask questions that invite the ABL's PERSPECTIVE on the data:
- Frame as discussion: "Based on the KPIs, I see X... What's your take on..." or "The data shows Y — how does this connect to what you observed in the field?"
- Ground questions in ACTUAL KPI data (reference specific numbers from the analysis)
- Do NOT ask if info already present in state
- Do NOT repeat questions already asked (asked_question_ids)
- Keep it to {max_total} questions max — focus on what adds MOST value to the FCR

TAS: {tas_name}

CRITICAL NAME RULE: You MUST use ONLY the name "{tas_name}" when referring to the TAS in your question. Do NOT use any other name. Do NOT infer or substitute a different name from the context or KPI data.

ALREADY ASKED QUESTION IDS:
{json.dumps(list(asked_ids))}

CURRENT STATE SNAPSHOT:
{json.dumps(context, indent=2, default=str)[:4500]}

Return ONLY JSON exactly:
{{
  "should_ask_questions": true/false,
  "next_question": {{
    "id": "string",
    "track": "kpi|seam_prework",
    "severity": "critical|important|helpful",
    "purpose": "kpi_insight|kpi_root_cause|seam_context|developmental_context|territory_challenge",
    "question_text": "string (conversational, references specific KPI data, invites ABL's perspective)",
    "follow_up_prompts": ["string","string"],
    "grounding": {{
      "missing_slot": "string",
      "evidence_span": "short quote/snippet from KPI data or SEAM notes"
    }}
  }} OR null,
  "remaining_gaps": [
    {{
      "track": "kpi|seam_prework",
      "missing_slot": "string",
      "severity": "critical|important|helpful",
      "reason": "string"
    }}
  ]
}}
"""

    bedrock = BedrockClient()
    raw = bedrock.invoke_claude(prompt=prompt, max_tokens=1500, temperature=0.0)
    parsed = _safe_json(raw)

    if not parsed:
        return {"next_question": None, "should_ask_questions": False, "planner_status": "complete"}

    next_q = parsed.get("next_question")
    if next_q and next_q.get("id") in asked_ids:
        # safety: never repeat
        return {"next_question": None, "should_ask_questions": False, "planner_status": "complete"}

    return {
        "should_ask_questions": bool(parsed.get("should_ask_questions")),
        "next_question": next_q,
        "remaining_gaps": parsed.get("remaining_gaps", []),
        "planner_status": "complete",
    }


def _build_context_snapshot(state: Dict[str, Any]) -> Dict[str, Any]:
    kpi = state.get("kpi_analysis") or {}
    return {
        # Raw inputs
        "tas_prework_text": (state.get("tas_prework_text") or "")[:1500],
        "selected_competencies": state.get("selected_competencies") or [],

        # Phase 1 already collected (SHOW to avoid re-asking)
        "phase1_observation_notes": (state.get("observation_notes") or "")[:500] + ("..." if len(state.get("observation_notes", "")) > 500 else ""),
        "phase1_strengths": (state.get("observed_strengths") or "")[:300] + ("..." if len(state.get("observed_strengths", "")) > 300 else ""),
        "phase1_opportunities": (state.get("development_opportunities") or "")[:300] + ("..." if len(state.get("development_opportunities", "")) > 300 else ""),
        "phase1_impact": (state.get("impact_statement") or "")[:300] + ("..." if len(state.get("impact_statement", "")) > 300 else ""),
        "phase1_actions": (state.get("action_items") or "")[:300] + ("..." if len(state.get("action_items", "")) > 300 else ""),

        # Phase 2 targets (what we're filling now)
        "seam_notes": state.get("seam_notes") or "",
        "developmental_context": state.get("developmental_context") or "",

        # KPI analysis (PRIMARY FOCUS)
        "kpi_narrative": (kpi.get("narrative") or "")[:800],
        "kpi_keys": list((kpi.get("analysis") or {}).keys())[:30],
        "kpi_full_analysis": str((kpi.get("analysis") or {}))[:1500],

        # Historical context
        "historical_fcr_count": ((state.get("context_bundle") or {}).get("past_fcr_context") or {}).get("historical_fcr_count", 0),
        "older_fcr_summary": (((state.get("context_bundle") or {}).get("past_fcr_context") or {}).get("older_fcr_summary") or "")[:800],
    }


def _safe_json(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?", "", cleaned).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except Exception:
        return None