"""
Rubric Check Node - LLM-based evaluation of FCR draft against OneBreakaway competency rubric.
Uses the FCR Comp Grid as the scoring reference.
"""
import json
from pathlib import Path
from typing import Dict, Any, List
 
from app.src.llm.bedrock_client import BedrockClient
 
 
def _load_rubric_prompt() -> str:
    prompt_path = Path(__file__).resolve().parents[2] / "llm" / "prompts" / "rubric_check.md"
    return prompt_path.read_text(encoding="utf-8")
 
 
def _clean_json(text: str) -> str:
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()
    # If LLM wrapped JSON with prose, find the first { or [
    if not text.startswith("{") and not text.startswith("["):
        start = text.find("{")
        if start == -1:
            start = text.find("[")
        if start != -1:
            text = text[start:]
    # Find the last matching bracket
    if text.startswith("{"):
        last = text.rfind("}")
        if last != -1:
            text = text[:last+1]
    elif text.startswith("["):
        last = text.rfind("]")
        if last != -1:
            text = text[:last+1]
    return text.strip()
 
 
class RubricCheckNode:
    """
    Evaluates FCR draft against the OneBreakaway competency rubric using LLM.
    Acts as an experienced ABL reviewing the report.
    """
 
    def __init__(self, state: Dict[str, Any]):
        self.state = state
        self.draft = state.get("draft", {})
 
    def run(self) -> Dict[str, Any]:
        if not self.draft:
            return {"rubric_issues": [{"severity": "high", "section": "Draft", "issue": "Draft is missing or empty", "suggestion": "Generate a draft first"}]}
 
        # Build the evaluation request
        rubric_prompt = _load_rubric_prompt()
 
        draft_json = json.dumps(self.draft, indent=2, default=str)
 
        # Include past FCR context if available
        context_bundle = self.state.get("context_bundle", {})
        past_fcr_context = context_bundle.get("past_fcr_context", {})
        past_fcr_info = ""
        if past_fcr_context:
            past_fcr_info = f"\n\nPast FCR Context:\n{json.dumps(past_fcr_context, indent=2, default=str)[:2000]}"
 
        tas_name = self.state.get("tas_name") or self.state.get("tas_id") or "TAS"

        full_prompt = f"""{rubric_prompt}

CRITICAL NAME RULE: The TAS being evaluated is "{tas_name}". Use ONLY this name in all rationale text. Do NOT use any other name.

## FCR Draft to Evaluate:
```json
{draft_json}
```
{past_fcr_info}
 
Evaluate this FCR draft now. Return ONLY valid JSON with "competency_scores" and "issues" keys as specified above."""
 
        bedrock = BedrockClient()
        llm_output = bedrock.invoke_claude(
            prompt=full_prompt,
            model_id=None,
            max_tokens=4096,
            temperature=0.0,
        )
 
        if not llm_output:
            return {"rubric_issues": [{"severity": "medium", "section": "System", "issue": "Rubric evaluation failed - LLM returned no output", "suggestion": "Retry the evaluation"}]}
 
        print(f"[RubricCheck] Raw LLM output (first 300 chars): {llm_output[:300]}")
        cleaned = _clean_json(llm_output)
        print(f"[RubricCheck] Cleaned output (first 300 chars): {cleaned[:300]}")
 
        try:
            parsed = json.loads(cleaned)
            if isinstance(parsed, dict):
                competency_scores = parsed.get("competency_scores", [])
                issues = parsed.get("issues", [])
            elif isinstance(parsed, list):
                competency_scores = []
                issues = parsed
            else:
                competency_scores = []
                issues = [parsed]
        except json.JSONDecodeError as e:
            print(f"[RubricCheck] JSON PARSE ERROR: {e}")
            print(f"[RubricCheck] Failed text (last 200 chars): {cleaned[-200:]}")
            competency_scores = []
            issues = [{"severity": "medium", "section": "System", "issue": "Could not parse rubric evaluation", "suggestion": "Review draft manually", "raw_output": llm_output[:500]}]
 
        return {"rubric_issues": issues, "competency_scores": competency_scores}