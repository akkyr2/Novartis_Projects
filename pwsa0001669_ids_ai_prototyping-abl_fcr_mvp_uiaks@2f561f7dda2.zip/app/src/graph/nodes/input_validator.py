"""
Input validation for intake chat fields.
Returns (is_valid, error_message) tuples.
"""
import re
from datetime import datetime
from typing import Tuple
 
 
def validate_tas_id(value: str) -> Tuple[bool, str]:
    """Validate TAS ID: accepts geo codes (DNCG12) or TAS names (AndyBackus)."""
    value = value.strip()
    if not value:
        return False, "Please provide a TAS ID."
    if len(value) < 3:
        return False, "TAS ID is too short. Please provide a valid TAS name or geo code."
    return True, ""
 
 
def validate_month(value: str) -> Tuple[bool, str]:
    """Validate month input using LLM to parse any format."""
    value = value.strip()
    if not value:
        return False, "Please provide the month."

    parsed = normalize_month(value)
    if not parsed or not re.match(r'^\d{4}-\d{2}$', parsed):
        return False, "I couldn't understand that date. Please try again (e.g., 'June 2026')."

    year, month = int(parsed[:4]), int(parsed[5:])
    if month < 1 or month > 12:
        return False, "Invalid month."
    if year < 2020 or year > datetime.now().year + 1:
        return False, f"Year seems incorrect. Please enter a year between 2020 and {datetime.now().year}."
    return True, ""


def normalize_month(value: str) -> str:
    """Use LLM to parse any date/month expression into YYYY-MM format."""
    from app.src.llm.bedrock_client import BedrockClient

    prompt = f"""Extract the month and year from the user input below. Return ONLY the result in YYYY-MM format. If you cannot determine the month/year, return "INVALID".

Today's date: {datetime.now().strftime('%Y-%m-%d')}

User input: "{value}"

Rules:
- If only a month name is given without a year, assume the current year ({datetime.now().year}).
- Handle misspellings, voice transcription errors, and any format.
- Return ONLY YYYY-MM, nothing else."""

    try:
        bedrock = BedrockClient()
        result = bedrock.invoke_claude(
            prompt=prompt,
            model_id=None,
            max_tokens=20,
            temperature=0.0,
        )
        result = result.strip()
        if re.match(r'^\d{4}-\d{2}$', result):
            return result
    except Exception as e:
        print(f"[DateParse] LLM fallback failed: {e}")

    # Quick regex fallback for obvious formats
    m = re.match(r'^(\d{4})-(\d{1,2})$', value.strip())
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}"

    return value
 
 
def validate_tas_prework_text(value: str) -> Tuple[bool, str]:
    """Validate TAS pre-work/SEAM note: minimum 20 words."""
    value = value.strip()
    if not value:
        return False, "Please provide the TAS pre-work text or SEAM note."
    if len(value.split()) < 20:
        return False, "TAS pre-work text must be at least 20 words. Please provide more detail."
    return True, ""
 
 
def validate_abl_eval_text(value: str) -> Tuple[bool, str]:
    """Validate ABL evaluation notes: minimum 20 words."""
    value = value.strip()
    if not value:
        return False, "Please provide the ABL observation/evaluation notes."
    if len(value.split()) < 20:
        return False, "ABL evaluation notes must be at least 20 words. Please provide more detail."
    return True, ""
 
 
def validate_selected_competencies(value: str) -> Tuple[bool, str]:
    """Validate competencies: at least one provided."""
    value = value.strip()
    if not value:
        return False, "Please provide at least one competency."
    items = [i.strip() for i in value.replace("\n", ",").split(",") if i.strip()]
    if not items:
        return False, "Please provide at least one competency (comma-separated)."
    return True, ""
 
 
# Map field names to their validators
FIELD_VALIDATORS = {
    "tas_id": validate_tas_id,
    "tas_prework_text": validate_tas_prework_text,
    "abl_eval_text": validate_abl_eval_text,
    "selected_competencies": validate_selected_competencies,
}
 
 
def validate_field(field_name: str, value: str) -> Tuple[bool, str]:
    """Validate a field by name. Returns (is_valid, error_message)."""
    validator = FIELD_VALIDATORS.get(field_name)
    if not validator:
        return True, ""
    return validator(value)