"""
Evaluation Answer Ingest Node
Processes answers to evaluation coaching questions and extracts structured information.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, Optional

from app.src.llm.bedrock_client import BedrockClient


def evaluation_answer_ingest_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract and structure information from ABL's answer to evaluation coaching question.
    """
    last_answer = (state.get("last_user_answer") or "").strip()
    last_question = state.get("last_eval_question") or {}
    
    if not last_answer or not last_question:
        return {}
    
    category = last_question.get("category", "observation")
    question_id = last_question.get("id", "")
    
    # Fast path: if answer is very short, just store it
    if len(last_answer) < 10:
        eval_answers = state.get("eval_answers", {}) or {}
        eval_answers[question_id] = last_answer
        return {"eval_answers": eval_answers}
    
    prompt = f"""
You are extracting structured coaching information from an ABL's response about a field day observation.

QUESTION CATEGORY: {category}
QUESTION ID: {question_id}

ABL'S ANSWER:
\"\"\"{last_answer}\"\"\"

Extract relevant information and categorize it appropriately.

Return JSON with any applicable keys:
{{
  "observation_notes": "Specific behaviors/actions observed (factual, concrete)",
  "observed_strengths": "Positive behaviors or capabilities noted",
  "development_opportunities": "Areas needing improvement or growth",
  "impact_statement": "Why this matters - effect on engagement/outcomes",
  "action_items": "Specific development actions or next steps",
  "competency_notes": "Notes related to specific competencies"
}}

RULES:
- Extract ONLY what is explicitly stated
- observation_notes: concrete behaviors seen during field day
- observed_strengths: what TAS did well
- development_opportunities: what needs work
- impact_statement: why the observation matters
- action_items: specific steps for improvement
- If answer doesn't fit categories, put in observation_notes

Return ONLY JSON.
"""
    
    bedrock = BedrockClient()
    try:
        raw = bedrock.invoke_claude(prompt=prompt, max_tokens=600, temperature=0.0)
    except Exception as e:
        print(f"❌ Evaluation answer ingest LLM call failed: {e}")
        eval_answers = state.get("eval_answers", {}) or {}
        eval_answers[question_id] = last_answer
        return {"eval_answers": eval_answers}
    parsed = _safe_json(raw)
    
    if not parsed:
        # Fallback: just store the raw answer
        eval_answers = state.get("eval_answers", {}) or {}
        eval_answers[question_id] = last_answer
        return {"eval_answers": eval_answers}
    
    # Store raw answer
    eval_answers = state.get("eval_answers", {}) or {}
    eval_answers[question_id] = last_answer
    
    # Merge extracted fields (append if exists, don't overwrite)
    updates = {"eval_answers": eval_answers}
    
    for key, value in parsed.items():
        if isinstance(value, str) and value.strip():
            existing = (state.get(key) or "").strip()
            if existing and value.strip() not in existing:
                updates[key] = (existing + "\n\n" + value.strip()).strip()
            else:
                updates[key] = value.strip()
    
    return updates


def _safe_json(text: str) -> Optional[Dict[str, Any]]:
    """Safely parse JSON from LLM response, handling truncation."""
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?", "", cleaned).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Try to find a complete JSON object within the text
        match = re.search(r'\{.*\}', cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass
        return None
