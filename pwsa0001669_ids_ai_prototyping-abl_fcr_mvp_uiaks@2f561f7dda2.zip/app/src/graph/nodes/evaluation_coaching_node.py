"""
ABL Evaluation Note Coaching Node
Asks up to MAX_EVAL_QUESTIONS targeted questions about the field day observation
to help ABL create a comprehensive evaluation note.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from app.src.llm.bedrock_client import BedrockClient


MAX_EVAL_QUESTIONS = 5


def evaluation_coaching_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate the next coaching question for ABL evaluation note.
    Focuses on: Observation, Impact, How to Improve (OII framework).
    """
    tas_name = state.get("tas_name") or state.get("tas_id") or "TAS"
    eval_questions_asked = state.get("eval_questions_asked", [])
    eval_question_count = len(eval_questions_asked)
    max_questions = int(state.get("max_questions", MAX_EVAL_QUESTIONS))

    # Stop if we've asked enough questions
    if eval_question_count >= max_questions:
        return {
            "next_eval_question": None,
            "should_ask_eval_questions": False,
            "eval_coaching_status": "complete"
        }

    # Build context from what we know so far
    context = _build_eval_context(state)

    prompt = f"""

An ABL is a manager for a Pharma companies field representatives and field representatives are called TAS. Every month An ABL gets to see a TAS interacting with Doctors (during what they call as field day) and makes a note of his observation. Next day both TAS and ABL come together where TAS brings a Field Pre-work note or SEAM Note which is created based on Past FCRs (Field Coaching Report) and TAS's inputs. While ABL brings in evaluation notes from the meeting with doctor (from the field day) where they both discuss on finalize on current month FCR. Final an ABL is responsible for creating FCR using TAS Past FCR, TAS created SEAM, TAS KPIs and Report from Field day i.e., field evaluation note and share it TAS.

A GOOD PLAN by an TAS would contain:
• Leveraged CRM and data reports to gain insights to customer’s prescribing activity and previous promotional activity to assess customer’s current position in A to B shift
• Set a customer specific call objective and patient type designed to advance the A to B shift
• Used all available data (CRM & Sales Data ) to analyze competitive/market landscape to identify opportunities and/or threats for each customer
• Always planned customized engagement to introduce patient type, engage customer and connect to previous call (if applicable) for each customer engaged with
• Identified all additional stakeholders that may need to be engaged to achieve stated objectives and planned for each stakeholder interactions
• Planned customized and specific challenging questions, anticipated customer responses and prepared follow up questions to maintain focus on planned objectives and product strengths for each calls
• Consistently planned for how to include Important Safety Information as part of product messaging


A GOOD ENGAGE by an TAS would contain:
• Consistently used a customer specific patient type identified in pre-call designed to advance the A to B shift
• Consistently set up a specific problem relative to the agreed upon patient type to advance the A to B shift
• Consistently used problem set up relative to specific patient type
• Consistently showed active listening to all customers/stakeholders
• Asked thought provoking questions to all customers/stakeholders to encourage a change in mindset
• Fostered trust and mutual respect by engaging customers/stakeholders in a specific and customer focused way
• Opening statements/questions were carefully planned to gain customer’s interest

A GOOD ADVANCE by an TAS would contain:
• Consistently used customer specific patient type and problem set up throughout the call to advance the A to B shift for the customers and key stakeholders
• Consistently provided insights and evidence relative to the patient, problem set up and product solution
• Consistently used a balance of emotions and logic (data) when presenting product messages whilst engaging customers and other key stakeholders
• Addressed obstacles when presented, taking time to clarify the objective and confirmed they had adequately addressed the obstacle before moving to a new topic
• Appropriately challenged customer and key stakeholders mindsets, when necessary, to advance the A to B shift
• Important Safety Information was shared throughout the interaction in collaboration with product messages to inform customer of any possible risks and to help identify the appropriate patients for the product


A GOOD CLOSE by an TAS would contain:
• Consistently had an action-oriented close with actions for both specialist and the customer
• Consistently identified action steps for customer and self which advance the customer along the A to B shift
• Consistently closed on the patient type mutually agreed upon with the customer
• Consistently closed with a call to action with key stakeholders, not just the customer
• Consistently checked in with the customers and key stakeholders (trial closes) throughout the call


A GOOD FALLOW-UP by an TAS would contain:
• Consistently utilized technology and systems to compliantly record the call
• Consistently established a clear next step goal
• Consistently reflected upon the call to evaluate the customer’s A to B shift and current mindset
• Allowed follow up with customers and key stakeholders as agreed upon in the call
• Consistently reached out to key team members, if applicable, as a way to ensure cross-functional collaboration
• Consistently identified resources or team members that may be required to accomplish next steps with customers and stakeholders



You are an expert coaching facilitator helping an ABL (Area Business Leader) create a high-quality Field Evaluation Note after observing a TAS (Territory Account Specialist) during a field day with doctors.

GOAL: Generate ONE specific, targeted question to help the ABL reflect on and articulate their field day observations.

TAS NAME: {tas_name}

CRITICAL NAME RULE: You MUST use ONLY the name "{tas_name}" when referring to the TAS. Do NOT use any other name. Do NOT infer or substitute a different name from the observation notes or context.

QUESTIONS ALREADY ASKED (count: {eval_question_count}):
{json.dumps(eval_questions_asked, indent=2)}

CURRENT EVALUATION CONTEXT:
{json.dumps(context, indent=2, default=str)}

INSTRUCTIONS:
- Limit the questions only related to coaching competency selected
- Relate questions with what is described in evaluation call out (before asking questions) if something is missing, needs additional details, take ABLs thought process etc.,
- If Evaluation doesnt contain any suggested action items by ABL. Ask last question to ABL if there are any action items which he is thinking of suggesting to TAS.
- Ask about MISSING or INCOMPLETE elements needed for a strong evaluation note
- Ask question like did you see...? did you observer...? do you think....? What else....? Have you...? etc., (NOT JUST LIMIT to this)
- DISTRIBUTE questions across ALL selected competencies — don't fixate on one
- Check which competencies have been covered by previous questions (target_competency field)
- Prioritize the competency with LEAST coverage so far
- Be specific and grounded in coaching best practices
- Focus on observable behaviors, not generic theory
- DO NOT repeat questions already asked
- If enough detail exists for ALL competencies, return next_question = null


Return ONLY JSON:
{{
  "should_ask_eval_questions": true/false,
  "next_question": {{
    "id": "eval_q_{eval_question_count + 1}",
    "category": "observation|impact|improvement",
    "target_competency": "which competency (Plan/Engage/Advance/Close/Follow-up) this question helps evaluate",
    "question_text": "string",
    "coaching_prompts": ["string", "string"],
    "purpose": "What this question aims to capture"
  }} OR null,
  "reasoning": "Why this question is needed or why we're done"
}}
"""

    bedrock = BedrockClient()
    try:
        raw = bedrock.invoke_claude(prompt=prompt, max_tokens=1500, temperature=0.3)
    except Exception as e:
        print(f"❌ Evaluation coaching LLM call failed: {e}")
        return {
            "next_eval_question": None,
            "should_ask_eval_questions": False,
            "eval_coaching_status": "complete"
        }

    parsed = _safe_json(raw)

    if not parsed:
        print(f"⚠️ Failed to parse evaluation coaching response. Raw (first 500 chars): {(raw or '')[:500]}")
        return {
            "next_eval_question": None,
            "should_ask_eval_questions": False,
            "eval_coaching_status": "complete"
        }

    next_q = parsed.get("next_question")

    return {
        "should_ask_eval_questions": bool(parsed.get("should_ask_eval_questions")),
        "next_eval_question": next_q,
        "eval_coaching_reasoning": parsed.get("reasoning", ""),
        "eval_coaching_status": "in_progress" if next_q else "complete"
    }


def _build_eval_context(state: Dict[str, Any]) -> Dict[str, Any]:
    """Build context snapshot for evaluation coaching, trimming long answers."""
    raw_answers = state.get("eval_answers", {}) or {}
    trimmed_answers = {
        k: (v[:300] + "..." if isinstance(v, str) and len(v) > 300 else v)
        for k, v in raw_answers.items()
    }
    return {
        "abl_eval_text_provided": (state.get("abl_eval_text") or "")[:500],
        "observation_notes": (state.get("observation_notes") or "")[:500],
        "observed_strengths": (state.get("observed_strengths") or "")[:500],
        "development_opportunities": (state.get("development_opportunities") or "")[:500],
        "impact_statement": (state.get("impact_statement") or "")[:500],
        "action_items": (state.get("action_items") or "")[:500],
        "selected_competencies": state.get("selected_competencies") or [],
        "eval_answers_collected": trimmed_answers
    }


def _safe_json(text: str) -> Optional[Dict[str, Any]]:
    """Safely parse JSON from LLM response, handling truncation."""
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?", "", cleaned).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Try to find a complete JSON object within the text
        match = re.search(r'\{.*\}', cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                pass
        return None
