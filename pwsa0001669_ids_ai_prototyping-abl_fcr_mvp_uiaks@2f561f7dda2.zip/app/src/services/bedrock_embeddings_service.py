"""
Bedrock Embeddings Service for generating embeddings using Amazon Bedrock.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

import boto3

from app.src.config import settings
import json


class BedrockEmbeddingsService:
    """
    Service for generating embeddings using Amazon Bedrock's Titan Embeddings model.
    """

    def __init__(
        self,
        model_id: str = None,
        aws_region: str | None = None,
    ) -> None:
        """
        Initialize the Bedrock Embeddings Service.

        Args:
            model_id: The Bedrock model ID for embeddings (default: Titan v2)
            aws_region: AWS region (defaults to environment variable or us-east-1)
        """
        self.model_id = model_id
        self.aws_region = aws_region or settings.aws_region
        self.model_id = model_id or settings.bedrock_embed_model_id

        self.bedrock_runtime = boto3.client(
            service_name="bedrock-runtime",
            region_name=self.aws_region,
        )

    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for a single text.

        Args:
            text: The text to embed

        Returns:
            List of floats representing the embedding vector
        """
        if not text or not text.strip():
            raise ValueError("Text cannot be empty")

        request_body = {
            "inputText": text.strip(),
        }

        try:
            response = self.bedrock_runtime.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body),
            )

            response_body = json.loads(response["body"].read())
            embedding = response_body.get("embedding")

            if not embedding:
                raise ValueError("No embedding returned from Bedrock")

            return embedding

        except Exception as exc:
            raise RuntimeError(f"Failed to generate embedding: {str(exc)}") from exc

    def generate_embeddings_batch(
        self,
        texts: List[str],
        batch_size: int = 25,
    ) -> List[List[float]]:
        """
        Generate embeddings for multiple texts.

        Args:
            texts: List of texts to embed
            batch_size: Number of texts to process at once (Bedrock recommendation: 25)

        Returns:
            List of embedding vectors
        """
        if not texts:
            return []

        embeddings = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]

            for text in batch:
                try:
                    embedding = self.generate_embedding(text)
                    embeddings.append(embedding)
                except Exception as exc:
                    # Log error but continue with remaining texts
                    print(f"Warning: Failed to embed text: {str(exc)}")
                    # Append zero vector as fallback
                    embeddings.append([0.0] * 1024)  # Titan v2 produces 1024-dim vectors

        return embeddings
