"""
FCR PDF Service — single source of truth for the Novartis "Coaching Report" PDF.

Both the memory-save path and the edit-popup preview/download endpoint use these
functions so the format is identical everywhere.

- build_fields_from_draft(): turn the structured `draft` + identity info into a flat
  `fields` dict that the popup form edits and the renderer consumes.
- render_coaching_report_pdf(fields): render the 2-page Novartis template to PDF bytes
  using fpdf2 (pure-Python, no OS libs).
"""

from typing import Dict, Any, List
import os
from datetime import datetime

LOGO_PATH = os.path.join(os.path.dirname(__file__), "..", "static", "images", "novartis-logo2.png")

COMPLIANCE_QUESTIONS = [
    ("ae_reporting", "Were AE's reported appropriately?"),
    ("fair_balance", "Were Fair Balance requirements met?"),
    ("prescribing_info", "Was current Full Prescribing Information provided for branded discussions?"),
    ("materials_approved", "Were all materials current, approved, and unaltered, consistent with label?"),
    ("ll_compliant", "Was L&L compliant (State Law Signage, ADS, meals policy)?"),
    ("medical_inquiries", "Were Medical Inquiries handled appropriately?"),
    ("samples_managed", "Were samples delivered/managed appropriately?"),
    ("virtual_ll_conducted", "Was a Virtual Lunch & Learn conducted?"),
]

VLL_QUESTIONS = [
    "Account Name", "Franchise / AAA",
    "Was the Virtual L&L conducted in an office/hospital/institutional setting and not at a home?",
    "Was the meal delivered in time to coincide with the educational discussion?",
    "Did the specialist verbally confirm participant(s) attendance on the call?",
    "Did all those who received a meal participate in the educational discussion?",
    "Did the specialist deliver a fair and balanced presentation consistent with approved messages?",
    "Was approved material displayed effectively through an approved Novartis platform?",
    "If product specific discussion occurred was PI offered/distributed?",
    "Did any deviations occur? If yes, detail steps taken and corrective action.",
]

COMPETENCIES = ["Plan", "Engage", "Advance", "Close", "Follow-up"]


def build_fields_from_draft(draft: Dict[str, Any], tas_name: str = "", abl_name: str = "",
                            month: str = "") -> Dict[str, Any]:
    """Flatten the structured draft into an editable fields dict for the popup form."""
    draft = draft or {}
    meta = draft.get("metadata", {}) or {}
    prev = draft.get("previous_smart_action", {}) or {}
    cc = draft.get("core_capabilities", {}) or {}

    # Competency scores -> {name: "x/5"}
    comp_scores = {}
    for cs in (draft.get("competency_scores") or draft.get("competencies") or []):
        nm = (cs.get("name") or "").strip()
        sc = cs.get("score")
        comp_scores[nm] = (f"{sc}/5" if sc not in (None, "") else "")

    # Observations -> one text block
    obs_lines = []
    for obs in (draft.get("observations") or []):
        area = obs.get("area", ""); what = obs.get("what_i_saw", ""); imp = obs.get("impact", "")
        obs_lines.append(f"{area}: {what}" + (f" Impact: {imp}" if imp else ""))

    # Core capabilities -> one text block
    cc_text = ""
    if cc.get("categories"):
        cc_text += ", ".join(cc["categories"])
    if cc.get("comments"):
        cc_text += ("\n" if cc_text else "") + cc["comments"]

    # SMART actions -> list of {detail, due}
    smart = []
    for a in (draft.get("smart_actions") or [])[:2]:
        detail = " | ".join(filter(None, [
            a.get("action", ""), a.get("measurable", a.get("measure", "")),
            a.get("achievable", ""), a.get("relevant", "")
        ]))
        smart.append({"detail": detail, "due": a.get("time_bound", a.get("due", ""))})

    compliance = draft.get("compliance", {}) or {}

    return {
        "coachee": tas_name or meta.get("coachee", ""),
        "coach": "ABL Coaching Agent",
        "reports_to": abl_name or "",
        "status": "Draft",
        "published_by": "ABL Coaching Agent",
        "published_date": datetime.now().strftime("%m/%d/%Y"),
        "session_type": meta.get("session_type", "Coaching HCP - Live"),
        "month": month or draft.get("month", ""),
        "previous_smart": {
            "description": prev.get("description", ""),
            "due_date": prev.get("due_date", ""),
            "status": prev.get("status", ""),
        },
        "kpi_narrative": draft.get("kpi_narrative", ""),
        "competency_scores": {c: comp_scores.get(c, "") for c in COMPETENCIES},
        "observations": "\n".join(obs_lines),
        "core_capabilities": cc_text,
        "smart_actions": smart,
        "specialist_comments": "",
        "compliance": {key: compliance.get(key, "") for key, _ in COMPLIANCE_QUESTIONS},
    }


def render_coaching_report_pdf(fields: Dict[str, Any]) -> bytes:
    """Render the 2-page Novartis Coaching Report from a flat fields dict."""
    from fpdf import FPDF

    f = fields or {}
    GREY = (215, 215, 215)
    DARK = (30, 30, 30)

    def _c(s):
        return (str(s) if s is not None else "").encode("latin-1", "replace").decode("latin-1")

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.set_margins(12, 12, 12)
    pdf.add_page()
    epw = pdf.w - pdf.l_margin - pdf.r_margin

    def header():
        try:
            if os.path.exists(LOGO_PATH):
                pdf.image(LOGO_PATH, x=12, y=10, h=12)
        except Exception:
            pass
        pdf.set_xy(12, 12)
        pdf.set_font("Helvetica", "B", 20)
        pdf.set_text_color(*DARK)
        pdf.cell(0, 12, _c("Coaching Report"), align="R", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)
        pdf.set_draw_color(120, 120, 120)
        pdf.line(12, pdf.get_y(), pdf.w - 12, pdf.get_y())
        pdf.ln(4)

    LINE_H = 5

    def _lines_needed(txt, w, style=""):
        pdf.set_font("Helvetica", style, 9)
        try:
            lines = pdf.multi_cell(w, LINE_H, _c(txt), dry_run=True, output="LINES")
            return max(1, len(lines))
        except Exception:
            return max(1, int(pdf.get_string_width(_c(txt)) / max(1, (w - 2))) + 1)

    def draw_row(cols):
        max_lines = 1
        for col in cols:
            measure_txt = col["text"] if col.get("align") == "C" else ("  " + col["text"])
            max_lines = max(max_lines, _lines_needed(measure_txt, col["w"], col.get("style", "")))
        row_h = max_lines * LINE_H + 2
        if pdf.get_y() + row_h > pdf.h - 18:
            pdf.add_page(); header()
        y0 = pdf.get_y()
        x = pdf.l_margin
        for col in cols:
            pdf.set_font("Helvetica", col.get("style", ""), 9)
            if col.get("fill"):
                pdf.set_fill_color(*GREY)
            pdf.rect(x, y0, col["w"], row_h, style="DF" if col.get("fill") else "D")
            align = col.get("align", "L")
            txt = col["text"] if align == "C" else ("  " + col["text"])
            pdf.set_xy(x, y0 + 1)
            pdf.multi_cell(col["w"], LINE_H, _c(txt), border=0, align=align, new_x="RIGHT", new_y="TOP")
            x += col["w"]
        pdf.set_xy(pdf.l_margin, y0 + row_h)

    def section_bar(title):
        draw_row([{"text": title, "w": epw, "style": "B", "fill": True}])

    def label_value(label, value, label_w=45):
        draw_row([
            {"text": label, "w": label_w, "style": "B"},
            {"text": str(value), "w": epw - label_w},
        ])

    def full_row(value):
        draw_row([{"text": str(value), "w": epw}])

    def three_col(left, mid, right, mid_w=28, right_w=28, header_row=False):
        st = "B" if header_row else ""
        cols = [{"text": left, "w": epw - mid_w - right_w, "style": st, "fill": header_row}]
        if mid_w > 0:
            cols.append({"text": mid, "w": mid_w, "style": st, "align": "C", "fill": header_row})
        if right_w > 0:
            cols.append({"text": right, "w": right_w, "style": st, "align": "C", "fill": header_row})
        draw_row(cols)

    header()

    # Identity block
    label_value("Coachee", f.get("coachee", ""))
    label_value("Reports To", f.get("reports_to", ""))
    label_value("Status", f.get("status", ""))
    label_value("Published By", f.get("published_by", ""))
    label_value("Published Date", f.get("published_date", ""))
    pdf.ln(1)

    # Previous SMART
    prev = f.get("previous_smart", {}) or {}
    three_col("Plan | Previous SMART Action Step", "Due Date", "Status Review", mid_w=32, right_w=34, header_row=True)
    draw_row([
        {"text": prev.get("description", ""), "w": epw - 32 - 34},
        {"text": str(prev.get("due_date", "")), "w": 32, "align": "C"},
        {"text": str(prev.get("status", "")), "w": 34, "align": "C"},
    ])

    # Performance & KPIs
    section_bar("Performance and KPIs")
    full_row(f.get("kpi_narrative", ""))

    # Selling Approach
    three_col("OneBreakaway Selling Approach", "Coach", "Coachee", header_row=True)
    comp = f.get("competency_scores", {}) or {}
    for c in COMPETENCIES:
        three_col(c, comp.get(c, ""), "")
    three_col("Observations", "", "")
    full_row(f.get("observations", ""))

    # Core Capabilities
    three_col("Core Capabilities", "Coach", "Coachee", header_row=True)
    full_row(f.get("core_capabilities", ""))

    # SMART Action Steps
    three_col("Plan | SMART Action Step", "Due Date", "", mid_w=34, right_w=0, header_row=True)
    smart = f.get("smart_actions", []) or []
    if smart:
        for a in smart:
            draw_row([
                {"text": a.get("detail", ""), "w": epw - 34},
                {"text": str(a.get("due", "")), "w": 34, "align": "C"},
            ])
    else:
        full_row("")

    # Specialist Comments
    section_bar("Specialist Comments")
    full_row(f.get("specialist_comments", ""))

    # Session Date & Type
    section_bar("Session Date & Type")
    full_row(f"{f.get('month', '')}  |  {f.get('session_type', '')}")

    # Footer page 1
    pdf.set_y(-15); pdf.set_font("Helvetica", "I", 8); pdf.set_text_color(90, 90, 90)
    pdf.cell(0, 8, _c("Business Use Only"), align="L")
    pdf.cell(0, 8, _c("1 of 2"), align="R")

    # PAGE 2
    pdf.add_page()
    header()
    section_bar("Compliance - Coaching Session")
    compliance = f.get("compliance", {}) or {}
    for key, question in COMPLIANCE_QUESTIONS:
        draw_row([
            {"text": question, "w": epw - 32},
            {"text": str(compliance.get(key, "")), "w": 32, "align": "C"},
        ])

    section_bar("Virtual Lunch & Learn")
    for q in VLL_QUESTIONS:
        draw_row([
            {"text": q, "w": epw - 32},
            {"text": "", "w": 32, "align": "C"},
        ])

    pdf.set_y(-15); pdf.set_font("Helvetica", "I", 8); pdf.set_text_color(90, 90, 90)
    pdf.cell(0, 8, _c("Business Use Only"), align="L")
    pdf.cell(0, 8, _c("2 of 2"), align="R")

    return bytes(pdf.output())
