"""
KPI Retrieval Service for fetching TAS performance metrics.
"""

from __future__ import annotations

from app.src.config import settings

import os
from datetime import datetime
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError


class KPIRetrievalService:
    """
    Service for retrieving TAS KPI data from various sources (S3, RDS, DynamoDB, etc.).
    """

    def __init__(
        self,
        kpi_bucket: Optional[str] = None,
        kpi_prefix: Optional[str] = None,
        aws_region: Optional[str] = None,
    ) -> None:
        """
        Initialize KPI Retrieval Service.

        Args:
            kpi_bucket: S3 bucket containing KPI data
            kpi_prefix: S3 prefix for KPI files
            aws_region: AWS region
        """
        self.kpi_bucket = kpi_bucket or settings.kpi_s3_bucket
        self.kpi_prefix = kpi_prefix or settings.kpi_s3_prefix
        self.aws_region = aws_region or settings.aws_region

        self.s3_client = boto3.client("s3", region_name=self.aws_region)

    def fetch_tas_kpis(
        self,
        tas_id: str,
        month: Optional[str] = None,
        territory: Optional[str] = None,
        include_trends: bool = True,
    ) -> Dict[str, Any]:
        """
        Fetch KPI data for a specific TAS.

        Args:
            tas_id: TAS employee identifier
            month: Specific month (e.g., "2026-05", "May 2026")
            territory: Territory identifier
            include_trends: Whether to include trend analysis

        Returns:
            Dictionary with KPI metrics and summary
        """
        if not tas_id:
            return {
                "status": "missing_tas_id",
                "kpi_summary": {},
                "metrics": [],
                "message": "TAS ID is required to fetch KPIs",
            }

        try:
            # Fetch KPI records
            kpi_records = self._fetch_kpi_records(
                tas_id=tas_id,
                month=month,
                territory=territory,
            )

            if not kpi_records:
                return {
                    "status": "no_kpis_found",
                    "tas_id": tas_id,
                    "month": month,
                    "territory": territory,
                    "kpi_summary": {},
                    "metrics": [],
                    "message": f"No KPI data found for TAS {tas_id}",
                }

            # Build KPI summary
            kpi_summary = self._build_kpi_summary(
                kpi_records=kpi_records,
                tas_id=tas_id,
                month=month,
            )

            # Add trend analysis if requested
            if include_trends:
                trends = self._analyze_kpi_trends(kpi_records)
                kpi_summary["trends"] = trends

            return {
                "status": "success",
                "tas_id": tas_id,
                "month": month,
                "territory": territory,
                "kpi_summary": kpi_summary,
                "metrics": kpi_records,
            }

        except Exception as exc:
            return {
                "status": "error",
                "tas_id": tas_id,
                "kpi_summary": {},
                "metrics": [],
                "error": str(exc),
                "message": f"Failed to fetch KPIs: {str(exc)}",
            }

    def _fetch_kpi_records(
        self,
        tas_id: str,
        month: Optional[str] = None,
        territory: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch raw KPI records from S3.

        Expected S3 structure:
            s3://bucket/kpi_reports/tas_{tas_id}/kpi_2026-05.json
            s3://bucket/kpi_reports/territory_{territory}/kpi_2026-05.json
            s3://bucket/kpi_reports/monthly/2026-05/tas_{tas_id}.json
        """
        import json

        # Build candidate S3 keys
        candidate_keys = []

        if month:
            normalized_month = self._normalize_month(month)
            candidate_keys.extend(
                [
                    f"{self.kpi_prefix}/tas_{tas_id}/kpi_{normalized_month}.json",
                    f"{self.kpi_prefix}/monthly/{normalized_month}/tas_{tas_id}.json",
                    f"{self.kpi_prefix}/{normalized_month}/tas_{tas_id}_kpi.json",
                ]
            )
        else:
            # Fetch latest available
            candidate_keys.append(f"{self.kpi_prefix}/tas_{tas_id}/")

        if territory:
            candidate_keys.append(
                f"{self.kpi_prefix}/territory_{territory}/tas_{tas_id}.json"
            )

        kpi_records = []

        for key in candidate_keys:
            try:
                if key.endswith("/"):
                    # List objects in prefix
                    response = self.s3_client.list_objects_v2(
                        Bucket=self.kpi_bucket,
                        Prefix=key,
                        MaxKeys=10,
                    )

                    for obj in response.get("Contents", []):
                        obj_key = obj.get("Key", "")
                        if obj_key.endswith(".json"):
                            records = self._read_kpi_json(obj_key)
                            kpi_records.extend(records)
                else:
                    # Read specific file
                    records = self._read_kpi_json(key)
                    kpi_records.extend(records)

            except ClientError:
                # Key not found, continue to next candidate
                continue

        return kpi_records

    def _read_kpi_json(self, key: str) -> List[Dict[str, Any]]:
        """Read and parse KPI JSON from S3."""
        import json

        try:
            response = self.s3_client.get_object(
                Bucket=self.kpi_bucket,
                Key=key,
            )

            raw_body = response["Body"].read().decode("utf-8")
            data = json.loads(raw_body)

            # Handle both single object and array
            if isinstance(data, list):
                return data
            elif isinstance(data, dict):
                return [data]
            else:
                return []

        except Exception:
            return []

    def _build_kpi_summary(
        self,
        kpi_records: List[Dict[str, Any]],
        tas_id: str,
        month: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Build a summarized view of KPI metrics.
        """
        summary = {
            "tas_id": tas_id,
            "month": month,
            "record_count": len(kpi_records),
            "metrics": {},
            "highlights": [],
            "areas_of_concern": [],
        }

        # Common KPI metric names
        metric_keys = [
            "calls_completed",
            "call_target",
            "call_completion_rate",
            "customer_coverage",
            "new_customer_acquisitions",
            "product_presentations",
            "samples_distributed",
            "territory_sales",
            "sales_target",
            "sales_attainment",
            "customer_satisfaction_score",
            "compliance_score",
        ]

        # Aggregate metrics
        for record in kpi_records:
            for key in metric_keys:
                value = record.get(key)
                if value is not None:
                    if key not in summary["metrics"]:
                        summary["metrics"][key] = []
                    summary["metrics"][key].append(value)

        # Calculate averages/totals
        for key, values in summary["metrics"].items():
            if values:
                if isinstance(values[0], (int, float)):
                    summary["metrics"][key] = {
                        "values": values,
                        "average": sum(values) / len(values),
                        "total": sum(values) if "count" in key or "number" in key else None,
                        "latest": values[-1],
                    }

        # Identify highlights and concerns
        for key, metric_data in summary["metrics"].items():
            if isinstance(metric_data, dict):
                avg = metric_data.get("average", 0)

                # Highlight strong performance
                if "rate" in key or "score" in key or "attainment" in key:
                    if avg >= 90:
                        summary["highlights"].append(
                            f"Strong {key.replace('_', ' ')}: {avg:.1f}%"
                        )
                    elif avg < 70:
                        summary["areas_of_concern"].append(
                            f"Below target {key.replace('_', ' ')}: {avg:.1f}%"
                        )

        return summary

    def _analyze_kpi_trends(
        self,
        kpi_records: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Analyze KPI trends over time.
        """
        trends = {
            "direction": "stable",
            "improving_metrics": [],
            "declining_metrics": [],
            "analysis": "Insufficient data for trend analysis",
        }

        if len(kpi_records) < 2:
            return trends

        # Simple trend analysis: compare first vs last
        first_record = kpi_records[0]
        last_record = kpi_records[-1]

        for key in ["call_completion_rate", "sales_attainment", "customer_satisfaction_score"]:
            first_val = first_record.get(key)
            last_val = last_record.get(key)

            if first_val is not None and last_val is not None:
                try:
                    first_val = float(first_val)
                    last_val = float(last_val)

                    if last_val > first_val * 1.05:  # 5% improvement
                        trends["improving_metrics"].append(key)
                    elif last_val < first_val * 0.95:  # 5% decline
                        trends["declining_metrics"].append(key)

                except (ValueError, TypeError):
                    continue

        if trends["improving_metrics"]:
            trends["direction"] = "improving"
        elif trends["declining_metrics"]:
            trends["direction"] = "declining"

        trends["analysis"] = self._generate_trend_narrative(trends)

        return trends

    def _generate_trend_narrative(self, trends: Dict[str, Any]) -> str:
        """Generate human-readable trend narrative."""
        if trends["direction"] == "stable":
            return "Performance metrics are relatively stable with no significant trends."

        parts = []

        if trends["improving_metrics"]:
            metrics_str = ", ".join(
                [m.replace("_", " ") for m in trends["improving_metrics"]]
            )
            parts.append(f"Showing improvement in: {metrics_str}")

        if trends["declining_metrics"]:
            metrics_str = ", ".join(
                [m.replace("_", " ") for m in trends["declining_metrics"]]
            )
            parts.append(f"Experiencing decline in: {metrics_str}")

        return ". ".join(parts) + "."

    def _normalize_month(self, month: str) -> str:
        """
        Normalize month to YYYY-MM format.

        Handles inputs like:
            - "2026-05"
            - "05/2026"
            - "May 2026"
            - "2026/05"
        """
        month = str(month).strip()

        # Already in YYYY-MM format
        if len(month) == 7 and month[4] == "-":
            return month

        # Try parsing various formats
        try:
            dt = datetime.strptime(month, "%B %Y")
            return dt.strftime("%Y-%m")
        except ValueError:
            pass

        try:
            dt = datetime.strptime(month, "%m/%Y")
            return dt.strftime("%Y-%m")
        except ValueError:
            pass

        try:
            dt = datetime.strptime(month, "%Y/%m")
            return dt.strftime("%Y-%m")
        except ValueError:
            pass

        # Return as-is if unable to parse
        return month
