"""
Guideline Retrieval Service for fetching relevant FCR guidelines, rubrics, and examples.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.src.services.bedrock_embeddings_service import BedrockEmbeddingsService
from app.src.services.opensearch_vector_store import OpenSearchVectorStore


class GuidelineRetrievalService:
    """
    Service for retrieving relevant FCR writing guidelines, rubric criteria, and examples
    based on the current coaching context.
    """

    def __init__(
        self,
        embeddings_service: Optional[BedrockEmbeddingsService] = None,
        vector_store: Optional[OpenSearchVectorStore] = None,
    ) -> None:
        """
        Initialize the Guideline Retrieval Service.

        Args:
            embeddings_service: Service for generating embeddings
            vector_store: OpenSearch vector store client
        """
        self.embeddings_service = embeddings_service or BedrockEmbeddingsService()
        self.vector_store = vector_store or OpenSearchVectorStore()

    def retrieve_relevant_guidelines(
        self,
        coaching_context: str,
        competencies: Optional[List[str]] = None,
        top_k: int = 5,
    ) -> Dict[str, Any]:
        """
        Retrieve relevant guidelines based on coaching context and competencies.

        Args:
            coaching_context: Summary of the current coaching observation/context
            competencies: List of competencies being evaluated (e.g., ["Selling Skills", "Clinical Knowledge"])
            top_k: Number of guideline chunks to retrieve

        Returns:
            Dictionary with categorized guideline references
        """
        try:
            # Build retrieval query
            query_parts = [coaching_context]

            if competencies:
                query_parts.append(f"Competencies: {', '.join(competencies)}")

            query_text = " ".join(query_parts)

            # Generate query embedding
            query_embedding = self.embeddings_service.generate_embedding(query_text)

            # Retrieve guidelines
            guideline_results = self.vector_store.hybrid_search(
                query_embedding=query_embedding,
                query_text=query_text,
                document_types=["guideline", "writing_guide"],
                top_k=top_k,
            )

            return {
                "status": "success",
                "guidelines": guideline_results,
                "retrieval_count": len(guideline_results),
            }

        except Exception as exc:
            return {
                "status": "error",
                "guidelines": [],
                "retrieval_count": 0,
                "error": str(exc),
            }

    def retrieve_rubric_criteria(
        self,
        competencies: Optional[List[str]] = None,
        top_k: int = 3,
    ) -> Dict[str, Any]:
        """
        Retrieve relevant rubric criteria for the given competencies.

        Args:
            competencies: List of competencies being evaluated
            top_k: Number of rubric chunks to retrieve

        Returns:
            Dictionary with rubric criteria
        """
        try:
            if not competencies:
                query_text = "FCR rubric criteria and evaluation standards"
            else:
                query_text = f"Rubric evaluation criteria for: {', '.join(competencies)}"

            query_embedding = self.embeddings_service.generate_embedding(query_text)

            rubric_results = self.vector_store.semantic_search(
                query_embedding=query_embedding,
                document_types=["rubric", "evaluation_criteria"],
                top_k=top_k,
            )

            return {
                "status": "success",
                "rubric_criteria": rubric_results,
                "retrieval_count": len(rubric_results),
            }

        except Exception as exc:
            return {
                "status": "error",
                "rubric_criteria": [],
                "retrieval_count": 0,
                "error": str(exc),
            }

    def retrieve_example_fcrs(
        self,
        coaching_scenario: str,
        competencies: Optional[List[str]] = None,
        top_k: int = 3,
    ) -> Dict[str, Any]:
        """
        Retrieve example FCR snippets similar to the current coaching scenario.

        Args:
            coaching_scenario: Description of the current coaching scenario
            competencies: Competencies being addressed
            top_k: Number of examples to retrieve

        Returns:
            Dictionary with example FCR snippets
        """
        try:
            query_parts = [f"Example FCR: {coaching_scenario}"]

            if competencies:
                query_parts.append(f"addressing {', '.join(competencies)}")

            query_text = " ".join(query_parts)

            query_embedding = self.embeddings_service.generate_embedding(query_text)

            example_results = self.vector_store.semantic_search(
                query_embedding=query_embedding,
                document_types=["example", "good_fcr"],
                top_k=top_k,
            )

            return {
                "status": "success",
                "examples": example_results,
                "retrieval_count": len(example_results),
            }

        except Exception as exc:
            return {
                "status": "error",
                "examples": [],
                "retrieval_count": 0,
                "error": str(exc),
            }

    def retrieve_coaching_framework(
        self,
        coaching_type: str = "developmental",
        top_k: int = 3,
    ) -> Dict[str, Any]:
        """
        Retrieve coaching framework guidance (e.g., SEAM, strength/opportunity framing).

        Args:
            coaching_type: Type of coaching (e.g., "developmental", "corrective", "recognition")
            top_k: Number of framework chunks to retrieve

        Returns:
            Dictionary with coaching framework guidance
        """
        try:
            query_text = f"{coaching_type} coaching framework approach and best practices"

            query_embedding = self.embeddings_service.generate_embedding(query_text)

            framework_results = self.vector_store.semantic_search(
                query_embedding=query_embedding,
                document_types=["coaching_framework", "best_practice"],
                top_k=top_k,
            )

            return {
                "status": "success",
                "framework_guidance": framework_results,
                "retrieval_count": len(framework_results),
            }

        except Exception as exc:
            return {
                "status": "error",
                "framework_guidance": [],
                "retrieval_count": 0,
                "error": str(exc),
            }

    def retrieve_comprehensive_context(
        self,
        coaching_context: str,
        competencies: Optional[List[str]] = None,
        coaching_type: str = "developmental",
        include_examples: bool = True,
    ) -> Dict[str, Any]:
        """
        Retrieve comprehensive context including guidelines, rubrics, frameworks, and examples.

        Args:
            coaching_context: Summary of coaching observation
            competencies: Competencies being evaluated
            coaching_type: Type of coaching
            include_examples: Whether to include example FCRs

        Returns:
            Comprehensive context bundle with all relevant references
        """
        results = {
            "status": "success",
            "guidelines": [],
            "rubric_criteria": [],
            "coaching_framework": [],
            "examples": [],
            "retrieval_counts": {},
        }

        try:
            # Retrieve guidelines
            guideline_result = self.retrieve_relevant_guidelines(
                coaching_context=coaching_context,
                competencies=competencies,
                top_k=5,
            )
            results["guidelines"] = guideline_result.get("guidelines", [])
            results["retrieval_counts"]["guidelines"] = guideline_result.get(
                "retrieval_count", 0
            )

            # Retrieve rubric criteria
            rubric_result = self.retrieve_rubric_criteria(
                competencies=competencies,
                top_k=3,
            )
            results["rubric_criteria"] = rubric_result.get("rubric_criteria", [])
            results["retrieval_counts"]["rubric_criteria"] = rubric_result.get(
                "retrieval_count", 0
            )

            # Retrieve coaching framework
            framework_result = self.retrieve_coaching_framework(
                coaching_type=coaching_type,
                top_k=3,
            )
            results["coaching_framework"] = framework_result.get(
                "framework_guidance", []
            )
            results["retrieval_counts"]["coaching_framework"] = framework_result.get(
                "retrieval_count", 0
            )

            # Retrieve examples if requested
            if include_examples:
                example_result = self.retrieve_example_fcrs(
                    coaching_scenario=coaching_context,
                    competencies=competencies,
                    top_k=3,
                )
                results["examples"] = example_result.get("examples", [])
                results["retrieval_counts"]["examples"] = example_result.get(
                    "retrieval_count", 0
                )

            # Add instruction for downstream nodes
            results["instruction"] = (
                "Use these guidelines and rubric criteria to structure the FCR. "
                "Examples are for style reference only—do not copy. "
                "Framework guidance ensures proper coaching approach. "
                "Ground the FCR in current observation details."
            )

            return results

        except Exception as exc:
            results["status"] = "error"
            results["error"] = str(exc)
            return results
