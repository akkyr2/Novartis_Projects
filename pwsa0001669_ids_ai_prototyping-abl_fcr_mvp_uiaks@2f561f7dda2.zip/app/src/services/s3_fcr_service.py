from __future__ import annotations

import json
import os
import re

from app.src.config import settings
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError


class S3FCRService:
    """
    Service responsible for reading historical FCR JSON files from S3.

    Expected environment variables:
        FCR_S3_BUCKET=your-bucket-name
        FCR_S3_PREFIX=optional/base/prefix

    Example S3 layouts supported:
        s3://bucket/fcrs/tas_123/fcr_2024-01-15.json
        s3://bucket/fcrs/2024/01/tas_123_fcr.json
        s3://bucket/fcrs/random-folder/file.json

    The service filters by TAS ID using both:
        1. JSON content fields
        2. S3 object key fallback
    """

    DATE_FIELDS = [
        "fcr_date",
        "field_coaching_date",
        "coaching_date",
        "visit_date",
        "created_at",
        "createdAt",
        "finalized_at",
        "finalizedAt",
        "date",
        "month",
    ]

    TAS_FIELDS = [
        "tas_id",
        "tasId",
        "tas_identifier",
        "tasIdentifier",
        "tas.employee_id",
        "tas.employeeId",
        "tas.id",
        "tas.name",
        "employee_id",
        "employeeId",
    ]

    ABL_FIELDS = [
        "abl_id",
        "ablId",
        "abl.employee_id",
        "abl.employeeId",
        "abl.id",
        "abl.name",
    ]

    def __init__(
        self,
        bucket_name: Optional[str] = None,
        base_prefix: Optional[str] = None,
        aws_region: Optional[str] = None,
        role: Optional[str] = None,
    ) -> None:
        self.bucket_name = (bucket_name or settings.fcr_s3_bucket).strip()
        if role == "guest":
            self.base_prefix = "extracted_json"
        else:
            self.base_prefix = (base_prefix or settings.fcr_s3_prefix).strip()
        self.aws_region = aws_region or settings.aws_region

        if not self.bucket_name:
            raise ValueError(
                "Missing S3 bucket. Set FCR_S3_BUCKET in environment variables."
            )

        if self.base_prefix and not self.base_prefix.endswith("/"):
            self.base_prefix = f"{self.base_prefix}/"

        if self.aws_region:
            self.s3_client = boto3.client("s3", region_name=self.aws_region)
        else:
            self.s3_client = boto3.client("s3")

    def fetch_past_fcrs(
        self,
        tas_id: str,
        abl_id: Optional[str] = None,
        territory: Optional[str] = None,
        max_records: int = 100,
    ) -> List[Dict[str, Any]]:
        """
        Fetches, filters, normalizes, and sorts historical FCR records.

        Returns records sorted from latest to oldest.

        Output shape:
            [
                {
                    "fcr_id": "...",
                    "tas_id": "...",
                    "abl_id": "...",
                    "fcr_date": "2025-01-10",
                    "s3_key": "...",
                    "fcr_json": {...}
                }
            ]
        """

        if not tas_id:
            return []

        keys = self._list_json_keys(tas_id=tas_id)
        records: List[Dict[str, Any]] = []

        for key in keys:
            try:
                json_payload = self._read_json_object(key)
            except Exception:
                continue

            candidate_records = json_payload if isinstance(json_payload, list) else [json_payload]

            for item in candidate_records:
                if not isinstance(item, dict):
                    continue

                if not self._matches_tas(item=item, key=key, tas_id=tas_id):
                    continue

                if abl_id and not self._matches_optional_identifier(
                    item=item,
                    key=key,
                    identifier=abl_id,
                    fields=self.ABL_FIELDS,
                ):
                    # Do not hard fail because older FCRs may not have ABL metadata.
                    # If your data always has ABL IDs, change this to continue.
                    pass

                normalized = self._normalize_record(item=item, key=key)
                records.append(normalized)

        records = self._dedupe_records(records)

        records.sort(
            key=lambda record: record.get("_sort_timestamp") or 0,
            reverse=True,
        )

        for record in records:
            record.pop("_sort_timestamp", None)

        return records[:max_records]

    def _list_json_keys(self, tas_id: str) -> List[str]:
        """
        Lists candidate JSON files from S3.

        This tries a TAS-specific prefix first, then falls back to the configured
        base prefix. This supports both organized and flat S3 layouts.
        """

        candidate_prefixes = []

        clean_tas_id = str(tas_id).strip()

        if self.base_prefix:
            candidate_prefixes.append(f"{self.base_prefix}{clean_tas_id}/")
            candidate_prefixes.append(self.base_prefix)
        else:
            candidate_prefixes.append(f"{clean_tas_id}/")
            candidate_prefixes.append("")

        seen_keys = set()
        json_keys: List[str] = []

        for prefix in candidate_prefixes:
            continuation_token = None

            while True:
                params: Dict[str, Any] = {
                    "Bucket": self.bucket_name,
                    "Prefix": prefix,
                    "MaxKeys": 1000,
                }

                if continuation_token:
                    params["ContinuationToken"] = continuation_token

                try:
                    response = self.s3_client.list_objects_v2(**params)
                except ClientError:
                    break

                for obj in response.get("Contents", []):
                    key = obj.get("Key", "")

                    if not key.lower().endswith(".json"):
                        continue

                    if key in seen_keys:
                        continue

                    seen_keys.add(key)
                    json_keys.append(key)

                if not response.get("IsTruncated"):
                    break

                continuation_token = response.get("NextContinuationToken")

        return json_keys

    def _read_json_object(self, key: str) -> Any:
        response = self.s3_client.get_object(
            Bucket=self.bucket_name,
            Key=key,
        )

        raw_body = response["Body"].read().decode("utf-8")
        return json.loads(raw_body)

    def _normalize_record(self, item: Dict[str, Any], key: str) -> Dict[str, Any]:
        fcr_date_raw = self._first_available_value(item, self.DATE_FIELDS)
        parsed_date = self._parse_date(fcr_date_raw)

        if not parsed_date:
            parsed_date = self._extract_date_from_key(key)

        fcr_id = (
            self._first_available_value(
                item,
                [
                    "fcr_id",
                    "fcrId",
                    "id",
                    "report_id",
                    "reportId",
                ],
            )
            or key
        )

        tas_id = self._first_available_value(item, self.TAS_FIELDS)
        abl_id = self._first_available_value(item, self.ABL_FIELDS)

        fcr_date = None
        sort_timestamp = 0

        if parsed_date:
            fcr_date = parsed_date.date().isoformat()
            sort_timestamp = int(parsed_date.replace(tzinfo=timezone.utc).timestamp())
        elif fcr_date_raw:
            fcr_date = str(fcr_date_raw)

        return {
            "fcr_id": str(fcr_id),
            "tas_id": str(tas_id) if tas_id else None,
            "abl_id": str(abl_id) if abl_id else None,
            "fcr_date": fcr_date,
            "s3_key": key,
            "fcr_json": item,
            "_sort_timestamp": sort_timestamp,
        }

    def _matches_tas(self, item: Dict[str, Any], key: str, tas_id: str) -> bool:
        return self._matches_optional_identifier(
            item=item,
            key=key,
            identifier=tas_id,
            fields=self.TAS_FIELDS,
        )

    def _matches_optional_identifier(
        self,
        item: Dict[str, Any],
        key: str,
        identifier: str,
        fields: List[str],
    ) -> bool:
        if not identifier:
            return True

        expected = self._normalize_text(identifier)

        values = []

        for field in fields:
            value = self._get_nested_value(item, field)
            if value:
                values.append(value)

        for value in values:
            if expected == self._normalize_text(value):
                return True

        normalized_key = self._normalize_text(key)

        if expected and expected in normalized_key:
            return True

        return False

    def _first_available_value(
        self,
        item: Dict[str, Any],
        fields: List[str],
    ) -> Optional[Any]:
        for field in fields:
            value = self._get_nested_value(item, field)
            if value not in [None, ""]:
                return value

        return None

    def _get_nested_value(self, item: Dict[str, Any], dotted_key: str) -> Optional[Any]:
        current: Any = item

        for part in dotted_key.split("."):
            if not isinstance(current, dict):
                return None

            if part not in current:
                return None

            current = current[part]

        return current

    def _parse_date(self, value: Any) -> Optional[datetime]:
        if value in [None, ""]:
            return None

        if isinstance(value, datetime):
            return value

        text = str(value).strip()

        if not text:
            return None

        candidates = [
            text,
            text.replace("Z", "+00:00"),
        ]

        for candidate in candidates:
            try:
                parsed = datetime.fromisoformat(candidate)
                return parsed.replace(tzinfo=None)
            except ValueError:
                pass

        date_patterns = [
            "%Y-%m-%d",
            "%Y/%m/%d",
            "%m/%d/%Y",
            "%d/%m/%Y",
            "%Y-%m",
            "%Y/%m",
            "%b %Y",
            "%B %Y",
            "%d %b %Y",
            "%d %B %Y",
        ]

        for pattern in date_patterns:
            try:
                return datetime.strptime(text, pattern)
            except ValueError:
                pass

        return None

    def _extract_date_from_key(self, key: str) -> Optional[datetime]:
        patterns = [
            r"(\d{4})[-_/](\d{2})[-_/](\d{2})",
            r"(\d{4})[-_/](\d{2})",
        ]

        for pattern in patterns:
            match = re.search(pattern, key)

            if not match:
                continue

            groups = match.groups()

            try:
                if len(groups) == 3:
                    return datetime(
                        int(groups[0]),
                        int(groups[1]),
                        int(groups[2]),
                    )

                if len(groups) == 2:
                    return datetime(
                        int(groups[0]),
                        int(groups[1]),
                        1,
                    )
            except ValueError:
                continue

        return None

    def _dedupe_records(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen = set()
        deduped = []

        for record in records:
            dedupe_key = (
                record.get("fcr_id"),
                record.get("fcr_date"),
                record.get("s3_key"),
            )

            if dedupe_key in seen:
                continue

            seen.add(dedupe_key)
            deduped.append(record)

        return deduped

    def _normalize_text(self, value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", "", str(value).lower().strip())