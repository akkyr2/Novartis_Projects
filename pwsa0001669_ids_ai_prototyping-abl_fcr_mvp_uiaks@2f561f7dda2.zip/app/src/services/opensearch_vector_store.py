"""
OpenSearch Vector Store Service for storing and retrieving FCR guideline embeddings.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import boto3
from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth


class OpenSearchVectorStore:
    """
    Service for managing FCR guidelines, rubrics, and examples in OpenSearch vector store.
    """

    def __init__(
        self,
        index_name: str = None,
        host: Optional[str] = None,
        aws_region: Optional[str] = None,
    ) -> None:
        """
        Initialize OpenSearch Vector Store.

        Args:
            index_name: Name of the OpenSearch index
            host: OpenSearch endpoint (defaults to environment variable)
            aws_region: AWS region
        """
        from app.src.config import settings

        self.index_name = index_name or settings.opensearch_index
        self.host = host or settings.opensearch_host
        self.aws_region = aws_region or settings.aws_region

        if not self.host:
            raise ValueError(
                "OpenSearch host is required. Set OPENSEARCH_HOST environment variable."
            )

        # AWS authentication
        credentials = boto3.Session().get_credentials()
        auth = AWSV4SignerAuth(credentials, self.aws_region, "aoss")  # "aoss" for serverless

        self.client = OpenSearch(
            hosts=[{"host": self.host, "port": 443}],
            http_auth=auth,
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection,
            timeout=30,
        )

    def create_index_if_not_exists(self, dimension: int = 1024) -> None:
        """
        Create the index with k-NN settings if it doesn't exist.

        Args:
            dimension: Embedding vector dimension (1024 for Titan v2)
        """
        if self.client.indices.exists(index=self.index_name):
            return

        index_body = {
            "settings": {
                "index": {
                    "knn": True,
                    "knn.algo_param.ef_search": 512,
                }
            },
            "mappings": {
                "properties": {
                    "embedding": {
                        "type": "knn_vector",
                        "dimension": dimension,
                        "method": {
                            "name": "hnsw",
                            "space_type": "cosinesimil",
                            "engine": "nmslib",
                            "parameters": {"ef_construction": 512, "m": 16},
                        },
                    },
                    "content": {"type": "text"},
                    "document_type": {"type": "keyword"},
                    "section": {"type": "keyword"},
                    "source": {"type": "keyword"},
                    "metadata": {"type": "object", "enabled": True},
                }
            },
        }

        self.client.indices.create(index=self.index_name, body=index_body)

    def index_document(
        self,
        doc_id: str,
        content: str,
        embedding: List[float],
        document_type: str,
        section: Optional[str] = None,
        source: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Index a document with its embedding.

        Args:
            doc_id: Unique document identifier
            content: The text content
            embedding: The embedding vector
            document_type: Type (e.g., "guideline", "rubric", "example", "coaching_framework")
            section: Optional section name
            source: Source file/document name
            metadata: Additional metadata
        """
        document = {
            "content": content,
            "embedding": embedding,
            "document_type": document_type,
            "section": section,
            "source": source,
            "metadata": metadata or {},
        }

        self.client.index(index=self.index_name, id=doc_id, body=document)

    def semantic_search(
        self,
        query_embedding: List[float],
        document_types: Optional[List[str]] = None,
        top_k: int = 5,
        min_score: float = 0.5,
    ) -> List[Dict[str, Any]]:
        """
        Perform semantic search using k-NN.

        Args:
            query_embedding: The query embedding vector
            document_types: Filter by document types (e.g., ["guideline", "rubric"])
            top_k: Number of results to return
            min_score: Minimum similarity score threshold

        Returns:
            List of matching documents with scores
        """
        query = {
            "size": top_k,
            "query": {
                "bool": {
                    "must": [
                        {
                            "knn": {
                                "embedding": {
                                    "vector": query_embedding,
                                    "k": top_k,
                                }
                            }
                        }
                    ]
                }
            },
            "_source": {
                "excludes": ["embedding"]  # Don't return embedding in results
            },
        }

        # Add document type filter if specified
        if document_types:
            query["query"]["bool"]["filter"] = [
                {"terms": {"document_type": document_types}}
            ]

        try:
            response = self.client.search(index=self.index_name, body=query)

            results = []
            for hit in response["hits"]["hits"]:
                score = hit["_score"]

                if score >= min_score:
                    results.append(
                        {
                            "id": hit["_id"],
                            "score": score,
                            "content": hit["_source"]["content"],
                            "document_type": hit["_source"]["document_type"],
                            "section": hit["_source"].get("section"),
                            "source": hit["_source"].get("source"),
                            "metadata": hit["_source"].get("metadata", {}),
                        }
                    )

            return results

        except Exception as exc:
            print(f"Search failed: {str(exc)}")
            return []

    def hybrid_search(
        self,
        query_embedding: List[float],
        query_text: str,
        document_types: Optional[List[str]] = None,
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Perform hybrid search (semantic + keyword).

        Args:
            query_embedding: The query embedding vector
            query_text: The query text for keyword matching
            document_types: Filter by document types
            top_k: Number of results to return

        Returns:
            List of matching documents with scores
        """
        query = {
            "size": top_k,
            "query": {
                "bool": {
                    "should": [
                        {
                            "knn": {
                                "embedding": {
                                    "vector": query_embedding,
                                    "k": top_k,
                                }
                            }
                        },
                        {
                            "multi_match": {
                                "query": query_text,
                                "fields": ["content^2", "section"],
                                "type": "best_fields",
                            }
                        },
                    ],
                    "minimum_should_match": 1,
                }
            },
            "_source": {"excludes": ["embedding"]},
        }

        if document_types:
            query["query"]["bool"]["filter"] = [
                {"terms": {"document_type": document_types}}
            ]

        try:
            response = self.client.search(index=self.index_name, body=query)

            results = []
            for hit in response["hits"]["hits"]:
                results.append(
                    {
                        "id": hit["_id"],
                        "score": hit["_score"],
                        "content": hit["_source"]["content"],
                        "document_type": hit["_source"]["document_type"],
                        "section": hit["_source"].get("section"),
                        "source": hit["_source"].get("source"),
                        "metadata": hit["_source"].get("metadata", {}),
                    }
                )

            return results

        except Exception as exc:
            print(f"Hybrid search failed: {str(exc)}")
            return []

    def bulk_index_documents(
        self,
        documents: List[Dict[str, Any]],
    ) -> None:
        """
        Bulk index multiple documents.

        Args:
            documents: List of documents with structure:
                {
                    "id": str,
                    "content": str,
                    "embedding": List[float],
                    "document_type": str,
                    "section": Optional[str],
                    "source": Optional[str],
                    "metadata": Optional[Dict]
                }
        """
        bulk_data = []

        for doc in documents:
            action = {"index": {"_index": self.index_name, "_id": doc["id"]}}
            bulk_data.append(action)

            body = {
                "content": doc["content"],
                "embedding": doc["embedding"],
                "document_type": doc["document_type"],
                "section": doc.get("section"),
                "source": doc.get("source"),
                "metadata": doc.get("metadata", {}),
            }
            bulk_data.append(body)

        if bulk_data:
            self.client.bulk(body=bulk_data)
