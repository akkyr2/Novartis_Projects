"""

SEAM Generation Service

Auto-generates SEAM pre-work from FCR history + KPI data when no existing SEAM is found.

"""

from __future__ import annotations
 
import json

import os

import re

from typing import Any, Dict, List, Optional
 
import boto3

from botocore.exceptions import ClientError
 
from app.src.services.s3_fcr_service import S3FCRService

from app.src.services.kpi_retrieval_service import KPIRetrievalService

from app.src.llm.bedrock_client import BedrockClient
 
from app.src.config import settings

SEAM_BUCKET = settings.seam_s3_bucket

SEAM_PREFIX = settings.seam_s3_prefix
 
# Concise system context — gives LLM all the domain knowledge it needs in minimal tokens

SYSTEM_CONTEXT = """
# ROLE & OBJECTIVE
You are an AI assistant helping Territory Account Specialists (TAS) at Novartis create high-quality SEAM pre-work notes for monthly ABL coaching sessions.
 
## BUSINESS BACKGROUND
**Novartis Field Coaching Workflow:**
- **TAS**: Pharma field representative who visits doctors/HCPs
- **ABL**: Area Business Leader (TAS's manager)
- **Monthly Process**:
  1. ABL observes TAS during field day (doctor visits)
  2. TAS creates SEAM pre-work using: Past FCRs + current performance data
  3. ABL brings field evaluation notes
  4. Together they discuss and create current month's FCR (Field Coaching Report)
 
**Your Task**: Generate a SEAM pre-work note that is data-driven, honest, actionable, and ready for ABL review.
 
---
 
## PRODUCT & COMPETITIVE LANDSCAPE
- **Our Brand**: Rhapsido (Novartis)
- **Competitors**: Dupixent (Sanofi/Regeneron), Xolair (Genentech)
- **Therapeutic Area**: [Add if relevant - appears to be respiratory/immunology]
 
---
 
## DATA SOURCES YOU MUST ANALYZE
 
### 1. **Territory-Level Baseline (data_20: Used in draft_fcr_node + performance analysis + territory benchmarking to generate KPI-driven narratives and insightsTerritory-level (geo aggregation)Core dataset for high-level TAS performance evaluation and cross-territory comparison)**
   - Metrics: Rhapsido TRx/NBRx, Dupixent TRx/NBRx, Xolair TRx/NBRx
   - Growth %, Reach, Depth, Start Forms
   - One row per territory
 
### 2. **HCP-Level Detail (data_21: HCP-level KPI dataset mapped to territories including HCP attributes (Tier, Degree, Target Flags) and KPI metrics (TRx, NBRx, calls, samples, growth, CSU patients)Used in deep coaching insights + HCP-level analysis + opportunity identification (e.g., which HCPs to target, gaps in engagement)HCP-level (individual entity, multi-territory mapping)Enables micro-level coaching recommendations and targeted interventions)**
   - Individual doctor prescribing patterns
   - Rhapsido/Dupixent/Xolair: TRx, NBRx, growth %
   - Start forms, tier classification, CSU patients, call history
 
### 3. **Prime KPIs (Territory-Level: Core dataset for performance-driven coaching insights and understanding as TAS current situation)**
   - TRx writers, Depth, Reach %
   - Top 2 Tier reach, CFA %
   - L&L calls, Samples distributed
   - NBA engagement, Zero call days
 
### 4. **Rhapsido Weekly Tracker (Used for recent performance context and short-term trend analysis.  Useful for understanding as TAS current situation and define stragies for performance improvement and queues for actions etc.,)**
   - Weekly NBRx: Actuals vs. Goal
   - QTD attainment %, Trend direction
 
---
 
## SEAM FRAMEWORK (MANDATORY STRUCTURE)
 
### **S - SITUATION** (2-3 sentences with real numbers)
**What to include:**
- Current territory performance vs. goal (NBRx, TRx, Start Forms, Writers, Reach)
- Identify the ONE biggest gap/challenge holding back performance
- Use specific metrics: "97% to NBRx goal" NOT "close to goal"
- Reference QTD or YTD timeframe
 
**Quality Check:**
✓ Includes at least 3 specific metrics with %
✓ Clearly identifies primary performance gap
✓ Compares actual vs. goal
 
---
 
### **E - EXPLANATION** (2 sentences max)
**What to include:**
- Personal accountability: What YOU (TAS) have/haven't been doing
- Root cause of the gap (behaviors, not external factors)
- Be honest and specific: "I focused too much on X, neglecting Y"
 
**Quality Check:**
✓ Uses first-person ("I" statements)
✓ Focuses on controllable behaviors
✓ Avoids blaming external factors (market, competitors, etc.)
 
---
 
### **A - ACTIONS** (3 specific tactics)
**What to include:**
- 3 concrete, specific tactics you'll execute differently
- Name actual doctors/accounts where possible: "Dr. Smith, Dr. Jones"
- One sentence per action
- Link to available resources: L&L, Webinars, RTE, TLL, MSL, Quantified
 
**Quality Check:**
✓ Each action is specific (not vague like "increase calls")
✓ Includes doctor names or account identifiers when possible
✓ Directly addresses the gap identified in Situation
 
---
 
### **M - MEASURES** (3 measurable outcomes)
**What to include:**
- 3 short, quantifiable success metrics
- Each measure ties directly to one action
- Include timeframes: "within 30-45 days"
- Show continuity from prior SMART goals (if past FCR data provided)
 
**Quality Check:**
✓ Each measure is quantifiable (numbers, counts, %)
✓ Includes specific timeline
✓ Logically connected to the Actions above
 
---
 
## TONE & STYLE GUIDELINES
- **Concise**: Short, punchy sentences
- **Honest**: Own your performance gaps
- **Conversational**: Like texting your ABL, but professional
- **Data-driven**: Use real numbers, not generalities
- **Action-oriented**: Forward-looking, not dwelling on past
 
**Avoid:**
❌ Corporate jargon or buzzwords
❌ Passive voice ("Calls were made...")
❌ Vague statements ("Improve performance...")
❌ Blaming external factors
 
---
 
## SEAM EXAMPLE (Low Breadth Scenario)
 
**Situation:**  
YTD, my territory is at 97% to NBRx goal and 98% to TRx goal. Volume per writer is stable but prescribing breadth is low — high NBRx concentration from a small group of writers. Call activity and Reach are on target but new SFs haven't accelerated.
 
**Explanation:**  
My focus has been heavily on depth with existing writers, with less effort on activating new/occasional writers. I haven't prioritized challenge thinking questions to uncover hesitation in starting patients.
 
**Actions:**
1. Identify and prioritize 3 new writers (Dr. Smith, Dr. Jones, Dr. Hill) aligned to bio-naive patient populations.
2. Lead with challenge thinking questions and make explicit ask focused on trial and initiation.
3. Practice challenge thinking questions in Quantified once weekly to strengthen messaging.
 
**Measures:**
1. Activate Dr. Smith, Jones, and Hill within 30-45 days using L&L, Webinar, RTE, TLL, or MSL engagement.
2. Track SF and NBRx for at least 1 new patient start from each new writer.
3. Once clinically sold, execute ARM lunch pull-through.
 
---
 
## STEP-BY-STEP INSTRUCTIONS FOR AGENT
 
### STEP 1: DATA ANALYSIS
1. Review all provided data sources
2. Calculate key gaps: Actual vs. Goal for NBRx, TRx, Reach, Depth, Start Forms
3. Identify the PRIMARY performance gap (biggest barrier to goal attainment)
4. Analyze HCP-level data to find specific doctors to target
 
### STEP 2: SITUATION WRITING
1. State current performance with 3+ specific metrics
2. Identify the ONE biggest gap
3. Keep to 2-3 sentences with real numbers
 
### STEP 3: EXPLANATION WRITING
1. Reflect on TAS behaviors causing the gap
2. Use "I" statements and personal accountability
3. Max 2 sentences
 
### STEP 4: ACTIONS CREATION
1. Develop 3 specific tactics addressing the gap
2. Name real doctors from data_21 if available
3. Link to Novartis resources (L&L, MSL, etc.)
 
### STEP 5: MEASURES DEFINITION
1. Create 3 quantifiable outcomes with timelines
2. Ensure each ties to an action
3. Check continuity with past FCR SMART goals (if provided)
 
### STEP 6: QUALITY ASSURANCE
- Re-read for tone: concise, honest, conversational
- Verify all numbers are accurate from data sources
- Ensure no corporate jargon or blame language
- Confirm SEAM is 8-12 sentences total
 
---
 
## COMMON PITFALL SCENARIOS & HOW TO HANDLE
 
**If NBRx is low but Reach is high:**
→ Focus on depth/messaging quality, not call frequency
 
**If Start Forms are low:**
→ Focus on challenge thinking questions and trial initiation discussions
 
**If Reach is low (especially Top Tier):**
→ Prioritize coverage of high-potential HCPs with specific names
 
**If performance is at/above goal:**
→ Focus on sustainability or competitive defense (Dupixent/Xolair share)
 
---
 
## OUTPUT FORMAT
Generate SEAM in this exact structure:
 
**Situation:**  
[2-3 sentences with metrics]
 
**Explanation:**  
[1-2 sentences with personal accountability]
 
**Actions:**  
1. [Specific tactic]
2. [Specific tactic]
3. [Specific tactic]
 
**Measures:**  
1. [Quantifiable outcome with timeline]
2. [Quantifiable outcome with timeline]
3. [Quantifiable outcome with timeline]
 
---
 
## INTEGRATION WITH PAST FCRS
If previous FCR data is provided:
- Reference prior SMART goals in Measures section
- Show progress or pivots from last month's actions
- Acknowledge what worked/didn't work from previous cycle
 
"""
 
 
class SEAMGenerationService:

    def __init__(self, aws_region: str = None):

        self.s3_client = boto3.client("s3", region_name=aws_region)

        self.fcr_service = S3FCRService(aws_region=aws_region)

        self.kpi_service = KPIRetrievalService(aws_region=aws_region)

        self.bedrock = BedrockClient(region_name=aws_region)

        self._data_dir = os.path.join(os.path.dirname(__file__), "..", "..", "data")
 
    def _resolve_territory(self, tas_id: str) -> str:

        """Resolve TAS name/ID to territory using tas_territory_mapping.xlsx."""

        import pandas as pd

        path = os.path.join(self._data_dir, "tas_territory_mapping.xlsx")

        if not os.path.exists(path) or not tas_id:

            return ""

        try:

            df = pd.read_excel(path)

            tas_lower = tas_id.lower().replace(" ", "")

            for _, row in df.iterrows():

                tas_name = str(row.get("TAS Name", "")).lower().replace(" ", "")

                s3_key = str(row.get("S3 Key", "")).lower().replace(" ", "")

                if tas_lower == tas_name or tas_lower == s3_key or tas_lower in tas_name or tas_name in tas_lower:

                    return str(row.get("Territory", ""))

            return ""

        except Exception:

            return ""
 
    def check_existing_seam(self, tas_id: str, month: str) -> Optional[Dict[str, Any]]:

        """Check S3 for an existing SEAM for this TAS + month."""

        normalized_month = self._normalize_month(month)

        candidate_keys = [

            f"{SEAM_PREFIX}{tas_id}/{normalized_month}.json",

            f"{SEAM_PREFIX}{tas_id}/seam_{normalized_month}.json",

        ]

        for key in candidate_keys:

            try:

                resp = self.s3_client.get_object(Bucket=SEAM_BUCKET, Key=key)

                data = json.loads(resp["Body"].read().decode("utf-8"))

                return data

            except (ClientError, json.JSONDecodeError):

                continue

        return None
 
    def generate_seam(self, tas_id: str, month: str) -> Dict[str, Any]:

        """Generate SEAM from FCR history + KPI data."""

        territory = self._resolve_territory(tas_id)

        fcr_records = self.fcr_service.fetch_past_fcrs(tas_id=tas_id, max_records=4)

        kpi_data = self._fetch_local_kpis(territory)

        prompt = self._build_prompt(tas_id, fcr_records, kpi_data, territory)
 
        raw = self.bedrock.invoke_claude(

            prompt=prompt,

            model_id=None,

            max_tokens=1000,

            temperature=0.3,

        )
 
        seam = self._parse_response(raw)

        if seam:

            seam["tas_id"] = tas_id

            seam["month"] = month

            seam["auto_generated"] = True

        return seam or {"status": "generation_failed", "tas_id": tas_id, "month": month}
 
    def _fetch_local_kpis(self, territory: str) -> Dict[str, Any]:

        """Fetch KPIs from all local data files for the territory."""

        import pandas as pd

        if not territory:

            return {}

        geo_code = territory.split(" - ")[0].strip() if " - " in territory else territory

        result = {}
 
        # 1. data_20: Territory-level KPIs (original baseline)

        try:

            path = os.path.join(self._data_dir, "data_20_modified_territory_level_kpis.xlsx")

            if os.path.exists(path):

                df = pd.read_excel(path)

                match = df[df["Territory"].str.contains(geo_code, case=False, na=False)]

                if not match.empty:

                    result["territory_kpis"] = match.iloc[0].dropna().to_dict()

        except Exception:

            pass
 
        # 2. data_21: HCP-level KPIs aggregated for territory

        try:

            path = os.path.join(self._data_dir, "data_21_modified_KPIs_of_HCP_mapped_to_territory.xlsx")

            if os.path.exists(path):

                df = pd.read_excel(path)

                match = df[df["Territory"].str.contains(geo_code, case=False, na=False)]

                if not match.empty:

                    result["hcp_data"] = {

                        "total_hcps": len(match),

                        "tier_breakdown": match["Tier"].value_counts().to_dict(),

                        "rhapsido_trx": float(match["Rhapsido TRx (a/o 04/17)"].sum()),

                        "rhapsido_nbrx": float(match["Rhapsido NBRx (a/o 05/04)"].sum()),

                        "rhapsido_trx_growth_avg": round(float(match["Rhapsido TRx Growth % (a/o 04/17)"].mean()), 4),

                        "rhapsido_nbrx_growth_avg": round(float(match["Rhapsido NBRx Growth % (a/o 05/01)"].mean()), 4),

                        "dupixent_trx": float(match["Dupixent TRx (a/o 04/10)"].sum()),

                        "dupixent_nbrx": float(match["Dupixent NBRx (a/o 04/10)"].sum()),

                        "dupixent_nbrx_growth_avg": round(float(match["Dupixent NBRx Growth % (a/o 04/10)"].mean()), 4),

                        "xolair_trx": float(match["Xolair TRx (a/o 04/10)"].sum()),

                        "xolair_nbrx": float(match["Xolair NBRx (a/o 04/10)"].sum()),

                        "csu_patients": float(match["Moderate-to-Severe CSU Patients (Target HCPs)"].sum()),

                        "total_calls": int(match["Calls"].sum()),

                    }

        except Exception:

            pass
 
        # 3. Prime KPIs: Territory-level performance

        try:

            path = os.path.join(self._data_dir, "Prime KPIs.xlsx")

            if os.path.exists(path):

                df = pd.read_excel(path)

                match = df[df["Territory"].str.contains(geo_code, case=False, na=False)]

                if not match.empty:

                    row = match.iloc[0]

                    prime = {}

                    for col in ["Rhapsido Start Forms (a/o 04/19)", "Rhapsido NBRx (a/o 04/19)",

                                "Rhapsido TRx (a/o 04/03)", "Dupixent NBRx (a/o 03/27)",

                                "Xolair NBRx (a/o 03/27)", "TRx Writers (a/o 04/03)",

                                "Depth", "Reach %", "Top 2 Tier Reach %", "Calls",

                                "L&L Calls", "Moderate-to-Severe CSU Patients (Target HCPs)",

                                "Zero Calls Days"]:

                        val = row.get(col)

                        if val is not None and str(val) != "nan":

                            prime[col] = val

                    if prime:

                        result["prime_kpis"] = prime

        except Exception:

            pass
 
        # 4. Rhapsido Weekly Tracker: NBRx goal attainment

        try:

            import glob as glob_mod

            files = glob_mod.glob(os.path.join(self._data_dir, "Rhapsido Allergy Weekly*"))

            if files:

                df = pd.read_excel(files[0], sheet_name="NBRx Summary", header=None)

                header = df.iloc[6].tolist()

                data = df.iloc[7:]

                data.columns = header

                match = data[data["Geo Code"].astype(str).str.contains(geo_code, case=False, na=False)]

                if not match.empty:

                    row = match.iloc[0]

                    result["weekly_tracker"] = {

                        "nbrx_ltd": row.get("Total\nNBRx"),

                        "avg_nbrx_per_week": row.get("Avg. NBRx/ Week"),

                        "nbrx_goal_qtd": row.get("NBRx Goal"),

                        "nbrx_actual_qtd": row.get("NBRx Actual"),

                    }

        except Exception:

            pass
 
        return result
 
    def _build_prompt(self, tas_id: str, fcr_records: List[Dict], kpi_data: Dict, territory: str) -> str:

        kpi_summary = "No KPI data available."

        if kpi_data:

            kpi_summary = json.dumps(kpi_data, indent=2, default=str)[:3000]
 
        fcr_section = "No prior FCRs."

        if fcr_records:

            parts = []

            for fcr in fcr_records[:4]:

                fcr_json = fcr.get("fcr_json", {})

                obs = fcr_json.get("observations", {})

                obs_content = obs.get("content", "") if isinstance(obs, dict) else str(obs)

                smart_steps = fcr_json.get("smart_action_steps", [])

                smart_text = ", ".join([s.get("content", "")[:100] for s in smart_steps[:3]])

                parts.append(f"[{fcr.get('fcr_date', '?')}] {obs_content[:250]} | SMART: {smart_text}")

            fcr_section = "\n".join(parts)
 
        return f"""{SYSTEM_CONTEXT}
 
TAS: {tas_id} | Territory: {territory}

CRITICAL NAME RULE: Use ONLY the name "{tas_id}" when referring to the TAS. Do NOT substitute any other name from FCR history or data.
 
PERFORMANCE DATA:

{kpi_summary}
 
FCR HISTORY:

{fcr_section}
 
Write SEAM pre-work using the data above. Output ONLY raw JSON: {{"situation":"...","explanation":"...","actions":["...","...","..."],"measures":["...","...","..."]}}"""
 
    def _parse_response(self, text: str) -> Optional[Dict[str, Any]]:

        if not text:

            return None

        cleaned = text.strip()

        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)

        cleaned = re.sub(r"\s*```$", "", cleaned)

        try:

            return json.loads(cleaned)

        except json.JSONDecodeError:

            return None
 
    def _normalize_month(self, month: str) -> str:

        from datetime import datetime

        month = str(month).strip()

        if len(month) == 7 and month[4] == "-":

            return month

        for fmt in ["%B %Y", "%m/%Y", "%Y/%m"]:

            try:

                return datetime.strptime(month, fmt).strftime("%Y-%m")

            except ValueError:

                continue

        return month
 
    def format_seam_as_text(self, seam: Dict[str, Any]) -> str:

        """Convert SEAM JSON to readable text."""

        situation = seam.get("situation", "")

        explanation = seam.get("explanation", "")

        actions = seam.get("actions", [])

        measures = seam.get("measures", [])
 
        parts = [f"Situation:\n{situation}", f"\nExplanation:\n{explanation}"]

        if actions:

            parts.append("\nActions:")

            for a in actions:

                parts.append(f"- {a}")

        if measures:

            parts.append("\nMeasures:")

            for m in measures:

                parts.append(f"- {m}")

        return "\n".join(parts)

 