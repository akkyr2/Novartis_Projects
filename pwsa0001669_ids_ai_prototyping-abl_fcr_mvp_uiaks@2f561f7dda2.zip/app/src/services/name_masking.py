"""
Guest mode name masking — replaces real ABL/TAS names with dummy names in UI responses.
Only applied when role=guest. Internal processing uses real names.
"""

import re

# Real name → Display name (guest mode only)
_GUEST_NAME_MAP = {
    # ABLs
    "Andie Miller": "Sarah Mitchell",
    "Eddie Bahri": "David Chen",
    # TASes under Andie Miller (Sarah Mitchell)
    "Devon Seibert": "Rachel Torres",
    "JAREDTATE": "Michael Grant",
    "Jared Tate": "Michael Grant",
    "Johnny Pecoraro": "James Patterson",
    "Joy Flynn Wall": "Lauren Hayes",
    "Kendell Tippet": "Kevin Brooks",
    "Kristin Cocci": "Amanda Foster",
    "Steve Bui": "Daniel Park",
    # TASes under Eddie Bahri (David Chen)
    "Andy Backus": "Brian Walsh",
    "Ashley Pierson": "Emily Carter",
    "D\u2019Ambrosi": "Mark Sullivan",
    "D'Ambrosi": "Mark Sullivan",
    "Bob D'Ambrosi": "Mark Sullivan",
    "Bob D\u2019Ambrosi": "Mark Sullivan",
}

# First/last names needing word-boundary replace (safety net for LLM partial references)
_GUEST_FIRST_NAMES = {
    "Jared": "Michael",
    "Devon": "Rachel",
    "Johnny": "James",
    "Kendell": "Kevin",
    "Kristin": "Amanda",
    "Pecoraro": "Patterson",
    "Seibert": "Torres",
    "Tippet": "Brooks",
    "Cocci": "Foster",
    "Backus": "Walsh",
    "Pierson": "Carter",
}


def mask_name(name: str) -> str:
    """Replace real name with dummy name for guest display."""
    return _GUEST_NAME_MAP.get(name, name)


def unmask_name(masked_name: str) -> str:
    """Reverse lookup: get real name from dummy name. Prefers longer (proper) name."""
    matches = [real for real, dummy in _GUEST_NAME_MAP.items() if dummy == masked_name]
    if matches:
        return max(matches, key=len)  # Prefer "Jared Tate" over "JAREDTATE"
    return masked_name


def mask_text(text: str) -> str:
    """Replace all occurrences of real names in a text block."""
    if not text:
        return text
    # First pass: full names (longer first to avoid partial clobbering)
    for real, dummy in sorted(_GUEST_NAME_MAP.items(), key=lambda x: -len(x[0])):
        if real in text:
            text = text.replace(real, dummy)
    # Second pass: first/last names with word boundaries
    for real, dummy in _GUEST_FIRST_NAMES.items():
        if real in text:
            text = re.sub(r'\b' + re.escape(real) + r'\b', dummy, text)
    return text
