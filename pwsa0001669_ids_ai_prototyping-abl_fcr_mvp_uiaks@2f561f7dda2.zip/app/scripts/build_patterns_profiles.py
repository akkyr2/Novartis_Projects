"""
Build rich profile.json-style data from abl_app_fcr_extracted_json/ files.
Writes output to S3: patterns_profiles/{TAS_NAME}.json

Usage:
    cd ~/pwsa0001669_ids_ai_prototyping
    python -m app.scripts.build_patterns_profiles
"""

import json
import re
import os
import sys
from datetime import datetime
from collections import defaultdict
from typing import Dict, Any, List

import boto3

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app.src.llm.bedrock_client import BedrockClient

S3_BUCKET = "abl-field-coaching-reports"
INPUT_PREFIX = "abl_app_fcr_extracted_json/"
OUTPUT_PREFIX = "patterns_profiles/"
REGION = "us-east-1"

PATTERN_PROMPT = """You are a pharmaceutical field coaching analyst. Analyze this Field Coaching Report (FCR) and extract coaching patterns.

**TAS Name:** {tas_name}
**ABL Name:** {abl_name}
**FCR Date:** {fcr_date}

**Current FCR data:**
```json
{fcr_json}
```

**Past FCRs for this TAS (if any):**
```json
{past_fcrs_json}
```

Extract the following as JSON:
{{
  "fcr_summary": "string (3-5 sentence summary of what was observed in this FCR — field execution, key strengths shown, areas needing development)",
  "strengths": ["string (specific skill/competency that was strong, e.g., Product Knowledge, HCP Engagement, Clinical Selling)"],
  "areas_of_improvement": ["string (specific skill/competency needing work, e.g., Breadth Expansion, Closing Technique)"],
  "areas_coached": ["string (standard competencies observed: Plan, Engage, Advance, Close, Follow-up)"],
  "key_coaching_topics": ["string (top 1-3 from ONLY the standard 5: Plan, Engage, Advance, Close, Follow-up)"]
}}

Rules:
- A skill CANNOT appear in both strengths and areas_of_improvement.
- "areas_coached" should contain ONLY from the standard 5: Plan, Engage, Advance, Close, Follow-up. Include a competency if it was scored or observed.
- "strengths" and "areas_of_improvement" should be specific descriptive skills (e.g., "Product Knowledge", "Territory Management"), not just the standard 5.
- "key_coaching_topics" MUST be from the standard 5 ONLY: Plan, Engage, Advance, Close, Follow-up. Pick the 1-3 that were the PRIMARY coaching focus in this session.
- "fcr_summary" should be specific and evidence-based, referencing what the TAS actually did.
- Return ONLY valid JSON, no markdown.
"""


def clean_json_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*\n?", "", text)
    text = re.sub(r"\n?\s*```\s*$", "", text)
    return text.strip()


def parse_filename(key: str) -> Dict[str, str]:
    """Parse ABL_TAS_FCR_date.json filename."""
    filename = key.replace(INPUT_PREFIX, "").replace(".json", "")
    parts = filename.split("_FCR_")
    if len(parts) != 2:
        return None
    name_part = parts[0]
    date_part = parts[1].strip()
    segments = name_part.split("_")
    if len(segments) < 2:
        return None

    abl_raw = segments[0]
    tas_raw = segments[1]
    abl_display = re.sub(r'([a-z])([A-Z])', r'\1 \2', abl_raw)
    tas_display = re.sub(r'([a-z])([A-Z])', r'\1 \2', tas_raw)

    # Parse date
    date_clean = re.sub(r'[\s-]', '_', date_part)
    date_match = re.match(r'(\d{1,2})_(\d{1,2})_(\d{4})', date_clean)
    if not date_match:
        return None
    a, b, y = int(date_match.group(1)), int(date_match.group(2)), int(date_match.group(3))
    try:
        if a > 12:
            fcr_date = datetime(y, b, a)
        else:
            fcr_date = datetime(y, a, b) if b <= 31 else datetime(y, b, a)
    except (ValueError, TypeError):
        return None

    return {
        "abl": abl_display,
        "tas": tas_display,
        "date": fcr_date,
        "month": fcr_date.strftime("%Y-%m"),
    }


def run_pattern_mining(fcr_data: Dict, tas_name: str, abl_name: str, fcr_date: str, past_fcrs: List[Dict]) -> Dict:
    """Run LLM pattern mining on a single FCR."""
    # Trim FCR data for prompt
    fcr_for_prompt = {
        "observations": fcr_data.get("observations", {}),
        "competencies": fcr_data.get("competencies", {}),
        "smart_action_steps": fcr_data.get("smart_action_steps", []),
        "previous_smart_action_steps": fcr_data.get("previous_smart_action_steps", []),
        "metadata": fcr_data.get("metadata", {}),
    }

    # Trim past FCRs
    past_trimmed = []
    for p in past_fcrs[-3:]:
        past_trimmed.append({
            "date": p.get("date", ""),
            "observations": p.get("observations", {}),
            "competencies": p.get("competencies", {}),
            "smart_action_steps": p.get("smart_action_steps", []),
        })

    prompt = PATTERN_PROMPT.format(
        tas_name=tas_name,
        abl_name=abl_name,
        fcr_date=fcr_date,
        fcr_json=json.dumps(fcr_for_prompt, indent=2, default=str)[:4000],
        past_fcrs_json=json.dumps(past_trimmed, indent=2, default=str)[:2000] if past_trimmed else "[]",
    )

    bedrock = BedrockClient(region_name=REGION)
    llm_output = bedrock.invoke_claude(
        prompt=prompt,
        model_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        max_tokens=2048,
        temperature=0.0,
    )

    cleaned = clean_json_text(llm_output)
    return json.loads(cleaned)


def build_session_entry(pattern_result: Dict, fcr_date: datetime, month: str) -> Dict:
    """Convert LLM pattern output to profile.json SESSION_MEMORY format."""
    strengths = pattern_result.get("strengths", [])
    areas = pattern_result.get("areas_of_improvement", [])
    coached = pattern_result.get("areas_coached", [])
    topics = pattern_result.get("key_coaching_topics", [])
    summary = pattern_result.get("fcr_summary", "")

    return {
        "DATETIME": fcr_date.isoformat(),
        "month": month,
        "Evaluation note summary": summary,
        "Evaluation note Strengths": ", ".join(strengths[:3]),
        "Evaluation note Areas of Improvement": ", ".join(areas[:3]),
        "SEAM note summary": "",
        "SEAM note Strengths": ", ".join(strengths[:2]),
        "SEAM note Areas of Improvement": ", ".join(areas[:2]),
        "FCR note summary": summary,
        "FCR note Strengths": ", ".join(strengths),
        "FCR note Areas of Improvement": ", ".join(areas),
        "Areas coached": "|".join(coached),
        "Key Coaching Topics": topics[:3] if topics else coached[:3],
    }


def main():
    s3 = boto3.client("s3", region_name=REGION)

    # List all input files
    print(f"Reading from s3://{S3_BUCKET}/{INPUT_PREFIX}")
    all_files = []
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=S3_BUCKET, Prefix=INPUT_PREFIX):
        for obj in page.get("Contents", []):
            if obj["Key"].endswith(".json"):
                all_files.append(obj["Key"])

    print(f"Found {len(all_files)} FCR files")

    # Group by TAS
    tas_groups = defaultdict(list)
    for key in all_files:
        parsed = parse_filename(key)
        if not parsed:
            print(f"  Skipping (can't parse): {key}")
            continue
        tas_groups[parsed["tas"]].append({"key": key, **parsed})

    print(f"Grouped into {len(tas_groups)} TAS reps")

    # Process each TAS
    for tas_name, files in tas_groups.items():
        files.sort(key=lambda x: x["date"])
        abl_name = files[0]["abl"]
        print(f"\n{'='*60}")
        print(f"Processing: {tas_name} (ABL: {abl_name}, {len(files)} FCRs)")

        session_memory = []
        past_fcrs_raw = []

        for i, f in enumerate(files):
            print(f"  [{i+1}/{len(files)}] {f['key']} ({f['month']})")

            # Read FCR from S3
            resp = s3.get_object(Bucket=S3_BUCKET, Key=f["key"])
            fcr_data = json.loads(resp["Body"].read())

            # Run pattern mining
            try:
                pattern_result = run_pattern_mining(
                    fcr_data=fcr_data,
                    tas_name=tas_name,
                    abl_name=abl_name,
                    fcr_date=f["date"].strftime("%B %d, %Y"),
                    past_fcrs=past_fcrs_raw,
                )
                print(f"    ✓ Strengths: {pattern_result.get('strengths', [])}")
                print(f"    ✓ Areas: {pattern_result.get('areas_of_improvement', [])}")
            except Exception as e:
                print(f"    ✗ LLM failed: {e}")
                # Fallback: use competency scores directly
                scores = fcr_data.get("competencies", {}).get("scores", {})
                pattern_result = {
                    "fcr_summary": "",
                    "strengths": list(scores.keys())[:3],
                    "areas_of_improvement": [],
                    "areas_coached": list(scores.keys()),
                    "key_coaching_topics": list(scores.keys())[:3],
                }

            # Build session entry
            session = build_session_entry(pattern_result, f["date"], f["month"])
            session_memory.append(session)

            # Add to past context for next iteration
            past_fcrs_raw.append({
                "date": f["date"].strftime("%Y-%m"),
                "observations": fcr_data.get("observations", {}),
                "competencies": fcr_data.get("competencies", {}),
                "smart_action_steps": fcr_data.get("smart_action_steps", []),
            })

        # Build profile
        profile = {
            "TAS_NAME": tas_name,
            "ABL_NAME": abl_name,
            "Territory": "",
            "SESSION_MEMORY": session_memory,
        }

        # Write to S3
        output_key = f"{OUTPUT_PREFIX}{tas_name}.json"
        s3.put_object(
            Bucket=S3_BUCKET,
            Key=output_key,
            Body=json.dumps(profile, indent=2, default=str),
            ContentType="application/json",
        )
        print(f"  → Wrote: s3://{S3_BUCKET}/{output_key}")

    print(f"\n{'='*60}")
    print(f"Done! Wrote {len(tas_groups)} profiles to s3://{S3_BUCKET}/{OUTPUT_PREFIX}")


if __name__ == "__main__":
    main()
