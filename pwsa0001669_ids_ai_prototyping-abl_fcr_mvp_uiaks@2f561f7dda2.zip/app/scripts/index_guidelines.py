"""
Script to index FCR guideline PDFs into OpenSearch vector store.

This script:
1. Reads guideline PDFs from the data/ directory
2. Chunks the content into semantic sections
3. Generates embeddings using Bedrock
4. Indexes into OpenSearch with appropriate metadata

Usage:
    python scripts/index_guidelines.py
"""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path
from typing import Any, Dict, List

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from services.bedrock_embeddings_service import BedrockEmbeddingsService
from services.opensearch_vector_store import OpenSearchVectorStore


def extract_text_from_pdf(pdf_path: Path) -> str:
    """
    Extract text from PDF file.

    Args:
        pdf_path: Path to PDF file

    Returns:
        Extracted text content
    """
    try:
        import PyPDF2

        with open(pdf_path, "rb") as file:
            reader = PyPDF2.PdfReader(file)
            text_parts = []

            for page in reader.pages:
                text_parts.append(page.extract_text())

            return "\n".join(text_parts)

    except Exception as exc:
        print(f"Failed to extract text from {pdf_path}: {exc}")
        return ""


def chunk_guideline_text(
    text: str,
    source_file: str,
    chunk_size: int = 1000,
    overlap: int = 200,
) -> List[Dict[str, Any]]:
    """
    Chunk guideline text into semantic sections.

    Args:
        text: The full guideline text
        source_file: Source filename
        chunk_size: Target size for each chunk (characters)
        overlap: Overlap between chunks

    Returns:
        List of chunks with metadata
    """
    chunks = []
    lines = text.split("\n")

    current_chunk = []
    current_size = 0
    chunk_index = 0

    for line in lines:
        line = line.strip()

        if not line:
            continue

        line_size = len(line)

        # Start new chunk if size exceeded
        if current_size + line_size > chunk_size and current_chunk:
            chunk_text = "\n".join(current_chunk)

            # Generate unique ID
            chunk_id = hashlib.md5(
                f"{source_file}_{chunk_index}".encode()
            ).hexdigest()

            chunks.append(
                {
                    "id": chunk_id,
                    "content": chunk_text,
                    "source": source_file,
                    "chunk_index": chunk_index,
                    "chunk_size": current_size,
                }
            )

            # Keep overlap
            overlap_lines = []
            overlap_size = 0

            for prev_line in reversed(current_chunk):
                if overlap_size + len(prev_line) < overlap:
                    overlap_lines.insert(0, prev_line)
                    overlap_size += len(prev_line)
                else:
                    break

            current_chunk = overlap_lines
            current_size = overlap_size
            chunk_index += 1

        current_chunk.append(line)
        current_size += line_size

    # Add final chunk
    if current_chunk:
        chunk_text = "\n".join(current_chunk)
        chunk_id = hashlib.md5(f"{source_file}_{chunk_index}".encode()).hexdigest()

        chunks.append(
            {
                "id": chunk_id,
                "content": chunk_text,
                "source": source_file,
                "chunk_index": chunk_index,
                "chunk_size": current_size,
            }
        )

    return chunks


def classify_document_type(filename: str) -> str:
    """
    Classify document type based on filename.

    Returns:
        Document type (guideline, rubric, example, coaching_framework)
    """
    filename_lower = filename.lower()

    if "rubric" in filename_lower or "evaluation" in filename_lower:
        return "rubric"
    elif "example" in filename_lower or "good" in filename_lower:
        return "example"
    elif "coaching" in filename_lower and "guide" in filename_lower:
        return "coaching_framework"
    elif "writing" in filename_lower or "guideline" in filename_lower:
        return "guideline"
    else:
        return "guideline"


def index_guideline_pdfs(data_dir: Path) -> None:
    """
    Index all guideline PDFs in the data directory.

    Args:
        data_dir: Path to directory containing PDF files
    """
    print("Initializing services...")
    embeddings_service = BedrockEmbeddingsService()
    vector_store = OpenSearchVectorStore()

    print("Creating OpenSearch index if not exists...")
    vector_store.create_index_if_not_exists(dimension=1024)

    pdf_files = list(data_dir.glob("*.pdf"))

    if not pdf_files:
        print(f"No PDF files found in {data_dir}")
        return

    print(f"Found {len(pdf_files)} PDF files to index")

    all_documents = []

    for pdf_path in pdf_files:
        print(f"\nProcessing: {pdf_path.name}")

        # Extract text
        text = extract_text_from_pdf(pdf_path)

        if not text or len(text) < 100:
            print(f"  ⚠️  Skipping - insufficient text extracted")
            continue

        print(f"  ✓ Extracted {len(text)} characters")

        # Classify document type
        doc_type = classify_document_type(pdf_path.name)
        print(f"  ✓ Classified as: {doc_type}")

        # Chunk text
        chunks = chunk_guideline_text(
            text=text,
            source_file=pdf_path.name,
            chunk_size=1000,
            overlap=200,
        )

        print(f"  ✓ Created {len(chunks)} chunks")

        # Generate embeddings for chunks
        print(f"  ⏳ Generating embeddings...")
        chunk_texts = [chunk["content"] for chunk in chunks]

        try:
            embeddings = embeddings_service.generate_embeddings_batch(chunk_texts)
            print(f"  ✓ Generated {len(embeddings)} embeddings")

            # Prepare documents for indexing
            for chunk, embedding in zip(chunks, embeddings):
                all_documents.append(
                    {
                        "id": chunk["id"],
                        "content": chunk["content"],
                        "embedding": embedding,
                        "document_type": doc_type,
                        "source": chunk["source"],
                        "section": None,
                        "metadata": {
                            "chunk_index": chunk["chunk_index"],
                            "chunk_size": chunk["chunk_size"],
                        },
                    }
                )

        except Exception as exc:
            print(f"  ✗ Failed to generate embeddings: {exc}")
            continue

    if not all_documents:
        print("\nNo documents to index")
        return

    # Bulk index all documents
    print(f"\n⏳ Indexing {len(all_documents)} documents into OpenSearch...")

    try:
        vector_store.bulk_index_documents(all_documents)
        print(f"✓ Successfully indexed {len(all_documents)} documents")

    except Exception as exc:
        print(f"✗ Indexing failed: {exc}")


def main() -> None:
    """Main entry point."""
    data_dir = Path(__file__).parent.parent / "data"

    if not data_dir.exists():
        print(f"Data directory not found: {data_dir}")
        sys.exit(1)

    print(f"Indexing guidelines from: {data_dir}\n")
    index_guideline_pdfs(data_dir)
    print("\n✅ Indexing complete!")


if __name__ == "__main__":
    main()
