"""
Example demonstrating the complete question flow.

This shows how the question_planner_node and ask_user_node work together.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from graph.nodes.question_planner_node import question_planner_node
from graph.nodes.ask_user_node import ask_user_node, set_user_answers


def example_complete_flow():
    """
    Example 1: Complete flow with all information provided.
    No questions should be generated.
    """
    print("=" * 80)
    print("Example 1: Complete Information - No Questions Needed")
    print("=" * 80)

    state = {
        "tas_id": "TAS_12345",
        "tas_name": "John Smith",
        "abl_id": "ABL_67890",
        "month": "May 2026",
        "territory": "NY_METRO",
        "selected_competencies": ["Selling Skills", "Clinical Knowledge"],
        "tas_prework_text": "Prepared thoroughly for customer call with Dr. Martinez. Reviewed product materials and recent clinical studies on allergy treatments.",
        "abl_eval_text": "John demonstrated strong clinical knowledge during the call. Good rapport with the physician. Identified an opportunity to improve closing technique.",
        "observation_notes": "Field visit with Dr. Martinez at Metropolitan Clinic. TAS presented Allergy Solution X effectively, answered clinical questions well.",
        "observed_strengths": "Strong clinical knowledge, excellent rapport building, well-prepared with latest studies",
        "development_opportunities": "Could improve closing technique - hesitated when asking for commitment",
        "impact_statement": "Stronger closing would convert more discussions into prescriptions, directly impacting territory sales",
        "action_items": "Practice closing scenarios, review sales training module on commitment-getting, schedule role-play session next week",
        "seam_notes": "Set context: performance review. Explained: strong clinical skills observed. Asked: how he felt about the call. Mutually agreed: focus on closing skills.",
        "context_bundle": {
            "past_fcr_context": {"status": "success", "historical_fcr_count": 5},
            "kpi_context": {"status": "success"},
        },
    }

    # Run question planner
    result = question_planner_node(state)

    print(f"\nShould ask questions: {result['should_ask_questions']}")
    print(f"Questions needed: {len(result['questions_needed'])}")
    print(f"Gap analysis: {result['gap_analysis']['analysis_summary']}")
    print(f"\nStatus: ✅ Ready to draft FCR (no questions needed)\n")


def example_minimal_info_flow():
    """
    Example 2: Minimal information - Multiple questions needed.
    """
    print("=" * 80)
    print("Example 2: Minimal Information - Questions Required")
    print("=" * 80)

    state = {
        "tas_id": "TAS_45678",
        "tas_name": "Sarah Johnson",
        "abl_id": "ABL_99999",
        "month": "May 2026",
        "context_bundle": {},
    }

    # Run question planner
    result = question_planner_node(state)

    print(f"\nShould ask questions: {result['should_ask_questions']}")
    print(f"Questions needed: {len(result['questions_needed'])}")
    print(f"\nGap Analysis:")
    print(f"  Total gaps: {result['gap_analysis']['total_gaps_identified']}")
    print(f"  Critical: {result['gap_analysis']['critical_gaps']}")
    print(f"  Important: {result['gap_analysis']['important_gaps']}")
    print(f"  Helpful: {result['gap_analysis']['helpful_gaps']}")

    print(f"\n{'='*80}")
    print("Questions to Ask ABL:")
    print(f"{'='*80}")

    for i, question in enumerate(result["questions_needed"], start=1):
        print(f"\nQuestion {i}:")
        print(f"  Purpose: {question['purpose']}")
        print(f"  Question: {question['question']}")
        print(f"  Type: {question['expected_answer_type']}")
        if question.get("prompts"):
            print(f"  Prompts:")
            for prompt in question["prompts"]:
                print(f"    - {prompt}")

    # Update state with planner results
    state.update(result)

    # Run ask_user_node
    ask_result = ask_user_node(state)

    print(f"\n{'='*80}")
    print("Ask User Node Result:")
    print(f"{'='*80}")
    print(f"Status: {ask_result['ask_user_status']}")
    print(f"Awaiting input: {ask_result['awaiting_user_input']}")
    print(f"Questions to present: {len(ask_result['questions_to_ask'])}")

    # Simulate ABL providing answers
    print(f"\n{'='*80}")
    print("Simulating ABL Answers:")
    print(f"{'='*80}")

    user_answers = {
        "q1": "We had a field visit to see Dr. Thompson. Sarah presented our new allergy medication. She was well-prepared and showed good product knowledge, but I noticed she struggled with objection handling when the doctor raised cost concerns.",
        "q2": "Selling Skills, Objection Handling",
        "q3": "Sarah did an excellent job building rapport and presenting clinical data. She was confident and well-prepared. The doctor seemed engaged and asked good questions.",
    }

    # Set answers in state
    state = set_user_answers(state, user_answers)

    # Run ask_user_node again with answers
    enriched_result = ask_user_node(state)

    print(f"\nStatus: {enriched_result['ask_user_status']}")
    print(f"Awaiting input: {enriched_result['awaiting_user_input']}")

    if enriched_result.get("observation_notes"):
        print(f"\n✅ Observation notes captured:")
        print(f"   {enriched_result['observation_notes'][:100]}...")

    if enriched_result.get("selected_competencies"):
        print(f"\n✅ Competencies identified:")
        for comp in enriched_result["selected_competencies"]:
            print(f"   - {comp}")

    if enriched_result.get("observed_strengths"):
        print(f"\n✅ Strengths captured:")
        print(f"   {enriched_result['observed_strengths'][:100]}...")

    print(f"\n{'='*80}")
    print("Status: ✅ Ready to draft FCR (questions answered)")
    print(f"{'='*80}\n")


def example_partial_info_flow():
    """
    Example 3: Partial information - Some questions needed.
    """
    print("=" * 80)
    print("Example 3: Partial Information - Targeted Questions")
    print("=" * 80)

    state = {
        "tas_id": "TAS_11111",
        "tas_name": "Michael Chen",
        "abl_id": "ABL_22222",
        "month": "May 2026",
        "selected_competencies": ["Territory Management", "Customer Engagement"],
        "observation_notes": "Field visit with multiple customers. Michael showed good planning and time management. Noticed some opportunities for improvement in customer engagement techniques.",
        "tas_prework_text": "Michael prepared customer profiles and visit objectives for each call.",
        "context_bundle": {
            "past_fcr_context": {"status": "success", "historical_fcr_count": 3},
        },
    }

    # Run question planner
    result = question_planner_node(state)

    print(f"\nShould ask questions: {result['should_ask_questions']}")
    print(f"Questions needed: {len(result['questions_needed'])}")

    print(f"\n{'='*80}")
    print("Targeted Questions (to complete picture):")
    print(f"{'='*80}")

    for i, question in enumerate(result["questions_needed"], start=1):
        print(f"\nQuestion {i}:")
        print(f"  {question['question']}")
        print(f"  → Purpose: {question['purpose']}")

    print(f"\n{'='*80}")
    print("Note: Only asking for missing critical elements")
    print(f"{'='*80}\n")


def example_ai_vs_template_questions():
    """
    Example 4: Compare AI-generated vs template-based questions.
    """
    print("=" * 80)
    print("Example 4: AI vs Template Question Generation")
    print("=" * 80)

    state = {
        "tas_id": "TAS_77777",
        "tas_name": "Emily Rodriguez",
        "month": "May 2026",
        "observation_notes": "Field visit observed. Emily showed creativity in her approach.",
    }

    print("\n--- Template-Based Questions ---")
    state["use_ai_question_generation"] = False
    result_template = question_planner_node(state)

    for i, q in enumerate(result_template["questions_needed"], start=1):
        print(f"{i}. {q['question'][:80]}...")

    print("\n--- AI-Generated Questions (if Bedrock available) ---")
    state["use_ai_question_generation"] = True
    result_ai = question_planner_node(state)

    for i, q in enumerate(result_ai["questions_needed"], start=1):
        print(f"{i}. {q['question'][:80]}...")

    print("\nNote: AI questions are more contextual and adaptive\n")


def main():
    """Run all examples."""
    print("\n" + "=" * 80)
    print("ABL COACHING AGENT - QUESTION FLOW EXAMPLES")
    print("=" * 80 + "\n")

    example_complete_flow()
    print("\n" * 2)

    example_minimal_info_flow()
    print("\n" * 2)

    example_partial_info_flow()
    print("\n" * 2)

    example_ai_vs_template_questions()

    print("\n" + "=" * 80)
    print("All examples completed!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()
