# FlowDesk - Project & Task Tracker

A modern project tracking application built to replace Excel-based workflows.

## Tech Stack

- **Backend**: Python / FastAPI / SQLAlchemy
- **Database**: PostgreSQL (RDS-compatible)
- **Frontend**: HTML / CSS / JavaScript (no frameworks)
- **Theme**: Dark theme with gradient UI, switchable to light

## Project Structure

```
FlowDesk/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── config.py
│   │   ├── database.py
│   │   ├── main.py
│   │   ├── models.py
│   │   ├── schemas.py
│   │   └── routes/
│   │       ├── __init__.py
│   │       ├── tasks.py
│   │       ├── users.py
│   │       ├── notifications.py
│   │       └── reports.py
│   ├── migrations/
│   │   ├── 001_create_users.sql
│   │   ├── 002_create_tasks.sql
│   │   ├── 003_create_milestones.sql
│   │   ├── 004_create_progress_comments.sql
│   │   ├── 005_create_task_dependencies.sql
│   │   ├── 006_create_notifications.sql
│   │   └── 007_create_migrations_history.sql
│   ├── run_migrations.py
│   ├── seed_data.py
│   ├── requirements.txt
│   └── .env
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── api.js
│       └── app.js
└── README.md
```

## Setup Instructions

### Prerequisites

- Python 3.9+
- PostgreSQL (local or RDS)
- A browser (Chrome, Firefox, Edge)

### Step 1: Set up PostgreSQL Database

```sql
CREATE DATABASE flowdesk;
```

### Step 2: Configure Backend

```bash
cd backend

# Create virtual environment
python -m venv venv
venv\Scripts\activate      # Windows
# source venv/bin/activate  # Linux/Mac

# Install dependencies
pip install -r requirements.txt

# Edit .env with your database credentials (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
```

### Step 3: Run Database Migrations

```bash
cd backend
python run_migrations.py
```

### Step 4: Seed Data from Excel (Optional)

Place your `Prototyping Active Tasks.xlsx` in the `backend/` folder, then:

```bash
cd backend
python seed_data.py
```

### Step 5: Start the API Server

```bash
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

API docs available at: http://localhost:8000/docs

### Step 6: Open the Frontend

Open `frontend/index.html` in your browser. You can use:

- **VS Code Live Server** (recommended - port 5500)
- **Python HTTP server**: `cd frontend && python -m http.server 5500`
- Or just open the file directly in browser

### Step 7: Verify

1. Open http://localhost:8000/docs - you should see Swagger UI
2. Open the frontend - you should see the dashboard
3. Create a test task using the "+ New Task" button

## Features

- Dashboard with task cards and progress bars
- Kanban board with drag-and-drop
- Task CRUD (Create, Read, Update, Delete)
- Milestone tracking (up to 5 per task)
- Weekly progress comments
- Auto-calculated fields (days remaining, completion %, overdue flags)
- Dark/Light theme toggle
- Search and filter (by status, type, PoC)
- CSV export
- Summary reports

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/tasks | List all tasks (with filters) |
| POST | /api/tasks | Create task |
| GET | /api/tasks/{id} | Get single task |
| PUT | /api/tasks/{id} | Update task |
| DELETE | /api/tasks/{id} | Delete task |
| POST | /api/tasks/{id}/comments | Add progress comment |
| GET | /api/tasks/{id}/comments | Get comments |
| POST | /api/tasks/{id}/milestones | Add milestone |
| PUT | /api/tasks/{id}/milestones/{num} | Update milestone |
| GET | /api/tasks/export/csv | Export CSV |
| GET | /api/reports/summary | Summary report |
| GET | /api/notifications | Get notifications |
| POST | /api/notifications/generate | Generate alerts |
| GET | /api/users | List users |
| POST | /api/users | Create user |
