# Word Document Export Setup

## Changes Made

### 1. Backend Changes
- **requirements.txt**: Added `python-docx==1.1.2` library
- **weekly_reports.py**: Added new endpoint `/api/weekly-reports/export-docx` with executive summary format

### 2. Frontend Changes
- **index.html**: Added "📄 Download Word Doc" button
- **summary.js**: Added Word document download functionality

## Installation Steps

### Step 1: Install New Python Package
```bash
cd backend
pip install python-docx==1.1.2
# OR reinstall all requirements
pip install -r requirements.txt
```

### Step 2: Restart the Backend Server
```bash
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Step 3: Test the Feature
1. Open the frontend in your browser
2. Navigate to "Weekly Summary" tab
3. Click "🤖 Generate Summary" - This will:
   - Generate AI summary with AWS Bedrock
   - Display on screen
   - Automatically download the Word document
4. Or click "📄 Download Word Doc" to download without regenerating

## Document Format

The generated Word document matches your existing template format:

**Filename:** `Weekly_Tracker_WE_v5_10_July_2026.docx`

### Document Structure (Based on Your Template):

#### 1. **Title Header**
- Blue header table: "AI&I Prototyping Team Weekly Status Update"

#### 2. **Project Info Table**
- Project Name: US AI&I Prototyping Team
- Week: WE 10 July 2026 (Jul 06 - Jul 10)
- Scrum Master / Owner: Srilatha / Mohan
- Team: AI&I Prototyping Team

#### 3. **Executive Summary**
- Overview paragraph with key statistics
- Total items, completion rate, items in progress

#### 4. **Dashboard Section**

##### Visual Insights - Metrics Table:
| 📊 34 | ✅ 26% | 🔄 25 | ⚠️ 6 | ⏸ 20 |
|-------|---------|--------|---------|---------|
| Total Items | Completion Rate | Active Items | Overdue Milestones | No Updates |

#### 5. **Health Status Summary**
- 🟢 On Track: X items  |  🟡 In Progress: Y items  |  🔴 Needs Attention: Z items
- Note explaining the categories

#### 6. **Weekly Highlights & Accomplishments**
Table with top 3 accomplishments:
- Accomplishment | Owner | Impact

#### 7. **Progress Overview**
Detailed table with ALL tasks:
- Work Item | Owner | Health (🟢🟡🔴) | Current Week Comment (AI-generated)

#### 8. **⚠️ Items Needing Attention**
Table showing:
- Tasks with overdue milestones
- Not started items
- Work Item | Owner | Reason

#### 9. **Risks & Mitigation**
Intelligent risk analysis table:
- Risk/Issue | Severity | Impact | Mitigation Action
- Auto-detects risks:
  - Multiple overdue milestones (High/Medium severity)
  - Tasks with no updates (Medium severity)
  - Not started tasks (Low/Medium severity)
  - Low completion rate (Medium severity)
- Color-coded severity: 🔴 High (red), 🟡 Medium (yellow), 🟢 Low (green)

#### 10. **Next Week Plan**
Actionable next steps table:
- Next Step | Owner
- Auto-generates from:
  - Upcoming milestones (within 2 weeks)
  - Overdue items needing attention
  - Not-started tasks to kickoff
- Priority indicators: 🔴 Overdue, 🟡 Due this week, 🟢 Due next week
- Limited to top 10 most urgent items

#### 11. **Footer**
- Source: FlowDesk Weekly Report Job
- Generated timestamp

### Formatting Features:
- ✅ Blue/white color scheme matching your template
- ✅ Professional tables with styled headers
- ✅ Emoji indicators (🟢🟡🔴📊✅⚠️)
- ✅ Executive summary style
- ✅ Proper spacing and margins
- ✅ AI-generated progress comments integrated

## API Endpoint

**GET** `/api/weekly-reports/export-docx`

**Query Parameters:**
- `week_ending` (optional): Date in YYYY-MM-DD format. If not provided, uses current week.

**Example:**
```
GET /api/weekly-reports/export-docx?week_ending=2026-07-10
```

**Response:**
- Content-Type: `application/vnd.openxmlformats-officedocument.wordprocessingml.document`
- Downloads .docx file with name: `Weekly_Tracker_WE_v5_{DD}_{Month}_{YYYY}.docx`

## What Gets Generated

### Statistics Calculated:
- Total tracked items
- Completion rate (%)
- Items by status (Completed, In-Progress, Not Started)
- Overdue milestones count
- Tasks with no updates this week

### AI Integration:
- Uses AWS Bedrock (Claude 3 Haiku) generated comments
- Falls back to raw comments if LLM not available
- Includes milestone information
- Shows health status per task

### Tables Included:
1. **Title table** - Team name header
2. **Project info table** - Week, owners, team
3. **Metrics table** - Visual KPIs
4. **Highlights table** - Top 3 accomplishments
5. **Progress overview table** - All tasks with status
6. **Attention items table** - Issues needing focus

## Troubleshooting

### If download doesn't work:
1. Check browser console for errors (F12)
2. Verify backend is running: `http://localhost:8000/api/health`
3. Check that `python-docx` is installed: `pip show python-docx`
4. Verify the API endpoint is accessible: `http://localhost:8000/docs`

### If Word document is blank or missing data:
1. Ensure you have tasks in the database
2. Run the seed data script if needed: `python seed_data.py`
3. Generate weekly reports first: Click "🤖 Generate Summary"
4. Check database has tasks: `SELECT COUNT(*) FROM tasks;`

### If formatting looks wrong:
- Open the .docx file in **Microsoft Word** (recommended)
- LibreOffice Writer also works well
- Google Docs may not render all formatting (especially emojis and colors)

### If emojis don't show:
- Some older Word versions may not display emojis correctly
- The document will still be readable, just without emoji indicators
- Consider updating to Office 2016 or newer

### If tables are misaligned:
- This is usually a Word version issue
- Try opening in Word Online or Word 2019+
- The python-docx library generates Office Open XML format which works best with modern Word versions
