# 🚀 Deployment Guide - Word Export Feature

## Pre-Deployment Checklist

### ✅ Files Modified:
- [x] `backend/requirements.txt` - Added python-docx
- [x] `backend/app/routes/weekly_reports.py` - Added export-docx endpoint
- [x] `frontend/index.html` - Added download button
- [x] `frontend/js/summary.js` - Added download logic

### ✅ New Dependencies:
- `python-docx==1.1.2`

---

## 🧪 Step 1: Local Testing (Recommended First)

### 1.1 Install Dependencies
```bash
cd backend
pip install python-docx==1.1.2

# Or reinstall all
pip install -r requirements.txt
```

### 1.2 Restart Backend Server
```bash
# From backend directory
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 1.3 Test the Feature
1. Open browser: `http://localhost:5500` (or your frontend port)
2. Navigate to **"Weekly Summary"** tab
3. Click **"🤖 Generate Summary"**
   - Should see: "⏳ Generating summary with AI and creating Word document..."
   - Document should download automatically
4. Check Downloads folder for: `Weekly_Tracker_WE_v5_10_July_2026.docx`
5. Open the Word document and verify:
   - ✅ All 11 sections present
   - ✅ Tables formatted correctly
   - ✅ Emojis display (🟢🟡🔴)
   - ✅ Colors and styling match template
6. Test **"📄 Download Word Doc"** button (standalone download)
7. Test **"📋 Copy to Clipboard"** button (still works)

### 1.4 Verify API Endpoint
```bash
# Check Swagger docs
Open: http://localhost:8000/docs

# Look for new endpoint:
GET /api/weekly-reports/export-docx

# Test it directly:
curl -O -J "http://localhost:8000/api/weekly-reports/export-docx"
```

---

## 🐳 Step 2: Docker Deployment

### 2.1 Verify Dockerfile
Your existing Dockerfile should work as-is since we updated `requirements.txt`:

```bash
# Check Dockerfile includes requirements.txt
cat Dockerfile | grep requirements.txt
# Should see: COPY backend/requirements.txt /app/backend/requirements.txt
# Should see: RUN pip install --no-cache-dir -r /app/backend/requirements.txt
```

### 2.2 Build Docker Image
```bash
# From project root (where Dockerfile is)
docker build -t flowdesk:latest .

# Or with specific tag
docker build -t flowdesk:word-export-v1 .
```

### 2.3 Test Docker Image Locally
```bash
# Run container
docker run -d \
  --name flowdesk-test \
  -p 8200:8200 \
  -e DB_HOST=your_db_host \
  -e DB_USER=your_db_user \
  -e DB_PASSWORD=your_db_password \
  -e DB_NAME=flowdesk \
  -e AWS_REGION=us-east-1 \
  -e BEDROCK_MODEL_ID=anthropic.claude-3-haiku-20240307-v1:0 \
  flowdesk:latest

# Check logs
docker logs -f flowdesk-test

# Test the application
# Open: http://localhost:8200
# Navigate to Weekly Summary and test download
```

### 2.4 Stop Test Container
```bash
docker stop flowdesk-test
docker rm flowdesk-test
```

---

## ☁️ Step 3: Production Deployment

### Option A: AWS ECS/Fargate

#### 3.1 Push to ECR
```bash
# Login to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ECR_URL

# Tag image
docker tag flowdesk:latest YOUR_ECR_URL/flowdesk:latest
docker tag flowdesk:latest YOUR_ECR_URL/flowdesk:word-export-v1

# Push
docker push YOUR_ECR_URL/flowdesk:latest
docker push YOUR_ECR_URL/flowdesk:word-export-v1
```

#### 3.2 Update ECS Task Definition
```bash
# Update task definition with new image
aws ecs register-task-definition \
  --cli-input-json file://task-definition.json

# Update service to use new task definition
aws ecs update-service \
  --cluster your-cluster \
  --service flowdesk-service \
  --task-definition flowdesk:LATEST
```

### Option B: Kubernetes

#### 3.3 Update Kubernetes Deployment
```bash
# Update image in deployment
kubectl set image deployment/flowdesk \
  flowdesk=YOUR_ECR_URL/flowdesk:word-export-v1

# Or apply updated deployment YAML
kubectl apply -f deployment.yaml

# Watch rollout
kubectl rollout status deployment/flowdesk

# Check pods
kubectl get pods -l app=flowdesk
```

### Option C: VM/Server Direct Deployment

#### 3.4 Deploy to Server
```bash
# SSH to server
ssh user@your-server

# Navigate to project
cd /path/to/flowdesk

# Pull latest code (if using git)
git pull origin main

# Activate virtual environment
source venv/bin/activate  # Linux/Mac
# OR
venv\Scripts\activate     # Windows

# Install new dependency
pip install python-docx==1.1.2

# Restart service
# Option 1: systemd
sudo systemctl restart flowdesk

# Option 2: supervisor
sudo supervisorctl restart flowdesk

# Option 3: manual restart
pkill -f "uvicorn app.main:app"
nohup uvicorn app.main:app --host 0.0.0.0 --port 8200 &
```

---

## 🔍 Step 4: Post-Deployment Verification

### 4.1 Health Check
```bash
# Check application is running
curl http://your-domain/api/health

# Should return: {"status":"healthy"}
```

### 4.2 Test Word Export Endpoint
```bash
# Test direct API call
curl -O -J "http://your-domain/api/weekly-reports/export-docx"

# Should download: Weekly_Tracker_WE_v5_DD_Month_YYYY.docx
```

### 4.3 Test Frontend
1. Open: `http://your-domain` (or `http://your-domain/flowdesk` if using reverse proxy)
2. Login (if authentication enabled)
3. Navigate to **Weekly Summary** tab
4. Select week from dropdown
5. Click **"🤖 Generate Summary"**
6. Verify document downloads
7. Open document and check all sections

### 4.4 Check Logs
```bash
# Docker
docker logs flowdesk-container

# Kubernetes
kubectl logs -f deployment/flowdesk

# Server logs
tail -f /var/log/flowdesk/app.log

# Look for errors related to:
# - python-docx import
# - Document generation
# - File streaming
```

---

## 🐛 Troubleshooting

### Issue 1: "No module named 'docx'"
**Solution:**
```bash
pip install python-docx==1.1.2
# Restart server
```

### Issue 2: Document downloads but is corrupt
**Symptoms:** File won't open in Word
**Solution:**
- Check backend logs for errors
- Verify python-docx version: `pip show python-docx`
- Test locally first before deploying

### Issue 3: Document is blank/missing sections
**Solution:**
```bash
# Generate weekly reports first
curl -X POST "http://your-domain/api/weekly-reports/generate-now"

# Then try export again
curl -O -J "http://your-domain/api/weekly-reports/export-docx"
```

### Issue 4: Download button doesn't work
**Solution:**
- Check browser console (F12) for JavaScript errors
- Verify CORS is enabled in backend
- Check network tab for API call success
- Verify frontend files were updated

### Issue 5: Emojis don't display in Word
**Solution:**
- This is a Word version issue
- Emojis require Word 2016 or newer
- Document is still functional, just missing visual indicators

### Issue 6: Timeout on generation
**Solution:**
```bash
# Increase timeout in frontend
# Edit summary.js line ~78:
await fetchWithTimeout(`${API_BASE}/weekly-reports/generate-now${params}`, 
  { method: 'POST' }, 
  120000  # Increase from 60000 to 120000 (2 minutes)
);
```

### Issue 7: Database connection error
**Solution:**
- Verify DB_HOST, DB_USER, DB_PASSWORD environment variables
- Check database is accessible from container/server
- Verify RDS security group allows connections

---

## 📊 Monitoring

### Key Metrics to Monitor:
- API response time for `/export-docx` endpoint (should be < 5 seconds)
- Success rate of document generation (should be > 95%)
- Error logs for python-docx related issues
- Disk space (temp files for document generation)

### CloudWatch Alarms (if on AWS):
```bash
# API Gateway 5XX errors
# ECS task health checks
# Application logs with ERROR level
```

---

## 🔄 Rollback Plan

### If Issues Occur:

#### Quick Rollback (Docker):
```bash
# Revert to previous image
docker pull YOUR_ECR_URL/flowdesk:previous-tag
docker stop flowdesk-container
docker rm flowdesk-container
docker run -d --name flowdesk-container YOUR_ECR_URL/flowdesk:previous-tag
```

#### Quick Rollback (Kubernetes):
```bash
# Rollback deployment
kubectl rollout undo deployment/flowdesk
```

#### Code Rollback (Git):
```bash
git revert HEAD
git push origin main
# Redeploy
```

#### Feature Toggle (Quick Fix):
- Comment out the download button in `frontend/index.html` line 171
- Or remove the route from `weekly_reports.py` import

---

## ✅ Final Deployment Checklist

Before going to production:

- [ ] Tested locally with real data
- [ ] Verified all 11 sections appear in document
- [ ] Confirmed AI generation works (AWS Bedrock)
- [ ] Tested with different week selections
- [ ] Verified document opens in Microsoft Word
- [ ] Checked formatting matches template
- [ ] Tested on staging environment
- [ ] Updated environment variables (if needed)
- [ ] Documented in team wiki/confluence
- [ ] Notified stakeholders of new feature
- [ ] Created rollback plan
- [ ] Set up monitoring/alerts

---

## 📝 Deployment Commands Summary

```bash
# === LOCAL ===
cd backend
pip install python-docx==1.1.2
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# === DOCKER ===
docker build -t flowdesk:word-export-v1 .
docker run -d -p 8200:8200 --name flowdesk flowdesk:word-export-v1

# === AWS ECR + ECS ===
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ECR_URL
docker tag flowdesk:word-export-v1 YOUR_ECR_URL/flowdesk:latest
docker push YOUR_ECR_URL/flowdesk:latest
aws ecs update-service --cluster your-cluster --service flowdesk-service --force-new-deployment

# === KUBERNETES ===
kubectl set image deployment/flowdesk flowdesk=YOUR_ECR_URL/flowdesk:word-export-v1
kubectl rollout status deployment/flowdesk
```

---

## 🎉 You're Ready to Deploy!

The feature is production-ready with:
- ✅ Complete template matching your format
- ✅ AI-powered content generation
- ✅ Intelligent risk detection
- ✅ Auto-generated next steps
- ✅ Professional Word document output
- ✅ Proper error handling
- ✅ Backward compatible (won't break existing features)

**Good luck with your deployment!** 🚀
