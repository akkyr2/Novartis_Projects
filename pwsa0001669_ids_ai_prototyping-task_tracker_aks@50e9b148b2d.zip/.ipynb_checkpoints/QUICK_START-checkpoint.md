# ⚡ Quick Start - Word Export Feature

## 🎯 What Changed?

**New Feature:** Download weekly status report as professionally formatted Word document (.docx)

**Filename:** `Weekly_Tracker_WE_v5_DD_Month_YYYY.docx` (e.g., `Weekly_Tracker_WE_v5_10_July_2026.docx`)

---

## 🚀 Deploy in 3 Steps

### Step 1: Install Dependency
```bash
cd backend
pip install python-docx==1.1.2
```

### Step 2: Restart Backend
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Step 3: Test
1. Open frontend → "Weekly Summary" tab
2. Click "🤖 Generate Summary"
3. Word document downloads automatically!

---

## 📋 Files Changed

| File | Change |
|------|--------|
| `backend/requirements.txt` | Added `python-docx==1.1.2` |
| `backend/app/routes/weekly_reports.py` | Added `/export-docx` endpoint |
| `frontend/index.html` | Added "📄 Download Word Doc" button |
| `frontend/js/summary.js` | Added download logic |

---

## 🎨 Document Sections (11 Total)

1. ✅ Title Header
2. ✅ Project Info
3. ✅ Executive Summary
4. ✅ Dashboard / Visual Insights
5. ✅ Health Status Summary
6. ✅ Weekly Highlights
7. ✅ Progress Overview
8. ✅ Items Needing Attention
9. ✅ **Risks & Mitigation** ⚠️
10. ✅ **Next Week Plan** 📅
11. ✅ Footer

---

## 🔧 Quick Commands

### Local Testing
```bash
# Install
pip install python-docx==1.1.2

# Run
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Docker
```bash
# Build
docker build -t flowdesk:latest .

# Run
docker run -d -p 8200:8200 flowdesk:latest
```

### Test API
```bash
# Direct download
curl -O -J "http://localhost:8000/api/weekly-reports/export-docx"
```

---

## ✨ Features

- 🤖 **AI-powered**: Uses AWS Bedrock (Claude 3 Haiku) for content
- 📊 **Auto-statistics**: Calculates completion rate, overdue count, etc.
- ⚠️ **Smart risks**: Detects risks automatically with severity levels
- 📅 **Next steps**: Auto-generates action items from milestones
- 🎨 **Professional**: Color-coded tables, emojis, blue headers
- 📄 **Format matching**: Identical to your existing template

---

## 🐛 Common Issues

| Issue | Solution |
|-------|----------|
| "No module named 'docx'" | `pip install python-docx==1.1.2` |
| Document won't open | Check backend logs, verify python-docx installed |
| Blank document | Run POST `/weekly-reports/generate-now` first |
| Button doesn't work | Check browser console (F12), verify CORS enabled |

---

## 📞 Support

- **Logs Location**: Check backend logs for errors
- **API Docs**: http://localhost:8000/docs
- **Test Endpoint**: GET `/api/weekly-reports/export-docx`

---

## ✅ Ready!

You're all set to deploy! The feature is:
- Backward compatible (won't break existing functionality)
- Production-ready
- Fully tested

**Just install the dependency and restart!** 🎉
