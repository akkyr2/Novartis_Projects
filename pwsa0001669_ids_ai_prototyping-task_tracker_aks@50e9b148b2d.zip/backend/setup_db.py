"""
FlowDesk - Database Setup Script
Creates the 'flowdesk' database, all tables, and inserts seed data.
Run this ONCE on SageMaker to set up everything.

Usage: python setup_db.py

NOTE: Set DB_SECRET in .env before running.
"""
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import os
from dotenv import load_dotenv

load_dotenv()

DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_USER = os.getenv("DB_USER")
DB_SECRET = os.getenv("DB_SECRET")
DB_NAME = os.getenv("DB_NAME", "flowdesk")


def create_database():
    """Connect to default 'postgres' DB and create 'flowdesk' database."""
    print(f"Connecting to {DB_HOST}:{DB_PORT} as {DB_USER}...")
    
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname="postgres",
        user=DB_USER,
        password=DB_SECRET
    )
    conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
    cursor = conn.cursor()

    # Check if database exists
    cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (DB_NAME,))
    exists = cursor.fetchone()

    if exists:
        print(f"✅ Database '{DB_NAME}' already exists")
    else:
        cursor.execute(f'CREATE DATABASE "{DB_NAME}"')
        print(f"✅ Database '{DB_NAME}' created successfully")

    cursor.close()
    conn.close()


def create_tables():
    """Connect to 'flowdesk' DB and create all tables."""
    print(f"\nConnecting to database '{DB_NAME}'...")
    
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_SECRET
    )
    conn.autocommit = False
    cursor = conn.cursor()

    print("Creating tables...")

    # Read and execute setup_database.sql
    sql_file = os.path.join(os.path.dirname(__file__), "setup_database.sql")
    
    with open(sql_file, "r") as f:
        sql = f.read()

    try:
        cursor.execute(sql)
        conn.commit()
        print("✅ All tables created and data inserted successfully")
    except Exception as e:
        conn.rollback()
        print(f"❌ Error: {e}")
        # Try to identify if it's a duplicate key issue (tables already have data)
        if "duplicate key" in str(e) or "already exists" in str(e):
            print("ℹ️  Tables/data may already exist. Trying without seed data...")
            conn.close()
            create_tables_only()
            return
        raise
    finally:
        cursor.close()
        conn.close()


def create_tables_only():
    """Create tables without inserting data (for re-runs)."""
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_SECRET
    )
    cursor = conn.cursor()

    tables_sql = """
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(100) UNIQUE NOT NULL,
        full_name VARCHAR(200) NOT NULL,
        role VARCHAR(20) DEFAULT 'member',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS tasks (
        id SERIAL PRIMARY KEY,
        name VARCHAR(300) NOT NULL,
        type VARCHAR(50) NOT NULL,
        poc_id INTEGER REFERENCES users(id),
        poc_name VARCHAR(200),
        description TEXT,
        comment TEXT,
        status VARCHAR(20) DEFAULT 'Not Started',
        completion_date DATE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE
    );

    CREATE TABLE IF NOT EXISTS milestones (
        id SERIAL PRIMARY KEY,
        task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
        milestone_number INTEGER NOT NULL,
        target_date DATE,
        description TEXT,
        is_completed BOOLEAN DEFAULT FALSE,
        UNIQUE (task_id, milestone_number)
    );

    CREATE TABLE IF NOT EXISTS progress_comments (
        id SERIAL PRIMARY KEY,
        task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
        comment_text TEXT NOT NULL,
        submitted_by VARCHAR(200),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS task_dependencies (
        id SERIAL PRIMARY KEY,
        predecessor_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
        successor_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
        UNIQUE (predecessor_id, successor_id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
        task_name VARCHAR(300) NOT NULL,
        milestone_description TEXT,
        milestone_date DATE,
        notification_type VARCHAR(20) NOT NULL,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS activity_log (
        id SERIAL PRIMARY KEY,
        task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
        field_changed VARCHAR(100) NOT NULL,
        old_value TEXT,
        new_value TEXT,
        changed_by VARCHAR(200),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS weekly_reports (
        id SERIAL PRIMARY KEY,
        task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
        week_ending DATE NOT NULL,
        generated_comment TEXT NOT NULL,
        raw_input TEXT,
        generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        UNIQUE (task_id, week_ending)
    );

    CREATE TABLE IF NOT EXISTS migrations_history (
        id SERIAL PRIMARY KEY,
        filename VARCHAR(255) NOT NULL UNIQUE,
        applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
    """

    try:
        cursor.execute(tables_sql)
        conn.commit()
        print("✅ Tables created (without seed data)")
    except Exception as e:
        conn.rollback()
        print(f"❌ Error creating tables: {e}")
    finally:
        cursor.close()
        conn.close()


def verify_setup():
    """Verify database has data."""
    print("\nVerifying setup...")
    
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_SECRET
    )
    cursor = conn.cursor()

    checks = [
        ("tasks", "SELECT count(*) FROM tasks"),
        ("milestones", "SELECT count(*) FROM milestones"),
        ("progress_comments", "SELECT count(*) FROM progress_comments"),
        ("users", "SELECT count(*) FROM users"),
    ]

    for table, query in checks:
        try:
            cursor.execute(query)
            count = cursor.fetchone()[0]
            print(f"  {table}: {count} rows")
        except Exception as e:
            print(f"  {table}: ❌ Error - {e}")
            conn.rollback()

    cursor.close()
    conn.close()
    print("\n✅ Setup verification complete")


if __name__ == "__main__":
    print("=" * 50)
    print("FlowDesk Database Setup")
    print("=" * 50)
    
    create_database()
    create_tables()
    verify_setup()
    
    print("\n" + "=" * 50)
    print("DONE! You can now start the API:")
    print("  cd FlowDesk/backend")
    print("  uvicorn app.main:app --host 0.0.0.0 --port 8000")
    print("=" * 50)
