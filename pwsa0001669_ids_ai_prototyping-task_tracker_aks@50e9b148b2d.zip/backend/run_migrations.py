"""
FlowDesk Migration Runner
Executes SQL migration scripts in order against PostgreSQL.
Usage: python run_migrations.py
"""
import os
import sys
import psycopg2
from dotenv import load_dotenv

load_dotenv()

# Import from config to reuse the same DB connection settings
from app.config import DATABASE_URL


def parse_db_url(url):
    """Parse database URL into connection parameters."""
    url = url.replace("postgresql://", "")
    user_cred, host_db = url.split("@")
    user, secret = user_cred.split(":")
    host_port, dbname = host_db.split("/")
    if ":" in host_port:
        host, port = host_port.split(":")
    else:
        host = host_port
        port = "5432"
    return {
        "host": host,
        "port": int(port),
        "user": user,
        "password": secret,
        "dbname": dbname
    }


def run_migrations():
    """Run all pending migrations in order."""
    params = parse_db_url(DATABASE_URL)
    conn = psycopg2.connect(**params)
    conn.autocommit = False
    cursor = conn.cursor()

    # Create migrations_history table if not exists
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS migrations_history (
            id SERIAL PRIMARY KEY,
            filename VARCHAR(255) NOT NULL UNIQUE,
            applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
    """)
    conn.commit()

    # Get already applied migrations
    cursor.execute("SELECT filename FROM migrations_history")
    applied = {row[0] for row in cursor.fetchall()}

    # Get migration files
    migrations_dir = os.path.join(os.path.dirname(__file__), "migrations")
    migration_files = sorted([
        f for f in os.listdir(migrations_dir)
        if f.endswith(".sql")
    ])

    applied_count = 0
    for filename in migration_files:
        if filename in applied:
            print(f"  SKIP: {filename} (already applied)")
            continue

        filepath = os.path.join(migrations_dir, filename)
        print(f"  APPLYING: {filename}...")

        try:
            with open(filepath, "r") as f:
                sql = f.read()
            cursor.execute(sql)
            cursor.execute(
                "INSERT INTO migrations_history (filename) VALUES (%s)",
                (filename,)
            )
            conn.commit()
            print(f"  SUCCESS: {filename}")
            applied_count += 1
        except Exception as e:
            conn.rollback()
            print(f"  FAILED: {filename}")
            print(f"  Error: {e}")
            sys.exit(1)

    cursor.close()
    conn.close()
    print(f"\nMigration complete. Applied {applied_count} new migration(s).")


if __name__ == "__main__":
    print("FlowDesk Migration Runner")
    print("=" * 40)
    run_migrations()
