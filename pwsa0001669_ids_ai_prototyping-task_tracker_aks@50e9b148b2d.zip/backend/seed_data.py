"""
FlowDesk Seed Script
Reads the Excel file and populates the database with initial data.
Usage: python seed_data.py
"""
import os
import sys
from datetime import datetime
from dotenv import load_dotenv
from openpyxl import load_workbook
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

load_dotenv()

# Import DATABASE_URL from config (reads from .env)
from app.config import DATABASE_URL

engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)

# Path to Excel file (adjust as needed)
EXCEL_PATH = os.getenv("EXCEL_PATH", "Prototyping Active Tasks.xlsx")


def parse_date(value):
    """Try to parse various date formats from Excel."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, str):
        value = value.strip()
        for fmt in ["%Y-%m-%d", "%m/%d/%y", "%m/%d/%Y", "%d-%m-%Y", "%d/%m/%Y"]:
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue
    return None


def seed_database():
    """Read Excel and insert tasks into database."""
    if not os.path.exists(EXCEL_PATH):
        print(f"ERROR: Excel file not found at: {EXCEL_PATH}")
        print("Set EXCEL_PATH environment variable or place the file in the backend directory.")
        sys.exit(1)

    session = Session()

    # Check if data already exists
    result = session.execute(text("SELECT COUNT(*) FROM tasks"))
    count = result.scalar()
    if count > 0:
        response = input(f"Database already has {count} tasks. Continue and add more? (y/n): ")
        if response.lower() != "y":
            print("Seed cancelled.")
            session.close()
            return

    # Load Excel
    wb = load_workbook(EXCEL_PATH, data_only=True)
    ws = wb.active

    # Find header row (row 1 based on the Excel structure)
    # Columns: B=Tasks, C=Type, D=PoC, E=Task Description, F=Comment, G=Status,
    #          H=Milestone1, I=Milestone2, J=Milestone3, K=Milestone4, L=Milestone5,
    #          M=Milestone Description, N=Completion Date, O=Upcoming Milestone,
    #          P=Number of Days, Q=Progress Comment

    imported = 0
    skipped = 0

    for row_idx, row in enumerate(ws.iter_rows(min_row=3, values_only=True), start=3):
        # Skip empty rows or rows without task name
        # Column B (index 1) = Task name
        if len(row) < 2 or not row[1]:
            skipped += 1
            continue

        task_name = str(row[1]).strip()
        if not task_name:
            skipped += 1
            continue

        task_type = str(row[2]).strip() if row[2] else "Others"
        poc_name = str(row[3]).strip() if row[3] else None
        description = str(row[4]).strip() if row[4] else None
        comment = str(row[5]).strip() if row[5] else None
        status = str(row[6]).strip() if row[6] else "Not Started"

        # Normalize status
        status_map = {
            "in-progress": "In-Progress",
            "in progress": "In-Progress",
            "completed": "Completed",
            "done": "Completed",
            "not started": "Not Started",
        }
        status = status_map.get(status.lower(), status)
        if status not in ["Not Started", "In-Progress", "Completed"]:
            status = "In-Progress"

        # Normalize type
        type_map = {
            "project": "Project",
            "access request": "Access Request",
            "tech spike": "Tech Spike",
            "documentation": "Documentation",
            "documenation": "Documentation",
            "others": "Others",
            "`": "Others",
        }
        task_type = type_map.get(task_type.lower(), task_type)
        if task_type not in ["Project", "Access Request", "Tech Spike", "Documentation", "Others"]:
            task_type = "Others"

        # Milestones (columns H-L, indices 7-11)
        milestone_dates = []
        for i in range(7, 12):
            if i < len(row):
                milestone_dates.append(parse_date(row[i]))
            else:
                milestone_dates.append(None)

        # Milestone descriptions (column M, index 12)
        milestone_desc_raw = str(row[12]).strip() if len(row) > 12 and row[12] else ""
        milestone_descs = [d.strip() for d in milestone_desc_raw.split("\n") if d.strip()] if milestone_desc_raw else []

        # Completion date (column N, index 13)
        completion_date = parse_date(row[13]) if len(row) > 13 else None

        # Progress comment (column Q, index 16 - last column)
        progress_comment = str(row[16]).strip() if len(row) > 16 and row[16] else None

        # Insert task
        session.execute(text("""
            INSERT INTO tasks (name, type, poc_name, description, comment, status, completion_date)
            VALUES (:name, :type, :poc_name, :description, :comment, :status, :completion_date)
        """), {
            "name": task_name,
            "type": task_type,
            "poc_name": poc_name,
            "description": description,
            "comment": comment,
            "status": status,
            "completion_date": completion_date
        })

        # Get the task ID
        result = session.execute(text("SELECT currval(pg_get_serial_sequence('tasks', 'id'))"))
        task_id = result.scalar()

        # Insert milestones
        for ms_num, ms_date in enumerate(milestone_dates, 1):
            if ms_date:
                ms_desc = milestone_descs[ms_num - 1] if ms_num - 1 < len(milestone_descs) else None
                session.execute(text("""
                    INSERT INTO milestones (task_id, milestone_number, target_date, description)
                    VALUES (:task_id, :ms_num, :target_date, :description)
                """), {
                    "task_id": task_id,
                    "ms_num": ms_num,
                    "target_date": ms_date,
                    "description": ms_desc
                })

        # Insert progress comment
        if progress_comment:
            session.execute(text("""
                INSERT INTO progress_comments (task_id, comment_text, submitted_by)
                VALUES (:task_id, :comment_text, :submitted_by)
            """), {
                "task_id": task_id,
                "comment_text": progress_comment,
                "submitted_by": poc_name
            })

        imported += 1

    session.commit()
    session.close()

    print(f"\nSeed complete!")
    print(f"  Imported: {imported} tasks")
    print(f"  Skipped: {skipped} rows (missing task name)")


if __name__ == "__main__":
    print("FlowDesk Data Seed Script")
    print("=" * 40)
    seed_database()
