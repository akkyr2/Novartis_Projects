"""
Standalone test: generates a Weekly_Report docx with fake data.
No DB / AWS needed.
Run from backend folder:
    python test_docx_local.py
"""
import io, os, sys, tempfile
from datetime import date, timedelta, datetime

# ── fake report_data ─────────────────────────────────────────────────────────
fake_report_data = [
    {
        'task_name': 'DRA62 - Full Tagging & Dashboard',
        'owner': 'Satya / Mohan',
        'status': 'In-Progress',
        'generated_comment': 'Resource tags implemented across all DRA62 services. Cost tracking dashboard designed for June month data. Next: Deploy dashboard to production by 07-Aug.',
        'task_type': 'Development',
        'upcoming_milestone': 'MS3: Deploy dashboard (due 07-Aug-2026)',
    },
    {
        'task_name': 'Agentic Colleague V2 - Unified Codebase',
        'owner': 'Revath / Kiran',
        'status': 'In-Progress',
        'generated_comment': 'New V2 repo created, end-to-end tested, and Data Ingestion + Transcript pipelines merged into a single codebase. Project Onboarding UI built for manual pipeline triggers.',
        'task_type': 'Development',
        'upcoming_milestone': 'MS1: Lambda trigger (due 10-Aug-2026)',
    },
    {
        'task_name': 'NEO4J Knowledge Graph',
        'owner': 'Revath',
        'status': 'In-Progress',
        'generated_comment': 'Architecture flow diagram and project documentation completed. Handoff to Revath prepared; walkthrough with Somath scheduled.',
        'task_type': 'R&D',
        'upcoming_milestone': 'MS3: NL-to-Cypher model finalised (due 22-Jul-2026) (Overdue milestone)',
    },
    {
        'task_name': 'Langsmith - VoiceIQ Deployment',
        'owner': 'Akhilesh',
        'status': 'In-Progress',
        'generated_comment': 'Application deployed to new production environment. S3 integration permission issues resolved. Post-deployment testing underway.',
        'task_type': 'DevOps',
        'upcoming_milestone': 'Complete EKS deployment; integrate Strands + AgentCore',
    },
    {
        'task_name': 'TAS SMART Agent - User Onboarding',
        'owner': 'Elaniyah',
        'status': 'Completed',
        'generated_comment': 'All 12 required users onboarded to IDS_DEV environment for agent testing. Task completed.',
        'task_type': 'Onboarding',
        'upcoming_milestone': '',
    },
    {
        'task_name': 'DevOps Adhoc Tasks',
        'owner': 'Satya',
        'status': 'In-Progress',
        'generated_comment': 'Resolved Bedrock AgentCore issue for Revath, Kiro/Claude Code issues, Jira/Confluence issues for Manohar, and EC2 availability issues across onshore/offshore teams.',
        'task_type': 'DevOps',
        'upcoming_milestone': '',
    },
    {
        'task_name': 'Data Masking for Shyam',
        'owner': 'Jayaseelan',
        'status': 'On Hold',
        'generated_comment': 'Data replication from production to dev environment in progress. Awaiting completion of setup.',
        'task_type': 'Data',
        'upcoming_milestone': 'Complete data replication from prod to dev',
    },
    {
        'task_name': 'ABL Coaching Agent Demo Video',
        'owner': 'Unassigned',
        'status': 'Completed',
        'generated_comment': 'Use case completed. No new updates this week.',
        'task_type': 'Demo',
        'upcoming_milestone': '',
    },
    {
        'task_name': 'Agentic Colleague - Azure SSO',
        'owner': 'Kiran',
        'status': 'Not Started',
        'generated_comment': 'On hold till August – to be revisited for Azure SSO integration.',
        'task_type': 'Development',
        'upcoming_milestone': 'On hold till August',
    },
    {
        'task_name': 'Norstella Knowledge Graph',
        'owner': 'Manohar',
        'status': 'In-Progress',
        'generated_comment': 'Initial data pipeline built. Schema mapping under review. Next: Finalize NL-to-Cypher conversion model.',
        'task_type': 'R&D',
        'upcoming_milestone': 'MS2: Schema mapping complete (due 14-Aug-2026)',
    },
]

# ── Copy helper functions from weekly_reports.py ─────────────────────────────
# (We import them directly from the route module, bypassing FastAPI/DB)
sys.path.insert(0, os.path.dirname(__file__))

# Patch out DB/AWS imports so the module loads cleanly
import unittest.mock as mock
with mock.patch.dict('sys.modules', {
    'app.database': mock.MagicMock(),
    'app.models':   mock.MagicMock(),
    'app.schemas':  mock.MagicMock(),
    'app.config':   mock.MagicMock(DATABASE_URL='', CORS_ORIGINS=[]),
    'boto3':        mock.MagicMock(),
    'psycopg2':     mock.MagicMock(),
}):
    # Import only the helper functions we need
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches, Cm
    from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
    from docx.enum.table import WD_ALIGN_VERTICAL
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    from docx.oxml import parse_xml
    from docx.oxml.ns import nsdecls

# ── Paste the same helper functions ──────────────────────────────────────────
_DARK_BLUE  = "1F4E79"
_LIGHT_BLUE = "BDD7EE"
_GREEN_BG   = "2E7D32"
_AMBER_BG   = "F57F17"
_RED_BG     = "C62828"
_WHITE      = "FFFFFF"
_LIGHT_GRAY = "F2F2F2"

def _shd(cell, color_hex):
    elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}" w:val="clear"/>')
    cell._tc.get_or_add_tcPr().append(elm)

def _cell_margins(cell, top=50, bottom=50, left=80, right=80):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for side, val in [('top', top), ('bottom', bottom), ('start', left), ('end', right)]:
        node = OxmlElement(f'w:{side}')
        node.set(qn('w:w'), str(val)); node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def _table_borders(table, color="A6A6A6", size="4"):
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    borders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        el = OxmlElement(f'w:{edge}')
        el.set(qn('w:val'), 'single'); el.set(qn('w:sz'), size)
        el.set(qn('w:space'), '0');    el.set(qn('w:color'), color)
        borders.append(el)
    tblPr.append(borders)

def _remove_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    borders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        el = OxmlElement(f'w:{edge}')
        el.set(qn('w:val'), 'none'); el.set(qn('w:sz'), '0'); el.set(qn('w:space'), '0')
        borders.append(el)
    tblPr.append(borders)

def _cell_text(cell, text, bold=False, font_size=9, font_name="Calibri",
               font_color=None, alignment=None, v_align=WD_ALIGN_VERTICAL.CENTER):
    for p in cell.paragraphs:
        p._element.getparent().remove(p._element)
    para = cell.add_paragraph()
    para.space_before = Pt(0); para.space_after = Pt(0)
    para.paragraph_format.line_spacing = 1.15
    if alignment:
        para.alignment = alignment
    run = para.add_run(text)
    run.font.name = font_name; run.font.size = Pt(font_size); run.bold = bold
    if font_color:
        run.font.color.rgb = RGBColor.from_string(font_color)
    cell.vertical_alignment = v_align

def _tbl_width(table, width_cm):
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    tblW = OxmlElement('w:tblW')
    tblW.set(qn('w:w'), str(int(width_cm * 567))); tblW.set(qn('w:type'), 'dxa')
    tblPr.append(tblW)

def _section_heading(doc, text):
    p = doc.add_paragraph(); p.space_before = Pt(12); p.space_after = Pt(6)
    run = p.add_run(text); run.font.name = "Calibri"; run.font.size = Pt(13)
    run.bold = True; run.font.color.rgb = RGBColor.from_string(_DARK_BLUE)

def _health(status):
    s = (status or "").lower().strip()
    if any(x in s for x in ('completed', 'done')):
        return "Completed", _GREEN_BG
    elif any(x in s for x in ('blocked', 'on hold', 'not started')):
        return "Needs Attention", _RED_BG
    else:
        return "In Progress", _AMBER_BG

# ── Build the doc ─────────────────────────────────────────────────────────────
def build_docx(report_data, week_start, week_end, output_path):
    today = date.today()
    week_str = f"WE {week_end.strftime('%d %B %Y')} ({week_start.strftime('%b %d')} - {week_end.strftime('%b %d')})"

    total      = len(report_data)
    completed  = sum(1 for r in report_data if 'completed' in r['status'].lower())
    in_progress= sum(1 for r in report_data if 'in-progress' in r['status'].lower() or r['status'].lower()=='started')
    not_started= sum(1 for r in report_data if 'not started' in r['status'].lower())
    green_count= sum(1 for r in report_data if _health(r['status'])[0]=='Completed')
    amber_count= sum(1 for r in report_data if _health(r['status'])[0]=='In Progress')
    red_count  = sum(1 for r in report_data if _health(r['status'])[0]=='Needs Attention')
    no_update  = sum(1 for r in report_data if 'no updates this week' in r['generated_comment'].lower())
    active_count = total - completed

    doc = Document()
    style = doc.styles['Normal']
    style.font.name = 'Calibri'; style.font.size = Pt(10)
    style.paragraph_format.space_after = Pt(0); style.paragraph_format.space_before = Pt(0)

    for section in doc.sections:
        section.top_margin = Cm(2.0); section.bottom_margin = Cm(2.0)
        section.left_margin = Cm(1.27); section.right_margin = Cm(1.27)

        # Header
        header = section.header; header.is_linked_to_previous = False
        h_para = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        h_para.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT; h_para.space_after = Pt(0)
        h_run = h_para.add_run("AI&I Prototyping Team  |  Weekly Status Update")
        h_run.font.name = "Calibri"; h_run.font.size = Pt(8)
        h_run.font.color.rgb = RGBColor.from_string(_DARK_BLUE); h_run.bold = True
        h_para.add_run("\t\t")
        h_date = h_para.add_run(f"WE {week_end.strftime('%d %B %Y')}")
        h_date.font.name = "Calibri"; h_date.font.size = Pt(8)
        h_date.font.color.rgb = RGBColor.from_string("808080")
        h_border = OxmlElement('w:pBdr'); h_bottom = OxmlElement('w:bottom')
        h_bottom.set(qn('w:val'), 'single'); h_bottom.set(qn('w:sz'), '4')
        h_bottom.set(qn('w:space'), '4'); h_bottom.set(qn('w:color'), _DARK_BLUE)
        h_border.append(h_bottom); h_para._element.get_or_add_pPr().append(h_border)

        # Footer
        footer = section.footer; footer.is_linked_to_previous = False
        f_para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        f_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER; f_para.space_before = Pt(4)
        f_border = OxmlElement('w:pBdr'); f_top = OxmlElement('w:top')
        f_top.set(qn('w:val'), 'single'); f_top.set(qn('w:sz'), '4')
        f_top.set(qn('w:space'), '4'); f_top.set(qn('w:color'), 'CCCCCC')
        f_border.append(f_top); f_para._element.get_or_add_pPr().append(f_border)
        f_left = f_para.add_run("Confidential  |  AI&I Prototyping Team")
        f_left.font.name = "Calibri"; f_left.font.size = Pt(7)
        f_left.font.color.rgb = RGBColor.from_string("808080")

    # TITLE BANNER
    ttbl = doc.add_table(rows=1, cols=1); _remove_borders(ttbl)
    tc = ttbl.rows[0].cells[0]; _shd(tc, _DARK_BLUE); _cell_margins(tc, top=120, bottom=120)
    _cell_text(tc, "AI&I Prototyping Team Weekly Status Update",
               bold=True, font_size=16, font_color=_WHITE,
               alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # PROJECT INFO
    info = doc.add_table(rows=2, cols=4); _table_borders(info, color="BFC0C2", size="6"); _tbl_width(info, 18)
    for i, (h, v) in enumerate(zip(
        ['Project Name', 'Week', 'Scrum Master / Owner', 'Team'],
        ['US AI&I Prototyping Team', week_str, 'Srilatha / Mohan', 'AI&I Prototyping Team']
    )):
        _shd(info.rows[0].cells[i], _LIGHT_BLUE)
        _cell_margins(info.rows[0].cells[i], top=60, bottom=60)
        _cell_margins(info.rows[1].cells[i], top=60, bottom=60)
        _cell_text(info.rows[0].cells[i], h, bold=True, font_size=9)
        _cell_text(info.rows[1].cells[i], v, font_size=9)
    doc.add_paragraph()

    # EXECUTIVE SUMMARY
    _section_heading(doc, "Executive Summary")
    p = doc.add_paragraph()
    run = p.add_run(
        f"This week's report covers {total} tracked work items across the Prototyping Team. "
        f"{completed} tasks are completed, {in_progress} are actively in progress, "
        f"and {not_started} are not yet started."
    )
    run.font.name = "Calibri"; run.font.size = Pt(10)
    doc.add_paragraph()

    # KEY METRICS CARDS
    mtr = doc.add_table(rows=2, cols=5); _remove_borders(mtr); _tbl_width(mtr, 18)
    m_labels = ['Total Items', 'Completed', 'Active Items', 'Needs Attention', 'No Updates']
    m_values = [str(total), str(completed), str(active_count), str(red_count), str(no_update)]
    m_colors = [_DARK_BLUE, _GREEN_BG, _LIGHT_BLUE, _RED_BG, _AMBER_BG]
    m_icons  = ['[T]', '[C]', '[A]', '[!]', '[-]']
    for i in range(5):
        top = mtr.rows[0].cells[i]; bot = mtr.rows[1].cells[i]
        _shd(top, m_colors[i]); _shd(bot, m_colors[i])
        _cell_margins(top, top=60, bottom=20); _cell_margins(bot, top=20, bottom=60)
        fc = _WHITE if m_colors[i] in (_DARK_BLUE, _GREEN_BG, _RED_BG, _AMBER_BG) else None
        _cell_text(top, f"{m_icons[i]}  {m_values[i]}", bold=True, font_size=14,
                   font_color=fc, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        _cell_text(bot, m_labels[i], font_size=8, font_color=fc,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # KEY ACCOMPLISHMENTS
    _section_heading(doc, "Key Accomplishments This Week")
    highlighted = [r for r in report_data
                   if 'no updates this week' not in r['generated_comment'].lower()
                   and 'not started' not in r['status'].lower()][:8]
    acc_table = doc.add_table(rows=1 + len(highlighted), cols=2)
    _table_borders(acc_table, color="BFC0C2", size="6"); _tbl_width(acc_table, 18)
    for i, h in enumerate(['Accomplishment', 'Details']):
        cell = acc_table.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for idx, r in enumerate(highlighted, start=1):
        cells = acc_table.rows[idx].cells
        _shd(cells[0], "E2EFDA"); _cell_margins(cells[0], top=60, bottom=60, left=100, right=80)
        _cell_text(cells[0], r['task_name'], bold=True, font_size=9)
        _shd(cells[1], "F4FBF0"); _cell_margins(cells[1], top=60, bottom=60, left=100, right=100)
        _cell_text(cells[1], r['generated_comment'], font_size=9)
    for row in acc_table.rows:
        row.cells[0].width = Cm(5.0); row.cells[1].width = Cm(13.0)
    doc.add_paragraph()

    # HEALTH STATUS BAR
    hbar = doc.add_table(rows=1, cols=3); _remove_borders(hbar)
    for i, (txt, bg) in enumerate([
        (f"Completed: {green_count}", _GREEN_BG),
        (f"In Progress: {amber_count}", _AMBER_BG),
        (f"Needs Attention: {red_count}", _RED_BG),
    ]):
        cell = hbar.rows[0].cells[i]; _shd(cell, bg); _cell_margins(cell, top=80, bottom=80)
        _cell_text(cell, txt, bold=True, font_size=11, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # DASHBOARD
    _section_heading(doc, "Dashboard")
    dash = doc.add_table(rows=2, cols=5); _table_borders(dash, color="BFC0C2", size="6")
    for i, (h, v) in enumerate(zip(
        ['Tracked Items', 'Completed', 'In Progress', 'Not Started', 'Needs Attention'],
        [str(total), str(completed), str(in_progress), str(not_started), str(red_count)]
    )):
        _shd(dash.rows[0].cells[i], _LIGHT_BLUE)
        _cell_margins(dash.rows[0].cells[i], top=60, bottom=60)
        _cell_margins(dash.rows[1].cells[i], top=60, bottom=60)
        _cell_text(dash.rows[0].cells[i], h, bold=True, font_size=9,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        _cell_text(dash.rows[1].cells[i], v, font_size=10, bold=True,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # CHARTS
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from collections import Counter

        def _pie(data, tmp):
            sm = Counter(r['status'].strip() for r in data)
            labels, sizes = list(sm.keys()), list(sm.values())
            clrs = {'Completed':'#2E7D32','In-Progress':'#1565C0','Not Started':'#C62828','On Hold':'#F57F17','Blocked':'#C62828'}
            colors = [clrs.get(l, '#757575') for l in labels]
            fig, ax = plt.subplots(figsize=(4.5, 3.5))
            wedges, _, autos = ax.pie(sizes, labels=None, autopct='%1.0f%%', startangle=140,
                colors=colors, pctdistance=0.78, wedgeprops=dict(width=0.45, edgecolor='white', linewidth=2))
            for t in autos: t.set_fontsize(9); t.set_fontweight('bold'); t.set_color('white')
            ax.text(0, 0, f"{sum(sizes)}\nTotal", ha='center', va='center', fontsize=14, fontweight='bold', color='#1F4E79')
            ax.legend(wedges, [f"{l} ({s})" for l, s in zip(labels, sizes)], loc='center left', bbox_to_anchor=(1, 0.5), fontsize=8, frameon=False)
            ax.set_title('Task Status Distribution', fontsize=11, fontweight='bold', color='#1F4E79', pad=12)
            plt.tight_layout()
            p = os.path.join(tmp, 'pie.png'); fig.savefig(p, dpi=180, bbox_inches='tight', facecolor='white'); plt.close(fig)
            return p

        def _hbar(g, a, r, tmp):
            cats = ['On Track', 'In Progress', 'Needs Attention']; vals = [g, a, r]
            clrs = ['#2E7D32', '#F57F17', '#C62828']
            fig, ax = plt.subplots(figsize=(4.5, 2.2))
            bars = ax.barh(cats, vals, color=clrs, height=0.55, edgecolor='white', linewidth=1.5)
            for bar, val in zip(bars, vals):
                ax.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height()/2,
                        str(val), va='center', fontsize=11, fontweight='bold', color='#333333')
            ax.set_xlim(0, max(vals) + 3)
            ax.set_title('Health Status Distribution', fontsize=11, fontweight='bold', color='#1F4E79', pad=10)
            ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
            plt.tight_layout()
            p = os.path.join(tmp, 'hbar.png'); fig.savefig(p, dpi=180, bbox_inches='tight', facecolor='white'); plt.close(fig)
            return p

        def _owner(data, tmp):
            active = [r for r in data if 'completed' not in r['status'].lower()]
            oc = Counter()
            for r in active:
                for o in r['owner'].replace('/', ',').split(','):
                    oc[o.strip().split()[0]] += 1
            top = sorted(oc.items(), key=lambda x: x[1], reverse=True)[:10]
            if not top: return None
            names, counts = [x[0] for x in top], [x[1] for x in top]
            fig, ax = plt.subplots(figsize=(5, 3))
            bclrs = ['#1F4E79' if i == 0 else '#4A90D9' for i in range(len(names))]
            ax.bar(names, counts, color=bclrs, width=0.6, edgecolor='white')
            for bar, val in zip(ax.patches, counts):
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.15, str(val), ha='center', fontsize=9, fontweight='bold', color='#333333')
            ax.set_title('Active Workload by Owner', fontsize=11, fontweight='bold', color='#1F4E79', pad=12)
            ax.set_ylabel('Active Items', fontsize=9); ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
            ax.tick_params(axis='x', rotation=30, labelsize=8); ax.set_ylim(0, max(counts) + 2)
            plt.tight_layout()
            p = os.path.join(tmp, 'owner.png'); fig.savefig(p, dpi=180, bbox_inches='tight', facecolor='white'); plt.close(fig)
            return p

        _section_heading(doc, "Visual Insights")
        tmp_dir = tempfile.mkdtemp()
        try:
            pie_p  = _pie(report_data, tmp_dir)
            hbar_p = _hbar(green_count, amber_count, red_count, tmp_dir)
            own_p  = _owner(report_data, tmp_dir)
            ct1 = doc.add_table(rows=1, cols=2); _remove_borders(ct1); _tbl_width(ct1, 18)
            ct1.rows[0].cells[0].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            ct1.rows[0].cells[0].paragraphs[0].add_run().add_picture(pie_p, width=Inches(3.3))
            ct1.rows[0].cells[1].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            ct1.rows[0].cells[1].paragraphs[0].add_run().add_picture(hbar_p, width=Inches(3.3))
            doc.add_paragraph()
            if own_p:
                ct2 = doc.add_table(rows=1, cols=1); _remove_borders(ct2)
                ct2.rows[0].cells[0].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                ct2.rows[0].cells[0].paragraphs[0].add_run().add_picture(own_p, width=Inches(3.3))
                doc.add_paragraph()
        finally:
            for f in os.listdir(tmp_dir):
                try: os.remove(os.path.join(tmp_dir, f))
                except: pass
            try: os.rmdir(tmp_dir)
            except: pass
        print("  [OK] Charts generated")
    except ImportError:
        print("  [SKIP] matplotlib not installed - skipping charts")

    # PROGRESS OVERVIEW
    _section_heading(doc, "Progress Overview")
    prog = doc.add_table(rows=1 + len(report_data), cols=5)
    _table_borders(prog, color="BFC0C2", size="6"); _tbl_width(prog, 18)
    for i, h in enumerate(['Work Item', 'Owner', 'Health', 'Current Week Comment', 'Next Milestone Details']):
        cell = prog.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=80, right=80)
        _cell_text(cell, h, bold=True, font_size=8, font_color=_WHITE, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for ri, item in enumerate(report_data, start=1):
        ht, hbg = _health(item['status'])
        row_bg = _LIGHT_GRAY if ri % 2 == 0 else None
        cells = prog.rows[ri].cells
        _cell_margins(cells[0], top=50, bottom=50, left=80, right=60)
        _cell_text(cells[0], item['task_name'], bold=True, font_size=8)
        if row_bg: _shd(cells[0], row_bg)
        _cell_margins(cells[1], top=50, bottom=50, left=60, right=60)
        _cell_text(cells[1], item['owner'], font_size=8)
        if row_bg: _shd(cells[1], row_bg)
        _cell_margins(cells[2], top=50, bottom=50, left=40, right=40)
        _shd(cells[2], hbg)
        _cell_text(cells[2], ht, bold=True, font_size=7, font_color=_WHITE, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        _cell_margins(cells[3], top=50, bottom=50, left=80, right=80)
        _cell_text(cells[3], item['generated_comment'], font_size=8)
        if row_bg: _shd(cells[3], row_bg)
        _cell_margins(cells[4], top=50, bottom=50, left=60, right=60)
        _cell_text(cells[4], item.get('upcoming_milestone', '-'), font_size=8)
        if row_bg: _shd(cells[4], row_bg)
    col_widths = [Cm(3.5), Cm(2.4), Cm(2.0), Cm(7.1), Cm(3.0)]
    for row in prog.rows:
        for i, w in enumerate(col_widths): row.cells[i].width = w
    doc.add_paragraph()

    # ITEMS NEEDING ATTENTION
    attn_items = [r for r in report_data
                  if 'overdue' in r['generated_comment'].lower()
                  or r['status'].lower() in ('blocked', 'on hold', 'not started')
                  or 'unassigned' in r['owner'].lower()]
    if attn_items:
        _section_heading(doc, "Items Needing Attention")
        at = doc.add_table(rows=1, cols=3)
        _table_borders(at, color="BFC0C2", size="6"); _tbl_width(at, 18)
        for i, h in enumerate(['Work Item', 'Owner', 'Reason']):
            cell = at.rows[0].cells[i]; _shd(cell, "C62828")
            _cell_margins(cell, top=70, bottom=70, left=100, right=100)
            _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        for r in attn_items:
            reasons = []
            if r['status'].lower() in ('blocked', 'on hold', 'not started'): reasons.append(f"Status: {r['status']}")
            if 'overdue' in r['generated_comment'].lower(): reasons.append("Has overdue milestones")
            if 'unassigned' in r['owner'].lower(): reasons.append("No owner assigned")
            row = at.add_row()
            for ci in range(3): _cell_margins(row.cells[ci], top=50, bottom=50, left=100, right=80)
            _cell_text(row.cells[0], r['task_name'], bold=True, font_size=9)
            _cell_text(row.cells[1], r['owner'], font_size=9)
            _shd(row.cells[2], "FCE4D6")
            _cell_text(row.cells[2], "; ".join(reasons), font_size=9)
        doc.add_paragraph()

    # WEEKLY HIGHLIGHTS
    _section_heading(doc, "Weekly Highlights")
    highlights = [r for r in report_data
                  if 'no updates this week' not in r['generated_comment'].lower()
                  and 'not started' not in r['status'].lower()][:6]
    hl = doc.add_table(rows=1, cols=2)
    _table_borders(hl, color="BFC0C2", size="6"); _tbl_width(hl, 18)
    for i, h in enumerate(['Work Item', 'Progress Summary']):
        cell = hl.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for r in highlights:
        row = hl.add_row()
        _cell_margins(row.cells[0], top=50, bottom=50, left=100, right=80)
        _cell_margins(row.cells[1], top=50, bottom=50, left=100, right=80)
        _cell_text(row.cells[0], r['task_name'], bold=True, font_size=9)
        _cell_text(row.cells[1], r['generated_comment'], font_size=9)
    doc.add_paragraph()

    # RISKS & MITIGATION
    _section_heading(doc, "Risks & Mitigation")
    risk_items = []
    for r in report_data:
        if 'overdue' in r['generated_comment'].lower():
            risk_items.append((r['task_name'], "Milestone overdue", "Escalate to owner; re-baseline timeline"))
        elif r['status'].lower() in ('blocked', 'on hold'):
            risk_items.append((r['task_name'], f"Status: {r['status']}", "Review blockers; identify alternate path"))
    if not risk_items:
        risk_items.append(("-", "No critical risks this week", "Continue monitoring"))
    rsk = doc.add_table(rows=1, cols=3)
    _table_borders(rsk, color="BFC0C2", size="6"); _tbl_width(rsk, 18)
    for i, h in enumerate(['Work Item', 'Risk', 'Mitigation']):
        cell = rsk.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for task_name, risk, mitigation in risk_items:
        row = rsk.add_row()
        for ci in range(3): _cell_margins(row.cells[ci], top=50, bottom=50, left=100, right=80)
        _cell_text(row.cells[0], task_name, bold=True, font_size=9)
        _shd(row.cells[1], _RED_BG)
        _cell_text(row.cells[1], risk, font_size=9, font_color=_WHITE)
        _cell_text(row.cells[2], mitigation, font_size=9)
    doc.add_paragraph()

    # NEXT WEEK PLAN
    _section_heading(doc, "Next Week Plan")
    next_items = []
    for r in report_data:
        if 'next:' in r['generated_comment'].lower():
            next_txt = r['generated_comment'].split('Next:')[-1].strip()
            next_items.append((r['task_name'], next_txt))
        elif 'in-progress' in r['status'].lower():
            next_items.append((r['task_name'], "Continue development"))
    next_items = next_items[:8]
    if not next_items:
        next_items.append(("-", "Continue active work items"))
    nw = doc.add_table(rows=1, cols=2)
    _table_borders(nw, color="BFC0C2", size="6"); _tbl_width(nw, 18)
    for i, h in enumerate(['Work Item', 'Planned Activity']):
        cell = nw.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for task_name, plan in next_items:
        row = nw.add_row()
        _cell_margins(row.cells[0], top=50, bottom=50, left=100, right=80)
        _cell_margins(row.cells[1], top=50, bottom=50, left=100, right=80)
        _cell_text(row.cells[0], task_name, bold=True, font_size=9)
        _cell_text(row.cells[1], plan, font_size=9)
    doc.add_paragraph()

    # HEALTH SUMMARY
    _section_heading(doc, "Health Status Summary")
    p = doc.add_paragraph()
    run = p.add_run(f"On Track: {green_count}  |  In Progress: {amber_count}  |  Needs Attention: {red_count}")
    run.font.name = "Calibri"; run.font.size = Pt(10)
    p2 = doc.add_paragraph()
    note = p2.add_run("Note: On Track = completed/progressing well  |  In Progress = actively being worked  |  Needs Attention = blocked, on hold, or not started")
    note.font.name = "Calibri"; note.font.size = Pt(8)
    note.font.color.rgb = RGBColor.from_string("808080"); note.italic = True
    doc.add_paragraph()

    # FOOTER NOTE
    p = doc.add_paragraph(); p.space_before = Pt(12)
    run = p.add_run(f"Source: FlowDesk | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    run.font.name = "Calibri"; run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string("808080")

    doc.save(output_path)


# ── MAIN ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    today = date.today()
    # Use last Friday as week_end
    week_end   = today - timedelta(days=(today.weekday() - 4) % 7)
    week_start = week_end - timedelta(days=4)

    output_path = os.path.join(
        os.path.expanduser("~"), "Downloads",
        f"Weekly_Report_WE_{week_end.strftime('%d_%B_%Y')}.docx"
    )

    print(f"\n{'='*55}")
    print(f"  AI&I Prototyping Team - Weekly Report (TEST)")
    print(f"  Week ending : {week_end.strftime('%d %B %Y')}")
    print(f"  Tasks       : {len(fake_report_data)}")
    print(f"{'='*55}")

    build_docx(fake_report_data, week_start, week_end, output_path)

    print(f"\n  [OK] Document saved to:\n  {output_path}\n")
    # Auto-open the file
    os.startfile(output_path)
