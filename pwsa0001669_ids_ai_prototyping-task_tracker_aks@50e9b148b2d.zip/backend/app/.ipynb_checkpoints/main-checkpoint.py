from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.config import CORS_ORIGINS
from app.database import engine, Base
from app.routes import tasks, users, notifications, reports, weekly_reports, upload
import os

# Create tables only if DB is connected
if engine:
    Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="FlowDesk API",
    description="Project and Task Tracking API",
    version="1.0.0",
    root_path=os.getenv("APP_ROOT_PATH", "")
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(tasks.router, prefix="/api/tasks", tags=["Tasks"])
app.include_router(users.router, prefix="/api/users", tags=["Users"])
app.include_router(notifications.router, prefix="/api/notifications", tags=["Notifications"])
app.include_router(reports.router, prefix="/api/reports", tags=["Reports"])
app.include_router(weekly_reports.router, prefix="/api/weekly-reports", tags=["Weekly Reports"])
app.include_router(upload.router, prefix="/api/upload", tags=["Upload"])


@app.get("/api/health")
def health_check():
    return {"status": "healthy"}


# Serve frontend static files (must be AFTER API routes)
frontend_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "frontend")
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
