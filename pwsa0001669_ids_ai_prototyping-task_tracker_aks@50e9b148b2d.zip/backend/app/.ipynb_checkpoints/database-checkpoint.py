from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.config import DATABASE_URL

Base = declarative_base()

# Try to create engine — if DB is not available, app still runs (demo mode)
engine = None
SessionLocal = None

if DATABASE_URL:
    try:
        engine = create_engine(DATABASE_URL, pool_pre_ping=True)
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        # Quick connection test
        with engine.connect() as conn:
            conn.execute(__import__('sqlalchemy').text("SELECT 1"))
        print("✅ Database connected successfully")
    except Exception as e:
        print(f"⚠️  Database connection failed: {e}")
        print("   App will run in demo mode (no live data)")
        engine = None
        SessionLocal = None
else:
    print("⚠️  No DATABASE_URL configured. App will run in demo mode.")


def get_db():
    if SessionLocal is None:
        # No DB available — return None, API endpoints should handle gracefully
        yield None
        return
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
