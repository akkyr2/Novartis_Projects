import os
import json
from urllib.parse import quote_plus
from dotenv import load_dotenv
import boto3

load_dotenv()


def _get_db_credentials_from_secrets_manager() -> dict:
    """
    Fetch DB username and password from AWS Secrets Manager.
    Returns dict with 'username' and 'password' keys.
    Falls back to .env values if Secrets Manager call fails.
    """
    secret_id = os.getenv("DB_SECRET_ID", "rds!db-98b26fd7-567b-4362-85e7-49d3d971a065")
    region = os.getenv("AWS_REGION", "us-east-1")

    try:
        client = boto3.client("secretsmanager", region_name=region)
        response = client.get_secret_value(SecretId=secret_id)
        secret = json.loads(response["SecretString"])
        print("✅ DB credentials fetched from Secrets Manager")
        return secret
    except Exception as e:
        print(f"⚠️  Secrets Manager fetch failed: {e}")
        print("   Falling back to .env credentials")
        return {
            "username": os.getenv("DB_USER", ""),
            "password": os.getenv("DB_SECRET", ""),
        }


# Fetch DB credentials from Secrets Manager
_db_creds = _get_db_credentials_from_secrets_manager()

# Database configuration
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_USER = _db_creds.get("username", "")
DB_SECRET = _db_creds.get("password", "")
DB_NAME = os.getenv("DB_NAME", "flowdesk")

# Build SQLAlchemy connection URL
_db_scheme = "postgresql"
if DB_HOST and DB_USER:
    _encoded = quote_plus(DB_SECRET or "")
    DATABASE_URL = f"{_db_scheme}://{DB_USER}:{_encoded}@{DB_HOST}:{DB_PORT}/{DB_NAME}?sslmode=require"
else:
    DATABASE_URL = ""

# CORS
_cors_raw = os.getenv("CORS_ORIGINS", "*")
if "*" in _cors_raw:
    CORS_ORIGINS = ["*"]
else:
    CORS_ORIGINS = [origin.strip() for origin in _cors_raw.split(",") if origin.strip()]
