"""
FlowDesk Weekly Reports API
Endpoints for retrieving and managing LLM-generated weekly progress comments.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import distinct
from typing import Optional, List
from datetime import date, datetime
from pydantic import BaseModel
import csv
import io
from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from lxml import etree
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls
import tempfile, os, collections

# ── Colour palette (matches Formatting/generate_from_excel.py) ──────────────
_DARK_BLUE  = "1F4E79"
_LIGHT_BLUE = "BDD7EE"
_GREEN_BG   = "2E7D32"
_AMBER_BG   = "F57F17"
_RED_BG     = "C62828"
_WHITE      = "FFFFFF"
_LIGHT_GRAY = "F2F2F2"

# ── Shared docx helper functions ─────────────────────────────────────────────
def _shd(cell, color_hex):
    elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}" w:val="clear"/>')
    cell._tc.get_or_add_tcPr().append(elm)

def _cell_margins(cell, top=50, bottom=50, left=80, right=80):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for side, val in [('top', top), ('bottom', bottom), ('start', left), ('end', right)]:
        node = OxmlElement(f'w:{side}')
        node.set(qn('w:w'), str(val)); node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def _table_borders(table, color="A6A6A6", size="4"):
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    borders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        el = OxmlElement(f'w:{edge}')
        el.set(qn('w:val'), 'single'); el.set(qn('w:sz'), size)
        el.set(qn('w:space'), '0');    el.set(qn('w:color'), color)
        borders.append(el)
    tblPr.append(borders)

def _remove_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    borders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        el = OxmlElement(f'w:{edge}')
        el.set(qn('w:val'), 'none'); el.set(qn('w:sz'), '0'); el.set(qn('w:space'), '0')
        borders.append(el)
    tblPr.append(borders)

def _cell_text(cell, text, bold=False, font_size=9, font_name="Calibri",
               font_color=None, alignment=None, v_align=WD_ALIGN_VERTICAL.CENTER):
    for p in cell.paragraphs:
        p._element.getparent().remove(p._element)
    para = cell.add_paragraph()
    para.space_before = Pt(0); para.space_after = Pt(0)
    para.paragraph_format.line_spacing = 1.15
    if alignment:
        para.alignment = alignment
    run = para.add_run(text)
    run.font.name = font_name; run.font.size = Pt(font_size); run.bold = bold
    if font_color:
        run.font.color.rgb = RGBColor.from_string(font_color)
    cell.vertical_alignment = v_align

def _tbl_width(table, width_cm):
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    tblW = OxmlElement('w:tblW')
    tblW.set(qn('w:w'), str(int(width_cm * 567))); tblW.set(qn('w:type'), 'dxa')
    tblPr.append(tblW)

def _section_heading(doc, text):
    p = doc.add_paragraph(); p.space_before = Pt(12); p.space_after = Pt(6)
    run = p.add_run(text); run.font.name = "Calibri"; run.font.size = Pt(13)
    run.bold = True; run.font.color.rgb = RGBColor.from_string(_DARK_BLUE)

def _health(status):
    s = (status or "").lower().strip()
    if any(x in s for x in ('completed', 'done')):
        return "✔ Completed", _GREEN_BG
    elif any(x in s for x in ('blocked', 'on hold', 'not started')):
        return "🔴 Needs Attention", _RED_BG
    else:
        return "🟠 In Progress", _AMBER_BG

from app.database import get_db
from app.models import Task, WeeklyReport, Milestone

router = APIRouter()


class WeeklyReportResponse(BaseModel):
    task_id: int
    task_name: str
    week_ending: date
    generated_comment: str
    generated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


@router.get("/weeks")
def get_available_weeks(db: Session = Depends(get_db)):
    """Get list of all weeks that have generated reports."""
    weeks = db.query(distinct(WeeklyReport.week_ending)).order_by(
        WeeklyReport.week_ending.desc()
    ).all()
    return [{"week_ending": w[0].isoformat()} for w in weeks]


@router.get("/by-week")
def get_reports_by_week(week_ending: date, db: Session = Depends(get_db)):
    """Get all generated comments for a specific week."""
    reports = db.query(WeeklyReport).filter(
        WeeklyReport.week_ending == week_ending
    ).all()

    result = []
    for r in reports:
        task = db.query(Task).filter(Task.id == r.task_id).first()
        result.append({
            "task_id": r.task_id,
            "task_name": task.name if task else "Unknown",
            "poc_name": task.poc_name if task else "",
            "type": task.type if task else "",
            "status": task.status if task else "",
            "week_ending": r.week_ending.isoformat(),
            "generated_comment": r.generated_comment,
            "generated_at": r.generated_at.isoformat() if r.generated_at else None
        })

    return result


@router.get("/by-task/{task_id}")
def get_reports_by_task(task_id: int, db: Session = Depends(get_db)):
    """Get all weekly reports for a specific task (history of all weeks)."""
    reports = db.query(WeeklyReport).filter(
        WeeklyReport.task_id == task_id
    ).order_by(WeeklyReport.week_ending.desc()).all()

    return [{
        "week_ending": r.week_ending.isoformat(),
        "generated_comment": r.generated_comment,
        "generated_at": r.generated_at.isoformat() if r.generated_at else None
    } for r in reports]


@router.post("/generate-now")
def generate_summary_now(week_ending: Optional[date] = None, db: Session = Depends(get_db)):
    """
    Generate LLM-polished progress comments for all active tasks (current week).
    Calls Bedrock Claude to rewrite raw PoC comments into stakeholder-ready language.
    Results are cached in weekly_reports table.
    """
    from datetime import timedelta
    from app.models import ProgressComment, ActivityLog
    from app.services.llm_service import generate_weekly_comment

    today = date.today()
    if week_ending:
        week_end = week_ending
        week_start = week_end - timedelta(days=4)
    else:
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=4)

    tasks = db.query(Task).filter(Task.status != "Completed").all()
    results = []
    generated_count = 0
    cached_count = 0

    for task in tasks:
        # Check if already generated for this week (cache)
        existing = db.query(WeeklyReport).filter(
            WeeklyReport.task_id == task.id,
            WeeklyReport.week_ending == week_end
        ).first()

        if existing:
            results.append({
                "task_id": task.id,
                "task_name": task.name,
                "generated_comment": existing.generated_comment,
                "source": "cached"
            })
            cached_count += 1
            continue

        # Get raw PoC comments this week
        raw_comments = db.query(ProgressComment).filter(
            ProgressComment.task_id == task.id,
            ProgressComment.created_at >= datetime.combine(week_start, datetime.min.time()),
            ProgressComment.created_at <= datetime.combine(week_end, datetime.max.time())
        ).all()

        # Get activity log this week
        activities = db.query(ActivityLog).filter(
            ActivityLog.task_id == task.id,
            ActivityLog.created_at >= datetime.combine(week_start, datetime.min.time()),
            ActivityLog.created_at <= datetime.combine(week_end, datetime.max.time())
        ).all()

        # Get milestone updates
        milestones = sorted(task.milestones, key=lambda m: m.milestone_number)
        milestone_updates = []
        for m in milestones:
            if m.is_completed and m.target_date and week_start <= m.target_date <= week_end:
                milestone_updates.append(f"MS{m.milestone_number} completed: {m.description or 'N/A'}")
            elif m.target_date and week_start <= m.target_date <= week_end:
                milestone_updates.append(f"MS{m.milestone_number} due this week: {m.description or 'N/A'}")

        # Skip if no activity
        raw_texts = [c.comment_text for c in raw_comments]
        activity_texts = [f"{a.field_changed}: {a.old_value} → {a.new_value}" for a in activities]

        if not raw_texts and not activity_texts and not milestone_updates:
            continue

        # Call LLM
        generated = generate_weekly_comment(
            task_name=task.name,
            task_type=task.type,
            poc_name=task.poc_name or "Unknown",
            status=task.status,
            raw_poc_comments=raw_texts,
            activity_changes=activity_texts,
            milestone_updates=milestone_updates
        )

        if generated:
            # Cache in DB
            report = WeeklyReport(
                task_id=task.id,
                week_ending=week_end,
                generated_comment=generated,
                raw_input="\n".join(raw_texts + activity_texts + milestone_updates)
            )
            db.add(report)
            results.append({
                "task_id": task.id,
                "task_name": task.name,
                "generated_comment": generated,
                "source": "llm"
            })
            generated_count += 1
        else:
            # Fallback — use raw comments
            fallback = "; ".join(raw_texts) if raw_texts else "No updates"
            results.append({
                "task_id": task.id,
                "task_name": task.name,
                "generated_comment": fallback,
                "source": "fallback"
            })

    db.commit()

    return {
        "week_ending": week_end.isoformat(),
        "generated": generated_count,
        "cached": cached_count,
        "total": len(results),
        "results": results
    }


@router.get("/email-summary")
def get_email_summary(week_ending: Optional[date] = None, db: Session = Depends(get_db)):
    """
    Generate a formatted email-style weekly summary for all tasks.
    If week_ending is not provided, uses current week (Monday to today).
    """
    from datetime import timedelta
    from app.models import ProgressComment

    today = date.today()

    if week_ending:
        week_end = week_ending
        week_start = week_end - timedelta(days=4)
    else:
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=4)

    week_label = week_end.strftime("%d %B %Y")

    tasks = db.query(Task).all()
    summary_items = []

    for idx, task in enumerate(tasks, 1):
        milestones = sorted(task.milestones, key=lambda m: m.milestone_number)

        # Get progress comments for this week
        week_comments = db.query(ProgressComment).filter(
            ProgressComment.task_id == task.id,
            ProgressComment.created_at >= datetime.combine(week_start, datetime.min.time()),
            ProgressComment.created_at <= datetime.combine(week_end, datetime.max.time())
        ).all()

        # Get LLM-generated report if available
        weekly_report = db.query(WeeklyReport).filter(
            WeeklyReport.task_id == task.id,
            WeeklyReport.week_ending == week_end
        ).first()

        completed_ms = [m for m in milestones if m.is_completed]
        upcoming_ms = None
        days_to_ms = None
        for m in milestones:
            if m.target_date and not m.is_completed:
                upcoming_ms = m
                days_to_ms = (m.target_date - today).days
                break

        # Progress text
        if weekly_report:
            progress_text = weekly_report.generated_comment
        elif week_comments:
            progress_text = "; ".join([c.comment_text.replace("\n", "; ") for c in week_comments])
        else:
            progress_text = "No updates this week"

        # Next steps
        next_steps = ""
        if upcoming_ms:
            next_steps = f"{upcoming_ms.description or 'Milestone ' + str(upcoming_ms.milestone_number)}"
            if upcoming_ms.target_date:
                next_steps += f" (due: {upcoming_ms.target_date.strftime('%m/%d/%Y')})"
        remaining_ms = [m for m in milestones if not m.is_completed and m != upcoming_ms]
        if remaining_ms:
            remaining_text = "; ".join([
                f"MS{m.milestone_number}: {m.target_date.strftime('%m/%d/%Y') if m.target_date else 'TBD'}"
                for m in remaining_ms
            ])
            next_steps += f"; then {remaining_text}" if next_steps else remaining_text
        if not next_steps:
            next_steps = "No upcoming milestones"

        item = {
            "number": idx,
            "name": task.name,
            "poc": task.poc_name or "Unassigned",
            "status": task.status,
            "current_milestone": None,
            "completed_milestone": None,
            "progress": progress_text,
            "next_steps": next_steps
        }
        if upcoming_ms:
            item["current_milestone"] = f"Milestone {upcoming_ms.milestone_number} due in {days_to_ms} days ({upcoming_ms.target_date.strftime('%m/%d/%Y')})"
        if completed_ms:
            latest = completed_ms[-1]
            item["completed_milestone"] = f"MS{latest.milestone_number} completed: {latest.description or 'N/A'}"

        summary_items.append(item)

    # Build email text
    email_lines = [
        f"Please find below the weekly project status update (WE {week_label}).",
        "For each task, I've captured current status, progress/achievements this week, and the next milestone/next steps.",
        ""
    ]
    for item in summary_items:
        email_lines.append(f"{item['number']}) {item['name']} (PoC: {item['poc']})")
        email_lines.append(f"Status: {item['status']}")
        if item["completed_milestone"]:
            email_lines.append(f"Completed milestone: {item['completed_milestone']}")
        if item["current_milestone"]:
            email_lines.append(f"Current milestone: {item['current_milestone']}")
        email_lines.append(f"Progress/Achievements this week: {item['progress']}")
        email_lines.append(f"Next steps: {item['next_steps']}")
        email_lines.append("")
    email_lines.append("Detailed tasks and milestones can be found in FlowDesk application.")

    return {
        "week_ending": week_end.isoformat(),
        "week_start": week_start.isoformat(),
        "week_label": f"WE {week_label}",
        "summary_text": "\n".join(email_lines),
        "items": summary_items,
        "total_tasks": len(summary_items)
    }


@router.get("/export-excel")
def export_weekly_excel(db: Session = Depends(get_db)):
    """
    Export full Excel-like CSV with all tasks and all weekly comment columns.
    Columns: Tasks, Type, PoC, Comment, Status, MS1-5, Milestone Description,
    Completion Date, Upcoming Milestone, Days Remaining, WE col1, WE col2, ...
    """
    tasks = db.query(Task).all()

    # Get all available weeks (sorted ascending for column order)
    weeks = db.query(distinct(WeeklyReport.week_ending)).order_by(
        WeeklyReport.week_ending.asc()
    ).all()
    week_dates = [w[0] for w in weeks]

    # Build header
    fixed_headers = [
        "Tasks", "Type", "PoC", "Comment", "Status",
        "Milestone 1", "Milestone 2", "Milestone 3", "Milestone 4", "Milestone 5",
        "Milestone Description", "Completion Date", "Upcoming Milestone",
        "Number of Days for Upcoming Milestone"
    ]
    week_headers = [f"Progress Comment - WE {w.strftime('%m/%d/%Y')}" for w in week_dates]
    headers = fixed_headers + week_headers

    # Build rows
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(headers)

    for task in tasks:
        milestones = sorted(task.milestones, key=lambda m: m.milestone_number)

        # Milestone dates
        ms_dates = []
        for i in range(1, 6):
            ms = next((m for m in milestones if m.milestone_number == i), None)
            ms_dates.append(str(ms.target_date) if ms and ms.target_date else "")

        # Milestone descriptions
        ms_descs = "\n".join(
            f"MS{m.milestone_number}: {m.description or 'N/A'}" for m in milestones
        ) if milestones else ""

        # Upcoming milestone
        today = date.today()
        upcoming = ""
        days_remaining = ""
        for m in milestones:
            if m.target_date and not m.is_completed and m.target_date >= today:
                upcoming = m.description or f"Milestone {m.milestone_number}"
                days_remaining = str((m.target_date - today).days)
                break

        # Weekly comments for each week
        week_comments = []
        for w in week_dates:
            report = db.query(WeeklyReport).filter(
                WeeklyReport.task_id == task.id,
                WeeklyReport.week_ending == w
            ).first()
            week_comments.append(report.generated_comment if report else "")

        row = [
            task.name, task.type, task.poc_name or "",
            task.comment or task.description or "",
            task.status,
            *ms_dates,
            ms_descs,
            str(task.completion_date) if task.completion_date else "",
            upcoming, days_remaining,
            *week_comments
        ]
        writer.writerow(row)

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=FlowDesk_Weekly_Report.csv"}
    )


@router.get("/export-docx")
def export_weekly_docx(week_ending: Optional[date] = None, db: Session = Depends(get_db)):
    """
    Generate a Word document (.docx) with the weekly summary report.
    Matches the polished AI&I Prototyping Team format.
    """
    from datetime import timedelta
    from app.models import ProgressComment

    today = date.today()

    if week_ending:
        week_end = week_ending
        week_start = week_end - timedelta(days=4)
    else:
        week_start = today - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=4)

    week_label_full = week_end.strftime("%d_%B_%Y")
    filename = f"Weekly_Report_WE_{week_label_full}.docx"
    week_label = week_end.strftime("%d %B %Y")
    week_str = f"WE {week_end.strftime('%d %B %Y')} ({week_start.strftime('%b %d')} – {week_end.strftime('%b %d')})"

    # ── Build report_data from DB (WEEK-FILTERED: only tasks with activity this week) ──
    all_tasks = db.query(Task).all()
    report_data = []
    for task in all_tasks:
        # Get the best available comment for this week
        weekly_report = db.query(WeeklyReport).filter(
            WeeklyReport.task_id == task.id,
            WeeklyReport.week_ending == week_end
        ).first()
        week_comments = db.query(ProgressComment).filter(
            ProgressComment.task_id == task.id,
            ProgressComment.created_at >= datetime.combine(week_start, datetime.min.time()),
            ProgressComment.created_at <= datetime.combine(week_end, datetime.max.time())
        ).order_by(ProgressComment.created_at.desc()).all()

        # Check if task has any milestone activity this week
        has_milestone_activity = False
        for m in task.milestones:
            if m.target_date and week_start <= m.target_date <= week_end:
                has_milestone_activity = True
                break

        # SKIP tasks that have NO activity this week (no report, no comments, no milestone activity)
        if not weekly_report and not week_comments and not has_milestone_activity:
            continue

        if weekly_report and weekly_report.generated_comment:
            comment = weekly_report.generated_comment
        elif week_comments:
            comment = "; ".join(c.comment_text for c in week_comments)
        else:
            comment = "Milestone activity this week."

        # Upcoming milestone
        upcoming_ms = None
        for m in sorted(task.milestones, key=lambda x: x.milestone_number):
            if m.target_date and not m.is_completed:
                upcoming_ms = m
                break
        ms_text = ""
        if upcoming_ms:
            ms_text = f"MS{upcoming_ms.milestone_number}: {upcoming_ms.description or ''}"
            if upcoming_ms.target_date:
                ms_text += f" (due {upcoming_ms.target_date.strftime('%d-%b-%Y')})"
            if upcoming_ms.target_date and upcoming_ms.target_date < today:
                comment += " (Overdue milestone)"

        report_data.append({
            'task_name': task.name,
            'owner': task.poc_name or "Unassigned",
            'status': task.status or "In-Progress",
            'generated_comment': comment,
            'task_type': task.type or "",
            'upcoming_milestone': ms_text,
        })

    # ── Metrics ──────────────────────────────────────────────────────────────
    total = len(report_data)
    completed = sum(1 for r in report_data if 'completed' in r['status'].lower())
    in_progress = sum(1 for r in report_data if 'in-progress' in r['status'].lower() or r['status'].lower() == 'started')
    not_started = sum(1 for r in report_data if 'not started' in r['status'].lower())
    green_count = sum(1 for r in report_data if _health(r['status'])[0].startswith('✔'))
    amber_count = sum(1 for r in report_data if _health(r['status'])[0].startswith('🟠'))
    red_count   = sum(1 for r in report_data if _health(r['status'])[0].startswith('🔴'))
    no_update   = sum(1 for r in report_data if 'no updates this week' in r['generated_comment'].lower())
    active_count = total - completed

    # ── Create document ───────────────────────────────────────────────────────
    doc = Document()
    style = doc.styles['Normal']
    style.font.name = 'Calibri'; style.font.size = Pt(10)
    style.paragraph_format.space_after = Pt(0); style.paragraph_format.space_before = Pt(0)

    for section in doc.sections:
        section.top_margin    = Cm(2.0); section.bottom_margin = Cm(2.0)
        section.left_margin   = Cm(1.27); section.right_margin  = Cm(1.27)

        # Header
        header = section.header; header.is_linked_to_previous = False
        h_para = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        h_para.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT; h_para.space_after = Pt(0)
        h_run = h_para.add_run("AI&I Prototyping Team  |  Weekly Status Update")
        h_run.font.name = "Calibri"; h_run.font.size = Pt(8)
        h_run.font.color.rgb = RGBColor.from_string(_DARK_BLUE); h_run.bold = True
        h_para.add_run("\t\t")
        h_date = h_para.add_run(f"WE {week_end.strftime('%d %B %Y')}")
        h_date.font.name = "Calibri"; h_date.font.size = Pt(8)
        h_date.font.color.rgb = RGBColor.from_string("808080")
        h_border = OxmlElement('w:pBdr'); h_bottom = OxmlElement('w:bottom')
        h_bottom.set(qn('w:val'), 'single'); h_bottom.set(qn('w:sz'), '4')
        h_bottom.set(qn('w:space'), '4'); h_bottom.set(qn('w:color'), _DARK_BLUE)
        h_border.append(h_bottom); h_para._element.get_or_add_pPr().append(h_border)

        # Footer
        footer = section.footer; footer.is_linked_to_previous = False
        f_para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        f_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER; f_para.space_before = Pt(4)
        f_border = OxmlElement('w:pBdr'); f_top = OxmlElement('w:top')
        f_top.set(qn('w:val'), 'single'); f_top.set(qn('w:sz'), '4')
        f_top.set(qn('w:space'), '4'); f_top.set(qn('w:color'), 'CCCCCC')
        f_border.append(f_top); f_para._element.get_or_add_pPr().append(f_border)
        f_left = f_para.add_run("Confidential  |  AI&I Prototyping Team")
        f_left.font.name = "Calibri"; f_left.font.size = Pt(7)
        f_left.font.color.rgb = RGBColor.from_string("808080")
        f_para.add_run("\t\t")
        f_page = f_para.add_run("Page ")
        f_page.font.name = "Calibri"; f_page.font.size = Pt(7)
        f_page.font.color.rgb = RGBColor.from_string("808080")
        fld1 = OxmlElement('w:fldChar'); fld1.set(qn('w:fldCharType'), 'begin'); f_page._element.append(fld1)
        instr = OxmlElement('w:instrText'); instr.set(qn('xml:space'), 'preserve'); instr.text = ' PAGE '; f_page._element.append(instr)
        fld2 = OxmlElement('w:fldChar'); fld2.set(qn('w:fldCharType'), 'end'); f_page._element.append(fld2)

    # â•â• TITLE BANNER â•â•
    ttbl = doc.add_table(rows=1, cols=1); _remove_borders(ttbl)
    tc = ttbl.rows[0].cells[0]; _shd(tc, _DARK_BLUE); _cell_margins(tc, top=120, bottom=120)
    _cell_text(tc, "AI&I Prototyping Team Weekly Status Update",
               bold=True, font_size=16, font_color=_WHITE,
               alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # â•â• PROJECT INFO â•â•
    info = doc.add_table(rows=2, cols=4); _table_borders(info, color="BFC0C2", size="6"); _tbl_width(info, 18)
    for i, (h, v) in enumerate(zip(
        ['Project Name', 'Week', 'Scrum Master / Owner', 'Team'],
        ['US AI&I Prototyping Team', week_str, 'Srilatha / Mohan', 'AI&I Prototyping Team']
    )):
        _shd(info.rows[0].cells[i], _LIGHT_BLUE)
        _cell_margins(info.rows[0].cells[i], top=60, bottom=60)
        _cell_margins(info.rows[1].cells[i], top=60, bottom=60)
        _cell_text(info.rows[0].cells[i], h, bold=True, font_size=9)
        _cell_text(info.rows[1].cells[i], v, font_size=9)
    doc.add_paragraph()

    # â•â• EXECUTIVE SUMMARY â•â•
    _section_heading(doc, "Executive Summary")
    p = doc.add_paragraph()
    run = p.add_run(
        f"This week's report covers {total} work items with activity during the week. "
        f"{completed} are completed, {in_progress} are actively in progress, "
        f"and {not_started} are not yet started."
    )
    run.font.name = "Calibri"; run.font.size = Pt(10)
    doc.add_paragraph()

    # â•â• KEY METRICS CARDS â•â•
    mtr = doc.add_table(rows=2, cols=5); _remove_borders(mtr); _tbl_width(mtr, 18)
    m_labels = ['Total Items', 'Completed', 'Active Items', 'Needs Attention', 'No Updates']
    m_values = [str(total), str(completed), str(active_count), str(red_count), str(no_update)]
    m_colors = [_DARK_BLUE, _GREEN_BG, _LIGHT_BLUE, _RED_BG, _AMBER_BG]
    m_icons  = ['📋', '✅', '🔄', '⚠️', '🔥']
    for i in range(5):
        top = mtr.rows[0].cells[i]; bot = mtr.rows[1].cells[i]
        _shd(top, m_colors[i]); _shd(bot, m_colors[i])
        _cell_margins(top, top=60, bottom=20); _cell_margins(bot, top=20, bottom=60)
        fc = _WHITE if m_colors[i] in (_DARK_BLUE, _GREEN_BG, _RED_BG, _AMBER_BG) else None
        _cell_text(top, f"{m_icons[i]}  {m_values[i]}", bold=True, font_size=14,
                   font_color=fc, alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        _cell_text(bot, m_labels[i], font_size=8, font_color=fc,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # â•â• KEY ACCOMPLISHMENTS â•â•
    _section_heading(doc, "🏆 Key Accomplishments This Week")
    completed_items = [r for r in report_data if 'completed' in r['status'].lower() or
                       ('no updates' not in r['generated_comment'].lower() and _health(r['status'])[0].startswith('✔'))]
    highlighted = [r for r in report_data
                   if 'no updates this week' not in r['generated_comment'].lower()
                   and not r['status'].lower().startswith('not')][:8]
    acc_table = doc.add_table(rows=1 + len(highlighted), cols=2)
    _table_borders(acc_table, color="BFC0C2", size="6"); _tbl_width(acc_table, 18)
    for i, h in enumerate(['Accomplishment', 'Details']):
        cell = acc_table.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for idx, r in enumerate(highlighted, start=1):
        cells = acc_table.rows[idx].cells
        _shd(cells[0], "E2EFDA"); _cell_margins(cells[0], top=60, bottom=60, left=100, right=80)
        _cell_text(cells[0], f"✅  {r['task_name']}", bold=True, font_size=9)
        _shd(cells[1], "F4FBF0"); _cell_margins(cells[1], top=60, bottom=60, left=100, right=100)
        _cell_text(cells[1], r['generated_comment'], font_size=9)
    for row in acc_table.rows:
        row.cells[0].width = Cm(5.0); row.cells[1].width = Cm(13.0)
    doc.add_paragraph()

    # â•â• HEALTH STATUS BAR â•â•
    hbar = doc.add_table(rows=1, cols=3); _remove_borders(hbar)
    for i, (txt, bg) in enumerate([
        (f"✔ Completed: {green_count}", _GREEN_BG),
        (f"🟠 In Progress: {amber_count}", _AMBER_BG),
        (f"🔴 Needs Attention: {red_count}", _RED_BG),
    ]):
        cell = hbar.rows[0].cells[i]; _shd(cell, bg); _cell_margins(cell, top=80, bottom=80)
        _cell_text(cell, txt, bold=True, font_size=11, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # â•â• DASHBOARD â•â•
    _section_heading(doc, "Dashboard")
    dash = doc.add_table(rows=2, cols=5); _table_borders(dash, color="BFC0C2", size="6")
    for i, (h, v) in enumerate(zip(
        ['Tracked Items', 'Completed', 'In Progress', 'Not Started', 'Needs Attention'],
        [str(total), str(completed), str(in_progress), str(not_started), str(red_count)]
    )):
        _shd(dash.rows[0].cells[i], _LIGHT_BLUE)
        _cell_margins(dash.rows[0].cells[i], top=60, bottom=60)
        _cell_margins(dash.rows[1].cells[i], top=60, bottom=60)
        _cell_text(dash.rows[0].cells[i], h, bold=True, font_size=9,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        _cell_text(dash.rows[1].cells[i], v, font_size=10, bold=True,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    doc.add_paragraph()

    # â•â• CHARTS (if matplotlib available) â•â•
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from collections import Counter

        def _pie_chart(data, tmp):
            sm = Counter(r['status'].strip() for r in data)
            labels, sizes = list(sm.keys()), list(sm.values())
            clrs = {'Completed':'#2E7D32','In-Progress':'#1565C0','Not Started':'#C62828',
                    'On Hold':'#F57F17','Blocked':'#C62828'}
            colors = [clrs.get(l, '#757575') for l in labels]
            fig, ax = plt.subplots(figsize=(4.5, 3.5))
            wedges, _, autos = ax.pie(sizes, labels=None, autopct='%1.0f%%', startangle=140,
                colors=colors, pctdistance=0.78, wedgeprops=dict(width=0.45, edgecolor='white', linewidth=2))
            for t in autos: t.set_fontsize(9); t.set_fontweight('bold'); t.set_color('white')
            ax.text(0, 0, f"{sum(sizes)}\nTotal", ha='center', va='center',
                    fontsize=14, fontweight='bold', color='#1F4E79')
            ax.legend(wedges, [f"{l} ({s})" for l, s in zip(labels, sizes)],
                     loc='center left', bbox_to_anchor=(1, 0.5), fontsize=8, frameon=False)
            ax.set_title('Task Status Distribution', fontsize=11, fontweight='bold', color='#1F4E79', pad=12)
            plt.tight_layout()
            p = os.path.join(tmp, 'pie.png'); fig.savefig(p, dpi=180, bbox_inches='tight', facecolor='white'); plt.close(fig)
            return p

        def _hbar_chart(g, a, r, tmp):
            cats = ['On Track', 'In Progress', 'Needs Attention']; vals = [g, a, r]
            clrs = ['#2E7D32', '#F57F17', '#C62828']
            fig, ax = plt.subplots(figsize=(4.5, 2.2))
            bars = ax.barh(cats, vals, color=clrs, height=0.55, edgecolor='white', linewidth=1.5)
            for bar, val in zip(bars, vals):
                ax.text(bar.get_width() + 0.3, bar.get_y() + bar.get_height()/2,
                        str(val), va='center', fontsize=11, fontweight='bold', color='#333333')
            ax.set_xlim(0, max(vals) + 3)
            ax.set_title('Health Status Distribution', fontsize=11, fontweight='bold', color='#1F4E79', pad=10)
            ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
            plt.tight_layout()
            p = os.path.join(tmp, 'hbar.png'); fig.savefig(p, dpi=180, bbox_inches='tight', facecolor='white'); plt.close(fig)
            return p

        def _owner_chart(data, tmp):
            active = [r for r in data if 'completed' not in r['status'].lower()]
            oc = Counter()
            for r in active:
                for o in r['owner'].replace('/', ',').split(','):
                    oc[o.strip().split()[0]] += 1
            top = sorted(oc.items(), key=lambda x: x[1], reverse=True)[:10]
            if not top: return None
            names, counts = [x[0] for x in top], [x[1] for x in top]
            fig, ax = plt.subplots(figsize=(5, 3))
            bclrs = ['#1F4E79' if i == 0 else '#4A90D9' for i in range(len(names))]
            bars = ax.bar(names, counts, color=bclrs, width=0.6, edgecolor='white', linewidth=1)
            for bar, val in zip(bars, counts):
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.15,
                        str(val), ha='center', fontsize=9, fontweight='bold', color='#333333')
            ax.set_title('Active Workload by Owner', fontsize=11, fontweight='bold', color='#1F4E79', pad=12)
            ax.set_ylabel('Active Items', fontsize=9, color='#555555')
            ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
            ax.tick_params(axis='x', rotation=30, labelsize=8); ax.set_ylim(0, max(counts) + 2)
            plt.tight_layout()
            p = os.path.join(tmp, 'owner.png'); fig.savefig(p, dpi=180, bbox_inches='tight', facecolor='white'); plt.close(fig)
            return p

        _section_heading(doc, "Visual Insights")
        tmp_dir = tempfile.mkdtemp()
        try:
            pie_p   = _pie_chart(report_data, tmp_dir)
            hbar_p  = _hbar_chart(green_count, amber_count, red_count, tmp_dir)
            owner_p = _owner_chart(report_data, tmp_dir)

            ct1 = doc.add_table(rows=1, cols=2); _remove_borders(ct1); _tbl_width(ct1, 18)
            ct1.rows[0].cells[0].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            ct1.rows[0].cells[0].paragraphs[0].add_run().add_picture(pie_p, width=Inches(3.3))
            ct1.rows[0].cells[1].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            ct1.rows[0].cells[1].paragraphs[0].add_run().add_picture(hbar_p, width=Inches(3.3))
            doc.add_paragraph()

            if owner_p:
                ct2 = doc.add_table(rows=1, cols=1); _remove_borders(ct2)
                ct2.rows[0].cells[0].paragraphs[0].alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                ct2.rows[0].cells[0].paragraphs[0].add_run().add_picture(owner_p, width=Inches(3.3))
                doc.add_paragraph()
        finally:
            for f in os.listdir(tmp_dir):
                try: os.remove(os.path.join(tmp_dir, f))
                except OSError: pass
            try: os.rmdir(tmp_dir)
            except OSError: pass
    except ImportError:
        pass  # matplotlib not installed – skip charts

    # â•â• PROGRESS OVERVIEW â•â•
    _section_heading(doc, "Progress Overview")
    prog = doc.add_table(rows=1 + len(report_data), cols=5)
    _table_borders(prog, color="BFC0C2", size="6"); _tbl_width(prog, 18)
    for i, h in enumerate(['Work Item', 'Owner', 'Health', 'Current Week Comment', 'Next Milestone Details']):
        cell = prog.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=80, right=80)
        _cell_text(cell, h, bold=True, font_size=8, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for ri, item in enumerate(report_data, start=1):
        ht, hbg = _health(item['status'])
        row_bg = _LIGHT_GRAY if ri % 2 == 0 else None
        cells = prog.rows[ri].cells
        _cell_margins(cells[0], top=50, bottom=50, left=80, right=60)
        _cell_text(cells[0], item['task_name'], bold=True, font_size=8)
        if row_bg: _shd(cells[0], row_bg)
        _cell_margins(cells[1], top=50, bottom=50, left=60, right=60)
        _cell_text(cells[1], item['owner'], font_size=8)
        if row_bg: _shd(cells[1], row_bg)
        _cell_margins(cells[2], top=50, bottom=50, left=40, right=40)
        _shd(cells[2], hbg)
        _cell_text(cells[2], ht, bold=True, font_size=7, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        _cell_margins(cells[3], top=50, bottom=50, left=80, right=80)
        _cell_text(cells[3], item['generated_comment'], font_size=8)
        if row_bg: _shd(cells[3], row_bg)
        _cell_margins(cells[4], top=50, bottom=50, left=60, right=60)
        _cell_text(cells[4], item.get('upcoming_milestone', '–'), font_size=8)
        if row_bg: _shd(cells[4], row_bg)
    col_widths = [Cm(3.5), Cm(2.4), Cm(2.0), Cm(7.1), Cm(3.0)]
    for row in prog.rows:
        for i, w in enumerate(col_widths): row.cells[i].width = w
    doc.add_paragraph()

    # â•â• ITEMS NEEDING ATTENTION â•â•
    attn_items = [r for r in report_data
                  if 'overdue' in r['generated_comment'].lower()
                  or r['status'].lower() in ('blocked', 'on hold', 'not started')
                  or 'unassigned' in r['owner'].lower()]
    if attn_items:
        _section_heading(doc, "⚠️ Items Needing Attention")
        at = doc.add_table(rows=1, cols=3)
        _table_borders(at, color="BFC0C2", size="6"); _tbl_width(at, 18)
        for i, h in enumerate(['Work Item', 'Owner', 'Reason']):
            cell = at.rows[0].cells[i]; _shd(cell, "C62828")
            _cell_margins(cell, top=70, bottom=70, left=100, right=100)
            _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE,
                       alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
        for r in attn_items:
            reasons = []
            if r['status'].lower() in ('blocked', 'on hold', 'not started'):
                reasons.append(f"Status: {r['status']}")
            if 'overdue' in r['generated_comment'].lower():
                reasons.append("Has overdue milestones")
            if 'unassigned' in r['owner'].lower():
                reasons.append("No owner assigned")
            row = at.add_row()
            _cell_margins(row.cells[0], top=50, bottom=50, left=100, right=80)
            _cell_margins(row.cells[1], top=50, bottom=50, left=80, right=80)
            _cell_margins(row.cells[2], top=50, bottom=50, left=80, right=80)
            _cell_text(row.cells[0], r['task_name'], bold=True, font_size=9)
            _cell_text(row.cells[1], r['owner'], font_size=9)
            _shd(row.cells[2], "FCE4D6")
            _cell_text(row.cells[2], "; ".join(reasons), font_size=9)
        doc.add_paragraph()

    # â•â• WEEKLY HIGHLIGHTS â•â•
    _section_heading(doc, "Weekly Highlights")
    highlights = [r for r in report_data
                  if r['generated_comment'] and 'no updates this week' not in r['generated_comment'].lower()
                  and 'not started' not in r['status'].lower()][:6]
    hl = doc.add_table(rows=1, cols=2)
    _table_borders(hl, color="BFC0C2", size="6"); _tbl_width(hl, 18)
    for i, h in enumerate(['Work Item', 'Progress Summary']):
        cell = hl.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for r in highlights:
        row = hl.add_row()
        _cell_margins(row.cells[0], top=50, bottom=50, left=100, right=80)
        _cell_margins(row.cells[1], top=50, bottom=50, left=100, right=80)
        _cell_text(row.cells[0], r['task_name'], bold=True, font_size=9)
        _cell_text(row.cells[1], r['generated_comment'], font_size=9)
    doc.add_paragraph()

    # â•â• RISKS & MITIGATION â•â•
    _section_heading(doc, "Risks & Mitigation")
    risk_items = []
    for r in report_data:
        if 'overdue' in r['generated_comment'].lower():
            risk_items.append((r['task_name'], "Milestone overdue", "Escalate to owner; re-baseline timeline"))
        elif r['status'].lower() in ('blocked', 'on hold'):
            risk_items.append((r['task_name'], f"Status: {r['status']}", "Review blockers; identify alternate path"))
    if not risk_items:
        risk_items.append(("–", "No critical risks this week", "Continue monitoring"))
    rsk = doc.add_table(rows=1, cols=3)
    _table_borders(rsk, color="BFC0C2", size="6"); _tbl_width(rsk, 18)
    for i, h in enumerate(['Work Item', 'Risk', 'Mitigation']):
        cell = rsk.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for task_name, risk, mitigation in risk_items:
        row = rsk.add_row()
        _cell_margins(row.cells[0], top=50, bottom=50, left=100, right=80)
        _cell_margins(row.cells[1], top=50, bottom=50, left=100, right=80)
        _cell_margins(row.cells[2], top=50, bottom=50, left=100, right=80)
        _cell_text(row.cells[0], task_name, bold=True, font_size=9)
        _shd(row.cells[1], _RED_BG)
        _cell_text(row.cells[1], risk, font_size=9, font_color=_WHITE)
        _cell_text(row.cells[2], mitigation, font_size=9)
    doc.add_paragraph()

    # â•â• NEXT WEEK PLAN â•â•
    _section_heading(doc, "Next Week Plan")
    next_items = []
    for r in report_data:
        if 'next:' in r['generated_comment'].lower():
            next_txt = r['generated_comment'].split('Next:')[-1].strip()
            next_items.append((r['task_name'], next_txt))
        elif 'in-progress' in r['status'].lower():
            next_items.append((r['task_name'], "Continue development"))
    next_items = next_items[:8]
    if not next_items:
        next_items.append(("–", "Continue active work items"))
    nw = doc.add_table(rows=1, cols=2)
    _table_borders(nw, color="BFC0C2", size="6"); _tbl_width(nw, 18)
    for i, h in enumerate(['Work Item', 'Planned Activity']):
        cell = nw.rows[0].cells[i]; _shd(cell, _DARK_BLUE)
        _cell_margins(cell, top=70, bottom=70, left=100, right=100)
        _cell_text(cell, h, bold=True, font_size=9, font_color=_WHITE,
                   alignment=WD_PARAGRAPH_ALIGNMENT.CENTER)
    for task_name, plan in next_items:
        row = nw.add_row()
        _cell_margins(row.cells[0], top=50, bottom=50, left=100, right=80)
        _cell_margins(row.cells[1], top=50, bottom=50, left=100, right=80)
        _cell_text(row.cells[0], task_name, bold=True, font_size=9)
        _cell_text(row.cells[1], plan, font_size=9)
    doc.add_paragraph()

    # â•â• HEALTH SUMMARY â•â•
    _section_heading(doc, "Health Status Summary")
    p = doc.add_paragraph()
    run = p.add_run(f"🟢 On Track: {green_count}  |  🟠 In Progress: {amber_count}  |  🔴 Needs Attention: {red_count}")
    run.font.name = "Calibri"; run.font.size = Pt(10)
    p2 = doc.add_paragraph()
    note = p2.add_run("Note: On Track = completed/progressing well  |  In Progress = actively being worked  |  Needs Attention = blocked, on hold, or not started")
    note.font.name = "Calibri"; note.font.size = Pt(8)
    note.font.color.rgb = RGBColor.from_string("808080"); note.italic = True
    doc.add_paragraph()

    # â•â• FOOTER NOTE â•â•
    p = doc.add_paragraph(); p.space_before = Pt(12)
    run = p.add_run(f"Source: FlowDesk | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    run.font.name = "Calibri"; run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string("808080")

    # Save to buffer
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)

    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

