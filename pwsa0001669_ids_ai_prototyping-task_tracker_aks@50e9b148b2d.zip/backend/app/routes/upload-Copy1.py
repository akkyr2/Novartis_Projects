"""
FlowDesk - Excel Upload & Data Sync API
Allows uploading an Excel tracker sheet to preview changes and apply updates to the database.
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import date, datetime
from pydantic import BaseModel
import io
import re
from openpyxl import load_workbook

from app.database import get_db
from app.models import Task, Milestone, ProgressComment

router = APIRouter()


# ─── Response Models ─────────────────────────────────────────────────────────

class MilestoneChange(BaseModel):
    milestone_number: int
    field: str
    old_value: Optional[str] = None
    new_value: Optional[str] = None


class CommentChange(BaseModel):
    week_ending: str
    comment_text: str


class TaskChange(BaseModel):
    task_name: str
    action: str  # "new", "updated", "unchanged"
    field_changes: List[dict] = []
    milestone_changes: List[MilestoneChange] = []
    new_comments: List[CommentChange] = []


class PreviewResponse(BaseModel):
    total_rows: int
    new_tasks: int
    updated_tasks: int
    unchanged_tasks: int
    total_milestone_changes: int
    total_new_comments: int
    changes: List[TaskChange]


# ─── Helper Functions ────────────────────────────────────────────────────────

def parse_date(value):
    """Parse a date from Excel cell value."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    # Try parsing string dates
    val = str(value).strip()
    if not val or val.lower() in ('none', 'n/a', '', '-'):
        return None
    for fmt in ('%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y', '%m-%d-%Y', '%d-%m-%Y'):
        try:
            return datetime.strptime(val, fmt).date()
        except ValueError:
            continue
    return None


def parse_week_ending_from_header(header: str) -> Optional[str]:
    """
    Extract a week-ending date from a column header like:
    'Progress Comment - WE 07/10/2026' or 'WE 07/10/2026' or 'WE 07/10/26'
    Returns date string in YYYY-MM-DD format.
    """
    # Look for pattern: WE MM/DD/YYYY or WE MM/DD/YY
    match = re.search(r'WE\s*(\d{1,2})[/\-](\d{1,2})[/\-](\d{2,4})', str(header))
    if match:
        month, day, year = match.groups()
        if len(year) == 2:
            year = '20' + year
        try:
            d = datetime(int(year), int(month), int(day)).date()
            return d.isoformat()
        except ValueError:
            pass
    return None


def normalize_status(status):
    """Normalize status value."""
    if not status:
        return None
    s = str(status).strip()
    s_lower = s.lower()
    if 'completed' in s_lower or 'done' in s_lower:
        return 'Completed'
    elif 'in-progress' in s_lower or 'in progress' in s_lower or 'started' in s_lower:
        return 'In-Progress'
    elif 'not started' in s_lower:
        return 'Not Started'
    return s  # Return as-is if no match


def safe_str(val):
    """Convert value to string safely, return None for empty."""
    if val is None:
        return None
    s = str(val).strip()
    return s if s and s.lower() not in ('none', 'n/a') else None


def parse_excel_data(file_bytes: bytes):
    """
    Parse the Excel file and extract task data.
    Expected columns (order may vary, matched by header name):
    - Tasks / Task Name
    - Type
    - PoC
    - Comment / Description
    - Status
    - Milestone 1 through Milestone 5 (dates)
    - Milestone Description (combined text)
    - Completion Date
    - Progress Comment - WE XX/XX/XXXX (one or more columns)
    """
    wb = load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
    ws = wb.active

    # Read headers from first row
    headers = []
    for cell in ws[1]:
        headers.append(str(cell.value or '').strip())

    # Map column indices
    col_map = {}
    we_columns = []  # List of (col_index, week_ending_date_str)

    for idx, h in enumerate(headers):
        h_lower = h.lower()
        if h_lower in ('tasks', 'task name', 'task', 'name'):
            col_map['name'] = idx
        elif h_lower == 'type':
            col_map['type'] = idx
        elif h_lower == 'poc':
            col_map['poc'] = idx
        elif h_lower in ('comment', 'description', 'comments'):
            col_map['comment'] = idx
        elif h_lower == 'status':
            col_map['status'] = idx
        elif h_lower in ('completion date', 'completion_date'):
            col_map['completion_date'] = idx
        elif re.match(r'milestone\s*1', h_lower):
            col_map['ms1'] = idx
        elif re.match(r'milestone\s*2', h_lower):
            col_map['ms2'] = idx
        elif re.match(r'milestone\s*3', h_lower):
            col_map['ms3'] = idx
        elif re.match(r'milestone\s*4', h_lower):
            col_map['ms4'] = idx
        elif re.match(r'milestone\s*5', h_lower):
            col_map['ms5'] = idx
        elif 'milestone desc' in h_lower or 'milestone description' in h_lower:
            col_map['ms_description'] = idx
        else:
            # Check if it's a WE (week ending) column
            we_date = parse_week_ending_from_header(h)
            if we_date:
                we_columns.append((idx, we_date))

    if 'name' not in col_map:
        raise ValueError("Could not find 'Tasks' or 'Task Name' column in the Excel file. Please check the header row.")

    # Parse rows
    tasks_data = []
    for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        if not row or len(row) == 0:
            continue

        name = safe_str(row[col_map['name']] if col_map.get('name') is not None and col_map['name'] < len(row) else None)
        if not name:
            continue  # Skip empty rows

        task_data = {
            'name': name,
            'type': safe_str(row[col_map['type']] if col_map.get('type') is not None and col_map['type'] < len(row) else None),
            'poc': safe_str(row[col_map['poc']] if col_map.get('poc') is not None and col_map['poc'] < len(row) else None),
            'comment': safe_str(row[col_map['comment']] if col_map.get('comment') is not None and col_map['comment'] < len(row) else None),
            'status': normalize_status(row[col_map['status']] if col_map.get('status') is not None and col_map['status'] < len(row) else None),
            'completion_date': parse_date(row[col_map['completion_date']] if col_map.get('completion_date') is not None and col_map['completion_date'] < len(row) else None),
            'milestones': {},
            'comments': []
        }

        # Parse milestone dates
        for ms_num in range(1, 6):
            key = f'ms{ms_num}'
            if key in col_map and col_map[key] < len(row):
                ms_date = parse_date(row[col_map[key]])
                if ms_date:
                    task_data['milestones'][ms_num] = {'target_date': ms_date, 'description': None}

        # Parse milestone descriptions from combined text column
        if 'ms_description' in col_map and col_map['ms_description'] < len(row):
            ms_desc_text = safe_str(row[col_map['ms_description']])
            if ms_desc_text:
                # Parse "MS1: desc\nMS2: desc" format
                for match in re.finditer(r'MS(\d+)\s*:\s*(.+?)(?=MS\d+\s*:|$)', ms_desc_text, re.DOTALL):
                    ms_n = int(match.group(1))
                    ms_d = match.group(2).strip()
                    if ms_n in task_data['milestones']:
                        task_data['milestones'][ms_n]['description'] = ms_d
                    else:
                        task_data['milestones'][ms_n] = {'target_date': None, 'description': ms_d}

        # Parse weekly comments
        for col_idx, we_date in we_columns:
            if col_idx < len(row):
                comment_text = safe_str(row[col_idx])
                if comment_text:
                    task_data['comments'].append({
                        'week_ending': we_date,
                        'comment_text': comment_text
                    })

        tasks_data.append(task_data)

    wb.close()
    return tasks_data


# ─── API Endpoints ───────────────────────────────────────────────────────────

@router.post("/preview")
async def preview_upload(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """
    Upload an Excel file and preview what changes would be applied.
    Does NOT modify the database — only compares and returns diff.
    """
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only .xlsx or .xls files are accepted.")

    try:
        file_bytes = await file.read()
        excel_data = parse_excel_data(file_bytes)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse Excel file: {str(e)}")

    changes: List[TaskChange] = []
    new_count = 0
    updated_count = 0
    unchanged_count = 0
    total_ms_changes = 0
    total_new_comments = 0

    for task_data in excel_data:
        # Look up existing task by name
        existing_task = db.query(Task).filter(Task.name == task_data['name']).first()

        if not existing_task:
            # New task
            new_count += 1
            new_comments = [CommentChange(week_ending=c['week_ending'], comment_text=c['comment_text']) for c in task_data['comments']]
            ms_changes = [
                MilestoneChange(milestone_number=ms_num, field="new", old_value=None,
                                new_value=f"{d['target_date'] or 'No date'} - {d['description'] or 'No description'}")
                for ms_num, d in task_data['milestones'].items()
            ]
            total_ms_changes += len(ms_changes)
            total_new_comments += len(new_comments)
            changes.append(TaskChange(
                task_name=task_data['name'],
                action="new",
                field_changes=[
                    {"field": "type", "old": None, "new": task_data['type']},
                    {"field": "poc", "old": None, "new": task_data['poc']},
                    {"field": "status", "old": None, "new": task_data['status']},
                    {"field": "comment", "old": None, "new": task_data['comment']},
                ],
                milestone_changes=ms_changes,
                new_comments=new_comments
            ))
        else:
            # Compare with existing
            field_changes = []

            # Compare basic fields
            if task_data['type'] and task_data['type'] != (existing_task.type or ''):
                field_changes.append({"field": "type", "old": existing_task.type, "new": task_data['type']})
            if task_data['poc'] and task_data['poc'] != (existing_task.poc_name or ''):
                field_changes.append({"field": "poc", "old": existing_task.poc_name, "new": task_data['poc']})
            if task_data['status'] and task_data['status'] != (existing_task.status or ''):
                field_changes.append({"field": "status", "old": existing_task.status, "new": task_data['status']})
            if task_data['comment'] and task_data['comment'] != (existing_task.comment or ''):
                field_changes.append({"field": "comment", "old": existing_task.comment, "new": task_data['comment']})
            if task_data['completion_date']:
                existing_cd = existing_task.completion_date
                if existing_cd != task_data['completion_date']:
                    field_changes.append({
                        "field": "completion_date",
                        "old": str(existing_cd) if existing_cd else None,
                        "new": str(task_data['completion_date'])
                    })

            # Compare milestones
            ms_changes = []
            existing_milestones = {m.milestone_number: m for m in existing_task.milestones}
            for ms_num, ms_data in task_data['milestones'].items():
                if ms_num in existing_milestones:
                    em = existing_milestones[ms_num]
                    if ms_data['target_date'] and ms_data['target_date'] != em.target_date:
                        ms_changes.append(MilestoneChange(
                            milestone_number=ms_num, field="target_date",
                            old_value=str(em.target_date) if em.target_date else None,
                            new_value=str(ms_data['target_date'])
                        ))
                    if ms_data['description'] and ms_data['description'] != (em.description or ''):
                        ms_changes.append(MilestoneChange(
                            milestone_number=ms_num, field="description",
                            old_value=em.description,
                            new_value=ms_data['description']
                        ))
                else:
                    # New milestone
                    ms_changes.append(MilestoneChange(
                        milestone_number=ms_num, field="new",
                        old_value=None,
                        new_value=f"{ms_data['target_date'] or 'No date'} - {ms_data['description'] or 'No description'}"
                    ))

            # Check for new comments (comments that don't exist for that week)
            new_comments = []
            for comment_data in task_data['comments']:
                we_date = datetime.strptime(comment_data['week_ending'], '%Y-%m-%d').date()
                # Check if comment already exists for this task and week
                existing_comment = db.query(ProgressComment).filter(
                    ProgressComment.task_id == existing_task.id,
                    ProgressComment.created_at >= datetime.combine(we_date, datetime.min.time()),
                    ProgressComment.created_at <= datetime.combine(we_date, datetime.max.time())
                ).first()
                if not existing_comment:
                    new_comments.append(CommentChange(
                        week_ending=comment_data['week_ending'],
                        comment_text=comment_data['comment_text']
                    ))

            total_ms_changes += len(ms_changes)
            total_new_comments += len(new_comments)

            if field_changes or ms_changes or new_comments:
                updated_count += 1
                changes.append(TaskChange(
                    task_name=task_data['name'],
                    action="updated",
                    field_changes=field_changes,
                    milestone_changes=ms_changes,
                    new_comments=new_comments
                ))
            else:
                unchanged_count += 1
                changes.append(TaskChange(
                    task_name=task_data['name'],
                    action="unchanged"
                ))

    return PreviewResponse(
        total_rows=len(excel_data),
        new_tasks=new_count,
        updated_tasks=updated_count,
        unchanged_tasks=unchanged_count,
        total_milestone_changes=total_ms_changes,
        total_new_comments=total_new_comments,
        changes=changes
    )


@router.post("/apply")
async def apply_upload(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """
    Upload an Excel file and apply changes to the database.
    This actually modifies records (upsert logic).
    """
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only .xlsx or .xls files are accepted.")

    try:
        file_bytes = await file.read()
        excel_data = parse_excel_data(file_bytes)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse Excel file: {str(e)}")

    new_count = 0
    updated_count = 0
    comments_added = 0
    milestones_changed = 0

    for task_data in excel_data:
        existing_task = db.query(Task).filter(Task.name == task_data['name']).first()

        if not existing_task:
            # Insert new task
            new_task = Task(
                name=task_data['name'],
                type=task_data['type'] or 'Project',
                poc_name=task_data['poc'],
                comment=task_data['comment'],
                status=task_data['status'] or 'Not Started',
                completion_date=task_data['completion_date']
            )
            db.add(new_task)
            db.flush()  # Get the ID

            # Add milestones
            for ms_num, ms_data in task_data['milestones'].items():
                ms = Milestone(
                    task_id=new_task.id,
                    milestone_number=ms_num,
                    target_date=ms_data['target_date'],
                    description=ms_data['description'],
                    is_completed=False
                )
                db.add(ms)
                milestones_changed += 1

            # Add comments
            for comment_data in task_data['comments']:
                we_date = datetime.strptime(comment_data['week_ending'], '%Y-%m-%d').date()
                pc = ProgressComment(
                    task_id=new_task.id,
                    comment_text=comment_data['comment_text'],
                    submitted_by=task_data['poc'],
                    created_at=datetime.combine(we_date, datetime.min.time().replace(hour=10))
                )
                db.add(pc)
                comments_added += 1

            new_count += 1
        else:
            # Update existing task
            changed = False

            if task_data['type'] and task_data['type'] != (existing_task.type or ''):
                existing_task.type = task_data['type']
                changed = True
            if task_data['poc'] and task_data['poc'] != (existing_task.poc_name or ''):
                existing_task.poc_name = task_data['poc']
                changed = True
            if task_data['status'] and task_data['status'] != (existing_task.status or ''):
                existing_task.status = task_data['status']
                changed = True
            if task_data['comment'] and task_data['comment'] != (existing_task.comment or ''):
                existing_task.comment = task_data['comment']
                changed = True
            if task_data['completion_date'] and task_data['completion_date'] != existing_task.completion_date:
                existing_task.completion_date = task_data['completion_date']
                changed = True

            # Update milestones
            existing_milestones = {m.milestone_number: m for m in existing_task.milestones}
            for ms_num, ms_data in task_data['milestones'].items():
                if ms_num in existing_milestones:
                    em = existing_milestones[ms_num]
                    ms_changed = False
                    if ms_data['target_date'] and ms_data['target_date'] != em.target_date:
                        em.target_date = ms_data['target_date']
                        ms_changed = True
                    if ms_data['description'] and ms_data['description'] != (em.description or ''):
                        em.description = ms_data['description']
                        ms_changed = True
                    if ms_changed:
                        milestones_changed += 1
                        changed = True
                else:
                    # New milestone
                    ms = Milestone(
                        task_id=existing_task.id,
                        milestone_number=ms_num,
                        target_date=ms_data['target_date'],
                        description=ms_data['description'],
                        is_completed=False
                    )
                    db.add(ms)
                    milestones_changed += 1
                    changed = True

            # Add new comments
            for comment_data in task_data['comments']:
                we_date = datetime.strptime(comment_data['week_ending'], '%Y-%m-%d').date()
                existing_comment = db.query(ProgressComment).filter(
                    ProgressComment.task_id == existing_task.id,
                    ProgressComment.created_at >= datetime.combine(we_date, datetime.min.time()),
                    ProgressComment.created_at <= datetime.combine(we_date, datetime.max.time())
                ).first()
                if not existing_comment:
                    pc = ProgressComment(
                        task_id=existing_task.id,
                        comment_text=comment_data['comment_text'],
                        submitted_by=task_data['poc'],
                        created_at=datetime.combine(we_date, datetime.min.time().replace(hour=10))
                    )
                    db.add(pc)
                    comments_added += 1
                    changed = True

            if changed:
                updated_count += 1

    db.commit()

    return {
        "success": True,
        "message": f"Update complete: {new_count} new tasks, {updated_count} tasks updated, {milestones_changed} milestone changes, {comments_added} comments added.",
        "new_tasks": new_count,
        "updated_tasks": updated_count,
        "milestones_changed": milestones_changed,
        "comments_added": comments_added
    }
