from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import or_
from typing import Optional, List
from datetime import date, datetime
import csv
import io

from app.database import get_db
from app.models import Task, Milestone, ProgressComment, TaskDependency, ActivityLog
from app.schemas import (
    TaskCreate, TaskUpdate, TaskResponse,
    MilestoneCreate, MilestoneUpdate, MilestoneResponse,
    ProgressCommentCreate, ProgressCommentResponse,
    DependencyCreate, DependencyResponse
)

router = APIRouter()

VALID_STATUSES = ["Not Started", "In-Progress", "Completed"]
VALID_TYPES = ["Project", "Access Request", "Tech Spike", "Documentation", "Others"]


def calculate_task_fields(task: Task) -> dict:
    """Calculate auto-computed fields for a task."""
    milestones = sorted(task.milestones, key=lambda m: m.milestone_number)
    today = date.today()

    # Completion percentage
    if not milestones:
        if task.status == "Completed":
            completion_percentage = 100
        elif task.status == "Not Started":
            completion_percentage = 0
        else:
            completion_percentage = 50
    else:
        completed_count = sum(1 for m in milestones if m.is_completed)
        completion_percentage = int((completed_count / len(milestones)) * 100)

    # Upcoming milestone & days remaining
    upcoming_milestone = None
    days_to_upcoming = None
    is_overdue = False

    for m in milestones:
        if m.target_date and not m.is_completed:
            upcoming_milestone = m.description or f"Milestone {m.milestone_number}"
            days_remaining = (m.target_date - today).days
            days_to_upcoming = days_remaining
            if days_remaining < 0 and task.status != "Completed":
                is_overdue = True
            break

    return {
        "completion_percentage": completion_percentage,
        "upcoming_milestone": upcoming_milestone,
        "days_to_upcoming": days_to_upcoming,
        "is_overdue": is_overdue
    }


def build_milestone_response(milestone: Milestone) -> dict:
    """Build milestone response with calculated fields."""
    today = date.today()
    is_overdue = False
    days_remaining = None

    if milestone.target_date:
        days_remaining = (milestone.target_date - today).days
        if days_remaining < 0 and not milestone.is_completed:
            is_overdue = True

    return {
        "id": milestone.id,
        "milestone_number": milestone.milestone_number,
        "target_date": milestone.target_date,
        "description": milestone.description,
        "is_completed": milestone.is_completed,
        "is_overdue": is_overdue,
        "days_remaining": days_remaining
    }


def task_to_response(task: Task) -> dict:
    """Convert task model to response dict with computed fields."""
    computed = calculate_task_fields(task)
    milestones_resp = [build_milestone_response(m) for m in task.milestones]
    comments_resp = [
        {
            "id": c.id,
            "comment_text": c.comment_text,
            "submitted_by": c.submitted_by,
            "created_at": c.created_at
        }
        for c in sorted(task.progress_comments, key=lambda x: x.created_at or datetime.min, reverse=True)
    ]

    return {
        "id": task.id,
        "name": task.name,
        "type": task.type,
        "poc_name": task.poc_name,
        "description": task.description,
        "comment": task.comment,
        "status": task.status,
        "completion_date": task.completion_date,
        "completion_percentage": computed["completion_percentage"],
        "upcoming_milestone": computed["upcoming_milestone"],
        "days_to_upcoming": computed["days_to_upcoming"],
        "is_overdue": computed["is_overdue"],
        "milestones": milestones_resp,
        "progress_comments": comments_resp,
        "created_at": task.created_at,
        "updated_at": task.updated_at
    }


# --- Task CRUD ---

@router.get("", response_model=List[TaskResponse])
def get_tasks(
    status: Optional[str] = None,
    type: Optional[str] = None,
    poc: Optional[str] = None,
    search: Optional[str] = None,
    role: Optional[str] = None,
    user: Optional[str] = None,
    db: Session = Depends(get_db)
):
    if db is None:
        return []

    query = db.query(Task)

    # Role-based filtering
    if role == "member" and user:
        query = query.filter(Task.poc_name.ilike(f"%{user}%"))

    # Filters
    if status:
        query = query.filter(Task.status == status)
    if type:
        query = query.filter(Task.type == type)
    if poc:
        query = query.filter(Task.poc_name.ilike(f"%{poc}%"))
    if search:
        query = query.filter(
            or_(
                Task.name.ilike(f"%{search}%"),
                Task.description.ilike(f"%{search}%")
            )
        )

    tasks = query.all()
    return [task_to_response(t) for t in tasks]


@router.get("/{task_id}", response_model=TaskResponse)
def get_task(task_id: int, db: Session = Depends(get_db)):
    if db is None:
        raise HTTPException(status_code=503, detail="Database unavailable")
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task_to_response(task)


@router.post("", response_model=TaskResponse, status_code=201)
def create_task(task_data: TaskCreate, db: Session = Depends(get_db)):
    if task_data.status and task_data.status not in VALID_STATUSES:
        raise HTTPException(status_code=422, detail=f"Invalid status. Must be one of: {VALID_STATUSES}")
    if task_data.type and task_data.type not in VALID_TYPES:
        raise HTTPException(status_code=422, detail=f"Invalid type. Must be one of: {VALID_TYPES}")

    task = Task(
        name=task_data.name,
        type=task_data.type,
        poc_name=task_data.poc_name,
        description=task_data.description,
        comment=task_data.comment,
        status=task_data.status,
        completion_date=task_data.completion_date
    )
    db.add(task)
    db.flush()

    # Add milestones if provided
    if task_data.milestones:
        prev_date = None
        for m_data in sorted(task_data.milestones, key=lambda x: x.milestone_number):
            if m_data.target_date and prev_date and m_data.target_date < prev_date:
                raise HTTPException(status_code=400, detail="Milestones must be in chronological order")
            milestone = Milestone(
                task_id=task.id,
                milestone_number=m_data.milestone_number,
                target_date=m_data.target_date,
                description=m_data.description
            )
            db.add(milestone)
            if m_data.target_date:
                prev_date = m_data.target_date

    db.commit()
    db.refresh(task)
    return task_to_response(task)


@router.put("/{task_id}", response_model=TaskResponse)
def update_task(task_id: int, task_data: TaskUpdate, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    if task_data.status and task_data.status not in VALID_STATUSES:
        raise HTTPException(status_code=422, detail=f"Invalid status. Must be one of: {VALID_STATUSES}")

    update_fields = task_data.model_dump(exclude_unset=True)
    for field, value in update_fields.items():
        old_value = getattr(task, field, None)
        if old_value != value:
            # Log the change to activity_log
            activity = ActivityLog(
                task_id=task.id,
                field_changed=field,
                old_value=str(old_value) if old_value is not None else None,
                new_value=str(value) if value is not None else None,
                changed_by=task.poc_name
            )
            db.add(activity)
        setattr(task, field, value)

    db.commit()
    db.refresh(task)
    return task_to_response(task)


@router.delete("/{task_id}")
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(task)
    db.commit()
    return {"message": "Task deleted successfully", "id": task_id}


# --- Milestone endpoints ---

@router.post("/{task_id}/milestones", response_model=MilestoneResponse, status_code=201)
def add_milestone(task_id: int, milestone_data: MilestoneCreate, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    existing = db.query(Milestone).filter(
        Milestone.task_id == task_id,
        Milestone.milestone_number == milestone_data.milestone_number
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"Milestone {milestone_data.milestone_number} already exists for this task")

    # Validate chronological order
    if milestone_data.target_date:
        prev_milestones = db.query(Milestone).filter(
            Milestone.task_id == task_id,
            Milestone.milestone_number < milestone_data.milestone_number
        ).all()
        for pm in prev_milestones:
            if pm.target_date and milestone_data.target_date < pm.target_date:
                raise HTTPException(status_code=400, detail="Milestones must be in chronological order")

    milestone = Milestone(
        task_id=task_id,
        milestone_number=milestone_data.milestone_number,
        target_date=milestone_data.target_date,
        description=milestone_data.description
    )
    db.add(milestone)
    db.commit()
    db.refresh(milestone)
    return build_milestone_response(milestone)


@router.put("/{task_id}/milestones/{milestone_num}", response_model=MilestoneResponse)
def update_milestone(task_id: int, milestone_num: int, milestone_data: MilestoneUpdate, db: Session = Depends(get_db)):
    milestone = db.query(Milestone).filter(
        Milestone.task_id == task_id,
        Milestone.milestone_number == milestone_num
    ).first()
    if not milestone:
        raise HTTPException(status_code=404, detail="Milestone not found")

    update_fields = milestone_data.model_dump(exclude_unset=True)
    for field, value in update_fields.items():
        setattr(milestone, field, value)

    db.commit()
    db.refresh(milestone)
    return build_milestone_response(milestone)


# --- Progress Comments ---

@router.post("/{task_id}/comments", response_model=ProgressCommentResponse, status_code=201)
def add_progress_comment(task_id: int, comment_data: ProgressCommentCreate, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    comment = ProgressComment(
        task_id=task_id,
        comment_text=comment_data.comment_text,
        submitted_by=comment_data.submitted_by
    )
    db.add(comment)
    db.commit()
    db.refresh(comment)
    return comment


@router.get("/{task_id}/comments", response_model=List[ProgressCommentResponse])
def get_progress_comments(task_id: int, db: Session = Depends(get_db)):
    comments = db.query(ProgressComment).filter(
        ProgressComment.task_id == task_id
    ).order_by(ProgressComment.created_at.desc()).all()
    return comments


# --- Dependencies ---

@router.post("/dependencies", response_model=DependencyResponse, status_code=201)
def create_dependency(dep_data: DependencyCreate, db: Session = Depends(get_db)):
    # Validate tasks exist
    predecessor = db.query(Task).filter(Task.id == dep_data.predecessor_id).first()
    successor = db.query(Task).filter(Task.id == dep_data.successor_id).first()
    if not predecessor or not successor:
        raise HTTPException(status_code=404, detail="One or both tasks not found")

    if dep_data.predecessor_id == dep_data.successor_id:
        raise HTTPException(status_code=400, detail="A task cannot depend on itself")

    # Check for circular dependency (simple check)
    existing_reverse = db.query(TaskDependency).filter(
        TaskDependency.predecessor_id == dep_data.successor_id,
        TaskDependency.successor_id == dep_data.predecessor_id
    ).first()
    if existing_reverse:
        raise HTTPException(status_code=400, detail="Circular dependencies are not allowed")

    dependency = TaskDependency(
        predecessor_id=dep_data.predecessor_id,
        successor_id=dep_data.successor_id
    )
    db.add(dependency)
    db.commit()
    db.refresh(dependency)
    return dependency


@router.get("/{task_id}/dependencies")
def get_task_dependencies(task_id: int, db: Session = Depends(get_db)):
    predecessors = db.query(TaskDependency).filter(TaskDependency.successor_id == task_id).all()
    successors = db.query(TaskDependency).filter(TaskDependency.predecessor_id == task_id).all()
    return {
        "predecessors": [{"id": d.id, "task_id": d.predecessor_id} for d in predecessors],
        "successors": [{"id": d.id, "task_id": d.successor_id} for d in successors]
    }


@router.delete("/dependencies/{dep_id}")
def delete_dependency(dep_id: int, db: Session = Depends(get_db)):
    dep = db.query(TaskDependency).filter(TaskDependency.id == dep_id).first()
    if not dep:
        raise HTTPException(status_code=404, detail="Dependency not found")
    db.delete(dep)
    db.commit()
    return {"message": "Dependency deleted successfully"}


# --- Export ---

@router.get("/export/csv")
def export_csv(db: Session = Depends(get_db)):
    tasks = db.query(Task).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Name", "Type", "PoC", "Description", "Status",
        "Milestone 1 Date", "Milestone 1 Desc",
        "Milestone 2 Date", "Milestone 2 Desc",
        "Milestone 3 Date", "Milestone 3 Desc",
        "Milestone 4 Date", "Milestone 4 Desc",
        "Milestone 5 Date", "Milestone 5 Desc",
        "Completion Date", "Latest Progress Comment"
    ])

    for task in tasks:
        milestones = sorted(task.milestones, key=lambda m: m.milestone_number)
        ms_data = []
        for i in range(1, 6):
            ms = next((m for m in milestones if m.milestone_number == i), None)
            ms_data.append(str(ms.target_date) if ms and ms.target_date else "")
            ms_data.append(ms.description if ms else "")

        latest_comment = ""
        if task.progress_comments:
            sorted_comments = sorted(task.progress_comments, key=lambda c: c.created_at or datetime.min, reverse=True)
            latest_comment = sorted_comments[0].comment_text if sorted_comments else ""

        writer.writerow([
            task.name, task.type, task.poc_name, task.description, task.status,
            *ms_data,
            str(task.completion_date) if task.completion_date else "",
            latest_comment
        ])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=flowdesk_export.csv"}
    )
