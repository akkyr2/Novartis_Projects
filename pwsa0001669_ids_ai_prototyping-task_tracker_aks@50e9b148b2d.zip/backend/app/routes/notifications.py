from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import date

from app.database import get_db
from app.models import Notification, Task, Milestone
from app.schemas import NotificationResponse

router = APIRouter()


@router.get("", response_model=List[NotificationResponse])
def get_notifications(user: str = None, db: Session = Depends(get_db)):
    query = db.query(Notification).order_by(Notification.created_at.desc())
    return query.all()


@router.post("/generate")
def generate_notifications(db: Session = Depends(get_db)):
    """Generate notifications for approaching and overdue milestones."""
    today = date.today()
    tasks = db.query(Task).filter(Task.status != "Completed").all()
    generated = 0

    for task in tasks:
        for milestone in task.milestones:
            if not milestone.target_date or milestone.is_completed:
                continue

            days_remaining = (milestone.target_date - today).days

            # Approaching milestone (within 3 days)
            if 0 <= days_remaining <= 3:
                notification = Notification(
                    task_id=task.id,
                    task_name=task.name,
                    milestone_description=milestone.description,
                    milestone_date=milestone.target_date,
                    notification_type="reminder"
                )
                db.add(notification)
                generated += 1

            # Overdue milestone
            elif days_remaining < 0:
                notification = Notification(
                    task_id=task.id,
                    task_name=task.name,
                    milestone_description=milestone.description,
                    milestone_date=milestone.target_date,
                    notification_type="overdue"
                )
                db.add(notification)
                generated += 1

    db.commit()
    return {"message": f"Generated {generated} notifications"}


@router.put("/{notification_id}/read")
def mark_read(notification_id: int, db: Session = Depends(get_db)):
    notif = db.query(Notification).filter(Notification.id == notification_id).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")
    notif.is_read = True
    db.commit()
    return {"message": "Notification marked as read"}
