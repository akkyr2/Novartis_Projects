from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date

from app.database import get_db
from app.models import Task, Milestone
from app.schemas import SummaryReport

router = APIRouter()


@router.get("/summary", response_model=SummaryReport)
def get_summary_report(db: Session = Depends(get_db)):
    if db is None:
        return SummaryReport(total_tasks=0, tasks_by_status={}, tasks_by_type={}, overdue_count=0)
    total_tasks = db.query(Task).count()

    # Tasks by status
    status_counts = db.query(Task.status, func.count(Task.id)).group_by(Task.status).all()
    tasks_by_status = {status: count for status, count in status_counts}

    # Tasks by type
    type_counts = db.query(Task.type, func.count(Task.id)).group_by(Task.type).all()
    tasks_by_type = {t: count for t, count in type_counts}

    # Overdue count
    today = date.today()
    overdue_tasks = db.query(Task).join(Milestone).filter(
        Task.status != "Completed",
        Milestone.target_date < today,
        Milestone.is_completed == False
    ).distinct().count()

    return SummaryReport(
        total_tasks=total_tasks,
        tasks_by_status=tasks_by_status,
        tasks_by_type=tasks_by_type,
        overdue_count=overdue_tasks
    )
