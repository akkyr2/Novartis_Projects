from sqlalchemy import Column, Integer, String, Text, Date, DateTime, Boolean, ForeignKey, Enum as SQLEnum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base
import enum


class TaskStatus(str, enum.Enum):
    NOT_STARTED = "Not Started"
    IN_PROGRESS = "In-Progress"
    COMPLETED = "Completed"


class TaskType(str, enum.Enum):
    PROJECT = "Project"
    ACCESS_REQUEST = "Access Request"
    TECH_SPIKE = "Tech Spike"
    DOCUMENTATION = "Documentation"
    OTHERS = "Others"


class UserRole(str, enum.Enum):
    MEMBER = "member"
    LEADERSHIP = "leadership"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    full_name = Column(String(200), nullable=False)
    role = Column(String(20), default="member")
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    tasks = relationship("Task", back_populates="owner")


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(300), nullable=False)
    type = Column(String(50), nullable=False)
    poc_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    poc_name = Column(String(200), nullable=True)
    description = Column(Text, nullable=True)
    comment = Column(Text, nullable=True)
    status = Column(String(20), default="Not Started")
    completion_date = Column(Date, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    owner = relationship("User", back_populates="tasks")
    milestones = relationship("Milestone", back_populates="task", cascade="all, delete-orphan", order_by="Milestone.milestone_number")
    progress_comments = relationship("ProgressComment", back_populates="task", cascade="all, delete-orphan", order_by="ProgressComment.created_at.desc()")
    dependencies_as_successor = relationship("TaskDependency", foreign_keys="TaskDependency.successor_id", back_populates="successor", cascade="all, delete-orphan")
    dependencies_as_predecessor = relationship("TaskDependency", foreign_keys="TaskDependency.predecessor_id", back_populates="predecessor", cascade="all, delete-orphan")


class Milestone(Base):
    __tablename__ = "milestones"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    milestone_number = Column(Integer, nullable=False)
    target_date = Column(Date, nullable=True)
    description = Column(Text, nullable=True)
    is_completed = Column(Boolean, default=False)

    task = relationship("Task", back_populates="milestones")


class ProgressComment(Base):
    __tablename__ = "progress_comments"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    comment_text = Column(Text, nullable=False)
    submitted_by = Column(String(200), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    task = relationship("Task", back_populates="progress_comments")


class TaskDependency(Base):
    __tablename__ = "task_dependencies"

    id = Column(Integer, primary_key=True, index=True)
    predecessor_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    successor_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)

    predecessor = relationship("Task", foreign_keys=[predecessor_id], back_populates="dependencies_as_predecessor")
    successor = relationship("Task", foreign_keys=[successor_id], back_populates="dependencies_as_successor")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    task_name = Column(String(300), nullable=False)
    milestone_description = Column(Text, nullable=True)
    milestone_date = Column(Date, nullable=True)
    notification_type = Column(String(20), nullable=False)  # "reminder" or "overdue"
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ActivityLog(Base):
    __tablename__ = "activity_log"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    field_changed = Column(String(100), nullable=False)
    old_value = Column(Text, nullable=True)
    new_value = Column(Text, nullable=True)
    changed_by = Column(String(200), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class WeeklyReport(Base):
    __tablename__ = "weekly_reports"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    week_ending = Column(Date, nullable=False)
    generated_comment = Column(Text, nullable=False)
    raw_input = Column(Text, nullable=True)
    generated_at = Column(DateTime(timezone=True), server_default=func.now())
