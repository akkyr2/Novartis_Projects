from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import date, datetime


# --- User Schemas ---
class UserCreate(BaseModel):
    username: str
    full_name: str
    role: str = "member"


class UserResponse(BaseModel):
    id: int
    username: str
    full_name: str
    role: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# --- Milestone Schemas ---
class MilestoneCreate(BaseModel):
    milestone_number: int = Field(ge=1, le=5)
    target_date: Optional[date] = None
    description: Optional[str] = None


class MilestoneUpdate(BaseModel):
    target_date: Optional[date] = None
    description: Optional[str] = None
    is_completed: Optional[bool] = None


class MilestoneResponse(BaseModel):
    id: int
    milestone_number: int
    target_date: Optional[date] = None
    description: Optional[str] = None
    is_completed: bool
    is_overdue: bool = False
    days_remaining: Optional[int] = None

    class Config:
        from_attributes = True


# --- Progress Comment Schemas ---
class ProgressCommentCreate(BaseModel):
    comment_text: str
    submitted_by: Optional[str] = None


class ProgressCommentResponse(BaseModel):
    id: int
    comment_text: str
    submitted_by: Optional[str] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# --- Task Schemas ---
class TaskCreate(BaseModel):
    name: str
    type: str
    poc_name: Optional[str] = None
    description: Optional[str] = None
    comment: Optional[str] = None
    status: str = "Not Started"
    completion_date: Optional[date] = None
    milestones: Optional[List[MilestoneCreate]] = None


class TaskUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    poc_name: Optional[str] = None
    description: Optional[str] = None
    comment: Optional[str] = None
    status: Optional[str] = None
    completion_date: Optional[date] = None


class TaskResponse(BaseModel):
    id: int
    name: str
    type: str
    poc_name: Optional[str] = None
    description: Optional[str] = None
    comment: Optional[str] = None
    status: str
    completion_date: Optional[date] = None
    completion_percentage: int = 0
    upcoming_milestone: Optional[str] = None
    days_to_upcoming: Optional[int] = None
    is_overdue: bool = False
    milestones: List[MilestoneResponse] = []
    progress_comments: List[ProgressCommentResponse] = []
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# --- Dependency Schemas ---
class DependencyCreate(BaseModel):
    predecessor_id: int
    successor_id: int


class DependencyResponse(BaseModel):
    id: int
    predecessor_id: int
    successor_id: int

    class Config:
        from_attributes = True


# --- Notification Schemas ---
class NotificationResponse(BaseModel):
    id: int
    task_name: str
    milestone_description: Optional[str] = None
    milestone_date: Optional[date] = None
    notification_type: str
    is_read: bool
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# --- Report Schemas ---
class SummaryReport(BaseModel):
    total_tasks: int
    tasks_by_status: dict
    tasks_by_type: dict
    overdue_count: int
