"""
FlowDesk Weekly Report Generation Job
Runs every Friday evening to generate LLM-based progress comments
and optionally email the report to stakeholders.

Usage:
    python -m app.services.weekly_report_job          # Generate for current week
    python -m app.services.weekly_report_job --dry-run  # Preview without saving
"""
import os
import sys
from datetime import date, datetime, timedelta
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

# Add parent to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

load_dotenv()

from app.models import Task, ProgressComment, ActivityLog, WeeklyReport, Milestone
from app.services.llm_service import generate_weekly_comment, build_prompt_input
from app.config import DATABASE_URL

engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)


def get_current_week_range(reference_date=None):
    """Get Monday-Friday range for the current week."""
    today = reference_date or date.today()
    # Find this week's Monday
    monday = today - timedelta(days=today.weekday())
    # Friday is Monday + 4
    friday = monday + timedelta(days=4)
    return monday, friday


def get_task_activity_this_week(session, task_id, week_start, week_end):
    """Get all activity log entries for a task within the week."""
    activities = session.query(ActivityLog).filter(
        ActivityLog.task_id == task_id,
        ActivityLog.created_at >= datetime.combine(week_start, datetime.min.time()),
        ActivityLog.created_at <= datetime.combine(week_end, datetime.max.time())
    ).order_by(ActivityLog.created_at).all()
    
    return [f"{a.field_changed}: {a.old_value or 'N/A'} → {a.new_value or 'N/A'}" for a in activities]


def get_task_comments_this_week(session, task_id, week_start, week_end):
    """Get all PoC comments for a task within the week."""
    comments = session.query(ProgressComment).filter(
        ProgressComment.task_id == task_id,
        ProgressComment.created_at >= datetime.combine(week_start, datetime.min.time()),
        ProgressComment.created_at <= datetime.combine(week_end, datetime.max.time())
    ).order_by(ProgressComment.created_at).all()
    
    return [c.comment_text for c in comments]


def get_milestone_updates_this_week(session, task_id, week_start, week_end):
    """Check for milestone changes this week (completed, date changes)."""
    # For now, check milestones with target_date in this week range
    milestones = session.query(Milestone).filter(
        Milestone.task_id == task_id
    ).all()
    
    updates = []
    for m in milestones:
        if m.is_completed and m.target_date:
            if week_start <= m.target_date <= week_end:
                updates.append(f"MS{m.milestone_number} completed: {m.description or 'N/A'}")
        elif m.target_date and week_start <= m.target_date <= week_end:
            updates.append(f"MS{m.milestone_number} due this week: {m.description or 'N/A'}")
    
    return updates


def generate_weekly_reports(dry_run=False, reference_date=None):
    """
    Main job: generate weekly reports for all tasks with activity this week.
    
    Args:
        dry_run: If True, print output but don't save to DB
        reference_date: Override today's date (useful for testing)
    """
    session = Session()
    week_start, week_end = get_current_week_range(reference_date)
    
    print(f"\nFlowDesk Weekly Report Generation")
    print(f"{'=' * 50}")
    print(f"Week: {week_start} (Mon) → {week_end} (Fri)")
    print(f"Mode: {'DRY RUN' if dry_run else 'LIVE'}")
    print(f"{'=' * 50}\n")
    
    # Get all active tasks (not completed)
    tasks = session.query(Task).filter(Task.status != "Completed").all()
    
    generated_count = 0
    skipped_count = 0
    
    for task in tasks:
        # Gather this week's data
        activity_changes = get_task_activity_this_week(session, task.id, week_start, week_end)
        raw_comments = get_task_comments_this_week(session, task.id, week_start, week_end)
        milestone_updates = get_milestone_updates_this_week(session, task.id, week_start, week_end)
        
        # Skip if no activity this week
        if not activity_changes and not raw_comments and not milestone_updates:
            skipped_count += 1
            continue
        
        print(f"📝 Task: {task.name}")
        print(f"   Activity: {len(activity_changes)} changes, {len(raw_comments)} comments, {len(milestone_updates)} milestone updates")
        
        # Generate LLM comment
        generated_comment = generate_weekly_comment(
            task_name=task.name,
            task_type=task.type,
            poc_name=task.poc_name or "Unknown",
            status=task.status,
            raw_poc_comments=raw_comments,
            activity_changes=activity_changes,
            milestone_updates=milestone_updates
        )
        
        if generated_comment:
            print(f"   Generated: {generated_comment[:80]}...")
            
            if not dry_run:
                # Check if report already exists for this task/week
                existing = session.query(WeeklyReport).filter(
                    WeeklyReport.task_id == task.id,
                    WeeklyReport.week_ending == week_end
                ).first()
                
                raw_input = build_prompt_input(
                    task.name, task.type, task.poc_name, task.status,
                    raw_comments, activity_changes, milestone_updates
                )
                
                if existing:
                    existing.generated_comment = generated_comment
                    existing.raw_input = raw_input
                    existing.generated_at = datetime.utcnow()
                else:
                    report = WeeklyReport(
                        task_id=task.id,
                        week_ending=week_end,
                        generated_comment=generated_comment,
                        raw_input=raw_input
                    )
                    session.add(report)
                
            generated_count += 1
        else:
            print(f"   ⚠️ LLM generation failed, skipping")
            skipped_count += 1
        
        print()
    
    if not dry_run:
        session.commit()
    
    session.close()
    
    print(f"\n{'=' * 50}")
    print(f"Summary: {generated_count} reports generated, {skipped_count} tasks skipped")
    print(f"{'=' * 50}\n")
    
    return generated_count


if __name__ == "__main__":
    dry_run = "--dry-run" in sys.argv
    generate_weekly_reports(dry_run=dry_run)
