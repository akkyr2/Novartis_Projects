"""
FlowDesk LLM Service
Generates stakeholder-ready weekly progress comments using AWS Bedrock (Claude).
"""
import os
import json
import boto3
from typing import Optional

# Configuration
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-haiku-20240307-v1:0")


def get_bedrock_client():
    """Create Bedrock runtime client."""
    return boto3.client(
        "bedrock-runtime",
        region_name=AWS_REGION
    )


def generate_weekly_comment(
    task_name: str,
    task_type: str,
    poc_name: str,
    status: str,
    raw_poc_comments: list[str],
    activity_changes: list[str],
    milestone_updates: list[str]
) -> Optional[str]:
    """
    Generate a stakeholder-ready weekly progress comment using LLM.
    
    Args:
        task_name: Name of the task
        task_type: Type (Project, Access Request, etc.)
        poc_name: Person of contact
        status: Current status
        raw_poc_comments: List of raw comments added by PoC this week
        activity_changes: List of field changes (e.g., "Status: Not Started → In-Progress")
        milestone_updates: List of milestone changes (e.g., "MS1 completed on 05/26")
    
    Returns:
        Generated stakeholder-ready comment string, or None if LLM call fails.
    """
    
    # Build the prompt
    raw_input = build_prompt_input(
        task_name, task_type, poc_name, status,
        raw_poc_comments, activity_changes, milestone_updates
    )
    
    prompt = f"""You are a project management assistant. Generate a concise weekly progress comment for stakeholder reporting.

Rules:
- Keep it concise: 2-5 bullet points maximum
- Use professional tone suitable for leadership/stakeholder review
- Start each point with "- " (dash space)
- Focus on: achievements, current status, blockers, and next steps
- Do NOT add greetings, signatures, or formatting beyond bullet points
- If there's minimal activity, keep it to 1-2 bullets

Task: "{task_name}"
Type: {task_type}
PoC: {poc_name}
Current Status: {status}

This week's activity:
{raw_input}

Generate the stakeholder-ready progress comment:"""

    try:
        client = get_bedrock_client()
        
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 300,
            "temperature": 0.5,
            "messages": [
                {"role": "user", "content": prompt}
            ]
        })
        
        response = client.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            body=body,
            contentType="application/json",
            accept="application/json"
        )
        
        response_body = json.loads(response["body"].read())
        generated_text = response_body["content"][0]["text"].strip()
        
        return generated_text
        
    except Exception as e:
        print(f"LLM generation failed for task '{task_name}': {e}")
        # Fallback: return raw comments concatenated
        if raw_poc_comments:
            return "\n".join(f"- {c}" for c in raw_poc_comments)
        return None


def build_prompt_input(
    task_name, task_type, poc_name, status,
    raw_poc_comments, activity_changes, milestone_updates
) -> str:
    """Build the raw input section of the prompt."""
    sections = []
    
    if activity_changes:
        sections.append("System changes:")
        for change in activity_changes:
            sections.append(f"  - {change}")
    
    if milestone_updates:
        sections.append("Milestone updates:")
        for update in milestone_updates:
            sections.append(f"  - {update}")
    
    if raw_poc_comments:
        sections.append("PoC comments:")
        for comment in raw_poc_comments:
            sections.append(f"  - {comment}")
    
    if not sections:
        sections.append("No significant activity recorded this week.")
    
    return "\n".join(sections)
