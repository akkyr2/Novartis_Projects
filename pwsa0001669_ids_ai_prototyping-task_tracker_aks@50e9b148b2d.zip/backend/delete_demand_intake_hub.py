"""
Delete all 'Demand Intake Hub' tasks and their related records from the database.
Run from the backend directory:
    cd /home/sagemaker-user/flowdesk_satya_4_8_26/backend
    python delete_demand_intake_hub.py
"""
import sys
sys.path.insert(0, '.')

from app.config import DATABASE_URL
from sqlalchemy import create_engine, text

if not DATABASE_URL:
    print("ERROR: No DATABASE_URL configured. Check your .env file.")
    sys.exit(1)

engine = create_engine(DATABASE_URL)

with engine.connect() as conn:
    # First, find the tasks
    result = conn.execute(text("SELECT id, name, poc_name, type FROM tasks WHERE name ILIKE '%Demand Intake Hub%'"))
    tasks = result.fetchall()

    if not tasks:
        print("No 'Demand Intake Hub' tasks found in the database.")
        sys.exit(0)

    print(f"Found {len(tasks)} 'Demand Intake Hub' task(s):")
    for t in tasks:
        print(f"  ID={t[0]} | Name={t[1]} | PoC={t[2]} | Type={t[3]}")

    task_ids = [t[0] for t in tasks]
    id_list = ','.join(str(i) for i in task_ids)

    # Delete related records first (foreign key constraints)
    r1 = conn.execute(text(f"DELETE FROM progress_comments WHERE task_id IN ({id_list})"))
    print(f"  Deleted {r1.rowcount} progress comments")

    r2 = conn.execute(text(f"DELETE FROM milestones WHERE task_id IN ({id_list})"))
    print(f"  Deleted {r2.rowcount} milestones")

    r3 = conn.execute(text(f"DELETE FROM weekly_reports WHERE task_id IN ({id_list})"))
    print(f"  Deleted {r3.rowcount} weekly reports")

    # Delete the tasks themselves
    r4 = conn.execute(text(f"DELETE FROM tasks WHERE id IN ({id_list})"))
    print(f"  Deleted {r4.rowcount} tasks")

    conn.commit()

print("\nDone. Both 'Demand Intake Hub' tasks have been removed.")
print("You can now re-upload the Excel sheet to get them back correctly.")
