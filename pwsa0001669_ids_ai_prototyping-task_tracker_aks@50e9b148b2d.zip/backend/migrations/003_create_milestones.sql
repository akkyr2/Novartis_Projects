-- Migration 003: Create milestones table
CREATE TABLE IF NOT EXISTS milestones (
    id SERIAL PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    milestone_number INTEGER NOT NULL,
    target_date DATE,
    description TEXT,
    is_completed BOOLEAN DEFAULT FALSE,
    UNIQUE (task_id, milestone_number)
);

CREATE INDEX IF NOT EXISTS idx_milestones_task_id ON milestones(task_id);
CREATE INDEX IF NOT EXISTS idx_milestones_target_date ON milestones(target_date);
