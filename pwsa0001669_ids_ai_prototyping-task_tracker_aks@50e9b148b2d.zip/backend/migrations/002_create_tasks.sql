-- Migration 002: Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id SERIAL PRIMARY KEY,
    name VARCHAR(300) NOT NULL,
    type VARCHAR(50) NOT NULL,
    poc_id INTEGER REFERENCES users(id),
    poc_name VARCHAR(200),
    description TEXT,
    comment TEXT,
    status VARCHAR(20) DEFAULT 'Not Started',
    completion_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_type ON tasks(type);
CREATE INDEX IF NOT EXISTS idx_tasks_poc_name ON tasks(poc_name);
