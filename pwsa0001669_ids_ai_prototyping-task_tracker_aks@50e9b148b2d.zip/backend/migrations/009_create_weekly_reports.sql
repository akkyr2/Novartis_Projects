-- Migration 009: Create weekly_reports table
-- Stores LLM-generated weekly summaries per task
CREATE TABLE IF NOT EXISTS weekly_reports (
    id SERIAL PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    week_ending DATE NOT NULL,
    generated_comment TEXT NOT NULL,
    raw_input TEXT,
    generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (task_id, week_ending)
);

CREATE INDEX IF NOT EXISTS idx_weekly_reports_task_id ON weekly_reports(task_id);
CREATE INDEX IF NOT EXISTS idx_weekly_reports_week_ending ON weekly_reports(week_ending);
CREATE INDEX IF NOT EXISTS idx_weekly_reports_task_week ON weekly_reports(task_id, week_ending);
