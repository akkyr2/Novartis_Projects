-- Migration 001: Create users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    role VARCHAR(20) DEFAULT 'member',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default users from the Excel data
INSERT INTO users (username, full_name, role) VALUES
    ('satya', 'Satya Shukla', 'member'),
    ('mohan', 'Mohan', 'member'),
    ('mithun', 'Mithun', 'member'),
    ('prathyusha', 'Prathyusha', 'member'),
    ('ayushh', 'Ayushh', 'member'),
    ('akhilesh', 'Akhilesh', 'member'),
    ('admin', 'Admin User', 'leadership')
ON CONFLICT (username) DO NOTHING;
