"""
FlowDesk - Refresh Data Script (Upsert Mode)
Keeps old records, updates existing tasks, adds new tasks and comments.
Run this whenever you get a new weekly Excel update.

Usage: python refresh_data.py
"""
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_USER = os.getenv("DB_USER")
DB_SECRET = os.getenv("DB_SECRET")
DB_NAME = os.getenv("DB_NAME", "flowdesk")


def get_connection():
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME,
        user=DB_USER, password=DB_SECRET, sslmode="require"
    )


def upsert_task(cursor, name, task_type, poc_name, comment, status, completion_date):
    """Insert or update a task by name. Returns task_id."""
    cursor.execute("SELECT id FROM tasks WHERE name = %s", (name,))
    row = cursor.fetchone()

    if row:
        task_id = row[0]
        cursor.execute("""
            UPDATE tasks SET type=%s, poc_name=%s, comment=%s, status=%s, completion_date=%s, updated_at=NOW()
            WHERE id=%s
        """, (task_type, poc_name, comment, status, completion_date, task_id))
        return task_id, "updated"
    else:
        cursor.execute("""
            INSERT INTO tasks (name, type, poc_name, comment, status, completion_date)
            VALUES (%s, %s, %s, %s, %s, %s) RETURNING id
        """, (name, task_type, poc_name, comment, status, completion_date))
        task_id = cursor.fetchone()[0]
        return task_id, "inserted"


def upsert_milestone(cursor, task_id, ms_num, target_date, description, is_completed):
    """Insert or update a milestone."""
    cursor.execute("""
        SELECT id FROM milestones WHERE task_id=%s AND milestone_number=%s
    """, (task_id, ms_num))
    row = cursor.fetchone()

    if row:
        cursor.execute("""
            UPDATE milestones SET target_date=%s, description=%s, is_completed=%s
            WHERE task_id=%s AND milestone_number=%s
        """, (target_date, description, is_completed, task_id, ms_num))
    else:
        cursor.execute("""
            INSERT INTO milestones (task_id, milestone_number, target_date, description, is_completed)
            VALUES (%s, %s, %s, %s, %s)
        """, (task_id, ms_num, target_date, description, is_completed))


def add_comment_if_new(cursor, task_id, comment_text, submitted_by, week_date):
    """Add comment only if no comment exists for this task in this week."""
    cursor.execute("""
        SELECT id FROM progress_comments
        WHERE task_id=%s AND created_at::date = %s
    """, (task_id, week_date))
    if not cursor.fetchone():
        cursor.execute("""
            INSERT INTO progress_comments (task_id, comment_text, submitted_by, created_at)
            VALUES (%s, %s, %s, %s)
        """, (task_id, comment_text, submitted_by, week_date + " 10:00:00+00"))


def ensure_user(cursor, username, full_name):
    """Add user if not exists."""
    cursor.execute("SELECT id FROM users WHERE username=%s", (username,))
    if not cursor.fetchone():
        cursor.execute("""
            INSERT INTO users (username, full_name, role) VALUES (%s, %s, 'member')
        """, (username, full_name))


def main():
    print("=" * 60)
    print("FlowDesk - Refresh Data (Upsert Mode - WE 07/10/2026)")
    print("=" * 60)

    conn = get_connection()
    conn.autocommit = False
    cursor = conn.cursor()

    # Ensure users
    ensure_user(cursor, "pawan", "Pawan Mane")
    ensure_user(cursor, "prathyusha", "Prathyusha")

    updated = 0
    inserted = 0

    # ============================================
    # TASK DATA FROM LATEST EXCEL (WE 07/10/2026)
    # ============================================

    tasks_data = [
        {
            "name": "Agentic Colleague - Azure",
            "type": "Project",
            "poc": "Mithun/Pawan",
            "comment": None,
            "status": "In-Progress",
            "completion_date": None,
            "milestones": [
                (1, "2026-07-08", "Deploy project code base on azure with all resources working perfectly without any permissions/roles blockers. Make sure project is in working state.", False),
            ],
            "comments_we_0703": "29th June - Script execution initiated, biceps issue got resolved. New challenge faced with policy setting. Resolved with help of Pramod by making changes in biceps file from enabled to disable for public policy. All resources created and verified on azure portal. 30th June - Role assignment approved from Pramod. RBAC permission setting initiated but faced issue with setting user level permission on resources. Reached out to Pramod who suggested adding user to ADS group. Entra ID App Registration mail sent to Prateek. 1st July - Verified user in ADS group already present. Tried multiple ways to set User level permission but did not work. Faced challenges with Entra ID creation on Azure, reached out to Pratik who shared required information. Will create ticket for Entra ID creation. 2nd July - Will connect with Azure Team (Pramod) to get user level permission issue resolved.",
            "comments_we_0710": None
        },
        {
            "name": "ABL Coaching Agent",
            "type": "Project",
            "poc": "Prathyusha",
            "comment": "FCR Draft generation to be presented for Business feedback with limited UI",
            "status": "In-Progress",
            "completion_date": "2026-06-08",
            "milestones": [
                (1, "2026-05-26", "Demo business users on flow till ABL Note creation and taking feedback", True),
                (2, "2026-06-03", "Adding new feedback from business. Completing end to end agent as per initial plan, including memory", True),
                (3, "2026-06-04", "Deployment to EC2", True),
                (4, "2026-06-08", "Demo with Business", True),
                (5, "2026-07-08", "Integrating the application on real data shared by Business, closing on demo video and documentation. Project closure with documentation", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": "Code cleanup is almost done, code review needs to be done need to work on the Documentation waiting for feedback from business"
        },
        {
            "name": "Copilot Studio Deployment",
            "type": "Access Request",
            "poc": "Mohan/Satya/Mithun",
            "comment": "Executive Meeting Planner (Event Assistant)",
            "status": "In-Progress",
            "completion_date": "2026-07-30",
            "milestones": [
                (1, "2026-05-28", "HLCCD and App ID completion", True),
                (2, "2026-07-06", "Documentation for Deployment & Sharing with AppSec for review", False),
            ],
            "comments_we_0703": "- Satya shared Architecture handbook for review\n- Mohan reviewed and provided his comments on the changes needed\n- Satya to work on incorporating feedback post which handbook will be shared with both Ajay and AppSec for review",
            "comments_we_0710": None
        },
        {
            "name": "Copilot Studio - Self Development Guide Agent",
            "type": "Access Request",
            "poc": "Mohan/Satya/Mithun",
            "comment": "Self Development Guide Agent",
            "status": "In-Progress",
            "completion_date": "2026-07-30",
            "milestones": [
                (1, "2026-06-02", "HLCCD and App ID completion", True),
                (2, "2026-07-06", "Documentation for Deployment", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "DRA62 Cost and Usage Tracking",
            "type": "Project",
            "poc": "Mithun/Akhilesh",
            "comment": "Mithun is waiting response from team",
            "status": "In-Progress",
            "completion_date": "2026-06-22",
            "milestones": [
                (1, "2026-06-08", "Initial basic report in excel on May months consumption by Service, By User and By use case", True),
                (2, "2026-06-22", "Dashboard on usage stats", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": "22/06/26: Checked all services provisioned with tag aiirp and added in excel sheet. 23/06/26: Designed cost explorer dashboard based on different filter. 24/06/26: Identified that Sagemaker Domain canvas app taking too much cost and designed holistic dashboard. 25/06/26: Discussed and gave overview to Ash and Mohan on DRA62 IDS Proto AWS services. 26/06/26: Identified AkhilS profile consuming too much cost, got his permission to delete his user-profile. 27/06/26: Now monitoring closely all services daily to make sure cost should not increase. 01/07/26: Monitoring cost dashboard."
        },
        {
            "name": "Agentify Execution Tracker for Field Insights & Analytics",
            "type": "Project",
            "poc": "Satya",
            "comment": "Copilot use case",
            "status": "In-Progress",
            "completion_date": None,
            "milestones": [
                (1, "2026-04-27", "Showing the capability PPT creation in required format", True),
                (2, "2026-05-23", "Including the capability of summarizing tracker then updating PPT", True),
                (3, "2026-06-19", "Scaling up the solution to additional trackers file and including short term and long term memory", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "Self Development Planner - Copilot Use case",
            "type": "Project",
            "poc": "Satya",
            "comment": None,
            "status": "In-Progress/On Hold",
            "completion_date": None,
            "milestones": [
                (1, "2026-06-18", "New data has been forwarded. Based on that Agent need to be updated", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "Downsizing DB",
            "type": None,
            "poc": "Mithun",
            "comment": None,
            "status": None,
            "completion_date": None,
            "milestones": [],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "Data Masking Use Case",
            "type": "Project",
            "poc": "Mohan",
            "comment": None,
            "status": "In-Progress",
            "completion_date": None,
            "milestones": [],
            "comments_we_0703": "- Shyam Vora to confirm on the tables for Masking\n- Mohan touchbased with Jayaseelan on project and seems like Jayaseelan and team are still working on resolving issue for connecting to snowflake\n- Jayaseelan to reachout to Mithun on access to source schema\n- Ash Sheth to get back on the details of the team who would do the migration of other tables\n- Still awaiting view on costing (from Ash Sheth) to finalize on sample size",
            "comments_we_0710": None
        },
        {
            "name": "TAS SMART Agent",
            "type": "Project",
            "poc": "Ayushh/Satya",
            "comment": "Timeline is subjective to changes until further discussion with Revath on Knowledge Source provisionings.",
            "status": "In-Progress",
            "completion_date": "2026-06-26",
            "milestones": [
                (1, "2026-06-16", "Integrate provided knowledge sources (Match Learn) into simple TAS agent and test the flow", True),
                (2, "2026-06-19", "Integrate other required knowledge sources into TAS Agent and make modifications based on changes recommended", True),
                (3, "2026-06-23", "Achieve final solution and implementation to building the Agent and have discussions for further updates to close it by 26th", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "Data Masking Snowflake access",
            "type": "Project",
            "poc": "Mithun",
            "comment": None,
            "status": None,
            "completion_date": "2026-07-10",
            "milestones": [],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "FlowDesk",
            "type": "Project",
            "poc": "Akhilesh",
            "comment": "Task tracking system with weekly summarization based on task updates and comments",
            "status": "In-Progress",
            "completion_date": None,
            "milestones": [
                (1, "2026-06-06", "Requirement gathering and initial design of task tracking system", True),
                (2, "2026-06-13", "Development of core task logging and comment tracking features", True),
                (3, "2026-06-20", "Implementation of weekly summarization logic based on task updates/comments", True),
                (4, "2026-06-27", "UI refinement and end-to-end testing", False),
                (5, None, "Deployment and final validation", False),
            ],
            "comments_we_0703": "Deployment to environment",
            "comments_we_0710": "29/06/2026: Bitbucket migration completed and EC2 deployment setup initiated. 30/06/2026: EC2 deployment in progress; resolved repository and access/password-related issues. 1/7/2026: Deployment completed and Docker .env configuration issue fixed. 2/7/2026: Shared application URL, working on UI enhancements and data validation fixes."
        },
        {
            "name": "Langsmith",
            "type": None,
            "poc": None,
            "comment": None,
            "status": None,
            "completion_date": None,
            "milestones": [],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "Sagemaker drift issue",
            "type": "Project",
            "poc": "Mithun",
            "comment": None,
            "status": "In Progress",
            "completion_date": "2026-07-08",
            "milestones": [],
            "comments_we_0703": None,
            "comments_we_0710": "01/07/26: Checked all user profiles inside pwsa000 1669 domain and noticed more than 50 user profile present. As we need to send all user to ask them to take their data backup so user list is ready. 02/07/26: AWS ticket is raised to get all instance level information so waiting for AWS team to get back to me."
        },
        {
            "name": "Agentic Colleague - AWS v2 - Graph API Integration",
            "type": "Project",
            "poc": "Pawan",
            "comment": None,
            "status": "Not Started",
            "completion_date": None,
            "milestones": [
                (1, "2026-07-10", "Graph API environment setup, Data Schema Structuring and Development approach finalize", False),
                (2, "2026-07-17", "Establishing connection to GraphApi through pipeline, Organizing Data, Data Cleaning, Storing on S3 with Incremental Approach", False),
                (3, "2026-07-24", "Replace with current document upload logic with user selection for project setting of GraphApi", False),
                (4, "2026-07-31", "Provision to onboard any project and user selection on chat application", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
        {
            "name": "Devops Adhoc tasks",
            "type": "Project",
            "poc": "Mithun",
            "comment": "Tracking all Devops request from onshore/offshore team",
            "status": "In Progress",
            "completion_date": "2026-07-10",
            "milestones": [],
            "comments_we_0703": None,
            "comments_we_0710": "30/06/26: -\n01/07/26: Had a call with Ehsan to fix his Jira issue.\n02/07/26: Ticket raised for Sebastian to get access to him IDS Proto workspace. Had a call with Langsmith"
        },
        {
            "name": "Langsmith - Bedrock AgentCore",
            "type": "Project",
            "poc": "Prathyusha",
            "comment": "Setting up bedrock agentcore runtime and strands in DRA62",
            "status": "Started",
            "completion_date": None,
            "milestones": [
                (1, "2026-07-08", "Baseline AWS Bedrock AgentCore + Strands Pilot Setup", False),
                (2, "2026-07-15", "LangSmith Observability Integration", False),
                (3, "2026-07-22", "Evaluation and Tool Comparison", False),
                (4, "2026-07-29", "OpenTelemetry Validation and Final Recommendation", False),
            ],
            "comments_we_0703": None,
            "comments_we_0710": None
        },
    ]

    # ============================================
    # PROCESS EACH TASK
    # ============================================

    for task in tasks_data:
        task_id, action = upsert_task(
            cursor, task["name"], task["type"], task["poc"],
            task["comment"], task["status"], task["completion_date"]
        )

        if action == "updated":
            updated += 1
        else:
            inserted += 1

        print(f"  {'✏️' if action == 'updated' else '➕'} {action.upper()}: {task['name']} (id={task_id})")

        # Milestones
        for ms in task.get("milestones", []):
            ms_num, ms_date, ms_desc, ms_done = ms
            upsert_milestone(cursor, task_id, ms_num, ms_date, ms_desc, ms_done)

        # WE 07/03 comment
        if task.get("comments_we_0703"):
            add_comment_if_new(cursor, task_id, task["comments_we_0703"], task["poc"], "2026-07-03")

        # WE 07/10 comment
        if task.get("comments_we_0710"):
            add_comment_if_new(cursor, task_id, task["comments_we_0710"], task["poc"], "2026-07-10")

    conn.commit()

    # ============================================
    # VERIFY
    # ============================================

    print("\n" + "=" * 60)
    print(f"Results: {inserted} new tasks inserted, {updated} tasks updated")
    print("=" * 60)

    cursor.execute("SELECT count(*) FROM tasks")
    print(f"  Total tasks in DB: {cursor.fetchone()[0]}")
    cursor.execute("SELECT count(*) FROM milestones")
    print(f"  Total milestones: {cursor.fetchone()[0]}")
    cursor.execute("SELECT count(*) FROM progress_comments")
    print(f"  Total comments: {cursor.fetchone()[0]}")

    cursor.close()
    conn.close()

    print("\n✅ Done! Restart uvicorn to see updated data.")
    print("   pkill -f uvicorn")
    print("   uvicorn app.main:app --host 0.0.0.0 --port 8200 &")


if __name__ == "__main__":
    main()
