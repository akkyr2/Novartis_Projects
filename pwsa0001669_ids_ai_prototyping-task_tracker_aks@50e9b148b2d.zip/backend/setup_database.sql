-- ============================================
-- FlowDesk - Complete Database Setup Script
-- Run this in psql or pgAdmin to set up everything
-- ============================================

-- Step 1: Create the database (run this separately if needed)
-- CREATE DATABASE flowdesk;

-- Step 2: Connect to flowdesk database, then run everything below
-- \c flowdesk

-- ============================================
-- TABLES
-- ============================================

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    role VARCHAR(20) DEFAULT 'member',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tasks (
    id SERIAL PRIMARY KEY,
    name VARCHAR(300) NOT NULL,
    type VARCHAR(50) NOT NULL,
    poc_id INTEGER REFERENCES users(id),
    poc_name VARCHAR(200),
    description TEXT,
    comment TEXT,
    status VARCHAR(20) DEFAULT 'Not Started',
    completion_date DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE IF NOT EXISTS milestones (
    id SERIAL PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    milestone_number INTEGER NOT NULL,
    target_date DATE,
    description TEXT,
    is_completed BOOLEAN DEFAULT FALSE,
    UNIQUE (task_id, milestone_number)
);

CREATE TABLE IF NOT EXISTS progress_comments (
    id SERIAL PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    comment_text TEXT NOT NULL,
    submitted_by VARCHAR(200),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS task_dependencies (
    id SERIAL PRIMARY KEY,
    predecessor_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    successor_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    UNIQUE (predecessor_id, successor_id)
);

CREATE TABLE IF NOT EXISTS notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    task_name VARCHAR(300) NOT NULL,
    milestone_description TEXT,
    milestone_date DATE,
    notification_type VARCHAR(20) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS activity_log (
    id SERIAL PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    field_changed VARCHAR(100) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    changed_by VARCHAR(200),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS weekly_reports (
    id SERIAL PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    week_ending DATE NOT NULL,
    generated_comment TEXT NOT NULL,
    raw_input TEXT,
    generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE (task_id, week_ending)
);

CREATE TABLE IF NOT EXISTS migrations_history (
    id SERIAL PRIMARY KEY,
    filename VARCHAR(255) NOT NULL UNIQUE,
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- INDEXES
-- ============================================

CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_type ON tasks(type);
CREATE INDEX IF NOT EXISTS idx_tasks_poc_name ON tasks(poc_name);
CREATE INDEX IF NOT EXISTS idx_milestones_task_id ON milestones(task_id);
CREATE INDEX IF NOT EXISTS idx_milestones_target_date ON milestones(target_date);
CREATE INDEX IF NOT EXISTS idx_progress_comments_task_id ON progress_comments(task_id);
CREATE INDEX IF NOT EXISTS idx_task_deps_predecessor ON task_dependencies(predecessor_id);
CREATE INDEX IF NOT EXISTS idx_task_deps_successor ON task_dependencies(successor_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_activity_log_task_id ON activity_log(task_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_created_at ON activity_log(created_at);
CREATE INDEX IF NOT EXISTS idx_weekly_reports_task_id ON weekly_reports(task_id);
CREATE INDEX IF NOT EXISTS idx_weekly_reports_week_ending ON weekly_reports(week_ending);

-- ============================================
-- SEED DATA (matching demo data from demoData.js)
-- ============================================

-- Users
INSERT INTO users (username, full_name, role) VALUES
    ('satya', 'Satya Shukla', 'member'),
    ('mohan', 'Mohan', 'member'),
    ('mithun', 'Mithun', 'member'),
    ('prathyusha', 'Prathyusha', 'member'),
    ('ayushh', 'Ayushh', 'member'),
    ('akhilesh', 'Akhilesh', 'member'),
    ('admin', 'Admin User', 'leadership')
ON CONFLICT (username) DO NOTHING;

-- Tasks
INSERT INTO tasks (id, name, type, poc_name, description, comment, status, completion_date) VALUES
(1, 'Agentic Colleague - AWS', 'Project', 'Satya', NULL, NULL, 'In-Progress', NULL),
(2, 'Agentic Colleague - Azure', 'Project', 'Satya/Mohan', NULL, NULL, 'Not Started', NULL),
(3, 'Agentic Colleague - Graph API Request', 'Access Request', 'Mithun/Mohan', NULL, NULL, 'In-Progress', NULL),
(4, 'ABL Coaching Agent', 'Project', 'Prathyusha', 'FCR Draft generation to be presented for Business feedback with limited UI', 'FCR Draft generation to be presented for Business feedback with limited UI', 'In-Progress', '2026-06-08'),
(5, 'KIRO Access to the team', 'Access Request', 'Mithun', 'Mithun to setup connect with Entire team AWS, Ash/Revath and Internal team on KIRO setup', 'Mithun to setup connect with Entire team AWS, Ash/Revath and Internal team on KIRO setup', 'In-Progress', '2026-06-27'),
(6, 'SLM Confluence Update', 'Others', 'Prathyusha/Mohan', 'Mohan will complete today', 'Mohan will complete today', 'Completed', '2026-05-22'),
(7, 'Copilot Studio Deployment', 'Access Request', 'Mohan/Satya/Mithun', 'Executive Meeting Planner (Event Assistant)', 'Executive Meeting Planner (Event Assistant)', 'In-Progress', '2026-06-15'),
(8, 'Copilot Studio - Self Development Guide Agent', 'Access Request', 'Mohan/Satya/Mithun', 'Self Development Guide Agent', 'Self Development Guide Agent', 'In-Progress', NULL),
(9, 'DRA62 Cost and Usage Tracking', 'Project', 'Mithun/Akhilesh', 'Mithun is waiting response from team', 'Mithun is waiting response from team', 'In-Progress', '2026-06-22'),
(10, 'Agentify Execution Tracker for Field Insights & Analytics', 'Project', 'Satya', 'Copilot use case for summarizing tracker and creating PPTs', NULL, 'In-Progress', NULL),
(11, 'Self Development Planner - Copilot Use case', 'Project', 'Satya', NULL, NULL, 'In-Progress', NULL),
(12, 'Downsizing DB', 'Project', 'Mithun', NULL, NULL, 'In-Progress', NULL),
(13, 'Voice-IQ - Documentation', 'Documentation', 'Ayushh', 'Create documentation for Voice-IQ covering features and capabilities and get it reviewed', 'Create documentation for Voice-IQ covering features and capabilities and get it reviewed', 'In-Progress', NULL),
(14, 'Voice-IQ Email Trigger Langfuse (SMTP & SNS) from EC2', 'Tech Spike', 'Ayushh', 'Deploy application and test email trigger on Voice-IQ app launch and downstream applications', 'Deploy application and test email trigger on Voice-IQ app launch and downstream applications', 'In-Progress', NULL),
(15, 'Voice Estimations for MVP', 'Project', 'Mohan', NULL, NULL, 'In-Progress', NULL),
(16, 'Norstella EHR', 'Project', 'Ayushh', 'Waiting for John Qu to provide updates on further data ingestion and closure.', 'Waiting for John Qu to provide updates on further data ingestion and closure.', 'In-Progress', NULL),
(17, 'Data Masking Use Case', 'Project', 'Mohan', 'Data masking implementation review and finalization', NULL, 'In-Progress', NULL);

-- Reset sequence
SELECT setval('tasks_id_seq', (SELECT MAX(id) FROM tasks));

-- Milestones
INSERT INTO milestones (task_id, milestone_number, target_date, description, is_completed) VALUES
-- Task 1: Agentic Colleague AWS
(1, 1, '2026-05-19', 'First look demo with Stan on basic application flow and agent overview', true),
(1, 2, '2026-06-02', 'Demo with IPST team', true),
(1, 3, '2026-06-09', 'Final Demo', false),
-- Task 4: ABL Coaching Agent
(4, 1, '2026-05-26', 'Demo business users on flow till ABL Note creation and taking feedback', true),
(4, 2, '2026-06-03', 'Adding new feedback from business. Completing end to end agent as per initial plan, including memory', true),
(4, 3, '2026-06-04', 'Deployment to EC2', true),
(4, 4, '2026-06-08', 'Demo with Business', false),
-- Task 5: KIRO Access
(5, 1, '2026-05-27', 'Setup and demo KIRO to the team', true),
-- Task 6: SLM Confluence
(6, 1, '2026-05-21', 'Confluence update completed', true),
-- Task 7: Copilot Studio Deployment
(7, 1, '2026-05-28', 'HLCCD and App ID completion', true),
(7, 2, '2026-06-02', 'Documentation for Deployment', true),
(7, 3, '2026-06-04', 'CRQ Creation and Approval', false),
(7, 4, '2026-06-08', 'Deployment to AQ', false),
(7, 5, '2026-06-15', 'Deployment to Prod', false),
-- Task 8: Self Dev Guide Agent
(8, 1, '2026-06-02', 'HLCCD and App ID completion', true),
(8, 2, NULL, 'Documentation for Deployment', false),
(8, 3, NULL, 'CRQ Creation and Approval', false),
(8, 4, NULL, 'Deployment to AQ', false),
(8, 5, NULL, 'Deployment to Prod', false),
-- Task 9: DRA62
(9, 1, '2026-06-08', 'Initial basic report in excel on May months consumption by Service, By User and By use case', false),
(9, 2, '2026-06-22', 'Dashboard on usage stats', false),
-- Task 10: Agentify Execution Tracker
(10, 1, '2026-04-27', 'Showing the capability PPT creation in required format', true),
(10, 2, '2026-05-23', 'Including the capability of summarizing tracker then updating PPT', true),
(10, 3, NULL, 'Scaling up the solution to additional trackers file and including short term and long term memory', false),
-- Task 13: Voice-IQ Documentation
(13, 1, '2026-05-22', 'Documentation completion and review', false),
-- Task 14: Voice-IQ Email Trigger
(14, 1, '2026-05-26', 'SNS email trigger tested and deployed from EC2', false),
-- Task 15: Voice Estimations
(15, 1, '2026-06-03', 'Reviewing and updating DDIT estimates and sharing final estimation for MVP Implementation', false),
-- Task 16: Norstella EHR
(16, 1, '2026-05-29', 'Connect regarding Norstella and data ingestion', false);

-- Progress Comments (Week Ending 05/29/2026)
INSERT INTO progress_comments (task_id, comment_text, submitted_by, created_at) VALUES
(1, '- Incorporated feedback from Tom
- Added new functionalities for triggers and Kanban as per discussion with Tom
- UI Improvements', 'Satya', '2026-05-29 10:00:00+00'),
(2, '- Meeting slots shared with Manoj for 1st and 3rd June waiting for invite to walkthrough on V0.5 implementation
- Completed training for Azure Sandbox creation waiting for Naga to come back on checking if sandbox is best option here', 'Satya/Mohan', '2026-05-29 10:00:00+00'),
(3, 'We have received all required details from Azure AD team. Need to check with team how to access Graph API', 'Mithun/Mohan', '2026-05-29 10:00:00+00'),
(4, 'MS1: Was delivered on 26th May. Initial demo on Evaluation note functionality went well. Received feedback on
- Making Action part of Evaluation note in SMART format
- Adding two flows in the agent one which directly generates Evaluation note and other which coaches on evaluation note creation', 'Prathyusha', '2026-05-29 10:00:00+00'),
(5, 'Successfully demoed team on KIRO setup and educated on credits usage. Now most of the team members has access to KIRO', 'Mithun', '2026-05-29 10:00:00+00'),
(6, 'Updated SLM Details in the confluence for Masarrat and Teams usage', 'Prathyusha/Mohan', '2026-05-29 10:00:00+00'),
(7, '- Application ID creation is completed and HLCCD is in progress completed', 'Mohan', '2026-05-29 10:00:00+00'),
(8, '- Application ID and HLCCD is completed
- Architecture handbook created
- Test cases document created', 'Mohan/Satya', '2026-05-29 10:00:00+00'),
(9, 'Started working on analyzing existing AWS services provisioned by IDS team.', 'Mithun/Akhilesh', '2026-05-29 10:00:00+00'),
(10, '- Created two flows one for summarization and another for link/ppt creation
- Waiting for the team to come back
- We suspect that issues might be resolved and waiting for Varad to confirm
- Next steps scaling to additional trackers', 'Satya', '2026-05-29 10:00:00+00'),
(11, 'Incorporated feedback on including ABL persona details and shared the updated agent. Waiting for feedback and final confirmation. Shared on 25th', 'Satya', '2026-05-29 10:00:00+00'),
(12, 'Identified 2 DBs which we can downsize. Need to check with Narayan before performing DB downsize as we need to make sure app should not have any issue', 'Mithun', '2026-05-29 10:00:00+00'),
(13, 'In progress and a little tuning is required before it is fully ready for business use case. Guide documentation completed.', 'Ayushh', '2026-05-29 10:00:00+00'),
(14, 'We are not taking the SMTP route and SNS email trigger successfully tested and deployed from EC2.', 'Ayushh', '2026-05-29 10:00:00+00'),
(15, '- Provided details to Farshad and Gopal on PoC Implementation
- Next step is to review and update estimation by including DDIT costs', 'Mohan', '2026-05-29 10:00:00+00'),
(16, 'We have a connect again on 1st June regarding Norstella. Everything is up to date.', 'Ayushh', '2026-05-29 10:00:00+00'),
(17, '- Team has shared their review on masking we need to finalize and confirm
- Mohan spoke with Jayaseelan and asked for a connect to go through the progress with broader team and align on next steps', 'Mohan', '2026-05-29 10:00:00+00');

-- Progress Comments (Week Ending 06/05/2026)
INSERT INTO progress_comments (task_id, comment_text, submitted_by, created_at) VALUES
(13, 'Documentation for VOICE IQ application completed successfully.', 'Ayushh', '2026-06-05 10:00:00+00'),
(14, 'Email trigger capability implemented in VOICE IQ. Email gets triggered in the following cases: When LLM as JUDGE fails, When there is PII leakage, When PII is detected and it is redacted.', 'Ayushh', '2026-06-05 10:00:00+00'),
(16, 'John Qu had provided with updates in the last call post playing around with the applications for Graph RAG and Vector RAG to compare results. Everything is clear from our end and there is nothing more', 'Ayushh', '2026-06-05 10:00:00+00');

-- ============================================
-- DONE
-- ============================================
