/**
 * FlowDesk - Weekly Summary View
 * Shows the email-formatted weekly report with week selector.
 */

async function loadSummary() {
    populateSummaryWeeks();
    await generateSummary();
    initSummaryEvents();
}

function initSummaryEvents() {
    const genBtn = document.getElementById('btn-generate-summary');
    const copyBtn = document.getElementById('btn-copy-summary');
    const downloadBtn = document.getElementById('btn-download-docx');
    const weekSelect = document.getElementById('summary-week-select');

    if (genBtn) genBtn.addEventListener('click', generateSummary);
    if (copyBtn) copyBtn.addEventListener('click', copySummaryToClipboard);
    if (downloadBtn) downloadBtn.addEventListener('click', downloadOnlyWordDocument);
    if (weekSelect) weekSelect.addEventListener('change', generateSummary);
}

async function downloadOnlyWordDocument() {
    const weekSelect = document.getElementById('summary-week-select');
    const selectedWeek = weekSelect ? weekSelect.value : '';
    const params = selectedWeek ? `?week_ending=${selectedWeek}` : '';

    try {
        await downloadWordDocument(params);
        showToast('Word document downloaded', 'success');
    } catch (e) {
        showToast('Failed to download Word document', 'error');
    }
}

function populateSummaryWeeks() {
    const select = document.getElementById('summary-week-select');
    if (!select) return;

    let options = '<option value="">Current Week</option>';

    // Add weeks from actual data (progress comment dates)
    const dataWeeks = new Set();
    const tasks = allTasks.length > 0 ? allTasks : (isDemoAvailable() ? DEMO_TASKS : []);
    tasks.forEach(t => {
        if (t.progress_comments) {
            t.progress_comments.forEach(c => {
                if (c.created_at) {
                    const d = new Date(c.created_at);
                    const friday = new Date(d);
                    friday.setDate(d.getDate() + (5 - d.getDay()));
                    dataWeeks.add(friday.toISOString().split('T')[0]);
                }
            });
        }
    });

    // Sort descending and add to dropdown
    const sortedWeeks = [...dataWeeks].sort().reverse();
    sortedWeeks.forEach(fridayStr => {
        const friday = new Date(fridayStr);
        const label = `WE ${String(friday.getMonth()+1).padStart(2,'0')}/${String(friday.getDate()).padStart(2,'0')}/${friday.getFullYear()}`;
        options += `<option value="${fridayStr}">${label}</option>`;
    });

    // Also add past 4 weeks from today if no data weeks found
    if (sortedWeeks.length === 0) {
        const today = new Date();
        for (let i = 1; i <= 4; i++) {
            const friday = new Date(today);
            friday.setDate(today.getDate() - today.getDay() + 5 - (i * 7));
            const label = `WE ${String(friday.getMonth()+1).padStart(2,'0')}/${String(friday.getDate()).padStart(2,'0')}/${friday.getFullYear()}`;
            options += `<option value="${friday.toISOString().split('T')[0]}">${label}</option>`;
        }
    }

    select.innerHTML = options;
}

async function generateSummary() {
    const container = document.getElementById('summary-content');
    if (!container) return;

    container.innerHTML = '<p style="color:var(--text-muted); text-align:center; padding:40px;">⏳ Generating summary with AI...</p>';

    const weekSelect = document.getElementById('summary-week-select');
    const selectedWeek = weekSelect ? weekSelect.value : '';
    const params = selectedWeek ? `?week_ending=${selectedWeek}` : '';

    try {
        // Step 1: Call generate-now to produce LLM-polished comments
        await fetchWithTimeout(`${API_BASE}/weekly-reports/generate-now${params}`, { method: 'POST' }, 60000);

        // Step 2: Fetch the formatted email summary (for display)
        const response = await fetchWithTimeout(`${API_BASE}/weekly-reports/email-summary${params}`);
        if (response.ok) {
            const data = await response.json();
            renderSummary(data);

            showToast('Summary generated with AI', 'success');
            return;
        }
    } catch (e) {
        console.warn('LLM generation failed, trying raw summary:', e.message);
    }

    // Fallback: try email-summary without LLM
    try {
        const response = await fetchWithTimeout(`${API_BASE}/weekly-reports/email-summary${params}`);
        if (response.ok) {
            const data = await response.json();
            renderSummary(data);

            showToast('Summary generated', 'success');
            return;
        }
    } catch (e) { /* ignore */ }

    // Final fallback: demo data
    if (isDemoAvailable() || allTasks.length > 0) {
        const tasks = allTasks.length > 0 ? allTasks : (isDemoAvailable() ? DEMO_TASKS : []);
        renderSummaryFromTasks(tasks, selectedWeek);
    } else {
        container.innerHTML = '<p style="color:var(--text-muted); text-align:center; padding:40px;">No data available.</p>';
    }
}

async function downloadWordDocument(params) {
    try {
        const response = await fetch(`${API_BASE}/weekly-reports/export-docx${params}`);
        if (!response.ok) {
            throw new Error('Failed to download Word document');
        }

        // Get the blob from response
        const blob = await response.blob();

        // Extract filename from Content-Disposition header
        const contentDisposition = response.headers.get('Content-Disposition');
        let filename = 'Weekly_Tracker.docx';
        if (contentDisposition) {
            const matches = /filename=([^;]+)/.exec(contentDisposition);
            if (matches && matches[1]) {
                filename = matches[1].replace(/['"]/g, '');
            }
        }

        // Create download link and trigger download
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);

        console.log('Word document downloaded:', filename);
    } catch (error) {
        console.error('Failed to download Word document:', error);
        throw error;
    }
}

function renderSummary(data) {
    const container = document.getElementById('summary-content');
    if (!container) return;

    let html = `<div class="summary-header" style="margin-bottom:20px; padding-bottom:16px; border-bottom:1px solid var(--border-color);">
        <h3 style="font-size:1.1rem; margin-bottom:4px;">${escapeHtml(data.week_label)}</h3>
        <span style="font-size:0.8rem; color:var(--text-muted);">${data.total_tasks} tasks</span>
    </div>`;

    html += `<div style="margin-bottom:16px; color:var(--text-secondary); font-size:0.85rem;">
        Please find below the weekly project status update (${escapeHtml(data.week_label)}). For each task, I've captured current status, progress/achievements this week, and the next milestone/next steps.
    </div>`;

    data.items.forEach(item => {
        html += renderSummaryItem(item);
    });

    html += `<div style="margin-top:20px; padding-top:16px; border-top:1px solid var(--border-color); font-size:0.8rem; color:var(--text-muted);">
        Detailed tasks and milestones can be found in FlowDesk application.
    </div>`;

    container.innerHTML = html;
}

function renderSummaryFromTasks(tasks, selectedWeek) {
    const container = document.getElementById('summary-content');
    const today = new Date();
    let weekEnd, weekStart;

    if (selectedWeek) {
        weekEnd = new Date(selectedWeek);
        weekStart = new Date(weekEnd);
        weekStart.setDate(weekEnd.getDate() - 4);
    } else {
        weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay() + 1);
        weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 4);
    }

    const weekLabel = `WE ${String(weekEnd.getDate()).padStart(2,'0')} ${weekEnd.toLocaleString('default',{month:'long'})} ${weekEnd.getFullYear()}`;

    let html = `<div class="summary-header" style="margin-bottom:20px; padding-bottom:16px; border-bottom:1px solid var(--border-color);">
        <h3 style="font-size:1.1rem; margin-bottom:4px;">${weekLabel}</h3>
        <span style="font-size:0.8rem; color:var(--text-muted);">${tasks.length} tasks</span>
    </div>`;

    html += `<div style="margin-bottom:16px; color:var(--text-secondary); font-size:0.85rem;">
        Please find below the weekly project status update (${weekLabel}). For each task, I've captured current status, progress/achievements this week, and the next milestone/next steps.
    </div>`;

    tasks.forEach((task, idx) => {
        let progress = "No updates this week";
        if (task.progress_comments && task.progress_comments.length > 0) {
            const weekComments = task.progress_comments.filter(c => {
                if (!c.created_at) return false;
                const d = new Date(c.created_at);
                return d >= weekStart && d <= weekEnd;
            });
            if (weekComments.length > 0) {
                progress = weekComments.map(c => c.comment_text).join("; ").replace(/\n/g, "; ");
            } else {
                progress = task.progress_comments[0].comment_text.replace(/\n/g, "; ");
            }
        }

        let currentMs = null;
        let completedMs = null;
        let nextSteps = "No upcoming milestones";

        if (task.milestones && task.milestones.length > 0) {
            const completed = task.milestones.filter(m => m.is_completed);
            if (completed.length > 0) {
                const latest = completed[completed.length - 1];
                completedMs = `MS${latest.milestone_number} completed: ${latest.description || 'N/A'}`;
            }
            const upcoming = task.milestones.find(m => !m.is_completed && m.target_date);
            if (upcoming) {
                const daysTo = upcoming.days_remaining != null ? upcoming.days_remaining : '?';
                currentMs = `Milestone ${upcoming.milestone_number} due in ${daysTo} days (${upcoming.target_date})`;
                nextSteps = `${upcoming.description || 'Next milestone'}`;
                if (upcoming.target_date) nextSteps += ` (due: ${upcoming.target_date})`;
            }
        }

        html += renderSummaryItem({
            number: idx + 1,
            name: task.name,
            poc: task.poc_name || "Unassigned",
            status: task.status,
            current_milestone: currentMs,
            completed_milestone: completedMs,
            progress: progress,
            next_steps: nextSteps
        });
    });

    html += `<div style="margin-top:20px; padding-top:16px; border-top:1px solid var(--border-color); font-size:0.8rem; color:var(--text-muted);">
        Detailed tasks and milestones can be found in FlowDesk application.
    </div>`;

    container.innerHTML = html;
}

function renderSummaryItem(item) {
    return `
    <div style="margin-bottom:16px; padding:14px; background:var(--surface-2); border-radius:var(--radius-sm); border-left:3px solid var(--status-${item.status === 'Completed' ? 'completed' : item.status === 'In-Progress' ? 'in-progress' : 'not-started'});">
        <div style="font-weight:700; margin-bottom:8px; font-size:0.92rem;">${item.number}) ${escapeHtml(item.name)} <span style="color:var(--text-muted); font-weight:400;">(PoC: ${escapeHtml(item.poc)})</span></div>
        <ul style="list-style:disc; padding-left:20px; font-size:0.82rem; line-height:1.7; margin:0;">
            <li><strong>Status:</strong> ${escapeHtml(item.status)}</li>
            ${item.completed_milestone ? `<li><strong>Completed milestone:</strong> ${escapeHtml(item.completed_milestone)}</li>` : ''}
            ${item.current_milestone ? `<li><strong>Current milestone:</strong> ${escapeHtml(item.current_milestone)}</li>` : ''}
            <li><strong>Progress/Achievements this week:</strong> ${escapeHtml(item.progress)}</li>
            <li><strong>Next steps:</strong> ${escapeHtml(item.next_steps)}</li>
        </ul>
    </div>`;
}

async function copySummaryToClipboard() {
    const container = document.getElementById('summary-content');
    if (!container) return;

    const html = container.innerHTML;

    try {
        // Copy as rich text (HTML) — bold and bullets will paste into Outlook/Teams
        await navigator.clipboard.write([
            new ClipboardItem({
                'text/html': new Blob([html], { type: 'text/html' }),
                'text/plain': new Blob([container.innerText], { type: 'text/plain' })
            })
        ]);
        showToast('Summary copied with formatting (bold + bullets)', 'success');
    } catch (e) {
        // Fallback for browsers that don't support ClipboardItem
        console.warn('Rich copy failed, using plain text:', e);
        const text = container.innerText;
        try {
            await navigator.clipboard.writeText(text);
            showToast('Summary copied (plain text)', 'success');
        } catch (e2) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            showToast('Summary copied (plain text)', 'success');
        }
    }
}
