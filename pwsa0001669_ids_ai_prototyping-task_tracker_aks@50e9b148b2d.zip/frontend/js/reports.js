/**
 * FlowDesk - Reports View
 * Renders summary stats and bar chart visualizations.
 */

async function loadReports() {
    try {
        const report = await api.getSummaryReport();
        renderReport(report);
    } catch (error) {
        showToast('Failed to load reports', 'error');
    }
}

function renderReport(report) {
    document.getElementById('report-stats').innerHTML = `
        <div class="stat-card">
            <div class="stat-value">${report.total_tasks}</div>
            <div class="stat-label">Total Tasks</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${report.overdue_count}</div>
            <div class="stat-label">Overdue</div>
        </div>
    `;

    // Render simple bar charts
    const statusBars = Object.entries(report.tasks_by_status).map(([status, count]) => `
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
            <span style="width:100px; font-size:0.8rem; color:var(--text-secondary);">${status}</span>
            <div class="progress-bar-container" style="flex:1; height:20px; border-radius:10px;">
                <div class="progress-bar" style="width:${(count / report.total_tasks) * 100}%; height:100%; border-radius:10px;"></div>
            </div>
            <span style="font-weight:600; min-width:30px;">${count}</span>
        </div>
    `).join('');

    const typeBars = Object.entries(report.tasks_by_type).map(([type, count]) => `
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
            <span style="width:120px; font-size:0.8rem; color:var(--text-secondary);">${type}</span>
            <div class="progress-bar-container" style="flex:1; height:20px; border-radius:10px;">
                <div class="progress-bar" style="width:${(count / report.total_tasks) * 100}%; height:100%; border-radius:10px;"></div>
            </div>
            <span style="font-weight:600; min-width:30px;">${count}</span>
        </div>
    `).join('');

    document.getElementById('report-charts').innerHTML = `
        <div class="card">
            <h3 style="margin-bottom:16px; font-size:1rem;">Tasks by Status</h3>
            ${statusBars}
        </div>
        <div class="card">
            <h3 style="margin-bottom:16px; font-size:1rem;">Tasks by Type</h3>
            ${typeBars}
        </div>
    `;
}
