/**
 * FlowDesk - Kanban Board View
 * Handles kanban rendering, drag-and-drop, and filters.
 */

let draggedTaskId = null;
let draggedOriginalStatus = null;
let kanbanDebounce = null;

async function loadKanban() {
    try {
        allTasks = await api.getTasks();
        initKanbanFilters();
        applyKanbanFilters();
    } catch (error) {
        showToast('Failed to load kanban data', 'error');
    }
}

function initKanbanFilters() {
    // Populate PoC filter
    const pocs = [...new Set(allTasks.map(t => t.poc_name).filter(Boolean))];
    const pocSelect = document.getElementById('kanban-filter-poc');
    if (pocSelect) {
        const currentVal = pocSelect.value;
        pocSelect.innerHTML = '<option value="">All PoC</option>' + pocs.map(p => `<option value="${p}">${escapeHtml(p)}</option>`).join('');
        pocSelect.value = currentVal;
    }

    // Populate month filter
    const monthSelect = document.getElementById('kanban-filter-month');
    if (monthSelect) {
        const months = new Set();
        allTasks.forEach(t => {
            if (t.milestones) {
                t.milestones.forEach(m => {
                    if (m.target_date) {
                        const d = new Date(m.target_date);
                        months.add(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`);
                    }
                });
            }
            if (t.created_at) {
                const d = new Date(t.created_at);
                months.add(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`);
            }
        });

        const sortedMonths = [...months].sort().reverse();
        const currentVal = monthSelect.value;
        monthSelect.innerHTML = '<option value="">All Time</option>' + sortedMonths.map(m => {
            const [year, month] = m.split('-');
            const date = new Date(year, parseInt(month)-1);
            const label = date.toLocaleString('default', { month: 'long', year: 'numeric' });
            return `<option value="${m}">${label}</option>`;
        }).join('');
        monthSelect.value = currentVal;
    }

    // Attach events (remove old listeners by replacing elements isn't needed — just attach once)
    const search = document.getElementById('kanban-search');
    const typeFilter = document.getElementById('kanban-filter-type');
    const pocFilter = document.getElementById('kanban-filter-poc');
    const monthFilter = document.getElementById('kanban-filter-month');

    if (search) search.oninput = () => {
        clearTimeout(kanbanDebounce);
        kanbanDebounce = setTimeout(applyKanbanFilters, 300);
    };
    if (typeFilter) typeFilter.onchange = applyKanbanFilters;
    if (pocFilter) pocFilter.onchange = applyKanbanFilters;
    if (monthFilter) monthFilter.onchange = applyKanbanFilters;

    const clearBtn = document.getElementById('kanban-btn-clear');
    if (clearBtn) clearBtn.onclick = clearKanbanFilters;
}

function clearKanbanFilters() {
    document.getElementById('kanban-search').value = '';
    document.getElementById('kanban-filter-type').value = '';
    document.getElementById('kanban-filter-poc').value = '';
    document.getElementById('kanban-filter-month').value = '';
    applyKanbanFilters();
}

function applyKanbanFilters() {
    let filtered = [...allTasks];

    const search = document.getElementById('kanban-search');
    const typeFilter = document.getElementById('kanban-filter-type');
    const pocFilter = document.getElementById('kanban-filter-poc');
    const monthFilter = document.getElementById('kanban-filter-month');

    const searchVal = search ? search.value.toLowerCase() : '';
    const typeVal = typeFilter ? typeFilter.value : '';
    const pocVal = pocFilter ? pocFilter.value : '';
    const monthVal = monthFilter ? monthFilter.value : '';

    if (searchVal) {
        filtered = filtered.filter(t =>
            t.name.toLowerCase().includes(searchVal) ||
            (t.description && t.description.toLowerCase().includes(searchVal))
        );
    }
    if (typeVal) {
        filtered = filtered.filter(t => t.type === typeVal);
    }
    if (pocVal) {
        filtered = filtered.filter(t => t.poc_name && t.poc_name.includes(pocVal));
    }
    if (monthVal) {
        const [year, month] = monthVal.split('-').map(Number);
        filtered = filtered.filter(t => {
            // Task has milestone in this month
            if (t.milestones && t.milestones.length > 0) {
                return t.milestones.some(m => {
                    if (!m.target_date) return false;
                    const d = new Date(m.target_date);
                    return d.getFullYear() === year && (d.getMonth()+1) === month;
                });
            }
            // Or task was created in this month
            if (t.created_at) {
                const d = new Date(t.created_at);
                return d.getFullYear() === year && (d.getMonth()+1) === month;
            }
            return false;
        });
    }

    renderKanban(filtered);
}

function renderKanban(tasks) {
    const notStarted = tasks.filter(t => t.status === 'Not Started');
    const inProgress = tasks.filter(t => t.status === 'In-Progress');
    const completed = tasks.filter(t => t.status === 'Completed');

    document.getElementById('count-not-started').textContent = notStarted.length;
    document.getElementById('count-in-progress').textContent = inProgress.length;
    document.getElementById('count-completed').textContent = completed.length;

    document.getElementById('kanban-not-started').innerHTML = notStarted.map(t => renderKanbanCard(t)).join('');
    document.getElementById('kanban-in-progress').innerHTML = inProgress.map(t => renderKanbanCard(t)).join('');
    document.getElementById('kanban-completed').innerHTML = completed.map(t => renderKanbanCard(t)).join('');

    // Re-attach drag events
    document.querySelectorAll('.kanban-card').forEach(card => {
        card.addEventListener('dragstart', handleDragStart);
        card.addEventListener('dragend', handleDragEnd);
    });
}

function renderKanbanCard(task) {
    return `
        <div class="kanban-card" draggable="true" data-task-id="${task.id}" data-status="${task.status}">
            <div style="font-weight: 600; font-size: 0.85rem; margin-bottom: 6px;">${escapeHtml(task.name)}</div>
            <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                <span class="badge badge-type" style="font-size: 0.6rem;">${escapeHtml(task.type)}</span>
                ${task.poc_name ? `<span class="badge badge-poc" style="font-size: 0.6rem;">${escapeHtml(task.poc_name)}</span>` : ''}
            </div>
            ${task.is_overdue ? '<div style="margin-top: 6px;"><span class="badge badge-overdue" style="font-size: 0.6rem;">OVERDUE</span></div>' : ''}
        </div>
    `;
}

function initKanbanDragDrop() {
    const dropZones = document.querySelectorAll('.kanban-drop-zone');
    dropZones.forEach(zone => {
        zone.addEventListener('dragover', (e) => {
            e.preventDefault();
            zone.classList.add('drag-over');
        });
        zone.addEventListener('dragleave', () => {
            zone.classList.remove('drag-over');
        });
        zone.addEventListener('drop', handleDrop);
    });
}

function handleDragStart(e) {
    draggedTaskId = e.target.dataset.taskId;
    draggedOriginalStatus = e.target.dataset.status;
    e.target.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
}

function handleDragEnd(e) {
    e.target.classList.remove('dragging');
    document.querySelectorAll('.kanban-drop-zone').forEach(z => z.classList.remove('drag-over'));
}

async function handleDrop(e) {
    e.preventDefault();
    const dropZone = e.currentTarget;
    dropZone.classList.remove('drag-over');

    const column = dropZone.closest('.kanban-column');
    const newStatus = column.dataset.status;

    if (!draggedTaskId || newStatus === draggedOriginalStatus) return;

    try {
        await api.updateTask(draggedTaskId, { status: newStatus });
        showToast(`Task moved to "${newStatus}"`, 'success');
        loadKanban();
    } catch (error) {
        showToast('Failed to update status', 'error');
        loadKanban();
    }
}
