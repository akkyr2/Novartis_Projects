/**
 * FlowDesk Demo/Dummy Data
 * 
 * This file provides static demo data for UI demonstration when the backend API is unavailable.
 * Updated to match the latest Excel (task-flow-2.xlsx) with two weeks of progress comments.
 * 
 * TO DISABLE DEMO MODE IN PRODUCTION:
 * 1. Set DEMO_MODE_ENABLED = false below
 * 2. Or simply remove the <script src="js/demoData.js"></script> line from index.html
 */

// ====================================================
// TOGGLE THIS TO DISABLE DEMO MODE
// ====================================================
const DEMO_MODE_ENABLED = true;

// Demo data matching the real API response structure (based on task-flow-2.xlsx)
const DEMO_TASKS = [
    {
        id: 1,
        name: "Agentic Colleague - AWS",
        type: "Project",
        poc_name: "Satya",
        description: null,
        comment: null,
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 66,
        upcoming_milestone: "Final Demo",
        days_to_upcoming: 1,
        is_overdue: false,
        milestones: [
            { id: 1, milestone_number: 1, target_date: "2026-05-19", description: "First look demo with Stan on basic application flow and agent overview", is_completed: true, is_overdue: false, days_remaining: -17 },
            { id: 2, milestone_number: 2, target_date: "2026-06-02", description: "Demo with IPST team", is_completed: true, is_overdue: false, days_remaining: -3 },
            { id: 3, milestone_number: 3, target_date: "2026-06-09", description: "Final Demo", is_completed: false, is_overdue: false, days_remaining: 1 }
        ],
        progress_comments: [
            { id: 101, comment_text: "- Incorporated feedback from Tom\n- Added new functionalities for triggers and Kanban as per discussion with Tom\n- UI Improvements", submitted_by: "Satya", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-01T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 2,
        name: "Agentic Colleague - Azure",
        type: "Project",
        poc_name: "Satya/Mohan",
        description: null,
        comment: null,
        status: "Not Started",
        completion_date: null,
        completion_percentage: 0,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [],
        progress_comments: [
            { id: 102, comment_text: "- Meeting slots shared with Manoj for 1st and 3rd June waiting for invite to walkthrough on V0.5 implementation\n- Completed training for Azure Sandbox creation waiting for Naga to come back on checking if sandbox is best option here", submitted_by: "Satya/Mohan", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-10T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 3,
        name: "Agentic Colleague - Graph API Request",
        type: "Access Request",
        poc_name: "Mithun/Mohan",
        description: null,
        comment: null,
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 0,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [],
        progress_comments: [
            { id: 103, comment_text: "We have received all required details from Azure AD team. Need to check with team how to access Graph API", submitted_by: "Mithun/Mohan", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-10T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 4,
        name: "ABL Coaching Agent",
        type: "Project",
        poc_name: "Prathyusha",
        description: "FCR Draft generation to be presented for Business feedback with limited UI",
        comment: "FCR Draft generation to be presented for Business feedback with limited UI",
        status: "In-Progress",
        completion_date: "2026-06-08",
        completion_percentage: 75,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [
            { id: 4, milestone_number: 1, target_date: "2026-05-26", description: "Demo business users on flow till ABL Note creation and taking feedback", is_completed: true, is_overdue: false, days_remaining: -10 },
            { id: 5, milestone_number: 2, target_date: "2026-06-03", description: "Adding new feedback from business. Completing end to end agent as per initial plan, including memory", is_completed: true, is_overdue: false, days_remaining: -2 },
            { id: 6, milestone_number: 3, target_date: "2026-06-04", description: "Deployment to EC2", is_completed: true, is_overdue: false, days_remaining: -1 },
            { id: 7, milestone_number: 4, target_date: "2026-06-08", description: "Demo with Business", is_completed: false, is_overdue: false, days_remaining: 3 }
        ],
        progress_comments: [
            { id: 104, comment_text: "MS1: Was delivered on 26th May. Initial demo on Evaluation note functionality went well. Received feedback on\n- Making Action part of Evaluation note in SMART format\n- Adding two flows in the agent one which directly generates Evaluation note and other which coaches on evaluation note creation", submitted_by: "Prathyusha", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-05T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 5,
        name: "KIRO Access to the team",
        type: "Access Request",
        poc_name: "Mithun",
        description: "Mithun to setup connect with Entire team AWS, Ash/Revath and Internal team on KIRO setup",
        comment: "Mithun to setup connect with Entire team AWS, Ash/Revath and Internal team on KIRO setup",
        status: "In-Progress",
        completion_date: "2026-06-27",
        completion_percentage: 100,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [
            { id: 8, milestone_number: 1, target_date: "2026-05-27", description: "Setup and demo KIRO to the team", is_completed: true, is_overdue: false, days_remaining: -9 }
        ],
        progress_comments: [
            { id: 105, comment_text: "Successfully demoed team on KIRO setup and educated on credits usage. Now most of the team members has access to KIRO", submitted_by: "Mithun", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-15T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 6,
        name: "SLM Confluence Update",
        type: "Others",
        poc_name: "Prathyusha/Mohan",
        description: "Mohan will complete today",
        comment: "Mohan will complete today",
        status: "Completed",
        completion_date: "2026-05-22",
        completion_percentage: 100,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [
            { id: 9, milestone_number: 1, target_date: "2026-05-21", description: "Confluence update completed", is_completed: true, is_overdue: false, days_remaining: -15 }
        ],
        progress_comments: [
            { id: 106, comment_text: "Updated SLM Details in the confluence for Masarrat and Team's usage", submitted_by: "Prathyusha/Mohan", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-18T08:00:00Z",
        updated_at: "2026-05-22T10:00:00Z"
    },
    {
        id: 7,
        name: "Copilot Studio Deployment",
        type: "Access Request",
        poc_name: "Mohan/Satya/Mithun",
        description: "Executive Meeting Planner (Event Assistant)",
        comment: "Executive Meeting Planner (Event Assistant)",
        status: "In-Progress",
        completion_date: "2026-06-15",
        completion_percentage: 40,
        upcoming_milestone: "Deployment to Prod",
        days_to_upcoming: 7,
        is_overdue: false,
        milestones: [
            { id: 10, milestone_number: 1, target_date: "2026-05-28", description: "HLCCD and App ID completion", is_completed: true, is_overdue: false, days_remaining: -8 },
            { id: 11, milestone_number: 2, target_date: "2026-06-02", description: "Documentation for Deployment", is_completed: true, is_overdue: false, days_remaining: -3 },
            { id: 12, milestone_number: 3, target_date: "2026-06-04", description: "CRQ Creation and Approval", is_completed: false, is_overdue: true, days_remaining: -1 },
            { id: 13, milestone_number: 4, target_date: "2026-06-08", description: "Deployment to AQ", is_completed: false, is_overdue: false, days_remaining: 3 },
            { id: 14, milestone_number: 5, target_date: "2026-06-15", description: "Deployment to Prod", is_completed: false, is_overdue: false, days_remaining: 7 }
        ],
        progress_comments: [
            { id: 107, comment_text: "- Application ID creation is completed and HLCCD is in progress completed", submitted_by: "Mohan", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-10T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 8,
        name: "Copilot Studio - Self Development Guide Agent",
        type: "Access Request",
        poc_name: "Mohan/Satya/Mithun",
        description: "Self Development Guide Agent",
        comment: "Self Development Guide Agent",
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 20,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [
            { id: 15, milestone_number: 1, target_date: "2026-06-02", description: "HLCCD and App ID completion", is_completed: true, is_overdue: false, days_remaining: -3 },
            { id: 16, milestone_number: 2, target_date: null, description: "Documentation for Deployment", is_completed: false, is_overdue: false, days_remaining: null },
            { id: 17, milestone_number: 3, target_date: null, description: "CRQ Creation and Approval", is_completed: false, is_overdue: false, days_remaining: null },
            { id: 18, milestone_number: 4, target_date: null, description: "Deployment to AQ", is_completed: false, is_overdue: false, days_remaining: null },
            { id: 19, milestone_number: 5, target_date: null, description: "Deployment to Prod", is_completed: false, is_overdue: false, days_remaining: null }
        ],
        progress_comments: [
            { id: 108, comment_text: "- Application ID and HLCCD is completed\n- Architecture handbook created\n- Test cases document created", submitted_by: "Mohan/Satya", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-20T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 9,
        name: "DRA62 Cost and Usage Tracking",
        type: "Project",
        poc_name: "Mithun/Akhilesh",
        description: "Mithun is waiting response from team",
        comment: "Mithun is waiting response from team",
        status: "In-Progress",
        completion_date: "2026-06-22",
        completion_percentage: 25,
        upcoming_milestone: "Dashboard on usage stats",
        days_to_upcoming: 14,
        is_overdue: false,
        milestones: [
            { id: 20, milestone_number: 1, target_date: "2026-06-08", description: "Initial basic report in excel on May month's consumption by Service, By User and By use case", is_completed: false, is_overdue: false, days_remaining: 3 },
            { id: 21, milestone_number: 2, target_date: "2026-06-22", description: "Dashboard on usage stats", is_completed: false, is_overdue: false, days_remaining: 14 }
        ],
        progress_comments: [
            { id: 109, comment_text: "Started working on analyzing existing AWS services provisioned by IDS team.", submitted_by: "Mithun/Akhilesh", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-20T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 10,
        name: "Agentify Execution Tracker for Field Insights & Analytics",
        type: "Project",
        poc_name: "Satya",
        description: "Copilot use case for summarizing tracker and creating PPTs",
        comment: null,
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 66,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [
            { id: 22, milestone_number: 1, target_date: "2026-04-27", description: "Showing the capability PPT creation in required format", is_completed: true, is_overdue: false, days_remaining: -39 },
            { id: 23, milestone_number: 2, target_date: "2026-05-23", description: "Including the capability of summarizing tracker then updating PPT", is_completed: true, is_overdue: false, days_remaining: -13 },
            { id: 24, milestone_number: 3, target_date: null, description: "Scaling up the solution to additional trackers file and including short term and long term memory", is_completed: false, is_overdue: false, days_remaining: null }
        ],
        progress_comments: [
            { id: 110, comment_text: "- Created two flows one for summarization and another for link/ppt creation\n- Waiting for the team to come back\n- We suspect that issues might be resolved and waiting for Varad to confirm\n- Next steps scaling to additional trackers", submitted_by: "Satya", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-04-15T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 11,
        name: "Self Development Planner - Copilot Use case",
        type: "Project",
        poc_name: "Satya",
        description: null,
        comment: null,
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 50,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [],
        progress_comments: [
            { id: 111, comment_text: "Incorporated feedback on including ABL persona details and shared the updated agent. Waiting for feedback and final confirmation. Shared on 25th", submitted_by: "Satya", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-10T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 12,
        name: "Downsizing DB",
        type: "Project",
        poc_name: "Mithun",
        description: null,
        comment: null,
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 25,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [],
        progress_comments: [
            { id: 112, comment_text: "Identified 2 DBs which we can downsize. Need to check with Narayan before performing DB downsize as we need to make sure app should not have any issue", submitted_by: "Mithun", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-15T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 13,
        name: "Voice-IQ - Documentation",
        type: "Documentation",
        poc_name: "Ayushh",
        description: "Create documentation for Voice-IQ covering features and capabilities and get it reviewed",
        comment: "Create documentation for Voice-IQ covering features and capabilities and get it reviewed",
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 50,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: true,
        milestones: [
            { id: 25, milestone_number: 1, target_date: "2026-05-22", description: "Documentation completion and review", is_completed: false, is_overdue: true, days_remaining: -14 }
        ],
        progress_comments: [
            { id: 113, comment_text: "In progress and a little tuning is required before it is fully ready for business use case. Guide documentation completed.", submitted_by: "Ayushh", created_at: "2026-05-29T10:00:00Z" },
            { id: 114, comment_text: "Documentation for VOICE IQ application completed successfully.", submitted_by: "Ayushh", created_at: "2026-06-05T10:00:00Z" }
        ],
        created_at: "2026-05-10T08:00:00Z",
        updated_at: "2026-06-05T10:00:00Z"
    },
    {
        id: 14,
        name: "Voice-IQ Email Trigger Langfuse (SMTP & SNS) from EC2",
        type: "Tech Spike",
        poc_name: "Ayushh",
        description: "Deploy application and test email trigger on Voice-IQ app launch and downstream applications",
        comment: "Deploy application and test email trigger on Voice-IQ app launch and downstream applications",
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 50,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: true,
        milestones: [
            { id: 26, milestone_number: 1, target_date: "2026-05-26", description: "SNS email trigger tested and deployed from EC2", is_completed: false, is_overdue: true, days_remaining: -10 }
        ],
        progress_comments: [
            { id: 115, comment_text: "We are not taking the SMTP route and SNS email trigger successfully tested and deployed from EC2.", submitted_by: "Ayushh", created_at: "2026-05-29T10:00:00Z" },
            { id: 116, comment_text: "Email trigger capability implemented in VOICE IQ. Email gets triggered in the following cases: When LLM as JUDGE fails, When there is PII leakage, When PII is detected and it is redacted.", submitted_by: "Ayushh", created_at: "2026-06-05T10:00:00Z" }
        ],
        created_at: "2026-05-15T08:00:00Z",
        updated_at: "2026-06-05T10:00:00Z"
    },
    {
        id: 15,
        name: "Voice Estimations for MVP",
        type: "Project",
        poc_name: "Mohan",
        description: null,
        comment: null,
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 25,
        upcoming_milestone: "Reviewing and updating DDIT estimates",
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [
            { id: 27, milestone_number: 1, target_date: "2026-06-03", description: "Reviewing and updating DDIT estimates and sharing final estimation for MVP Implementation", is_completed: false, is_overdue: true, days_remaining: -2 }
        ],
        progress_comments: [
            { id: 117, comment_text: "- Provided details to Farshad and Gopal on PoC Implementation\n- Next step is to review and update estimation by including DDIT costs", submitted_by: "Mohan", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-20T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    },
    {
        id: 16,
        name: "Norstella EHR",
        type: "Project",
        poc_name: "Ayushh",
        description: "Waiting for John Qu to provide updates on further data ingestion and closure.",
        comment: "Waiting for John Qu to provide updates on further data ingestion and closure.",
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 50,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: true,
        milestones: [
            { id: 28, milestone_number: 1, target_date: "2026-05-29", description: "Connect regarding Norstella and data ingestion", is_completed: false, is_overdue: true, days_remaining: -7 }
        ],
        progress_comments: [
            { id: 118, comment_text: "We have a connect again on 1st June regarding Norstella. Everything is up to date.", submitted_by: "Ayushh", created_at: "2026-05-29T10:00:00Z" },
            { id: 119, comment_text: "John Qu had provided with updates in the last call post playing around with the applications for Graph RAG and Vector RAG to compare results. Everything is clear from our end and there is nothing more", submitted_by: "Ayushh", created_at: "2026-06-05T10:00:00Z" }
        ],
        created_at: "2026-05-01T08:00:00Z",
        updated_at: "2026-06-05T10:00:00Z"
    },
    {
        id: 17,
        name: "Data Masking Use Case",
        type: "Project",
        poc_name: "Mohan",
        description: "Data masking implementation review and finalization",
        comment: null,
        status: "In-Progress",
        completion_date: null,
        completion_percentage: 25,
        upcoming_milestone: null,
        days_to_upcoming: null,
        is_overdue: false,
        milestones: [],
        progress_comments: [
            { id: 120, comment_text: "- Team has shared their review on masking we need to finalize and confirm\n- Mohan spoke with Jayaseelan and asked for a connect to go through the progress with broader team and align on next steps", submitted_by: "Mohan", created_at: "2026-05-29T10:00:00Z" }
        ],
        created_at: "2026-05-15T08:00:00Z",
        updated_at: "2026-05-29T10:00:00Z"
    }
];

// Demo summary report
const DEMO_SUMMARY_REPORT = {
    total_tasks: 17,
    tasks_by_status: {
        "In-Progress": 14,
        "Completed": 1,
        "Not Started": 2
    },
    tasks_by_type: {
        "Project": 10,
        "Access Request": 4,
        "Tech Spike": 1,
        "Documentation": 1,
        "Others": 1
    },
    overdue_count: 4
};
