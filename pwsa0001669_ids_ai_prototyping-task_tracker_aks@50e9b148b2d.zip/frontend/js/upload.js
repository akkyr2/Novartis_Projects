/**
 * FlowDesk - Update Sheet (Excel Upload) View
 * Allows uploading an Excel tracker sheet to preview and apply changes to the database.
 */

var uploadedFile = null;
var previewData = null;

function loadUploadSheet() {
    renderUploadPage();
    initUploadEvents();
}

function initUploadEvents() {
    var fileInput = document.getElementById('upload-file-input');
    var dropZone = document.getElementById('upload-drop-zone');
    var analyzeBtn = document.getElementById('btn-analyze-sheet');
    var confirmBtn = document.getElementById('btn-confirm-update');
    var cancelBtn = document.getElementById('btn-cancel-update');

    if (fileInput) fileInput.addEventListener('change', handleFileSelect);
    if (analyzeBtn) analyzeBtn.addEventListener('click', analyzeSheet);
    if (confirmBtn) confirmBtn.addEventListener('click', applyUpdate);
    if (cancelBtn) cancelBtn.addEventListener('click', resetUpload);

    // Drag and drop
    if (dropZone) {
        dropZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            dropZone.classList.add('drag-over');
        });
        dropZone.addEventListener('dragleave', function() {
            dropZone.classList.remove('drag-over');
        });
        dropZone.addEventListener('drop', function(e) {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            var files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFile(files[0]);
            }
        });
        dropZone.addEventListener('click', function() {
            if (fileInput) fileInput.click();
        });
    }
}

function handleFileSelect(e) {
    var file = e.target.files[0];
    if (file) handleFile(file);
}

function handleFile(file) {
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
        showToast('Please select a .xlsx or .xls file', 'error');
        return;
    }
    uploadedFile = file;
    previewData = null;

    // Update UI to show selected file
    var dropZone = document.getElementById('upload-drop-zone');
    var fileInfo = document.getElementById('upload-file-info');
    var analyzeBtn = document.getElementById('btn-analyze-sheet');

    if (dropZone) dropZone.style.display = 'none';
    if (fileInfo) {
        fileInfo.style.display = 'flex';
        fileInfo.innerHTML = '<div style="display:flex; align-items:center; gap:12px;">' +
            '<span style="font-size:2rem;">&#128196;</span>' +
            '<div>' +
            '<div style="font-weight:600; font-size:0.9rem;">' + escapeHtml(file.name) + '</div>' +
            '<div style="font-size:0.78rem; color:var(--text-muted);">' + (file.size / 1024).toFixed(1) + ' KB</div>' +
            '</div>' +
            '<button class="btn btn-secondary btn-sm" onclick="resetFileSelection()" style="margin-left:auto;">&#10005; Remove</button>' +
            '</div>';
    }
    if (analyzeBtn) analyzeBtn.disabled = false;

    // Hide preview if previously shown
    var previewContainer = document.getElementById('upload-preview-container');
    if (previewContainer) previewContainer.style.display = 'none';
}

function resetFileSelection() {
    uploadedFile = null;
    previewData = null;
    var dropZone = document.getElementById('upload-drop-zone');
    var fileInfo = document.getElementById('upload-file-info');
    var analyzeBtn = document.getElementById('btn-analyze-sheet');
    var fileInput = document.getElementById('upload-file-input');
    var previewContainer = document.getElementById('upload-preview-container');

    if (dropZone) dropZone.style.display = 'flex';
    if (fileInfo) fileInfo.style.display = 'none';
    if (analyzeBtn) analyzeBtn.disabled = true;
    if (fileInput) fileInput.value = '';
    if (previewContainer) previewContainer.style.display = 'none';
}

function resetUpload() {
    resetFileSelection();
    showToast('Upload cancelled', 'info');
}

async function analyzeSheet() {
    if (!uploadedFile) {
        showToast('Please select a file first', 'error');
        return;
    }

    var analyzeBtn = document.getElementById('btn-analyze-sheet');
    if (analyzeBtn) {
        analyzeBtn.disabled = true;
        analyzeBtn.textContent = 'Analyzing...';
    }

    try {
        var formData = new FormData();
        formData.append('file', uploadedFile);

        var response = await fetch(API_BASE + '/upload/preview', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            var err = await response.json();
            throw new Error(err.detail || 'Failed to analyze file');
        }

        previewData = await response.json();
        renderPreview(previewData);
        showToast('Analysis complete - review changes below', 'success');
    } catch (e) {
        showToast(e.message || 'Failed to analyze file', 'error');
    } finally {
        if (analyzeBtn) {
            analyzeBtn.disabled = false;
            analyzeBtn.textContent = 'Analyze Sheet';
        }
    }
}

function renderPreview(data) {
    var container = document.getElementById('upload-preview-container');
    if (!container) return;

    container.style.display = 'block';

    // Summary stats
    var html = '<div class="upload-preview-summary">' +
        '<h3 style="margin-bottom:12px; font-size:1rem; color:var(--text-primary);">Analysis Summary</h3>' +
        '<div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap:10px; margin-bottom:16px;">' +
        '<div class="upload-stat-card"><div class="upload-stat-value">' + data.total_rows + '</div><div class="upload-stat-label">Total Rows</div></div>' +
        '<div class="upload-stat-card" style="border-color: var(--status-completed);"><div class="upload-stat-value" style="color:var(--status-completed);">' + data.new_tasks + '</div><div class="upload-stat-label">New Tasks</div></div>' +
        '<div class="upload-stat-card" style="border-color: var(--status-in-progress);"><div class="upload-stat-value" style="color:var(--status-in-progress);">' + data.updated_tasks + '</div><div class="upload-stat-label">Updated Tasks</div></div>' +
        '<div class="upload-stat-card"><div class="upload-stat-value">' + data.unchanged_tasks + '</div><div class="upload-stat-label">Unchanged</div></div>' +
        '<div class="upload-stat-card"><div class="upload-stat-value">' + data.total_milestone_changes + '</div><div class="upload-stat-label">Milestone Changes</div></div>' +
        '<div class="upload-stat-card"><div class="upload-stat-value">' + data.total_new_comments + '</div><div class="upload-stat-label">New Comments</div></div>' +
        '</div></div>';

    // No changes message
    if (data.new_tasks === 0 && data.updated_tasks === 0) {
        html += '<div style="text-align:center; padding:30px; color:var(--text-muted);">' +
            '<span style="font-size:2rem;">&#9989;</span>' +
            '<p style="margin-top:8px;">Everything is up to date. No changes detected.</p></div>';
        container.innerHTML = html;
        return;
    }

    // Detailed changes
    html += '<h3 style="margin:16px 0 12px; font-size:1rem; color:var(--text-primary);">Detailed Changes</h3>';

    // New tasks
    var newTasks = data.changes.filter(function(c) { return c.action === 'new'; });
    if (newTasks.length > 0) {
        html += '<div class="upload-change-section">' +
            '<h4 style="color:var(--status-completed); margin-bottom:8px;">+ New Tasks (' + newTasks.length + ')</h4>';
        newTasks.forEach(function(task) {
            html += renderTaskChange(task);
        });
        html += '</div>';
    }

    // Updated tasks
    var updatedTasks = data.changes.filter(function(c) { return c.action === 'updated'; });
    if (updatedTasks.length > 0) {
        html += '<div class="upload-change-section">' +
            '<h4 style="color:var(--status-in-progress); margin-bottom:8px;">Updated Tasks (' + updatedTasks.length + ')</h4>';
        updatedTasks.forEach(function(task) {
            html += renderTaskChange(task);
        });
        html += '</div>';
    }

    // Action buttons
    html += '<div style="display:flex; gap:12px; margin-top:20px; padding-top:16px; border-top:1px solid var(--border-color);">' +
        '<button class="btn btn-primary" id="btn-confirm-update">Confirm & Apply Updates</button>' +
        '<button class="btn btn-secondary" id="btn-cancel-update">Cancel</button></div>';

    container.innerHTML = html;

    // Re-attach event listeners for dynamically created buttons
    var confirmBtn = document.getElementById('btn-confirm-update');
    var cancelBtn = document.getElementById('btn-cancel-update');
    if (confirmBtn) confirmBtn.addEventListener('click', applyUpdate);
    if (cancelBtn) cancelBtn.addEventListener('click', resetUpload);
}

function renderTaskChange(task) {
    var html = '<div class="upload-task-change">' +
        '<div class="upload-task-name">' + escapeHtml(task.task_name) + '</div>';

    // Field changes
    if (task.field_changes && task.field_changes.length > 0) {
        html += '<div class="upload-changes-list">';
        task.field_changes.forEach(function(fc) {
            if (fc.old && fc['new']) {
                html += '<div class="upload-change-item">' +
                    '<span class="upload-change-field">' + escapeHtml(fc.field) + ':</span>' +
                    '<span class="upload-change-old">' + escapeHtml(fc.old || '(empty)') + '</span>' +
                    '<span class="upload-change-arrow">&rarr;</span>' +
                    '<span class="upload-change-new">' + escapeHtml(fc['new']) + '</span></div>';
            } else if (fc['new']) {
                html += '<div class="upload-change-item">' +
                    '<span class="upload-change-field">' + escapeHtml(fc.field) + ':</span>' +
                    '<span class="upload-change-new">' + escapeHtml(fc['new']) + '</span></div>';
            }
        });
        html += '</div>';
    }

    // Milestone changes
    if (task.milestone_changes && task.milestone_changes.length > 0) {
        html += '<div class="upload-changes-list" style="margin-top:4px;">';
        task.milestone_changes.forEach(function(mc) {
            if (mc.field === 'new') {
                html += '<div class="upload-change-item">' +
                    '<span class="upload-change-field">MS' + mc.milestone_number + ' (new):</span>' +
                    '<span class="upload-change-new">' + escapeHtml(mc.new_value || '') + '</span></div>';
            } else {
                html += '<div class="upload-change-item">' +
                    '<span class="upload-change-field">MS' + mc.milestone_number + ' ' + escapeHtml(mc.field) + ':</span>' +
                    '<span class="upload-change-old">' + escapeHtml(mc.old_value || '(empty)') + '</span>' +
                    '<span class="upload-change-arrow">&rarr;</span>' +
                    '<span class="upload-change-new">' + escapeHtml(mc.new_value || '') + '</span></div>';
            }
        });
        html += '</div>';
    }

    // New comments
    if (task.new_comments && task.new_comments.length > 0) {
        html += '<div class="upload-changes-list" style="margin-top:4px;">';
        task.new_comments.forEach(function(nc) {
            var preview = nc.comment_text.length > 80 ? nc.comment_text.substring(0, 80) + '...' : nc.comment_text;
            html += '<div class="upload-change-item">' +
                '<span class="upload-change-field">Comment (WE ' + nc.week_ending + '):</span>' +
                '<span class="upload-change-new">' + escapeHtml(preview) + '</span></div>';
        });
        html += '</div>';
    }

    html += '</div>';
    return html;
}

async function applyUpdate() {
    if (!uploadedFile) {
        showToast('No file selected', 'error');
        return;
    }

    var confirmBtn = document.getElementById('btn-confirm-update');
    if (confirmBtn) {
        confirmBtn.disabled = true;
        confirmBtn.textContent = 'Applying updates...';
    }

    try {
        var formData = new FormData();
        formData.append('file', uploadedFile);

        var response = await fetch(API_BASE + '/upload/apply', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            var err = await response.json();
            throw new Error(err.detail || 'Failed to apply updates');
        }

        var result = await response.json();
        showToast(result.message, 'success');

        // Show success state
        var container = document.getElementById('upload-preview-container');
        if (container) {
            container.innerHTML = '<div style="text-align:center; padding:40px;">' +
                '<span style="font-size:3rem;">&#9989;</span>' +
                '<h3 style="margin-top:12px; color:var(--status-completed);">Update Applied Successfully!</h3>' +
                '<p style="color:var(--text-secondary); margin-top:8px; font-size:0.88rem;">' + escapeHtml(result.message) + '</p>' +
                '<button class="btn btn-primary" onclick="resetFileSelection(); loadUploadSheet();" style="margin-top:20px;">Upload Another Sheet</button></div>';
        }
    } catch (e) {
        showToast(e.message || 'Failed to apply updates', 'error');
        if (confirmBtn) {
            confirmBtn.disabled = false;
            confirmBtn.textContent = 'Confirm & Apply Updates';
        }
    }
}

function renderUploadPage() {
    var container = document.getElementById('upload-page-content');
    if (!container) return;

    container.innerHTML = '<div class="upload-container">' +
        '<div class="upload-header">' +
        '<h3 style="font-size:1.1rem; margin-bottom:4px;">Upload Excel Tracker Sheet</h3>' +
        '<p style="font-size:0.82rem; color:var(--text-muted);">' +
        'Upload your latest Excel tracker to sync task data with the database. Changes will be previewed before applying.</p>' +
        '</div>' +

        '<div class="upload-area">' +
        '<div class="upload-drop-zone" id="upload-drop-zone">' +
        '<span style="font-size:2.5rem;">&#128193;</span>' +
        '<p style="font-weight:600; margin-top:8px;">Drop your Excel file here</p>' +
        '<p style="font-size:0.78rem; color:var(--text-muted);">or click to browse (.xlsx files only)</p>' +
        '</div>' +

        '<div class="upload-file-info" id="upload-file-info" style="display:none;"></div>' +
        '<input type="file" id="upload-file-input" accept=".xlsx,.xls" style="display:none;">' +

        '<div style="margin-top:16px; display:flex; gap:10px; align-items:center;">' +
        '<button class="btn btn-primary" id="btn-analyze-sheet" disabled>Analyze Sheet</button>' +
        '<span style="font-size:0.78rem; color:var(--text-muted);">Compares sheet data with current database records</span>' +
        '</div>' +
        '</div>' +

        '<div class="upload-preview" id="upload-preview-container" style="display:none;"></div>' +

        '<div class="upload-format-info">' +
        '<h4 style="font-size:0.88rem; margin-bottom:8px;">Expected Excel Format</h4>' +
        '<p style="font-size:0.78rem; color:var(--text-muted); margin-bottom:8px;">' +
        'Your Excel should have headers in the first row. The following columns are recognized:</p>' +
        '<div style="display:grid; grid-template-columns:1fr 1fr; gap:4px; font-size:0.76rem;">' +
        '<div><strong>Tasks</strong> &mdash; Task name (required)</div>' +
        '<div><strong>Type</strong> &mdash; Project, Access Request, etc.</div>' +
        '<div><strong>PoC</strong> &mdash; Person of Contact</div>' +
        '<div><strong>Comment</strong> &mdash; Description/comment</div>' +
        '<div><strong>Status</strong> &mdash; Not Started, In-Progress, Completed</div>' +
        '<div><strong>Completion Date</strong> &mdash; Target completion date</div>' +
        '<div><strong>Milestone 1-5</strong> &mdash; Milestone dates</div>' +
        '<div><strong>Milestone Description</strong> &mdash; MS descriptions (MS1: ...)</div>' +
        '<div><strong>WE MM/DD/YYYY</strong> &mdash; Weekly progress comments</div>' +
        '<div style="color:var(--text-muted);">Other columns will be ignored</div>' +
        '</div></div></div>';
}
