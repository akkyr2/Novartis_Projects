/**
 * FlowDesk - Main Application (Init, Utilities & Orchestrator)
 * Handles initialization, theme, navigation, modals, filters, demo button,
 * and shared helper functions used across all views.
 * 
 * View-specific logic lives in separate files:
 *   - dashboard.js  → Dashboard cards & stats
 *   - kanban.js     → Kanban board & drag-drop
 *   - tasks.js      → Tasks table view
 *   - reports.js    → Summary reports & charts
 */

let allTasks = [];
let editingTaskId = null;
let searchDebounce = null;

// ============================================
// SHARED UTILITIES
// ============================================

function getStatusClass(status) {
    if (status === 'Not Started') return 'not-started';
    if (status === 'In-Progress') return 'in-progress';
    if (status === 'Completed') return 'completed';
    return '';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${type === 'success' ? '✓' : '⚠'}</span> <span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

function refreshCurrentPage() {
    const activePage = document.querySelector('.nav-link.active');
    if (activePage) navigateTo(activePage.dataset.page);
}

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initNavigation();
    initModal();
    initFilters();
    initKanbanDragDrop();
    initDemoButton();
    loadDashboard();
});

// Add CSS for active pages
const style = document.createElement('style');
style.textContent = '.page { display: none; } .page.active { display: block; }';
document.head.appendChild(style);

// ============================================
// THEME
// ============================================

function initTheme() {
    const saved = localStorage.getItem('flowdesk-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', saved);

    document.getElementById('theme-toggle').addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('flowdesk-theme', next);
    });
}

// ============================================
// NAVIGATION
// ============================================

function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.dataset.page;
            navigateTo(page);
        });
    });
}

function navigateTo(page) {
    // Update nav
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector(`[data-page="${page}"]`).classList.add('active');

    // Update pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(`page-${page}`).classList.add('active');

    // Update title
    const titles = {
        dashboard: 'Dashboard',
        kanban: 'Kanban Board',
        tasks: 'All Tasks',
        upload: 'Update Sheet',
        reports: 'Reports',
        summary: 'Weekly Summary'
    };
    document.getElementById('page-title').textContent = titles[page] || 'FlowDesk';

    // Load page data
    if (page === 'dashboard') loadDashboard();
    if (page === 'kanban') loadKanban();
    if (page === 'tasks') loadTasksTable();
    if (page === 'upload') loadUploadSheet();
    if (page === 'reports') loadReports();
    if (page === 'summary') loadSummary();
}

// ============================================
// DEMO BUTTON
// ============================================

function initDemoButton() {
    const btn = document.getElementById('btn-load-demo');
    if (!btn) return;

    // Hide the demo button if demo data script is not loaded
    if (typeof DEMO_MODE_ENABLED === 'undefined' || !DEMO_MODE_ENABLED) {
        btn.style.display = 'none';
        return;
    }

    btn.addEventListener('click', () => {
        if (isUsingDemoData) {
            // Toggle OFF — clear demo data and try real API
            setDemoMode(false);
            allTasks = [];
            btn.innerHTML = 'Demo-Data';
            btn.classList.remove('btn-warning');
            btn.classList.add('btn-primary');

            clearAllViews();
            showToast('Demo data removed. Connecting to live API...', 'success');
            refreshCurrentPage();
        } else {
            // Toggle ON — force demo data
            forceLoadDemoData();
            btn.innerHTML = 'Live-Data';
            btn.classList.remove('btn-secondary');
            btn.classList.add('btn-warning');
            showToast('Demo data loaded for presentation', 'success');
        }
    });
}

function clearAllViews() {
    const ids = [
        'stats-grid', 'dashboard-grid',
        'kanban-not-started', 'kanban-in-progress', 'kanban-completed',
        'tasks-table-container',
        'report-stats', 'report-charts'
    ];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = '';
    });

    // Reset kanban counts
    ['count-not-started', 'count-in-progress', 'count-completed'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = '0';
    });
}

// ============================================
// MODAL & FORMS
// ============================================

function initModal() {
    document.getElementById('btn-add-task').addEventListener('click', () => openModal());
    document.getElementById('modal-close').addEventListener('click', () => closeModal());
    document.getElementById('btn-cancel-form').addEventListener('click', () => closeModal());
    document.getElementById('detail-modal-close').addEventListener('click', () => closeDetailModal());
    document.getElementById('task-form').addEventListener('submit', handleFormSubmit);

    // Close on backdrop click
    document.getElementById('modal-overlay').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) closeModal();
    });
    document.getElementById('detail-modal-overlay').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) closeDetailModal();
    });
}

function openModal(task = null) {
    editingTaskId = task ? task.id : null;
    document.getElementById('modal-title').textContent = task ? 'Edit Task' : 'New Task';
    document.getElementById('form-name').value = task ? task.name : '';
    document.getElementById('form-type').value = task ? task.type : 'Project';
    document.getElementById('form-poc').value = task ? (task.poc_name || '') : '';
    document.getElementById('form-description').value = task ? (task.description || task.comment || '') : '';
    document.getElementById('form-status').value = task ? task.status : 'Not Started';
    document.getElementById('form-completion-date').value = task ? (task.completion_date || '') : '';
    document.getElementById('form-progress-comment').value = '';

    // Populate milestone fields
    for (let i = 1; i <= 5; i++) {
        const dateField = document.getElementById(`form-ms${i}-date`);
        const descField = document.getElementById(`form-ms${i}-desc`);
        if (task && task.milestones) {
            const ms = task.milestones.find(m => m.milestone_number === i);
            dateField.value = ms && ms.target_date ? ms.target_date : '';
            descField.value = ms && ms.description ? ms.description : '';
        } else {
            dateField.value = '';
            descField.value = '';
        }
    }

    document.getElementById('modal-overlay').classList.add('active');
}

function closeModal() {
    document.getElementById('modal-overlay').classList.remove('active');
    editingTaskId = null;
}

async function handleFormSubmit(e) {
    e.preventDefault();

    // Collect milestone data
    const milestones = [];
    for (let i = 1; i <= 5; i++) {
        const dateVal = document.getElementById(`form-ms${i}-date`).value;
        const descVal = document.getElementById(`form-ms${i}-desc`).value;
        if (dateVal || descVal) {
            milestones.push({
                milestone_number: i,
                target_date: dateVal || null,
                description: descVal || null
            });
        }
    }

    const taskData = {
        name: document.getElementById('form-name').value,
        type: document.getElementById('form-type').value,
        poc_name: document.getElementById('form-poc').value || null,
        description: document.getElementById('form-description').value || null,
        status: document.getElementById('form-status').value,
        completion_date: document.getElementById('form-completion-date').value || null,
        milestones: milestones.length > 0 ? milestones : undefined
    };

    const progressComment = document.getElementById('form-progress-comment').value;

    try {
        let savedTask;
        if (editingTaskId) {
            savedTask = await api.updateTask(editingTaskId, taskData);
            showToast('Task updated successfully', 'success');
        } else {
            savedTask = await api.createTask(taskData);
            showToast('Task created successfully', 'success');
        }

        // Add progress comment if provided
        if (progressComment && savedTask && savedTask.id) {
            await api.addComment(savedTask.id, {
                comment_text: progressComment,
                submitted_by: taskData.poc_name || 'Unknown'
            });
        }

        closeModal();
        refreshCurrentPage();
    } catch (error) {
        showToast(error.message, 'error');
    }
}

async function editTask(taskId) {
    try {
        const task = await api.getTask(taskId);
        openModal(task);
    } catch (error) {
        showToast('Failed to load task', 'error');
    }
}

async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) return;
    try {
        await api.deleteTask(taskId);
        showToast('Task deleted', 'success');
        refreshCurrentPage();
    } catch (error) {
        showToast('Failed to delete task', 'error');
    }
}

async function openTaskDetail(taskId) {
    try {
        const task = await api.getTask(taskId);
        document.getElementById('detail-modal-title').textContent = task.name;
        document.getElementById('detail-modal-content').innerHTML = `
            <div style="margin-bottom:16px;">
                <div class="task-card-meta">
                    <span class="badge badge-type">${escapeHtml(task.type)}</span>
                    ${task.poc_name ? `<span class="badge badge-poc">${escapeHtml(task.poc_name)}</span>` : ''}
                    <span class="badge badge-status ${getStatusClass(task.status)}">${task.status}</span>
                    ${task.is_overdue ? '<span class="badge badge-overdue">OVERDUE</span>' : ''}
                </div>
            </div>
            ${task.description ? `<p style="color:var(--text-secondary); margin-bottom:16px;">${escapeHtml(task.description)}</p>` : ''}
            <div style="margin-bottom:16px;">
                <strong style="font-size:0.8rem; color:var(--text-muted); text-transform:uppercase;">Progress: ${task.completion_percentage}%</strong>
                <div class="progress-bar-container" style="margin-top:8px;">
                    <div class="progress-bar" style="width:${task.completion_percentage}%"></div>
                </div>
            </div>
            ${task.milestones.length > 0 ? `
                <div style="margin-bottom:16px;">
                    <strong style="font-size:0.8rem; color:var(--text-muted); text-transform:uppercase;">Milestones</strong>
                    <div style="margin-top:8px;">
                        ${task.milestones.map(m => `
                            <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px; padding:8px; background:var(--surface-2); border-radius:6px;">
                                <div class="milestone-dot ${m.is_completed ? 'completed' : (m.is_overdue ? 'overdue' : '')}" style="flex-shrink:0;">${m.milestone_number}</div>
                                <div style="flex:1;">
                                    <div style="font-size:0.85rem;">${m.description || 'Milestone ' + m.milestone_number}</div>
                                    <div style="font-size:0.75rem; color:var(--text-muted);">${m.target_date || 'No date'}${m.days_remaining != null ? ` (${m.days_remaining} days)` : ''}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
            ${task.progress_comments.length > 0 ? `
                <div>
                    <strong style="font-size:0.8rem; color:var(--text-muted); text-transform:uppercase;">Progress Comments</strong>
                    <div style="margin-top:8px; max-height:200px; overflow-y:auto;">
                        ${task.progress_comments.map(c => `
                            <div style="padding:10px; background:var(--surface-2); border-radius:6px; margin-bottom:8px;">
                                <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:4px;">${c.submitted_by || 'Unknown'} • ${c.created_at ? new Date(c.created_at).toLocaleDateString() : ''}</div>
                                <div style="font-size:0.85rem;">${escapeHtml(c.comment_text)}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
            <div style="margin-top:20px; display:flex; gap:8px;">
                <button class="btn btn-primary btn-sm" onclick="editTask(${task.id}); closeDetailModal();">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deleteTask(${task.id}); closeDetailModal();">Delete</button>
            </div>
        `;
        document.getElementById('detail-modal-overlay').classList.add('active');
    } catch (error) {
        showToast('Failed to load task details', 'error');
    }
}

function closeDetailModal() {
    document.getElementById('detail-modal-overlay').classList.remove('active');
}

// ============================================
// FILTERS
// ============================================

function initFilters() {
    document.getElementById('search-input').addEventListener('input', () => {
        clearTimeout(searchDebounce);
        searchDebounce = setTimeout(() => loadDashboard(), 300);
    });
    document.getElementById('filter-status').addEventListener('change', () => loadDashboard());
    document.getElementById('filter-type').addEventListener('change', () => loadDashboard());
    document.getElementById('filter-poc').addEventListener('change', () => loadDashboard());
    document.getElementById('btn-export').addEventListener('click', async () => {
        try {
            await api.exportCSV();
            showToast('Export downloaded', 'success');
        } catch (error) {
            showToast('Export failed', 'error');
        }
    });
}

function getCurrentFilters() {
    return {
        search: document.getElementById('search-input').value || undefined,
        status: document.getElementById('filter-status').value || undefined,
        type: document.getElementById('filter-type').value || undefined,
        poc: document.getElementById('filter-poc').value || undefined
    };
}

function populatePoCFilter(tasks) {
    const pocs = [...new Set(tasks.map(t => t.poc_name).filter(Boolean))];
    const select = document.getElementById('filter-poc');
    const currentValue = select.value;
    select.innerHTML = '<option value="">All PoC</option>' + pocs.map(p => `<option value="${p}">${p}</option>`).join('');
    select.value = currentValue;
}
