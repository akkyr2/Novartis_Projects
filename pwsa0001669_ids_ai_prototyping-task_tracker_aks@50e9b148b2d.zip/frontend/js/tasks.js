/**
 * FlowDesk - All Tasks Table View
 * Full Excel-like table with expand/collapse, weekly filters, and CSV export.
 * Column sequence matches Excel: Tasks, Type, PoC, Comment, Status, MS1-5, Milestone Description,
 * Completion Date, Upcoming Milestone, Days Remaining, Progress Comment WE1, Progress Comment WE2
 */

let tasksExpanded = false;
let selectedWeek = null;

async function loadTasksTable() {
    try {
        allTasks = await api.getTasks();
        renderTasksFilters();
        renderTasksTable(allTasks);
    } catch (error) {
        showToast('Failed to load tasks', 'error');
    }
}

function renderTasksFilters() {
    const container = document.getElementById('tasks-table-container');
    const filtersHtml = `
        <div class="filters-bar" id="tasks-filters-bar">
            <input type="text" class="filter-input" id="tasks-search" placeholder="Search tasks...">
            <div class="multiselect-dropdown" id="tasks-status-dropdown">
                <div class="multiselect-trigger" id="tasks-status-trigger">Status ▾</div>
                <div class="multiselect-options" id="tasks-status-options">
                    <label><input type="checkbox" value="Not Started"> Not Started</label>
                    <label><input type="checkbox" value="In-Progress"> In-Progress</label>
                    <label><input type="checkbox" value="Completed"> Completed</label>
                </div>
            </div>
            <select class="filter-select" id="tasks-filter-type">
                <option value="">All Types</option>
                <option value="Project">Project</option>
                <option value="Access Request">Access Request</option>
                <option value="Tech Spike">Tech Spike</option>
                <option value="Documentation">Documentation</option>
                <option value="Others">Others</option>
            </select>
            <select class="filter-select" id="tasks-filter-poc">
                <option value="">All PoC</option>
            </select>
            <select class="filter-select" id="tasks-filter-week">
                <option value="">All Time (Monthly)</option>
            </select>
            <button class="btn btn-secondary btn-sm" id="tasks-btn-export">📥 Export CSV</button>
            <button class="btn btn-primary btn-sm" id="tasks-btn-expand">${tasksExpanded ? '⬅️ Collapse' : '➡️ Expand All'}</button>
            <button class="btn btn-secondary btn-sm" id="tasks-btn-clear">✕ Clear</button>
        </div>
        <div id="tasks-table-content"></div>
    `;
    container.innerHTML = filtersHtml;

    // Populate PoC filter
    const pocs = [...new Set(allTasks.map(t => t.poc_name).filter(Boolean))];
    const pocSelect = document.getElementById('tasks-filter-poc');
    pocSelect.innerHTML = '<option value="">All PoC</option>' + pocs.map(p => `<option value="${p}">${escapeHtml(p)}</option>`).join('');

    // Populate week selector
    populateWeekSelector();

    // Attach events
    document.getElementById('tasks-search').addEventListener('input', debounceTasksFilter);
    document.getElementById('tasks-filter-type').addEventListener('change', applyTasksFilter);
    document.getElementById('tasks-filter-poc').addEventListener('change', applyTasksFilter);
    document.getElementById('tasks-filter-week').addEventListener('change', handleWeekChange);
    document.getElementById('tasks-btn-expand').addEventListener('click', toggleExpand);
    document.getElementById('tasks-btn-export').addEventListener('click', exportTasksCSV);
    document.getElementById('tasks-btn-clear').addEventListener('click', clearTasksFilters);

    // Multiselect status dropdown
    const trigger = document.getElementById('tasks-status-trigger');
    const options = document.getElementById('tasks-status-options');
    if (trigger) {
        trigger.addEventListener('click', () => {
            options.classList.toggle('open');
        });
        // Close on click outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('#tasks-status-dropdown')) {
                options.classList.remove('open');
            }
        });
    }
    // Checkbox change triggers filter
    document.querySelectorAll('#tasks-status-options input[type="checkbox"]').forEach(cb => {
        cb.addEventListener('change', () => {
            const checked = Array.from(document.querySelectorAll('#tasks-status-options input:checked')).map(c => c.value);
            trigger.textContent = checked.length > 0 ? checked.join(', ') + ' ▾' : 'Status ▾';
            applyTasksFilter();
        });
    });
}

function clearTasksFilters() {
    document.getElementById('tasks-search').value = '';
    document.querySelectorAll('#tasks-status-options input[type="checkbox"]').forEach(cb => cb.checked = false);
    document.getElementById('tasks-status-trigger').textContent = 'Status ▾';
    document.getElementById('tasks-filter-type').value = '';
    document.getElementById('tasks-filter-poc').value = '';
    document.getElementById('tasks-filter-week').value = '';
    selectedWeek = null;
    applyTasksFilter();
}

function populateWeekSelector() {
    const select = document.getElementById('tasks-filter-week');
    const today = new Date();
    let options = '<option value="">All Time (Monthly)</option>';

    for (let i = 0; i < 8; i++) {
        const weekEnd = new Date(today);
        weekEnd.setDate(today.getDate() - today.getDay() + 5 - (i * 7));
        const weekStart = new Date(weekEnd);
        weekStart.setDate(weekEnd.getDate() - 4);

        const startStr = formatDateShort(weekStart);
        const endStr = formatDateShort(weekEnd);
        const value = `${weekStart.toISOString().split('T')[0]}|${weekEnd.toISOString().split('T')[0]}`;

        const label = i === 0 ? `This Week (${startStr} - ${endStr})` :
                      i === 1 ? `Last Week (${startStr} - ${endStr})` :
                      `WE ${endStr}`;
        options += `<option value="${value}">${label}</option>`;
    }
    select.innerHTML = options;
}

function formatDateShort(date) {
    return `${String(date.getMonth() + 1).padStart(2, '0')}/${String(date.getDate()).padStart(2, '0')}`;
}

function handleWeekChange() {
    const val = document.getElementById('tasks-filter-week').value;
    if (val) {
        const [start, end] = val.split('|');
        selectedWeek = { start: new Date(start), end: new Date(end) };
    } else {
        selectedWeek = null;
    }
    applyTasksFilter();
}

let tasksDebounce = null;
function debounceTasksFilter() {
    clearTimeout(tasksDebounce);
    tasksDebounce = setTimeout(applyTasksFilter, 300);
}

function applyTasksFilter() {
    let filtered = [...allTasks];
    const search = document.getElementById('tasks-search').value.toLowerCase();
    const statusChecks = document.querySelectorAll('#tasks-status-options input[type="checkbox"]:checked');
    const selectedStatuses = Array.from(statusChecks).map(cb => cb.value);
    const type = document.getElementById('tasks-filter-type').value;
    const poc = document.getElementById('tasks-filter-poc').value;

    if (search) {
        filtered = filtered.filter(t =>
            t.name.toLowerCase().includes(search) ||
            (t.description && t.description.toLowerCase().includes(search))
        );
    }
    if (selectedStatuses.length > 0) filtered = filtered.filter(t => selectedStatuses.includes(t.status));
    if (type) filtered = filtered.filter(t => t.type === type);
    if (poc) filtered = filtered.filter(t => t.poc_name && t.poc_name.includes(poc));

    // If a week is selected, filter out tasks with no activity in that week
    if (selectedWeek) {
        filtered = filtered.filter(t => taskHasActivityInWeek(t, selectedWeek.start, selectedWeek.end));
    }

    renderTasksTable(filtered);
}

/**
 * Check if a task has any relevant activity in the given week:
 * - Has progress comments in that week
 * - Has milestones due in that week
 * - Was NOT already completed before that week started
 */
function taskHasActivityInWeek(task, weekStart, weekEnd) {
    // If task was completed before this week started, exclude it
    if (task.status === 'Completed' && task.completion_date) {
        const completedDate = new Date(task.completion_date);
        if (completedDate < weekStart) return false;
    }

    // Check if there are progress comments in this week
    if (task.progress_comments && task.progress_comments.length > 0) {
        const hasComment = task.progress_comments.some(c => {
            if (!c.created_at) return false;
            const d = new Date(c.created_at);
            return d >= weekStart && d <= weekEnd;
        });
        if (hasComment) return true;
    }

    // Check if any milestone falls within this week
    if (task.milestones && task.milestones.length > 0) {
        const hasMilestone = task.milestones.some(m => {
            if (!m.target_date) return false;
            const d = new Date(m.target_date);
            return d >= weekStart && d <= weekEnd;
        });
        if (hasMilestone) return true;
    }

    // No activity found for this week
    return false;
}

function toggleExpand() {
    tasksExpanded = !tasksExpanded;
    const btn = document.getElementById('tasks-btn-expand');
    btn.innerHTML = tasksExpanded ? '⬅️ Collapse' : '➡️ Expand All';
    applyTasksFilter();
}

// --- Helper functions ---

function truncateWords(text, maxWords) {
    if (!text) return '';
    const words = text.split(/\s+/);
    if (words.length <= maxWords) return text;
    return words.slice(0, maxWords).join(' ') + '...';
}

function renderTruncatedCell(text, maxWords) {
    if (!text) return '';
    const truncated = truncateWords(text, maxWords);
    if (truncated === text) return escapeHtml(text);
    return `<span class="cell-truncated" data-tooltip="${escapeHtml(text).replace(/"/g, '&quot;')}">${escapeHtml(truncated)}</span>`;
}

function getMilestoneDisplay(task, num) {
    if (!task.milestones) return '';
    const ms = task.milestones.find(m => m.milestone_number === num);
    if (!ms || !ms.target_date) return '';
    return ms.target_date;
}

function getMilestoneDescriptions(task) {
    if (!task.milestones || task.milestones.length === 0) return '';
    return task.milestones.map(m => `MS${m.milestone_number}: ${m.description || 'N/A'}`).join('\n');
}

function getCommentForWeek(task, weekStart, weekEnd) {
    if (!task.progress_comments || task.progress_comments.length === 0) return '';
    const comments = task.progress_comments.filter(c => {
        if (!c.created_at) return false;
        const d = new Date(c.created_at);
        return d >= weekStart && d <= weekEnd;
    });
    return comments.map(c => c.comment_text).join('\n');
}

function getWeek1Comment(task) {
    // WE 05/29/2026 — week ending May 29
    const start = new Date('2026-05-25');
    const end = new Date('2026-05-30');
    return getCommentForWeek(task, start, end);
}

function getWeek2Comment(task) {
    // WE 06/05/2026 — week ending June 5
    const start = new Date('2026-06-01');
    const end = new Date('2026-06-06');
    return getCommentForWeek(task, start, end);
}

function getSelectedWeekComment(task) {
    if (!selectedWeek) {
        // Show latest comment when no week selected
        if (task.progress_comments && task.progress_comments.length > 0) {
            return task.progress_comments[task.progress_comments.length - 1].comment_text || '';
        }
        return '';
    }
    return getCommentForWeek(task, selectedWeek.start, selectedWeek.end);
}

// --- Table rendering ---

function renderTasksTable(tasks) {
    const container = document.getElementById('tasks-table-content');
    if (!container) return;

    if (tasks.length === 0) {
        container.innerHTML = '<div class="card" style="text-align:center; padding:40px;"><p style="color:var(--text-muted)">No tasks found</p></div>';
        return;
    }

    // Expanded: show all columns matching Excel sequence
    // Excel columns: Tasks | Type | PoC | Comment | Status | MS1 | MS2 | MS3 | MS4 | MS5 | Milestone Description | Completion Date | Upcoming Milestone | Days Remaining | Progress Comment WE 05/29 | Progress Comment WE 06/05

    let headerHtml = '';
    let bodyRowFn;

    if (tasksExpanded) {
        headerHtml = `
            <tr>
                <th class="table-th">Tasks</th>
                <th class="table-th">Type</th>
                <th class="table-th">PoC</th>
                <th class="table-th">Comment</th>
                <th class="table-th">Status</th>
                <th class="table-th">MS 1</th>
                <th class="table-th">MS 2</th>
                <th class="table-th">MS 3</th>
                <th class="table-th">MS 4</th>
                <th class="table-th">MS 5</th>
                <th class="table-th">Milestone Description</th>
                <th class="table-th">Completion Date</th>
                <th class="table-th">Upcoming Milestone</th>
                <th class="table-th">Days Remaining</th>
                <th class="table-th">Progress Comment - WE 05/29</th>
                <th class="table-th">Progress Comment - WE 06/05</th>
                <th class="table-th" style="text-align:center;">Actions</th>
            </tr>
        `;
        bodyRowFn = (t, idx) => {
            const rowClass = idx % 2 === 0 ? 'table-row-even' : 'table-row-odd';
            return `
            <tr class="${rowClass}">
                <td class="table-td" style="font-weight:500; min-width:160px;">${escapeHtml(t.name)}</td>
                <td class="table-td">${escapeHtml(t.type)}</td>
                <td class="table-td">${escapeHtml(t.poc_name || '-')}</td>
                <td class="table-td" style="max-width:160px;">${renderTruncatedCell(t.comment || t.description || '', 8)}</td>
                <td class="table-td"><span class="badge badge-status ${getStatusClass(t.status)}">${t.status}</span></td>
                <td class="table-td">${escapeHtml(getMilestoneDisplay(t, 1))}</td>
                <td class="table-td">${escapeHtml(getMilestoneDisplay(t, 2))}</td>
                <td class="table-td">${escapeHtml(getMilestoneDisplay(t, 3))}</td>
                <td class="table-td">${escapeHtml(getMilestoneDisplay(t, 4))}</td>
                <td class="table-td">${escapeHtml(getMilestoneDisplay(t, 5))}</td>
                <td class="table-td" style="max-width:200px;">${renderTruncatedCell(getMilestoneDescriptions(t), 10)}</td>
                <td class="table-td">${t.completion_date || '-'}</td>
                <td class="table-td">${escapeHtml(t.upcoming_milestone || '-')}</td>
                <td class="table-td">${t.days_to_upcoming != null ? t.days_to_upcoming : '-'}</td>
                <td class="table-td" style="max-width:220px;">${renderTruncatedCell(getWeek1Comment(t), 10)}</td>
                <td class="table-td" style="max-width:220px;">${renderTruncatedCell(getWeek2Comment(t), 10)}</td>
                <td class="table-td" style="text-align:center; white-space:nowrap;">
                    <button class="btn btn-primary btn-sm" onclick="editTask(${t.id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteTask(${t.id})">Del</button>
                </td>
            </tr>`;
        };
    } else {
        // Compact: show key columns + selected week comment
        const weekLabel = selectedWeek ?
            `WE ${String(selectedWeek.end.getMonth()+1).padStart(2,'0')}/${String(selectedWeek.end.getDate()).padStart(2,'0')}` :
            'Latest Comment';

        headerHtml = `
            <tr>
                <th class="table-th">Tasks</th>
                <th class="table-th">Type</th>
                <th class="table-th">PoC</th>
                <th class="table-th">Status</th>
                <th class="table-th">Progress</th>
                <th class="table-th">Upcoming Milestone</th>
                <th class="table-th">Days</th>
                <th class="table-th">Progress Comment - ${escapeHtml(weekLabel)}</th>
                <th class="table-th" style="text-align:center;">Actions</th>
            </tr>
        `;
        bodyRowFn = (t, idx) => {
            const rowClass = idx % 2 === 0 ? 'table-row-even' : 'table-row-odd';
            const comment = getSelectedWeekComment(t);
            return `
            <tr class="${rowClass}">
                <td class="table-td" style="font-weight:500;">${escapeHtml(t.name)}</td>
                <td class="table-td">${escapeHtml(t.type)}</td>
                <td class="table-td">${escapeHtml(t.poc_name || '-')}</td>
                <td class="table-td"><span class="badge badge-status ${getStatusClass(t.status)}">${t.status}</span></td>
                <td class="table-td">
                    <div class="progress-bar-container" style="width:60px; height:5px;">
                        <div class="progress-bar" style="width:${t.completion_percentage}%"></div>
                    </div>
                </td>
                <td class="table-td">${escapeHtml(t.upcoming_milestone || '-')}</td>
                <td class="table-td">${t.days_to_upcoming != null ? t.days_to_upcoming : '-'}</td>
                <td class="table-td" style="max-width:250px;">${renderTruncatedCell(comment, 10)}</td>
                <td class="table-td" style="text-align:center; white-space:nowrap;">
                    <button class="btn btn-primary btn-sm" onclick="editTask(${t.id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteTask(${t.id})">Del</button>
                </td>
            </tr>`;
        };
    }

    container.innerHTML = `
        <div class="card" style="padding: 0;">
            <table>
                <thead>${headerHtml}</thead>
                <tbody>${tasks.map((t, idx) => bodyRowFn(t, idx)).join('')}</tbody>
            </table>
        </div>
    `;
}

// --- Export ---

async function exportTasksCSV() {
    const tasks = allTasks;

    // Export all columns matching Excel sequence
    const headers = [
        "Tasks", "Type", "PoC", "Comment", "Status",
        "Milestone 1", "Milestone 2", "Milestone 3", "Milestone 4", "Milestone 5",
        "Milestone Description", "Completion Date", "Upcoming Milestone",
        "Number of Days for Upcoming Milestone",
        "Progress Comment - WE 05/29/2026", "Progress Comment - WE 06/05/2026"
    ];

    const rows = tasks.map(t => [
        t.name || '',
        t.type || '',
        t.poc_name || '',
        t.comment || t.description || '',
        t.status || '',
        getMilestoneDisplay(t, 1),
        getMilestoneDisplay(t, 2),
        getMilestoneDisplay(t, 3),
        getMilestoneDisplay(t, 4),
        getMilestoneDisplay(t, 5),
        getMilestoneDescriptions(t),
        t.completion_date || '',
        t.upcoming_milestone || '',
        t.days_to_upcoming != null ? t.days_to_upcoming : '',
        getWeek1Comment(t),
        getWeek2Comment(t)
    ]);

    const csv = [headers, ...rows].map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FlowDesk_Weekly_Report.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    showToast('CSV exported', 'success');
}
