/**
 * FlowDesk - Dashboard View
 * Renders stat cards, task cards with progress bars and milestone timelines.
 */

async function loadDashboard() {
    try {
        const filters = getCurrentFilters();
        allTasks = await api.getTasks(filters);
        renderStats(allTasks);
        renderDashboardCards(allTasks);
        populatePoCFilter(allTasks);
    } catch (error) {
        showToast('Failed to load tasks. Is the API running?', 'error');
        console.error(error);
    }
}

function renderStats(tasks) {
    const total = tasks.length;
    const inProgress = tasks.filter(t => t.status === 'In-Progress').length;
    const completed = tasks.filter(t => t.status === 'Completed').length;
    const overdue = tasks.filter(t => t.is_overdue).length;

    document.getElementById('stats-grid').innerHTML = `
        <div class="stat-card">
            <div class="stat-value">${total}</div>
            <div class="stat-label">Total Tasks</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${inProgress}</div>
            <div class="stat-label">In Progress</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${completed}</div>
            <div class="stat-label">Completed</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">${overdue}</div>
            <div class="stat-label">Overdue</div>
        </div>
    `;
}

function renderDashboardCards(tasks) {
    const grid = document.getElementById('dashboard-grid');
    if (tasks.length === 0) {
        grid.innerHTML = `<div class="card" style="grid-column: 1/-1; text-align:center; padding:60px;">
            <p style="color: var(--text-muted); font-size: 1.1rem;">No tasks found. Create your first task!</p>
        </div>`;
        return;
    }

    grid.innerHTML = tasks.map(task => `
        <div class="card task-card ${task.is_overdue ? 'overdue' : ''}" onclick="openTaskDetail(${task.id})">
            <div class="task-card-header">
                <span class="task-card-title">${escapeHtml(task.name)}</span>
            </div>
            <div class="task-card-meta">
                <span class="badge badge-type">${escapeHtml(task.type)}</span>
                ${task.poc_name ? `<span class="badge badge-poc">${escapeHtml(task.poc_name)}</span>` : ''}
                <span class="badge badge-status ${getStatusClass(task.status)}">${task.status}</span>
                ${task.is_overdue ? '<span class="badge badge-overdue">OVERDUE</span>' : ''}
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar" style="width: ${task.completion_percentage}%"></div>
            </div>
            <div class="progress-label">${task.completion_percentage}% complete${task.days_to_upcoming != null ? ` • ${task.days_to_upcoming} days to next milestone` : ''}</div>
            <div class="milestone-timeline">
                ${renderMilestoneDots(task.milestones)}
            </div>
        </div>
    `).join('');
}

function renderMilestoneDots(milestones) {
    if (!milestones || milestones.length === 0) return '';
    return milestones.map(m => {
        let cls = '';
        if (m.is_completed) cls = 'completed';
        else if (m.is_overdue) cls = 'overdue';
        else if (m.days_remaining != null && m.days_remaining <= 7) cls = 'upcoming';
        return `<div class="milestone-dot ${cls}" title="${m.description || 'Milestone ' + m.milestone_number}${m.target_date ? ' (' + m.target_date + ')' : ''}">${m.milestone_number}</div>`;
    }).join('');
}
