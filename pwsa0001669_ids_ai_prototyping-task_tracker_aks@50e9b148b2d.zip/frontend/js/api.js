/**
 * FlowDesk API Client
 * Handles all communication with the FastAPI backend.
 * Falls back to demo data (from demoData.js) when API is unavailable.
 */

const API_BASE = './api';

// Track if we're currently showing demo data
let isUsingDemoData = false;

/**
 * Check if demo mode is available and enabled.
 */
function isDemoAvailable() {
    return typeof DEMO_MODE_ENABLED !== 'undefined' && DEMO_MODE_ENABLED === true && typeof DEMO_TASKS !== 'undefined';
}

function setDemoMode(active) {
    isUsingDemoData = active;
    updateDemoBanner();
}

function updateDemoBanner() {
    let banner = document.getElementById('demo-mode-banner');
    if (isUsingDemoData) {
        if (!banner) {
            banner = document.createElement('div');
            banner.id = 'demo-mode-banner';
            banner.style.cssText = `
                position: fixed;
                bottom: 16px;
                left: 50%;
                transform: translateX(-50%);
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                color: white;
                padding: 8px 20px;
                border-radius: 20px;
                font-size: 0.75rem;
                font-weight: 600;
                z-index: 9999;
                box-shadow: 0 4px 20px rgba(240, 147, 251, 0.4);
                letter-spacing: 0.5px;
                text-transform: uppercase;
            `;
            banner.textContent = '⚡ Demo Mode — Showing sample data';
            document.body.appendChild(banner);
        }
        banner.style.display = 'block';
    } else if (banner) {
        banner.style.display = 'none';
    }
}

/**
 * Fetch with timeout — prevents hanging when API is down.
 */
function fetchWithTimeout(url, options = {}, timeout = 3000) {
    return Promise.race([
        fetch(url, options),
        new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Request timeout')), timeout)
        )
    ]);
}

// --- Filter demo data locally ---
function filterDemoTasks(filters = {}) {
    let tasks = JSON.parse(JSON.stringify(DEMO_TASKS)); // deep copy

    if (filters.status) {
        tasks = tasks.filter(t => t.status === filters.status);
    }
    if (filters.type) {
        tasks = tasks.filter(t => t.type === filters.type);
    }
    if (filters.poc) {
        tasks = tasks.filter(t => t.poc_name && t.poc_name.toLowerCase().includes(filters.poc.toLowerCase()));
    }
    if (filters.search) {
        const q = filters.search.toLowerCase();
        tasks = tasks.filter(t =>
            t.name.toLowerCase().includes(q) ||
            (t.description && t.description.toLowerCase().includes(q))
        );
    }
    if (filters.role === 'member' && filters.user) {
        tasks = tasks.filter(t => t.poc_name && t.poc_name.toLowerCase().includes(filters.user.toLowerCase()));
    }

    return tasks;
}

/**
 * Force load demo data — called by the "Load Demo" button
 */
function forceLoadDemoData() {
    if (!isDemoAvailable()) {
        showToast('Demo data not available', 'error');
        return;
    }
    setDemoMode(true);
    // Trigger a refresh of current page
    if (typeof refreshCurrentPage === 'function') {
        refreshCurrentPage();
    }
}

const api = {
    // --- Tasks ---
    async getTasks(filters = {}) {
        // If demo mode is active, use demo data directly
        if (isUsingDemoData && isDemoAvailable()) {
            return filterDemoTasks(filters);
        }

        try {
            const params = new URLSearchParams();
            if (filters.status) params.append('status', filters.status);
            if (filters.type) params.append('type', filters.type);
            if (filters.poc) params.append('poc', filters.poc);
            if (filters.search) params.append('search', filters.search);
            if (filters.role) params.append('role', filters.role);
            if (filters.user) params.append('user', filters.user);

            const url = `${API_BASE}/tasks?${params.toString()}`;
            const response = await fetchWithTimeout(url);
            if (!response.ok) throw new Error('API error');
            const data = await response.json();

            // API returned real data
            setDemoMode(false);
            return data;
        } catch (error) {
            // API unreachable — return empty (don't auto-fallback to demo)
            // Demo only loads on first page load or when user clicks Demo button
            console.warn('API unreachable:', error.message);
            return [];
        }
    },

    async getTask(taskId) {
        if (isUsingDemoData && isDemoAvailable()) {
            const task = DEMO_TASKS.find(t => t.id == taskId);
            if (task) return JSON.parse(JSON.stringify(task));
            throw new Error('Task not found in demo data');
        }

        const response = await fetchWithTimeout(`${API_BASE}/tasks/${taskId}`);
        if (!response.ok) throw new Error('Failed to fetch task');
        return response.json();
    },

    async createTask(taskData) {
        if (isUsingDemoData && isDemoAvailable()) {
            const newTask = {
                id: Math.max(...DEMO_TASKS.map(t => t.id)) + 1,
                ...taskData,
                poc_name: taskData.poc_name || null,
                description: taskData.description || null,
                comment: taskData.comment || null,
                completion_percentage: taskData.status === 'Completed' ? 100 : 0,
                upcoming_milestone: null,
                days_to_upcoming: null,
                is_overdue: false,
                milestones: [],
                progress_comments: [],
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            };
            DEMO_TASKS.push(newTask);
            return newTask;
        }

        const response = await fetchWithTimeout(`${API_BASE}/tasks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(taskData)
        });
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || 'Failed to create task');
        }
        return response.json();
    },

    async updateTask(taskId, taskData) {
        if (isUsingDemoData && isDemoAvailable()) {
            const idx = DEMO_TASKS.findIndex(t => t.id == taskId);
            if (idx !== -1) {
                Object.assign(DEMO_TASKS[idx], taskData, { updated_at: new Date().toISOString() });
                return JSON.parse(JSON.stringify(DEMO_TASKS[idx]));
            }
            throw new Error('Task not found');
        }

        const response = await fetchWithTimeout(`${API_BASE}/tasks/${taskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(taskData)
        });
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || 'Failed to update task');
        }
        return response.json();
    },

    async deleteTask(taskId) {
        if (isUsingDemoData && isDemoAvailable()) {
            const idx = DEMO_TASKS.findIndex(t => t.id == taskId);
            if (idx !== -1) {
                DEMO_TASKS.splice(idx, 1);
                return { message: "Task deleted", id: taskId };
            }
            throw new Error('Task not found');
        }

        const response = await fetchWithTimeout(`${API_BASE}/tasks/${taskId}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('Failed to delete task');
        return response.json();
    },

    // --- Progress Comments ---
    async addComment(taskId, commentData) {
        if (isUsingDemoData && isDemoAvailable()) {
            const task = DEMO_TASKS.find(t => t.id == taskId);
            if (task) {
                const comment = {
                    id: Date.now(),
                    ...commentData,
                    created_at: new Date().toISOString()
                };
                task.progress_comments.unshift(comment);
                return comment;
            }
            throw new Error('Task not found');
        }

        const response = await fetchWithTimeout(`${API_BASE}/tasks/${taskId}/comments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(commentData)
        });
        if (!response.ok) throw new Error('Failed to add comment');
        return response.json();
    },

    // --- Reports ---
    async getSummaryReport() {
        if (isUsingDemoData && isDemoAvailable()) {
            return DEMO_SUMMARY_REPORT;
        }

        try {
            const response = await fetchWithTimeout(`${API_BASE}/reports/summary`);
            if (!response.ok) throw new Error('API error');
            return response.json();
        } catch (error) {
            console.warn('Reports API unreachable:', error.message);
            return { total_tasks: 0, tasks_by_status: {}, tasks_by_type: {}, overdue_count: 0 };
        }
    },

    // --- Export ---
    async exportCSV() {
        if (isUsingDemoData && isDemoAvailable()) {
            const headers = ["Name", "Type", "PoC", "Description", "Status", "Completion %", "Upcoming Milestone"];
            const rows = DEMO_TASKS.map(t => [
                t.name, t.type, t.poc_name || '', t.description || '',
                t.status, t.completion_percentage, t.upcoming_milestone || ''
            ]);
            const csv = [headers, ...rows].map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'flowdesk_demo_export.csv';
            a.click();
            window.URL.revokeObjectURL(url);
            return;
        }

        const response = await fetchWithTimeout(`${API_BASE}/tasks/export/csv`);
        if (!response.ok) throw new Error('Failed to export');
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'flowdesk_export.csv';
        a.click();
        window.URL.revokeObjectURL(url);
    },

    // --- Notifications ---
    async getNotifications() {
        if (isUsingDemoData && isDemoAvailable()) {
            return [
                { id: 1, task_name: "ABL Coaching Agent", milestone_description: "Demo with Business", milestone_date: "2026-06-08", notification_type: "reminder", is_read: false, created_at: "2026-06-05T08:00:00Z" },
                { id: 2, task_name: "Voice-IQ Documentation", milestone_description: "Documentation completion", milestone_date: "2026-05-22", notification_type: "overdue", is_read: false, created_at: "2026-06-05T08:00:00Z" },
                { id: 3, task_name: "DRA62 Cost and Usage Tracking", milestone_description: "Initial basic report", milestone_date: "2026-06-08", notification_type: "reminder", is_read: false, created_at: "2026-06-05T08:00:00Z" }
            ];
        }

        try {
            const response = await fetchWithTimeout(`${API_BASE}/notifications`);
            if (!response.ok) throw new Error('API error');
            return response.json();
        } catch (error) {
            return [];
        }
    },

    async generateNotifications() {
        if (isUsingDemoData) {
            return { message: "Generated 3 notifications (demo)" };
        }
        const response = await fetchWithTimeout(`${API_BASE}/notifications/generate`, { method: 'POST' });
        if (!response.ok) throw new Error('Failed to generate notifications');
        return response.json();
    }
};
