<!--
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
-->

# MBR Dashboard - Code Reference & Implementation Guide

**Document Version:** 1.4  
**Date:** December 16, 2025  
**System Version:** V2.2.1  
**Author:** AI Development Team

---

## 1. Executive Summary

### Document Purpose

This document provides a comprehensive code reference for the MBR Dashboard system, including:
- Complete function-level documentation for all Python and TypeScript files
- Data schema and mock data generation details
- Step-by-step implementation guides for common modifications
- Provider switching guide (AWS Bedrock → Google/OpenAI/Azure/etc.)

**Target Audience:**
- Developers maintaining or extending the system
- New team members onboarding to the codebase
- Technical architects evaluating the implementation

### Codebase Overview

**Backend: Python 3.9+ with Flask**
- Framework: Flask (lightweight REST API)
- AI/ML: AWS Bedrock (Claude Sonnet 4.5)
- Database: DynamoDB (5 tables)
- Text-to-Speech: Amazon Polly
- Architecture: Custom agent with function calling

**Frontend: TypeScript with React 18**
- Framework: React 18 with TypeScript
- Build Tool: Vite
- Charting: Recharts
- Voice Input: Web Speech API (browser-native)
- Styling: CSS3 with QuickSuite purple theme

**Utility Scripts: Python**
- Data generation and transformation
- DynamoDB upload and management
- Testing and validation

### File Organization Structure

```
MBR_Dashboard/
├── backend_api/                    # Python backend
│   ├── app.py                      # Main Flask API (PRODUCTION)
│   ├── config.py                   # Configuration management
│   ├── aws_clients.py              # Centralized AWS client management
│   ├── Dockerfile                  # Docker container definition
│   ├── novartis_agent_handler_v2_1.py  # Agent with 5 tools (PRODUCTION)
│   ├── novartis_queries_v2_1.py    # DynamoDB queries (PRODUCTION)
│   ├── slide_preprocessor.py       # Slide preprocessing engine
│   ├── novartis_agent_handler_v2.py    # V2.0 (3 tools, legacy)
│   ├── novartis_queries_v2.py      # V2.0 queries (legacy)
│   ├── novartis_agent_handler.py   # V1.0 (10 tools, legacy)
│   ├── novartis_queries.py         # V1.0 queries (legacy)
│   └── frontend/                   # Built frontend (for Docker)
│       ├── index.html
│       ├── logos/
│       └── static/
├── frontend/                       # React frontend source
│   ├── src/
│   │   ├── App.tsx                 # Main application
│   │   ├── index.tsx               # Entry point
│   │   ├── components/
│   │   │   ├── AIPanel.tsx         # Chat interface
│   │   │   ├── ChartDisplay.tsx    # Chart visualization
│   │   │   ├── VoiceControls.tsx   # Voice input
│   │   │   ├── PDFUpload.tsx       # PDF upload
│   │   │   └── SlideViewer.tsx     # Slide navigation
│   │   ├── services/               # API services
│   │   └── styles/                 # CSS styles
│   ├── public/
│   │   └── logos/                  # Logo assets
│   ├── package.json
│   ├── tsconfig.json
│   └── build/                      # Production build output
├── utils/                          # Utility scripts
│   ├── aws/
│   │   └── aws_utils.py           # AWS credential management
│   ├── data_generation/
│   │   ├── generate_all_data.py   # Unified data generator (PRODUCTION)
│   │   ├── generate_mbr_slides.py # MBR slide generator
│   │   └── preprocess_slides.sh   # Slide preprocessing script
│   └── data_management/
│       ├── load_all_tables.py     # Create tables & load data
│       └── load_dynamodb_data.py  # Load data to existing tables
├── infrastructure/                 # AWS CDK deployment
│   ├── bin/
│   │   └── mbr-dashboard.ts       # CDK app entry point
│   ├── cdk.json                   # CDK configuration
│   ├── package.json               # Node.js dependencies
│   ├── tsconfig.json              # TypeScript config
│   └── jest.config.js             # Jest test configuration
│   # NOTE: lib/ folder with stack definition should be created for CDK deployment
├── scripts/                        # Test & diagnostic scripts
│   ├── bedrock_agent/
│   │   ├── test_end_to_end.py
│   │   └── test_vision_model.py
│   ├── test_*.py                  # Various test files
│   ├── setup-vpc-testing.sh       # Automated AWS deployment testing
│   ├── check_aws_access.py        # AWS access verification
│   ├── cleanup_aws_resources.py   # Resource cleanup tool
│   ├── fix_forecast_types.py      # Helper script (archived)
│   └── generate_all_data_COMPLETE.py  # Backup of unified generator
├── docs/                           # Documentation
│   ├── ISENGUARD_SETUP.md         # AWS credential setup guide
│   ├── SAMPLE_QUESTIONS.md        # Example queries
│   └── ... (session summaries, architecture docs)
├── data/                           # Data files
│   ├── data_docs/                 # Data documentation
│   │   ├── DATA_CATALOGUE.md
│   │   ├── TABLE_ROUTING_GUIDE.md
│   │   └── ... (7 .md files)
│   └── data_samples/              # Production data
│       ├── FCT_CALLS_expanded.csv
│       ├── FCT_DOSES_PLU_corrected.csv
│       ├── FCT_MARKET_PLU_corrected.csv
│       ├── FCT_ROME_PLU_expanded.csv
│       ├── SALES_FINANCE_BPC_corrected.csv
│       └── Novartis_MBR_*.pdf/pptx/jpeg
├── uploads/                        # Temporary upload storage
│   ├── presentation.pdf            # Uploaded PDF
│   ├── preprocessed_slides.json    # Extracted slide data
│   └── slides/                     # Slide images
│       └── slide_*.png
├── archive/                        # Archived documentation
├── deploy.sh                       # AWS deployment script (CDK-based)
├── cleanup.sh                      # AWS resource cleanup script
├── dev.sh                          # Local development helper script
├── .env.example.aws                # AWS environment configuration template
├── requirements.txt                # Python dependencies
└── README.md                       # Project documentation
```

### Version Information

**Current Production Version:** V2.2.1

**Version History:**
- V1.0: 10 fragmented tools, Python aggregation (30-50s response time)
- V2.0: 3 table-aligned tools, Claude aggregation (13-15s response time)
- V2.1: 5 table-aligned tools, complete MBR coverage (17-20s response time)
- V2.2: Preprocessing system, multi-series charts (7-10s response time)

**Key Architectural Changes:**
- V1.0 → V2.0: Eliminated Python aggregation, table-aligned tools
- V2.0 → V2.1: Added FCT_CALLS and FCT_ROME_PLU tables
- V2.1 → V2.2: Preprocessing system, connection pooling, smart routing

---

## 2. Data Schema & Generation

### 2.1 Data Overview

**5 DynamoDB Tables:**
1. SALES_FINANCE_BPC_corrected - Financial performance
2. FCT_MARKET_PLU_corrected - Market intelligence
3. FCT_DOSES_PLU_corrected - Supply and demand
4. FCT_CALLS - Field force activity
5. FCT_ROME_PLU - Site-level orders and demand

**Data Time Range:**
- Actual data: 2020-2025 (6 years)
- Forecast data: 2026-2028 (3 years, Sales and Doses only)
- Total records: ~30,000+ across all tables

**Data Granularity:**
- Base granularity: Monthly
- Aggregation: Handled by Claude (quarterly, yearly, YTD, custom periods)
- Relative indexes: Pre-calculated for fast filtering

**Data Sources:**
- Original: CSV files from business systems
- Corrections: Applied via Python scripts (relative indexes, date formats)
- Expansion: Generated via Python scripts (2020-2025 coverage)
- Upload: Batch upload to DynamoDB via boto3



### 2.2 Table Schemas

#### Table 1: SALES_FINANCE_BPC_corrected

**Purpose:** Aggregated sales forecast data for performance analysis and planning

**Row Count:** 105 base records → expanded for complete coverage

**Columns (14 total):**

| Column | Type | Description |
|--------|------|-------------|
| product | String | Product name (Pluvicto, Lutathera, Xofigo, Novacure) |
| brand | String | Novartis product name |
| forecast_type | String | Actual, Budget, or OC (Operating Committee) |
| date | Date | Month of sales (YYYY-MM-DD) |
| net_sales | Numeric | Net sales in dollars |
| gross_sales | Numeric | Gross sales in dollars |
| revenue_deductions | Numeric | Revenue deductions in dollars |
| source | String | Unique identifier (e.g., "BPC_SALES") |
| data_frequency | String | Monthly or weekly |
| month_rel_index | Integer | Relative month (1000=current, 999=last month) |
| year_rel_index | Integer | Relative year (1000=current, 999=last year) |
| cycle_rel_index | Integer | Relative quarter (1000=current, 999=last quarter) |
| year_quarter | String | Year and quarter (e.g., "2023-Q1") |
| last_altered | Timestamp | Latest source refresh timestamp |

**Sample Data:**
```json
{
  "product": "Pluvicto",
  "brand": "Pluvicto",
  "forecast_type": "Actual",
  "date": "2025-01-01",
  "net_sales": 88000000,
  "gross_sales": 95000000,
  "revenue_deductions": 7000000,
  "month_rel_index": 1000,
  "year_rel_index": 1000,
  "cycle_rel_index": 1000,
  "year_quarter": "2025-Q1"
}
```

**Use Cases:**
- Revenue analysis and forecasting
- Actual vs Budget vs OC comparisons
- Year-over-year and month-over-month trends
- Quarterly and annual performance tracking

#### Table 2: FCT_MARKET_PLU_corrected

**Purpose:** Monthly market volumes for Pluvicto and competitor brands

**Row Count:** 67 base records

**Columns (13 total):**

| Column | Type | Description |
|--------|------|-------------|
| product | String | Product name (including competitors) |
| brand | String | Novartis product name |
| class | String | Product class (detailed) |
| class_aggregated | String | Product class (aggregated) |
| date | Date | Month of sales |
| TRX_R3M | Numeric | Total demand volume (rolling 3 months) |
| TRX_SHARE_R3M | Numeric | Market share (rolling 3 months) |
| NBRX_R3M | Numeric | New patient volume (rolling 3 months) |
| NBRX_SHARE_R3M | Numeric | New patient share (rolling 3 months) |
| month_rel_index | Integer | Relative month index |
| year_rel_index | Integer | Relative year index |
| cycle_rel_index | Integer | Relative quarter index |
| year_quarter | String | Year and quarter |

**Sample Data:**
```json
{
  "product": "Pluvicto",
  "brand": "Pluvicto",
  "date": "2024-12-01",
  "TRX_R3M": 1500,
  "TRX_SHARE_R3M": 30.64,
  "NBRX_R3M": 450,
  "NBRX_SHARE_R3M": 30.64,
  "month_rel_index": 999,
  "year_rel_index": 999
}
```

**Use Cases:**
- Market share analysis
- Competitor tracking
- Market volume trends
- New patient acquisition analysis

#### Table 3: FCT_DOSES_PLU_corrected

**Purpose:** Product doses shipped over time

**Row Count:** 105 base records

**Columns (9 total):**

| Column | Type | Description |
|--------|------|-------------|
| product | String | Product name |
| brand | String | Novartis product name |
| date | Date | Month of sales |
| forecast_type | String | Actual, Budget, or OC |
| value | Numeric | Metric value at national level |
| metric | String | TRX_shipped, TRX_injected, or NBRX |
| month_rel_index | Integer | Relative month index |
| year_rel_index | Integer | Relative year index |
| quarter_rel_index | Integer | Relative quarter index |

**Sample Data:**
```json
{
  "product": "Pluvicto",
  "brand": "Pluvicto",
  "date": "2025-01-01",
  "forecast_type": "Actual",
  "value": 1200,
  "metric": "TRX_shipped",
  "month_rel_index": 1000,
  "year_rel_index": 1000,
  "quarter_rel_index": 1000
}
```

**Use Cases:**
- Dose shipment tracking
- Injection rate analysis
- New patient (NBRX) tracking
- Actual vs Budget dose performance

#### Table 4: FCT_CALLS

**Purpose:** Field force activity and sales rep performance

**Row Count:** 180 base → 1,920 expanded (2020-2025)

**Key Columns (39 total):**

| Column | Type | Description |
|--------|------|-------------|
| product | String | Product name |
| dim_geo_level | String | Nation or Region |
| dim_geo_name | String | Geographic name (e.g., "Northeast") |
| dim_time_period | String | Time period (e.g., "2024-Q1") |
| dim_metric_type | String | Metric type |
| CPD | Numeric | Calls per day |
| cpd_goal | Numeric | CPD target |
| cpd_attainment | Numeric | CPD attainment percentage |
| target_hcp_reach | Numeric | Target HCP reach |
| total_target | Numeric | Total target |
| percent_reached | Numeric | Percentage reached |
| call_frequency_actual | Numeric | Actual call frequency |
| call_frequency_attainment | Numeric | Call frequency attainment |
| actual_calls | Numeric | Actual number of calls |
| planned_calls | Numeric | Planned number of calls |
| cycle_rel_index | Integer | Relative quarter index |
| call_date | Date | Call date |
| year_quarter | String | Year and quarter |

**Sample Data:**
```json
{
  "product": "Pluvicto",
  "dim_geo_level": "Region",
  "dim_geo_name": "Northeast",
  "dim_time_period": "2024-Q1",
  "CPD": 8.5,
  "cpd_goal": 10.0,
  "cpd_attainment": 85.0,
  "target_hcp_reach": 500,
  "percent_reached": 78.5,
  "actual_calls": 1200,
  "planned_calls": 1500
}
```

**Use Cases:**
- Field activity analysis
- Sales rep performance tracking
- HCP reach and engagement
- Call frequency attainment
- Territory performance comparison

#### Table 5: FCT_ROME_PLU

**Purpose:** Site-level order and demand data

**Row Count:** 217 base → 2,951 expanded (2020-2025)

**Key Columns:**

| Column | Type | Description |
|--------|------|-------------|
| product | String | Product name |
| territory | String | Territory name |
| site | String | Site identifier |
| customer | String | Customer identifier |
| demand_metric | String | Demand metric type |
| value | Numeric | Metric value |
| date | Date | Date |
| status | String | Site status (Active, Dormant, etc.) |

**Sample Data:**
```json
{
  "product": "Pluvicto",
  "territory": "Northeast",
  "site": "SITE_001",
  "demand_metric": "first_dose_orders",
  "value": 25,
  "date": "2024-12-01",
  "status": "Active"
}
```

**Use Cases:**
- Site activation tracking
- Patient demand by territory
- Dormant site identification
- First dose order tracking
- Regional performance analysis

### 2.3 Data Generation & Upload Scripts

#### generate_all_data.py (utils/data_generation/)

**Purpose:** Unified data generator that creates all 5 CSV files with consistent schemas and realistic data patterns.

**Location:** `utils/data_generation/generate_all_data.py`

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `generate_sales_finance_data()` | Generate SALES_FINANCE_BPC_corrected.csv (2020-2025) | None | pandas DataFrame (864 rows) |
| `generate_market_data()` | Generate FCT_MARKET_PLU_corrected.csv (2020-2028) | None | pandas DataFrame (756 rows) |
| `generate_doses_data()` | Generate FCT_DOSES_PLU_corrected.csv (2020-2025) | None | pandas DataFrame (2,592 rows) |
| `generate_calls_data()` | Generate FCT_CALLS_expanded.csv (2020-2025) | None | pandas DataFrame (7,296 rows) |
| `generate_rome_data()` | Generate FCT_ROME_PLU_expanded.csv (2020-2025) | None | pandas DataFrame (2,959 rows) |
| `create_call_record()` | Helper to create single call record with all metrics | product, geo_level, geo_name, quarter, dates, growth_factor | dict (single record) |

**Key Features:**
- Single script generates all 5 CSV files
- Timestamped output directories: `data/data_samples_YYYYMMDD_HHMMSS/`
- Consistent headers matching original files exactly
- Correct forecast types: Actual, Budget, OC (not "Latest Estimate")
- Market data includes 3 competitors (A, B, C) and extends to 2028
- Realistic growth patterns by product
- Relative indexing system (1000-based)
- Reproducible with seed=42

**Data Generated:**
1. **SALES_FINANCE_BPC_corrected.csv**: 864 rows
   - 4 products × 6 years × 12 months × 3 forecast types
   - Forecast types: 288 Actual, 288 Budget, 288 OC

2. **FCT_MARKET_PLU_corrected.csv**: 756 rows
   - 7 brands (4 products + 3 competitors) × 108 months (2020-2028)
   - Includes Competitor_A, Competitor_B, Competitor_C

3. **FCT_DOSES_PLU_corrected.csv**: 2,592 rows
   - 4 products × 6 years × 12 months × 3 metrics × 3 forecast types
   - Metrics: TRX_shipped, TRX_injected, NBRX
   - Forecast types: 864 Actual, 864 Budget, 864 OC

4. **FCT_CALLS_expanded.csv**: 7,296 rows
   - 4 products × 3 geo levels × 6 years × 4 quarters × 4 metric types
   - Geo levels: Nation, Region (4), Territory (13)
   - Metrics: hcp_reach, cpd, call_frequency_attainment, total_calls

5. **FCT_ROME_PLU_expanded.csv**: 2,959 rows
   - 12 sites × 4 products × 6 years × 12 months (variable orders per month)
   - Order statuses: Open, Shipped, Delivered, Cancelled
   - Patient dose sequences (1-6 doses)

**Usage:**
```bash
python3 utils/data_generation/generate_all_data.py
```

**Output:**
- Creates timestamped folder: `data/data_samples_20251217_123450/`
- Saves all 5 CSV files without `_new` suffix
- Ready for upload to DynamoDB

#### load_all_tables.py (utils/data_management/)

**Purpose:** Create DynamoDB tables and load all 5 CSV files with automatic table creation and batch upload.

**Location:** `utils/data_management/load_all_tables.py`

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `convert_to_dynamodb_format()` | Convert pandas values to DynamoDB-compatible Decimal/String types | value: Any pandas value | Decimal, String, or None |
| `get_or_create_table()` | Get existing table or create if it doesn't exist | dynamodb, table_name: str, with_gsi: bool | DynamoDB Table object |
| `load_sales_finance_data()` | Load SALES_FINANCE_BPC_corrected.csv to DynamoDB | dynamodb, data_dir: str | int (record count) |
| `load_market_data()` | Load FCT_MARKET_PLU_corrected.csv to DynamoDB | dynamodb, data_dir: str | int (record count) |
| `load_doses_data()` | Load FCT_DOSES_PLU_corrected.csv to DynamoDB | dynamodb, data_dir: str | int (record count) |
| `load_calls_data()` | Load FCT_CALLS_expanded.csv to DynamoDB | dynamodb, data_dir: str | int (record count) |
| `load_rome_data()` | Load FCT_ROME_PLU_expanded.csv to DynamoDB | dynamodb, data_dir: str | int (record count) |
| `main()` | Orchestrate table creation and data loading | Command line args: --data-dir, --profile | None (prints status) |

**Key Features:**
- Automatic table creation with GSI if tables don't exist
- Batch writing (25 items per batch)
- Progress tracking every 100 records
- Normalized columns for Sales/Market/Doses
- Raw CSV columns for Calls/Rome
- Composite key generation (PK/SK)
- Billing Mode: PAY_PER_REQUEST

**Table Schemas Created:**
- Primary Key: PK (partition), SK (sort)
- GSI1: GSI1PK (partition), GSI1SK (sort)
- All tables include entity_type attribute for filtering

**Usage:**
```bash
# Use default data directory (data/data_samples/)
python3 utils/data_management/load_all_tables.py

# Use custom data directory
python3 utils/data_management/load_all_tables.py --data-dir data/data_samples_20251217_123450

# Use specific AWS profile
python3 utils/data_management/load_all_tables.py --profile mo-nov
```

#### load_dynamodb_data.py (utils/data_management/)

**Purpose:** Load data into existing DynamoDB tables (for CDK deployments where tables are pre-created).

**Location:** `utils/data_management/load_dynamodb_data.py`

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `convert_to_dynamodb_format()` | Convert pandas values to DynamoDB types | value: Any | Decimal/String/None |
| `get_existing_table()` | Get reference to existing DynamoDB table | dynamodb, table_name: str | DynamoDB Table object |
| `load_sales_finance_data()` | Load SALES data to existing table | dynamodb, data_dir: str | int (record count) |
| `load_market_data()` | Load MARKET data to existing table | dynamodb, data_dir: str | int (record count) |
| `load_doses_data()` | Load DOSES data to existing table | dynamodb, data_dir: str | int (record count) |
| `load_calls_data()` | Load CALLS data to existing table | dynamodb, data_dir: str | int (record count) |
| `load_rome_data()` | Load ROME data to existing table | dynamodb, data_dir: str | int (record count) |
| `main()` | Load data into pre-existing tables | Command line args: --data-dir, --profile | None (prints status) |

**Key Features:**
- Assumes tables are already created by CDK infrastructure
- Validates table existence before loading
- Batch writing with progress tracking
- Error handling for missing tables
- Supports custom data directories

**Usage:**
```bash
# After CDK deployment creates tables
python3 utils/data_management/load_dynamodb_data.py --data-dir data/data_samples/

# Use specific AWS profile
python3 utils/data_management/load_dynamodb_data.py --profile mo-nov
```

**Difference from load_all_tables.py:**
- `load_all_tables.py`: Creates tables if they don't exist (standalone use)
- `load_dynamodb_data.py`: Requires tables to exist (CDK deployment use)

## 3. Backend Implementation (Python)

### 3.1 Main API Server (app.py)

**Purpose:** Flask REST API server connecting React frontend to AWS services (Bedrock, DynamoDB, Polly).

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `invoke_bedrock_with_retry()` | Call Bedrock with exponential backoff retry logic | request_body: dict, max_retries: int, initial_delay: int | dict (Bedrock response) |
| `ask_question()` | Main endpoint: process user questions with agent or rule-based mode | POST /api/ask: question, slideNumber, conversationHistory, agentMode | JSON: answer, chartData, audioSummary, dataSource, timing |
| `synthesize_speech()` | Convert text to speech using Amazon Polly Neural | POST /api/synthesize: text | JSON: audio (base64), format |
| `resolve_follow_up_question()` | Resolve follow-up questions using conversation context | question: str, conversation_history: list | str (resolved question) |
| `extract_suggested_question()` | Extract suggested follow-up from assistant response | response_text: str | str or None (suggested question) |
| `extract_query_context()` | Extract query context (data type, chart type, time period) | response_text: str | dict (context info) |
| `load_preprocessed_slides()` | Load preprocessed slide data from JSON file | None | list of slide dicts or None |
| `get_slide_context()` | Get preprocessed context for specific slide | slide_number: int | dict or None (slide context) |
| `preprocess_pdf()` | Upload and preprocess PDF slides endpoint | POST /api/preprocess: PDF file | JSON: status updates |

**Key Features:**
- ALWAYS uses agent mode (QuickSuite-style) for better quality
- Conversation history support (last 6 messages for context)
- Follow-up question resolution (detects "yes", "same chart", etc.)
- Preprocessing system for slide analysis
- Connection pooling to prevent leaks
- Comprehensive error handling and logging

**Endpoints:**
- `POST /api/ask` - Process questions (main endpoint)
- `POST /api/synthesize` - Text-to-speech conversion
- `POST /api/preprocess` - PDF upload and preprocessing
- `GET /api/health` - Health check

### 3.2 Agent Handler (novartis_agent_handler_v2_1.py)

**Purpose:** Claude Sonnet agent with 5 table-aligned tools for MBR data queries.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `generate_chart_data()` | Generate chart configuration from tool results | tool_name: str, tool_input: dict, tool_result: dict, question: str | dict or None (chart config) |
| `execute_tool()` | Execute a tool and return results | tool_name: str, tool_input: dict | dict: {success, data, record_count} |
| `handle_question_with_agent()` | Main agent handler with tool calling | question: str, image_base64: str, conversation_history: list, slide_number: int, use_preprocessed: bool | tuple: (answer, chart_data, audio_summary, data_source) |

**Tool Definitions (5 tools):**
1. `query_sales_finance_table` - Revenue, sales, gross sales, deductions
2. `query_doses_table` - National-level doses (TRX_shipped, TRX_injected, NBRX)
3. `query_market_share_table` - Market share, competitors, volumes
4. `query_calls_table` - Field activity, HCP reach, call frequency
5. `query_rome_table` - Site activity, patient demand, territories

**Key Features:**
- ONE question = ONE table = ONE tool call philosophy
- Claude does analysis/aggregation, DynamoDB does filtering
- Automatic chart generation from tool results
- Multi-series chart support (Actual vs Budget)
- Audio summary extraction from response
- Conversation history support (last 2 exchanges)
- **Enhanced slide context integration:**
  - Includes visual elements (chart count and descriptions)
  - Includes key metrics from slide
  - Enables answering visual questions ("how many charts", "what figures")
  - Agent references slide context for layout questions without querying DynamoDB

### 3.3 Query Functions (novartis_queries_v2_1.py)

**Purpose:** DynamoDB query functions for all 5 tables with filtering logic.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `decimal_to_float()` | Convert Decimal to float for JSON serialization | obj: Any | float/dict/list (converted) |
| `query_sales_finance_table()` | Query SALES_FINANCE_BPC_corrected table | filters: dict (products, forecast_types, year, dates, rel_indexes) | list of records |
| `query_doses_table()` | Query FCT_DOSES_PLU_corrected table | filters: dict (products, metrics, forecast_types, year, dates, rel_indexes) | list of records |
| `query_market_share_table()` | Query FCT_MARKET_PLU_corrected table | filters: dict (brands, year, dates, rel_indexes) | list of records |
| `query_calls_table()` | Query FCT_CALLS table | filters: dict (products, geo_level, geo_name, metric_type, year_quarter, dates) | list of records |
| `query_rome_table()` | Query FCT_ROME_PLU table | filters: dict (products, territories, regions, site_ids, active_dormant, order_status, is_first_dose, dates) | list of records |

**Filter Parameters:**
- **Common:** year, start_date, end_date, year_rel_index, month_rel_index, cycle_rel_index
- **Sales:** products, forecast_types
- **Doses:** products, metrics, forecast_types, quarter_rel_index
- **Market:** brands
- **Calls:** products, geo_level, geo_name, metric_type, year_quarter
- **Rome:** products, territories, regions, site_ids, active_dormant, order_status, is_first_dose

**Key Features:**
- All functions use table.scan() with post-filtering (production should use GSI)
- Decimal-to-float conversion for JSON compatibility
- Comprehensive error handling
- Returns empty list on error (never crashes)

### 3.4 AWS Clients (aws_clients.py)

**Purpose:** Centralized AWS client management to prevent connection leaks.

**Shared Clients:**

| Client | Purpose | Configuration |
|--------|---------|---------------|
| `bedrock_runtime` | Claude Sonnet 4.5 API calls | max_pool_connections=25, retries=5, timeout=60s |
| `polly_client` | Text-to-speech synthesis | max_pool_connections=10 |
| `dynamodb` | DynamoDB resource access | max_pool_connections=50 |

**Key Features:**
- Single instance pattern (prevents "too many connections" errors)
- Optimized connection pooling
- Adaptive retry mode
- Imported by all modules (app.py, agent_handler, queries)
- Uses centralized `aws_utils.get_aws_client()` and `aws_utils.get_aws_resource()` for consistent credential handling

**Credential Handling:**
All clients automatically use the credential resolution from `aws_utils.py`:
1. ECS task role (production)
2. AWS Profile with isengardcli (local dev - recommended)
3. Isenguard CSV file (local dev - fallback)
4. Default AWS credential chain

**Imports:**
```python
from aws_utils import get_aws_client, get_aws_resource
```

### 3.5 AWS Credential Management (aws_utils.py)

**Purpose:** Centralized AWS credential handling for multiple environments.

**Location:** `utils/aws/aws_utils.py`

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `get_aws_session()` | Create AWS session with automatic credential resolution | None (uses environment variables) | boto3.Session object |
| `get_aws_client()` | Get AWS client with proper credentials | service_name: str, **kwargs | boto3 client |
| `get_aws_resource()` | Get AWS resource with proper credentials | service_name: str, **kwargs | boto3 resource |

**Credential Priority Order:**
1. **ECS Task Role** (production) - Automatically detected via ECS metadata endpoint
2. **AWS Profile with isengardcli** (local dev - recommended) - Uses `AWS_PROFILE` environment variable
3. **Isenguard CSV file** (local dev - fallback) - Reads from `isenguard_access/*.csv`
4. **Default AWS credential chain** - Last resort fallback

**get_aws_session() Logic:**
```python
def get_aws_session():
    # 1. Check if running in ECS (production)
    if is_ecs:
        return boto3.Session(region_name=aws_region)
    
    # 2. Try AWS CLI profile (supports isengardcli credential_process)
    if AWS_PROFILE:
        session = boto3.Session(profile_name=aws_profile)
        # Test session with get_caller_identity()
        return session
    
    # 3. Fallback to isenguard CSV credentials
    if csv_file_exists:
        return boto3.Session(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key
        )
    
    # 4. Last resort: default credential chain
    return boto3.Session(region_name=aws_region)
```

**Key Features:**
- Automatic environment detection (ECS vs local)
- Credential validation (tests session before returning)
- Comprehensive error handling with fallbacks
- Clear console output showing which credential method is active
- Supports temporary credentials (isengardcli)
- Backward compatible with CSV files

**Setup Guide:** See `docs/ISENGUARD_SETUP.md` for detailed credential configuration.

### 3.6 Configuration Management (backend_api/config.py)

**Purpose:** Environment-aware configuration for local development and AWS deployment.

**Core Class:**

#### Config

**Purpose:** Configuration class that adapts to different environments.

**Key Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `environment` | str | 'local' or 'aws-deployment' |
| `aws_region` | str | AWS region (default: us-east-1) |
| `aws_profile` | str | AWS profile name (default: default) |
| `bedrock_model_id` | str | Claude model ID |
| `dynamodb_tables` | dict | Novartis table names (5 tables) |
| `polly_voice_id` | str | Voice for TTS (default: Joanna) |
| `enable_voice_controls` | bool | Feature flag for voice input |
| `enable_preprocessing` | bool | Feature flag for slide preprocessing |
| `cors_origins` | list | Allowed CORS origins |
| `port` | int | Flask server port (default: 5000) |
| `debug` | bool | Debug mode flag |

**Key Methods:**

| Method | Purpose | Returns |
|--------|---------|---------|
| `is_local_development` | Check if running in local dev mode | bool |
| `is_aws_deployment` | Detect if running in AWS (ECS/Lambda) | bool |
| `get_aws_config()` | Get AWS configuration for boto3 clients | dict |
| `get_flask_config()` | Get Flask application configuration | dict |
| `print_config_summary()` | Print configuration for debugging | None |

**Environment Detection Logic:**
```python
@property
def is_aws_deployment(self) -> bool:
    return (
        self.environment in ['aws-deployment', 'production', 'staging'] or
        os.path.exists('/app') or  # Docker container
        os.getenv('AWS_EXECUTION_ENV') is not None or  # Lambda
        os.getenv('ECS_CONTAINER_METADATA_URI') is not None  # ECS
    )
```

**Usage Example:**
```python
from backend_api.config import config

# Check environment
if config.is_aws_deployment:
    # Production logic
else:
    # Local dev logic

# Get DynamoDB tables
tables = config.dynamodb_tables
# {'sales_finance': 'Novartis_Sales_Finance', ...}

# Get AWS configuration
aws_config = config.get_aws_config()
# {'region_name': 'us-east-1', ...}
```

**Key Features:**
- Environment variable support via `.env` file
- Automatic environment detection
- Feature flags for easy toggling
- Custom endpoint support (for local testing)
- CORS configuration
- Performance tuning parameters
- Logging configuration
- Development mode settings

### 3.5 Slide Preprocessor (slide_preprocessor.py)

**Purpose:** Extract structured data from slides ONCE using Claude Sonnet vision model.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `preprocess_slide()` | Extract structured data from single slide | slide_path: str, slide_number: int | dict (structured data) |
| `pdf_to_images()` | Convert PDF to PNG images | pdf_path: str, output_dir: str | list of image paths |
| `preprocess_slides()` | Main preprocessing: PDF → Images → Extract Data | pdf_path: str, status_callback: function | dict: {total_slides, data_file, slides_dir, processing_time} |
| `preprocess_all_slides()` | Preprocess all slides in directory | slides_dir: str, output_file: str | list of slide dicts |
| `load_preprocessed_data()` | Load preprocessed slide data from JSON | data_file: str | list or None |
| `get_slide_data()` | Get preprocessed data for specific slide | slide_number: int, preprocessed_data: list | dict or None |

**Extraction Prompt:**
- Title, summary (1-2 sentences)
- Key numbers (top 3-5 metrics)
- Main topics
- Time period
- **Visual elements:** Count and detailed description of each chart/figure
  - Chart type (line, bar, pie, table, etc.)
  - Chart title
  - Chart description

**Extracted Data Structure:**
```json
{
  "title": "Slide Title",
  "summary": "Brief overview",
  "key_numbers": [{"label": "Metric", "value": 123, "unit": "M"}],
  "main_topics": ["topic1", "topic2"],
  "time_period": "Q4 2025",
  "visual_elements": {
    "count": 4,
    "charts": [
      {"type": "line", "title": "Sales Trend", "description": "..."},
      {"type": "bar", "title": "Product Mix", "description": "..."}
    ]
  }
}
```

**Key Features:**
- Runs ONCE during PDF upload
- Eliminates need to send images on every question
- Saves to JSON file (uploads/preprocessed_slides.json)
- 150 DPI image quality
- Comprehensive error handling
- Progress callbacks for UI updates

## 4. Frontend Implementation (TypeScript/React)

### 4.0 Frontend Configuration

**Proxy Configuration (package.json):**

The frontend includes a proxy setting for local development to eliminate CORS issues:

```json
{
  "proxy": "http://localhost:5000"
}
```

**Purpose:** Forwards all `/api/*` requests from the frontend (port 3000) to the backend (port 5000).

**Benefits:**
- Eliminates CORS errors during local development
- Simplifies API calls (no need for full URLs)
- Matches production behavior (same-origin requests)

**Usage in Components:**
```typescript
// Before (with CORS issues):
fetch('http://localhost:5000/api/ask', {...})

// After (with proxy):
fetch('/api/ask', {...})  // Automatically proxied to backend
```

**Production Deployment:**
In production, the frontend is served from the same origin as the backend, so the proxy is not needed.

### 4.1 Main Application (App.tsx)

**Purpose:** Root component managing application state, slide navigation, and AI interactions.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `handleVoiceInput()` | Process voice transcript and call backend API | transcript: string | void (updates messages state) |
| `playAudio()` | Play audio using Amazon Polly with microphone blocking | text: string, messageIndex: number | void (plays audio, blocks mic) |
| `handleSlideChange()` | Navigate between slides | slideNumber: number | void (updates currentSlide) |
| `handleUploadComplete()` | Handle PDF upload completion | slideCount: number, filename: string | void (sets isReady=true) |

**State Management:**
- `isReady`: boolean - Whether preprocessing is complete
- `currentSlide`: number - Current slide number (1-indexed)
- `totalSlides`: number - Total number of slides
- `pdfFileName`: string - Uploaded PDF filename
- `messages`: Message[] - Conversation history
- `isListening`: boolean - Microphone active state
- `isProcessing`: boolean - API call in progress
- `currentAudio`: HTMLAudioElement - Currently playing audio
- `isPlayingAudio`: boolean - Audio playback state (blocks mic)
- `agentMode`: boolean | null - Force agent/rule mode or auto-detect

**Key Features:**
- Realistic progress updates during API calls (6 steps)
- Conversation history (last 6 messages sent to backend)
- Auto-play responses with Polly
- Microphone blocking during audio playback (prevents echo)
- Safety timeout (30s) to re-enable mic if stuck
- Agent mode toggle (auto/agent/rule)
- Upload screen before preprocessing complete

### 4.2 AI Panel (AIPanel.tsx)

**Purpose:** Chat interface displaying conversation with markdown rendering and chart integration.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `MarkdownRenderer` | Render markdown content with tables and formatting | content: string | JSX (rendered HTML) |
| `formatTime()` | Format timestamp for display | date: Date | string (HH:MM AM/PM) |

**Props:**
- `messages`: Message[] - Conversation history
- `isProcessing`: boolean - Show typing indicator
- `onPlayAudio`: function - Callback to play audio

**Message Interface:**
```typescript
interface Message {
  role: 'user' | 'assistant';
  content: string;
  dataSource?: string;
  timestamp: Date;
  chartData?: any;
  isPlaying?: boolean;
  timing?: { data_load, agent_processing, total };
  isProcessing?: boolean;
  progressStatus?: string;
}
```

**Key Features:**
- Markdown rendering with marked.js (tables, bold, lists)
- Auto-scroll to bottom on new messages
- Empty state with example questions
- Chart display integration
- Data source badges (DynamoDB table names)
- Performance timing display
- Play audio button per message
- Processing indicator with progress status

### 4.3 Chart Display (ChartDisplay.tsx)

**Purpose:** Render interactive charts using Recharts library with professional styling.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `SingleChart` | Render single chart (line/bar/pie) | chartData: ChartData | JSX (chart component) |
| `CustomTooltip` | Custom tooltip with formatted values | active, payload, label | JSX or null |
| `renderCustomLabel` | Pie chart percentage labels | entry: any | string (percentage) |
| `onPieEnter/onPieLeave` | Pie chart hover effects | index: number | void (updates activeIndex) |

**ChartData Interface:**
```typescript
interface ChartData {
  type: 'line' | 'bar' | 'pie';
  title: string;
  data: any[];
  xKey: string;
  yKey?: string;  // Single series
  seriesKeys?: string[];  // Multi-series
  yLabel?: string;
  confidenceInterval?: boolean;
}
```

**Chart Types:**
1. **Line Chart** - Trends over time, multi-series support
2. **Bar Chart** - Comparisons, multi-series support
3. **Pie Chart** - Distributions with percentages
4. **Composed Chart** - Line + confidence intervals (for projections)

**Key Features:**
- Professional color palette (QuickSuite purple theme)
- Responsive sizing (100% width, 300px height)
- Custom tooltips with formatted numbers
- Pie chart hover effects (opacity changes)
- Multi-series support (Actual vs Budget)
- Confidence interval visualization
- Data source badges
- Percentage labels on pie charts

### 4.4 Voice Controls (VoiceControls.tsx)

**Purpose:** Voice input using Web Speech API with microphone management.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `toggleListening()` | Start/stop speech recognition | None | void (updates isListening) |
| `handleReset()` | Reset conversation and reinitialize microphone | None | void (clears messages, resets mic) |

**Props:**
- `isListening`: boolean - Current listening state
- `onVoiceInput`: function - Callback with transcript
- `onListeningChange`: function - Update listening state
- `isDisabled`: boolean - Disable during audio playback
- `onReset`: function - Clear conversation callback

**State Management:**
- `transcript`: string - Final transcript
- `interimTranscript`: string - Real-time transcript
- `isInitializing`: boolean - Microphone initialization state
- `recognitionRef`: useRef - Speech recognition instance

**Key Features:**
- Web Speech API (webkitSpeechRecognition)
- Continuous=false for better reliability
- Interim results for real-time feedback
- Auto-stop after final result (prevents API exhaustion)
- Error handling (no-speech, not-allowed, audio-capture)
- Microphone permission prompts
- Reset button to reinitialize
- Visual feedback (pulse ring, transcript display)
- Disabled state during audio playback

### 4.5 PDF Upload (PDFUpload.tsx)

**Purpose:** PDF upload interface with preprocessing progress tracking.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `handleFileSelect()` | Validate and set selected PDF file | selectedFile: File | void (updates file state) |
| `handleDrop()` | Handle drag-and-drop file upload | e: React.DragEvent | void (calls handleFileSelect) |
| `handleDragOver/handleDragLeave()` | Manage drag-and-drop visual feedback | e: React.DragEvent | void (updates isDragging) |
| `handleFileInput()` | Handle file input change | e: React.ChangeEvent | void (calls handleFileSelect) |
| `handleUpload()` | Upload PDF and poll for preprocessing status | None | void (updates status, calls onUploadComplete) |
| `getStageIcon/getStageColor()` | Get icon/color for current stage | None | string (emoji/color) |

**PreprocessingStatus Interface:**
```typescript
interface PreprocessingStatus {
  stage: 'idle' | 'uploading' | 'extracting' | 'processing' | 'complete' | 'error';
  progress: number;  // 0-100
  message: string;
  details?: string;
  totalSlides?: number;
  processedSlides?: number;
}
```

**Processing Stages:**
1. **Uploading** (10%) - Sending PDF to server
2. **Extracting** (30%) - Converting PDF pages to images
3. **Processing** (30-90%) - Vision model analyzing each slide
4. **Complete** (100%) - Ready to use

**Key Features:**
- Drag-and-drop file upload
- File validation (PDF only)
- Progress bar with percentage
- Slide counter (X / Y slides)
- Status polling (1s intervals)
- Visual step indicators
- Error handling and retry
- Info box explaining preprocessing
- Responsive design

### 4.6 Slide Viewer (SlideViewer.tsx)

**Purpose:** Display slides with navigation controls and keyboard shortcuts.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `handlePrevious()` | Navigate to previous slide | None | void (calls onSlideChange) |
| `handleNext()` | Navigate to next slide | None | void (calls onSlideChange) |
| `handleKeyDown()` | Handle keyboard navigation | e: React.KeyboardEvent | void (arrow keys) |

**Props:**
- `currentSlide`: number - Current slide number
- `totalSlides`: number - Total number of slides
- `onSlideChange`: function - Callback with new slide number

**Key Features:**
- Image loading from backend API (/api/slides/{slideNumber})
- Previous/Next buttons with disabled states
- Slide counter (X / Y)
- Keyboard navigation (← → arrow keys)
- Error fallback (SVG placeholder if image fails)
- Keyboard hint display
- Responsive image sizing

### 4.7 Entry Point (index.tsx)

**Purpose:** React application entry point with StrictMode.

**Core Functions:**

| Function | Purpose | Inputs | Outputs |
|----------|---------|--------|---------|
| `root.render()` | Mount React application to DOM | None | void (renders App) |

**Key Features:**
- React 18 createRoot API
- StrictMode for development checks
- Mounts to #root element

## 5. Development Guidelines

### 5.1 Switching LLM Providers

**Current Implementation:** AWS Bedrock with Claude Sonnet 4.5

The system uses a simple direct API integration via `bedrock_runtime.invoke_model()`. This makes it easy to switch to other providers by modifying the centralized client and adding an adapter function.

#### Architecture Overview

```
Frontend → Flask API → LLM Adapter → Provider API
                ↓
            DynamoDB
```

**Current Code Location:** `backend_api/aws_clients.py` and `backend_api/novartis_agent_handler_v2_1.py`

#### Option 1: AWS Bedrock (Current)

**Pros:**
- Integrated with AWS ecosystem
- No API keys needed (uses IAM)
- Multiple models available
- Pay-per-use pricing

**Setup:**
```python
# aws_clients.py
import boto3
from botocore.config import Config

bedrock_runtime = boto3.client(
    'bedrock-runtime',
    region_name='us-east-1',
    config=Config(
        max_pool_connections=25,
        retries={'max_attempts': 5, 'mode': 'adaptive'}
    )
)

# Usage in agent handler
response = bedrock_runtime.invoke_model(
    modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
    body=json.dumps(request_body)
)
```

**Cost:** ~$3 per 1M input tokens, ~$15 per 1M output tokens

#### Option 2: OpenAI (GPT-4)

**Pros:**
- Industry-leading performance
- Extensive documentation
- Function calling support
- Vision capabilities

**Setup:**
```python
# Install: pip install openai

# aws_clients.py (replace bedrock_runtime)
from openai import OpenAI

openai_client = OpenAI(api_key=os.environ['OPENAI_API_KEY'])

# Adapter function in novartis_agent_handler_v2_1.py
def call_llm(messages, tools=None, system_prompt=None):
    """Unified LLM adapter"""
    response = openai_client.chat.completions.create(
        model="gpt-4-turbo-preview",
        messages=[
            {"role": "system", "content": system_prompt}
        ] + messages,
        tools=tools,  # OpenAI format
        temperature=0.7,
        max_tokens=1024
    )
    return response

# Convert tool definitions to OpenAI format
def convert_tools_to_openai(bedrock_tools):
    """Convert Bedrock tool format to OpenAI format"""
    openai_tools = []
    for tool in bedrock_tools:
        openai_tools.append({
            "type": "function",
            "function": {
                "name": tool["name"],
                "description": tool["description"],
                "parameters": tool["input_schema"]
            }
        })
    return openai_tools
```

**Cost:** ~$10 per 1M input tokens, ~$30 per 1M output tokens

#### Option 3: Google Vertex AI (Gemini)

**Pros:**
- Multimodal capabilities
- Long context window (1M tokens)
- Competitive pricing
- Google Cloud integration

**Setup:**
```python
# Install: pip install google-cloud-aiplatform

# aws_clients.py
from google.cloud import aiplatform
from vertexai.preview.generative_models import GenerativeModel

aiplatform.init(project="your-project-id", location="us-central1")

gemini_model = GenerativeModel("gemini-1.5-pro")

# Adapter function
def call_llm(messages, tools=None, system_prompt=None):
    """Unified LLM adapter for Gemini"""
    # Convert messages to Gemini format
    contents = []
    for msg in messages:
        contents.append({
            "role": "user" if msg["role"] == "user" else "model",
            "parts": [{"text": msg["content"]}]
        })
    
    response = gemini_model.generate_content(
        contents,
        generation_config={
            "temperature": 0.7,
            "max_output_tokens": 1024
        },
        tools=tools  # Gemini format
    )
    return response
```

**Cost:** ~$1.25 per 1M input tokens, ~$5 per 1M output tokens

#### Option 4: Azure OpenAI

**Pros:**
- Enterprise-grade security
- Microsoft ecosystem integration
- Same models as OpenAI
- Compliance certifications

**Setup:**
```python
# Install: pip install openai

# aws_clients.py
from openai import AzureOpenAI

azure_client = AzureOpenAI(
    api_key=os.environ['AZURE_OPENAI_KEY'],
    api_version="2024-02-15-preview",
    azure_endpoint=os.environ['AZURE_OPENAI_ENDPOINT']
)

# Adapter function (same as OpenAI)
def call_llm(messages, tools=None, system_prompt=None):
    response = azure_client.chat.completions.create(
        model="gpt-4-deployment-name",  # Your deployment name
        messages=[
            {"role": "system", "content": system_prompt}
        ] + messages,
        tools=tools,
        temperature=0.7,
        max_tokens=1024
    )
    return response
```

**Cost:** Same as OpenAI (varies by region)

#### Option 5: Anthropic Direct API

**Pros:**
- Direct access to Claude models
- No cloud provider dependency
- Latest model versions
- Simple API

**Setup:**
```python
# Install: pip install anthropic

# aws_clients.py
from anthropic import Anthropic

anthropic_client = Anthropic(api_key=os.environ['ANTHROPIC_API_KEY'])

# Adapter function
def call_llm(messages, tools=None, system_prompt=None):
    response = anthropic_client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=1024,
        temperature=0.7,
        system=system_prompt,
        messages=messages,
        tools=tools  # Anthropic format (same as Bedrock)
    )
    return response
```

**Cost:** ~$3 per 1M input tokens, ~$15 per 1M output tokens

#### Unified Adapter Pattern

**Recommended Approach:** Create a unified `call_llm()` function that abstracts provider differences.

```python
# backend_api/llm_adapter.py

import os
from enum import Enum

class LLMProvider(Enum):
    BEDROCK = "bedrock"
    OPENAI = "openai"
    GEMINI = "gemini"
    AZURE = "azure"
    ANTHROPIC = "anthropic"

# Set provider via environment variable
CURRENT_PROVIDER = LLMProvider(os.getenv('LLM_PROVIDER', 'bedrock'))

def call_llm(messages, tools=None, system_prompt=None, model=None):
    """
    Unified LLM adapter supporting multiple providers
    
    Args:
        messages: List of message dicts with role and content
        tools: List of tool definitions (provider-specific format)
        system_prompt: System prompt string
        model: Optional model override
    
    Returns:
        Standardized response dict with:
        - content: List of content blocks
        - stop_reason: Why generation stopped
        - usage: Token usage stats
    """
    if CURRENT_PROVIDER == LLMProvider.BEDROCK:
        return call_bedrock(messages, tools, system_prompt, model)
    elif CURRENT_PROVIDER == LLMProvider.OPENAI:
        return call_openai(messages, tools, system_prompt, model)
    elif CURRENT_PROVIDER == LLMProvider.GEMINI:
        return call_gemini(messages, tools, system_prompt, model)
    elif CURRENT_PROVIDER == LLMProvider.AZURE:
        return call_azure(messages, tools, system_prompt, model)
    elif CURRENT_PROVIDER == LLMProvider.ANTHROPIC:
        return call_anthropic(messages, tools, system_prompt, model)
    else:
        raise ValueError(f"Unsupported provider: {CURRENT_PROVIDER}")

def call_bedrock(messages, tools, system_prompt, model):
    """AWS Bedrock implementation"""
    from aws_clients import bedrock_runtime
    import json
    
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1024,
        "temperature": 0.7,
        "system": system_prompt,
        "messages": messages,
        "tools": tools
    }
    
    response = bedrock_runtime.invoke_model(
        modelId=model or 'us.anthropic.claude-sonnet-4-5-20250929-v1:0',
        body=json.dumps(request_body)
    )
    
    return json.loads(response['body'].read())

def call_openai(messages, tools, system_prompt, model):
    """OpenAI implementation"""
    from openai import OpenAI
    
    client = OpenAI(api_key=os.environ['OPENAI_API_KEY'])
    
    # Convert tools to OpenAI format
    openai_tools = convert_tools_to_openai(tools) if tools else None
    
    # Add system message
    full_messages = [{"role": "system", "content": system_prompt}] + messages
    
    response = client.chat.completions.create(
        model=model or "gpt-4-turbo-preview",
        messages=full_messages,
        tools=openai_tools,
        temperature=0.7,
        max_tokens=1024
    )
    
    # Convert to standard format
    return convert_openai_response(response)

# Similar implementations for other providers...
```

**Usage in Agent Handler:**

```python
# novartis_agent_handler_v2_1.py

from llm_adapter import call_llm

def handle_question_with_agent(question, image_base64=None, ...):
    # Build messages (same as before)
    messages = [...]
    
    # Call LLM (provider-agnostic)
    response = call_llm(
        messages=messages,
        tools=NOVARTIS_TOOLS,
        system_prompt=SYSTEM_PROMPT
    )
    
    # Rest of logic remains the same
    ...
```

#### Cost Comparison

| Provider | Input (per 1M tokens) | Output (per 1M tokens) | Notes |
|----------|----------------------|------------------------|-------|
| AWS Bedrock (Claude) | $3 | $15 | Current implementation |
| OpenAI (GPT-4) | $10 | $30 | Higher cost, good performance |
| Google Gemini | $1.25 | $5 | Most cost-effective |
| Azure OpenAI | $10 | $30 | Same as OpenAI |
| Anthropic Direct | $3 | $15 | Same as Bedrock |

**Recommendation:** 
- **Stay with Bedrock** for AWS integration and reasonable cost
- **Switch to Gemini** for cost savings (60% cheaper)
- **Switch to OpenAI** for maximum performance (if budget allows)

#### Migration Checklist

1. ✅ Install new provider SDK (`pip install openai/google-cloud-aiplatform/anthropic`)
2. ✅ Set API keys in environment variables
3. ✅ Create adapter function in `llm_adapter.py`
4. ✅ Convert tool definitions to provider format
5. ✅ Update `novartis_agent_handler_v2_1.py` to use adapter
6. ✅ Test with sample questions
7. ✅ Update `aws_clients.py` if needed
8. ✅ Deploy and monitor costs

### 5.2 AWS Credentials Setup

**Overview:**
The application supports multiple credential methods with automatic fallback for maximum flexibility across environments.

#### Recommended Method: isengardcli (Local Development)

**Benefits:**
- ✅ Automatic credential refresh (no expiration issues)
- ✅ No static credentials on disk (more secure)
- ✅ Temporary credentials (follows AWS best practices)
- ✅ Works with all AWS CLI and boto3 applications
- ✅ Integrated with Amazon's internal authentication

**Installation Steps:**

1. **Add isengard-cli registry:**
   ```bash
   toolbox registry add s3://buildertoolbox-registry-isengard-cli-us-west-2/tools.json
   ```

2. **Install isengard-cli:**
   ```bash
   toolbox install isengard-cli
   ```
   
   Note: May require system reboot if installing brazilcli for the first time.

3. **Configure AWS profile in `~/.aws/config`:**
   ```ini
   [profile mo-nov]
   output = json
   region = us-east-1
   credential_process = isengardcli credentials --awscli your-email@amazon.com --role Admin
   ```
   
   Replace `your-email@amazon.com` with your Amazon email and `Admin` with your role.

4. **Set environment variable:**
   ```bash
   export AWS_PROFILE=mo-nov
   echo 'export AWS_PROFILE=mo-nov' >> ~/.zshrc  # Make permanent
   ```

5. **Authenticate:**
   ```bash
   mwinit  # Authenticate with Midway
   ```

6. **Verify credentials:**
   ```bash
   aws sts get-caller-identity
   ```
   
   Should return your account ID and role ARN.

**How It Works:**
- `credential_process` tells boto3 to run `isengardcli` to get credentials
- isengardcli fetches temporary credentials from Isengard
- Credentials are automatically refreshed when they expire
- No manual credential management needed

#### Fallback Method: CSV File (Backward Compatibility)

If isengardcli is not available, the application can use static credentials from a CSV file.

**Setup:**
1. Download your Isengard credentials CSV file
2. Place it in the `isenguard_access/` directory
3. Rename to match pattern: `username-cli_accessKeys.csv`

**File Format:**
```csv
Access key ID,Secret access key
```

**Note:** CSV credentials are static and require manual rotation. Use isengardcli for better security.

#### Production Deployment: ECS Task Role

In AWS ECS, the application automatically uses the ECS task role. No configuration needed.

**How It Works:**
- ECS provides credentials via metadata endpoint
- Application detects ECS environment automatically
- Credentials are managed by AWS (no manual setup)

**Detection Logic:**
```python
# Checks for ECS metadata endpoint
is_ecs = os.environ.get('ECS_CONTAINER_METADATA_URI_V4') or \
         os.environ.get('ECS_CONTAINER_METADATA_URI')
```

#### Credential Priority Summary

The application tries credentials in this order:

1. **ECS Task Role** (production)
   - Detected: ECS metadata endpoint present
   - Used: Automatically in AWS ECS
   - Output: "✅ Running in ECS - using task role credentials"

2. **AWS Profile with isengardcli** (local dev - recommended)
   - Detected: `AWS_PROFILE` environment variable set
   - Used: When profile configured with `credential_process`
   - Output: "✅ Using AWS profile: mo-nov"

3. **Isenguard CSV file** (local dev - fallback)
   - Detected: CSV file exists in `isenguard_access/`
   - Used: When profile not available
   - Output: "✅ Using isenguard credentials from CSV file"

4. **Default AWS credential chain** (last resort)
   - Detected: None of the above available
   - Used: Falls back to standard boto3 credential resolution
   - Output: "✅ Using default AWS credential chain"

#### Troubleshooting

**Issue:** "Unable to locate credentials"
- **Solution:** Verify `AWS_PROFILE` is set or CSV file exists
- **Check:** Run `echo $AWS_PROFILE` and verify file path

**Issue:** "No such profile: mo-nov"
- **Solution:** Check `~/.aws/config` has the profile section
- **Verify:** Run `cat ~/.aws/config | grep mo-nov`

**Issue:** "credential_process returned non-zero exit status"
- **Solution:** Run `mwinit` to authenticate with Midway
- **Check:** Run `isengardcli credentials --awscli your-email@amazon.com --role Admin` manually

**Issue:** Backend shows "Using default AWS credential chain"
- **Cause:** Neither profile nor CSV file found
- **Solution:** Set up isengardcli or add CSV file

**Issue:** "Access Denied" errors
- **Cause:** Credentials don't have required permissions
- **Solution:** Verify role has DynamoDB, Bedrock, and Polly permissions
- **Check:** Run `aws sts get-caller-identity` to see current role

#### Security Best Practices

1. **Use isengardcli** instead of CSV files (temporary credentials)
2. **Never commit** CSV files to git (already in `.gitignore`)
3. **Rotate credentials** regularly if using CSV method
4. **Use least privilege** IAM roles (only required permissions)
5. **Monitor usage** via CloudTrail for suspicious activity

#### Detailed Setup Guide

For complete setup instructions, troubleshooting, and advanced configuration, see:
- `docs/ISENGUARD_SETUP.md` - Comprehensive credential setup guide
- `aws_utils.py` - Credential resolution implementation
- `backend_api/config.py` - Environment configuration

## 6. Deployment & Infrastructure

### 6.1 AWS CDK Infrastructure (infrastructure/)

**Purpose:** Infrastructure as Code for deploying MBR Dashboard to AWS ECS Fargate.

**Key Files:**
- `bin/mbr-dashboard.ts` - CDK app entry point
- `lib/mbr-dashboard-simple-stack.ts` - Stack definition (ECS, ALB, DynamoDB, ECR)
- `cdk.json` - CDK configuration
- `package.json` - Node.js dependencies (aws-cdk-lib, constructs)

**Deployment Architecture:**
- **ECS Fargate** - Containerized application (Flask + React)
- **Private ALB** - Internal load balancer (VPC-only access)
- **DynamoDB** - 5 tables for data storage
- **ECR** - Docker image repository
- **CloudWatch** - Logging and monitoring

**Deployment Commands:**
```bash
# Deploy to AWS
export AWS_PROFILE=your-profile-name
./deploy.sh

# Cleanup all resources
./cleanup.sh
```

### 6.2 Deployment Scripts

#### deploy.sh
**Purpose:** Automated deployment to AWS using CDK.

**What it does:**
1. Builds Docker image for backend + frontend
2. Pushes image to ECR
3. Deploys CDK stack (ECS, ALB, DynamoDB)
4. Outputs ALB URL for access

**Requirements:**
- AWS CLI configured with profile
- Docker installed and running
- Node.js and CDK CLI installed
- VPC with private subnets

#### cleanup.sh
**Purpose:** Complete teardown of all AWS resources.

**What it deletes:**
- DynamoDB tables (all 5 tables)
- ECS cluster and service
- Application Load Balancer
- ECR repository and images
- IAM roles and policies
- Security groups
- CloudWatch log groups

**Safety Features:**
- Requires typing "yes" to confirm
- Shows warnings before deletion
- Cannot be accidentally triggered

#### scripts/setup-vpc-testing.sh
**Purpose:** Automated testing of deployed application.

**What it does:**
1. Auto-detects ALB URL from CloudFormation stack
2. Creates temporary EC2 instance in private subnet
3. Tests health endpoint, frontend, and API
4. Automatically cleans up test instance

**Usage:**
```bash
AWS_PROFILE=your-profile-name ./scripts/setup-vpc-testing.sh
```

### 6.3 Environment Configuration

**.env.example.aws**
Template for AWS deployment configuration:
```bash
AWS_DEFAULT_REGION=us-east-1
VPC_ID=vpc-xxxxxxxxx  # Optional
PRIVATE_SUBNET_IDS=subnet-xxx,subnet-yyy  # Optional
```

**When to use:**
- Custom VPC deployment
- Specific subnet selection
- Different AWS region

### 6.4 Local Development

**dev.sh**
Helper script for local development with two modes:

```bash
# Development Mode (RECOMMENDED - separate ports)
./dev.sh dev
# - Frontend: http://localhost:3000 (with hot reload)
# - Backend: http://localhost:5000 (API only)
# - Best for development, microphone works perfectly

# Production Mode (single port)
./dev.sh start
# - Single port: http://localhost:5000
# - Frontend served from Flask
# - Best for production-like testing

# Other commands
./dev.sh setup    # Install dependencies
./dev.sh build    # Build frontend
./dev.sh data     # Load DynamoDB data
./dev.sh deploy   # Deploy to AWS
./dev.sh clean    # Clean build artifacts
```

**Key Features:**
- Automatic prerequisite checking (Python, Node.js, AWS CLI)
- Environment setup and configuration
- Frontend build and deployment
- DynamoDB data loading
- AWS deployment integration

---

## 7. Troubleshooting Guide

### Common Issues and Solutions

#### Backend Issues

**Issue:** "Too many connections" error from Bedrock
- **Cause:** Multiple client instances created
- **Solution:** Use shared clients from `aws_clients.py`
- **Prevention:** Always import clients, never create new ones

**Issue:** DynamoDB query returns empty results
- **Cause:** Incorrect filter parameters or missing data
- **Solution:** Check filter values, verify data exists with scan()
- **Debug:** Add print statements in query functions

**Issue:** Agent doesn't call tools
- **Cause:** Tool descriptions unclear or question doesn't match
- **Solution:** Improve tool descriptions, check SYSTEM_PROMPT
- **Debug:** Print request_body before calling Bedrock

**Issue:** Preprocessing fails on PDF upload
- **Cause:** pdf2image not installed or poppler missing
- **Solution:** `pip install pdf2image` and install poppler
- **Mac:** `brew install poppler`
- **Linux:** `apt-get install poppler-utils`

#### Frontend Issues

**Issue:** Microphone stuck in disabled state
- **Cause:** Audio playback didn't complete properly
- **Solution:** Click "Unlock Microphone" button
- **Prevention:** Ensure audio.onended callback fires

**Issue:** Charts not displaying
- **Cause:** Chart data format mismatch
- **Solution:** Check chartData structure matches ChartDisplay interface
- **Debug:** Console.log chartData in ChartDisplay component

**Issue:** Voice recognition not working
- **Cause:** Browser doesn't support Web Speech API or permissions denied
- **Solution:** Use Chrome/Edge, grant microphone permissions
- **Check:** Look for permission prompt in address bar

**Issue:** Slides not loading
- **Cause:** Backend API not running or slides not preprocessed
- **Solution:** Start backend with `python backend_api/app.py`
- **Check:** Visit http://localhost:5000/api/health

### Performance Optimization Tips

1. **Reduce Response Time:**
   - Use preprocessed slides (eliminates vision model call)
   - Optimize DynamoDB queries with GSI
   - Cache frequently accessed data
   - Use connection pooling (already implemented)

2. **Reduce Costs:**
   - Switch to Gemini (60% cheaper than Claude)
   - Reduce max_tokens in agent handler
   - Cache LLM responses for identical questions
   - Use smaller models for simple queries

3. **Improve Accuracy:**
   - Enhance tool descriptions with examples
   - Add more context to SYSTEM_PROMPT
   - Use conversation history effectively
   - Validate data before sending to LLM

### Debugging Checklist

**Backend:**
- [ ] Check backend logs for errors
- [ ] Verify AWS credentials are set
- [ ] Test DynamoDB connection
- [ ] Verify Bedrock model ID is correct
- [ ] Check tool execution results
- [ ] Validate chart data generation

**Frontend:**
- [ ] Check browser console for errors
- [ ] Verify API endpoint URLs
- [ ] Test microphone permissions
- [ ] Check network tab for failed requests
- [ ] Validate message state updates
- [ ] Test chart rendering with sample data

**Data:**
- [ ] Verify CSV files exist
- [ ] Check DynamoDB tables created
- [ ] Validate data format (dates, numbers)
- [ ] Test query functions independently
- [ ] Check relative indexes calculated correctly

---

## Appendix A: File Reference Quick Index

### Backend Python Files
- `app.py` - Main Flask API server (11 functions)
- `novartis_agent_handler_v2_1.py` - Agent with 5 tools (3 functions, enhanced visual context)
- `novartis_queries_v2_1.py` - DynamoDB queries (6 functions)
- `aws_clients.py` - Shared AWS clients (3 clients)
- `config.py` - Configuration management (5 methods)
- `slide_preprocessor.py` - Slide preprocessing (6 functions, visual elements extraction)
- `utils/aws/aws_utils.py` - AWS credential management (3 functions)

### Frontend TypeScript Files
- `App.tsx` - Main application (4 functions)
- `AIPanel.tsx` - Chat interface (2 functions)
- `ChartDisplay.tsx` - Chart rendering (4 functions)
- `VoiceControls.tsx` - Voice input (2 functions)
- `PDFUpload.tsx` - PDF upload (6 functions)
- `SlideViewer.tsx` - Slide display (3 functions)

### Infrastructure & Deployment
- `infrastructure/bin/mbr-dashboard.ts` - CDK app entry point
- `infrastructure/lib/mbr-dashboard-simple-stack.ts` - Stack definition
- `deploy.sh` - AWS deployment script (CDK-based)
- `cleanup.sh` - AWS resource cleanup script
- `dev.sh` - Local development helper
- `scripts/setup-vpc-testing.sh` - Automated deployment testing (472 lines)
- `index.tsx` - Entry point (1 function)

### Utility Scripts

**Test Scripts (in scripts/):**
- `test_v2.py` - Agent testing (V2.0)
- `test_v2_1.py` - Agent testing (V2.1)
- `test_audio_summary.py` - Audio generation testing
- `test_chart_generation.py` - Chart generation testing
- `test_preprocessing_performance.py` - Preprocessing benchmarks
- `test_slide_summarization.py` - Slide processing testing

**Data Generation Scripts (in utils/data_generation/):**
- `generate_calls_expanded.py` - Generate calls data (4 functions)
- `generate_rome_expanded.py` - Generate Rome data (4 functions)
- `generate_corrected_tables.py` - Correct table data
- `generate_rome_corrected.py` - Correct Rome data
- `generate_mbr_slides.py` - Generate MBR slides
- `generate_expected_charts.py` - Generate test charts

**Data Management Scripts (in utils/data_management/):**
- `load_all_tables.py` - Load all tables to DynamoDB (main loader)
- `load_dynamodb_data.py` - Load data for CDK deployment

**Legacy Scripts (in scripts/):**
- `upload_to_dynamodb.py` - CSV to DynamoDB (3 functions)
- `create_dynamodb_tables.py` - Table creation (6 functions)

### Total Function Count
- **Backend:** 37 functions (includes aws_utils.py and config.py)
- **Frontend:** 22 functions
- **Scripts:** 17 functions
- **Grand Total:** 76 documented functions

---

## Appendix B: Technology Stack Summary

### Backend
- **Language:** Python 3.9+
- **Framework:** Flask 2.3+
- **AI/ML:** AWS Bedrock (Claude Sonnet 4.5)
- **Database:** DynamoDB
- **TTS:** Amazon Polly Neural
- **Vision:** Claude Sonnet vision model
- **PDF Processing:** pdf2image, poppler

### Frontend
- **Language:** TypeScript 4.9+
- **Framework:** React 18
- **Build Tool:** Vite 4.3+
- **Charts:** Recharts 2.5+
- **Markdown:** marked 5.0+
- **Voice:** Web Speech API (browser-native)
- **Styling:** CSS3

### AWS Services
- **Bedrock Runtime:** Claude Sonnet 4.5 (us-east-1)
- **DynamoDB:** 5 tables with GSI
- **Polly:** Neural TTS (Joanna voice)
- **IAM:** Credentials via CSV file

### Development Tools
- **Package Manager:** pip (Python), npm (Node.js)
- **Version Control:** Git
- **IDE:** VS Code (recommended)
- **Testing:** Manual testing (no automated tests)

---

## Document Revision History

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0 | December 12, 2025 | Initial comprehensive code reference | AI Development Team |
| 1.1 | December 16, 2025 | Added aws_utils.py, config.py, isengardcli setup, proxy config, reorganized folder structure | AI Development Team |
| 1.2 | December 16, 2025 | Major reorganization: Created utils/ directory, reorganized data/ directory, removed Healthcare KPI code, updated all import paths | AI Development Team |
| 1.3 | December 16, 2025 | Added CDK infrastructure, deployment scripts (deploy.sh, cleanup.sh), enhanced visual elements in agent handler, automated testing script | AI Development Team |
| 1.4 | December 16, 2025 | Enhanced dev.sh with development mode (separate ports 3000/5000) and production mode (single port 5000), fixed microphone issues, added AWS copyright headers | AI Development Team |

---

**End of Document**

For questions or clarifications, refer to:
- DOC1_SOLUTION_ARCHITECTURE.md - Architecture and design decisions
- README.md - Quick start guide
- QUICK_REFERENCE.md - Common commands and workflows
