# MBR Dashboard Frontend

Voice-enabled AI assistant for Monthly Business Review presentations.

## Features

- **PowerPoint Viewer** (2/3 width)
  - Display slides from S3
  - Keyboard navigation (← →)
  - Slide counter

- **AI Assistant Panel** (1/3 width)
  - Conversation history
  - Real-time responses
  - Typing indicators

- **Voice Controls**
  - Web Speech API integration
  - Continuous voice recognition
  - Visual feedback

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    MBR Dashboard                         │
├──────────────────────────┬──────────────────────────────┤
│   Slide Viewer (2/3)     │   AI Panel (1/3)            │
│                          │                              │
│   ┌──────────────────┐   │   ┌──────────────────────┐  │
│   │                  │   │   │  Conversation        │  │
│   │   Slide Image    │   │   │  History             │  │
│   │                  │   │   │                      │  │
│   └──────────────────┘   │   └──────────────────────┘  │
│                          │                              │
│   [← Prev] 1/36 [Next →] │   [Voice Controls 🎤]       │
└──────────────────────────┴──────────────────────────────┘
```

## Setup

### Prerequisites
- Node.js 16+ and npm
- AWS account with S3 bucket containing slides

### Installation

```bash
cd frontend
npm install
```

### Configuration

Update S3 bucket name in `src/components/SlideViewer.tsx`:
```typescript
const S3_BUCKET = 'your-bucket-name-here';
```

### Development

```bash
npm start
```

Opens at http://localhost:3000

### Build for Production

```bash
npm run build
```

Creates optimized build in `build/` directory.

## Components

### SlideViewer
- Displays PowerPoint slides from S3
- Navigation controls
- Keyboard shortcuts

### AIPanel
- Message display
- Conversation history
- Status indicators

### VoiceControls
- Microphone button
- Speech recognition
- Transcript display

## Browser Support

- Chrome/Edge: Full support (Web Speech API)
- Firefox: Limited support
- Safari: Partial support

## Integration

### Backend API

The frontend expects a backend API at `/api/ask`:

```typescript
POST /api/ask
{
  "question": "What's the current enrollment?",
  "slideNumber": 1
}

Response:
{
  "answer": "Total enrollment is 105,645 members...",
  "audioUrl": "https://s3.../response.mp3" // Optional
}
```

### AWS Services

- **S3**: Slide images storage
- **API Gateway**: Backend API
- **Lambda**: Query processing
- **Bedrock**: AI responses
- **Polly**: Text-to-speech (optional)

## Deployment

### Option 1: S3 + CloudFront

```bash
npm run build
aws s3 sync build/ s3://your-bucket-name
aws cloudfront create-invalidation --distribution-id YOUR_ID --paths "/*"
```

### Option 2: Amplify

```bash
amplify init
amplify add hosting
amplify publish
```

## Environment Variables

Create `.env` file:

```
REACT_APP_API_URL=https://your-api-gateway-url
REACT_APP_S3_BUCKET=your-bucket-name
REACT_APP_AWS_REGION=us-east-1
```

## Troubleshooting

### Slides not loading
- Check S3 bucket permissions
- Verify CORS configuration
- Check bucket name in SlideViewer.tsx

### Voice not working
- Use Chrome/Edge browser
- Allow microphone permissions
- Check HTTPS (required for Web Speech API)

### API errors
- Verify API Gateway URL
- Check CORS headers
- Review Lambda logs

## Performance

- Slide images: ~300KB each
- Initial load: <2s
- Voice recognition: Real-time
- AI response: 3-5s

## Security

- S3 bucket: Public read for slides only
- API: Authenticated requests
- CORS: Configured for frontend domain
- No sensitive data in frontend

## Future Enhancements

- [ ] Chart visualization generation
- [ ] Multi-language support
- [ ] Offline mode
- [ ] Mobile app version
- [ ] Screen sharing for presentations
