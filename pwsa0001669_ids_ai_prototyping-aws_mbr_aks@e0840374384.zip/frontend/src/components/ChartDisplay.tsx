/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import React from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  ComposedChart
} from 'recharts';
import './ChartDisplay.css';

interface ChartData {
  type: 'line' | 'bar' | 'pie';
  title: string;
  data: any[];
  xKey: string;
  yKey?: string;  // Single series
  seriesKeys?: string[];  // Multi-series (for actual vs budget, etc.)
  yLabel?: string;
  confidenceInterval?: boolean;
}

// Professional color palette matching QuickSuite
const COLORS = [
  '#5e35b1', // Purple (Marketing)
  '#4db6ac', // Teal (Sales)
  '#1e3a5f', // Dark Blue (Development)
  '#ff8a00', // Orange (Support)
  '#2e7d32', // Green (Operations)
  '#7b1fa2', // Deep Purple
  '#0288d1', // Light Blue
  '#f57c00', // Deep Orange
  '#00897b', // Teal Green
  '#5d4037'  // Brown
];

interface ChartDisplayProps {
  chartData: ChartData | ChartData[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="tooltip-label">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="tooltip-value" style={{ color: entry.color }}>
            {entry.name}: {typeof entry.value === 'number' ? entry.value.toLocaleString() : entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

const SingleChart: React.FC<{ chartData: ChartData }> = ({ chartData }) => {
  const { type, title, data, xKey, yKey, seriesKeys, yLabel, confidenceInterval } = chartData;
  const [activeIndex, setActiveIndex] = React.useState<number | null>(null);

  // Determine if multi-series
  const isMultiSeries = seriesKeys && seriesKeys.length > 0;
  const effectiveYKey = yKey || (seriesKeys && seriesKeys[0]) || 'value';

  // Calculate total for percentages (pie charts only use single yKey)
  const total = data.reduce((sum, entry) => sum + entry[effectiveYKey], 0);

  // Custom label for pie chart showing percentage
  const renderCustomLabel = (entry: any) => {
    const percent = ((entry[effectiveYKey] / total) * 100).toFixed(1);
    return `${percent}%`;
  };

  // Handle pie chart hover
  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(null);
  };

  // Get source from chartData or use default
  const source = (chartData as any).source || 'SALES_FINANCE_BPC_corrected';
  
  return (
    <div className="chart-display">
      <div className="chart-header">
        <h3 className="chart-title">{title}</h3>
        <button className="source-button" title="Data Source">
          <span className="source-icon">📊</span>
          <span className="source-text">DynamoDB: {source}</span>
        </button>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        {type === 'line' && confidenceInterval ? (
          <ComposedChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey={xKey} 
              angle={-45}
              textAnchor="end"
              height={80}
              tick={{ fontSize: 10, fill: '#64748b' }}
              stroke="#cbd5e1"
            />
            <YAxis 
              label={{ value: yLabel || '', angle: -90, position: 'insideLeft', style: { fill: '#64748b' } }}
              tick={{ fill: '#64748b' }}
              stroke="#cbd5e1"
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ paddingTop: '10px' }} />
            <Area 
              type="monotone" 
              dataKey="upper" 
              stroke="#c084fc" 
              strokeWidth={1}
              strokeDasharray="5 5"
              fill="#f3e8ff" 
              fillOpacity={0.3}
              name="Upper CI"
            />
            <Area 
              type="monotone" 
              dataKey="lower" 
              stroke="#f97316" 
              strokeWidth={1}
              strokeDasharray="5 5"
              fill="#ffffff" 
              fillOpacity={1}
              name="Lower CI"
            />
            <Line 
              type="monotone" 
              dataKey={yKey} 
              stroke="#8b5cf6" 
              strokeWidth={3}
              dot={{ fill: '#8b5cf6', r: 4 }}
              activeDot={{ r: 6 }}
              name="Projected Enrollment"
            />
          </ComposedChart>
        ) : type === 'line' ? (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey={xKey} tick={{ fill: '#64748b' }} stroke="#cbd5e1" />
            <YAxis 
              label={{ value: yLabel || '', angle: -90, position: 'insideLeft', style: { fill: '#64748b' } }}
              tick={{ fill: '#64748b' }}
              stroke="#cbd5e1"
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            {isMultiSeries ? (
              // Multi-series: render multiple lines
              seriesKeys!.map((key, index) => (
                <Line 
                  key={key}
                  type="monotone" 
                  dataKey={key} 
                  stroke={COLORS[index % COLORS.length]} 
                  strokeWidth={3} 
                  dot={{ fill: COLORS[index % COLORS.length], r: 4 }}
                  name={key.charAt(0).toUpperCase() + key.slice(1)}
                />
              ))
            ) : (
              // Single series
              <Line type="monotone" dataKey={effectiveYKey} stroke="#5e35b1" strokeWidth={3} dot={{ fill: '#5e35b1', r: 4 }} />
            )}
          </LineChart>
        ) : type === 'pie' ? (
          <PieChart onMouseLeave={onPieLeave}>
            <Pie
              data={data}
              dataKey={effectiveYKey}
              nameKey={xKey}
              cx="50%"
              cy="50%"
              outerRadius={110}
              innerRadius={0}
              label={renderCustomLabel}
              labelLine={{
                stroke: '#64748b',
                strokeWidth: 1
              }}
              onMouseEnter={onPieEnter}
              onMouseLeave={onPieLeave}
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[index % COLORS.length]}
                  opacity={activeIndex === null || activeIndex === index ? 1 : 0.3}
                  style={{ 
                    transition: 'opacity 0.3s ease',
                    cursor: 'pointer'
                  }}
                />
              ))}
            </Pie>
            <Tooltip 
              content={({ active, payload }) => {
                if (active && payload && payload.length && payload[0].value !== undefined) {
                  const data = payload[0];
                  const value = data.value as number;
                  const percent = ((value / total) * 100).toFixed(1);
                  return (
                    <div className="custom-tooltip">
                      <p className="tooltip-label">{data.name}</p>
                      <p className="tooltip-value" style={{ color: data.payload.fill }}>
                        Count: {value.toLocaleString()}
                      </p>
                      <p className="tooltip-value" style={{ color: data.payload.fill }}>
                        Percentage: {percent}%
                      </p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              formatter={(value, entry: any) => {
                const percent = ((entry.payload[effectiveYKey] / total) * 100).toFixed(1);
                return `${value} (${percent}%)`;
              }}
            />
          </PieChart>
        ) : (
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey={xKey} tick={{ fill: '#64748b' }} stroke="#cbd5e1" />
            <YAxis 
              label={{ value: yLabel || '', angle: -90, position: 'insideLeft', style: { fill: '#64748b' } }}
              tick={{ fill: '#64748b' }}
              stroke="#cbd5e1"
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            {isMultiSeries ? (
              // Multi-series: render multiple bars
              seriesKeys!.map((key, index) => (
                <Bar 
                  key={key}
                  dataKey={key} 
                  fill={COLORS[index % COLORS.length]} 
                  radius={[8, 8, 0, 0]}
                  name={key.charAt(0).toUpperCase() + key.slice(1)}
                />
              ))
            ) : (
              // Single series
              <Bar dataKey={effectiveYKey} fill="#5e35b1" radius={[8, 8, 0, 0]} />
            )}
          </BarChart>
        )}
      </ResponsiveContainer>
    </div>
  );
};

const ChartDisplay: React.FC<ChartDisplayProps> = ({ chartData }) => {
  // Support both single chart and multiple charts
  const charts = Array.isArray(chartData) ? chartData : [chartData];

  return (
    <div className="charts-container">
      {charts.map((chart, index) => (
        <SingleChart key={index} chartData={chart} />
      ))}
    </div>
  );
};

export default ChartDisplay;
