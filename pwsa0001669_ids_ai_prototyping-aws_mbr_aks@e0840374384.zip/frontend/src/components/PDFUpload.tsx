/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import React, { useState } from 'react';
import './PDFUpload.css';
import { apiRequest } from '../utils/apiUtils';

interface PDFUploadProps {
  onUploadComplete: (totalSlides: number, filename?: string) => void;
}

interface PreprocessingStatus {
  stage: 'idle' | 'uploading' | 'extracting' | 'processing' | 'complete' | 'error';
  progress: number;
  message: string;
  details?: string;
  totalSlides?: number;
  processedSlides?: number;
}

const PDFUpload: React.FC<PDFUploadProps> = ({ onUploadComplete }) => {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<PreprocessingStatus>({
    stage: 'idle',
    progress: 0,
    message: 'Upload a PDF to get started'
  });
  const [isDragging, setIsDragging] = useState(false);

  const handleFileSelect = (selectedFile: File) => {
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setStatus({
        stage: 'idle',
        progress: 0,
        message: `Ready to process: ${selectedFile.name}`
      });
    } else {
      setStatus({
        stage: 'error',
        progress: 0,
        message: 'Please select a valid PDF file'
      });
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileSelect(droppedFile);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      handleFileSelect(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    const formData = new FormData();
    formData.append('pdf', file);

    try {
      // Stage 1: Uploading
      setStatus({
        stage: 'uploading',
        progress: 10,
        message: 'Uploading PDF...',
        details: 'Sending file to server'
      });

      const response = await apiRequest('/api/preprocess', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      // Stage 2: Extracting
      setStatus({
        stage: 'extracting',
        progress: 30,
        message: 'Extracting slides...',
        details: 'Converting PDF pages to images'
      });

      // Poll for status updates
      const pollStatus = async () => {
        try {
          const statusResponse = await apiRequest('/api/preprocess/status');
          const statusData = await statusResponse.json();

          if (statusData.stage === 'processing') {
            setStatus({
              stage: 'processing',
              progress: 30 + (statusData.progress || 0) * 0.6, // 30% to 90%
              message: 'Processing slides with Vision Model...',
              details: `Analyzing slide ${statusData.currentSlide || 0} of ${statusData.totalSlides || 0}`,
              totalSlides: statusData.totalSlides,
              processedSlides: statusData.currentSlide
            });

            // Continue polling
            setTimeout(pollStatus, 1000);
          } else if (statusData.stage === 'complete') {
            setStatus({
              stage: 'complete',
              progress: 100,
              message: 'Preprocessing complete!',
              details: `Successfully processed ${statusData.totalSlides} slides`,
              totalSlides: statusData.totalSlides
            });

            // Notify parent component with slide count and filename
            setTimeout(() => {
              onUploadComplete(statusData.totalSlides || 1, file?.name);
            }, 2000);
          } else if (statusData.stage === 'error') {
            throw new Error(statusData.message || 'Processing failed');
          }
        } catch (error) {
          console.error('Status polling error:', error);
          // Continue polling on error
          setTimeout(pollStatus, 2000);
        }
      };

      // Start polling
      setTimeout(pollStatus, 1000);

    } catch (error) {
      console.error('Upload error:', error);
      setStatus({
        stage: 'error',
        progress: 0,
        message: 'Upload failed',
        details: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    }
  };

  const getStageIcon = () => {
    switch (status.stage) {
      case 'idle': return '📄';
      case 'uploading': return '⬆️';
      case 'extracting': return '🔍';
      case 'processing': return '🤖';
      case 'complete': return '✅';
      case 'error': return '❌';
      default: return '📄';
    }
  };

  const getStageColor = () => {
    switch (status.stage) {
      case 'uploading': return '#3b82f6';
      case 'extracting': return '#8b5cf6';
      case 'processing': return '#f59e0b';
      case 'complete': return '#10b981';
      case 'error': return '#ef4444';
      default: return '#6b7280';
    }
  };

  return (
      <div className="upload-card">

        {/* Upload Area */}
        {status.stage === 'idle' || status.stage === 'error' ? (
          <div
            className={`upload-dropzone ${isDragging ? 'dragging' : ''}`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
          >
            <div className="dropzone-content">
              <div className="dropzone-icon">📁</div>
              <h3>Drag & Drop your PDF here</h3>
              <p>or</p>
              <label className="file-input-label">
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileInput}
                  style={{ display: 'none' }}
                />
                <span className="browse-button">Browse Files</span>
              </label>
              {file && (
                <div className="selected-file">
                  <span className="file-icon">📄</span>
                  <span className="file-name">{file.name}</span>
                  <span className="file-size">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </span>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Processing Status */
          <div className="processing-status">
            <div className="status-icon" style={{ color: getStageColor() }}>
              {getStageIcon()}
            </div>
            <h2>{status.message}</h2>
            {status.details && <p className="status-details">{status.details}</p>}
            
            {/* Progress Bar */}
            <div className="progress-container">
              <div 
                className="progress-bar" 
                style={{ 
                  width: `${status.progress}%`,
                  backgroundColor: getStageColor()
                }}
              />
            </div>
            <div className="progress-text">{Math.round(status.progress)}%</div>

            {/* Slide Counter */}
            {status.totalSlides && status.processedSlides !== undefined && (
              <div className="slide-counter">
                <span className="counter-label">Progress:</span>
                <span className="counter-value">
                  {status.processedSlides} / {status.totalSlides} slides
                </span>
              </div>
            )}

            {/* Processing Steps */}
            <div className="processing-steps">
              <div className={`step ${status.stage === 'uploading' || status.progress > 10 ? 'active' : ''} ${status.progress > 30 ? 'complete' : ''}`}>
                <div className="step-icon">⬆️</div>
                <div className="step-label">Upload</div>
              </div>
              <div className={`step ${status.stage === 'extracting' || status.progress > 30 ? 'active' : ''} ${status.progress > 50 ? 'complete' : ''}`}>
                <div className="step-icon">🔍</div>
                <div className="step-label">Extract</div>
              </div>
              <div className={`step ${status.stage === 'processing' || status.progress > 50 ? 'active' : ''} ${status.progress === 100 ? 'complete' : ''}`}>
                <div className="step-icon">🤖</div>
                <div className="step-label">Process</div>
              </div>
              <div className={`step ${status.stage === 'complete' ? 'active complete' : ''}`}>
                <div className="step-icon">✅</div>
                <div className="step-label">Ready</div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="upload-actions">
          {file && status.stage === 'idle' && (
            <button className="upload-button" onClick={handleUpload}>
              Start Processing
            </button>
          )}
          {status.stage === 'error' && (
            <button className="retry-button" onClick={() => {
              setFile(null);
              setStatus({
                stage: 'idle',
                progress: 0,
                message: 'Upload a PDF to get started'
              });
            }}>
              Try Again
            </button>
          )} 
        </div>

        {/* Info Box */}
        <div className="info-box">
          <h4>What happens during preprocessing?</h4>
          <ul>
            <li><strong>Upload:</strong> Your PDF is securely uploaded to the server</li>
            <li><strong>Extract:</strong> Each slide is converted to a high-quality image</li>
            <li><strong>Process:</strong> Vision AI analyzes each slide to extract data and context</li>
            <li><strong>Ready:</strong> AI assistant is ready to answer questions about your presentation</li>
          </ul>
        </div>
          
        {/* Info Box */}
        <div className="info-box">
          <h4>If you don’t upload a PDF, the assistant will respond using only your question and existing data.</h4>
        </div>
      </div>
  );
};

export default PDFUpload;
