/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import React, { useState, useEffect, useRef } from 'react';
import './VoiceControls.css';

interface VoiceControlsProps {
  isListening: boolean;
  onVoiceInput: (transcript: string) => void;
  onListeningChange: (isListening: boolean) => void;
  isDisabled?: boolean;
  onReset?: () => void;
}

const VoiceControls: React.FC<VoiceControlsProps> = ({
  isListening,
  onVoiceInput,
  onListeningChange,
  isDisabled = false,
  onReset
}) => {
  const [transcript, setTranscript] = useState<string>('');
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [isInitializing, setIsInitializing] = useState<boolean>(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check if browser supports Web Speech API
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      console.warn('Speech recognition not supported in this browser');
      return;
    }

    // Initialize speech recognition
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false; // Changed to false for better reliability
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      console.log('✅ Speech recognition started successfully');
      console.log('🎤 Microphone is active and listening...');
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += transcript;
        } else {
          interim += transcript;
        }
      }

      if (final) {
        console.log('✅ Final transcript:', final);
        setTranscript(final);
        setInterimTranscript('');
        onVoiceInput(final);
        
        // Immediately stop recognition after getting final result
        // This prevents API exhaustion
        try {
          recognition.stop();
        } catch (e) {
          console.log('Recognition already stopping');
        }
      } else {
        setInterimTranscript(interim);
      }
    };

    recognition.onerror = (event: any) => {
      console.error('❌ Speech recognition error:', event.error);
      console.error('Error details:', event);
      
      // Don't treat 'no-speech' as a critical error
      if (event.error === 'no-speech') {
        console.log('⚠️ No speech detected - microphone is working but heard nothing');
        console.log('💡 Try speaking louder or check microphone settings');
      } else if (event.error === 'aborted') {
        console.log('⚠️ Recognition aborted');
      } else if (event.error === 'not-allowed') {
        console.error('🚫 Microphone permission DENIED');
        alert('❌ Microphone access denied!\n\nPlease:\n1. Click the lock icon in the address bar\n2. Set Microphone to "Allow"\n3. Refresh the page');
      } else if (event.error === 'audio-capture') {
        console.error('🚫 No microphone found or microphone in use');
        alert('❌ Microphone not available!\n\nPlease check:\n1. Microphone is connected\n2. Not being used by another app\n3. Browser has permission');
      } else {
        console.error('❌ Critical error:', event.error);
        alert(`Microphone error: ${event.error}\n\nTry:\n1. Refresh the page\n2. Check browser permissions\n3. Try a different browser`);
      }
      
      // Always reset state on error
      onListeningChange(false);
      setInterimTranscript('');
      setIsInitializing(false);
    };

    recognition.onend = () => {
      console.log('🛑 Speech recognition ended');
      console.log('Reason: Normal completion or error');
      
      // Small delay before allowing restart to prevent race conditions
      setTimeout(() => {
        onListeningChange(false);
        setInterimTranscript('');
        setIsInitializing(false);
      }, 50);
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // Already stopped
        }
      }
    };
  }, [onVoiceInput, onListeningChange]);

  // Stop recognition when disabled
  useEffect(() => {
    if (isDisabled && recognitionRef.current && isListening) {
      console.log('Stopping recognition due to disabled state');
      try {
        recognitionRef.current.stop();
        onListeningChange(false);
        setIsInitializing(false);
      } catch (e) {
        console.error('Error stopping recognition:', e);
        // Force reset state even if stop fails
        onListeningChange(false);
        setIsInitializing(false);
      }
    }
  }, [isDisabled, isListening, onListeningChange]);

  const toggleListening = () => {
    console.log('Toggle listening clicked, current state:', isListening, 'disabled:', isDisabled, 'initializing:', isInitializing);
    
    if (isDisabled) {
      console.log('Microphone disabled during audio playback');
      return;
    }
    
    if (isInitializing) {
      console.log('Microphone is initializing, please wait');
      return;
    }
    
    if (!recognitionRef.current) {
      console.error('Recognition not initialized');
      return;
    }
    
    if (isListening) {
      console.log('Stopping recognition...');
      try {
        recognitionRef.current.stop();
        onListeningChange(false);
        setIsInitializing(false);
      } catch (e) {
        console.error('Error stopping:', e);
        onListeningChange(false);
        setIsInitializing(false);
      }
    } else {
      console.log('Starting recognition...');
      setTranscript('');
      setInterimTranscript('');
      setIsInitializing(true);
      
      // Force stop any existing recognition first
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // Ignore - might not be running
      }
      
      // Wait a bit then start fresh
      setIsInitializing(true);
      setTimeout(() => {
        try {
          recognitionRef.current.start();
          onListeningChange(true);
          setIsInitializing(false);
          console.log('Recognition started successfully');
        } catch (e: any) {
          console.error('Error starting recognition:', e);
          
          // If it says already started, force stop and try again
          if (e.message && e.message.includes('already started')) {
            console.log('Recognition already started, forcing restart...');
            try {
              recognitionRef.current.stop();
            } catch (stopError) {
              // Ignore
            }
            
            setTimeout(() => {
              try {
                recognitionRef.current.start();
                onListeningChange(true);
                setIsInitializing(false);
                console.log('Recognition restarted successfully');
              } catch (retryError) {
                console.error('Retry failed:', retryError);
                onListeningChange(false);
                setIsInitializing(false);
              }
            }, 200);
          } else {
            onListeningChange(false);
            setIsInitializing(false);
          }
        }
      }, 100);
    }
  };

  const handleReset = () => {
    console.log('🔄 Resetting conversation and microphone...');
    
    // Force stop and destroy current recognition
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
        recognitionRef.current.abort();
      } catch (e) {
        console.log('Recognition already stopped');
      }
    }
    
    // Reset all states
    onListeningChange(false);
    setIsInitializing(false);
    setTranscript('');
    setInterimTranscript('');
    
    // Call parent reset callback to clear messages
    if (onReset) {
      onReset();
    }
    
    // Reinitialize the recognition object
    console.log('🔄 Reinitializing Speech Recognition API...');
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      
      // Reattach all event handlers (copy from useEffect)
      recognition.onstart = () => {
        console.log('✅ Speech recognition restarted successfully');
      };
      
      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            final += transcript;
          } else {
            interim += transcript;
          }
        }
        if (final) {
          setTranscript(final);
          setInterimTranscript('');
        } else {
          setInterimTranscript(interim);
        }
      };
      
      recognition.onend = () => {
        if (transcript) {
          onVoiceInput(transcript);
          setTranscript('');
        }
        onListeningChange(false);
        setIsInitializing(false);
      };
      
      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        onListeningChange(false);
        setIsInitializing(false);
      };
      
      recognitionRef.current = recognition;
      console.log('✅ Conversation and microphone reset complete');
    }
  };

  return (
    <div className="voice-controls">
      <div className="voice-controls-buttons">
        <button
          className={`mic-button ${isListening ? 'listening' : ''} ${isDisabled || isInitializing ? 'disabled' : ''}`}
          onClick={toggleListening}
          disabled={isDisabled || isInitializing}
          aria-label={
            isDisabled ? 'Audio playing...' : 
            isInitializing ? 'Initializing microphone...' :
            isListening ? 'Stop listening' : 
            'Start listening'
          }
        >
          <div className="mic-icon">
            {isDisabled ? '🔇' : isInitializing ? '⏳' : isListening ? '🎤' : '🎙️'}
          </div>
          {isListening && !isDisabled && !isInitializing && (
            <div className="pulse-ring"></div>
          )}
        </button>

        <button
          className="reset-button"
          onClick={handleReset}
          disabled={isDisabled}
          aria-label="Reset microphone"
          title="Reset Microphone"
        >
          🔄
        </button>
      </div>

      {isInitializing && (
        <div className="transcript-display">
          <div className="transcript-content">
            Initializing microphone...
          </div>
        </div>
      )}

      {(isListening || interimTranscript) && !isInitializing && (
        <div className="transcript-display">
          <div className="transcript-content">
            {interimTranscript || 'Listening...'}
          </div>
        </div>
      )}

      {transcript && !isListening && (
        <div className="last-transcript">
          Last: "{transcript}"
        </div>
      )}
    </div>
  );
};

export default VoiceControls;
