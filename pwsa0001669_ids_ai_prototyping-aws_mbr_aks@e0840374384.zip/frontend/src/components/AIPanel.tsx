/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import React, { useEffect, useRef } from 'react';
import { marked } from 'marked';
import ChartDisplay from './ChartDisplay';
import './AIPanel.css';

// Configure marked options
marked.setOptions({
  breaks: true,
  gfm: true, // GitHub Flavored Markdown (includes tables)
});

// Markdown renderer component using marked library
const MarkdownRenderer: React.FC<{ content: string }> = ({ content }) => {
  const html = marked.parse(content) as string;
  return <div dangerouslySetInnerHTML={{ __html: html }} />;
};

interface Message {
  role: 'user' | 'assistant';
  content: string;
  dataSource?: string;
  timestamp: Date;
  chartData?: any;
  isPlaying?: boolean;
  timing?: {
    data_load?: number;
    agent_processing?: number;
    total?: number;
  };
  isProcessing?: boolean;
  progressStatus?: string;
}

interface AIPanelProps {
  messages: Message[];
  isProcessing: boolean;
  onPlayAudio?: (text: string, messageIndex: number) => void;
  onSendMessage?: (text: string) => void;
  isListening: boolean;
  onVoiceInput: (transcript: string) => void;
  onListeningChange: (isListening: boolean) => void;
  isVoiceDisabled?: boolean;
  onReset?: () => void;
}

const AIPanel: React.FC<AIPanelProps> = ({ 
  messages, 
  isProcessing, 
  onPlayAudio, 
  onSendMessage,
  isListening,
  onVoiceInput,
  onListeningChange,
  isVoiceDisabled = false,
  onReset
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [inputText, setInputText] = React.useState('');
  const [transcript, setTranscript] = React.useState<string>('');
  const [interimTranscript, setInterimTranscript] = React.useState<string>('');
  const [isInitializing, setIsInitializing] = React.useState<boolean>(false);
  const recognitionRef = useRef<any>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initialize speech recognition
  useEffect(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      console.warn('Speech recognition not supported in this browser');
      return;
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      console.log('✅ Speech recognition started successfully');
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          final += transcript;
        } else {
          interim += transcript;
        }
      }

      if (final) {
        console.log('✅ Final transcript:', final);
        setTranscript(final);
        setInterimTranscript('');
        onVoiceInput(final);
        
        try {
          recognition.stop();
        } catch (e) {
          console.log('Recognition already stopping');
        }
      } else {
        setInterimTranscript(interim);
      }
    };

    recognition.onerror = (event: any) => {
      console.error('❌ Speech recognition error:', event.error);
      onListeningChange(false);
      setInterimTranscript('');
      setIsInitializing(false);
    };

    recognition.onend = () => {
      console.log('🛑 Speech recognition ended');
      setTimeout(() => {
        onListeningChange(false);
        setInterimTranscript('');
        setIsInitializing(false);
      }, 50);
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // Already stopped
        }
      }
    };
  }, [onVoiceInput, onListeningChange]);

  // Stop recognition when disabled
  useEffect(() => {
    if (isVoiceDisabled && recognitionRef.current && isListening) {
      console.log('Stopping recognition due to disabled state');
      try {
        recognitionRef.current.stop();
        onListeningChange(false);
        setIsInitializing(false);
      } catch (e) {
        console.error('Error stopping recognition:', e);
        onListeningChange(false);
        setIsInitializing(false);
      }
    }
  }, [isVoiceDisabled, isListening, onListeningChange]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const toggleListening = () => {
    if (isVoiceDisabled || isInitializing || !recognitionRef.current) {
      return;
    }
    
    if (isListening) {
      try {
        recognitionRef.current.stop();
        onListeningChange(false);
        setIsInitializing(false);
      } catch (e) {
        console.error('Error stopping:', e);
        onListeningChange(false);
        setIsInitializing(false);
      }
    } else {
      setTranscript('');
      setInterimTranscript('');
      setIsInitializing(true);
      
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // Ignore
      }
      
      setTimeout(() => {
        try {
          recognitionRef.current.start();
          onListeningChange(true);
          setIsInitializing(false);
        } catch (e: any) {
          console.error('Error starting recognition:', e);
          onListeningChange(false);
          setIsInitializing(false);
        }
      }, 100);
    }
  };

  const handleReset = () => {
    console.log('🔄 Resetting conversation and microphone...');
    
    // Force stop and destroy current recognition
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
        recognitionRef.current.abort();
      } catch (e) {
        console.log('Recognition already stopped');
      }
    }
    
    // Reset all states
    onListeningChange(false);
    setIsInitializing(false);
    setTranscript('');
    setInterimTranscript('');
    
    // Call parent reset callback to clear messages
    if (onReset) {
      onReset();
    }
    
    // Reinitialize the recognition object
    console.log('🔄 Reinitializing Speech Recognition API...');
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      
      recognition.onstart = () => {
        console.log('✅ Speech recognition restarted successfully');
      };
      
      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            final += transcript;
          } else {
            interim += transcript;
          }
        }
        if (final) {
          setTranscript(final);
          setInterimTranscript('');
          onVoiceInput(final);
          try {
            recognition.stop();
          } catch (e) {
            console.log('Recognition already stopping');
          }
        } else {
          setInterimTranscript(interim);
        }
      };
      
      recognition.onend = () => {
        setTimeout(() => {
          onListeningChange(false);
          setInterimTranscript('');
          setIsInitializing(false);
        }, 50);
      };
      
      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        onListeningChange(false);
        setIsInitializing(false);
      };
      
      recognitionRef.current = recognition;
      console.log('✅ Conversation and microphone reset complete');
    }
  };

  const handleSendMessage = () => {
    if (inputText.trim() && onSendMessage && !isProcessing) {
      onSendMessage(inputText.trim());
      setInputText('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="ai-panel">
      {/* Header */}
      <div className="ai-panel-header">
        <div className="header-content">
          <div className="ai-icon">✨</div>
          <div className="header-text">
            <h2>AI Assistant</h2>
            <p>Ask questions about your MBR</p>
          </div>
        </div>
        <div className="status-indicator">
          <span className={`status-dot ${isProcessing ? 'processing' : 'ready'}`}></span>
          <span className="status-text">
            {isProcessing ? 'Processing...' : 'Ready'}
          </span>
        </div>
      </div>

      {/* Messages */}
      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">💬</div>
            <h3>Start a conversation</h3>
            <p>Click the microphone button and ask a question about the data shown in the slides.</p>
            <div className="example-questions">
              <p className="example-title">Try asking:</p>
              <ul>
                <li>"What is calls per day by Region for all Tiers?"</li>
                <li>"What is Pluvicto Net Sales YTD as compared to forecast and previous year?"</li>
                <li>"Which month has highest number of shipped doses this year?"</li>
                <li>"Show me top 10 sites by volume."</li>
                <li>"Show me market share data for Pluvicto."</li>
              </ul>
            </div>
            {/* Footer in empty state */}
            {/* <div className="empty-state-footer">
              <p className="footer-text">
                Powered by Claude Sonnet 4.5 • Voice-enabled • Amazon Polly
              </p>
            </div> */}
          </div>
        ) : (
          <div className="messages-list">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`message ${message.role}`}
              >
                <div className="message-avatar">
                  {message.role === 'user' ? '👤' : '✨'}
                </div>
                <div className="message-content">
                  {message.isProcessing ? (
                    <div className="processing-message">
                      <div className="progress-spinner"></div>
                      <div className="progress-text">{message.progressStatus}</div>
                    </div>
                  ) : (
                    <>
                      <div className="message-text">
                        {message.role === 'assistant' ? (
                          <MarkdownRenderer content={message.content} />
                        ) : (
                          message.content
                        )}
                      </div>
                      {message.chartData && (
                        <ChartDisplay chartData={message.chartData} />
                      )}
                      {message.dataSource && (
                        <div className="data-source-badge">
                          <span className="source-icon">📊</span>
                          <span className="source-text">DynamoDB: {message.dataSource}</span>
                        </div>
                      )}
                      {message.timing && message.timing.total && (
                        <div className="timing-summary">
                          <strong>⏱️ Performance:</strong> Total {message.timing.total}s
                          {message.timing.data_load !== undefined && (
                            <span> • Data Load: {message.timing.data_load}s</span>
                          )}
                          {message.timing.agent_processing !== undefined && (
                            <span> • AI Processing: {message.timing.agent_processing}s</span>
                          )}
                        </div>
                      )}
                      <div className="message-footer">
                        <div className="message-time">{formatTime(message.timestamp)}</div>
                        {message.role === 'assistant' && onPlayAudio && (
                          <button
                            className="play-audio-btn"
                            onClick={() => onPlayAudio(message.content, index)}
                            disabled={message.isPlaying}
                            title="Play audio"
                          >
                            {message.isPlaying ? '🔊' : '🔈'}
                          </button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </div>
            ))}
            {isProcessing && (
              <div className="message assistant">
                <div className="message-avatar">✨</div>
                <div className="message-content">
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Chat Input - Inside messages area, above footer */}
      <div className="chat-input-wrapper">
        <div className="chat-input-container">
          <div className="voice-buttons-group">
            <button
              className={`mic-button-inline ${isListening ? 'listening' : ''} ${isVoiceDisabled || isInitializing ? 'disabled' : ''}`}
              onClick={toggleListening}
              disabled={isVoiceDisabled || isInitializing}
              title={
                isVoiceDisabled ? 'Audio playing...' : 
                isInitializing ? 'Initializing microphone...' :
                isListening ? 'Stop listening' : 
                'Start voice input'
              }
            >
              {isVoiceDisabled ? '🔇' : isInitializing ? '⏳' : isListening ? '🎤' : '🎙️'}
            </button>
            <button
              className="reset-button-inline"
              onClick={handleReset}
              disabled={isVoiceDisabled}
              title="Reset conversation and microphone"
            >
              🔄
            </button>
          </div>
          <textarea
            className="chat-input"
            placeholder={isListening ? 'Listening...' : interimTranscript || 'Type your question here... (or use voice)'}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={isProcessing}
            rows={1}
          />
          <button
            className="send-button"
            onClick={handleSendMessage}
            disabled={isProcessing || !inputText.trim()}
            title="Send message"
          >
            {isProcessing ? '⏳' : '📤'}
          </button>
        </div>
        {(isListening || interimTranscript) && !isInitializing && (
          <div className="transcript-display-inline">
            {interimTranscript || 'Listening...'}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="ai-panel-footer">
        <p className="footer-text">
          Powered by Claude Sonnet 4.5 • Voice & Text • Amazon Polly
        </p>
      </div>
    </div>
  );
};

export default AIPanel;
