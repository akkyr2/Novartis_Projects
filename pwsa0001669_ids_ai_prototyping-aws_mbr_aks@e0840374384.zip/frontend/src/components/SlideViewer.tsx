/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import React, { useState } from 'react';
import './SlideViewer.css';
import { apiRequest } from '../utils/apiUtils';
import PDFUpload from './PDFUpload';

interface SlideViewerProps {
  currentSlide: number;
  onSlideChange: (slideNumber: number) => void;
  onUploadComplete?: (totalSlides: number, filename?: string) => void;
}

const SlideViewer: React.FC<SlideViewerProps> = ({
  currentSlide,
  onSlideChange,
  onUploadComplete
}) => {
  const [slideImageUrl, setSlideImageUrl] = React.useState<string>('');
  const [isReady, setIsReady] = useState<boolean>(false); // Track if preprocessing is complete
  const [totalSlides, setTotalSlides] = useState<number>(1); // Will be updated after upload
  const [pdfFileName, setPdfFileName] = useState<string>(''); // Store PDF filename
  const [loading, setLoading] = React.useState<boolean>(true);
  const [error, setError] = React.useState<boolean>(false);

  // Load slide image from backend API
  React.useEffect(() => {
    if (!isReady) return; // Don't fetch slides until PDF is uploaded
    
    const fetchSlide = async () => {
      setLoading(true);
      setError(false);
      try {
        const response = await apiRequest(`/api/slides/${currentSlide}`);
        if (!response.ok) {
          throw new Error('Slide not found');
        }
        const data = await response.json();
        if (data.imageData) {
          setSlideImageUrl(`data:image/png;base64,${data.imageData}`);
        } else {
          throw new Error('No image data');
        }
      } catch (err) {
        console.error('Error loading slide:', err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchSlide();
  }, [currentSlide, isReady]);

  const handlePrevious = () => {
    if (currentSlide > 1) {
      onSlideChange(currentSlide - 1);
    }
  };

  const handleNext = () => {
    if (currentSlide < totalSlides) {
      onSlideChange(currentSlide + 1);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft') handlePrevious();
    if (e.key === 'ArrowRight') handleNext();
  };

  // Handle upload completion
  const handleUploadComplete = (slideCount: number, filename?: string) => {
    setTotalSlides(slideCount);
    setPdfFileName(filename || 'Presentation');
    setIsReady(true);
    onUploadComplete?.(slideCount, filename);
    // Clear previous conversation when new PDF is uploaded
    console.log('🔄 Cleared conversation for new PDF upload');
  };

  return (
    <div className="slide-viewer" onKeyDown={handleKeyDown} tabIndex={0}>
      {/* Slide Display */}
      <div className="slide-display">
        {!isReady ? (
          <PDFUpload onUploadComplete={handleUploadComplete} />
        ) : loading ? (
          <div className="slide-loading">Loading slide...</div>
        ) : error || !slideImageUrl ? (
          <div className="slide-error">
            <svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">
              <rect width="800" height="600" fill="#f0f0f0"/>
              <text x="50%" y="50%" textAnchor="middle" fill="#666" fontSize="24">
                Slide {currentSlide} not available
              </text>
            </svg>
          </div>
        ) : (
          <img
            src={slideImageUrl}
            alt={`Slide ${currentSlide}`}
            className="slide-image"
          />
        )}
      </div>

      {/* Navigation Controls */}
      { !isReady ? (
      <div className="info-panel">
        <p>
            This dashboard uses advanced AI to analyze your Monthly Business Review presentations. 
            Ask questions in natural language, get instant insights from your data, and explore 
            interactive visualizations—all powered by voice and conversational AI.
          </p>
        </div>) :
      <div className="slide-controls">
        <button
          className="nav-button"
          onClick={handlePrevious}
          disabled={currentSlide === 1}
          aria-label="Previous slide"
        >
          ← Previous
        </button>

        <div className="slide-counter">
          <span className="current-slide">{currentSlide}</span>
          <span className="separator">/</span>
          <span className="total-slides">{totalSlides}</span>
        </div>

        <button
          className="nav-button"
          onClick={handleNext}
          disabled={currentSlide === totalSlides}
          aria-label="Next slide"
        >
          Next →
        </button>
      </div>}

      {/* Keyboard hint */}
      <div className="keyboard-hint">
        Use ← → arrow keys to navigate
      </div>
    </div>
  );
};

export default SlideViewer;
