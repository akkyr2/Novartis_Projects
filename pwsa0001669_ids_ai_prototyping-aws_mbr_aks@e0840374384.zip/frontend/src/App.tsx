/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import React, { useState, useEffect } from 'react';
import { flushSync } from 'react-dom';
import './App.css';
import AIPanel from './components/AIPanel';
import { BrowserRouter as Router } from 'react-router-dom';
import { getApiUrl, getBaseUrl } from './utils/apiUtils';
import awsLogo from './assets/logos/aws.png';
import novartisLogo from './assets/logos/novartis.png';
import collapsedLogo from './assets/logos/collapsed_logo_light.png';
import expandedLogo from './assets/logos/white_logo_light.png';
import { sessionManager } from './utils/sessionManager';
import { apiRequest } from './utils/apiUtils';


interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  chartData?: any;
  dataSource?: string;
  audioSummary?: string;
  isPlaying?: boolean;
  timing?: {
    data_load?: number;
    agent_processing?: number;
    total?: number;
  };
  isProcessing?: boolean;
  progressStatus?: string;
}

function App() {
  const [currentSlide, setCurrentSlide] = useState<number>(1);
  const [totalSlides, setTotalSlides] = useState<number>(62);
  // const [pdfFileName, setPdfFileName] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [currentAudio, setCurrentAudio] = useState<HTMLAudioElement | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const audioTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);
  const [agentMode, setAgentMode] = useState<boolean | null>(null); // null = auto-detect
  const [useStreaming, setUseStreaming] = useState<boolean>(false); // Enable streaming by default
  


  // Initialize session on mount
  useEffect(() => {
    const sessionId = sessionManager.getSessionId();
    console.log('📱 App initialized with session:', sessionId);
  }, []);
    // Handle text input from chat box
    const handleTextInput = async (text: string) => {
      console.log('💬 handleTextInput called:', text);
      // Use the same handler as voice input
      return handleVoiceInput(text);
    };

  // Handle voice input with streaming support
  const handleVoiceInput = async (transcript: string) => {
    console.log('🎯 handleVoiceInput called, useStreaming:', useStreaming);
        if (useStreaming) {
          console.log('✅ Using STREAMING mode');
          return handleVoiceInputStreaming(transcript);
        }
        console.log('⚠️ Using NON-STREAMING mode');
        return handleVoiceInputNonStreaming(transcript);
      };
    
      // Streaming version - tokens appear as they arrive
      const handleVoiceInputStreaming = async (transcript: string) => {
        if (!transcript.trim()) return;
    
        // Add user message
        const userMessage: Message = {
          role: 'user',
          content: transcript,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, userMessage]);
        setIsProcessing(true);
    
        // Add empty assistant message that will be filled as tokens arrive
        const assistantMessageIndex = messages.length + 1;
        const assistantMessage: Message = {
          role: 'assistant',
          content: '',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, assistantMessage]);
    
        // Track timing
        const startTime = Date.now();
        let firstTokenTime: number | null = null;
    
        try {
          // Prepare conversation history
          const recentHistory = messages.slice(-6).map(m => ({
            role: m.role,
            content: m.content,
            audioSummary: m.audioSummary
          }));
    
          // Open EventSource for streaming
          console.log('🚀 Calling /api/ask-stream endpoint');
          const response = await fetch('/api/ask-stream', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              question: transcript,
              slideNumber: currentSlide,
              conversationHistory: recentHistory,
              agentMode: agentMode
            })
          });
          console.log('📡 Response received, status:', response.status);
    
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
    
          const reader = response.body?.getReader();
          const decoder = new TextDecoder();
    
          if (!reader) {
            throw new Error('No reader available');
          }
    
          let accumulatedText = '';
          let chartData: any = null;
          let audioSummary: string = '';
          let dataSource: string = '';
    
          while (true) {
            const { done, value } = await reader.read();
            
            if (done) {
              console.log('✅ Stream complete');
              break;
            }
    
            // Decode chunk
            const chunk = decoder.decode(value, { stream: true });
            
            // Parse SSE format (data: {...}\n\n)
            const lines = chunk.split('\n');
            for (const line of lines) {
              if (line.startsWith('data: ')) {
                try {
                  const data = JSON.parse(line.substring(6));
                  
                  if (data.type === 'text') {
                    // Track first token time
                    if (!firstTokenTime) {
                      firstTokenTime = Date.now();
                      const timeToFirst = ((firstTokenTime - startTime) / 1000).toFixed(2);
                      console.log(`⚡ First token received in ${timeToFirst}s`);
                    }
                    
                    // Append text token
                    accumulatedText += data.content;
                    console.log('📝 Token received:', data.content, '| Total length:', accumulatedText.length);
                    
                    // Remove audio summary marker if present
                    let displayText = accumulatedText;
                    if (displayText.includes('---AUDIO_SUMMARY---')) {
                      displayText = displayText.split('---AUDIO_SUMMARY---')[0].trim();
                    }
                    
                    // Update message in real-time with flushSync to force immediate render
                    flushSync(() => {
                      setMessages(prev => {
                        const updated = [...prev];
                        updated[assistantMessageIndex] = {
                          ...updated[assistantMessageIndex],
                          content: displayText
                        };
                        return updated;
                      });
                    });
                  }
                  else if (data.type === 'chart') {
                    // Add chart when ready
                    chartData = data.content;
                    setMessages(prev => {
                      const updated = [...prev];
                      updated[assistantMessageIndex] = {
                        ...updated[assistantMessageIndex],
                        chartData: chartData
                      };
                      return updated;
                    });
                  }
                  else if (data.type === 'source') {
                    // Add data source
                    dataSource = data.content;
                    setMessages(prev => {
                      const updated = [...prev];
                      updated[assistantMessageIndex] = {
                        ...updated[assistantMessageIndex],
                        dataSource: dataSource
                      };
                      return updated;
                    });
                  }
                  else if (data.type === 'audio') {
                    // Add audio summary (but don't display it in content)
                    audioSummary = data.content;
                    
                    // Calculate timing
                    const endTime = Date.now();
                    const totalTime = ((endTime - startTime) / 1000).toFixed(2);
                    const timeToFirst = firstTokenTime ? ((firstTokenTime - startTime) / 1000).toFixed(2) : '0';
                    
                    console.log(`⏱️ Performance: First token: ${timeToFirst}s, Total: ${totalTime}s`);
                    
                    setMessages(prev => {
                      const updated = [...prev];
                      updated[assistantMessageIndex] = {
                        ...updated[assistantMessageIndex],
                        audioSummary: audioSummary,
                        timing: {
                          data_load: parseFloat(timeToFirst),
                          total: parseFloat(totalTime)
                        }
                      };
                      return updated;
                    });
                    
                    // Auto-play audio
                    if (audioSummary) {
                      playAudio(audioSummary, assistantMessageIndex);
                    }
                  }
                  else if (data.type === 'complete') {
                    console.log('✅ Response complete');
                  }
                  else if (data.type === 'error') {
                    console.error('❌ Stream error:', data.content);
                    throw new Error(data.content);
                  }
                } catch (parseError) {
                  console.error('Error parsing SSE data:', parseError);
                }
              }
            }
          }
    
        } catch (error) {
          console.error('Error in streaming:', error);
          
          // Update message with error
          setMessages(prev => {
            const updated = [...prev];
            updated[assistantMessageIndex] = {
              ...updated[assistantMessageIndex],
              content: 'I apologize, but I encountered an error. Please try again.'
            };
            return updated;
          });
        } finally {
          setIsProcessing(false);
        }
      };
    
      // Non-streaming version (original implementation)
      const handleVoiceInputNonStreaming = async (transcript: string) => {
    if (!transcript.trim()) return;

    // Add user message
    const userMessage: Message = {
      role: 'user',
      content: transcript,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setIsProcessing(true);

    // Add a temporary processing message with progress
    const processingMessage: Message = {
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isProcessing: true,
      progressStatus: 'Initializing...'
    };
    setMessages(prev => [...prev, processingMessage]);

    try {
      // Realistic progress updates that match backend processing
      const progressSteps = [
        { text: 'Loading slide data...', duration: 800 },
        { text: 'Analyzing question with vision model...', duration: 1500 },
        { text: 'Querying DynamoDB for KPI data...', duration: 1200 },
        { text: 'LLM reasoning and tool selection...', duration: 2000 },
        { text: 'Generating charts and insights...', duration: 1500 },
        { text: 'Finalizing response...', duration: 800 }
      ];

      let currentStep = 0;
      let stepStartTime = Date.now();
      
      const progressInterval = setInterval(() => {
        const elapsed = Date.now() - stepStartTime;
        
        if (currentStep < progressSteps.length) {
          // Update to next step if duration passed
          if (elapsed >= progressSteps[currentStep].duration) {
            currentStep++;
            stepStartTime = Date.now();
          }
          
          // Update progress message
          if (currentStep < progressSteps.length) {
            setMessages(prev => {
              const newMessages = [...prev];
              const lastMsg = newMessages[newMessages.length - 1];
              if (lastMsg && lastMsg.isProcessing) {
                lastMsg.progressStatus = progressSteps[currentStep].text;
              }
              return newMessages;
            });
          }
        }
      }, 100);

      try {
        const apiStartTime = Date.now();
        console.log('🚀 Starting API call...');
        
        // Call backend API with conversation history (last 3 messages for context)
        const recentHistory = messages.slice(-6).map(m => ({
          role: m.role,
          content: m.content,
          audioSummary: m.audioSummary  // Include audio summary for follow-up extraction
        }));
        
        const response = await apiRequest('/api/ask', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question: transcript,
            slideNumber: currentSlide,
            conversationHistory: recentHistory,
            agentMode: agentMode  // null = auto-detect, true = force agent, false = force rule-based
          })
        });

        clearInterval(progressInterval);
        const data = await response.json();
        const apiEndTime = Date.now();
        const totalWaitTime = ((apiEndTime - apiStartTime) / 1000).toFixed(2);
        
        console.log('✅ API call completed');
        console.log(`⏱️ Frontend wait time: ${totalWaitTime}s`);
        console.log('📊 Response data:', data);
        console.log('⏱️ Backend timing:', data.timing);

        // Remove processing message and add final assistant message
        setMessages(prev => {
          const filtered = prev.filter(m => !m.isProcessing);
          const assistantMessage: Message = {
            role: 'assistant',
            content: data.answer || 'I apologize, but I encountered an error processing your question.',
            timestamp: new Date(),
            chartData: data.chartData || undefined,
            dataSource: data.dataSource || undefined,
            audioSummary: data.audioSummary || undefined,
            timing: data.timing || undefined
          };
          console.log('💬 Assistant message with timing:', assistantMessage);
          return [...filtered, assistantMessage];
        });

        // Auto-play response with Polly
        // Use audioSummary if available (for agent mode), otherwise use full answer
        const audioText = data.audioSummary || data.answer;
        if (audioText) {
          playAudio(audioText, messages.length);
        }
      } catch (error) {
        clearInterval(progressInterval);
        console.error('Error processing question:', error);
        
        // Remove processing message and add error message
        setMessages(prev => {
          const filtered = prev.filter(m => !m.isProcessing);
          const errorMessage: Message = {
            role: 'assistant',
            content: 'I apologize, but I encountered an error. Please try again.',
            timestamp: new Date()
          };
          return [...filtered, errorMessage];
        });
      }
    } catch (outerError) {
      console.error('Outer error:', outerError);
    } finally {
      setIsProcessing(false);
    }
  };

  // Play audio using Amazon Polly
  const playAudio = async (text: string, messageIndex: number) => {
    try {
      console.log('🔊 Starting audio playback');
      // CRITICAL: Stop listening and block mic during audio playback
      setIsListening(false);
      setIsPlayingAudio(true);
      console.log('🔇 Microphone disabled for audio playback');
      
      // Clear any existing timeout
      if (audioTimeoutRef.current) {
        clearTimeout(audioTimeoutRef.current);
      }
      
      // Safety timeout: re-enable mic after 30 seconds if something goes wrong
      audioTimeoutRef.current = setTimeout(() => {
        console.warn('Audio timeout - force re-enabling microphone');
        setIsPlayingAudio(false);
        setMessages(prev => prev.map(msg => ({ ...msg, isPlaying: false })));
      }, 30000);
      
      // Stop any currently playing audio
      if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
      }

      // Mark message as playing
      setMessages(prev => prev.map((msg, idx) => ({
        ...msg,
        isPlaying: idx === messageIndex
      })));

      // Call Polly API
      const response = await apiRequest('/api/synthesize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });

      const data = await response.json();

      if (data.audioData) {
        // Convert base64 to audio
        const audioBlob = new Blob(
          [Uint8Array.from(atob(data.audioData), c => c.charCodeAt(0))],
          { type: 'audio/mpeg' }
        );
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);

        audio.onended = () => {
          console.log('Audio playback ended');
          if (audioTimeoutRef.current) {
            clearTimeout(audioTimeoutRef.current);
          }
          setMessages(prev => prev.map(msg => ({ ...msg, isPlaying: false })));
          setCurrentAudio(null);
          URL.revokeObjectURL(audioUrl);
          // Add delay before allowing mic to start again
          setTimeout(() => {
            console.log('Re-enabling microphone');
            setIsPlayingAudio(false);
          }, 1500); // 1.5 second buffer after audio ends
        };

        audio.onerror = () => {
          console.error('Audio playback error');
          if (audioTimeoutRef.current) {
            clearTimeout(audioTimeoutRef.current);
          }
          setMessages(prev => prev.map(msg => ({ ...msg, isPlaying: false })));
          setCurrentAudio(null);
          setIsPlayingAudio(false);
        };

        setCurrentAudio(audio);
        await audio.play();
      } else {
        // No audio data received - re-enable microphone immediately
        console.warn('No audio data received from Polly');
        if (audioTimeoutRef.current) {
          clearTimeout(audioTimeoutRef.current);
        }
        setMessages(prev => prev.map(msg => ({ ...msg, isPlaying: false })));
        setIsPlayingAudio(false);
      }
    } catch (error) {
      console.error('Error playing audio:', error);
      if (audioTimeoutRef.current) {
        clearTimeout(audioTimeoutRef.current);
      }
      setMessages(prev => prev.map(msg => ({ ...msg, isPlaying: false })));
      setIsPlayingAudio(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="header-logos-top">
          <img src={novartisLogo} alt="Novartis" className="header-logo header-logo-left" />
        </div>
        <div className="header-logos-top-right">
          <img src={awsLogo} alt="AWS" className="header-logo header-logo-right" />
        </div>
        <div className="header-content">
          <div className="header-title">
            <img src={collapsedLogo} alt="Novartis" className="header-inline-logo" />
            <div className="header-text">
              <h1>MBR Dashboard</h1>
              <p style={{ color: '#ffffff !important', textDecoration: 'none', opacity: 1, filter: 'none', WebkitTextFillColor: '#ffffff' }}></p>
                <div className="disclaimer">
                    FOR TESTING ONLY — NOT FOR BUSINESS USE
                </div>
            </div>
          </div>
          {/* <div className="agent-mode-toggle">
            <label>
              <select 
                value={agentMode === null ? 'auto' : agentMode ? 'agent' : 'rule'}
                onChange={(e) => {
                  const value = e.target.value;
                  setAgentMode(value === 'auto' ? null : value === 'agent');
                }}
                style={{
                  padding: '8px 12px',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  backgroundColor: 'white',
                  fontSize: '14px',
                  cursor: 'pointer'
                }}
              >
                <option value="auto">🤖 Auto Mode</option>
                <option value="agent">🧠 Agent Mode (QuickSuite-like)</option>
                <option value="rule">⚡ Rule Mode (Fast)</option>
              </select>
            </label>
          </div> */}
        </div>
      </header>

      <div className="dashboard-container">
        {/* AI Assistant Panel - Full width */}
        <div className="ai-panel-container">
          <AIPanel
            messages={messages}
            isProcessing={isProcessing}
            onPlayAudio={playAudio}
            onSendMessage={handleTextInput}
            isListening={isListening}
            onVoiceInput={handleVoiceInput}
            onListeningChange={setIsListening}
            isVoiceDisabled={isPlayingAudio}
            onReset={() => {
              console.log('🔄 Clearing conversation messages');
              setMessages([]);
            }}
          />
        </div>
      </div>
        
      {/* Debug: Force enable microphone if stuck */}
      {isPlayingAudio && (
        <div style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          background: '#ff9900',
          color: 'white',
          padding: '10px 20px',
          borderRadius: '8px',
          cursor: 'pointer',
          zIndex: 10001,
          boxShadow: '0 4px 6px rgba(0,0,0,0.2)'
        }}
        onClick={() => {
          console.log('🔓 Force enabling microphone');
          setIsPlayingAudio(false);
          if (currentAudio) {
            currentAudio.pause();
            setCurrentAudio(null);
          }
          if (audioTimeoutRef.current) {
            clearTimeout(audioTimeoutRef.current);
          }
        }}>
          🔓 Stop Voice-Over & Unlock Microphone
        </div>
      )}
    </div>
  );
}

function baseApp() {
  const baseUrl = getBaseUrl();

  return (
    <Router basename={baseUrl}>
      <App />
    </Router> 
  )
}


export default baseApp;