/**
 * Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
 * Session Manager for MBR Dashboard
 * 
 * Manages user session IDs for multi-session support.
 * Each browser tab gets its own unique session ID stored in sessionStorage.
 */

class SessionManager {
  private sessionId: string | null = null;
  private readonly SESSION_KEY = 'mbr-session-id';

  /**
   * Get or create session ID
   * 
   * If a session ID exists in sessionStorage, it will be restored.
   * Otherwise, a new UUID will be generated and stored.
   * 
   * @returns The current session ID
   */
  getSessionId(): string {
    if (!this.sessionId) {
      // Try to load from session storage
      this.sessionId = sessionStorage.getItem(this.SESSION_KEY);
      
      if (!this.sessionId) {
        // Generate new UUID
        this.sessionId = this.generateUUID();
        sessionStorage.setItem(this.SESSION_KEY, this.sessionId);
        console.log('🆕 Created new session:', this.sessionId);
      } else {
        console.log('♻️ Restored session:', this.sessionId);
      }
    }
    
    return this.sessionId;
  }

  /**
   * Clear current session
   * 
   * Removes the session ID from sessionStorage and resets the internal state.
   * The next call to getSessionId() will generate a new session.
   */
  clearSession(): void {
    sessionStorage.removeItem(this.SESSION_KEY);
    this.sessionId = null;
    console.log('🗑️ Cleared session');
  }

  /**
   * Generate UUID v4
   * 
   * Creates a cryptographically secure random UUID v4 identifier using Web Crypto API.
   * 
   * @returns A UUID v4 string
   */
  private generateUUID(): string {
    // Use crypto.randomUUID() if available (modern browsers)
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    
    // Fallback: Use crypto.getRandomValues() for older browsers
    if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = crypto.getRandomValues(new Uint8Array(1))[0] % 16;
        const v = c === 'x' ? r : ((r & 0x3) | 0x8);
        return v.toString(16);
      });
    }
    
    // Should never reach here in modern browsers
    throw new Error('Crypto API not available - cannot generate secure session ID');
  }
}

// Export singleton instance
export const sessionManager = new SessionManager();
