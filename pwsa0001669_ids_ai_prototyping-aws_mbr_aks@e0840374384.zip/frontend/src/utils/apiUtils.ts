/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import { sessionManager } from './sessionManager';

/**
 * API Request Options
 * Extends RequestInit with additional configuration options
 */
export interface ApiRequestOptions extends RequestInit {
  // Extend RequestInit with any custom options if needed
}

/**
 * Get the base URL from environment variable
 */
export const getBaseUrl = (): string => {
  return process.env.REACT_APP_BASE_URL || '';
};

/**
 * Construct an API URL with the base URL prefix
 * @param endpoint - The API endpoint (e.g., '/api/ask', '/api/synthesize')
 * @returns The full URL with base path included
 * 
 * @example
 * // If REACT_APP_BASE_URL is '/mbr-dashboard'
 * getApiUrl('/api/ask') // returns '/mbr-dashboard/api/ask'
 * 
 * // If REACT_APP_BASE_URL is empty
 * getApiUrl('/api/ask') // returns '/api/ask'
 */
export const getApiUrl = (endpoint: string): string => {
  const baseUrl = getBaseUrl();
  
  // Ensure endpoint starts with '/'
  const normalizedEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  
  // If baseUrl is empty, return endpoint as is
  if (!baseUrl) {
    return normalizedEndpoint;
  }
  
  // Remove trailing slash from baseUrl if present
  const normalizedBaseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
  
  return `${normalizedBaseUrl}${normalizedEndpoint}`;
};

/**
 * Validate endpoint to prevent SSRF attacks
 * Only allows alphanumeric characters, hyphens, underscores, slashes, dots, and query strings
 * Prevents path traversal and absolute URLs
 */
function validateEndpoint(endpoint: string): void {
  // Reject empty endpoints
  if (!endpoint || endpoint.trim() === '') {
    throw new Error('Invalid endpoint: endpoint cannot be empty');
  }

  // Reject absolute URLs (http://, https://, //)
  if (/^(https?:)?\/\//i.test(endpoint)) {
    throw new Error('Invalid endpoint: absolute URLs are not allowed');
  }

  // Reject path traversal attempts
  if (endpoint.includes('..')) {
    throw new Error('Invalid endpoint: path traversal is not allowed');
  }

  // Allow safe characters: alphanumeric, hyphens, underscores, forward slashes, dots, and query strings
  if (!/^[a-zA-Z0-9\-_\/\.?&=]+$/.test(endpoint)) {
    throw new Error('Invalid endpoint: contains invalid characters');
  }
}

/**
 * Make an API request with automatic session ID injection
 * 
 * @param endpoint - API endpoint (e.g., '/api/ask', '/api/synthesize')
 * @param options - Fetch options (method, headers, body, etc.)
 * @returns Promise with the fetch response
 */
export async function apiRequest(
  endpoint: string,
  options: ApiRequestOptions = {}
): Promise<Response> {
  // Validate endpoint to prevent SSRF
  validateEndpoint(endpoint);
  
  // Get session ID
  const sessionId = sessionManager.getSessionId();
  
  // Build full URL
  const url = getApiUrl(endpoint);
  
  // Merge headers with session ID
  const headers = {
    ...options.headers,
    'X-Session-ID': sessionId,
  };
  
  // Make request
  try {
    const response = await fetch(url, {
      ...options,
      headers,
    });
    
    // Handle session-related errors
    if (response.status === 400 || response.status === 401 || response.status === 410) {
      const errorData = await response.json().catch(() => ({}));
      const errorMessage = errorData.error || 'Session error';
      
      // Check if it's a session-related error
      if (
        errorMessage.toLowerCase().includes('session') ||
        response.status === 410 // Gone - session expired
      ) {
        console.warn('⚠️ Session error detected, clearing session:', errorMessage);
        
        // Clear session and retry once
        sessionManager.clearSession();
        
        // Get new session ID
        const newSessionId = sessionManager.getSessionId();
        console.log('🔄 Retrying with new session:', newSessionId);
        
        // Retry with new session
        const retryHeaders = {
          ...options.headers,
          'X-Session-ID': newSessionId,
        };
        
        return fetch(url, {
          ...options,
          headers: retryHeaders,
        });
      }
    }
    
    return response;
  } catch (error) {
    console.error('❌ API request failed:', error);
    throw error;
  }
}

/**
 * Convenience method for GET requests
 */
export async function apiGet(endpoint: string): Promise<Response> {
  return apiRequest(endpoint, { method: 'GET' });
}

/**
 * Convenience method for POST requests
 */
export async function apiPost(
  endpoint: string,
  body: any,
  contentType: string = 'application/json'
): Promise<Response> {
  const options: ApiRequestOptions = {
    method: 'POST',
    headers: {
      'Content-Type': contentType,
    },
  };
  
  // Handle different body types
  if (contentType === 'application/json') {
    options.body = JSON.stringify(body);
  } else {
    options.body = body;
  }
  
  return apiRequest(endpoint, options);
}

export default apiRequest;
