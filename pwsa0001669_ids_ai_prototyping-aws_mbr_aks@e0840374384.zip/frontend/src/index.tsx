/*
 * Copyright © Amazon.com and Affiliates: This deliverable is considered 
 * Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025.
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import logo from "./assets/logos/favicon-32x32.png";

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

const link  = document.createElement('link');
link.rel = 'icon';
link.type = 'image/png';
link.href = logo;
document.head.appendChild(link);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
