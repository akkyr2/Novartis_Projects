#!/bin/bash

# MBR Dashboard Cleanup Script
# This script removes all AWS resources to avoid ongoing costs

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
REGION=${AWS_DEFAULT_REGION:-us-east-1}
STACK_NAME="MbrDashboardStack"

echo -e "${YELLOW}🧹 Starting MBR Dashboard cleanup...${NC}"
echo -e "${YELLOW}This will delete ALL AWS resources created by the deployment${NC}"

# Display AWS configuration
echo -e "${BLUE}📋 Cleanup Configuration:${NC}"
echo -e "${BLUE}  Region: ${REGION}${NC}"
echo -e "${BLUE}  Stack: ${STACK_NAME}${NC}"

# Check AWS configuration and display profile info
CALLER_IDENTITY=$(aws sts get-caller-identity 2>/dev/null)
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ AWS CLI not configured or no valid credentials found${NC}"
    echo -e "${YELLOW}Please run 'aws configure' or set up your AWS credentials${NC}"
    exit 1
fi

# Extract account ID and user info
AWS_ACCOUNT_ID=$(echo $CALLER_IDENTITY | jq -r '.Account' 2>/dev/null || echo "unknown")
AWS_USER_ARN=$(echo $CALLER_IDENTITY | jq -r '.Arn' 2>/dev/null || echo "unknown")

echo -e "${BLUE}  Account ID: ${AWS_ACCOUNT_ID}${NC}"
echo -e "${BLUE}  User/Role: ${AWS_USER_ARN}${NC}"

# Display current AWS profile
if [ -n "$AWS_PROFILE" ]; then
    echo -e "${BLUE}  AWS Profile: ${AWS_PROFILE}${NC}"
else
    echo -e "${BLUE}  AWS Profile: default${NC}"
fi
echo ""

# Function to confirm deletion
confirm_deletion() {
    echo -e "${RED}⚠️  WARNING: This will permanently delete all resources!${NC}"
    echo -e "${RED}This action cannot be undone.${NC}"
    read -p "Are you sure you want to continue? (type 'yes' to confirm): " confirmation
    
    if [ "$confirmation" != "yes" ]; then
        echo -e "${BLUE}❌ Cleanup cancelled${NC}"
        exit 0
    fi
}

# Note: No S3 buckets to clean up - frontend served from ECS container

# Function to delete ECR images
delete_ecr_images() {
    echo -e "${YELLOW}🗑️  Deleting ECR images...${NC}"
    
    # Get ECR repository URI
    ECR_URI=$(aws cloudformation describe-stacks \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --query 'Stacks[0].Outputs[?OutputKey==`EcrRepoUri`].OutputValue' \
        --output text 2>/dev/null || echo "")
    
    if [ ! -z "$ECR_URI" ]; then
        REPO_NAME=$(echo $ECR_URI | cut -d'/' -f2)
        echo -e "${YELLOW}Deleting images from repository: ${REPO_NAME}${NC}"
        
        # List and delete all images
        aws ecr list-images \
            --repository-name ${REPO_NAME} \
            --region ${REGION} \
            --query 'imageIds[*]' \
            --output json | \
        aws ecr batch-delete-image \
            --repository-name ${REPO_NAME} \
            --region ${REGION} \
            --image-ids file:///dev/stdin || true
    fi
}

# Function to delete CloudFormation stack
delete_stack() {
    echo -e "${YELLOW}🗑️  Deleting CloudFormation stack...${NC}"
    
    # Check if stack exists
    if aws cloudformation describe-stacks --stack-name ${STACK_NAME} --region ${REGION} > /dev/null 2>&1; then
        echo -e "${YELLOW}Deleting stack: ${STACK_NAME}${NC}"
        aws cloudformation delete-stack --stack-name ${STACK_NAME} --region ${REGION}
        
        echo -e "${YELLOW}Waiting for stack deletion to complete...${NC}"
        aws cloudformation wait stack-delete-complete --stack-name ${STACK_NAME} --region ${REGION}
        
        echo -e "${GREEN}✅ Stack deleted successfully${NC}"
    else
        echo -e "${YELLOW}Stack ${STACK_NAME} not found or already deleted${NC}"
    fi
}

# Function to clean up local Docker images
cleanup_local_docker() {
    echo -e "${YELLOW}🐳 Cleaning up local Docker images...${NC}"
    
    # Remove local Docker images
    docker rmi mbr-dashboard:latest 2>/dev/null || true
    docker rmi $(docker images --filter "reference=*mbr-dashboard*" -q) 2>/dev/null || true
    
    echo -e "${GREEN}✅ Local Docker cleanup completed${NC}"
}

# Function to display cleanup summary
show_cleanup_summary() {
    echo -e "\n${GREEN}🎉 Cleanup completed successfully!${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}📋 Cleanup Summary:${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}✅ ECR images deleted${NC}"
    echo -e "${GREEN}✅ CloudFormation stack deleted${NC}"
    echo -e "${GREEN}✅ Local Docker images cleaned up${NC}"
    echo -e "\n${GREEN}💰 All AWS resources have been removed to avoid ongoing costs${NC}"
}

# Main execution
main() {
    confirm_deletion
    delete_ecr_images
    delete_stack
    cleanup_local_docker
    show_cleanup_summary
}

# Handle script interruption
trap 'echo -e "\n${RED}❌ Cleanup interrupted${NC}"; exit 1' INT TERM

# Run main function
main "$@"