#!/bin/bash

# MBR Dashboard Development Script
# Comprehensive development environment setup and management

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Configuration
PROJECT_ROOT=$(pwd)
FRONTEND_DIR="$PROJECT_ROOT/frontend"
BACKEND_DIR="$PROJECT_ROOT/backend_api"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_header() {
    echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${PURPLE}$1${NC}"
    echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Function to check prerequisites
check_prerequisites() {
    print_header "🔍 Checking Prerequisites"
    
    local missing_deps=0
    
    # Check Python
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        print_success "Python: $PYTHON_VERSION"
    else
        print_error "Python 3 not found"
        missing_deps=1
    fi
    
    # Check Node.js
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        print_success "Node.js: $NODE_VERSION"
    else
        print_error "Node.js not found"
        missing_deps=1
    fi
    
    # Check AWS CLI
    if command -v aws &> /dev/null; then
        if aws sts get-caller-identity >/dev/null 2>&1; then
            AWS_ACCOUNT=$(aws sts get-caller-identity --query 'Account' --output text)
            AWS_REGION=$(aws configure get region 2>/dev/null || echo "us-east-1")
            print_success "AWS CLI: Configured (Account: $AWS_ACCOUNT, Region: $AWS_REGION)"
        else
            print_warning "AWS CLI installed but not configured"
        fi
    else
        print_error "AWS CLI not found"
        missing_deps=1
    fi
    
    if [ $missing_deps -eq 1 ]; then
        print_error "Missing prerequisites. Please install them first."
        exit 1
    fi
}

# Function to setup environment
setup_environment() {
    print_header "⚙️  Setting Up Environment"
    
    # Create .env if it doesn't exist
    if [ ! -f ".env" ]; then
        print_status "Creating .env file from template..."
        cp .env.example .env
        print_success "Created .env file"
        print_warning "Please review and customize .env file for your setup"
    else
        print_success ".env file already exists"
    fi
    
    # Create necessary directories
    print_status "Creating project directories..."
    mkdir -p uploads/slides
    mkdir -p data_sample/slide_images
    print_success "Project directories created"
    
    # Install Python dependencies
    print_status "Installing Python dependencies..."
    pip install -r requirements.txt
    print_success "Python dependencies installed"
    
    # Install Node.js dependencies
    print_status "Installing Node.js dependencies..."
    cd "$FRONTEND_DIR"
    npm install
    cd "$PROJECT_ROOT"
    print_success "Node.js dependencies installed"
}

# Function to build frontend
build_frontend() {
    print_header "🎨 Building Frontend"
    
    print_status "Building React application..."
    cd "$FRONTEND_DIR"
    npm run build
    cd "$PROJECT_ROOT"
    
    print_status "Copying build to backend..."
    rm -rf "$BACKEND_DIR/frontend"
    cp -r "$FRONTEND_DIR/build" "$BACKEND_DIR/frontend"
    
    print_success "Frontend built and deployed to backend"
}

# Function to start development server (production-like, single port)
start_dev_server() {
    print_header "🚀 Starting Development Server (Production Mode)"
    
    # Kill any existing process on port 5000
    print_status "Checking for existing processes on port 5000..."
    if lsof -ti:5000 >/dev/null 2>&1; then
        print_warning "Killing existing process on port 5000..."
        lsof -ti:5000 | xargs kill -9 2>/dev/null || true
        sleep 2
    fi
    
    # Set environment variables for local development
    export ENVIRONMENT=local
    export DEBUG=true
    export AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION:-us-east-1}
    
    print_status "Starting Flask server..."
    print_success "Server will be available at: http://localhost:5000"
    print_success "API endpoints at: http://localhost:5000/api"
    print_success "Health check: http://localhost:5000/api/health"
    print_success "Logo test: http://localhost:5000/logos/novartis.png"
    
    echo -e "\n${YELLOW}📝 Development Notes:${NC}"
    echo -e "• Upload directory: $PROJECT_ROOT/uploads"
    echo -e "• Logs appear in this terminal"
    echo -e "• Press Ctrl+C to stop the server"
    echo -e "• Run './dev.sh build' to rebuild frontend"
    echo -e "• Run './dev.sh dev' for separate frontend/backend (recommended)"
    echo -e "• Run './dev.sh deploy' to deploy to AWS"
    
    echo -e "\n${BLUE}🔄 Starting server...${NC}"
    
    cd "$BACKEND_DIR"
    python app.py
}

# Function to start development mode (separate ports)
start_dev_mode() {
    print_header "🚀 Starting Development Mode (Separate Ports)"
    
    # Kill any existing processes
    print_status "Checking for existing processes..."
    if lsof -ti:5000 >/dev/null 2>&1; then
        print_warning "Killing existing process on port 5000..."
        lsof -ti:5000 | xargs kill -9 2>/dev/null || true
    fi
    if lsof -ti:3000 >/dev/null 2>&1; then
        print_warning "Killing existing process on port 3000..."
        lsof -ti:3000 | xargs kill -9 2>/dev/null || true
    fi
    sleep 2
    
    # Set environment variables
    export ENVIRONMENT=local
    export DEBUG=true
    export AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION:-us-east-1}
    
    print_success "Backend will run on: http://localhost:5000"
    print_success "Frontend will run on: http://localhost:3000"
    print_success "API endpoints at: http://localhost:5000/api"
    
    echo -e "\n${YELLOW}📝 Development Notes:${NC}"
    echo -e "• Frontend: http://localhost:3000 (with hot reload)"
    echo -e "• Backend: http://localhost:5000 (API only)"
    echo -e "• Microphone works better in this mode"
    echo -e "• Press Ctrl+C to stop both servers"
    
    echo -e "\n${BLUE}🔄 Starting backend...${NC}"
    cd "$BACKEND_DIR"
    python app.py > "$PROJECT_ROOT/backend.log" 2>&1 &
    BACKEND_PID=$!
    
    sleep 3
    
    echo -e "${BLUE}🔄 Starting frontend...${NC}"
    cd "$FRONTEND_DIR"
    BROWSER=none npm start &
    FRONTEND_PID=$!
    
    echo -e "\n${GREEN}✅ Both servers started!${NC}"
    echo -e "${YELLOW}Backend PID: $BACKEND_PID${NC}"
    echo -e "${YELLOW}Frontend PID: $FRONTEND_PID${NC}"
    echo -e "\n${BLUE}Opening browser in 5 seconds...${NC}"
    sleep 5
    
    # Try to open browser
    if command -v open >/dev/null 2>&1; then
        open http://localhost:3000
    elif command -v xdg-open >/dev/null 2>&1; then
        xdg-open http://localhost:3000
    fi
    
    # Wait for both processes
    wait $BACKEND_PID $FRONTEND_PID
}

# Function to run tests
run_tests() {
    print_header "🧪 Running Tests"
    
    print_status "Testing backend health..."
    if curl -s http://localhost:5000/api/health >/dev/null 2>&1; then
        print_success "Backend is running and healthy"
    else
        print_error "Backend is not running. Start it with './dev.sh start'"
        return 1
    fi
    
    print_status "Testing frontend assets..."
    if curl -s http://localhost:5000/logos/novartis.png >/dev/null 2>&1; then
        print_success "Frontend assets are accessible"
    else
        print_error "Frontend assets not accessible"
        return 1
    fi
    
    print_status "Testing AWS connectivity..."
    if aws sts get-caller-identity >/dev/null 2>&1; then
        print_success "AWS credentials are valid"
    else
        print_warning "AWS credentials not configured"
    fi
    
    print_success "All tests passed!"
}

# Function to deploy to AWS
deploy_to_aws() {
    print_header "☁️  Deploying to AWS"
    
    print_status "Running AWS deployment script..."
    ./deploy.sh
}

# Function to clean up
cleanup() {
    print_header "🧹 Cleaning Up"
    
    print_status "Cleaning build artifacts..."
    rm -rf "$FRONTEND_DIR/build"
    rm -rf "$BACKEND_DIR/frontend"
    rm -rf "$BACKEND_DIR/__pycache__"
    
    print_status "Cleaning uploads..."
    rm -rf uploads/slides/*
    
    print_success "Cleanup completed"
}

# Function to show logs
show_logs() {
    print_header "📋 Application Logs"
    
    if [ -f "app.log" ]; then
        tail -f app.log
    else
        print_warning "No log file found. Logs appear in terminal when running './dev.sh start'"
    fi
}

# Function to load DynamoDB data
load_data() {
    print_header "📊 Loading DynamoDB Data"
    
    # Check if data loading script exists
    if [ ! -f "scripts/load_dynamodb_data.py" ]; then
        print_error "Data loading script not found: scripts/load_dynamodb_data.py"
        return 1
    fi
    
    # Check if data directory exists
    if [ ! -d "data_sample/Real_data" ]; then
        print_error "Data directory not found: data_sample/Real_data"
        print_warning "Please ensure you have the Novartis data files in data_sample/Real_data/"
        return 1
    fi
    
    print_status "Installing required Python packages..."
    pip install pandas boto3 >/dev/null 2>&1
    
    print_status "Loading data into DynamoDB..."
    python scripts/load_dynamodb_data.py \
        --region ${AWS_DEFAULT_REGION:-us-east-1} \
        --data-dir data_sample/Real_data \
        --tables all
    
    if [ $? -eq 0 ]; then
        print_success "DynamoDB data loaded successfully"
        print_success "Tables: novartis-sales-finance, novartis-market-share, novartis-doses, novartis-calls"
    else
        print_error "Data loading failed"
        return 1
    fi
}

# Function to show help
show_help() {
    echo -e "${PURPLE}MBR Dashboard Development Script${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "${YELLOW}Usage:${NC} ./dev.sh [command]"
    echo ""
    echo -e "${YELLOW}Commands:${NC}"
    echo -e "  ${GREEN}setup${NC}     - Install dependencies and setup environment"
    echo -e "  ${GREEN}dev${NC}       - Start in development mode (ports 3000 & 5000) - RECOMMENDED"
    echo -e "  ${GREEN}build${NC}     - Build frontend and copy to backend"
    echo -e "  ${GREEN}start${NC}     - Start production mode (port 5000 only)"
    echo -e "  ${GREEN}test${NC}      - Run health checks and tests"
    echo -e "  ${GREEN}data${NC}      - Load DynamoDB data from CSV files"
    echo -e "  ${GREEN}deploy${NC}    - Deploy to AWS"
    echo -e "  ${GREEN}clean${NC}     - Clean build artifacts and uploads"
    echo -e "  ${GREEN}logs${NC}      - Show application logs"
    echo -e "  ${GREEN}help${NC}      - Show this help message"
    echo ""
    echo -e "${YELLOW}Examples:${NC}"
    echo -e "  ./dev.sh setup    # First time setup"
    echo -e "  ./dev.sh data     # Load DynamoDB data"
    echo -e "  ./dev.sh dev      # Start development mode (RECOMMENDED)"
    echo -e "  ./dev.sh start    # Start production mode"
    echo -e "  ./dev.sh build    # Rebuild frontend"
    echo -e "  ./dev.sh deploy   # Deploy to AWS"
    echo ""
    echo -e "${YELLOW}Quick Start:${NC}"
    echo -e "  1. ./dev.sh setup"
    echo -e "  2. ./dev.sh data"
    echo -e "  3. ./dev.sh dev      # Opens http://localhost:3000"
    echo ""
    echo -e "${YELLOW}Development vs Production Mode:${NC}"
    echo -e "  ${GREEN}dev${NC}   - Frontend (3000) + Backend (5000) - Hot reload, better debugging"
    echo -e "  ${GREEN}start${NC} - Single port (5000) - Production-like testing"
}

# Main script logic
main() {
    local command=${1:-start}
    
    case $command in
        "setup")
            check_prerequisites
            setup_environment
            build_frontend
            print_success "Setup completed! Run './dev.sh dev' to start in development mode."
            ;;
        "dev")
            check_prerequisites
            start_dev_mode
            ;;
        "build")
            build_frontend
            print_success "Frontend rebuilt! Restart the server to see changes."
            ;;
        "start")
            check_prerequisites
            if [ ! -d "$BACKEND_DIR/frontend" ]; then
                print_warning "Frontend not built. Building now..."
                build_frontend
            fi
            start_dev_server
            ;;
        "test")
            run_tests
            ;;
        "data")
            load_data
            ;;
        "deploy")
            deploy_to_aws
            ;;
        "clean")
            cleanup
            ;;
        "logs")
            show_logs
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            print_error "Unknown command: $command"
            show_help
            exit 1
            ;;
    esac
}

# Handle script interruption
trap 'echo -e "\n${YELLOW}🛑 Development server stopped${NC}"; exit 0' INT TERM

# Run main function
main "$@"