#!/bin/bash
# Preprocess all slides to extract structured data

echo "=================================="
echo "Slide Preprocessing Script"
echo "=================================="
echo ""

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    echo "Activating virtual environment..."
    source venv/bin/activate
fi

# Run preprocessing
echo "Starting slide preprocessing..."
python3 backend_api/slide_preprocessor.py \
    --slides-dir data_sample/slide_images \
    --output data_sample/preprocessed_slides.json

echo ""
echo "=================================="
echo "Preprocessing complete!"
echo "=================================="
echo ""
echo "Next steps:"
echo "1. Restart the backend API"
echo "2. Test with a question - it should be much faster!"
echo ""
