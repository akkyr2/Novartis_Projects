#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025

UNIFIED DATA GENERATOR
Generates all 5 CSV files required for the Novartis MBR Dashboard:
1. SALES_FINANCE_BPC_corrected.csv
2. FCT_MARKET_PLU_corrected.csv
3. FCT_DOSES_PLU_corrected.csv
4. FCT_CALLS_expanded.csv
5. FCT_ROME_PLU_expanded.csv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import os

# Set seed for reproducibility
np.random.seed(42)
random.seed(42)

print("="*80)
print("NOVARTIS DATA GENERATOR - ALL TABLES")
print("="*80)

# ============================================================================
# 1. SALES_FINANCE_BPC_corrected.csv
# ============================================================================

def generate_sales_finance_data():
    """Generate sales finance data for 2020-2025"""
    print("\n📊 Generating SALES_FINANCE_BPC_corrected.csv...")
    
    products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
    forecast_types = ['Actual', 'Budget', 'OC']
    
    records = []
    
    for year in range(2020, 2026):  # 2020-2025
        for month in range(1, 13):
            dim_date = f'{year}-{month:02d}-01'
            quarter = (month - 1) // 3 + 1
            year_quarter = f'{year}-Q{quarter}'
            
            # Calculate relative indexes
            base_year = 2025
            base_month = 12
            months_diff = (base_year - year) * 12 + (base_month - month)
            month_rel_index = 1000 - months_diff
            year_rel_index = 1000 - (base_year - year)
            
            quarters_diff = (base_year - year) * 4 + (4 - quarter)
            cycle_rel_index = 1000 - quarters_diff
            
            for product in products:
                # Growth factors by product
                if product == 'Pluvicto':
                    base_sales = 50_000_000
                    growth = 1.0 + (year - 2020) * 0.18  # 18% annual growth
                elif product == 'Lutathera':
                    base_sales = 35_000_000
                    growth = 1.0 + (year - 2020) * 0.10  # 10% annual growth
                elif product == 'Xofigo':
                    base_sales = 25_000_000
                    growth = 1.0 - (year - 2020) * 0.06  # 6% annual decline
                else:  # Novacure
                    base_sales = 30_000_000
                    growth = 1.0 + (year - 2020) * 0.14  # 14% annual growth
                
                for forecast_type in forecast_types:
                    # Add variance for different forecast types
                    if forecast_type == 'Actual':
                        variance = random.uniform(0.95, 1.05)
                    elif forecast_type == 'Budget':
                        variance = random.uniform(0.92, 0.98)
                    else:  # OC (Operating Committee)
                        variance = random.uniform(0.97, 1.03)
                    
                    gross_sales = base_sales * growth * variance * random.uniform(0.9, 1.1)
                    revenue_deductions = gross_sales * random.uniform(0.08, 0.12)
                    net_sales = gross_sales - revenue_deductions
                    
                    record = {
                        'PRODUCT': product,
                        'DIM_Brand': product,
                        'DIM_forecast': forecast_type,
                        'dim_date': dim_date,
                        'net_sales': net_sales,
                        'gross_sales': gross_sales,
                        'revenue_deductions': revenue_deductions,
                        'source': 'BPC_SALES',
                        'data_frequency': 'monthly',
                        'month_rel_index': month_rel_index,
                        'year_rel_index': year_rel_index,
                        'cycle_rel_index': cycle_rel_index,
                        'year_quarter': year_quarter,
                        'last_altered': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'month': float(month)
                    }
                    records.append(record)
    
    df = pd.DataFrame(records)
    print(f"   ✅ Generated {len(df)} records")
    return df

# ============================================================================
# 2. FCT_MARKET_PLU_corrected.csv
# ============================================================================

def generate_market_data():
    """Generate market share data for 2020-2028"""
    print("\n📊 Generating FCT_MARKET_PLU_corrected.csv...")
    
    # All brands including competitors
    brands = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure', 'Competitor_A', 'Competitor_B', 'Competitor_C']
    
    records = []
    
    for year in range(2020, 2029):  # 2020-2028
        for month in range(1, 13):
            dim_date = f'{year}-{month:02d}-01'
            quarter = (month - 1) // 3 + 1
            year_quarter = f'{year}-Q{quarter}'
            
            # Calculate relative indexes
            month_rel_index = 1000
            year_rel_index = 1000
            cycle_rel_index = 1000
            
            # Generate market shares that sum to 100%
            total_trx = 10000  # Total market volume
            
            for brand in brands:
                # Market share evolution
                if brand == 'Pluvicto':
                    base_share = 25.0 + (year - 2020) * 2.0  # Growing share
                    trx = int(total_trx * base_share / 100 * random.uniform(0.95, 1.05))
                elif brand == 'Lutathera':
                    base_share = 22.0 + (year - 2020) * 0.5
                    trx = int(total_trx * base_share / 100 * random.uniform(0.95, 1.05))
                elif brand == 'Xofigo':
                    base_share = 18.0 - (year - 2020) * 1.0  # Declining share
                    trx = int(total_trx * base_share / 100 * random.uniform(0.95, 1.05))
                elif brand == 'Novacure':
                    base_share = 15.0 + (year - 2020) * 1.5
                    trx = int(total_trx * base_share / 100 * random.uniform(0.95, 1.05))
                else:  # Competitors
                    base_share = 10.0
                    trx = int(total_trx * base_share / 100 * random.uniform(0.95, 1.05))
                
                trx_share = round(trx / total_trx * 100, 2)
                nbrx = int(trx * 0.15)  # New prescriptions ~15% of total
                nbrx_share = trx_share
                
                # Determine class
                if brand in ['Pluvicto', 'Lutathera', 'Xofigo']:
                    class_name = brand.lower()
                    class_agg = 'RLT'
                else:
                    class_name = 'competitor'
                    class_agg = 'Other'
                
                record = {
                    'PRODUCT': 'Pluvicto',  # Product context
                    'DIM_Brand': brand,
                    'Class': class_name,
                    'class_aggregated': class_agg,
                    'dim_date': dim_date,
                    'TRX_R3M': trx,
                    'TRX_SHARE_R3M': trx_share,
                    'NBRX_R3M': nbrx,
                    'NBRX_SHARE_R3M': nbrx_share,
                    'month_rel_index': month_rel_index,
                    'year_rel_index': year_rel_index,
                    'cycle_rel_index': cycle_rel_index,
                    'year_quarter': year_quarter
                }
                records.append(record)
    
    df = pd.DataFrame(records)
    print(f"   ✅ Generated {len(df)} records")
    return df

# ============================================================================
# 3. FCT_DOSES_PLU_corrected.csv
# ============================================================================

def generate_doses_data():
    """Generate doses data for 2020-2025"""
    print("\n📊 Generating FCT_DOSES_PLU_corrected.csv...")
    
    products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
    metrics = ['TRX_shipped', 'TRX_injected', 'NBRX']
    forecast_types = ['Actual', 'Budget', 'OC']
    
    records = []
    
    for year in range(2020, 2026):  # 2020-2025
        for month in range(1, 13):
            dim_date = f'{year}-{month:02d}-01'
            quarter = (month - 1) // 3 + 1
            
            # Calculate relative indexes
            base_year = 2025
            base_month = 12
            months_diff = (base_year - year) * 12 + (base_month - month)
            month_rel_index = 1000 - months_diff
            year_rel_index = 1000 - (base_year - year)
            
            quarters_diff = (base_year - year) * 4 + (4 - quarter)
            quarter_rel_index = 1000 - quarters_diff
            
            for product in products:
                # Growth factors by product
                if product == 'Pluvicto':
                    base_doses = 250
                    growth = 1.0 + (year - 2020) * 0.20  # 20% annual growth
                elif product == 'Lutathera':
                    base_doses = 200
                    growth = 1.0 + (year - 2020) * 0.10  # 10% annual growth
                elif product == 'Xofigo':
                    base_doses = 150
                    growth = 1.0 - (year - 2020) * 0.08  # 8% annual decline
                else:  # Novacure
                    base_doses = 180
                    growth = 1.0 + (year - 2020) * 0.15  # 15% annual growth
                
                for forecast_type in forecast_types:
                    for metric in metrics:
                        # Metric-specific adjustments
                        if metric == 'TRX_shipped':
                            value = base_doses * growth * random.uniform(0.95, 1.05)
                        elif metric == 'TRX_injected':
                            value = base_doses * growth * 0.92 * random.uniform(0.95, 1.05)  # ~92% of shipped
                        else:  # NBRX
                            value = base_doses * growth * 0.15 * random.uniform(0.95, 1.05)  # ~15% new
                        
                        # Forecast variance
                        if forecast_type == 'Budget':
                            value *= random.uniform(0.95, 0.98)
                        elif forecast_type == 'OC':
                            value *= random.uniform(0.97, 1.02)
                        
                        record = {
                            'PRODUCT': product,
                            'DIM_Brand': product,
                            'dim_date': dim_date,
                            'dim_forecast': forecast_type,
                            'value': round(value, 1),
                            'metric': metric,
                            'month_rel_index': month_rel_index,
                            'year_rel_index': year_rel_index,
                            'quarter_rel_index': quarter_rel_index
                        }
                        records.append(record)
    
    df = pd.DataFrame(records)
    print(f"   ✅ Generated {len(df)} records")
    return df

# ============================================================================
# 4. FCT_CALLS_expanded.csv
# ============================================================================

def generate_calls_data():
    """Generate field calls data for 2020-2025"""
    print("\n📊 Generating FCT_CALLS_expanded.csv...")
    
    products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
    geo_levels = ['Nation', 'Region', 'Territory']
    regions = ['Northeast', 'Southeast', 'Midwest', 'West']
    territories = {
        'Northeast': ['Northeast-T1', 'Northeast-T2', 'Northeast-T3'],
        'Southeast': ['Southeast-T1', 'Southeast-T2', 'Southeast-T3', 'Southeast-T4'],
        'Midwest': ['Midwest-T1', 'Midwest-T2', 'Midwest-T3'],
        'West': ['West-T1', 'West-T2', 'West-T3', 'West-T4']
    }
    metric_types = ['hcp_reach', 'cpd', 'call_frequency_attainment', 'total_calls']
    quarters = ['Q1', 'Q2', 'Q3', 'Q4']
    
    records = []
    
    for year in range(2020, 2026):  # 2020-2025
        for quarter in quarters:
            quarter_name = f'{year}-{quarter}'
            quarter_num = quarters.index(quarter) + 1
            
            # Quarter end dates
            quarter_ends = {'Q1': f'{year}-03-01', 'Q2': f'{year}-05-30', 
                          'Q3': f'{year}-08-28', 'Q4': f'{year}-11-30'}
            call_date = quarter_ends[quarter]
            
            # Calculate cycle_rel_index
            base_year = 2025
            base_quarter = 4
            quarters_diff = (base_year - year) * 4 + (base_quarter - quarter_num)
            cycle_rel_index = 1000 - quarters_diff
            
            # Period dates
            if quarter_num == 1:
                period_start, period_end = f'{year}-01-01', f'{year}-03-31'
                total_weeks, working_days = 13, 64
            elif quarter_num == 2:
                period_start, period_end = f'{year}-04-01', f'{year}-06-30'
                total_weeks, working_days = 13, 65
            elif quarter_num == 3:
                period_start, period_end = f'{year}-07-01', f'{year}-09-30'
                total_weeks, working_days = 13, 66
            else:
                period_start, period_end = f'{year}-10-01', f'{year}-12-31'
                total_weeks, working_days = 13, 65
            
            for product in products:
                # Growth factors
                if product == 'Pluvicto':
                    base_growth = 1.0 + (year - 2020) * 0.15
                elif product == 'Lutathera':
                    base_growth = 1.0 + (year - 2020) * 0.08
                elif product == 'Xofigo':
                    base_growth = 1.0 - (year - 2020) * 0.05
                else:
                    base_growth = 1.0 + (year - 2020) * 0.12
                
                # Nation level
                for metric_type in metric_types:
                    records.append(create_call_record(
                        product, 'Nation', 'United States', quarter_name, metric_type,
                        call_date, cycle_rel_index, period_start, period_end,
                        total_weeks, working_days, base_growth
                    ))
                
                # Region level
                for region in regions:
                    for metric_type in metric_types:
                        records.append(create_call_record(
                            product, 'Region', region, quarter_name, metric_type,
                            call_date, cycle_rel_index, period_start, period_end,
                            total_weeks, working_days, base_growth * 0.25
                        ))
                    
                    # Territory level
                    for territory in territories[region]:
                        for metric_type in metric_types:
                            territory_factor = 0.25 / len(territories[region])
                            records.append(create_call_record(
                                product, 'Territory', territory, quarter_name, metric_type,
                                call_date, cycle_rel_index, period_start, period_end,
                                total_weeks, working_days, base_growth * territory_factor
                            ))
    
    df = pd.DataFrame(records)
    print(f"   ✅ Generated {len(df)} records")
    return df

def create_call_record(product, geo_level, geo_name, quarter_name, metric_type,
                      call_date, cycle_rel_index, period_start, period_end,
                      total_weeks, working_days, growth_factor):
    """Helper to create a single call record"""
    
    target_hcp_reach = int(800 * growth_factor * random.uniform(0.9, 1.1))
    total_target = int(1400 * growth_factor * random.uniform(0.9, 1.1))
    percent_reached = round(target_hcp_reach / total_target * 100, 1)
    hcp_not_reached = total_target - target_hcp_reach
    cpd = round(8.5 * growth_factor * random.uniform(0.9, 1.1), 2)
    cpd_goal = 8.0
    cpd_attainment = round(cpd / cpd_goal * 100, 2)
    call_frequency_actual = round(3.5 * growth_factor * random.uniform(0.9, 1.1), 1)
    call_frequency_attainment = round(call_frequency_actual / 3.8 * 100, 1)
    actual_calls = int(7500 * growth_factor * random.uniform(0.9, 1.1))
    planned_calls = int(6700 * growth_factor * random.uniform(0.9, 1.1))
    
    return {
        'product': product,
        'source': 'FIELD_CEE_KPI_2WK_LAG',
        'dim_tier': 'Tier 1',
        'dim_brand': product,
        'dim_time_period': quarter_name,
        'dim_metric_type': metric_type,
        'dim_geo_level': geo_level,
        'dim_geo_name': geo_name,
        'dim_ic_cycle': quarter_name,
        'CPD': cpd,
        'cpd_goal': cpd_goal,
        'cpd_attainment': cpd_attainment,
        'target_hcp_reach': target_hcp_reach,
        'total_target': total_target,
        'percent_reached': percent_reached,
        'hcp_not_reached': hcp_not_reached,
        'call_frequency_actual': call_frequency_actual,
        'call_frequency_attainment': call_frequency_attainment,
        'actual_calls': actual_calls,
        'week_month_num': '',
        'geo_id': f'{geo_level[:3].upper()}_{geo_name.replace(" ", "_").upper()}',
        'therapeutic_area': 'Oncology',
        'sub_therapeutic_area': 'RLT',
        'zero_call_day': random.randint(2, 6),
        'planned_calls': planned_calls,
        'year_quarter': quarter_name,
        'dim_date': call_date,
        'cycle_rel_index': cycle_rel_index,
        'call_date': call_date,
        'period_start_date': period_start,
        'period_end_date': period_end,
        'total_week_mth': total_weeks,
        'working_day': working_days,
        'prorated_planned_calls': int(planned_calls * 0.95),
        'prorated_call_frequency_goal': round(3.8 * 0.95, 1),
        'prorated_hcp_reach_goal': int(total_target * 0.8),
        'reporting_week_date': call_date,
        'incentive_start_date': period_start,
        'last_altered': datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    }

# ============================================================================
# 5. FCT_ROME_PLU_expanded.csv
# ============================================================================

def generate_rome_data():
    """Generate Rome order data for 2020-2025"""
    print("\n📊 Generating FCT_ROME_PLU_expanded.csv...")
    
    products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
    regions = ['Northeast', 'Southeast', 'Midwest', 'West']
    order_statuses = ['Open', 'Shipped', 'Delivered', 'Cancelled']
    order_types = ['Commercial', 'Compassionate']
    site_types = ['Academic', 'Community', 'Hospital']
    tiers = ['T1', 'T2', 'T3']
    
    # Generate sites
    sites = []
    site_id = 1
    for region in regions:
        for i in range(3):  # 3 sites per region = 12 total
            sites.append({
                'site_id': f'SITE{site_id:03d}',
                'customer_name': f'{region} Medical Center {i+1}',
                'region': region,
                'area': f'{region[:3].upper()}_A{(i % 2) + 1}',
                'territory': f'TERR_{region[:2].upper()}_{i+1:02d}',
                'site_type': random.choice(site_types),
                'tier': random.choice(tiers),
                'system_name': f'{region} Health System'
            })
            site_id += 1
    
    records = []
    patient_id = 1
    order_id = 1
    treatment_id = 1
    
    for year in range(2020, 2026):  # 2020-2025
        for month in range(1, 13):
            # Last day of month
            if month == 12:
                month_end = datetime(year + 1, 1, 1) - timedelta(days=1)
            else:
                month_end = datetime(year, month + 1, 1) - timedelta(days=1)
            
            dim_date = month_end.strftime('%Y-%m-%d')
            quarter = (month - 1) // 3 + 1
            year_quarter = f'{year}-Q{quarter}'
            
            # Calculate relative indexes
            base_year = 2025
            base_month = 12
            months_diff = (base_year - year) * 12 + (base_month - month)
            month_rel_index = 1000 - months_diff
            year_rel_index = 1000 - (base_year - year)
            
            quarters_diff = (base_year - year) * 4 + (4 - quarter)
            cycle_rel_index = 1000 - quarters_diff
            
            for product in products:
                # Growth factors
                if product == 'Pluvicto':
                    base_orders = 15
                    growth = 1.0 + (year - 2020) * 0.20
                elif product == 'Lutathera':
                    base_orders = 12
                    growth = 1.0 + (year - 2020) * 0.10
                elif product == 'Xofigo':
                    base_orders = 8
                    growth = 1.0 - (year - 2020) * 0.08
                else:
                    base_orders = 10
                    growth = 1.0 + (year - 2020) * 0.15
                
                orders_this_month = int(base_orders * growth * random.uniform(0.8, 1.2))
                selected_sites = random.sample(sites, min(orders_this_month, len(sites)))
                
                for site in selected_sites:
                    is_first_dose = random.random() < 0.3
                    dose_number = 1 if is_first_dose else random.randint(2, 6)
                    
                    status_weights = [0.15, 0.25, 0.55, 0.05]
                    order_status = random.choices(order_statuses, weights=status_weights)[0]
                    active_dormant = 'Active' if order_status in ['Open', 'Shipped', 'Delivered'] else 'Dormant'
                    
                    record = {
                        'PRODUCT': product,
                        'DIM_Brand': product,
                        'dim_date': dim_date,
                        'dim_customer_name': site['customer_name'],
                        'dim_order_status': order_status,
                        'dim_order_type': random.choice(order_types),
                        'dim_order_group': 'Vial',
                        'dim_ecosystem': random.choice(['Integrated', 'Independent', 'Limited']),
                        'dim_account_status': random.choice(['Onboarded', 'Pending', 'Active']),
                        'dim_site_type': site['site_type'],
                        'dim_terr_name': site['territory'],
                        'dim_area_name': site['area'],
                        'dim_region_name': site['region'],
                        'dim_tier': site['tier'],
                        'dim_system_name': site['system_name'],
                        'month_rel_index': month_rel_index,
                        'year_rel_index': year_rel_index,
                        'cycle_rel_index': cycle_rel_index,
                        'year_quarter': year_quarter,
                        'sales_order_number': f'SO-{year}-{order_id:05d}',
                        'treatment_id': f'TRT-{treatment_id:05d}',
                        'insurance_provider': random.choice(['UnitedHealthcare', 'Aetna', 'Cigna', 'BCBS', 'Medicare']),
                        'patient_reference_number': f'PAT-{patient_id:05d}',
                        'cancellation_date': dim_date if order_status == 'Cancelled' else '',
                        'cancellation_unused_dose_reason': 'Patient discontinued' if order_status == 'Cancelled' else '',
                        'cancellation_unused_dose_other_reason': '',
                        'referring_physician': f'Dr. {random.choice(["Smith", "Johnson", "Williams", "Brown", "Jones"])}',
                        'ordering_physician': f'Dr. {random.choice(["Davis", "Miller", "Wilson", "Moore", "Taylor"])}',
                        'site_id': site['site_id'],
                        'active_dormant_flag': active_dormant,
                        'dose_number': dose_number,
                        'is_patients_first_dose': 'Yes' if is_first_dose else 'No',
                        'order_status_customer': 'Confirmed' if order_status != 'Cancelled' else 'Cancelled',
                        'delivery_address': '[REDACTED - PII]',
                        'delivery_address_city': site['region'],
                        'delivery_address_zip': str(random.randint(10000, 99999)),
                        'state': random.choice(['NY', 'CA', 'TX', 'FL', 'IL', 'PA', 'OH', 'GA', 'NC', 'MI']),
                        'country': 'USA',
                        'terr_id': site['territory'],
                        'area_id': site['area'],
                        'region_id': site['region']
                    }
                    
                    records.append(record)
                    order_id += 1
                    
                    if is_first_dose:
                        patient_id += 1
                        treatment_id += 1
    
    df = pd.DataFrame(records)
    print(f"   ✅ Generated {len(df)} records")
    return df

# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == '__main__':
    # Generate all datasets
    df_sales = generate_sales_finance_data()
    df_market = generate_market_data()
    df_doses = generate_doses_data()
    df_calls = generate_calls_data()
    df_rome = generate_rome_data()
    
    # Create timestamped output directory
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_dir = f'data/data_samples_{timestamp}'
    os.makedirs(output_dir, exist_ok=True)
    
    print("\n" + "="*80)
    print(f"💾 SAVING FILES TO {output_dir}")
    print("="*80)
    
    files = [
        (df_sales, 'SALES_FINANCE_BPC_corrected.csv'),
        (df_market, 'FCT_MARKET_PLU_corrected.csv'),
        (df_doses, 'FCT_DOSES_PLU_corrected.csv'),
        (df_calls, 'FCT_CALLS_expanded.csv'),
        (df_rome, 'FCT_ROME_PLU_expanded.csv')
    ]
    
    for df, filename in files:
        filepath = os.path.join(output_dir, filename)
        df.to_csv(filepath, index=False)
        print(f"   ✅ {filename} ({len(df):,} rows, {len(df.columns)} columns)")
    
    print("\n" + "="*80)
    print("✅ ALL FILES GENERATED SUCCESSFULLY!")
    print("="*80)
    print("\n📋 Summary:")
    print(f"   1. SALES_FINANCE_BPC_corrected.csv : {len(df_sales):,} rows")
    print(f"   2. FCT_MARKET_PLU_corrected.csv    : {len(df_market):,} rows")
    print(f"   3. FCT_DOSES_PLU_corrected.csv     : {len(df_doses):,} rows")
    print(f"   4. FCT_CALLS_expanded.csv          : {len(df_calls):,} rows")
    print(f"   5. FCT_ROME_PLU_expanded.csv       : {len(df_rome):,} rows")
    print(f"\n📍 Files saved in: {output_dir}")
    print("="*80)
