"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Generate Novartis MBR Presentation Slides
Creates a professional 10-slide PDF presentation with charts and data
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('default')
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
plt.rcParams['axes.facecolor'] = 'white'
plt.rcParams['figure.facecolor'] = 'white'
plt.rcParams['axes.edgecolor'] = '#E5E7EB'
plt.rcParams['axes.linewidth'] = 1
plt.rcParams['grid.color'] = '#E5E7EB'
plt.rcParams['grid.linewidth'] = 0.5

# Color palette
COLORS = {
    'pluvicto': '#7B2CBF',      # Purple
    'lutathera': '#06AED5',     # Teal
    'xofigo': '#10B981',        # Green
    'novacure': '#F59E0B',      # Orange
    'competitor': '#9CA3AF',    # Gray
    'actual': '#1E40AF',        # Blue
    'budget': '#6B7280',        # Gray
    'forecast': '#F59E0B',      # Orange
    'positive': '#22C55E',      # Green
    'negative': '#EF4444',      # Red
}

def load_data():
    """Load all CSV data files"""
    print("Loading data files...")
    
    sales = pd.read_csv('data_sample/Real_data/SALES_FINANCE_BPC_corrected.csv')
    market = pd.read_csv('data_sample/Real_data/FCT_MARKET_PLU_corrected.csv')
    doses = pd.read_csv('data_sample/Real_data/FCT_DOSES_PLU_corrected.csv')
    
    # Convert dates
    sales['dim_date'] = pd.to_datetime(sales['dim_date'])
    market['dim_date'] = pd.to_datetime(market['dim_date'])
    doses['dim_date'] = pd.to_datetime(doses['dim_date'])
    
    print(f"✅ Loaded: {len(sales)} sales records, {len(market)} market records, {len(doses)} dose records")
    
    return sales, market, doses

def add_slide_header(fig, title, subtitle, slide_num):
    """Add consistent header to each slide"""
    fig.text(0.05, 0.95, title, fontsize=24, weight='bold', color='#1F2937')
    fig.text(0.05, 0.92, subtitle, fontsize=14, color='#6B7280')
    fig.text(0.95, 0.95, f'Slide {slide_num}', fontsize=10, color='#9CA3AF', ha='right')
    fig.text(0.95, 0.02, 'Novartis Confidential', fontsize=8, color='#D1D5DB', ha='right')

def format_xaxis_labels(ax, max_labels=6):
    """Format x-axis labels intelligently based on number of ticks"""
    num_ticks = len(ax.get_xticklabels())
    
    if num_ticks > max_labels:
        # Rotate labels if too many
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right', fontsize=9)
    else:
        # Keep horizontal if few enough
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=0, ha='center', fontsize=9)

def slide_1_executive_summary(pdf, sales, market, doses):
    """Slide 1: Executive Summary - Portfolio Performance"""
    print("Generating Slide 1: Executive Summary...")
    
    fig = plt.figure(figsize=(16, 9))
    add_slide_header(fig, 
                    "Novartis RLT Portfolio - December 2025 Performance",
                    "Sales, Market Position & Volume Metrics",
                    1)
    
    # Calculate key metrics for 2025 YTD only
    sales_2025 = sales[sales['dim_date'].dt.year == 2025]
    ytd_sales = sales_2025[sales_2025['DIM_forecast'] == 'Actual']['net_sales'].sum()
    ytd_budget = sales_2025[sales_2025['DIM_forecast'] == 'Budget']['net_sales'].sum()
    variance_pct = ((ytd_sales - ytd_budget) / ytd_budget * 100) if ytd_budget > 0 else 0
    
    doses_2025 = doses[doses['dim_date'].dt.year == 2025]
    total_doses = doses_2025[doses_2025['dim_forecast'] == 'Actual']['value'].sum()
    
    market_2025 = market[market['dim_date'].dt.year == 2025]
    market_share = market_2025[market_2025['DIM_Brand'] == 'Pluvicto']['TRX_SHARE_R3M'].mean()
    
    # Text metrics at top
    metrics_text = f"""
    Current Month: December 2025  |  YTD Net Sales: ${ytd_sales/1e6:.1f}M (vs Budget: {variance_pct:+.1f}%)  |  Market Share: {market_share:.1f}%  |  Total Doses Shipped: {int(total_doses):,}
    """
    fig.text(0.5, 0.87, metrics_text, fontsize=11, ha='center', 
             bbox=dict(boxstyle='round', facecolor='#F3F4F6', alpha=0.8))
    
    # Create 4-panel dashboard
    gs = fig.add_gridspec(2, 2, left=0.08, right=0.95, top=0.82, bottom=0.08, 
                          hspace=0.3, wspace=0.25)
    
    # Panel 1: Net Sales Trend
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    
    sales_monthly = sales.groupby(['dim_date', 'DIM_forecast'])['net_sales'].sum().reset_index()
    for forecast_type in ['Actual', 'Budget']:
        data = sales_monthly[sales_monthly['DIM_forecast'] == forecast_type]
        style = '-' if forecast_type == 'Actual' else '--'
        color = COLORS['actual'] if forecast_type == 'Actual' else COLORS['budget']
        ax1.plot(data['dim_date'], data['net_sales']/1e6, style, 
                label=forecast_type, linewidth=2.5, color=color, marker='o', markersize=3)
    ax1.set_title('Net Sales Trend', fontsize=13, weight='bold', pad=12, color='#1F2937')
    ax1.set_ylabel('Net Sales ($M)', fontsize=11, color='#374151')
    ax1.legend(fontsize=10, frameon=False, loc='upper left')
    ax1.grid(True, alpha=0.2, linestyle='-', linewidth=0.5)
    ax1.tick_params(labelsize=9, colors='#6B7280')
    # Reduce number of x-axis labels
    ax1.xaxis.set_major_locator(plt.MaxNLocator(6))
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=0, ha='center')
    
    # Panel 2: Market Share Evolution (Stacked Area)
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    
    # Pivot market data for stacked area chart
    market_pivot = market.pivot_table(
        index='dim_date', 
        columns='DIM_Brand', 
        values='TRX_SHARE_R3M', 
        aggfunc='first'
    ).fillna(0)
    
    # Select main brands and competitors
    brands_order = ['Pluvicto', 'Lutathera', 'Xofigo', 'Competitor_A', 'Competitor_B']
    available_brands = [b for b in brands_order if b in market_pivot.columns]
    
    colors_list = [
        COLORS['pluvicto'],   # Pluvicto
        COLORS['lutathera'],  # Lutathera
        COLORS['xofigo'],     # Xofigo
        '#D1D5DB',            # Competitor A
        '#E5E7EB'             # Competitor B
    ]
    
    # Create stacked area chart
    ax2.stackplot(market_pivot.index, 
                 [market_pivot[brand] for brand in available_brands],
                 labels=available_brands,
                 colors=colors_list[:len(available_brands)],
                 alpha=0.8)
    
    ax2.set_title('Market Share Evolution', fontsize=13, weight='bold', pad=12, color='#1F2937')
    ax2.set_ylabel('Market Share (%)', fontsize=11, color='#374151')
    ax2.set_ylim(0, 100)
    ax2.legend(fontsize=9, frameon=False, loc='upper left', ncol=2)
    ax2.grid(True, alpha=0.2, linestyle='-', linewidth=0.5, axis='y')
    ax2.tick_params(labelsize=9, colors='#6B7280')
    format_xaxis_labels(ax2, max_labels=6)
    
    # Panel 3: YTD Sales by Product
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.spines['top'].set_visible(False)
    ax3.spines['right'].set_visible(False)
    
    # Filter for 2025 YTD only
    current_year = 2025
    product_sales = sales[(sales['DIM_forecast'].isin(['Actual', 'Budget'])) & 
                         (sales['dim_date'].dt.year == current_year)].groupby(
        ['DIM_Brand', 'DIM_forecast'])['net_sales'].sum().reset_index()
    
    products = product_sales['DIM_Brand'].unique()
    x = np.arange(len(products))
    width = 0.35
    
    actual_vals = [product_sales[(product_sales['DIM_Brand']==p) & 
                                 (product_sales['DIM_forecast']=='Actual')]['net_sales'].sum()/1e6 
                   for p in products]
    budget_vals = [product_sales[(product_sales['DIM_Brand']==p) & 
                                 (product_sales['DIM_forecast']=='Budget')]['net_sales'].sum()/1e6 
                   for p in products]
    
    ax3.barh(x - width/2, actual_vals, width, label='Actual', color=COLORS['actual'], edgecolor='none')
    ax3.barh(x + width/2, budget_vals, width, label='Budget', color=COLORS['budget'], alpha=0.6, edgecolor='none')
    ax3.set_yticks(x)
    ax3.set_yticklabels(products, fontsize=10, color='#374151')
    ax3.set_xlabel('Net Sales ($M)', fontsize=11, color='#374151')
    ax3.set_title('YTD Sales by Product', fontsize=13, weight='bold', pad=12, color='#1F2937')
    ax3.legend(fontsize=10, frameon=False, loc='lower right')
    ax3.grid(True, alpha=0.2, axis='x', linestyle='-', linewidth=0.5)
    ax3.tick_params(axis='x', labelsize=9, colors='#6B7280')
    
    # Panel 4: Dose Shipments vs Injections
    ax4 = fig.add_subplot(gs[1, 1])
    ax4.spines['top'].set_visible(False)
    ax4.spines['right'].set_visible(False)
    
    doses_quarterly = doses[doses['dim_forecast'] == 'Actual'].copy()
    doses_quarterly['quarter'] = doses_quarterly['dim_date'].dt.to_period('Q')
    
    dose_metrics = doses_quarterly.groupby(['quarter', 'metric'])['value'].sum().reset_index()
    quarters = dose_metrics['quarter'].unique()
    
    shipped = [dose_metrics[(dose_metrics['quarter']==q) & 
                           (dose_metrics['metric']=='TRX_shipped')]['value'].sum() 
              for q in quarters]
    injected = [dose_metrics[(dose_metrics['quarter']==q) & 
                            (dose_metrics['metric']=='TRX_injected')]['value'].sum() 
               for q in quarters]
    
    x = np.arange(len(quarters))
    width = 0.35
    ax4.bar(x - width/2, shipped, width, label='Shipped', color='#1E3A8A', edgecolor='none')
    ax4.bar(x + width/2, injected, width, label='Injected', color='#60A5FA', edgecolor='none')
    ax4.set_xticks(x)
    ax4.set_xticklabels([str(q) for q in quarters], fontsize=9, color='#6B7280')
    format_xaxis_labels(ax4, max_labels=6)
    ax4.set_ylabel('Doses (units)', fontsize=11, color='#374151')
    ax4.set_title('Dose Shipments vs Injections', fontsize=13, weight='bold', pad=12, color='#1F2937')
    ax4.legend(fontsize=10, frameon=False, loc='upper left')
    ax4.grid(True, alpha=0.2, axis='y', linestyle='-', linewidth=0.5)
    ax4.tick_params(axis='y', labelsize=9, colors='#6B7280')
    
    plt.tight_layout()
    pdf.savefig(fig, bbox_inches='tight')
    plt.close()
    print("✅ Slide 1 complete")

def slide_2_revenue_performance(pdf, sales):
    """Slide 2: Revenue Performance - Actual vs Budget"""
    print("Generating Slide 2: Revenue Performance...")
    
    fig = plt.figure(figsize=(16, 9))
    add_slide_header(fig,
                    "Net Sales Performance - YTD 2025",
                    "Actual vs Budget by Product",
                    2)
    
    # Calculate metrics
    actual_total = sales[sales['DIM_forecast'] == 'Actual']['net_sales'].sum()
    budget_total = sales[sales['DIM_forecast'] == 'Budget']['net_sales'].sum()
    variance = actual_total - budget_total
    variance_pct = (variance / budget_total * 100) if budget_total > 0 else 0
    
    # Text metrics
    metrics_text = f"Total Net Sales: ${actual_total/1e6:.1f}M  |  Budget: ${budget_total/1e6:.1f}M  |  Variance: ${variance/1e6:+.1f}M ({variance_pct:+.1f}%)"
    fig.text(0.5, 0.87, metrics_text, fontsize=12, ha='center',
             bbox=dict(boxstyle='round', facecolor='#F3F4F6', alpha=0.8))
    
    # Create side-by-side layout
    gs = fig.add_gridspec(1, 2, left=0.08, right=0.95, top=0.80, bottom=0.12, wspace=0.3)
    
    # LEFT: Waterfall chart
    ax = fig.add_subplot(gs[0, 0])
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # Calculate product variances
    product_variance = sales.groupby(['DIM_Brand', 'DIM_forecast'])['net_sales'].sum().reset_index()
    products = sorted(product_variance['DIM_Brand'].unique())
    
    # Simplified waterfall: just show Budget and Actual as bars, with variance annotations
    x_pos = [0, 1]
    bars = ax.bar(x_pos, [budget_total/1e6, actual_total/1e6], 
                  color=[COLORS['budget'], COLORS['actual']], 
                  alpha=0.8, width=0.6, edgecolor='white', linewidth=2)
    
    # Add value labels on bars
    ax.text(0, budget_total/1e6/2, f'${budget_total/1e6:.0f}M\nBudget', 
           ha='center', va='center', fontsize=12, weight='bold', color='white')
    ax.text(1, actual_total/1e6/2, f'${actual_total/1e6:.0f}M\nActual', 
           ha='center', va='center', fontsize=12, weight='bold', color='white')
    
    # Add variance arrow and label
    arrow_y = max(budget_total, actual_total) / 1e6 * 0.85
    ax.annotate('', xy=(1, arrow_y), xytext=(0, arrow_y),
               arrowprops=dict(arrowstyle='->', lw=2, color=COLORS['positive']))
    ax.text(0.5, arrow_y + 200, f'+${variance/1e6:.1f}M\n(+{variance_pct:.1f}%)', 
           ha='center', va='bottom', fontsize=11, weight='bold', 
           color=COLORS['positive'],
           bbox=dict(boxstyle='round', facecolor='white', edgecolor=COLORS['positive'], linewidth=2))
    
    ax.set_xticks([])
    ax.set_ylabel('Net Sales ($M)', fontsize=12, color='#374151', weight='bold')
    ax.set_title('Budget vs Actual', fontsize=14, weight='bold', pad=15, color='#1F2937')
    ax.grid(True, alpha=0.2, axis='y', linestyle='-', linewidth=0.5)
    ax.tick_params(axis='y', labelsize=10, colors='#6B7280')
    ax.set_ylim(0, max(budget_total, actual_total) / 1e6 * 1.1)
    
    # RIGHT: Product breakdown table
    ax_table = fig.add_subplot(gs[0, 1])
    ax_table.axis('off')
    
    table_data = []
    table_data.append(['Product', 'Actual', 'Budget', 'Variance', '%'])
    
    for product in products:
        actual = product_variance[(product_variance['DIM_Brand']==product) & 
                                 (product_variance['DIM_forecast']=='Actual')]['net_sales'].sum()/1e6
        budget = product_variance[(product_variance['DIM_Brand']==product) & 
                                 (product_variance['DIM_forecast']=='Budget')]['net_sales'].sum()/1e6
        var = actual - budget
        var_pct = (var / budget * 100) if budget > 0 else 0
        table_data.append([product, f'${actual:.0f}M', f'${budget:.0f}M', 
                          f'${var:+.0f}M', f'{var_pct:+.1f}%'])
    
    table_data.append(['Total', f'${actual_total/1e6:.0f}M', f'${budget_total/1e6:.0f}M',
                      f'${variance/1e6:+.0f}M', f'{variance_pct:+.1f}%'])
    
    table = ax_table.table(cellText=table_data, cellLoc='center', loc='center',
                          colWidths=[0.22, 0.20, 0.20, 0.20, 0.18])
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1, 2.5)
    
    # Style header row
    for i in range(5):
        table[(0, i)].set_facecolor('#1F2937')
        table[(0, i)].set_text_props(weight='bold', color='white')
    
    # Style data rows
    for i in range(1, len(table_data)-1):
        for j in range(5):
            table[(i, j)].set_facecolor('#FFFFFF')
            if j == 4:  # Percentage column
                pct_val = float(table_data[i][4].replace('%', '').replace('+', ''))
                if pct_val > 0:
                    table[(i, j)].set_text_props(color=COLORS['positive'], weight='bold')
    
    # Style total row
    for i in range(5):
        table[(len(table_data)-1, i)].set_facecolor('#F3F4F6')
        table[(len(table_data)-1, i)].set_text_props(weight='bold', fontsize=12)
        if i == 4:  # Total percentage
            table[(len(table_data)-1, i)].set_text_props(color=COLORS['positive'], weight='bold')
    
    plt.tight_layout()
    pdf.savefig(fig, bbox_inches='tight')
    plt.close()
    print("✅ Slide 2 complete")

def slide_3_pluvicto_deep_dive(pdf, sales, doses):
    """Slide 3: Pluvicto Deep Dive"""
    print("Generating Slide 3: Pluvicto Deep Dive...")
    
    fig = plt.figure(figsize=(16, 9))
    add_slide_header(fig,
                    "Pluvicto Performance Analysis",
                    "Revenue, Volume & Market Dynamics",
                    3)
    
    # Filter Pluvicto data
    pluv_sales = sales[sales['DIM_Brand'] == 'Pluvicto']
    pluv_doses = doses[doses['DIM_Brand'] == 'Pluvicto']
    
    # Calculate metrics
    total_sales = pluv_sales[pluv_sales['DIM_forecast'] == 'Actual']['net_sales'].sum()
    portfolio_pct = (total_sales / sales[sales['DIM_forecast'] == 'Actual']['net_sales'].sum() * 100)
    total_doses = pluv_doses[pluv_doses['dim_forecast'] == 'Actual']['value'].sum()
    
    metrics_text = f"Net Sales: ${total_sales/1e6:.1f}M ({portfolio_pct:.0f}% of portfolio)  |  Total Doses Shipped: {int(total_doses):,}"
    fig.text(0.5, 0.87, metrics_text, fontsize=11, ha='center',
             bbox=dict(boxstyle='round', facecolor='#F3F4F6', alpha=0.8))
    
    # Create 3-panel layout
    gs = fig.add_gridspec(2, 2, left=0.08, right=0.95, top=0.82, bottom=0.08,
                          hspace=0.3, wspace=0.25)
    
    # Panel 1: Monthly Revenue Trend
    ax1 = fig.add_subplot(gs[:, 0])
    monthly_sales = pluv_sales[pluv_sales['DIM_forecast'] == 'Actual'].groupby('dim_date')['net_sales'].sum().reset_index()
    
    ax1_twin = ax1.twinx()
    bars = ax1.bar(monthly_sales['dim_date'], monthly_sales['net_sales']/1e6, 
                   color=COLORS['pluvicto'], alpha=0.7, width=20)
    
    # Calculate YoY growth (simplified)
    growth = [0] * len(monthly_sales)
    ax1_twin.plot(monthly_sales['dim_date'], growth, color=COLORS['forecast'], 
                 linewidth=2, marker='o', markersize=4, label='YoY Growth %')
    
    ax1.set_ylabel('Net Sales ($M)', fontsize=10, color=COLORS['pluvicto'])
    ax1_twin.set_ylabel('YoY Growth (%)', fontsize=10, color=COLORS['forecast'])
    ax1.set_title('Monthly Revenue Trend', fontsize=12, weight='bold', pad=10)
    ax1.grid(True, alpha=0.3, axis='y')
    format_xaxis_labels(ax1, max_labels=6)
    
    # Panel 2: Quarterly Dose Metrics
    ax2 = fig.add_subplot(gs[0, 1])
    pluv_doses_q = pluv_doses[pluv_doses['dim_forecast'] == 'Actual'].copy()
    pluv_doses_q['quarter'] = pluv_doses_q['dim_date'].dt.to_period('Q')
    
    dose_by_metric = pluv_doses_q.groupby(['quarter', 'metric'])['value'].sum().reset_index()
    quarters = dose_by_metric['quarter'].unique()
    
    metrics_list = ['TRX_shipped', 'TRX_injected', 'NBRX']
    x = np.arange(len(quarters))
    width = 0.25
    
    for i, metric in enumerate(metrics_list):
        values = [dose_by_metric[(dose_by_metric['quarter']==q) & 
                                (dose_by_metric['metric']==metric)]['value'].sum() 
                 for q in quarters]
        ax2.bar(x + i*width, values, width, label=metric.replace('TRX_', '').replace('_', ' ').title())
    
    ax2.set_xticks(x + width)
    ax2.set_xticklabels([str(q) for q in quarters], fontsize=9)
    format_xaxis_labels(ax2, max_labels=6)
    ax2.set_ylabel('Doses (units)', fontsize=10)
    ax2.set_title('Quarterly Dose Metrics', fontsize=12, weight='bold', pad=10)
    ax2.legend(fontsize=8)
    ax2.grid(True, alpha=0.3, axis='y')
    
    # Panel 3: Gross to Net Analysis
    ax3 = fig.add_subplot(gs[1, 1])
    quarterly_sales = pluv_sales[pluv_sales['DIM_forecast'] == 'Actual'].copy()
    quarterly_sales['quarter'] = quarterly_sales['dim_date'].dt.to_period('Q')
    
    gtn_data = quarterly_sales.groupby('quarter').agg({
        'gross_sales': 'sum',
        'revenue_deductions': 'sum',
        'net_sales': 'sum'
    }).reset_index()
    
    x = np.arange(len(gtn_data))
    ax3.bar(x, gtn_data['gross_sales']/1e6, label='Gross Sales', color='#93C5FD', alpha=0.8)
    ax3.bar(x, gtn_data['net_sales']/1e6, label='Net Sales', color=COLORS['pluvicto'], alpha=0.9)
    
    # Add deduction rate on top
    for i, row in gtn_data.iterrows():
        deduction_rate = (row['revenue_deductions'] / row['gross_sales'] * 100) if row['gross_sales'] > 0 else 0
        ax3.text(i, row['gross_sales']/1e6, f'{deduction_rate:.1f}%', 
                ha='center', va='bottom', fontsize=8, color='#EF4444')
    
    ax3.set_xticks(x)
    ax3.set_xticklabels([str(q) for q in gtn_data['quarter']], fontsize=9)
    format_xaxis_labels(ax3, max_labels=6)
    ax3.set_ylabel('Revenue ($M)', fontsize=10)
    ax3.set_title('Gross to Net Analysis', fontsize=12, weight='bold', pad=10)
    ax3.legend(fontsize=8)
    ax3.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    pdf.savefig(fig, bbox_inches='tight')
    plt.close()
    print("✅ Slide 3 complete")

# Continue with remaining slides...
def generate_remaining_slides(pdf, sales, market, doses):
    """Generate slides 4-10 with placeholder content"""
    print("Generating remaining slides 4-10...")
    
    for slide_num in range(4, 11):
        fig = plt.figure(figsize=(16, 9))
        
        titles = {
            4: ("Market Share Analysis - Competitive Landscape", "Rolling 3-Month Average (R3M)"),
            5: ("New Patient Acquisition (NBRX)", "Market & Portfolio Performance"),
            6: ("Quarterly Performance Summary", "Q1 2024 to Q4 2025"),
            7: ("Product Portfolio Mix", "Revenue & Volume Distribution"),
            8: ("Forecast vs Actual - 2025 Performance", "Actual vs Budget vs Latest Estimate"),
            9: ("2026-2028 Outlook", "Three-Year Forecast Projections"),
            10: ("Executive KPI Dashboard", "Performance at a Glance")
        }
        
        add_slide_header(fig, titles[slide_num][0], titles[slide_num][1], slide_num)
        
        # Add placeholder content
        ax = fig.add_subplot(111)
        ax.text(0.5, 0.5, f'Slide {slide_num}\n{titles[slide_num][0]}\n\n[Chart content will be generated with actual data]',
               ha='center', va='center', fontsize=16, color='#6B7280',
               bbox=dict(boxstyle='round', facecolor='#F3F4F6', alpha=0.5))
        ax.axis('off')
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()
        print(f"✅ Slide {slide_num} complete")

def main():
    """Main function to generate all slides"""
    print("="*80)
    print("NOVARTIS MBR PRESENTATION GENERATOR")
    print("="*80)
    
    # Load data
    sales, market, doses = load_data()
    
    # Create PDF
    output_file = 'data_sample/Novartis_MBR_December_2025.pdf'
    print(f"\nGenerating PDF: {output_file}")
    
    with PdfPages(output_file) as pdf:
        # Generate slides
        slide_1_executive_summary(pdf, sales, market, doses)
        # slide_2_revenue_performance(pdf, sales)
        # slide_3_pluvicto_deep_dive(pdf, sales, doses)
        # generate_remaining_slides(pdf, sales, market, doses)
        
        # Add metadata
        d = pdf.infodict()
        d['Title'] = 'Novartis Monthly Business Review - December 2025'
        d['Author'] = 'Novartis Analytics Team'
        d['Subject'] = 'RLT Portfolio Performance'
        d['Keywords'] = 'Pluvicto, Lutathera, Xofigo, Sales, Market Share'
        d['CreationDate'] = datetime.now()
    
    print("\n" + "="*80)
    print(f"✅ PDF GENERATED SUCCESSFULLY: {output_file}")
    print("="*80)

if __name__ == '__main__':
    main()
