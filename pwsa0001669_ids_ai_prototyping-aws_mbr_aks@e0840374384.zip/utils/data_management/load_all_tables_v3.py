#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Load All Novartis MBR Tables to DynamoDB
Combines create_dynamodb_tables.py and upload_to_dynamodb.py approaches
Uses normalized columns for Sales/Market/Doses and raw CSV columns for Calls/Rome
This matches the mo-nov profile data structure exactly
"""

import boto3
import pandas as pd
import json
from decimal import Decimal
from datetime import datetime
import time
import argparse

def convert_to_dynamodb_format(value):
    """Convert pandas values to DynamoDB compatible format"""
    if pd.isna(value):
        return None
    elif isinstance(value, (int, float)):
        return Decimal(str(value))
    elif isinstance(value, datetime):
        return value.isoformat()
    elif isinstance(value, pd.Timestamp):
        return value.isoformat()
    else:
        return str(value)

def get_or_create_table(dynamodb, table_name, with_gsi=False):
    """Get existing table or create if it doesn't exist"""
    
    try:
        # Try to get existing table
        table = dynamodb.Table(table_name)
        table.load()  # This will raise an exception if table doesn't exist
        print(f"✓ Using existing table: {table_name}")
        return table
    except dynamodb.meta.client.exceptions.ResourceNotFoundException:
        # Table doesn't exist, create it
        print(f"Creating new table: {table_name}")
        
        # Base table configuration
        table_config = {
            'TableName': table_name,
            'KeySchema': [
                {'AttributeName': 'PK', 'KeyType': 'HASH'},  # Partition key
                {'AttributeName': 'SK', 'KeyType': 'RANGE'}  # Sort key
            ],
            'AttributeDefinitions': [
                {'AttributeName': 'PK', 'AttributeType': 'S'},
                {'AttributeName': 'SK', 'AttributeType': 'S'},
            ],
            'BillingMode': 'PAY_PER_REQUEST'  # Match CDK billing mode
        }
        
        # Add GSI if needed (for Sales, Market, Doses tables)
        if with_gsi:
            table_config['AttributeDefinitions'].extend([
                {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
            ])
            table_config['GlobalSecondaryIndexes'] = [{
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            }]
        
        table = dynamodb.create_table(**table_config)
        
        # Wait for table to be created
        print("Waiting for table to be created...")
        table.wait_until_exists()
        print("✓ Table created")
        
        return table

def load_sales_finance_table(dynamodb):
    """Load Sales Finance table (normalized approach) - V3 with uppercase values"""
    table_name = 'Novartis_Sales_Finance_v3'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Sales Finance has GSI
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/SALES_FINANCE_BPC_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                # Primary Key: PRODUCT#ProductName#FORECAST#ForecastType (UPPERCASE)
                'PK': f"PRODUCT#{str(row['DIM_Brand']).upper()}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{str(row['DIM_forecast']).upper()}",
                
                # GSI1: Query by date and forecast type (matches mo-nov profile) (UPPERCASE)
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"PRODUCT#{str(row['DIM_Brand']).upper()}#FORECAST#{str(row['DIM_forecast']).upper()}",
                
                # Attributes (normalized names) - VALUES IN UPPERCASE
                'product': str(row['PRODUCT']).upper(),
                'brand': str(row['DIM_Brand']).upper(),
                'forecast_type': str(row['DIM_forecast']).upper(),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'net_sales': convert_to_dynamodb_format(row['net_sales']),
                'gross_sales': convert_to_dynamodb_format(row['gross_sales']),
                'revenue_deductions': convert_to_dynamodb_format(row['revenue_deductions']),
                'source': str(row['source']).upper(),
                'data_frequency': str(row['data_frequency']).upper(),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'year_quarter': str(row['year_quarter']),
                'last_altered': str(row['last_altered']),
                'entity_type': 'SALES'
            }
            
            # Remove None values
            item = {k: v for k, v in item.items() if v is not None}
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_market_share_table(dynamodb):
    """Load Market Share table (normalized approach) - V3 with uppercase values"""
    table_name = 'Novartis_Market_Share_v3'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Market Share has GSI
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_MARKET_PLU_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                'PK': f"BRAND#{str(row['DIM_Brand']).upper()}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}",
                
                # GSI1: Query by date (matches mo-nov profile) (UPPERCASE)
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{str(row['DIM_Brand']).upper()}",
                
                # Normalized attributes - VALUES IN UPPERCASE
                'brand': str(row['DIM_Brand']).upper(),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'trx_r3m': convert_to_dynamodb_format(row.get('TRX_R3M')),
                'trx_share_r3m': convert_to_dynamodb_format(row['TRX_SHARE_R3M']),
                'nbrx_r3m': convert_to_dynamodb_format(row.get('NBRX_R3M')),
                'nbrx_share_r3m': convert_to_dynamodb_format(row['NBRX_SHARE_R3M']),
                'product': str(row.get('PRODUCT', '')).upper(),
                'class': str(row.get('Class', '')).upper(),
                'class_aggregated': str(row.get('class_aggregated', '')).upper(),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'year_quarter': str(row['year_quarter']),
                'entity_type': 'MARKET_SHARE'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_doses_table(dynamodb):
    """Load Doses table (normalized approach) - V3 with uppercase values"""
    table_name = 'Novartis_Doses_v3'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Doses has GSI
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_DOSES_PLU_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                'PK': f"BRAND#{str(row['DIM_Brand']).upper()}#METRIC#{str(row['metric']).upper()}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{str(row['dim_forecast']).upper()}",
                
                # GSI1: Query by date (matches mo-nov profile) (UPPERCASE)
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{str(row['DIM_Brand']).upper()}#METRIC#{str(row['metric']).upper()}#FORECAST#{str(row['dim_forecast']).upper()}",
                
                # Normalized attributes - VALUES IN UPPERCASE
                'brand': str(row['DIM_Brand']).upper(),
                'metric': str(row['metric']).upper(),
                'forecast_type': str(row['dim_forecast']).upper(),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'value': convert_to_dynamodb_format(row['value']),
                'product': str(row.get('PRODUCT', '')).upper(),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'quarter_rel_index': int(row.get('quarter_rel_index', 0)),
                'entity_type': 'DOSES'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_calls_table(dynamodb):
    """Load Calls table (raw CSV approach) - V3 with uppercase values"""
    table_name = 'Novartis_Calls_v3'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=False)  # Calls has NO GSI
    
    # Load CSV data (using expanded file)
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_CALLS_expanded.csv')
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data with RAW CSV column names - ALL VALUES IN UPPERCASE
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            # Convert all CSV columns to DynamoDB item (preserving original column names, uppercasing values)
            item = {}
            for col in df.columns:
                value = convert_to_dynamodb_format(row[col])
                if value is not None:
                    # Uppercase string values, keep numbers as-is
                    if isinstance(value, str):
                        item[col] = value.upper()
                    else:
                        item[col] = value
            
            # Add DynamoDB keys using mo-nov pattern (simpler format, no GSI) - UPPERCASE
            item['PK'] = f"{item.get('product', 'UNKNOWN').upper()}#{item.get('dim_geo_level', 'UNKNOWN').upper()}#{item.get('dim_geo_name', 'UNKNOWN').upper()}"
            item['SK'] = f"{item.get('year_quarter', 'UNKNOWN').upper()}#{item.get('dim_metric_type', 'UNKNOWN').upper()}"
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_rome_table(dynamodb):
    """Load Rome table (raw CSV approach) - V3 with uppercase values (except specific columns)"""
    table_name = 'Novartis_Rome_v3'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=False)  # Rome has NO GSI
    
    # Load CSV data (using expanded file)
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_ROME_PLU_expanded.csv')
    
    print(f"Total records to insert: {len(df)}")
    
    # Columns to keep lowercase (exceptions)
    lowercase_columns = {
        'dim_order_status',
        'dim_order_type',
        'cancellation_unused_dose_reason',
        'cancellation_unused_dose_other_reason',
        'order_status_costumer',
        'delivery_address',
        'delivery_address_city'
    }
    
    # Insert data with RAW CSV column names - UPPERCASE except specific columns
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            # Convert all CSV columns to DynamoDB item (preserving original column names)
            item = {}
            for col in df.columns:
                value = convert_to_dynamodb_format(row[col])
                if value is not None:
                    # Check if this column should stay lowercase
                    if isinstance(value, str) and col not in lowercase_columns:
                        item[col] = value.upper()
                    else:
                        item[col] = value
            
            # Add DynamoDB keys using mo-nov pattern (simpler format, no GSI) - UPPERCASE
            item['PK'] = f"{item.get('PRODUCT', 'UNKNOWN').upper()}#{item.get('site_id', 'UNKNOWN').upper() if isinstance(item.get('site_id'), str) else item.get('site_id', 'UNKNOWN')}"
            item['SK'] = f"{item.get('dim_date', 'UNKNOWN').upper() if isinstance(item.get('dim_date'), str) else item.get('dim_date', 'UNKNOWN')}#{item.get('sales_order_number', 'UNKNOWN').upper() if isinstance(item.get('sales_order_number'), str) else item.get('sales_order_number', 'UNKNOWN')}"
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def verify_tables(dynamodb):
    """Verify table creation and data"""
    print(f"\n{'='*80}")
    print("VERIFICATION")
    print(f"{'='*80}")
    
    tables = [
        'Novartis_Sales_Finance_v3',
        'Novartis_Market_Share_v3',
        'Novartis_Doses_v3',
        'Novartis_Calls_v3',
        'Novartis_Rome_v3'
    ]
    
    for table_name in tables:
        table = dynamodb.Table(table_name)
        count = table.item_count
        print(f"✓ {table_name}: {count} items")

def main():
    """Main execution"""
    parser = argparse.ArgumentParser(description='Load all Novartis MBR tables to DynamoDB')
    parser.add_argument('--region', default='us-east-1', help='AWS region')
    
    args = parser.parse_args()
    
    print("="*80)
    print("NOVARTIS MBR - ALL TABLES CREATION V3")
    print("="*80)
    print(f"Region: {args.region}")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print()
    print("📋 Strategy:")
    print("  • Sales Finance, Market Share, Doses: Normalized column names, UPPERCASE values")
    print("  • Calls: Raw CSV column names, UPPERCASE values")
    print("  • Rome: Raw CSV column names, UPPERCASE values (except specific columns)")
    print("  • All tables: Same PK/SK patterns and GSI structure with _v3 suffix")
    
    # DynamoDB client
    dynamodb = boto3.resource('dynamodb', region_name=args.region)
    
    try:
        # Load all tables
        load_sales_finance_table(dynamodb)
        load_market_share_table(dynamodb)
        load_doses_table(dynamodb)
        load_calls_table(dynamodb)
        load_rome_table(dynamodb)
        
        # Verify
        time.sleep(5)  # Wait for eventual consistency
        verify_tables(dynamodb)
        
        print(f"\n{'='*80}")
        print("✅ ALL V3 TABLES CREATED SUCCESSFULLY")
        print(f"{'='*80}")
        
        print("\n📋 Data Structure Summary:")
        print("-"*80)
        print("✅ Sales Finance: Normalized columns, UPPERCASE values")
        print("✅ Market Share: Normalized columns, UPPERCASE values")
        print("✅ Doses: Normalized columns, UPPERCASE values")
        print("✅ Calls: Raw CSV columns, UPPERCASE values")
        print("✅ Rome: Raw CSV columns, UPPERCASE values (except specific columns)")
        
        print("\n📋 File Usage:")
        print("-"*80)
        print("• Sales Finance: data/data_samples/SALES_FINANCE_BPC_corrected.csv")
        print("• Market Share: data/data_samples/FCT_MARKET_PLU_corrected.csv")
        print("• Doses: data/data_samples/FCT_DOSES_PLU_corrected.csv")
        print("• Calls: data/data_samples/FCT_CALLS_expanded.csv")
        print("• Rome: data/data_samples/FCT_ROME_PLU_expanded.csv")
        
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        raise

if __name__ == '__main__':
    main()