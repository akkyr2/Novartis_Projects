#!/usr/bin/env python3
"""
Load All Novartis MBR Tables to DynamoDB - V6 UNIFIED LOADER

This unified loader combines:
1. 5 main tables (Sales, Market, Doses, Calls, Rome) from load_all_tables_v5.py
2. 4 Rome aggregated tables creation from create_rome_aggregated_tables_v6.py
3. 4 Rome aggregated tables population from aggregate_rome_data_v6.py

Total: 9 tables (5 main + 4 aggregated)

Usage:
    # Load all 9 tables
    python utils/data_management/load_all_tables_v6.py --table all
    
    # Load only main tables (5 tables)
    python utils/data_management/load_all_tables_v6.py --table main
    
    # Load only ROME aggregated tables (4 tables)
    python utils/data_management/load_all_tables_v6.py --table rome_aggregated
    
    # Load specific main table
    python utils/data_management/load_all_tables_v6.py --table sales
    python utils/data_management/load_all_tables_v6.py --table calls
    python utils/data_management/load_all_tables_v6.py --table rome
    
    # Load specific aggregated table
    python utils/data_management/load_all_tables_v6.py --table rome_new_patients
    python utils/data_management/load_all_tables_v6.py --table rome_all_orders

V6 Changes:
- Unified loader for all 9 tables
- Rome aggregated tables use _v6 suffix
- Supports Python helper tools (deduplicate_and_aggregate, simple_aggregate)
- Pre-computed counts optimization for fast queries
- Idempotent: Can rerun without duplicates
"""

import boto3
import argparse
from datetime import datetime
import sys
import os

# Import all loader functions from consolidated utilities
sys.path.insert(0, os.path.dirname(__file__))
from load_utils import (
    # Main table loaders
    load_sales_finance_table,
    load_market_share_table,
    load_doses_table,
    load_calls_table,
    load_rome_table_v5,
    # ROME aggregated table creation
    create_new_patient_starts_table,
    create_new_patient_orders_table,
    create_all_orders_table,
    create_site_status_table,
    # ROME aggregation functions
    scan_rome_table,
    aggregate_new_patient_starts,
    aggregate_new_patient_orders,
    aggregate_all_orders,
    aggregate_site_status,
    write_to_table
)



def main():
    parser = argparse.ArgumentParser(description='Load all Novartis MBR tables to DynamoDB - V6')
    parser.add_argument('--region', default='us-east-1', help='AWS region')
    parser.add_argument('--version', default='v6_final', help='Table version suffix (default: v6_final)')
    parser.add_argument('--table', 
                        choices=['all', 'main', 'rome_aggregated',
                                'sales', 'market', 'doses', 'calls', 'rome',
                                'rome_new_patients', 'rome_new_patient_orders', 
                                'rome_all_orders', 'rome_site_status'],
                        default='all', 
                        help='Which table(s) to load')
    
    args = parser.parse_args()
    
    print("="*80)
    print("NOVARTIS MBR - V6 UNIFIED TABLE LOADER")
    print("="*80)
    print(f"Region: {args.region}")
    print(f"Version: {args.version}")
    print(f"Table: {args.table}")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print()
    print("📋 V6 Strategy:")
    print("  • 5 Main Tables: Sales, Market, Doses, Calls, Rome")
    print("  • 4 ROME Aggregated Tables: NewPatientStarts, NewPatientOrders, AllOrders, SiteStatus")
    print("  • Total: 9 tables")
    print()
    
    dynamodb = boto3.resource('dynamodb', region_name=args.region)
    loaded_tables = []
    
    # ========================================================================
    # STEP 1: Load Main Tables (5 tables)
    # ========================================================================
    
    if args.table in ['all', 'main', 'sales']:
        print("\n" + "="*80)
        print(f"STEP 1.1: Loading Sales Finance Table ({args.version.upper()})")
        print("="*80)
        load_sales_finance_table(dynamodb, version=args.version)
        loaded_tables.append(f'Novartis_Sales_Finance_{args.version}')
    
    if args.table in ['all', 'main', 'market']:
        print("\n" + "="*80)
        print(f"STEP 1.2: Loading Market Share Table ({args.version.upper()})")
        print("="*80)
        load_market_share_table(dynamodb, version=args.version)
        loaded_tables.append(f'Novartis_Market_Share_{args.version}')
    
    if args.table in ['all', 'main', 'doses']:
        print("\n" + "="*80)
        print(f"STEP 1.3: Loading Doses Table ({args.version.upper()})")
        print("="*80)
        load_doses_table(dynamodb, version=args.version)
        loaded_tables.append(f'Novartis_Doses_{args.version}')
    
    if args.table in ['all', 'main', 'calls']:
        print("\n" + "="*80)
        print(f"STEP 1.4: Loading Calls Table ({args.version.upper()} with GSI5)")
        print("="*80)
        load_calls_table(dynamodb, version=args.version)
        loaded_tables.append(f'Novartis_Calls_{args.version}')
    
    if args.table in ['all', 'main', 'rome']:
        print("\n" + "="*80)
        print(f"STEP 1.5: Loading Rome Table ({args.version.upper()} with 6 GSIs)")
        print("="*80)
        load_rome_table_v5(dynamodb, version=args.version)
        loaded_tables.append(f'Novartis_Rome_{args.version}')
    
    # ========================================================================
    # STEP 2: Create ROME Aggregated Tables (4 tables)
    # ========================================================================
    
    if args.table in ['all', 'rome_aggregated', 'rome_new_patients']:
        print("\n" + "="*80)
        print(f"STEP 2.1: Creating Rome NewPatientStarts Table ({args.version.upper()})")
        print("="*80)
        create_new_patient_starts_table(dynamodb, version=args.version)
        loaded_tables.append(f'Rome_NewPatientStarts_Monthly_{args.version}')
    
    if args.table in ['all', 'rome_aggregated', 'rome_new_patient_orders']:
        print("\n" + "="*80)
        print(f"STEP 2.2: Creating Rome NewPatientOrders Table ({args.version.upper()})")
        print("="*80)
        create_new_patient_orders_table(dynamodb, version=args.version)
        loaded_tables.append(f'Rome_NewPatientOrders_Monthly_{args.version}')
    
    if args.table in ['all', 'rome_aggregated', 'rome_all_orders']:
        print("\n" + "="*80)
        print(f"STEP 2.3: Creating Rome AllOrders Table ({args.version.upper()})")
        print("="*80)
        create_all_orders_table(dynamodb, version=args.version)
        loaded_tables.append(f'Rome_AllOrders_Monthly_{args.version}')
    
    if args.table in ['all', 'rome_aggregated', 'rome_site_status']:
        print("\n" + "="*80)
        print(f"STEP 2.4: Creating Rome SiteStatus Table ({args.version.upper()})")
        print("="*80)
        create_site_status_table(dynamodb, version=args.version)
        loaded_tables.append(f'Rome_SiteStatus_Quarterly_{args.version}')
    
    # ========================================================================
    # STEP 3: Populate ROME Aggregated Tables (4 tables)
    # ========================================================================
    
    if args.table in ['all', 'rome_aggregated', 'rome_new_patients', 
                      'rome_new_patient_orders', 'rome_all_orders', 'rome_site_status']:
        print("\n" + "="*80)
        print("STEP 3: Populating ROME Aggregated Tables")
        print("="*80)
        print(f"Scanning Rome_{args.version} table for raw data...")
        raw_data = scan_rome_table(version=args.version)
        
        if args.table in ['all', 'rome_aggregated', 'rome_new_patients']:
            print("\n" + "-"*80)
            print("STEP 3.1: Aggregating New Patient Starts")
            print("-"*80)
            new_patient_records = aggregate_new_patient_starts(raw_data)
            write_to_table(f'Rome_NewPatientStarts_Monthly_{args.version}', new_patient_records)
        
        if args.table in ['all', 'rome_aggregated', 'rome_new_patient_orders']:
            print("\n" + "-"*80)
            print("STEP 3.2: Aggregating New Patient Orders")
            print("-"*80)
            new_patient_orders_records = aggregate_new_patient_orders(raw_data)
            write_to_table(f'Rome_NewPatientOrders_Monthly_{args.version}', new_patient_orders_records)
        
        if args.table in ['all', 'rome_aggregated', 'rome_all_orders']:
            print("\n" + "-"*80)
            print("STEP 3.3: Aggregating All Orders")
            print("-"*80)
            all_orders_records = aggregate_all_orders(raw_data)
            write_to_table(f'Rome_AllOrders_Monthly_{args.version}', all_orders_records)
        
        if args.table in ['all', 'rome_aggregated', 'rome_site_status']:
            print("\n" + "-"*80)
            print("STEP 3.4: Aggregating Site Status")
            print("-"*80)
            site_status_records = aggregate_site_status(raw_data)
            write_to_table(f'Rome_SiteStatus_Quarterly_{args.version}', site_status_records)
    
    # ========================================================================
    # FINAL SUMMARY
    # ========================================================================
    
    print("\n" + "="*80)
    print("✅ V6 UNIFIED LOADER COMPLETE")
    print("="*80)
    
    print("\n📋 Loaded Tables:")
    for table_name in loaded_tables:
        print(f"  ✓ {table_name}")
    
    print("\n📋 Next Steps:")
    print("  1. Verify tables in DynamoDB console")
    print("  2. Test queries with novartis_queries_v6.py")
    print("  3. Update app.py to use novartis_agent_handler_v6_final.py")
    print("  4. Run comprehensive test: scripts/scripts_v6/test_v6_final_all_42_questions.py")

if __name__ == '__main__':
    main()
