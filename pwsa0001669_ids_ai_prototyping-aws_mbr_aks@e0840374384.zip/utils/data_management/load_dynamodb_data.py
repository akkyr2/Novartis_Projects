#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Load Novartis MBR data into existing DynamoDB tables
Data loading script for deployment (tables must be created by CDK first)
"""

import boto3
import pandas as pd
import json
import argparse
import sys
import os
from decimal import Decimal
from datetime import datetime
import time
from botocore.exceptions import ClientError

def convert_to_dynamodb_format(value):
    """Convert pandas values to DynamoDB compatible format"""
    if pd.isna(value):
        return None
    elif isinstance(value, (int, float)):
        return Decimal(str(value))
    elif isinstance(value, datetime):
        return value.isoformat()
    elif isinstance(value, pd.Timestamp):
        return value.isoformat()
    else:
        return str(value)

def get_existing_table(dynamodb, table_name):
    """Get reference to existing DynamoDB table"""
    try:
        table = dynamodb.Table(table_name)
        table.load()
        print(f"✅ Found existing table '{table_name}'")
        return table
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print(f"❌ Table '{table_name}' does not exist")
            print(f"💡 Tables should be created by CDK infrastructure deployment")
            raise Exception(f"Table '{table_name}' not found. Deploy infrastructure first.")
        else:
            raise

def load_sales_finance_data(dynamodb, data_dir):
    """Load Sales Finance data"""
    table_name = 'Novartis_Sales_Finance'
    
    print(f"\n{'='*80}")
    print(f"Loading Sales Finance Data")
    print(f"{'='*80}")
    
    # Get existing table (created by CDK)
    table = get_existing_table(dynamodb, table_name)
    
    # Load data
    csv_file = os.path.join(data_dir, 'SALES_FINANCE_BPC_corrected.csv')
    if not os.path.exists(csv_file):
        print(f"⚠️ File not found: {csv_file}")
        return 0
    
    print(f"📖 Reading {csv_file}...")
    df = pd.read_csv(csv_file)
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"📤 Loading {len(df)} records...")
    
    # Insert data in batches
    batch_size = 25
    total_inserted = 0
    
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i+batch_size]
        
        with table.batch_writer() as writer:
            for idx, row in batch.iterrows():
                item = {
                    'PK': f"PRODUCT#{row['DIM_Brand']}",
                    'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{row['DIM_forecast']}",
                    'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                    'GSI1SK': f"PRODUCT#{row['DIM_Brand']}#FORECAST#{row['DIM_forecast']}",
                    'product': str(row['PRODUCT']),
                    'brand': str(row['DIM_Brand']),
                    'forecast_type': str(row['DIM_forecast']),
                    'date': row['dim_date'].strftime('%Y-%m-%d'),
                    'year': int(row['dim_date'].year),
                    'month': int(row['dim_date'].month),
                    'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                    'net_sales': convert_to_dynamodb_format(row['net_sales']),
                    'gross_sales': convert_to_dynamodb_format(row['gross_sales']),
                    'revenue_deductions': convert_to_dynamodb_format(row['revenue_deductions']),
                    'source': str(row['source']),
                    'data_frequency': str(row['data_frequency']),
                    'month_rel_index': int(row['month_rel_index']),
                    'year_rel_index': int(row['year_rel_index']),
                    'cycle_rel_index': int(row['cycle_rel_index']),
                    'year_quarter': str(row['year_quarter']),
                    'last_altered': str(row['last_altered']),
                    'entity_type': 'SALES'
                }
                
                # Remove None values
                item = {k: v for k, v in item.items() if v is not None}
                writer.put_item(Item=item)
                total_inserted += 1
        
        if (i + batch_size) % 100 == 0:
            print(f"   Inserted {min(i + batch_size, len(df))}/{len(df)} records...")
    
    print(f"✅ Loaded {total_inserted} sales finance records")
    return total_inserted

def load_market_share_data(dynamodb, data_dir):
    """Load Market Share data"""
    table_name = 'Novartis_Market_Share'
    
    print(f"\n{'='*80}")
    print(f"Loading Market Share Data")
    print(f"{'='*80}")
    
    # Get existing table (created by CDK)
    table = get_existing_table(dynamodb, table_name)
    
    # Load data
    csv_file = os.path.join(data_dir, 'FCT_MARKET_PLU_corrected.csv')
    if not os.path.exists(csv_file):
        print(f"⚠️ File not found: {csv_file}")
        return 0
    
    print(f"📖 Reading {csv_file}...")
    df = pd.read_csv(csv_file)
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"📤 Loading {len(df)} records...")
    
    # Insert data in batches
    batch_size = 25
    total_inserted = 0
    
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i+batch_size]
        
        with table.batch_writer() as writer:
            for idx, row in batch.iterrows():
                item = {
                    'PK': f"BRAND#{row['DIM_Brand']}",
                    'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}",
                    'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                    'GSI1SK': f"BRAND#{row['DIM_Brand']}",
                    'brand': str(row['DIM_Brand']),
                    'date': row['dim_date'].strftime('%Y-%m-%d'),
                    'year': int(row['dim_date'].year),
                    'month': int(row['dim_date'].month),
                    'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                    'trx_r3m': convert_to_dynamodb_format(row.get('TRX_R3M')),
                    'trx_share_r3m': convert_to_dynamodb_format(row['TRX_SHARE_R3M']),
                    'nbrx_r3m': convert_to_dynamodb_format(row.get('NBRX_R3M')),
                    'nbrx_share_r3m': convert_to_dynamodb_format(row['NBRX_SHARE_R3M']),
                    'product': str(row.get('PRODUCT', '')),
                    'class': str(row.get('Class', '')),
                    'class_aggregated': str(row.get('class_aggregated', '')),
                    'month_rel_index': int(row['month_rel_index']),
                    'year_rel_index': int(row['year_rel_index']),
                    'cycle_rel_index': int(row['cycle_rel_index']),
                    'year_quarter': str(row['year_quarter']),
                    'entity_type': 'MARKET_SHARE'
                }
                
                item = {k: v for k, v in item.items() if v is not None}
                writer.put_item(Item=item)
                total_inserted += 1
        
        if (i + batch_size) % 100 == 0:
            print(f"   Inserted {min(i + batch_size, len(df))}/{len(df)} records...")
    
    print(f"✅ Loaded {total_inserted} market share records")
    return total_inserted

def load_doses_data(dynamodb, data_dir):
    """Load Doses data"""
    table_name = 'Novartis_Doses'
    
    print(f"\n{'='*80}")
    print(f"Loading Doses Data")
    print(f"{'='*80}")
    
    # Get existing table (created by CDK)
    table = get_existing_table(dynamodb, table_name)
    
    # Load data
    csv_file = os.path.join(data_dir, 'FCT_DOSES_PLU_corrected.csv')
    if not os.path.exists(csv_file):
        print(f"⚠️ File not found: {csv_file}")
        return 0
    
    print(f"📖 Reading {csv_file}...")
    df = pd.read_csv(csv_file)
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"📤 Loading {len(df)} records...")
    
    # Insert data in batches
    batch_size = 25
    total_inserted = 0
    
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i+batch_size]
        
        with table.batch_writer() as writer:
            for idx, row in batch.iterrows():
                item = {
                    'PK': f"BRAND#{row['DIM_Brand']}#METRIC#{row['metric']}",
                    'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{row['dim_forecast']}",
                    'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                    'GSI1SK': f"BRAND#{row['DIM_Brand']}#METRIC#{row['metric']}#FORECAST#{row['dim_forecast']}",
                    'brand': str(row['DIM_Brand']),
                    'metric': str(row['metric']),
                    'forecast_type': str(row['dim_forecast']),
                    'date': row['dim_date'].strftime('%Y-%m-%d'),
                    'year': int(row['dim_date'].year),
                    'month': int(row['dim_date'].month),
                    'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                    'value': convert_to_dynamodb_format(row['value']),
                    'product': str(row.get('PRODUCT', '')),
                    'month_rel_index': int(row['month_rel_index']),
                    'year_rel_index': int(row['year_rel_index']),
                    'quarter_rel_index': int(row.get('quarter_rel_index', 0)),
                    'entity_type': 'DOSES'
                }
                
                item = {k: v for k, v in item.items() if v is not None}
                writer.put_item(Item=item)
                total_inserted += 1
        
        if (i + batch_size) % 100 == 0:
            print(f"   Inserted {min(i + batch_size, len(df))}/{len(df)} records...")
    
    print(f"✅ Loaded {total_inserted} doses records")
    return total_inserted

def load_calls_data(dynamodb, data_dir):
    """Load Calls data"""
    table_name = 'Novartis_Calls'
    
    print(f"\n{'='*80}")
    print(f"Loading Calls Data")
    print(f"{'='*80}")
    
    # Get existing table (created by CDK)
    table = get_existing_table(dynamodb, table_name)
    
    # Load data
    csv_file = os.path.join(data_dir, 'FCT_CALLS_corrected.csv')
    if not os.path.exists(csv_file):
        print(f"⚠️ File not found: {csv_file}")
        return 0
    
    print(f"📖 Reading {csv_file}...")
    df = pd.read_csv(csv_file)
    
    print(f"📤 Loading {len(df)} records...")
    
    # Insert data in batches
    batch_size = 25
    total_inserted = 0
    
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i+batch_size]
        
        with table.batch_writer() as writer:
            for idx, row in batch.iterrows():
                item = {
                    'PK': f"PRODUCT#{row['product']}#GEO#{row['dim_geo_level']}#{row['dim_geo_name']}",
                    'SK': f"QUARTER#{row['year_quarter']}#METRIC#{row['dim_metric_type']}#ID#{idx}",
                    'GSI1PK': f"QUARTER#{row['year_quarter']}",
                    'GSI1SK': f"PRODUCT#{row['product']}#GEO#{row['dim_geo_level']}#{row['dim_geo_name']}#METRIC#{row['dim_metric_type']}#ID#{idx}",
                    'product': str(row['product']),
                    'source': str(row.get('source', '')),
                    'brand': str(row.get('dim_brand', '')),
                    'tier': str(row.get('dim_tier', '')),
                    'time_period': str(row.get('dim_time_period', '')),
                    'geo_level': str(row['dim_geo_level']),
                    'geo_name': str(row['dim_geo_name']),
                    'metric_type': str(row['dim_metric_type']),
                    'year_quarter': str(row['year_quarter']),
                    'cpd': convert_to_dynamodb_format(row.get('CPD')),
                    'cpd_goal': convert_to_dynamodb_format(row.get('cpd_goal')),
                    'cpd_attainment': convert_to_dynamodb_format(row.get('cpd_attainment')),
                    'target_hcp_reach': convert_to_dynamodb_format(row.get('target_hcp_reach')),
                    'total_target': convert_to_dynamodb_format(row.get('total_target')),
                    'percent_reached': convert_to_dynamodb_format(row.get('percent_reached')),
                    'hcp_not_reached': convert_to_dynamodb_format(row.get('hcp_not_reached')),
                    'call_frequency_actual': convert_to_dynamodb_format(row.get('call_frequency_actual')),
                    'call_frequency_attainment': convert_to_dynamodb_format(row.get('call_frequency_attainment')),
                    'actual_calls': convert_to_dynamodb_format(row.get('actual_calls')),
                    'planned_calls': convert_to_dynamodb_format(row.get('planned_calls')),
                    'therapeutic_area': str(row.get('therapeutic_area', '')),
                    'sub_therapeutic_area': str(row.get('sub_therapeutic_area', '')),
                    'entity_type': 'CALLS'
                }
                
                item = {k: v for k, v in item.items() if v is not None}
                writer.put_item(Item=item)
                total_inserted += 1
        
        if (i + batch_size) % 100 == 0:
            print(f"   Inserted {min(i + batch_size, len(df))}/{len(df)} records...")
    
    print(f"✅ Loaded {total_inserted} calls records")
    return total_inserted

def verify_data_load(dynamodb):
    """Verify that data was loaded correctly"""
    print(f"\n{'='*80}")
    print("VERIFICATION")
    print(f"{'='*80}")
    
    tables = [
        'Novartis_Sales_Finance',
        'Novartis_Market_Share',
        'Novartis_Doses',
        'Novartis_Calls'
    ]
    
    total_items = 0
    for table_name in tables:
        try:
            table = dynamodb.Table(table_name)
            # Get approximate item count
            response = table.meta.client.describe_table(TableName=table_name)
            count = response['Table']['ItemCount']
            size = response['Table']['TableSizeBytes']
            total_items += count
            print(f"✅ {table_name}: {count:,} items ({size:,} bytes)")
        except Exception as e:
            print(f"❌ {table_name}: Error - {str(e)}")
    
    print(f"\n📊 Total items across all tables: {total_items:,}")
    return total_items

def main():
    """Main execution"""
    parser = argparse.ArgumentParser(description='Load Novartis MBR data into DynamoDB')
    parser.add_argument('--data-dir', default='data_sample/Real_data', 
                       help='Directory containing CSV files')
    parser.add_argument('--region', default='us-east-1', 
                       help='AWS region')
    parser.add_argument('--tables', nargs='+', 
                       choices=['sales', 'market', 'doses', 'calls', 'all'],
                       default=['all'],
                       help='Which tables to load')
    
    args = parser.parse_args()
    
    print("="*80)
    print("NOVARTIS MBR - DYNAMODB DATA LOADING")
    print("="*80)
    print(f"Region: {args.region}")
    print(f"Data Directory: {args.data_dir}")
    print(f"Tables: {args.tables}")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print()
    print("📋 Note: This script loads data into existing DynamoDB tables.")
    print("   Tables must be created by CDK infrastructure deployment first.")
    
    # Check if data directory exists
    if not os.path.exists(args.data_dir):
        print(f"❌ Data directory not found: {args.data_dir}")
        sys.exit(1)
    
    # Initialize DynamoDB
    try:
        dynamodb = boto3.resource('dynamodb', region_name=args.region)
        print(f"✅ Connected to DynamoDB in {args.region}")
    except Exception as e:
        print(f"❌ Failed to connect to DynamoDB: {str(e)}")
        sys.exit(1)
    
    # Load data
    total_loaded = 0
    
    try:
        if 'all' in args.tables or 'sales' in args.tables:
            total_loaded += load_sales_finance_data(dynamodb, args.data_dir)
        
        if 'all' in args.tables or 'market' in args.tables:
            total_loaded += load_market_share_data(dynamodb, args.data_dir)
        
        if 'all' in args.tables or 'doses' in args.tables:
            total_loaded += load_doses_data(dynamodb, args.data_dir)
        
        if 'all' in args.tables or 'calls' in args.tables:
            total_loaded += load_calls_data(dynamodb, args.data_dir)
        
        # Verify data load
        print(f"\n⏳ Waiting for eventual consistency...")
        time.sleep(5)
        verify_data_load(dynamodb)
        
        print(f"\n{'='*80}")
        print("✅ DATA LOADING COMPLETED SUCCESSFULLY")
        print(f"{'='*80}")
        print(f"Total records loaded: {total_loaded:,}")
        
        print(f"\n📋 Next Steps:")
        print(f"1. Test queries using the MBR Dashboard")
        print(f"2. Verify data accuracy in the application")
        print(f"3. Monitor DynamoDB usage and costs")
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    main()