#!/usr/bin/env python3
"""
Load Utilities - Consolidated Functions

This file consolidates all table loading functions from:
1. Main table loaders (5 tables: Sales, Market, Doses, Calls, Rome)
2. ROME aggregated table creation (4 tables)
3. ROME aggregated table population (4 functions)

Used by: load_all_tables_v6.py
"""

import boto3
import pandas as pd
from decimal import Decimal
from datetime import datetime
import time
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from botocore.exceptions import ClientError
from collections import defaultdict
from boto3.dynamodb.conditions import Key, Attr

# AWS Configuration
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'utils', 'aws'))
from aws_utils import get_aws_resource

# Initialize DynamoDB
dynamodb = get_aws_resource('dynamodb')

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def find_csv_file(keyword):
    """Find CSV file in data/data_samples directory that contains the keyword
    
    Args:
        keyword: Keyword to search for in filename (e.g., 'SALES', 'ROME', 'CALLS')
    
    Returns:
        Full path to the CSV file
    
    Raises:
        FileNotFoundError: If no matching CSV file is found
    """
    import glob
    
    data_dir = 'data/data_samples'
    pattern = f"{data_dir}/*{keyword}*.csv"
    
    matching_files = glob.glob(pattern)
    
    if not matching_files:
        raise FileNotFoundError(f"No CSV file found matching pattern: {pattern}")
    
    if len(matching_files) > 1:
        print(f"⚠️  Warning: Multiple CSV files found for '{keyword}': {matching_files}")
        print(f"   Using first match: {matching_files[0]}")
    
    return matching_files[0]


def convert_to_dynamodb_format(value):
    """Convert pandas values to DynamoDB compatible format"""
    if pd.isna(value):
        return None
    elif value == '' or (isinstance(value, str) and value.strip() == ''):
        return None
    elif isinstance(value, bool):
        return str(value).upper()
    elif isinstance(value, (int, float)):
        return Decimal(str(value))
    elif isinstance(value, datetime):
        return value.isoformat()
    elif isinstance(value, pd.Timestamp):
        return value.isoformat()
    else:
        return str(value)


def get_or_create_table(dynamodb, table_name, with_gsi=False, gsi_count=1):
    """Get existing table or create if it doesn't exist
    
    Args:
        dynamodb: DynamoDB resource
        table_name: Name of table to create
        with_gsi: Whether to create GSIs
        gsi_count: Number of GSIs to create (1=single GSI, 4=Calls, 6=Rome)
    """
    
    try:
        # Try to get existing table
        table = dynamodb.Table(table_name)
        table.load()  # This will raise an exception if table doesn't exist
        print(f"✓ Using existing table: {table_name}")
        return table
    except dynamodb.meta.client.exceptions.ResourceNotFoundException:
        # Table doesn't exist, create it
        print(f"Creating new table: {table_name}")
        
        # Base table configuration
        table_config = {
            'TableName': table_name,
            'KeySchema': [
                {'AttributeName': 'PK', 'KeyType': 'HASH'},  # Partition key
                {'AttributeName': 'SK', 'KeyType': 'RANGE'}  # Sort key
            ],
            'AttributeDefinitions': [
                {'AttributeName': 'PK', 'AttributeType': 'S'},
                {'AttributeName': 'SK', 'AttributeType': 'S'},
            ],
            'BillingMode': 'PAY_PER_REQUEST'  # Match CDK billing mode
        }
        
        # Add GSIs for Rome table (6 GSIs)
        if 'Rome' in table_name and gsi_count >= 6:
            table_config['AttributeDefinitions'].extend([
                {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI2PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI2SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI3PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI3SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI4PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI4SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI5PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI5SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI6PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI6SK', 'AttributeType': 'S'},
            ])
            
            table_config['GlobalSecondaryIndexes'] = [
                {
                    'IndexName': 'GSI1',
                    'KeySchema': [
                        {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI2',
                    'KeySchema': [
                        {'AttributeName': 'GSI2PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI2SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI3',
                    'KeySchema': [
                        {'AttributeName': 'GSI3PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI3SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI4',
                    'KeySchema': [
                        {'AttributeName': 'GSI4PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI4SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI5',
                    'KeySchema': [
                        {'AttributeName': 'GSI5PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI5SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI6',
                    'KeySchema': [
                        {'AttributeName': 'GSI6PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI6SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                }
            ]
        # Add GSIs for Calls table (4 GSIs: GSI1-3, GSI5 only)
        elif 'Calls' in table_name and gsi_count >= 1:
            # Define 4 GSI attributes (removed GSI6/7 - not used in practice)
            table_config['AttributeDefinitions'].extend([
                {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI2PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI2SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI3PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI3SK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI5PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI5SK', 'AttributeType': 'S'},
            ])
            
            # Create 4 GSIs (GSI1-3, GSI5) - GSI6/7 removed for 2x faster loading
            table_config['GlobalSecondaryIndexes'] = [
                {
                    'IndexName': 'GSI1',
                    'KeySchema': [
                        {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI2',
                    'KeySchema': [
                        {'AttributeName': 'GSI2PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI2SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI3',
                    'KeySchema': [
                        {'AttributeName': 'GSI3PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI3SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                },
                {
                    'IndexName': 'GSI5',
                    'KeySchema': [
                        {'AttributeName': 'GSI5PK', 'KeyType': 'HASH'},
                        {'AttributeName': 'GSI5SK', 'KeyType': 'RANGE'}
                    ],
                    'Projection': {'ProjectionType': 'ALL'}
                }
            ]
        # Add GSI for other tables (Sales, Market, Doses, Rome)
        elif with_gsi:
            table_config['AttributeDefinitions'].extend([
                {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
            ])
            table_config['GlobalSecondaryIndexes'] = [{
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            }]
        
        table = dynamodb.create_table(**table_config)
        
        # Wait for table to be created
        print("Waiting for table to be created...")
        table.wait_until_exists()
        print("✓ Table created")
        
        return table


# ============================================================================
# MAIN TABLE LOADERS
# ============================================================================

def load_sales_finance_table(dynamodb, version='v6_final'):
    """Load Sales Finance table - V6 with corrected structure
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Novartis_Sales_Finance_{version}'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Sales Finance has GSI
    
    # Load CSV data - use dynamic CSV discovery
    print("Loading CSV data...")
    csv_file = find_csv_file('SALES')
    print(f"  Using CSV file: {csv_file}")
    df = pd.read_csv(csv_file)
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                # Match V3 structure: PRODUCT#{product} (not BRAND#!)
                'PK': f"PRODUCT#{str(row['PRODUCT']).upper()}",
                # Match V3 structure: Include FORECAST in SK
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{str(row['DIM_forecast']).upper()}",
                
                # GSI1: Match V3 structure
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"PRODUCT#{str(row['PRODUCT']).upper()}#FORECAST#{str(row['DIM_forecast']).upper()}",
                
                # Attributes (normalized names) - VALUES IN UPPERCASE
                'product': str(row['PRODUCT']).upper(),
                'brand': str(row['PRODUCT']).upper(),
                'forecast_type': str(row['DIM_forecast']).upper(),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'year_quarter': str(row['year_quarter']),
                'net_sales': convert_to_dynamodb_format(row['net_sales']),
                'gross_sales': convert_to_dynamodb_format(row['gross_sales']),
                'revenue_deductions': convert_to_dynamodb_format(row['revenue_deductions']),
                'data_frequency': 'MONTHLY',
                'source': 'BPC_SALES',
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'entity_type': 'SALES'
            }
            
            # Remove None values
            item = {k: v for k, v in item.items() if v is not None}
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table


def load_market_share_table(dynamodb, version='v6_final'):
    """Load Market Share table - V6 with corrected structure
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Novartis_Market_Share_{version}'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Market Share has GSI
    
    # Load CSV data - use dynamic CSV discovery
    print("Loading CSV data...")
    csv_file = find_csv_file('MARKET')
    print(f"  Using CSV file: {csv_file}")
    df = pd.read_csv(csv_file)
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    print(f"Products (from PRODUCT column): {df['PRODUCT'].unique()}")
    print(f"Brands (from DIM_Brand column): {df['DIM_Brand'].unique()}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                # CRITICAL: Use PRODUCT column (not DIM_Brand) to match real data structure
                'PK': f"BRAND#{str(row['PRODUCT']).upper()}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}",
                
                # GSI1: Match V3 structure
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{str(row['PRODUCT']).upper()}",
                
                # Normalized attributes - VALUES IN UPPERCASE
                # Map PRODUCT to 'brand' attribute (for real data where PRODUCT varies)
                'brand': str(row['PRODUCT']).upper(),
                'product': str(row.get('PRODUCT', '')).upper(),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'year_quarter': str(row['year_quarter']),
                'trx_r3m': convert_to_dynamodb_format(row.get('TRX_R3M')),
                'trx_share_r3m': convert_to_dynamodb_format(row['TRX_SHARE_R3M']),
                'nbrx_r3m': convert_to_dynamodb_format(row.get('NBRX_R3M')),
                'nbrx_share_r3m': convert_to_dynamodb_format(row['NBRX_SHARE_R3M']),
                'class': str(row.get('Class', '')).upper(),
                'class_aggregated': str(row.get('class_aggregated', '')).upper(),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'entity_type': 'MARKET_SHARE'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table


def load_doses_table(dynamodb, version='v6_final'):
    """Load Doses table - V6 with corrected structure
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Novartis_Doses_{version}'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Doses has GSI
    
    # Load CSV data - use dynamic CSV discovery
    print("Loading CSV data...")
    csv_file = find_csv_file('DOSES')
    print(f"  Using CSV file: {csv_file}")
    df = pd.read_csv(csv_file)
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    print(f"Products: {df['PRODUCT'].unique()}")
    print(f"Metrics: {df['metric'].unique()}")
    print(f"Forecast types: {df['dim_forecast'].unique()}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                # Match V3 structure: BRAND#{brand}#METRIC#{metric}
                'PK': f"BRAND#{str(row['PRODUCT']).upper()}#METRIC#{str(row['metric']).upper()}",
                # Match V3 structure: Include FORECAST in SK
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{str(row['dim_forecast']).upper()}",
                
                # GSI1: Match V3 structure
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{str(row['PRODUCT']).upper()}#METRIC#{str(row['metric']).upper()}#FORECAST#{str(row['dim_forecast']).upper()}",
                
                # Normalized attributes - VALUES IN UPPERCASE
                'brand': str(row['PRODUCT']).upper(),
                'product': str(row['PRODUCT']).upper(),
                'metric': str(row['metric']).upper(),
                'forecast_type': str(row['dim_forecast']).upper(),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'value': convert_to_dynamodb_format(row['value']),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'quarter_rel_index': int(row.get('quarter_rel_index', 0)),
                'entity_type': 'DOSES'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table


def load_calls_table(dynamodb, version='v6_final'):
    """Load Calls table with composite key + GSIs
    
    Structure:
        PK: {PRODUCT}#{DIM_TIER}#{GEO_LEVEL}#{GEO_NAME}#{PERIOD_END_DATE}
        SK: {YEAR_QUARTER}#{DIM_TIME_PERIOD}#{METRIC_TYPE}
        
        GSI1: Time-based queries (DATE#{YYYY-MM})
        GSI2: Product + Tier queries ({PRODUCT}#{DIM_TIER})
        GSI3: Geography queries ({GEO_LEVEL}#{GEO_NAME})
        GSI5: Product+Year+Tier+GeoLevel+Metric (MOST IMPORTANT - 80% of queries)
    
    Benefits:
        - GSI5 handles 80% of queries with <1000 records returned
        - Sub-second query times for all common questions
        - Idempotent: Reloading same data overwrites (no duplicates)
        - Production ready: Can reload data anytime
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Novartis_Calls_{version}'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    print(f"Structure: Composite Key + 4 GSIs (optimized)")
    print(f"  - PK: PRODUCT#TIER#GEO_LEVEL#GEO_NAME#PERIOD_END_DATE")
    print(f"  - SK: YEAR_QUARTER#TIME_PERIOD#METRIC_TYPE#WEEK_MONTH_NUM")
    print(f"  - GSI1: Time-based (DATE#YYYY-MM)")
    print(f"  - GSI2: Product+Tier")
    print(f"  - GSI3: Geography")
    print(f"  - GSI5: Product+Year+Tier+GeoLevel+Metric (MOST IMPORTANT)")
    print(f"  - GSI6/7: REMOVED (not used in practice)")
    print()
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True, gsi_count=6)
    
    # Load CSV data
    print("Loading CSV data...")
    csv_file = find_csv_file('CALLS')
    print(f"  Using CSV file: {csv_file}")
    df = pd.read_csv(csv_file)
    
    # Parse period_end_date as datetime
    df['period_end_date'] = pd.to_datetime(df['period_end_date'])
    
    print(f"Total records to insert: {len(df)}")
    print()
    
    # Columns to preserve case (not uppercase)
    preserve_case_columns = ['dim_tier']  # dim_tier has mixed case like "T1", "All Tiers Except NT"
    
    # Insert data with RAW CSV column names - UPPERCASE except preserved columns
    # Use parallel batch writes for faster loading
    from concurrent.futures import ThreadPoolExecutor, as_completed
    import threading
    
    inserted_count = 0
    batch_size = 25  # DynamoDB batch limit
    batches = []
    current_batch = []
    
    print("  Preparing batches...")
    for idx, row in df.iterrows():
        # Convert all CSV columns to DynamoDB item
        item = {}
        for col in df.columns:
            value = convert_to_dynamodb_format(row[col])
            if value is not None:
                # Preserve case for specific columns, uppercase others
                if isinstance(value, str) and col not in preserve_case_columns:
                    item[col] = value.upper()
                else:
                    item[col] = value
        
        # Extract values for keys (uppercase where needed)
        product = str(row['product']).upper()
        dim_tier = str(row['dim_tier'])  # Preserve case
        dim_geo_level = str(row['dim_geo_level']).upper()
        dim_geo_name = str(row['dim_geo_name']).upper()
        year_quarter = str(row['year_quarter'])  # Keep format (e.g., "2024-Q1")
        dim_time_period = str(row['dim_time_period']).upper()
        dim_metric_type = str(row['dim_metric_type']).upper()
        period_end_date = row['period_end_date']
        year = period_end_date.year
        quarter = f"Q{period_end_date.quarter}"
        
        # PK: Complete composite key (all 8 unique fields)
        # Use period_end_date instead of call_date to prevent duplicates
        item['PK'] = f"{product}#{dim_tier}#{dim_geo_level}#{dim_geo_name}#{period_end_date.strftime('%Y-%m-%d')}"
        
        # SK: Include week_month_num to handle weekly periods (WEEK, CUM_WEEK, ROLLING_4WEEK)
        week_month_num = int(row.get('week_month_num', 0))
        item['SK'] = f"{year_quarter}#{dim_time_period}#{dim_metric_type}#{week_month_num}"
        
        # GSI1: Time-based queries (DATE#{YYYY-MM})
        item['GSI1PK'] = f"DATE#{period_end_date.strftime('%Y-%m')}"
        item['GSI1SK'] = f"{product}#{dim_tier}#{dim_metric_type}"
        
        # GSI2: Product + Tier queries
        item['GSI2PK'] = f"{product}#{dim_tier}"
        item['GSI2SK'] = f"{year_quarter}#{dim_geo_level}#{dim_geo_name}"
        
        # GSI3: Geography queries (specific region/territory)
        item['GSI3PK'] = f"{dim_geo_level}#{dim_geo_name}"
        item['GSI3SK'] = f"{product}#{dim_tier}#{year_quarter}"
        
        # GSI5: Product+Year+Tier+GeoLevel+Metric (MOST IMPORTANT - 80% of queries)
        # This returns only the exact records needed (e.g., 688 instead of 81,872)
        # GSI5SK uses TIME_PERIOD + CYCLE_REL_INDEX for filtering by time period
        cycle_rel_index = int(row['cycle_rel_index'])
        item['GSI5PK'] = f"{product}#{year}#{dim_tier}#{dim_geo_level}#{dim_metric_type}"
        item['GSI5SK'] = f"{dim_time_period}#{cycle_rel_index}"
        
        # GSI6 and GSI7 removed - not used in practice (all queries use GSI5)
        
        current_batch.append(item)
        
        if len(current_batch) >= batch_size:
            batches.append(current_batch)
            current_batch = []
    
    # Add remaining items
    if current_batch:
        batches.append(current_batch)
    
    print(f"  Created {len(batches)} batches of {batch_size} items each")
    print(f"  Writing with 20 parallel threads (balanced for GSI scaling)...")
    
    # Write batches in parallel with retry logic for throttling
    lock = threading.Lock()
    
    def write_batch(batch_items):
        import time
        import random
        from botocore.exceptions import ClientError
        
        # Each thread gets its own DynamoDB resource
        import boto3
        from botocore.config import Config
        thread_config = Config(
            max_pool_connections=20,
            retries={'max_attempts': 10, 'mode': 'adaptive'}
        )
        thread_dynamodb = boto3.resource('dynamodb', region_name='us-east-1', config=thread_config)
        thread_table = thread_dynamodb.Table(table_name)
        
        max_retries = 5
        for attempt in range(max_retries):
            try:
                with thread_table.batch_writer() as batch:
                    for item in batch_items:
                        batch.put_item(Item=item)
                return len(batch_items)
            except ClientError as e:
                if e.response['Error']['Code'] == 'ThrottlingException' and attempt < max_retries - 1:
                    # Exponential backoff with jitter
                    wait_time = (2 ** attempt) + random.uniform(0, 1)
                    time.sleep(wait_time)
                else:
                    raise
    
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(write_batch, batch): i for i, batch in enumerate(batches)}
        
        for future in as_completed(futures):
            count = future.result()
            with lock:
                inserted_count += count
                if inserted_count % 5000 < batch_size:  # Print every ~5000 records
                    print(f"  Inserted {inserted_count:,} records...")
    
    print(f"\n✓ Successfully inserted {inserted_count:,} records into {table_name}")
    print(f"✓ Table is idempotent - can reload data anytime without duplicates")
    print(f"✓ All 6 GSIs created for fast queries (GSI5 handles 80% of queries)")
    return table


def load_rome_table_v5(dynamodb, table_name=None, version='v6_final'):
    """
    Load Rome table with 6 GSIs for optimized queries
    
    Rome Structure:
        PK: {PRODUCT}#{SITE_ID}
        SK: {DIM_DATE}#{SALES_ORDER_NUMBER}
        
        GSI1: Time-based (Monthly) - DATE#{YYYY-MM}
        GSI2: Site-based - SITE#{SITE_ID}
        GSI3: Geography-based - {GEO_LEVEL}#{GEO_NAME}
        GSI4: Product + Year + First Dose - {PRODUCT}#{YEAR}#{IS_FIRST_DOSE}
        GSI5: Order Status + Geography - {ORDER_STATUS}#{GEO_LEVEL}#{GEO_NAME}
        GSI6: Account Status + Site Attributes - {ACCOUNT_STATUS}#{ACTIVE_DORMANT_FLAG}
    
    Expected Performance:
        - 95%+ faster than previous versions (30-60s to <2s)
        - Handles 17 business questions efficiently
    
    Args:
        dynamodb: DynamoDB resource
        table_name: Optional explicit table name (overrides version)
        version: Table version suffix (default: 'v6_final')
    """
    if table_name is None:
        table_name = f'Novartis_Rome_{version}'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    print(f"Structure: 6 GSIs for optimized queries")
    print(f"  - PK: PRODUCT#SITE_ID")
    print(f"  - SK: DIM_DATE#SALES_ORDER_NUMBER")
    print(f"  - GSI1: Time-based (Monthly)")
    print(f"  - GSI2: Site-based")
    print(f"  - GSI3: Geography-based")
    print(f"  - GSI4: Site Type + First Dose")
    print(f"  - GSI5: Order Status + Geography")
    print(f"  - GSI6: Account Status + Site Attributes")
    print()
    
    # Create table with 6 GSIs
    table = get_or_create_table(dynamodb, table_name, with_gsi=True, gsi_count=6)
    
    # Load CSV data
    print("Loading CSV data...")
    csv_file = find_csv_file('ROME')
    print(f"  Using CSV file: {csv_file}")
    df = pd.read_csv(csv_file)
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df):,}")
    print()
    
    # Columns to preserve case (not uppercase)
    preserve_case_columns = {
        'dim_order_status',  # Has mixed case like "Delivered", "Late Delivery"
        'dim_order_type',  # Has "Commercial - PRD", "Medical affairs"
        'order_status_customer',  # Customer-facing status
        'cancellation_unused_dose_reason',
        'cancellation_unused_dose_other_reason'
    }
    
    # Prepare batches
    inserted_count = 0
    batch_size = 25
    batches = []
    current_batch = []
    
    print("  Preparing batches...")
    for idx, row in df.iterrows():
        # Convert all CSV columns to DynamoDB item
        item = {}
        for col in df.columns:
            value = convert_to_dynamodb_format(row[col])
            if value is not None:
                # Preserve case for specific columns, uppercase others
                if isinstance(value, str) and col not in preserve_case_columns:
                    item[col] = value.upper()
                else:
                    item[col] = value
        
        # Extract values for keys
        product = str(row['PRODUCT']).upper()
        site_id = str(row['site_id'])
        dim_date = row['dim_date']
        sales_order_number = str(row['sales_order_number'])
        
        # Geography
        dim_terr_name = str(row['dim_terr_name']).upper()
        dim_area_name = str(row['dim_area_name']).upper()
        dim_region_name = str(row['dim_region_name']).upper()
        
        # Site attributes
        dim_site_type = str(row['dim_site_type']).upper() if pd.notna(row['dim_site_type']) else 'NULL'
        dim_ecosystem = str(row['dim_ecosystem']) if pd.notna(row['dim_ecosystem']) else 'NULL'
        dim_account_status = str(row['dim_account_status']).upper() if pd.notna(row['dim_account_status']) else 'NULL'
        active_dormant_flag = str(row['active_dormant_flag']).upper() if pd.notna(row['active_dormant_flag']) else 'NULL'
        dim_tier = str(row['dim_tier']) if pd.notna(row['dim_tier']) else 'NULL'
        
        # Order attributes
        dim_order_status = str(row['dim_order_status'])  # Preserve case
        is_patients_first_dose = str(row['is_patients_first_dose']).upper()
        year_quarter = str(row['year_quarter'])
        cycle_rel_index = int(row['cycle_rel_index'])
        
        # Primary Key - Add row index to prevent duplicates in CSV
        item['PK'] = f"{product}#{site_id}"
        item['SK'] = f"{dim_date.strftime('%Y-%m-%d')}#{sales_order_number}#{idx}"  # Add idx for uniqueness
        
        # GSI1: Time-based queries (Monthly)
        item['GSI1PK'] = f"DATE#{dim_date.strftime('%Y-%m')}"
        item['GSI1SK'] = f"{product}#{site_id}#{is_patients_first_dose}"
        
        # GSI2: Site-based queries
        item['GSI2PK'] = f"SITE#{site_id}"
        item['GSI2SK'] = f"{year_quarter}#{dim_order_status}"
        
        # GSI3: Geography-based queries
        item['GSI3PK'] = f"TERRITORY#{dim_terr_name}"
        item['GSI3SK'] = f"{year_quarter}#{dim_site_type}"
        
        # GSI4: Site Type + First Dose (NEW PATIENT STARTS) - ORIGINAL STRUCTURE
        item['GSI4PK'] = f"{dim_site_type}#{is_patients_first_dose}"
        item['GSI4SK'] = f"{year_quarter}#{dim_ecosystem}"
        
        # GSI5: Order Status + Geography (SHIPPED DOSES)
        item['GSI5PK'] = f"{dim_order_status}#TERRITORY#{dim_terr_name}"
        item['GSI5SK'] = f"{year_quarter}#{cycle_rel_index}"
        
        # GSI6: Account Status + Site Attributes (FIXED: Added year to SK for performance)
        item['GSI6PK'] = f"{dim_account_status}#{active_dormant_flag}"
        # Extract year from year_quarter (e.g., "2025 Q4" -> "2025")
        year_only = year_quarter.split()[0] if year_quarter and ' ' in year_quarter else year_quarter
        item['GSI6SK'] = f"{year_only}#{dim_site_type}#{dim_ecosystem}#{dim_tier}"
        
        current_batch.append(item)
        
        if len(current_batch) >= batch_size:
            batches.append(current_batch)
            current_batch = []
    
    # Add remaining items
    if current_batch:
        batches.append(current_batch)
    
    print(f"  Created {len(batches):,} batches of {batch_size} items each")
    print(f"  Writing with 20 parallel threads...")
    
    # Write batches in parallel with retry logic
    lock = threading.Lock()
    
    def write_batch(batch_items):
        from botocore.config import Config
        thread_config = Config(
            max_pool_connections=20,
            retries={'max_attempts': 10, 'mode': 'adaptive'}
        )
        thread_dynamodb = boto3.resource('dynamodb', region_name='us-east-1', config=thread_config)
        thread_table = thread_dynamodb.Table(table_name)
        
        max_retries = 5
        for attempt in range(max_retries):
            try:
                with thread_table.batch_writer() as batch:
                    for item in batch_items:
                        batch.put_item(Item=item)
                return len(batch_items)
            except ClientError as e:
                if e.response['Error']['Code'] == 'ThrottlingException' and attempt < max_retries - 1:
                    wait_time = (2 ** attempt) + random.uniform(0, 1)
                    time.sleep(wait_time)
                else:
                    raise
    
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(write_batch, batch): i for i, batch in enumerate(batches)}
        
        for future in as_completed(futures):
            count = future.result()
            with lock:
                inserted_count += count
                if inserted_count % 5000 < batch_size:
                    print(f"  Inserted {inserted_count:,} records...")
    
    print(f"\n✓ Successfully inserted {inserted_count:,} records into {table_name}")
    print(f"✓ Table is idempotent - can reload data anytime without duplicates")
    print(f"✓ All 6 GSIs created for fast queries (<2 seconds)")
    return table



# ============================================================================
# ROME AGGREGATED TABLE CREATION
# ============================================================================

def create_new_patient_starts_table(dynamodb, version='v6_final'):
    """
    Create Rome_NewPatientStarts_Monthly table
    
    Purpose: Fast queries for new patient start questions (Q1-Q4, Q8, Q17)
    Expected Records: ~10,000
    Expected Query Time: <1s
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Rome_NewPatientStarts_Monthly_{version}'
    
    print(f"\n{'='*80}")
    print(f"Creating table: {table_name}")
    print(f"{'='*80}")
    
    try:
        # Check if table exists
        table = dynamodb.Table(table_name)
        table.load()
        print(f"✓ Table already exists: {table_name}")
        return table
    except dynamodb.meta.client.exceptions.ResourceNotFoundException:
        pass
    
    # Create table
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'PK', 'KeyType': 'HASH'},
            {'AttributeName': 'SK', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'PK', 'AttributeType': 'S'},
            {'AttributeName': 'SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2SK', 'AttributeType': 'S'},
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            },
            {
                'IndexName': 'GSI2',
                'KeySchema': [
                    {'AttributeName': 'GSI2PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI2SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            }
        ],
        BillingMode='PAY_PER_REQUEST'
    )
    
    print("Waiting for table to be created...")
    table.wait_until_exists()
    print(f"✓ Table created: {table_name}")
    
    print("\n📋 Table Structure:")
    print("  PK: PRODUCT#{PRODUCT}")
    print("  SK: YEAR#{YEAR}#MONTH#{MONTH}#SITE_TYPE#{SITE_TYPE}#TERRITORY#{TERRITORY}")
    print("  GSI1PK: YEAR#{YEAR}")
    print("  GSI1SK: MONTH#{MONTH}#SITE_TYPE#{SITE_TYPE}")
    print("  GSI2PK: YEAR#{YEAR}#QUARTER#{QUARTER}")
    print("  GSI2SK: SITE_TYPE#{SITE_TYPE}#ECOSYSTEM#{ECOSYSTEM}")
    
    return table


def create_new_patient_orders_table(dynamodb, version='v6_final'):
    """
    Create Rome_NewPatientOrders_Monthly table
    
    Purpose: Fast queries for new patient orders questions (Q6, Q7)
    Expected Records: ~21,000
    Expected Query Time: <1s
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Rome_NewPatientOrders_Monthly_{version}'
    
    print(f"\n{'='*80}")
    print(f"Creating table: {table_name}")
    print(f"{'='*80}")
    
    try:
        table = dynamodb.Table(table_name)
        table.load()
        print(f"✓ Table already exists: {table_name}")
        return table
    except dynamodb.meta.client.exceptions.ResourceNotFoundException:
        pass
    
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'PK', 'KeyType': 'HASH'},
            {'AttributeName': 'SK', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'PK', 'AttributeType': 'S'},
            {'AttributeName': 'SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2SK', 'AttributeType': 'S'},
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            },
            {
                'IndexName': 'GSI2',
                'KeySchema': [
                    {'AttributeName': 'GSI2PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI2SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            }
        ],
        BillingMode='PAY_PER_REQUEST'
    )
    
    print("Waiting for table to be created...")
    table.wait_until_exists()
    print(f"✓ Table created: {table_name}")
    
    print("\n📋 Table Structure:")
    print("  PK: PRODUCT#{PRODUCT}")
    print("  SK: YEAR#{YEAR}#MONTH#{MONTH}#SITE_TYPE#{SITE_TYPE}#TERRITORY#{TERRITORY}")
    print("  GSI1PK: YEAR#{YEAR}")
    print("  GSI1SK: MONTH#{MONTH}#SITE_TYPE#{SITE_TYPE}")
    print("  GSI2PK: YEAR#{YEAR}#QUARTER#{QUARTER}")
    print("  GSI2SK: SITE_TYPE#{SITE_TYPE}#ECOSYSTEM#{ECOSYSTEM}")
    
    return table


def create_all_orders_table(dynamodb, version='v6_final'):
    """
    Create Rome_AllOrders_Monthly table
    
    Purpose: Fast queries for all orders questions (Q5-Q7, Q9, Q14-Q16)
    Expected Records: ~12,000
    Expected Query Time: <1s
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Rome_AllOrders_Monthly_{version}'
    
    print(f"\n{'='*80}")
    print(f"Creating table: {table_name}")
    print(f"{'='*80}")
    
    try:
        table = dynamodb.Table(table_name)
        table.load()
        print(f"✓ Table already exists: {table_name}")
        return table
    except dynamodb.meta.client.exceptions.ResourceNotFoundException:
        pass
    
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'PK', 'KeyType': 'HASH'},
            {'AttributeName': 'SK', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'PK', 'AttributeType': 'S'},
            {'AttributeName': 'SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2SK', 'AttributeType': 'S'},
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            },
            {
                'IndexName': 'GSI2',
                'KeySchema': [
                    {'AttributeName': 'GSI2PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI2SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            }
        ],
        BillingMode='PAY_PER_REQUEST'
    )
    
    print("Waiting for table to be created...")
    table.wait_until_exists()
    print(f"✓ Table created: {table_name}")
    
    print("\n📋 Table Structure:")
    print("  PK: PRODUCT#{PRODUCT}")
    print("  SK: YEAR#{YEAR}#MONTH#{MONTH}#SITE#{SITE_ID}")
    print("  GSI1PK: YEAR#{YEAR}")
    print("  GSI1SK: MONTH#{MONTH}#TERRITORY#{TERRITORY}")
    print("  GSI2PK: YEAR#{YEAR}#QUARTER#{QUARTER}")
    print("  GSI2SK: SITE#{SITE_ID}")
    
    return table


def create_site_status_table(dynamodb, version='v6_final'):
    """
    Create Rome_SiteStatus_Quarterly table
    
    Purpose: Fast queries for site status questions (Q10-Q13)
    Expected Records: ~4,000
    Expected Query Time: <1s
    
    Args:
        dynamodb: DynamoDB resource
        version: Table version suffix (default: 'v6_final')
    """
    table_name = f'Rome_SiteStatus_Quarterly_{version}'
    
    print(f"\n{'='*80}")
    print(f"Creating table: {table_name}")
    print(f"{'='*80}")
    
    try:
        table = dynamodb.Table(table_name)
        table.load()
        print(f"✓ Table already exists: {table_name}")
        return table
    except dynamodb.meta.client.exceptions.ResourceNotFoundException:
        pass
    
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'PK', 'KeyType': 'HASH'},
            {'AttributeName': 'SK', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'PK', 'AttributeType': 'S'},
            {'AttributeName': 'SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI2SK', 'AttributeType': 'S'},
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            },
            {
                'IndexName': 'GSI2',
                'KeySchema': [
                    {'AttributeName': 'GSI2PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI2SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            }
        ],
        BillingMode='PAY_PER_REQUEST'
    )
    
    print("Waiting for table to be created...")
    table.wait_until_exists()
    print(f"✓ Table created: {table_name}")
    
    print("\n📋 Table Structure:")
    print("  PK: PRODUCT#{PRODUCT}")
    print("  SK: YEAR#{YEAR}#QUARTER#{QUARTER}#SITE#{SITE_ID}")
    print("  GSI1PK: YEAR#{YEAR}#QUARTER#{QUARTER}")
    print("  GSI1SK: ACCOUNT_STATUS#{STATUS}#ACTIVE_DORMANT#{FLAG}")
    print("  GSI2PK: YEAR#{YEAR}")
    print("  GSI2SK: SITE#{SITE_ID}")
    
    return table



# ============================================================================
# ROME AGGREGATION FUNCTIONS
# ============================================================================

def scan_rome_table(version='v6_final'):
    """Scan entire Rome table and return all records
    
    Args:
        version: Table version suffix (default: 'v6_final')
    """
    print("📊 Scanning Rome table...", flush=True)
    
    # Get Rome table reference - use dynamic version
    rome_table = dynamodb.Table(f'Novartis_Rome_{version}')
    
    items = []
    
    response = rome_table.scan()
    items.extend(response.get('Items', []))
    
    while 'LastEvaluatedKey' in response:
        response = rome_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response.get('Items', []))
        print(f"   Scanned {len(items):,} records...", flush=True)
    
    print(f"✅ Scanned {len(items):,} total records", flush=True)
    return items


def aggregate_new_patient_starts(raw_data):
    """
    Aggregate new patient starts by month - PRE-COMPUTED COUNTS VERSION
    
    Dimensions: Year, Quarter, Month, Site Type, Territory, Area, Region, Ecosystem, Tier
    Filters: is_first_dose = TRUE, order_status IN (Delivered, Late Delivery)
    
    OPTIMIZATION: Stores only unique_order_count (not order_list)
    """
    print("\n📈 Aggregating new patient starts (pre-computed counts)...", flush=True)
    
    # Filter for new patient starts (delivered doses only, ALL order types)
    new_patient_data = [
        r for r in raw_data
        if r.get('is_patients_first_dose') == 'TRUE' 
        and r.get('dim_order_status') in ['Delivered', 'Late Delivery']
    ]
    
    print(f"   Filtered to {len(new_patient_data):,} new patient start records", flush=True)
    
    # Aggregate by dimensions
    aggregates = defaultdict(lambda: {
        'new_patient_count': 0,
        'unique_sites': set(),
        'unique_orders': set()  # Set for deduplication during aggregation
    })
    
    for record in new_patient_data:
        # Extract dimensions
        product = record.get('PRODUCT', 'PLUVICTO')
        year_quarter = record.get('year_quarter', '')
        year = year_quarter.split()[0] if year_quarter and ' ' in year_quarter else year_quarter
        quarter = year_quarter.split()[1] if year_quarter and ' ' in year_quarter else ''
        
        # Extract month from dim_date
        dim_date = record.get('dim_date', '')
        if isinstance(dim_date, str) and len(dim_date) >= 7:
            month = int(dim_date[5:7])
        else:
            continue
        
        site_type = record.get('dim_site_type', 'NULL')
        territory = record.get('dim_terr_name', 'NULL')
        area = record.get('dim_area_name', 'NULL')
        region = record.get('dim_region_name', 'NULL')
        ecosystem = record.get('dim_ecosystem', 'NULL')
        tier = record.get('dim_tier', 'NULL')
        
        site_id = record.get('site_id', 'NULL')
        sales_order = record.get('sales_order_number', 'NULL')
        
        # Create aggregation key
        key = (product, year, quarter, month, site_type, territory, area, region, ecosystem, tier)
        
        # Aggregate - deduplication happens here via set
        aggregates[key]['new_patient_count'] += 1
        aggregates[key]['unique_sites'].add(site_id)
        aggregates[key]['unique_orders'].add(sales_order)
    
    # Convert to DynamoDB records
    records = []
    for idx, (key, metrics) in enumerate(aggregates.items()):
        product, year, quarter, month, site_type, territory, area, region, ecosystem, tier = key
        
        record = {
            'PK': f"PRODUCT#{product}",
            'SK': f"YEAR#{year}#MONTH#{month:02d}#SITE_TYPE#{site_type}#TERRITORY#{territory}#AREA#{area}#REGION#{region}#ECOSYSTEM#{ecosystem}#TIER#{tier}#IDX#{idx}",
            
            # Dimensions
            'product': product,
            'year': int(year) if year.isdigit() else 0,
            'quarter': quarter,
            'month': month,
            'year_quarter': f"{year} {quarter}",
            'site_type': site_type,
            'territory': territory,
            'area': area,
            'region': region,
            'ecosystem': ecosystem,
            'tier': tier,
            
            # Metrics - Keep order_list for Q1-Q4 deduplication needs
            'unique_order_count': Decimal(str(len(metrics['unique_orders']))),  # Pre-computed deduplicated count
            'unique_sites': Decimal(str(len(metrics['unique_sites']))),
            'order_list': list(metrics['unique_orders']),  # KEEP for cross-dimension deduplication in Q1-Q4
            
            # Metadata
            'aggregation_type': 'NEW_PATIENT_STARTS',
            'last_updated': datetime.now().isoformat()
        }
        
        # GSI keys for fast queries
        record['GSI1PK'] = f"YEAR#{year}"
        record['GSI1SK'] = f"MONTH#{month:02d}#SITE_TYPE#{site_type}"
        
        record['GSI2PK'] = f"YEAR#{year}#QUARTER#{quarter}"
        record['GSI2SK'] = f"SITE_TYPE#{site_type}#ECOSYSTEM#{ecosystem}"
        
        records.append(record)
    
    print(f"✅ Generated {len(records):,} aggregated records", flush=True)
    return records


def aggregate_new_patient_orders(raw_data):
    """
    Aggregate new patient orders by month (ALL order statuses) - PRE-COMPUTED COUNTS VERSION
    
    OPTIMIZATION: Stores only unique_order_count (not order_list)
    """
    print("\n📈 Aggregating new patient orders (pre-computed counts)...", flush=True)
    
    # Filter for new patient orders (all statuses)
    new_patient_orders = [
        r for r in raw_data
        if r.get('is_patients_first_dose') == 'TRUE' 
        and r.get('dim_order_status') in ['Delivered', 'Late Delivery', 'Open', 'Cancelled']
        and r.get('dim_order_type') in ['Commercial', 'Commercial - PRD']
    ]
    
    print(f"   Filtered to {len(new_patient_orders):,} new patient order records", flush=True)
    
    # Aggregate by dimensions
    aggregates = defaultdict(lambda: {
        'new_patient_count': 0,
        'unique_sites': set(),
        'unique_orders': set()
    })
    
    for record in new_patient_orders:
        # Extract dimensions
        product = record.get('PRODUCT', 'PLUVICTO')
        year_quarter = record.get('year_quarter', '')
        year = year_quarter.split()[0] if year_quarter and ' ' in year_quarter else year_quarter
        quarter = year_quarter.split()[1] if year_quarter and ' ' in year_quarter else ''
        
        # Extract month from dim_date
        dim_date = record.get('dim_date', '')
        if isinstance(dim_date, str) and len(dim_date) >= 7:
            month = int(dim_date[5:7])
        else:
            continue
        
        site_type = record.get('dim_site_type', 'NULL')
        territory = record.get('dim_terr_name', 'NULL')
        area = record.get('dim_area_name', 'NULL')
        region = record.get('dim_region_name', 'NULL')
        ecosystem = record.get('dim_ecosystem', 'NULL')
        tier = record.get('dim_tier', 'NULL')
        
        site_id = record.get('site_id', 'NULL')
        sales_order = record.get('sales_order_number', 'NULL')
        
        # Create aggregation key
        key = (product, year, quarter, month, site_type, territory, area, region, ecosystem, tier)
        
        # Aggregate
        aggregates[key]['new_patient_count'] += 1
        aggregates[key]['unique_sites'].add(site_id)
        aggregates[key]['unique_orders'].add(sales_order)
    
    # Convert to DynamoDB records
    records = []
    for idx, (key, metrics) in enumerate(aggregates.items()):
        product, year, quarter, month, site_type, territory, area, region, ecosystem, tier = key
        
        record = {
            'PK': f"PRODUCT#{product}",
            'SK': f"YEAR#{year}#MONTH#{month:02d}#SITE_TYPE#{site_type}#TERRITORY#{territory}#AREA#{area}#REGION#{region}#ECOSYSTEM#{ecosystem}#TIER#{tier}#IDX#{idx}",
            
            # Dimensions
            'product': product,
            'year': int(year) if year.isdigit() else 0,
            'quarter': quarter,
            'month': month,
            'year_quarter': f"{year} {quarter}",
            'site_type': site_type,
            'territory': territory,
            'area': area,
            'region': region,
            'ecosystem': ecosystem,
            'tier': tier,
            
            # Metrics - Keep order_list for Q7 deduplication needs
            'unique_order_count': Decimal(str(len(metrics['unique_orders']))),
            'unique_sites': Decimal(str(len(metrics['unique_sites']))),
            'order_list': list(metrics['unique_orders']),  # KEEP for cross-dimension deduplication in Q7
            
            # Metadata
            'aggregation_type': 'NEW_PATIENT_ORDERS',
            'last_updated': datetime.now().isoformat()
        }
        
        # GSI keys for fast queries
        record['GSI1PK'] = f"YEAR#{year}"
        record['GSI1SK'] = f"MONTH#{month:02d}#SITE_TYPE#{site_type}"
        
        record['GSI2PK'] = f"YEAR#{year}#QUARTER#{quarter}"
        record['GSI2SK'] = f"SITE_TYPE#{site_type}#ECOSYSTEM#{ecosystem}"
        
        records.append(record)
    
    print(f"✅ Generated {len(records):,} aggregated records", flush=True)
    return records


def aggregate_all_orders(raw_data):
    """
    Aggregate all orders by month and site - PRE-COMPUTED COUNTS VERSION
    
    OPTIMIZATION: Stores only counts (not lists):
    - unique_order_count (all statuses)
    - delivered_order_count (delivered/late delivery only)
    - new_patient_order_count
    - repeat_patient_order_count
    """
    print("\n📈 Aggregating all orders (pre-computed counts)...", flush=True)
    
    delivered_data = raw_data  # All records, no filtering
    
    print(f"   Processing {len(delivered_data):,} order records", flush=True)
    
    # Aggregate by dimensions
    aggregates = defaultdict(lambda: {
        'order_count': 0,
        'new_patient_count': 0,
        'repeat_patient_count': 0,
        'unique_orders': set(),
        'new_patient_orders': set(),
        'repeat_patient_orders': set(),
        'delivered_orders': set()
    })
    
    for record in delivered_data:
        # Extract dimensions
        product = record.get('PRODUCT', 'PLUVICTO')
        year_quarter = record.get('year_quarter', '')
        year = year_quarter.split()[0] if year_quarter and ' ' in year_quarter else year_quarter
        quarter = year_quarter.split()[1] if year_quarter and ' ' in year_quarter else ''
        
        # Extract month from dim_date
        dim_date = record.get('dim_date', '')
        if isinstance(dim_date, str) and len(dim_date) >= 7:
            month = int(dim_date[5:7])
        else:
            continue
        
        site_id = record.get('site_id', 'NULL')
        site_type = record.get('dim_site_type', 'NULL')
        territory = record.get('dim_terr_name', 'NULL')
        area = record.get('dim_area_name', 'NULL')
        region = record.get('dim_region_name', 'NULL')
        ecosystem = record.get('dim_ecosystem', 'NULL')
        tier = record.get('dim_tier', 'NULL')
        
        is_first_dose = record.get('is_patients_first_dose', 'FALSE')
        order_status = record.get('dim_order_status', 'NULL')
        sales_order = record.get('sales_order_number', 'NULL')
        
        # Create aggregation key - ONLY site + month
        key = (product, year, quarter, month, site_id)
        
        # Aggregate
        aggregates[key]['order_count'] += 1
        aggregates[key]['unique_orders'].add(sales_order)
        
        # Track delivered orders separately (for Q5, Q6)
        if order_status in ['Delivered', 'Late Delivery']:
            aggregates[key]['delivered_orders'].add(sales_order)
        
        # Store site attributes (take first occurrence)
        if 'site_type' not in aggregates[key]:
            aggregates[key]['site_type'] = site_type
            aggregates[key]['territory'] = territory
            aggregates[key]['area'] = area
            aggregates[key]['region'] = region
            aggregates[key]['ecosystem'] = ecosystem
            aggregates[key]['tier'] = tier
        
        # Track new vs repeat patient orders
        if is_first_dose == 'TRUE':
            aggregates[key]['new_patient_count'] += 1
            aggregates[key]['new_patient_orders'].add(sales_order)
        else:
            aggregates[key]['repeat_patient_count'] += 1
            aggregates[key]['repeat_patient_orders'].add(sales_order)
    
    # Convert to DynamoDB records
    records = []
    for idx, (key, metrics) in enumerate(aggregates.items()):
        product, year, quarter, month, site_id = key
        
        record = {
            'PK': f"PRODUCT#{product}",
            'SK': f"YEAR#{year}#MONTH#{month:02d}#SITE#{site_id}#IDX#{idx}",
            
            # Dimensions
            'product': product,
            'year': int(year) if year.isdigit() else 0,
            'quarter': quarter,
            'month': month,
            'year_quarter': f"{year} {quarter}",
            'site_id': site_id,
            'site_type': metrics.get('site_type', 'NULL'),
            'territory': metrics.get('territory', 'NULL'),
            'area': metrics.get('area', 'NULL'),
            'region': metrics.get('region', 'NULL'),
            'ecosystem': metrics.get('ecosystem', 'NULL'),
            'tier': metrics.get('tier', 'NULL'),
            
            # Metrics - ONLY COUNTS (no lists)
            'unique_order_count': Decimal(str(len(metrics['unique_orders']))),  # All statuses
            'delivered_order_count': Decimal(str(len(metrics['delivered_orders']))),  # Delivered only
            'new_patient_order_count': Decimal(str(len(metrics['new_patient_orders']))),
            'repeat_patient_order_count': Decimal(str(len(metrics['repeat_patient_orders']))),
            
            # Metadata
            'aggregation_type': 'ALL_ORDERS',
            'last_updated': datetime.now().isoformat()
        }
        
        # GSI keys
        record['GSI1PK'] = f"YEAR#{year}"
        record['GSI1SK'] = f"MONTH#{month:02d}#TERRITORY#{metrics.get('territory', 'NULL')}"
        
        record['GSI2PK'] = f"YEAR#{year}#QUARTER#{quarter}"
        record['GSI2SK'] = f"SITE#{site_id}"
        
        records.append(record)
    
    print(f"✅ Generated {len(records):,} aggregated records", flush=True)
    return records


def aggregate_site_status(raw_data):
    """
    Aggregate site status by quarter - PRE-COMPUTED COUNTS VERSION
    
    OPTIMIZATION: Stores only counts (not lists):
    - unique_order_count
    - new_patient_order_count
    - delivered_order_count
    """
    print("\n📈 Aggregating site status (pre-computed counts)...", flush=True)
    
    # Aggregate by dimensions
    aggregates = defaultdict(lambda: {
        'order_count': 0,
        'new_patient_count': 0,
        'delivered_count': 0,
        'unique_orders': set(),
        'new_patient_orders': set(),
        'delivered_orders': set()
    })
    
    for record in raw_data:
        # Extract dimensions
        product = record.get('PRODUCT', 'PLUVICTO')
        year_quarter = record.get('year_quarter', '')
        year = year_quarter.split()[0] if year_quarter and ' ' in year_quarter else year_quarter
        quarter = year_quarter.split()[1] if year_quarter and ' ' in year_quarter else ''
        
        site_id = record.get('site_id', 'NULL')
        site_type = record.get('dim_site_type', 'NULL')
        account_status = record.get('dim_account_status', 'NULL')
        active_dormant = record.get('active_dormant_flag', 'NULL')
        ecosystem = record.get('dim_ecosystem', 'NULL')
        tier = record.get('dim_tier', 'NULL')
        territory = record.get('dim_terr_name', 'NULL')
        area = record.get('dim_area_name', 'NULL')
        region = record.get('dim_region_name', 'NULL')
        
        is_first_dose = record.get('is_patients_first_dose', 'FALSE')
        order_status = record.get('dim_order_status', 'NULL')
        sales_order = record.get('sales_order_number', 'NULL')
        
        # Create aggregation key - ONLY site + quarter
        key = (product, year, quarter, site_id)
        
        # Aggregate
        aggregates[key]['order_count'] += 1
        aggregates[key]['unique_orders'].add(sales_order)
        
        # Store site attributes (take first occurrence, update for priority values)
        if 'site_type' not in aggregates[key]:
            aggregates[key]['site_type'] = site_type
            aggregates[key]['account_status'] = account_status
            aggregates[key]['active_dormant'] = active_dormant
            aggregates[key]['ecosystem'] = ecosystem
            aggregates[key]['tier'] = tier
            aggregates[key]['territory'] = territory
            aggregates[key]['area'] = area
            aggregates[key]['region'] = region
        else:
            # Update account_status priority: NOT ONBOARDED > ONBOARDED > NULL
            current_status = aggregates[key].get('account_status', 'NULL')
            if account_status == 'NOT ONBOARDED' or (account_status == 'ONBOARDED' and current_status == 'NULL'):
                aggregates[key]['account_status'] = account_status
            
            # Update active_dormant priority: DORMANT > ACTIVE > NULL
            current_dormant = aggregates[key].get('active_dormant', 'NULL')
            if active_dormant == 'DORMANT' or (active_dormant == 'ACTIVE' and current_dormant == 'NULL'):
                aggregates[key]['active_dormant'] = active_dormant
        
        if is_first_dose == 'TRUE':
            aggregates[key]['new_patient_count'] += 1
            aggregates[key]['new_patient_orders'].add(sales_order)
        
        if order_status == 'Delivered':
            aggregates[key]['delivered_count'] += 1
            aggregates[key]['delivered_orders'].add(sales_order)
    
    # Convert to DynamoDB records
    records = []
    for idx, (key, metrics) in enumerate(aggregates.items()):
        product, year, quarter, site_id = key
        
        record = {
            'PK': f"PRODUCT#{product}",
            'SK': f"YEAR#{year}#QUARTER#{quarter}#SITE#{site_id}#IDX#{idx}",
            
            # Dimensions
            'product': product,
            'year': int(year) if year.isdigit() else 0,
            'quarter': quarter,
            'year_quarter': f"{year} {quarter}",
            'site_id': site_id,
            'site_type': metrics.get('site_type', 'NULL'),
            'account_status': metrics.get('account_status', 'NULL'),
            'active_dormant': metrics.get('active_dormant', 'NULL'),
            'ecosystem': metrics.get('ecosystem', 'NULL'),
            'tier': metrics.get('tier', 'NULL'),
            'territory': metrics.get('territory', 'NULL'),
            'area': metrics.get('area', 'NULL'),
            'region': metrics.get('region', 'NULL'),
            
            # Metrics - ONLY COUNTS (no lists)
            'unique_order_count': Decimal(str(len(metrics['unique_orders']))),
            'new_patient_order_count': Decimal(str(len(metrics['new_patient_orders']))),
            'delivered_order_count': Decimal(str(len(metrics['delivered_orders']))),
            
            # Metadata
            'aggregation_type': 'SITE_STATUS',
            'last_updated': datetime.now().isoformat()
        }
        
        # GSI keys
        record['GSI1PK'] = f"YEAR#{year}#QUARTER#{quarter}"
        record['GSI1SK'] = f"ACCOUNT_STATUS#{metrics.get('account_status', 'NULL')}#ACTIVE_DORMANT#{metrics.get('active_dormant', 'NULL')}"
        
        record['GSI2PK'] = f"YEAR#{year}"
        record['GSI2SK'] = f"SITE#{site_id}"
        
        records.append(record)
    
    print(f"✅ Generated {len(records):,} aggregated records", flush=True)
    return records


def write_to_table(table_name, records, batch_size=25):
    """Write aggregated records to DynamoDB table with parallel processing"""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    import threading
    
    print(f"\n💾 Writing {len(records):,} records to {table_name}...", flush=True)
    
    table = dynamodb.Table(table_name)
    written = 0
    lock = threading.Lock()
    
    def write_batch(batch_records):
        """Write a batch of records"""
        with table.batch_writer() as writer:
            for record in batch_records:
                writer.put_item(Item=record)
        return len(batch_records)
    
    # Split records into batches
    batches = [records[i:i + batch_size] for i in range(0, len(records), batch_size)]
    
    # Write batches in parallel (10 threads)
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(write_batch, batch): batch for batch in batches}
        
        for future in as_completed(futures):
            try:
                count = future.result()
                with lock:
                    written += count
                    if written % 500 == 0:
                        print(f"   Written {written:,} records...", flush=True)
            except Exception as e:
                print(f"   ⚠️  Error writing batch: {e}", flush=True)
    
    print(f"✅ Successfully written {written:,} records to {table_name}", flush=True)

