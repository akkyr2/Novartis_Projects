#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Load All Novartis MBR Tables to DynamoDB
Combines create_dynamodb_tables.py and upload_to_dynamodb.py approaches
Uses normalized columns for Sales/Market/Doses and raw CSV columns for Calls/Rome
This matches the mo-nov profile data structure exactly
"""

import boto3
import pandas as pd
import json
from decimal import Decimal
from datetime import datetime
import time
import argparse

def convert_to_dynamodb_format(value):
    """Convert pandas values to DynamoDB compatible format"""
    if pd.isna(value):
        return None
    elif isinstance(value, (int, float)):
        return Decimal(str(value))
    elif isinstance(value, datetime):
        return value.isoformat()
    elif isinstance(value, pd.Timestamp):
        return value.isoformat()
    else:
        return str(value)

def get_or_create_table(dynamodb, table_name, with_gsi=False):
    """Get existing table or create if it doesn't exist"""
    
    try:
        # Try to get existing table
        table = dynamodb.Table(table_name)
        table.load()  # This will raise an exception if table doesn't exist
        print(f"✓ Using existing table: {table_name}")
        return table
    except dynamodb.meta.client.exceptions.ResourceNotFoundException:
        # Table doesn't exist, create it
        print(f"Creating new table: {table_name}")
        
        # Base table configuration
        table_config = {
            'TableName': table_name,
            'KeySchema': [
                {'AttributeName': 'PK', 'KeyType': 'HASH'},  # Partition key
                {'AttributeName': 'SK', 'KeyType': 'RANGE'}  # Sort key
            ],
            'AttributeDefinitions': [
                {'AttributeName': 'PK', 'AttributeType': 'S'},
                {'AttributeName': 'SK', 'AttributeType': 'S'},
            ],
            'BillingMode': 'PAY_PER_REQUEST'  # Match CDK billing mode
        }
        
        # Add GSI if needed (for Sales, Market, Doses tables)
        if with_gsi:
            table_config['AttributeDefinitions'].extend([
                {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
                {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
            ])
            table_config['GlobalSecondaryIndexes'] = [{
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'}
            }]
        
        table = dynamodb.create_table(**table_config)
        
        # Wait for table to be created
        print("Waiting for table to be created...")
        table.wait_until_exists()
        print("✓ Table created")
        
        return table

def load_sales_finance_table(dynamodb):
    """Load Sales Finance table (normalized approach)"""
    table_name = 'Novartis_Sales_Finance'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Sales Finance has GSI
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/SALES_FINANCE_BPC_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                # Primary Key: PRODUCT#ProductName#FORECAST#ForecastType
                'PK': f"PRODUCT#{row['DIM_Brand']}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{row['DIM_forecast']}",
                
                # GSI1: Query by date and forecast type (matches mo-nov profile)
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"PRODUCT#{row['DIM_Brand']}#FORECAST#{row['DIM_forecast']}",
                
                # Attributes (normalized names)
                'product': str(row['PRODUCT']),
                'brand': str(row['DIM_Brand']),
                'forecast_type': str(row['DIM_forecast']),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'net_sales': convert_to_dynamodb_format(row['net_sales']),
                'gross_sales': convert_to_dynamodb_format(row['gross_sales']),
                'revenue_deductions': convert_to_dynamodb_format(row['revenue_deductions']),
                'source': str(row['source']),
                'data_frequency': str(row['data_frequency']),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'year_quarter': str(row['year_quarter']),
                'last_altered': str(row['last_altered']),
                'entity_type': 'SALES'
            }
            
            # Remove None values
            item = {k: v for k, v in item.items() if v is not None}
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_market_share_table(dynamodb):
    """Load Market Share table (normalized approach)"""
    table_name = 'Novartis_Market_Share'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Market Share has GSI
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_MARKET_PLU_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                'PK': f"BRAND#{row['DIM_Brand']}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}",
                
                # GSI1: Query by date (matches mo-nov profile)
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{row['DIM_Brand']}",
                
                # Normalized attributes
                'brand': str(row['DIM_Brand']),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'trx_r3m': convert_to_dynamodb_format(row.get('TRX_R3M')),
                'trx_share_r3m': convert_to_dynamodb_format(row['TRX_SHARE_R3M']),
                'nbrx_r3m': convert_to_dynamodb_format(row.get('NBRX_R3M')),
                'nbrx_share_r3m': convert_to_dynamodb_format(row['NBRX_SHARE_R3M']),
                'product': str(row.get('PRODUCT', '')),
                'class': str(row.get('Class', '')),
                'class_aggregated': str(row.get('class_aggregated', '')),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'year_quarter': str(row['year_quarter']),
                'entity_type': 'MARKET_SHARE'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_doses_table(dynamodb):
    """Load Doses table (normalized approach)"""
    table_name = 'Novartis_Doses'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=True)  # Doses has GSI
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_DOSES_PLU_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                'PK': f"BRAND#{row['DIM_Brand']}#METRIC#{row['metric']}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{row['dim_forecast']}",
                
                # GSI1: Query by date (matches mo-nov profile)
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{row['DIM_Brand']}#METRIC#{row['metric']}#FORECAST#{row['dim_forecast']}",
                
                # Normalized attributes
                'brand': str(row['DIM_Brand']),
                'metric': str(row['metric']),
                'forecast_type': str(row['dim_forecast']),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'value': convert_to_dynamodb_format(row['value']),
                'product': str(row.get('PRODUCT', '')),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'quarter_rel_index': int(row.get('quarter_rel_index', 0)),
                'entity_type': 'DOSES'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_calls_table(dynamodb):
    """Load Calls table (raw CSV approach)"""
    table_name = 'Novartis_Calls'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=False)  # Calls has NO GSI
    
    # Load CSV data (using expanded file)
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_CALLS_expanded.csv')
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data with RAW CSV column names 
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            # Convert all CSV columns to DynamoDB item (preserving original names)
            item = {}
            for col in df.columns:
                value = convert_to_dynamodb_format(row[col])
                if value is not None:
                    item[col] = value
            
            # Add DynamoDB keys using mo-nov pattern (simpler format, no GSI)
            item['PK'] = f"{item.get('product', 'UNKNOWN')}#{item.get('dim_geo_level', 'UNKNOWN')}#{item.get('dim_geo_name', 'UNKNOWN')}"
            item['SK'] = f"{item.get('year_quarter', 'UNKNOWN')}#{item.get('dim_metric_type', 'UNKNOWN')}"
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def load_rome_table(dynamodb):
    """Load Rome table (raw CSV approach )"""
    table_name = 'Novartis_Rome'
    
    print(f"\n{'='*80}")
    print(f"Loading table: {table_name}")
    print(f"{'='*80}")
    
    table = get_or_create_table(dynamodb, table_name, with_gsi=False)  # Rome has NO GSI
    
    # Load CSV data (using expanded file)
    print("Loading CSV data...")
    df = pd.read_csv('data/data_samples/FCT_ROME_PLU_expanded.csv')
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data with RAW CSV column names ()
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            # Convert all CSV columns to DynamoDB item (preserving original names)
            item = {}
            for col in df.columns:
                value = convert_to_dynamodb_format(row[col])
                if value is not None:
                    item[col] = value
            
            # Add DynamoDB keys using mo-nov pattern (simpler format, no GSI)
            item['PK'] = f"{item.get('PRODUCT', 'UNKNOWN')}#{item.get('site_id', 'UNKNOWN')}"
            item['SK'] = f"{item.get('dim_date', 'UNKNOWN')}#{item.get('sales_order_number', 'UNKNOWN')}"
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def verify_tables(dynamodb):
    """Verify table creation and data"""
    print(f"\n{'='*80}")
    print("VERIFICATION")
    print(f"{'='*80}")
    
    tables = [
        'Novartis_Sales_Finance',
        'Novartis_Market_Share',
        'Novartis_Doses',
        'Novartis_Calls',
        'Novartis_Rome'
    ]
    
    for table_name in tables:
        table = dynamodb.Table(table_name)
        count = table.item_count
        print(f"✓ {table_name}: {count} items")

def main():
    """Main execution"""
    parser = argparse.ArgumentParser(description='Load all Novartis MBR tables to DynamoDB')
    parser.add_argument('--region', default='us-east-1', help='AWS region')
    
    args = parser.parse_args()
    
    print("="*80)
    print("NOVARTIS MBR - ALL TABLES CREATION")
    print("="*80)
    print(f"Region: {args.region}")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print()
    print("📋 Strategy:")
    print("  • Sales Finance, Market Share, Doses: Normalized column names")
    print("  • Calls, Rome: Raw CSV column names ")
    print("  • All tables: Same PK/SK patterns and GSI structure")
    
    # DynamoDB client
    dynamodb = boto3.resource('dynamodb', region_name=args.region)
    
    try:
        # Load all tables
        load_sales_finance_table(dynamodb)
        load_market_share_table(dynamodb)
        load_doses_table(dynamodb)
        load_calls_table(dynamodb)
        load_rome_table(dynamodb)
        
        # Verify
        time.sleep(5)  # Wait for eventual consistency
        verify_tables(dynamodb)
        
        print(f"\n{'='*80}")
        print("✅ ALL TABLES CREATED SUCCESSFULLY")
        print(f"{'='*80}")
        
        print("\n📋 Data Structure Summary:")
        print("-"*80)
        print("✅ Sales Finance: Normalized columns ")
        print("✅ Market Share: Normalized columns ")
        print("✅ Doses: Normalized columns ")
        print("✅ Calls: Raw CSV columns ")
        print("✅ Rome: Raw CSV columns ")
        
        print("\n📋 File Usage:")
        print("-"*80)
        print("• Sales Finance: data/data_samples/SALES_FINANCE_BPC_corrected.csv")
        print("• Market Share: data/data_samples/FCT_MARKET_PLU_corrected.csv")
        print("• Doses: data/data_samples/FCT_DOSES_PLU_corrected.csv")
        print("• Calls: data/data_samples/FCT_CALLS_expanded.csv")
        print("• Rome: data/data_samples/FCT_ROME_PLU_expanded.csv")
        
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        raise

if __name__ == '__main__':
    main()