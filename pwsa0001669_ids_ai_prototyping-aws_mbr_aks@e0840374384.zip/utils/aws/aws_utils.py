"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Shared AWS utilities for consistent credential handling across environments
"""

import boto3
import os
import csv

def get_aws_session():
    """
    Create AWS session that works in multiple environments:
    - Local dev with isenguard CLI: Uses AWS_PROFILE with credential_process (RECOMMENDED)
    - Local dev with isenguard CSV: Uses CSV credentials file (FALLBACK)
    - ECS Task: Uses task IAM role automatically
    - Lambda: Uses execution role automatically
    
    Setup for isengardcli (recommended):
    1. Add to ~/.aws/config:
       [profile mo-nov]
       output=json
       region=us-east-1
       credential_process=isengardcli credentials --awscli mbabakme+onboarding@amazon.com --role Admin
    
    2. Set environment variable:
       export AWS_PROFILE=mo-nov
    
    3. Run mwinit if prompted
    """
    aws_region = os.environ.get('AWS_DEFAULT_REGION', 'us-east-1')
    
    # Check if we're running in ECS (has ECS metadata endpoint)
    is_ecs = os.environ.get('ECS_CONTAINER_METADATA_URI_V4') or os.environ.get('ECS_CONTAINER_METADATA_URI')
    
    if is_ecs:
        # Running in ECS - use task role credentials (no profile)
        # Explicitly unset AWS_PROFILE to prevent boto3 from trying to use it
        if 'AWS_PROFILE' in os.environ:
            del os.environ['AWS_PROFILE']
        print("✅ Running in ECS - using task role credentials")
        return boto3.Session(region_name=aws_region)
    
    # Try AWS CLI profile first (supports isengardcli credential_process)
    aws_profile = os.environ.get('AWS_PROFILE')
    if aws_profile:
        try:
            session = boto3.Session(profile_name=aws_profile, region_name=aws_region)
            # Test the session by making a simple call
            session.client('sts').get_caller_identity()
            print(f"✅ Using AWS profile: {aws_profile}")
            return session
        except Exception as e:
            print(f"Warning: Failed to use profile '{aws_profile}': {e}")
            print("Falling back to CSV credentials")
    
    # Fallback: Try isenguard CSV credentials (for backward compatibility)
    isenguard_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'isenguard_access', 'mbabakme-cli_accessKeys.csv')
    if os.path.exists(isenguard_path):
        try:
            with open(isenguard_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                creds = next(reader)
                access_key = creds['Access key ID'].strip()
                secret_key = creds['Secret access key'].strip()
                
                # Set environment variables for boto3
                os.environ['AWS_ACCESS_KEY_ID'] = access_key
                os.environ['AWS_SECRET_ACCESS_KEY'] = secret_key
                os.environ['AWS_DEFAULT_REGION'] = aws_region
                
                print("✅ Using isenguard credentials from CSV file")
                return boto3.Session(
                    aws_access_key_id=access_key,
                    aws_secret_access_key=secret_key,
                    region_name=aws_region
                )
        except Exception as e:
            print(f"Warning: Failed to load isenguard credentials: {e}")
    
    # Last resort: use default credential chain
    print("✅ Using default AWS credential chain")
    return boto3.Session(region_name=aws_region)

def get_aws_client(service_name, **kwargs):
    """Get AWS client with proper credential handling"""
    session = get_aws_session()
    return session.client(service_name, **kwargs)

def get_aws_resource(service_name, **kwargs):
    """Get AWS resource with proper credential handling"""
    session = get_aws_session()
    return session.resource(service_name, **kwargs)