# Utils Directory

This directory contains all utility scripts and helper functions organized by purpose.

## Directory Structure

### `aws/`
AWS credential management and access utilities
- `aws_utils.py` - Main credential handler (supports isengardcli, CSV, ECS task role)
- `check_aws_access.py` - Verify AWS access and permissions
- `credentials/` - Credential files (gitignored)

### `data_generation/`
Scripts for generating and transforming data
- `generate_sample_data.py` - Generate sample MBR data
- `generate_corrected_tables.py` - Apply corrections to raw data
- `generate_rome_corrected.py` - Generate corrected Rome data
- `generate_calls_expanded.py` - Expand FCT_CALLS data (2020-2025)
- `generate_rome_expanded.py` - Expand FCT_ROME_PLU data (2020-2025)
- `generate_mbr_slides.py` - Generate MBR presentation slides
- `generate_expected_charts.py` - Generate expected chart outputs
- `preprocess_slides.sh` - Preprocess PDF slides

### `data_management/`
DynamoDB operations and data loading
- `create_dynamodb_tables.py` - Create all 5 DynamoDB tables
- `load_all_tables.py` - Load all tables from CSV files
- `load_dynamodb_data.py` - Load data to DynamoDB
- `upload_to_dynamodb.py` - Upload CSV to DynamoDB

### `data_analysis/`
Data analysis and visualization utilities
- `sample_queries.py` - Sample DynamoDB queries
- `visualize_data.py` - Data visualization utilities

### `cleanup/`
Cleanup and maintenance utilities
- `cleanup_aws_resources.py` - Clean up AWS resources

### `infrastructure/`
Infrastructure setup scripts (legacy)
- `create_dynamodb_table.py` - Create DynamoDB table (old)
- `load_data_to_dynamodb.py` - Load data (old)
- `setup_s3_bucket.py` - S3 bucket setup
- `convert_pdf_to_images.py` - PDF to image conversion

## Usage

Most scripts can be run directly from the utils directory:

```bash
# Generate expanded data
python utils/data_generation/generate_calls_expanded.py

# Create DynamoDB tables
python utils/data_management/create_dynamodb_tables.py

# Check AWS access
python utils/aws/check_aws_access.py
```

## Import in Backend

Backend files import from utils using relative paths:

```python
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'utils'))
from aws.aws_utils import get_aws_client, get_aws_resource
```
