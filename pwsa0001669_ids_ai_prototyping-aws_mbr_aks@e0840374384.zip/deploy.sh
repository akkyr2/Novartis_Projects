#!/bin/bash

# MBR Dashboard One-Click Deployment Script
# This script orchestrates the complete deployment of the MBR Dashboard to AWS

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Load environment variables from .env file if it exists
if [ -f ".env" ]; then
    echo -e "${BLUE}📄 Loading configuration from .env file...${NC}"
    export $(grep -v '^#' .env | xargs)
fi

# Configuration
REGION=${AWS_DEFAULT_REGION:-us-east-1}
STACK_NAME="MbrDashboardStack"
ECR_REPO_NAME="mbr-dashboard"

echo -e "${BLUE}🚀 Starting MBR Dashboard deployment...${NC}"
echo -e "${BLUE}Region: ${REGION}${NC}"
echo -e "${BLUE}Stack: ${STACK_NAME}${NC}"

# Display configuration
echo -e "${BLUE}📋 Deployment Configuration:${NC}"
echo -e "${BLUE}  ALB Type: Private (VPC-only access)${NC}"
echo -e "${BLUE}  Protocol: HTTP only${NC}"
echo -e "${BLUE}  Authentication: Disabled${NC}"
echo -e "${BLUE}  VPC: ${VPC_ID:-Default VPC}${NC}"
if [ -n "$PRIVATE_SUBNET_IDS" ]; then
    echo -e "${BLUE}  Private Subnets: ${PRIVATE_SUBNET_IDS}${NC}"
fi

# Function to check if AWS CLI is configured
check_aws_config() {
    echo -e "${YELLOW}🔍 Checking AWS configuration...${NC}"
    
    # Get caller identity
    CALLER_IDENTITY=$(aws sts get-caller-identity 2>/dev/null)
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ AWS CLI not configured or no valid credentials found${NC}"
        echo -e "${YELLOW}Please run 'aws configure' or set up your AWS credentials${NC}"
        exit 1
    fi
    
    # Extract account ID and user info
    AWS_ACCOUNT_ID=$(echo $CALLER_IDENTITY | jq -r '.Account' 2>/dev/null || echo "unknown")
    AWS_USER_ARN=$(echo $CALLER_IDENTITY | jq -r '.Arn' 2>/dev/null || echo "unknown")
    
    echo -e "${GREEN}✅ AWS credentials configured${NC}"
    echo -e "${BLUE}  Account ID: ${AWS_ACCOUNT_ID}${NC}"
    echo -e "${BLUE}  User/Role: ${AWS_USER_ARN}${NC}"
    echo -e "${BLUE}  Region: ${REGION}${NC}"
    
    # Export for CDK
    export CDK_DEFAULT_ACCOUNT=${AWS_ACCOUNT_ID}
    export CDK_DEFAULT_REGION=${REGION}
}

# Function to get stack outputs
get_stack_outputs() {
    echo -e "${YELLOW}📋 Getting stack outputs...${NC}"
    
    ECR_URI=$(aws cloudformation describe-stacks \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --query 'Stacks[0].Outputs[?OutputKey==`EcrRepoUri`].OutputValue' \
        --output text 2>/dev/null || echo "")
    
    # Note: No S3 buckets - frontend served from ECS container
    
    ECS_CLUSTER=$(aws cloudformation describe-stacks \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --query 'Stacks[0].Outputs[?OutputKey==`EcsClusterName`].OutputValue' \
        --output text 2>/dev/null || echo "")
    
    ECS_SERVICE=$(aws cloudformation describe-stacks \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --query 'Stacks[0].Outputs[?OutputKey==`EcsServiceName`].OutputValue' \
        --output text 2>/dev/null || echo "")
}

# Function to start ECS service after Docker image is ready
start_ecs_service() {
    echo -e "${YELLOW}🚀 Starting ECS service...${NC}"
    
    if [ -z "$ECS_CLUSTER" ] || [ -z "$ECS_SERVICE" ]; then
        echo -e "${RED}❌ ECS cluster or service name not found${NC}"
        exit 1
    fi
    
    # Update service to desired count 1 and force new deployment
    aws ecs update-service \
        --cluster ${ECS_CLUSTER} \
        --service ${ECS_SERVICE} \
        --desired-count 1 \
        --force-new-deployment \
        --region ${REGION}
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ ECS service started successfully${NC}"
    else
        echo -e "${RED}❌ Failed to start ECS service${NC}"
        exit 1
    fi
}

# Function to deploy infrastructure (legacy - keeping for reference)
deploy_infrastructure() {
    echo -e "${YELLOW}🏗️ Deploying infrastructure with CDK...${NC}"
    
    # Check if CDK is installed
    if ! command -v cdk &> /dev/null; then
        echo -e "${YELLOW}📦 Installing AWS CDK CLI globally...${NC}"
        npm install -g aws-cdk
    fi
    
    cd infrastructure
    
    # Install dependencies if needed
    if [ ! -d "node_modules" ]; then
        echo -e "${YELLOW}📦 Installing CDK dependencies...${NC}"
        npm install
        
        if [ $? -ne 0 ]; then
            echo -e "${RED}❌ Failed to install CDK dependencies${NC}"
            exit 1
        fi
    fi
    
    # Bootstrap CDK if needed (first time setup)
    echo -e "${YELLOW}🔧 Checking CDK bootstrap status...${NC}"
    npx cdk bootstrap aws://${AWS_ACCOUNT_ID}/${REGION} --region ${REGION} 2>/dev/null || {
        echo -e "${YELLOW}🚀 Bootstrapping CDK environment...${NC}"
        npx cdk bootstrap --region ${REGION}
        
        if [ $? -ne 0 ]; then
            echo -e "${RED}❌ CDK bootstrap failed${NC}"
            exit 1
        fi
    }
    
    # Synthesize the stack first to check for errors
    echo -e "${YELLOW}🔍 Synthesizing CDK stack...${NC}"
    npx cdk synth --region ${REGION}
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ CDK synthesis failed${NC}"
        exit 1
    fi
    
    # Deploy the stack with progress tracking
    echo -e "${YELLOW}🚀 Deploying CDK stack...${NC}"
    echo -e "${BLUE}  Stack: ${STACK_NAME}${NC}"
    echo -e "${BLUE}  Region: ${REGION}${NC}"
    
    # Simple deployment - no parameters needed
    CDK_PARAMETERS=""
    echo -e "${BLUE}  Simple deployment - no parameters needed${NC}"
    
    npx cdk deploy ${STACK_NAME} \
        --require-approval never \
        --region ${REGION} \
        --progress events \
        --outputs-file cdk-outputs.json \
        $CDK_PARAMETERS
    
    CDK_EXIT_CODE=$?
    
    if [ $CDK_EXIT_CODE -eq 0 ]; then
        echo -e "${GREEN}✅ Infrastructure deployed successfully${NC}"
        
        # Display stack outputs if available
        if [ -f "cdk-outputs.json" ]; then
            echo -e "${BLUE}📋 Stack Outputs:${NC}"
            cat cdk-outputs.json | jq -r '.MbrDashboardStack | to_entries[] | "  \(.key): \(.value)"' 2>/dev/null || {
                echo -e "${YELLOW}  (Install jq for formatted output)${NC}"
                cat cdk-outputs.json
            }
        fi
    else
        echo -e "${RED}❌ Infrastructure deployment failed (exit code: ${CDK_EXIT_CODE})${NC}"
        
        # Show recent CloudFormation events for debugging
        echo -e "${YELLOW}📋 Recent CloudFormation events:${NC}"
        aws cloudformation describe-stack-events \
            --stack-name ${STACK_NAME} \
            --region ${REGION} \
            --max-items 10 \
            --query 'StackEvents[?ResourceStatus!=`CREATE_IN_PROGRESS`].[Timestamp,ResourceType,ResourceStatus,ResourceStatusReason]' \
            --output table 2>/dev/null || echo "Could not fetch stack events"
        
        exit 1
    fi
    
    cd ..
}

# Function to build and push Docker image
build_and_push_docker() {
    echo -e "${YELLOW}📦 Building and pushing Docker image...${NC}"
    
    if [ -z "$ECR_URI" ]; then
        echo -e "${RED}❌ ECR URI not found. Infrastructure may not be deployed.${NC}"
        exit 1
    fi
    
    # Check if Finch is available and start it if needed
    if command -v finch &> /dev/null; then
        echo -e "${BLUE}  Checking Finch VM status...${NC}"
        if ! finch version &> /dev/null; then
            echo -e "${YELLOW}  Starting Finch VM...${NC}"
            finch vm start
            if [ $? -ne 0 ]; then
                echo -e "${RED}❌ Failed to start Finch VM${NC}"
                exit 1
            fi
        fi
    elif command -v docker &> /dev/null; then
        echo -e "${BLUE}  Using Docker${NC}"
    else
        echo -e "${RED}❌ Neither Finch nor Docker found. Please install one of them.${NC}"
        exit 1
    fi
    
    # Login to ECR
    echo -e "${YELLOW}🔐 Logging into ECR...${NC}"
    if command -v finch &> /dev/null; then
        echo -e "${BLUE}  Using Finch for ECR login${NC}"
        aws ecr get-login-password --region ${REGION} | finch login --username AWS --password-stdin ${ECR_URI}
    else
        echo -e "${BLUE}  Using Docker for ECR login${NC}"
        aws ecr get-login-password --region ${REGION} | docker login --username AWS --password-stdin ${ECR_URI}
    fi
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Failed to login to ECR${NC}"
        exit 1
    fi
    
    # Build frontend first
    echo -e "${YELLOW}🎨 Building frontend...${NC}"
    cd frontend
    
    # Install dependencies if needed
    if [ ! -d "node_modules" ]; then
        echo -e "${YELLOW}📦 Installing frontend dependencies...${NC}"
        npm install
        
        if [ $? -ne 0 ]; then
            echo -e "${RED}❌ Failed to install frontend dependencies${NC}"
            exit 1
        fi
    fi
    
    # Build the React app
    echo -e "${YELLOW}🔨 Building React application...${NC}"
    npm run build
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Frontend build failed${NC}"
        exit 1
    fi
    
    cd ..
    
    # Copy frontend build to backend directory for Docker
    echo -e "${YELLOW}📁 Copying frontend build to backend...${NC}"
    rm -rf backend_api/frontend
    cp -r frontend/build backend_api/frontend
    
    # Build Docker image with build context
    echo -e "${YELLOW}🔨 Building Docker image...${NC}"
    echo -e "${BLUE}  Build context: ./backend_api${NC}"
    echo -e "${BLUE}  Image name: ${ECR_REPO_NAME}${NC}"
    echo -e "${BLUE}  Platform: linux/amd64 (for ECS Fargate)${NC}"
    
    # Add timestamp tag for versioning
    TIMESTAMP=$(date +%Y%m%d-%H%M%S)
    GIT_COMMIT=$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
    IMAGE_TAG="${TIMESTAMP}-${GIT_COMMIT}"
    
    # Build for correct architecture (x86_64 for ECS Fargate)
    # Use project root as build context and specify Dockerfile location
    if command -v finch &> /dev/null; then
        echo -e "${BLUE}  Using Finch (detected)${NC}"
        finch build --platform linux/amd64 -f backend_api/Dockerfile -t ${ECR_REPO_NAME}:latest -t ${ECR_REPO_NAME}:${IMAGE_TAG} .
    else
        echo -e "${BLUE}  Using Docker${NC}"
        docker build --platform linux/amd64 -f backend_api/Dockerfile -t ${ECR_REPO_NAME}:latest -t ${ECR_REPO_NAME}:${IMAGE_TAG} .
    fi
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ Docker build failed${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ Docker image built successfully${NC}"
    echo -e "${BLUE}  Tags: latest, ${IMAGE_TAG}${NC}"
    
    # Tag and push images
    echo -e "${YELLOW}📤 Pushing Docker images to ECR...${NC}"
    
    # Tag for ECR
    if command -v finch &> /dev/null; then
        finch tag ${ECR_REPO_NAME}:latest ${ECR_URI}:latest
        finch tag ${ECR_REPO_NAME}:${IMAGE_TAG} ${ECR_URI}:${IMAGE_TAG}
        
        # Push both tags
        echo -e "${BLUE}  Pushing latest tag...${NC}"
        finch push ${ECR_URI}:latest
        
        if [ $? -ne 0 ]; then
            echo -e "${RED}❌ Failed to push latest tag${NC}"
            exit 1
        fi
        
        echo -e "${BLUE}  Pushing versioned tag...${NC}"
        finch push ${ECR_URI}:${IMAGE_TAG}
        
        if [ $? -ne 0 ]; then
            echo -e "${YELLOW}⚠️ Failed to push versioned tag (continuing...)${NC}"
        fi
    else
        docker tag ${ECR_REPO_NAME}:latest ${ECR_URI}:latest
        docker tag ${ECR_REPO_NAME}:${IMAGE_TAG} ${ECR_URI}:${IMAGE_TAG}
        
        # Push both tags
        echo -e "${BLUE}  Pushing latest tag...${NC}"
        docker push ${ECR_URI}:latest
        
        if [ $? -ne 0 ]; then
            echo -e "${RED}❌ Failed to push latest tag${NC}"
            exit 1
        fi
        
        echo -e "${BLUE}  Pushing versioned tag...${NC}"
        docker push ${ECR_URI}:${IMAGE_TAG}
        
        if [ $? -ne 0 ]; then
            echo -e "${YELLOW}⚠️ Failed to push versioned tag (continuing...)${NC}"
        fi
    fi
    
    echo -e "${GREEN}✅ Docker image pushed successfully${NC}"
    echo -e "${BLUE}  Repository: ${ECR_URI}${NC}"
    echo -e "${BLUE}  Tags: latest, ${IMAGE_TAG}${NC}"
}

# Function to load DynamoDB data
load_dynamodb_data() {
    echo -e "${YELLOW}📊 Loading DynamoDB data...${NC}"
    
    # Check if data loading script exists
    if [ ! -f "scripts/load_dynamodb_data.py" ]; then
        echo -e "${RED}❌ Data loading script not found: scripts/load_dynamodb_data.py${NC}"
        return 1
    fi
    
    # Check if data directory exists
    if [ ! -d "data_sample/Real_data" ]; then
        echo -e "${RED}❌ Data directory not found: data_sample/Real_data${NC}"
        echo -e "${YELLOW}💡 Skipping data loading. You can load data later using:${NC}"
        echo -e "   python scripts/load_dynamodb_data.py --region ${REGION}"
        return 0
    fi
    
    echo -e "${BLUE}  Note: DynamoDB tables are created by CDK infrastructure${NC}"
    echo -e "${BLUE}  This step loads data into the existing tables${NC}"
    
    # Check required CSV files
    local required_files=(
        "data_sample/Real_data/SALES_FINANCE_BPC_corrected.csv"
        "data_sample/Real_data/FCT_MARKET_PLU_corrected.csv"
        "data_sample/Real_data/FCT_DOSES_PLU_corrected.csv"
        "data_sample/Real_data/FCT_CALLS_corrected.csv"
        "data_sample/Real_data/FCT_ROME_PLU_expanded.csv"
    )
    
    local missing_files=0
    for file in "${required_files[@]}"; do
        if [ ! -f "$file" ]; then
            echo -e "${YELLOW}⚠️  Missing data file: $file${NC}"
            missing_files=1
        fi
    done
    
    if [ $missing_files -eq 1 ]; then
        echo -e "${YELLOW}💡 Some data files are missing. Loading available data...${NC}"
    fi
    
    # Install required Python packages
    echo -e "${BLUE}  Installing required Python packages...${NC}"
    pip install pandas boto3 >/dev/null 2>&1
    
    # Run data loading script
    echo -e "${BLUE}  Running data loading script...${NC}"
    python scripts/load_all_tables.py \
        --region ${REGION}
    
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        echo -e "${GREEN}✅ DynamoDB data loaded successfully${NC}"
        
        # Display table information
        echo -e "\n${BLUE}📊 DynamoDB Tables Populated:${NC}"
        echo -e "• Novartis_Sales_Finance - Sales and revenue data"
        echo -e "• Novartis_Market_Share - Market share and prescription data"
        echo -e "• Novartis_Doses - Dose shipment and treatment data"
        echo -e "• Novartis_Calls - Sales call and engagement data"
        echo -e "• Novartis_Rome - Patient order and treatment data"
        
        echo -e "\n${YELLOW}💡 Data Loading Notes:${NC}"
        echo -e "• Tables created by CDK with provisioned capacity"
        echo -e "• Data is indexed for efficient querying by product, date, and geography"
        echo -e "• You can reload data anytime using: python scripts/load_dynamodb_data.py"
        
    else
        echo -e "${YELLOW}⚠️  Data loading completed with warnings${NC}"
        echo -e "${YELLOW}💡 You can retry data loading using:${NC}"
        echo -e "   python scripts/load_dynamodb_data.py --region ${REGION}"
    fi
    
    return 0
}

# Function to wait for ECS service to be stable
wait_for_ecs_stable() {
    echo -e "${YELLOW}⏳ Waiting for ECS service to be stable...${NC}"
    
    if [ -z "$ECS_CLUSTER" ] || [ -z "$ECS_SERVICE" ]; then
        echo -e "${RED}❌ ECS cluster or service name not found${NC}"
        return 1
    fi
    
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        local service_status=$(aws ecs describe-services \
            --cluster ${ECS_CLUSTER} \
            --services ${ECS_SERVICE} \
            --region ${REGION} \
            --query 'services[0].deployments[?status==`PRIMARY`].runningCount' \
            --output text 2>/dev/null || echo "0")
        
        local desired_count=$(aws ecs describe-services \
            --cluster ${ECS_CLUSTER} \
            --services ${ECS_SERVICE} \
            --region ${REGION} \
            --query 'services[0].desiredCount' \
            --output text 2>/dev/null || echo "0")
        
        if [ "$service_status" = "$desired_count" ] && [ "$service_status" -gt 0 ]; then
            echo -e "${GREEN}✅ ECS service is stable${NC}"
            return 0
        fi
        
        echo -e "${BLUE}  Attempt $((attempt + 1))/${max_attempts}: Running=${service_status}, Desired=${desired_count}${NC}"
        sleep 10
        ((attempt++))
    done
    
    echo -e "${RED}❌ ECS service did not stabilize within timeout${NC}"
    return 1
}

# Frontend configuration functions removed - now served through ALB

# Frontend deployment function removed - now served through ALB

# Function to display deployment summary
show_summary() {
    echo -e "\n${GREEN}🎉 Deployment completed successfully!${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}📋 Deployment Summary:${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    # Get ALB DNS name from stack outputs
    ALB_DNS=$(aws cloudformation describe-stacks \
        --stack-name ${STACK_NAME} \
        --region ${REGION} \
        --query 'Stacks[0].Outputs[?OutputKey==`ApplicationUrl`].OutputValue' \
        --output text 2>/dev/null || echo "")
    
    if [ ! -z "$ALB_DNS" ]; then
        echo -e "${GREEN}🌐 Application URL: ${ALB_DNS}${NC}"
        echo -e "${GREEN}📱 API URL: ${ALB_DNS}/api${NC}"
    fi
    

    
    if [ ! -z "$ECR_URI" ]; then
        echo -e "\n${GREEN}📦 ECR Repository: ${ECR_URI}${NC}"
    fi
    
    if [ ! -z "$ECS_CLUSTER" ]; then
        echo -e "${GREEN}🚀 ECS Cluster: ${ECS_CLUSTER}${NC}"
    fi
    
    echo -e "\n${YELLOW}🔓 Protocol: HTTP only (no HTTPS/SSL)${NC}"
    echo -e "${BLUE}🏢 Network: Private ALB (VPC-only access)${NC}"
    
    echo -e "\n${YELLOW}📝 Next Steps:${NC}"
    echo -e "1. Wait 2-3 minutes for ECS service to fully start"
    echo -e "2. Access the application from within the VPC (private ALB)"
    echo -e "3. Test the application functionality"
    echo -e "4. Consider adding authentication and HTTPS for production use"
    
    echo -e "\n${YELLOW}🔧 Useful Commands:${NC}"
    echo -e "• Check ECS service: aws ecs describe-services --cluster ${ECS_CLUSTER} --services ${ECS_SERVICE} --region ${REGION}"
    echo -e "• View ECS logs: aws logs tail /aws/ecs/mbr-dashboard --follow --region ${REGION}"
    echo -e "• Clean up resources: ./cleanup.sh"
    
    echo -e "\n${GREEN}🎯 Deployment Configuration Used:${NC}"
    echo -e "• ALB Type: Private (VPC-only)"
    echo -e "• Protocol: HTTP only"
    echo -e "• Authentication: Disabled"
    echo -e "• Region: ${REGION}"
}

# Main execution
main() {
    check_aws_config
    
    # Step 1: Deploy infrastructure with ECS service scaled to 0
    echo -e "${YELLOW}📋 Step 1: Deploying infrastructure...${NC}"
    deploy_infrastructure
    
    # Step 2: Build and push Docker image
    echo -e "${YELLOW}📋 Step 2: Building and pushing Docker image...${NC}"
    get_stack_outputs
    build_and_push_docker
    
    # Step 3: Scale up ECS service now that image exists
    echo -e "${YELLOW}📋 Step 3: Starting ECS service...${NC}"
    start_ecs_service
    
    # Step 4: Wait for ECS service to stabilize
    echo -e "${YELLOW}⏳ Step 4: Waiting for ECS service to start...${NC}"
    wait_for_ecs_stable
    
    # Step 5: Frontend is now served by the Flask app through ALB
    echo -e "${YELLOW}📋 Step 5: Frontend integrated with backend (served through ALB)${NC}"
    
    # Step 6: Load DynamoDB data
    echo -e "${YELLOW}📋 Step 6: Loading DynamoDB data...${NC}"
    load_dynamodb_data
    

    
    show_summary
}

# Handle script interruption
trap 'echo -e "\n${RED}❌ Deployment interrupted${NC}"; exit 1' INT TERM

# Run main function
main "$@"