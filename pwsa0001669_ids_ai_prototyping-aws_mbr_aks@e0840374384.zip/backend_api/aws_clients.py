#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Shared AWS Clients - Single Instance Pattern
Prevents "too many connections" errors by reusing clients across modules
"""

from botocore.config import Config
import sys
import os

# Add utils/aws to path for aws_utils
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'utils', 'aws'))
from aws_utils import get_aws_client, get_aws_resource

print("🔐 Using shared AWS client configuration")

# Create single shared instances with optimized connection pooling
bedrock_runtime = get_aws_client(
    'bedrock-runtime',
    config=Config(
        max_pool_connections=25,  # Balanced pool size
        retries={'max_attempts': 5, 'mode': 'adaptive'},
        connect_timeout=60,
        read_timeout=60
    )
)

polly_client = get_aws_client(
    'polly',
    config=Config(
        max_pool_connections=10
    )
)

dynamodb = get_aws_resource(
    'dynamodb',
    config=Config(
        max_pool_connections=50
    )
)
