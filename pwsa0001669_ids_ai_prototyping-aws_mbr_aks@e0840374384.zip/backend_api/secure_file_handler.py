"""
Secure File Handler Module
Provides secure file access functions to prevent path traversal attacks
"""

import os
import logging
from pathlib import Path
from typing import List, Optional

# Configure security logging
security_logger = logging.getLogger('security')

class SecureFileHandler:
    """
    Secure file handler that prevents path traversal attacks
    """
    
    def __init__(self, allowed_directories: List[str]):
        """
        Initialize with list of allowed base directories
        
        Args:
            allowed_directories: List of absolute paths to allowed directories
        """
        self.allowed_directories = [os.path.abspath(d) for d in allowed_directories]
        
    def safe_file_access(self, filename: str, base_directory: str) -> str:
        """
        Safely access files within a restricted directory
        
        Args:
            filename: Name of file to access
            base_directory: Base directory (must be in allowed_directories)
            
        Returns:
            str: Safe absolute path to file
            
        Raises:
            ValueError: If path traversal attempt detected or directory not allowed
            FileNotFoundError: If file doesn't exist
        """
        # Validate base directory is allowed
        base_path = os.path.abspath(base_directory)
        if base_path not in self.allowed_directories:
            security_logger.warning(f"Unauthorized directory access attempt: {base_directory}")
            raise ValueError("Access denied: Directory not allowed")
        
        # Construct and validate requested path
        requested_path = os.path.abspath(os.path.join(base_directory, filename))
        
        # Ensure the requested path is within the base directory
        if not requested_path.startswith(base_path + os.sep) and requested_path != base_path:
            security_logger.warning(f"Path traversal attempt detected: {filename} -> {requested_path}")
            raise ValueError("Access denied: Path traversal attempt detected")
        
        # Check if file exists
        if not os.path.exists(requested_path):
            raise FileNotFoundError(f"File not found: {filename}")
        
        # Additional security check - ensure it's a file, not a directory
        if not os.path.isfile(requested_path):
            security_logger.warning(f"Attempt to access non-file: {requested_path}")
            raise ValueError("Access denied: Not a file")
        
        return requested_path
    
    def safe_read_file(self, filename: str, base_directory: str, mode: str = 'rb') -> bytes:
        """
        Safely read file content with path traversal protection
        
        Args:
            filename: Name of file to read
            base_directory: Base directory (must be in allowed_directories)
            mode: File open mode ('r', 'rb', etc.)
            
        Returns:
            File content as bytes or string
            
        Raises:
            ValueError: If path traversal attempt detected or directory not allowed
            FileNotFoundError: If file doesn't exist
        """
        safe_path = self.safe_file_access(filename, base_directory)
        
        try:
            # Use Path object for additional security validation
            safe_file_path = Path(safe_path)
            if not safe_file_path.exists():
                raise FileNotFoundError(f"File not found: {filename}")
            
            # Resolve any remaining symbolic links and validate again
            resolved_path = safe_file_path.resolve()
            base_resolved = Path(base_directory).resolve()
            
            # Final security check after resolving symbolic links
            if not str(resolved_path).startswith(str(base_resolved) + os.sep) and resolved_path != base_resolved:
                security_logger.warning(f"Symbolic link traversal attempt: {resolved_path}")
                raise ValueError("Access denied: Invalid file path after resolution")
            
            # Safe file read using resolved path
            with resolved_path.open(mode) as f:
                return f.read()
        except Exception as e:
            security_logger.error(f"Error reading file {filename}: {str(e)}")
            raise

def validate_slide_number(slide_num: int, max_slides: int = 100) -> int:
    """
    Validate slide number is within acceptable range
    
    Args:
        slide_num: Slide number to validate
        max_slides: Maximum allowed slide number
        
    Returns:
        int: Validated slide number
        
    Raises:
        ValueError: If slide number is invalid
    """
    if not isinstance(slide_num, int):
        raise ValueError("Slide number must be an integer")
    
    if not (1 <= slide_num <= max_slides):
        raise ValueError(f"Slide number must be between 1 and {max_slides}")
    
    return slide_num

def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename to prevent malicious characters
    
    Args:
        filename: Original filename
        
    Returns:
        str: Sanitized filename
    """
    # Remove path separators and other dangerous characters
    dangerous_chars = ['/', '\\', '..', '~', '$', '&', '|', ';', '`']
    sanitized = filename
    
    for char in dangerous_chars:
        sanitized = sanitized.replace(char, '')
    
    # Ensure filename is not empty after sanitization
    if not sanitized.strip():
        raise ValueError("Invalid filename after sanitization")
    
    return sanitized.strip()