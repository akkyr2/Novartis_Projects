#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Novartis DynamoDB Query Functions

Query functions for Novartis RLT Portfolio data:
- Sales & Financial metrics
- Market share data
- Dose shipments and injections
"""

import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
import json
import os

# AWS Configuration - use shared utility for consistent credential handling
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'utils', 'aws'))
from aws_utils import get_aws_resource

dynamodb = get_aws_resource('dynamodb')

# Table references
sales_table = dynamodb.Table('Novartis_Sales_Finance')
market_table = dynamodb.Table('Novartis_Market_Share')
doses_table = dynamodb.Table('Novartis_Doses')

def decimal_to_float(obj):
    """Convert Decimal to float for JSON serialization"""
    if isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_float(i) for i in obj]
    return obj

def query_sales(product, year, forecast_type='Actual'):
    """
    Query sales data for a product and year
    
    Args:
        product: Product name (Pluvicto, Lutathera, Xofigo, Novacure)
        year: Year (2020-2028)
        forecast_type: Actual, Budget, or OC
    
    Returns:
        list: Sales records
    """
    try:
        response = sales_table.query(
            KeyConditionExpression=Key('PK').eq(f'PRODUCT#{product}') & 
                                  Key('SK').begins_with(f'DATE#{year}')
        )
        
        items = response.get('Items', [])
        
        # Filter by forecast type
        filtered = [item for item in items if item.get('forecast_type') == forecast_type]
        
        return decimal_to_float(filtered)
    except Exception as e:
        print(f"Error querying sales: {e}")
        return []

def query_market_share(product, year):
    """
    Query market share data for a product and year
    
    Args:
        product: Product name
        year: Year
    
    Returns:
        list: Market share records
    """
    try:
        response = market_table.query(
            KeyConditionExpression=Key('PK').eq(f'BRAND#{product}') & 
                                  Key('SK').begins_with(f'DATE#{year}')
        )
        
        return decimal_to_float(response.get('Items', []))
    except Exception as e:
        print(f"Error querying market share: {e}")
        return []

def query_doses(product, metric, year):
    """
    Query dose data for a product, metric, and year
    
    Args:
        product: Product name
        metric: TRX_shipped, TRX_injected, or NBRX
        year: Year
    
    Returns:
        list: Dose records
    """
    try:
        response = doses_table.query(
            KeyConditionExpression=Key('PK').eq(f'BRAND#{product}#METRIC#{metric}') & 
                                  Key('SK').begins_with(f'DATE#{year}')
        )
        
        return decimal_to_float(response.get('Items', []))
    except Exception as e:
        print(f"Error querying doses: {e}")
        return []

def query_portfolio_summary(year, month):
    """
    Query portfolio summary for all products in a specific month
    
    Args:
        year: Year
        month: Month (1-12)
    
    Returns:
        dict: Summary by product
    """
    try:
        date_str = f'{year}-{month:02d}'
        
        response = sales_table.query(
            IndexName='GSI1',
            KeyConditionExpression=Key('GSI1PK').eq(f'DATE#{date_str}')
        )
        
        items = response.get('Items', [])
        
        # Group by product
        summary = {}
        for item in items:
            if item.get('forecast_type') == 'Actual':
                product = item.get('brand')
                if product not in summary:
                    summary[product] = {
                        'net_sales': 0,
                        'gross_sales': 0,
                        'revenue_deductions': 0
                    }
                summary[product]['net_sales'] += float(item.get('net_sales', 0))
                summary[product]['gross_sales'] += float(item.get('gross_sales', 0))
                summary[product]['revenue_deductions'] += float(item.get('revenue_deductions', 0))
        
        return summary
    except Exception as e:
        print(f"Error querying portfolio summary: {e}")
        return {}

def query_ytd_performance(year):
    """
    Query year-to-date performance for all products
    
    Args:
        year: Year
    
    Returns:
        dict: YTD metrics by product
    """
    try:
        products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
        ytd_data = {}
        
        for product in products:
            # Query actual
            actual_data = query_sales(product, year, 'Actual')
            # Query budget
            budget_data = query_sales(product, year, 'Budget')
            
            actual_total = sum(item.get('net_sales', 0) for item in actual_data)
            budget_total = sum(item.get('net_sales', 0) for item in budget_data)
            
            variance = actual_total - budget_total
            variance_pct = (variance / budget_total * 100) if budget_total > 0 else 0
            
            ytd_data[product] = {
                'actual': actual_total,
                'budget': budget_total,
                'variance': variance,
                'variance_pct': variance_pct
            }
        
        return ytd_data
    except Exception as e:
        print(f"Error querying YTD performance: {e}")
        return {}

def query_product_comparison(year, month):
    """
    Compare all products for a specific month
    
    Args:
        year: Year
        month: Month
    
    Returns:
        list: Product comparison data
    """
    try:
        summary = query_portfolio_summary(year, month)
        
        comparison = []
        for product, metrics in summary.items():
            comparison.append({
                'product': product,
                'net_sales': metrics['net_sales'],
                'gross_sales': metrics['gross_sales'],
                'deduction_rate': (metrics['revenue_deductions'] / metrics['gross_sales'] * 100) 
                                 if metrics['gross_sales'] > 0 else 0
            })
        
        # Sort by net sales descending
        comparison.sort(key=lambda x: x['net_sales'], reverse=True)
        
        return comparison
    except Exception as e:
        print(f"Error querying product comparison: {e}")
        return []

def query_quarterly_doses(year):
    """
    Query quarterly dose performance for all products with Actual vs Budget comparison
    Aggregates monthly data into quarters for faster quarterly analysis
    Returns BOTH Actual and Budget in one call
    
    Args:
        year: Year (2020-2028)
    
    Returns:
        dict: Quarterly data with 'Actual' and 'Budget' keys, each containing quarters by product
    """
    try:
        products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
        
        # Structure: {Actual: {Q1: {}, Q2: {}, ...}, Budget: {Q1: {}, Q2: {}, ...}}
        result = {
            'Actual': {'Q1': {}, 'Q2': {}, 'Q3': {}, 'Q4': {}, 'YTD': {}},
            'Budget': {'Q1': {}, 'Q2': {}, 'Q3': {}, 'Q4': {}, 'YTD': {}}
        }
        
        # Month to quarter mapping
        quarter_map = {
            1: 'Q1', 2: 'Q1', 3: 'Q1',
            4: 'Q2', 5: 'Q2', 6: 'Q2',
            7: 'Q3', 8: 'Q3', 9: 'Q3',
            10: 'Q4', 11: 'Q4', 12: 'Q4'
        }
        
        for product in products:
            # Query all TRX_shipped data for the year (gets both Actual and Budget)
            doses_data = query_doses(product, 'TRX_shipped', year)
            
            # Separate by forecast type and aggregate by quarter
            for forecast_type in ['Actual', 'Budget']:
                filtered_data = [d for d in doses_data if d.get('forecast_type') == forecast_type]
                
                product_quarters = {'Q1': 0, 'Q2': 0, 'Q3': 0, 'Q4': 0}
                
                for record in filtered_data:
                    month = record.get('month')
                    value = record.get('value', 0)
                    quarter = quarter_map.get(month)
                    
                    if quarter:
                        product_quarters[quarter] += value
                
                # Add to result
                for quarter in ['Q1', 'Q2', 'Q3', 'Q4']:
                    result[forecast_type][quarter][product] = product_quarters[quarter]
                
                # Calculate YTD
                result[forecast_type]['YTD'][product] = sum(product_quarters.values())
        
        return result
    except Exception as e:
        print(f"Error querying quarterly doses: {e}")
        return {}

def query_quarterly_sales(year):
    """
    Query quarterly sales performance for all products with Actual vs Budget comparison
    Aggregates monthly data into quarters for faster quarterly analysis
    Returns BOTH Actual and Budget in one call
    
    Args:
        year: Year (2020-2028)
    
    Returns:
        dict: Quarterly sales data with 'Actual' and 'Budget' keys
    """
    try:
        products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
        
        result = {
            'Actual': {'Q1': {}, 'Q2': {}, 'Q3': {}, 'Q4': {}, 'YTD': {}},
            'Budget': {'Q1': {}, 'Q2': {}, 'Q3': {}, 'Q4': {}, 'YTD': {}}
        }
        
        # Month to quarter mapping
        quarter_map = {
            1: 'Q1', 2: 'Q1', 3: 'Q1',
            4: 'Q2', 5: 'Q2', 6: 'Q2',
            7: 'Q3', 8: 'Q3', 9: 'Q3',
            10: 'Q4', 11: 'Q4', 12: 'Q4'
        }
        
        for product in products:
            for forecast_type in ['Actual', 'Budget']:
                # Query sales data for the year
                sales_data = query_sales(product, year, forecast_type)
                
                # Aggregate by quarter
                product_quarters = {'Q1': 0, 'Q2': 0, 'Q3': 0, 'Q4': 0}
                
                for record in sales_data:
                    month = record.get('month')
                    net_sales = record.get('net_sales', 0)
                    quarter = quarter_map.get(month)
                    
                    if quarter:
                        product_quarters[quarter] += net_sales
                
                # Add to result
                for quarter in ['Q1', 'Q2', 'Q3', 'Q4']:
                    result[forecast_type][quarter][product] = product_quarters[quarter]
                
                # Calculate YTD
                result[forecast_type]['YTD'][product] = sum(product_quarters.values())
        
        return result
    except Exception as e:
        print(f"Error querying quarterly sales: {e}")
        return {}

def query_year_over_year(metric, years):
    """
    Compare year-over-year performance for a metric across multiple years
    
    Args:
        metric: 'sales', 'doses', or 'market_share'
        years: List of years to compare (e.g., [2024, 2025])
    
    Returns:
        dict: YoY comparison data by product and year
    """
    try:
        products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
        result = {}
        
        for year in years:
            result[str(year)] = {}
            
            if metric == 'sales':
                # Get YTD sales for each product
                for product in products:
                    sales_data = query_sales(product, year, 'Actual')
                    total_sales = sum(s.get('net_sales', 0) for s in sales_data)
                    result[str(year)][product] = total_sales
            
            elif metric == 'doses':
                # Get YTD doses for each product
                for product in products:
                    doses_data = query_doses(product, 'TRX_shipped', year)
                    actual_doses = [d for d in doses_data if d.get('forecast_type') == 'Actual']
                    total_doses = sum(d.get('value', 0) for d in actual_doses)
                    result[str(year)][product] = total_doses
            
            elif metric == 'market_share':
                # Get average market share for each product
                for product in products:
                    share_data = query_market_share(product, year)
                    if share_data:
                        avg_share = sum(s.get('trx_share_r3m', 0) for s in share_data) / len(share_data)
                        result[str(year)][product] = avg_share
                    else:
                        result[str(year)][product] = 0
        
        # Calculate YoY growth
        if len(years) == 2:
            result['growth'] = {}
            year1, year2 = str(years[0]), str(years[1])
            for product in products:
                val1 = result[year1].get(product, 0)
                val2 = result[year2].get(product, 0)
                if val1 > 0:
                    growth_pct = ((val2 - val1) / val1) * 100
                    result['growth'][product] = growth_pct
                else:
                    result['growth'][product] = 0
        
        return result
    except Exception as e:
        print(f"Error querying year-over-year: {e}")
        return {}

def query_month_over_month(product, metric, year, month):
    """
    Compare month-over-month performance for a product
    Returns current month and previous month for comparison
    
    Args:
        product: Product name
        metric: 'sales', 'doses', or 'market_share'
        year: Year
        month: Current month (1-12)
    
    Returns:
        dict: MoM comparison data
    """
    try:
        # Calculate previous month
        if month == 1:
            prev_year = year - 1
            prev_month = 12
        else:
            prev_year = year
            prev_month = month - 1
        
        result = {
            'current': {'year': year, 'month': month},
            'previous': {'year': prev_year, 'month': prev_month}
        }
        
        if metric == 'sales':
            # Get sales for both months
            current_data = query_sales(product, year, 'Actual')
            current_month_data = [s for s in current_data if s.get('month') == month]
            
            prev_data = query_sales(product, prev_year, 'Actual')
            prev_month_data = [s for s in prev_data if s.get('month') == prev_month]
            
            result['current']['value'] = current_month_data[0].get('net_sales', 0) if current_month_data else 0
            result['previous']['value'] = prev_month_data[0].get('net_sales', 0) if prev_month_data else 0
        
        elif metric == 'doses':
            # Get doses for both months
            current_data = query_doses(product, 'TRX_shipped', year)
            current_actual = [d for d in current_data if d.get('forecast_type') == 'Actual' and d.get('month') == month]
            
            prev_data = query_doses(product, 'TRX_shipped', prev_year)
            prev_actual = [d for d in prev_data if d.get('forecast_type') == 'Actual' and d.get('month') == prev_month]
            
            result['current']['value'] = current_actual[0].get('value', 0) if current_actual else 0
            result['previous']['value'] = prev_actual[0].get('value', 0) if prev_actual else 0
        
        elif metric == 'market_share':
            # Get market share for both months
            current_data = query_market_share(product, year)
            current_month_data = [s for s in current_data if s.get('month') == month]
            
            prev_data = query_market_share(product, prev_year)
            prev_month_data = [s for s in prev_data if s.get('month') == prev_month]
            
            result['current']['value'] = current_month_data[0].get('trx_share_r3m', 0) if current_month_data else 0
            result['previous']['value'] = prev_month_data[0].get('trx_share_r3m', 0) if prev_month_data else 0
        
        # Calculate MoM change
        current_val = result['current']['value']
        prev_val = result['previous']['value']
        
        if prev_val > 0:
            result['change_pct'] = ((current_val - prev_val) / prev_val) * 100
            result['change_abs'] = current_val - prev_val
        else:
            result['change_pct'] = 0
            result['change_abs'] = current_val
        
        return result
    except Exception as e:
        print(f"Error querying month-over-month: {e}")
        return {}

def query_all_competitors(year, month=None):
    """
    Query market share for ALL brands including competitors
    
    Args:
        year: Year
        month: Optional specific month (1-12), if None returns average for year
    
    Returns:
        list: Market share data for all brands sorted by share
    """
    try:
        # Query market share for all Novartis products
        products = ['Pluvicto', 'Lutathera', 'Xofigo', 'Novacure']
        all_brands = []
        
        for product in products:
            share_data = query_market_share(product, year)
            
            if month:
                # Filter for specific month
                month_data = [s for s in share_data if s.get('month') == month]
                if month_data:
                    all_brands.append({
                        'brand': product,
                        'trx_share': month_data[0].get('trx_share_r3m', 0),
                        'nbrx_share': month_data[0].get('nbrx_share_r3m', 0),
                        'is_novartis': True
                    })
            else:
                # Average for the year
                if share_data:
                    avg_trx = sum(s.get('trx_share_r3m', 0) for s in share_data) / len(share_data)
                    avg_nbrx = sum(s.get('nbrx_share_r3m', 0) for s in share_data) / len(share_data)
                    all_brands.append({
                        'brand': product,
                        'trx_share': avg_trx,
                        'nbrx_share': avg_nbrx,
                        'is_novartis': True
                    })
        
        # Sort by TRX share descending
        all_brands.sort(key=lambda x: x['trx_share'], reverse=True)
        
        return all_brands
    except Exception as e:
        print(f"Error querying all competitors: {e}")
        return []

# Test function
if __name__ == '__main__':
    print("Testing Novartis Query Functions")
    print("="*80)
    
    # Test 1: Query Pluvicto sales for 2025
    print("\n1. Pluvicto Sales 2025:")
    sales = query_sales('Pluvicto', 2025)
    print(f"   Found {len(sales)} records")
    if sales:
        total = sum(s['net_sales'] for s in sales)
        print(f"   Total: ${total/1e6:.1f}M")
    
    # Test 2: Query market share
    print("\n2. Pluvicto Market Share 2025:")
    market = query_market_share('Pluvicto', 2025)
    print(f"   Found {len(market)} records")
    if market:
        avg_share = sum(m['trx_share_r3m'] for m in market) / len(market)
        print(f"   Average share: {avg_share:.1f}%")
    
    # Test 3: Portfolio summary
    print("\n3. Portfolio Summary Dec 2025:")
    summary = query_portfolio_summary(2025, 12)
    for product, metrics in summary.items():
        print(f"   {product}: ${metrics['net_sales']/1e6:.1f}M")
    
    # Test 4: YTD Performance
    print("\n4. YTD Performance 2025:")
    ytd = query_ytd_performance(2025)
    for product, metrics in ytd.items():
        print(f"   {product}: ${metrics['actual']/1e6:.1f}M ({metrics['variance_pct']:+.1f}% vs budget)")
    
    print("\n" + "="*80)
    print("✅ All tests complete")
