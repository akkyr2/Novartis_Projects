"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
Session management for multi-user support in MBR Dashboard.

This module provides thread-safe session management with automatic cleanup
of stale sessions. Each session maintains its own conversation history and
preprocessed slide data.
"""

import threading
import time
import uuid
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class SessionData:
    """Container for session-specific data.
    
    Attributes:
        session_id: Unique identifier for the session (UUID)
        created_at: Timestamp when session was created
        last_accessed: Timestamp of last session access
        conversation_history: List of conversation messages
        preprocessed_slides_cache: Cached preprocessed slide data
        preprocessing_status: Current preprocessing status and progress
    """
    session_id: str
    created_at: datetime
    last_accessed: datetime
    conversation_history: List[Dict] = field(default_factory=list)
    preprocessed_slides_cache: Optional[Dict] = None
    preprocessing_status: Dict = field(default_factory=lambda: {
        'stage': 'idle',
        'progress': 0,
        'message': 'Ready for PDF upload',
        'currentSlide': 0,
        'totalSlides': 0
    })


class SessionManager:
    """Manages user sessions with thread-safe operations.
    
    This class provides thread-safe session management using a global lock
    to protect the session store dictionary. Sessions are automatically
    cleaned up after the specified timeout period.
    
    Attributes:
        session_store: Dictionary mapping session IDs to SessionData
        session_lock: Threading lock for thread-safe operations
        session_timeout: Timedelta for session expiration
    """
    
    def __init__(self, session_timeout_hours: int = 1):
        """Initialize the session manager.
        
        Args:
            session_timeout_hours: Hours of inactivity before session expires (default: 1)
        """
        self.session_store: Dict[str, SessionData] = {}
        self.session_lock = threading.Lock()
        self.session_timeout = timedelta(hours=session_timeout_hours)
        logger.info(f"SessionManager initialized with {session_timeout_hours}h timeout")
    
    def create_session(self, session_id: Optional[str] = None) -> SessionData:
        """Create a new session.
        
        Args:
            session_id: Optional session ID. If None, generates a new UUID.
            
        Returns:
            SessionData object for the new session
        """
        if session_id is None:
            session_id = str(uuid.uuid4())
        
        with self.session_lock:
            now = datetime.now()
            session_data = SessionData(
                session_id=session_id,
                created_at=now,
                last_accessed=now
            )
            self.session_store[session_id] = session_data
            logger.info(f"Session created: {session_id}")
            return session_data
    
    def get_session(self, session_id: str) -> Optional[SessionData]:
        """Retrieve session data and update last accessed time.
        
        Args:
            session_id: The session ID to retrieve
            
        Returns:
            SessionData if found, None otherwise
        """
        with self.session_lock:
            session_data = self.session_store.get(session_id)
            if session_data:
                session_data.last_accessed = datetime.now()
                logger.debug(f"Session accessed: {session_id}")
            else:
                logger.warning(f"Session not found: {session_id}")
            return session_data
    
    def update_session(self, session_id: str, **kwargs) -> bool:
        """Update session data fields.
        
        Args:
            session_id: The session ID to update
            **kwargs: Fields to update (must be valid SessionData attributes)
            
        Returns:
            True if session was updated, False if session not found
        """
        with self.session_lock:
            session_data = self.session_store.get(session_id)
            if not session_data:
                logger.warning(f"Cannot update - session not found: {session_id}")
                return False
            
            for key, value in kwargs.items():
                if hasattr(session_data, key):
                    setattr(session_data, key, value)
                else:
                    logger.warning(f"Invalid session attribute: {key}")
            
            session_data.last_accessed = datetime.now()
            logger.debug(f"Session updated: {session_id}")
            return True
    
    def delete_session(self, session_id: str) -> bool:
        """Delete a session.
        
        Args:
            session_id: The session ID to delete
            
        Returns:
            True if session was deleted, False if not found
        """
        with self.session_lock:
            if session_id in self.session_store:
                del self.session_store[session_id]
                logger.info(f"Session deleted: {session_id}")
                return True
            logger.warning(f"Cannot delete - session not found: {session_id}")
            return False
    
    def cleanup_stale_sessions(self) -> int:
        """Remove sessions that haven't been accessed within timeout period.
        
        Returns:
            Number of sessions removed
        """
        with self.session_lock:
            now = datetime.now()
            stale_sessions = [
                sid for sid, data in self.session_store.items()
                if now - data.last_accessed > self.session_timeout
            ]
            
            for sid in stale_sessions:
                inactive_hours = (now - self.session_store[sid].last_accessed).total_seconds() / 3600
                logger.info(f"Cleaning up stale session: {sid} (inactive: {inactive_hours:.1f}h)")
                del self.session_store[sid]
            
            if stale_sessions:
                logger.info(f"Cleaned up {len(stale_sessions)} stale sessions")
            
            return len(stale_sessions)
    
    def get_session_count(self) -> int:
        """Get count of active sessions.
        
        Returns:
            Number of active sessions
        """
        with self.session_lock:
            return len(self.session_store)


def start_session_cleanup_task(session_manager: SessionManager) -> None:
    """Start background thread for periodic session cleanup.
    
    This function starts a daemon thread that runs cleanup every hour.
    The thread will automatically stop when the main program exits.
    
    Args:
        session_manager: The SessionManager instance to clean up
    """
    def cleanup_loop():
        """Background loop that runs cleanup periodically."""
        while True:
            time.sleep(3600)  # Run every hour
            try:
                removed_count = session_manager.cleanup_stale_sessions()
                if removed_count > 0:
                    logger.info(f"Background cleanup removed {removed_count} sessions")
            except Exception as e:
                logger.error(f"Error in session cleanup: {e}", exc_info=True)
    
    cleanup_thread = threading.Thread(target=cleanup_loop, daemon=True)
    cleanup_thread.start()
    logger.info("Started session cleanup background task (runs every 1 hour)")
