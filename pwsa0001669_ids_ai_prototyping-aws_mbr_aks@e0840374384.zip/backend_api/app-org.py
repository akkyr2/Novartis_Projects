#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025

MBR Dashboard Backend API - Clean Version

A Flask-based REST API that connects the React frontend to AWS services:
- Amazon Bedrock (Claude 3.5 Sonnet v2) for AI analysis
- Amazon DynamoDB for Novartis KPI data queries
- Amazon Polly Neural for text-to-speech synthesis

Endpoints:
    POST /api/ask - Process questions about Novartis MBR slides
    POST /api/synthesize - Convert text to speech using Polly
    GET /api/health - Health check endpoint

Author: AI Assistant + User
Date: December 2025
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import boto3
from botocore.config import Config
import json
import base64
import os
import sys
import time
import logging
import traceback
import re

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import configuration
from config import config
from novartis_agent_handler_v3 import handle_question_with_agent
from aws_clients import bedrock_runtime, polly_client
from slide_preprocessor import preprocess_slides

# Configure logging
logging.basicConfig(
    level=getattr(logging, config.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s' if config.log_format == 'detailed' else '%(levelname)s: %(message)s'
)
logger = logging.getLogger(__name__)

# Print configuration summary
config.print_config_summary()

static_prefix = os.getenv('REACT_APP_BASE_URL', '')

# Create Flask app - always serve frontend from the same app for consistency
app = Flask(__name__, static_folder='frontend'+static_prefix, static_url_path=static_prefix)

# Apply Flask configuration
app.config.update(config.get_flask_config())

# Security middleware and headers
@app.after_request
def add_security_headers(response):
    """Add security headers to all responses"""
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' data: blob:"
    return response

@app.before_request
def validate_request_security():
    """Validate request for security issues"""
    # Log suspicious patterns in URLs and parameters
    suspicious_patterns = ['../', '..\\', '%2e%2e', '%2f', '%5c', '<script', 'javascript:', 'data:']
    
    request_url = request.url.lower()
    request_args = str(request.args).lower()
    
    for pattern in suspicious_patterns:
        if pattern in request_url or pattern in request_args:
            app.logger.warning(f"Suspicious request pattern detected: {pattern} from {request.remote_addr}")
            break

# Configure CORS
if config.is_local_development:
    # For local development, allow same-origin requests (since we serve frontend from Flask)
    CORS(app, origins=['http://localhost:5000', 'http://127.0.0.1:5000'] + config.cors_origins)
else:
    # More restrictive CORS for production (same-origin requests only)
    CORS(app, origins=config.cors_origins if config.cors_origins != ['*'] else False)

# AWS clients with retry configuration
boto_config = Config(
    retries={
        'max_attempts': 3,
        'mode': 'adaptive'
    },
    max_pool_connections=10,
    region_name=config.aws_region
)

# AWS clients are imported at the top

def invoke_bedrock_with_retry(request_body, max_retries=3, initial_delay=2):
    """Invoke Bedrock with exponential backoff retry logic"""
    for attempt in range(max_retries):
        try:
            response = bedrock_runtime.invoke_model(
                modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
                body=json.dumps(request_body)
            )
            return json.loads(response['body'].read())
        except Exception as e:
            if 'ServiceUnavailableException' in str(e) or 'ThrottlingException' in str(e):
                if attempt < max_retries - 1:
                    delay = initial_delay * (2 ** attempt)
                    print(f"⏳ Rate limited, retrying in {delay}s... (attempt {attempt + 1}/{max_retries})")
                    time.sleep(delay)
                else:
                    raise
            else:
                raise

@app.route('/api/ask', methods=['POST'])
def ask_question():
    """Handle question from frontend using Novartis agent handler"""
    try:
        data = request.json
        question = data.get('question', '')
        slide_number = data.get('slideNumber', 1)
        conversation_history = data.get('conversationHistory', [])
        
        if not question:
            return jsonify({'error': 'No question provided'}), 400
        
        # Resolve follow-up questions using conversation context
        resolved_question = resolve_follow_up_question(question, conversation_history)
        
        # Use resolved question for processing
        if resolved_question != question:
            print(f"🔄 Resolved follow-up question:")
            print(f"   Original: {question}")
            print(f"   Resolved: {resolved_question}")
            question = resolved_question
        
        # Use Novartis agent-based handler
        start_time = time.time()
        timing = {}
        
        print(f"🤖 Using Novartis agent handler")
        print(f"   Question: {question}")
        
        # Load slide image and preprocessed data
        load_start = time.time()
        
        # Secure slide loading with path traversal protection
        from backend_api.secure_file_handler import SecureFileHandler, validate_slide_number
        
        try:
            # Validate slide number
            validated_slide_num = validate_slide_number(slide_number, max_slides=100)
            
            # Initialize secure file handler
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            allowed_dirs = [
                os.path.join(project_root, 'uploads', 'slides'),
                os.path.join(project_root, 'data_sample', 'slide_images')
            ]
            file_handler = SecureFileHandler(allowed_dirs)
            
            # Define filename
            filename = f'slide_{validated_slide_num:02d}.png'
            
            # Try uploaded slides first
            image_base64 = None
            slide_path = None
            
            try:
                uploads_dir = os.path.join(project_root, 'uploads', 'slides')
                image_bytes = file_handler.safe_read_file(filename, uploads_dir, 'rb')
                image_base64 = base64.b64encode(image_bytes).decode('utf-8')
                print(f"   ✓ Loaded slide from uploads: {uploads_dir}/{filename}")
            except (ValueError, FileNotFoundError):
                # Fallback to sample slides
                try:
                    sample_dir = os.path.join(project_root, 'data_sample', 'slide_images')
                    image_bytes = file_handler.safe_read_file(filename, sample_dir, 'rb')
                    image_base64 = base64.b64encode(image_bytes).decode('utf-8')
                    print(f"   ✓ Loaded slide from samples: {sample_dir}/{filename}")
                except (ValueError, FileNotFoundError):
                    print(f"   ✗ Slide {validated_slide_num} not found in any directory")
                    
        except ValueError as e:
            print(f"   ✗ Invalid slide number: {e}")
            image_base64 = None
        
        # Load preprocessed slide context
        slide_context = get_slide_context(slide_number)
        if slide_context:
            print(f"   ✓ Using preprocessed data for slide {slide_number}")
            print(f"     Title: {slide_context.get('title', 'N/A')}")
        
        timing['data_load'] = round(time.time() - load_start, 2)
        
        # Use Novartis agent-based handler with conversation history
        agent_start = time.time()
        answer, chart_data, audio_summary, data_source = handle_question_with_agent(
            question, 
            image_base64, 
            conversation_history,
            slide_number=slide_number,
            use_preprocessed=True  # Enable preprocessed data
        )
        timing['agent_processing'] = round(time.time() - agent_start, 2)
        
        timing['total'] = round(time.time() - start_time, 2)
        
        print(f"⏱️ Timing breakdown: {timing}")
        
        response = {
            'answer': answer,
            'audioSummary': audio_summary,  # Polly-friendly version
            'dataSource': data_source,  # DynamoDB table used
            'mode': 'novartis-agent',
            'timing': timing
        }
        
        if chart_data:
            response['chartData'] = chart_data
        
        print(f"📤 Sending response with timing: {response.get('timing')}")
        return jsonify(response)
        
    except Exception as e:
        error_msg = f"❌ Error in /api/ask: {str(e)}"
        print(error_msg, flush=True)  # Force flush to stdout
        logger.error(error_msg)
        logger.error(f"Traceback: {traceback.format_exc()}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/synthesize', methods=['POST'])
def synthesize_speech():
    """Convert text to speech using Amazon Polly Neural"""
    try:
        data = request.json
        text = data.get('text', '')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        print(f"\n🔊 Synthesizing speech: {text[:100]}...")
        
        # Use Polly Neural for high-quality speech
        response = polly_client.synthesize_speech(
            Text=text,
            OutputFormat='mp3',
            VoiceId='Joanna',  # Neural voice
            Engine='neural'
        )
        
        # Get audio stream
        audio_stream = response['AudioStream'].read()
        
        # Convert to base64 for frontend
        audio_base64 = base64.b64encode(audio_stream).decode('utf-8')
        
        return jsonify({
            'audioData': audio_base64,
            'contentType': 'audio/mpeg'
        })
        
    except Exception as e:
        print(f"❌ Polly error: {e}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def resolve_follow_up_question(question, conversation_history):
    """Resolve follow-up questions using conversation context"""
    q_lower = question.lower().strip()
    
    # Skip resolution for complete questions
    if len(question.split()) > 8:
        return question
    
    # Common follow-up patterns
    follow_up_patterns = [
        'what about', 'how about', 'and for', 'what for', 'show me',
        'can you', 'could you', 'tell me about', 'what are', 'how are',
        'compare', 'versus', 'vs', 'difference', 'between'
    ]
    
    is_follow_up = any(pattern in q_lower for pattern in follow_up_patterns)
    
    if is_follow_up and conversation_history:
        # Get the last user question for context
        last_user_question = None
        for msg in reversed(conversation_history):
            if msg.get('role') == 'user':
                last_user_question = msg.get('content', '')
                break
        
        if last_user_question:
            # Extract context from previous question
            context = extract_query_context(last_user_question)
            
            if context:
                # Build resolved question
                resolved = f"{question}"
                
                # Add product context if missing
                if context.get('product') and not any(p.lower() in q_lower for p in ['pluvicto', 'lutathera', 'xofigo', 'novacure']):
                    resolved = f"{question} for {context['product']}"
                
                # Add time context if missing
                if context.get('time_period') and not any(t in q_lower for t in ['2020', '2021', '2022', '2023', '2024', '2025']):
                    resolved = f"{resolved} in {context['time_period']}"
                
                return resolved
    
    return question

def extract_query_context(response_text):
    """Extract query context from assistant response"""
    context = {
        'product': None,
        'time_period': None,
        'metric_type': None
    }
    
    text_lower = response_text.lower()
    
    # Extract product
    products = ['pluvicto', 'lutathera', 'xofigo', 'novacure']
    for product in products:
        if product in text_lower:
            context['product'] = product.title()
            break
    
    # Extract time period
    year_match = re.search(r'\b(20\d{2})\b', response_text)
    if year_match:
        context['time_period'] = year_match.group(1)
    
    # Extract metric type
    if 'sales' in text_lower or 'revenue' in text_lower:
        context['metric_type'] = 'sales'
    elif 'dose' in text_lower or 'prescription' in text_lower:
        context['metric_type'] = 'doses'
    elif 'market share' in text_lower or 'share' in text_lower:
        context['metric_type'] = 'market_share'
    
    return context

# Preprocessed slides cache
preprocessed_slides_cache = None

# Global preprocessing status
preprocessing_status = {
    'stage': 'idle',
    'progress': 0,
    'message': 'Ready for PDF upload',
    'currentSlide': 0,
    'totalSlides': 0
}

def load_preprocessed_slides():
    """Load preprocessed slide data from JSON file with security protection"""
    from backend_api.secure_file_handler import SecureFileHandler
    global preprocessed_slides_cache
    
    if preprocessed_slides_cache is not None:
        return preprocessed_slides_cache
    
    # Define allowed directories for preprocessed data
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    allowed_dirs = [
        os.path.join(project_root, 'uploads'),
        os.path.join(project_root, 'data_sample')
    ]
    
    file_handler = SecureFileHandler(allowed_dirs)
    filename = 'preprocessed_slides.json'
    
    # Try each allowed directory
    for base_dir in allowed_dirs:
        try:
            file_content = file_handler.safe_read_file(filename, base_dir, 'r')
            preprocessed_slides_cache = json.loads(file_content)
            print(f"✅ Loaded {len(preprocessed_slides_cache)} preprocessed slides from {base_dir}/{filename}")
            return preprocessed_slides_cache
        except (ValueError, FileNotFoundError, json.JSONDecodeError) as e:
            continue
        except Exception as e:
            print(f"⚠️ Error loading preprocessed slides from {base_dir}: {e}")
            continue
    
    print(f"⚠️ No preprocessed slides found in allowed directories")
    return None

def get_slide_context(slide_number):
    """Get preprocessed context for a specific slide"""
    slides_data = load_preprocessed_slides()
    if slides_data:
        for slide in slides_data:
            if slide.get('slide_number') == slide_number:
                return slide
    return None

@app.route('/api/preprocess', methods=['POST'])
def preprocess_pdf():
    """
    Upload and preprocess PDF slides
    Extracts images and processes them with Vision Model
    """
    global preprocessing_status, preprocessed_slides_cache
    
    # Clear the cache so new preprocessing results are loaded
    preprocessed_slides_cache = None
    print("🔄 Cleared preprocessed slides cache")
    
    try:
        # Check if PDF file is present
        if 'pdf' not in request.files:
            return jsonify({'error': 'No PDF file provided'}), 400
        
        pdf_file = request.files['pdf']
        if pdf_file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not pdf_file.filename.endswith('.pdf'):
            return jsonify({'error': 'File must be a PDF'}), 400
        
        # Save PDF temporarily - use environment-aware path
        if config.is_aws_deployment:
            upload_dir = '/app/uploads'
        else:
            # Local development - use project root
            upload_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads')
        os.makedirs(upload_dir, exist_ok=True)
        
        pdf_path = os.path.join(upload_dir, 'presentation.pdf')
        pdf_file.save(pdf_path)
        
        # Update status
        preprocessing_status = {
            'stage': 'extracting',
            'progress': 0.2,
            'message': 'Extracting slides from PDF',
            'currentSlide': 0,
            'totalSlides': 0
        }
        
        # Use preprocessing function (imported at top)
        
        # Start preprocessing in background (for demo, we'll do it synchronously)
        print("🚀 Starting slide preprocessing...")
        
        # Run preprocessing
        result = preprocess_slides(pdf_path)
        
        # Check if result has total_slides (success case)
        if 'total_slides' in result:
            preprocessing_status = {
                'stage': 'complete',
                'progress': 1.0,
                'message': 'Preprocessing complete!',
                'currentSlide': result['total_slides'],
                'totalSlides': result['total_slides']
            }
            
            return jsonify({
                'message': 'PDF uploaded and preprocessing started',
                'status': 'success',
                'totalSlides': result['total_slides']
            })
        else:
            preprocessing_status = {
                'stage': 'error',
                'progress': 0,
                'message': 'Preprocessing failed',
                'currentSlide': 0,
                'totalSlides': 0
            }
            return jsonify({'error': 'Preprocessing failed'}), 500
            
    except Exception as e:
        print(f"❌ Preprocessing error: {str(e)}")
        preprocessing_status = {
            'stage': 'error',
            'progress': 0,
            'message': f'Upload failed: {str(e)}',
            'currentSlide': 0,
            'totalSlides': 0
        }
        return jsonify({'error': str(e)}), 500

@app.route('/api/preprocess/status', methods=['GET'])
def get_preprocessing_status():
    """Get current preprocessing status"""
    global preprocessing_status
    return jsonify(preprocessing_status)

@app.route('/api/slides/<int:slide_number>', methods=['GET'])
def get_slide_image(slide_number):
    """Serve uploaded slide images with security protection"""
    try:
        from backend_api.secure_file_handler import SecureFileHandler, validate_slide_number
        
        # Validate slide number
        validated_slide_num = validate_slide_number(slide_number, max_slides=100)
        
        # Initialize secure file handler with environment-aware paths
        if config.is_aws_deployment:
            allowed_dirs = [
                '/app/uploads/slides',
                '/app/data_sample/slide_images'
            ]
            uploads_dir = '/app/uploads/slides'
            sample_dir = '/app/data_sample/slide_images'
        else:
            # Local development paths
            project_root = os.path.dirname(os.path.dirname(__file__))
            allowed_dirs = [
                os.path.join(project_root, 'uploads', 'slides'),
                os.path.join(project_root, 'data_sample', 'slide_images')
            ]
            uploads_dir = os.path.join(project_root, 'uploads', 'slides')
            sample_dir = os.path.join(project_root, 'data_sample', 'slide_images')
        
        file_handler = SecureFileHandler(allowed_dirs)
        filename = f'slide_{validated_slide_num:02d}.png'
        
        # Try uploaded slides first, then sample slides
        try:
            image_data = file_handler.safe_read_file(filename, uploads_dir, 'rb')
            image_data_b64 = base64.b64encode(image_data).decode('utf-8')
            return jsonify({'imageData': image_data_b64})
        except (ValueError, FileNotFoundError):
            # Fallback to sample slides
            try:
                image_data = file_handler.safe_read_file(filename, sample_dir, 'rb')
                image_data_b64 = base64.b64encode(image_data).decode('utf-8')
                return jsonify({'imageData': image_data_b64})
            except (ValueError, FileNotFoundError):
                return jsonify({'error': 'Slide not found'}), 404
                
    except ValueError as e:
        app.logger.warning(f"Invalid slide request: {str(e)}")
        return jsonify({'error': 'Invalid slide number'}), 400
    except Exception as e:
        app.logger.error(f"Error serving slide {slide_number}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'ok', 'message': 'Novartis MBR Dashboard API is running'})



# Frontend serving routes (for both local and AWS deployment)
@app.route('/')
def serve_frontend():
    """Serve the React frontend index.html"""
    try:
        return send_from_directory(app.static_folder, 'index.html')
    except Exception as e:
        logger.error(f"Error serving frontend: {str(e)}")
        return jsonify({'error': 'Frontend not available. Run: npm run build && cp -r frontend/build backend_api/frontend'}), 404

@app.route('/<path:path>')
def serve_static_files(path):
    """Serve static files for the React frontend"""
    try:
        return send_from_directory(app.static_folder, path)
    except Exception as e:
        # For React Router, serve index.html for unknown routes
        if not path.startswith('api/'):
            try:
                return send_from_directory(app.static_folder, 'index.html')
            except:
                pass
        logger.error(f"Error serving static file {path}: {str(e)}")
        return jsonify({'error': f'File not found: {path}'}), 404

if __name__ == '__main__':
    logger.info(f"Starting MBR Dashboard Backend API")
    logger.info(f"Environment: {config.environment}")
    logger.info(f"Debug Mode: {config.debug}")
    logger.info(f"Port: {config.port}")
    
    app.run(
        host=config.host,
        port=config.port,
        debug=config.debug and config.hot_reload
    )