#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Novartis Agent-Based Query Handler

Uses Claude with function calling to dynamically query Novartis DynamoDB
based on user questions about pharmaceutical sales, market share, and doses.
"""

import json
import boto3
from botocore.config import Config
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend_api.novartis_queries import (
    query_sales,
    query_market_share,
    query_doses,
    query_portfolio_summary,
    query_ytd_performance,
    query_product_comparison,
    query_quarterly_doses,
    query_quarterly_sales,
    query_year_over_year,
    query_month_over_month,
    query_all_competitors
)

# AWS clients
boto_config = Config(
    retries={'max_attempts': 3, 'mode': 'adaptive'},
    max_pool_connections=10
)

bedrock_runtime = boto3.client(
    'bedrock-runtime',
    region_name='us-east-1',
    config=boto_config
)

# Define tools for Novartis data
NOVARTIS_TOOLS = [
    {
        "name": "query_product_sales",
        "description": "Query sales data for ONE SPECIFIC product (Pluvicto, Lutathera, Xofigo, or Novacure) for a given year. Returns monthly net sales, gross sales, and revenue deductions. USE ONLY when the question asks about a specific product by name. For portfolio-wide or total sales questions, use query_portfolio_ytd instead.",
        "input_schema": {
            "type": "object",
            "properties": {
                "product": {
                    "type": "string",
                    "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"],
                    "description": "Product name"
                },
                "year": {
                    "type": "integer",
                    "description": "Year (2020-2028)"
                },
                "forecast_type": {
                    "type": "string",
                    "enum": ["Actual", "Budget", "OC"],
                    "description": "Forecast type: Actual (historical), Budget (plan), or OC (latest estimate)"
                }
            },
            "required": ["product", "year"]
        }
    },
    {
        "name": "query_product_market_share",
        "description": "Query market share data for a product. Returns TRX share and NBRX share (R3M rolling 3-month average).",
        "input_schema": {
            "type": "object",
            "properties": {
                "product": {
                    "type": "string",
                    "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"],
                    "description": "Product name"
                },
                "year": {
                    "type": "integer",
                    "description": "Year (2020-2028)"
                }
            },
            "required": ["product", "year"]
        }
    },
    {
        "name": "query_product_doses",
        "description": "Query dose shipment and injection data for a product. Metrics include TRX_shipped (doses shipped), TRX_injected (doses administered), and NBRX (new patient prescriptions).",
        "input_schema": {
            "type": "object",
            "properties": {
                "product": {
                    "type": "string",
                    "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"],
                    "description": "Product name"
                },
                "metric": {
                    "type": "string",
                    "enum": ["TRX_shipped", "TRX_injected", "NBRX"],
                    "description": "Dose metric type"
                },
                "year": {
                    "type": "integer",
                    "description": "Year (2020-2028)"
                }
            },
            "required": ["product", "metric", "year"]
        }
    },
    {
        "name": "query_portfolio_ytd",
        "description": "Query year-to-date performance for ALL products in the portfolio (total sales across Pluvicto, Lutathera, Xofigo, Novacure). Returns actual vs budget comparison with variance for each product AND portfolio totals. USE THIS for questions about: 'total sales', 'portfolio performance', 'overall sales', 'all products', 'actual vs budget', 'forecast vs actual', or any general sales questions not specific to one product.",
        "input_schema": {
            "type": "object",
            "properties": {
                "year": {
                    "type": "integer",
                    "description": "Year (2020-2028)"
                }
            },
            "required": ["year"]
        }
    },
    {
        "name": "query_monthly_summary",
        "description": "Query portfolio summary for a specific month across all products.",
        "input_schema": {
            "type": "object",
            "properties": {
                "year": {
                    "type": "integer",
                    "description": "Year"
                },
                "month": {
                    "type": "integer",
                    "description": "Month (1-12)"
                }
            },
            "required": ["year", "month"]
        }
    },
    {
        "name": "query_quarterly_doses",
        "description": "Query quarterly dose shipment performance for ALL products with BOTH Actual and Budget in ONE call. Returns Q1, Q2, Q3, Q4, and YTD totals for all products with Actual vs Budget comparison. USE THIS for quarterly dose questions. Perfect for 'targets missed/exceeded' questions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "year": {
                    "type": "integer",
                    "description": "Year (2020-2028)"
                }
            },
            "required": ["year"]
        }
    },
    {
        "name": "query_quarterly_sales",
        "description": "Query quarterly sales performance for ALL products with BOTH Actual and Budget in ONE call. Returns Q1, Q2, Q3, Q4, and YTD totals for all products with Actual vs Budget comparison. USE THIS for quarterly sales questions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "year": {
                    "type": "integer",
                    "description": "Year (2020-2028)"
                }
            },
            "required": ["year"]
        }
    },
    {
        "name": "query_year_over_year",
        "description": "Compare year-over-year performance across multiple years for ALL products. Returns data for each year AND calculates YoY growth percentage. USE THIS for 'vs previous year', 'YoY growth', 'compare 2024 vs 2025' questions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "metric": {
                    "type": "string",
                    "enum": ["sales", "doses", "market_share"],
                    "description": "Metric to compare: sales (revenue), doses (TRX_shipped), or market_share"
                },
                "years": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Years to compare (e.g., [2024, 2025])"
                }
            },
            "required": ["metric", "years"]
        }
    },
    {
        "name": "query_month_over_month",
        "description": "Compare month-over-month performance for ONE product. Returns current month, previous month, and MoM change percentage. USE THIS for 'MoM growth', 'vs last month', 'monthly change' questions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "product": {
                    "type": "string",
                    "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"],
                    "description": "Product name"
                },
                "metric": {
                    "type": "string",
                    "enum": ["sales", "doses", "market_share"],
                    "description": "Metric to compare"
                },
                "year": {
                    "type": "integer",
                    "description": "Current year"
                },
                "month": {
                    "type": "integer",
                    "description": "Current month (1-12)"
                }
            },
            "required": ["product", "metric", "year", "month"]
        }
    },
    {
        "name": "query_all_competitors",
        "description": "Query market share for ALL brands including competitors, ranked by share. USE THIS for 'biggest competitor', 'top brands', 'all competitors', 'market ranking' questions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "year": {
                    "type": "integer",
                    "description": "Year"
                },
                "month": {
                    "type": "integer",
                    "description": "Optional specific month (1-12), omit for yearly average"
                }
            },
            "required": ["year"]
        }
    }
]

SYSTEM_PROMPT = """You are an AI assistant for Novartis RLT (Radioligand Therapy) Portfolio Monthly Business Review (MBR).

Your role is to help executives analyze pharmaceutical sales performance, market dynamics, and operational metrics.

**Available Data:**
- **Products**: Pluvicto, Lutathera, Xofigo, Novacure
- **Time Period**: 2020-2025 (Actual historical data), 2026-2028 (Budget/OC forecasts)
- **Metrics**:
  - Sales: Net sales, gross sales, revenue deductions
  - Market: TRX share (total prescriptions), NBRX share (new patients), R3M (rolling 3-month)
  - Doses: TRX_shipped, TRX_injected, NBRX (new patient doses)

**Forecast Types - When to Use:**
- **Actual**: Historical data (2020-2025) - use for "what happened", "actual sales", "real performance"
- **Budget**: Original annual plan - use for "budget", "plan", "target", "goal", "vs budget"
- **OC (Operating Committee)**: Latest forecast/estimate - use for "forecast", "projection", "latest estimate", "expected"

**Default Logic:**
- For historical years (2020-2025): Use "Actual"
- For future years (2026-2028): Use "OC" (latest forecast) unless user specifically asks for "budget"
- When comparing: Use both Actual and Budget (e.g., "actual vs budget")

**CRITICAL - Product Name Matching (Voice Recognition):**
When users ask about products via voice, they may mispronounce names. Map these variations to the correct product:

- **Pluvicto** (correct): "pluvicto", "plu victo", "play victor", "pluvecto", "pluvikto", "ploo victo"
- **Lutathera** (correct): "lutathera", "luta thera", "luther", "luthera", "luthara", "loo ta thera"
- **Xofigo** (correct): "xofigo", "zo figo", "zofigo", "ex ofigo", "sofigo", "xo figo"
- **Novacure** (correct): "novacure", "nova cure", "novacur", "nova cur", "novo cure"

**Always map misspelled/mispronounced product names to the correct spelling before calling tools.**

**Key Context:**
- **Pluvicto**: Blockbuster product, largest revenue contributor (~45% of portfolio)
- **Lutathera**: Mature product, stable performance (~25% of portfolio)
- **Xofigo**: Declining product, facing competitive pressure (~18% of portfolio)
- **Novacure**: Smaller product, steady growth (~12% of portfolio)

**Historical Events:**
- **2020 Q2-Q4**: COVID-19 impact (sales dropped 10-20% below budget)
- **2022 Q2**: Production issues (sales dropped 5-15% below budget)
- **2023-2025**: Recovery and growth period

**CRITICAL - Tool Selection Rules (TABLE_ROUTING_GUIDE):**

Use this decision tree to select the correct tool:

1. **MARKET SHARE or COMPETITORS?**
   → Use `query_product_market_share`
   - Any question mentioning competitors, market dynamics, share trends
   - Examples: "market share vs competitors", "how are we doing vs market"

2. **REVENUE or SALES PERFORMANCE for ONE specific product?**
   → Use `query_product_sales`
   - Single product sales analysis (Pluvicto, Lutathera, Xofigo, Novacure)
   - Budget vs Actual for one product
   - Examples: "Pluvicto sales", "Lutathera revenue trend"

3. **PORTFOLIO-WIDE or TOTAL SALES?**
   → Use `query_portfolio_ytd`
   - Questions about "total sales", "overall performance", "all products"
   - Portfolio actual vs budget comparison
   - Examples: "total revenue", "portfolio performance", "how are we doing overall"

4. **DOSES or PRESCRIPTIONS?**
   → Use `query_product_doses`
   - TRX_shipped, TRX_injected, NBRX metrics
   - National-level dose analysis
   - Examples: "doses shipped", "prescription volume", "new patient starts"

5. **QUARTERLY DOSES or SALES?**
   → Use `query_quarterly_doses` or `query_quarterly_sales`
   - Questions about "quarterly", "Q1", "Q2", "Q3", "Q4", "quarter"
   - Quarterly targets, quarterly performance, quarterly comparison
   - Examples: "quarterly dose targets", "Q1 vs Q2 sales", "quarterly revenue"
   - Returns ALL products in ONE call - never call query_product_doses multiple times

6. **MONTHLY SNAPSHOT across products?**
   → Use `query_monthly_summary`
   - Specific month portfolio view
   - Product mix for a given month

7. **YEAR-OVER-YEAR COMPARISON?**
   → Use `query_year_over_year`
   - Questions about "vs previous year", "YoY growth", "compare 2024 vs 2025"
   - Returns data for multiple years AND growth percentages
   - Examples: "sales vs last year", "YoY dose growth"

8. **MONTH-OVER-MONTH COMPARISON?**
   → Use `query_month_over_month`
   - Questions about "vs last month", "MoM growth", "monthly change"
   - Returns current month, previous month, and change percentage
   - Examples: "Pluvicto sales vs last month", "MoM dose growth"

9. **COMPETITOR ANALYSIS?**
   → Use `query_all_competitors`
   - Questions about "biggest competitor", "top brands", "market ranking"
   - Returns all brands ranked by market share
   - Examples: "who is our biggest competitor", "top 3 brands"

**Tool Selection Priority:**
- If question mentions "market share" or "competitors" → ALWAYS use market share tool
- If question asks about "total" or "portfolio" or "all products" → ALWAYS use portfolio_ytd tool
- If question names ONE specific product + sales/revenue → use product_sales tool
- If question asks about doses/prescriptions → use doses tool
- When in doubt between product_sales and portfolio_ytd → choose portfolio_ytd for broader questions

**🚨 CRITICAL DATA ARCHITECTURE RULE - READ THIS FIRST:**
- **Each question = EXACTLY ONE tool call**
- **NEVER call the same tool multiple times** (e.g., query_product_doses for Pluvicto, then Lutathera, then Xofigo)
- **NEVER call different data tools together** (e.g., query_product_sales + query_market_share)
- If a question needs multiple products, use portfolio-level tools (query_portfolio_ytd, query_quarterly_doses, query_quarterly_sales)
- Quarterly tools (query_quarterly_doses, query_quarterly_sales) automatically return BOTH Actual and Budget - no need to call twice

**Valid patterns:**
1. ONE call for single product: query_product_sales(Pluvicto, 2025, Actual)
2. ONE call for quarterly with comparison: query_quarterly_doses(2025) → returns Actual AND Budget
3. ONE call for portfolio: query_portfolio_ytd(2025)

**If you find yourself wanting to call a tool more than once, STOP - you picked the wrong tool!**

**Your Approach:**
1. **CRITICAL:** Only use numbers and data that are explicitly provided in the slide context or from DynamoDB queries
2. Do NOT invent, estimate, or hallucinate numbers that aren't shown
3. If you need additional data beyond what's in the slide, use the DynamoDB query tools
4. **IMPORTANT:** Make ALL necessary tool calls in ONE turn - do NOT say "let me query" or "I need to get" - just query it
5. Analyze trends, variances, and patterns based on actual data
6. Provide executive-level insights with context
7. Highlight significant changes or concerns

**Response Style:**
- Professional and concise
- Focus on business impact
- Use pharmaceutical terminology appropriately
- Provide actionable insights
- Include data to support conclusions
- **NEVER make up percentages or variances** - only report what's explicitly shown

**Data Accuracy Rules:**
- If a slide shows products are "close to budget", say that - don't claim large variances
- If specific numbers aren't provided, say "data not available on this slide" and offer to query DynamoDB
- When comparing actual vs budget, only report the variance if it's explicitly shown or calculable from provided numbers

**CRITICAL - Chart Generation Rules:**
- **DO NOT generate ASCII charts, bar charts, or visual representations in your text response**
- **DO NOT use markdown code blocks to create text-based visualizations**
- When you query data using tools, the system will automatically generate professional interactive charts
- Simply describe the data insights in text - the frontend will handle visualization
- Focus on analysis and interpretation, not visual representation
- Example: Instead of drawing a bar chart, say "Pluvicto leads with 29,191 doses, followed by Lutathera at 18,168 doses"

When you need data, use the available tools to query DynamoDB. Always provide context and interpretation, not just raw numbers."""

def generate_chart_data(tool_name, tool_input, tool_result):
    """Generate chart data from tool results for frontend visualization"""
    if not tool_result.get('success') or not tool_result.get('data'):
        return None
    
    try:
        if tool_name == "query_product_sales":
            # Line chart for sales trend
            product = tool_input.get('product')
            year = tool_input.get('year')
            forecast_type = tool_input.get('forecast_type', 'Actual')
            
            chart_data = []
            for record in tool_result['data']:
                chart_data.append({
                    'month': f"{int(record['year'])}-{int(record['month']):02d}",
                    'sales': round(float(record['net_sales']) / 1e6, 1)  # Convert to millions
                })
            
            return {
                'type': 'line',
                'title': f"{product} {forecast_type} Sales - {year}",
                'data': chart_data,
                'xKey': 'month',
                'yKey': 'sales',
                'yLabel': 'Net Sales ($M)'
            }
        
        elif tool_name == "query_product_market_share":
            # Line chart for market share trend
            product = tool_input.get('product')
            year = tool_input.get('year')
            
            chart_data = []
            for record in tool_result['data']:
                chart_data.append({
                    'month': f"{int(record['year'])}-{int(record['month']):02d}",
                    'share': round(float(record['trx_share_r3m']), 1)
                })
            
            return {
                'type': 'line',
                'title': f"{product} Market Share (TRX R3M) - {year}",
                'data': chart_data,
                'xKey': 'month',
                'yKey': 'share',
                'yLabel': 'Market Share (%)'
            }
        
        elif tool_name == "query_product_doses":
            # Bar chart for dose metrics
            product = tool_input.get('product')
            metric = tool_input.get('metric')
            year = tool_input.get('year')
            
            chart_data = []
            for record in tool_result['data']:
                chart_data.append({
                    'month': f"{int(record['year'])}-{int(record['month']):02d}",
                    'doses': round(float(record['value']))
                })
            
            return {
                'type': 'bar',
                'title': f"{product} {metric} - {year}",
                'data': chart_data,
                'xKey': 'month',
                'yKey': 'doses',
                'yLabel': 'Doses'
            }
        
        elif tool_name == "query_portfolio_ytd":
            # Bar chart for YTD comparison
            year = tool_input.get('year')
            
            chart_data = []
            for product, metrics in tool_result['data'].items():
                chart_data.append({
                    'product': product,
                    'actual': round(metrics['actual'] / 1e6, 1),
                    'budget': round(metrics['budget'] / 1e6, 1)
                })
            
            return {
                'type': 'bar',
                'title': f"YTD {year} Portfolio Performance (Actual vs Budget)",
                'data': chart_data,
                'xKey': 'product',
                'yKey': 'actual',
                'yLabel': 'Sales ($M)'
            }
        
        elif tool_name == "query_monthly_summary":
            # Pie chart for product mix
            year = tool_input.get('year')
            month = tool_input.get('month')
            
            chart_data = []
            for product, metrics in tool_result['data'].items():
                chart_data.append({
                    'product': product,
                    'sales': round(metrics['net_sales'] / 1e6, 1)
                })
            
            return {
                'type': 'pie',
                'title': f"Product Mix - {year}-{month:02d}",
                'data': chart_data,
                'xKey': 'product',
                'yKey': 'sales',
                'yLabel': 'Sales ($M)'
            }
        
        return None
    
    except Exception as e:
        print(f"⚠️ Chart generation error: {e}")
        return None

def execute_tool(tool_name, tool_input):
    """Execute a tool and return results"""
    try:
        if tool_name == "query_product_sales":
            product = tool_input.get('product')
            year = tool_input.get('year')
            forecast_type = tool_input.get('forecast_type', 'Actual')
            
            results = query_sales(product, year, forecast_type)
            
            if results:
                total_sales = sum(r['net_sales'] for r in results)
                return {
                    "success": True,
                    "data": results,
                    "summary": f"{product} {forecast_type} sales for {year}: ${total_sales/1e6:.1f}M across {len(results)} months"
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_product_market_share":
            product = tool_input.get('product')
            year = tool_input.get('year')
            
            results = query_market_share(product, year)
            
            if results:
                avg_share = sum(r['trx_share_r3m'] for r in results) / len(results)
                return {
                    "success": True,
                    "data": results,
                    "summary": f"{product} average market share for {year}: {avg_share:.1f}% (R3M)"
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_product_doses":
            product = tool_input.get('product')
            metric = tool_input.get('metric')
            year = tool_input.get('year')
            
            results = query_doses(product, metric, year)
            
            if results:
                total_doses = sum(r['value'] for r in results)
                return {
                    "success": True,
                    "data": results,
                    "summary": f"{product} {metric} for {year}: {int(total_doses):,} doses across {len(results)} months"
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_portfolio_ytd":
            year = tool_input.get('year')
            
            results = query_ytd_performance(year)
            
            if results:
                summary_lines = []
                for product, metrics in results.items():
                    summary_lines.append(
                        f"{product}: ${metrics['actual']/1e6:.1f}M actual vs ${metrics['budget']/1e6:.1f}M budget ({metrics['variance_pct']:+.1f}%)"
                    )
                
                return {
                    "success": True,
                    "data": results,
                    "summary": f"YTD {year} Portfolio Performance:\n" + "\n".join(summary_lines)
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_monthly_summary":
            year = tool_input.get('year')
            month = tool_input.get('month')
            
            results = query_portfolio_summary(year, month)
            
            if results:
                summary_lines = []
                total = 0
                for product, metrics in results.items():
                    summary_lines.append(f"{product}: ${metrics['net_sales']/1e6:.1f}M")
                    total += metrics['net_sales']
                
                return {
                    "success": True,
                    "data": results,
                    "summary": f"Portfolio Summary {year}-{month:02d}:\n" + "\n".join(summary_lines) + f"\nTotal: ${total/1e6:.1f}M"
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_quarterly_doses":
            year = tool_input.get('year')
            
            results = query_quarterly_doses(year)
            
            if results:
                summary_lines = []
                summary_lines.append("Actual vs Budget:")
                for quarter in ['Q1', 'Q2', 'Q3', 'Q4']:
                    actual_total = sum(results['Actual'][quarter].values())
                    budget_total = sum(results['Budget'][quarter].values())
                    variance = actual_total - budget_total
                    variance_pct = (variance / budget_total * 100) if budget_total > 0 else 0
                    summary_lines.append(f"{quarter}: {int(actual_total):,} actual vs {int(budget_total):,} budget ({variance_pct:+.1f}%)")
                
                ytd_actual = sum(results['Actual']['YTD'].values())
                ytd_budget = sum(results['Budget']['YTD'].values())
                ytd_variance_pct = ((ytd_actual - ytd_budget) / ytd_budget * 100) if ytd_budget > 0 else 0
                summary_lines.append(f"YTD: {int(ytd_actual):,} actual vs {int(ytd_budget):,} budget ({ytd_variance_pct:+.1f}%)")
                
                return {
                    "success": True,
                    "data": results,
                    "summary": f"Quarterly Doses {year}:\n" + "\n".join(summary_lines)
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_quarterly_sales":
            year = tool_input.get('year')
            
            results = query_quarterly_sales(year)
            
            if results:
                summary_lines = []
                summary_lines.append("Actual vs Budget:")
                for quarter in ['Q1', 'Q2', 'Q3', 'Q4']:
                    actual_total = sum(results['Actual'][quarter].values())
                    budget_total = sum(results['Budget'][quarter].values())
                    variance = actual_total - budget_total
                    variance_pct = (variance / budget_total * 100) if budget_total > 0 else 0
                    summary_lines.append(f"{quarter}: ${actual_total/1e6:.1f}M actual vs ${budget_total/1e6:.1f}M budget ({variance_pct:+.1f}%)")
                
                ytd_actual = sum(results['Actual']['YTD'].values())
                ytd_budget = sum(results['Budget']['YTD'].values())
                ytd_variance_pct = ((ytd_actual - ytd_budget) / ytd_budget * 100) if ytd_budget > 0 else 0
                summary_lines.append(f"YTD: ${ytd_actual/1e6:.1f}M actual vs ${ytd_budget/1e6:.1f}M budget ({ytd_variance_pct:+.1f}%)")
                
                return {
                    "success": True,
                    "data": results,
                    "summary": f"Quarterly Sales {year}:\n" + "\n".join(summary_lines)
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_year_over_year":
            metric = tool_input.get('metric')
            years = tool_input.get('years')
            
            results = query_year_over_year(metric, years)
            
            if results:
                summary_lines = []
                for year in years:
                    year_str = str(year)
                    if year_str in results:
                        total = sum(results[year_str].values())
                        if metric == 'sales':
                            summary_lines.append(f"{year}: ${total/1e6:.1f}M")
                        elif metric == 'doses':
                            summary_lines.append(f"{year}: {int(total):,} doses")
                        elif metric == 'market_share':
                            avg = total / len(results[year_str])
                            summary_lines.append(f"{year}: {avg:.1f}% avg share")
                
                if 'growth' in results:
                    summary_lines.append("\nYoY Growth:")
                    for product, growth in results['growth'].items():
                        summary_lines.append(f"  {product}: {growth:+.1f}%")
                
                return {
                    "success": True,
                    "data": results,
                    "summary": f"Year-over-Year {metric.title()}:\n" + "\n".join(summary_lines)
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_month_over_month":
            product = tool_input.get('product')
            metric = tool_input.get('metric')
            year = tool_input.get('year')
            month = tool_input.get('month')
            
            results = query_month_over_month(product, metric, year, month)
            
            if results:
                current = results['current']
                previous = results['previous']
                change_pct = results.get('change_pct', 0)
                
                if metric == 'sales':
                    summary = f"{product} MoM Sales:\nCurrent ({current['year']}-{current['month']:02d}): ${current['value']/1e6:.1f}M\nPrevious ({previous['year']}-{previous['month']:02d}): ${previous['value']/1e6:.1f}M\nChange: {change_pct:+.1f}%"
                elif metric == 'doses':
                    summary = f"{product} MoM Doses:\nCurrent ({current['year']}-{current['month']:02d}): {int(current['value']):,} doses\nPrevious ({previous['year']}-{previous['month']:02d}): {int(previous['value']):,} doses\nChange: {change_pct:+.1f}%"
                elif metric == 'market_share':
                    summary = f"{product} MoM Market Share:\nCurrent ({current['year']}-{current['month']:02d}): {current['value']:.1f}%\nPrevious ({previous['year']}-{previous['month']:02d}): {previous['value']:.1f}%\nChange: {change_pct:+.1f} percentage points"
                
                return {
                    "success": True,
                    "data": results,
                    "summary": summary
                }
            else:
                return {"success": False, "error": "No data found"}
        
        elif tool_name == "query_all_competitors":
            year = tool_input.get('year')
            month = tool_input.get('month')
            
            results = query_all_competitors(year, month)
            
            if results:
                summary_lines = []
                period = f"{year}-{month:02d}" if month else f"{year} average"
                summary_lines.append(f"Market Share Ranking ({period}):")
                
                for i, brand in enumerate(results[:10], 1):  # Top 10
                    novartis_flag = "✓" if brand['is_novartis'] else ""
                    summary_lines.append(f"{i}. {brand['brand']}: {brand['trx_share']:.1f}% TRX share {novartis_flag}")
                
                return {
                    "success": True,
                    "data": results,
                    "summary": "\n".join(summary_lines)
                }
            else:
                return {"success": False, "error": "No data found"}
        
        else:
            return {"success": False, "error": f"Unknown tool: {tool_name}"}
    
    except Exception as e:
        return {"success": False, "error": str(e)}

def handle_question_with_agent(question, image_base64=None, conversation_history=None, slide_number=None, use_preprocessed=False):
    """
    Handle question using agent-based approach with function calling
    
    Args:
        question: User's question
        image_base64: Base64 encoded slide image (optional if using preprocessed)
        conversation_history: Previous messages for context
        slide_number: Current slide number
        use_preprocessed: Whether to use preprocessed slide data
    
    Returns:
        tuple: (answer, chart_data, audio_summary)
    """
    print(f"\n{'='*80}")
    print(f"🤖 AGENT-BASED HANDLER")
    print(f"{'='*80}")
    print(f"Question: {question}")
    print(f"Slide: {slide_number}")
    print(f"Use preprocessed: {use_preprocessed}")
    
    # Smart question routing - detect if slide context is needed
    q_lower = question.lower()
    
    # Slide-focused questions (need slide context)
    slide_keywords = ['slide', 'this', 'here', 'see', 'page', 'summarize', 'summary', 
                      'about', 'explain', 'what does', 'tell me about this']
    is_slide_question = any(keyword in q_lower for keyword in slide_keywords) and len(question.split()) < 15
    
    # Data-focused questions (need database, not slide)
    data_keywords = ['sales', 'revenue', 'market share', 'doses', 'prescriptions', 
                     'trend', 'projection', 'forecast', 'compare', 'growth', 'rate', 
                     'total', 'portfolio', 'budget', 'actual', 'variance', 'performance',
                     'pluvicto', 'lutathera', 'xofigo', 'novacure', 'trx', 'nbrx',
                     'shipped', 'injected', 'year', 'month', 'quarter', 'ytd']
    is_data_question = any(keyword in q_lower for keyword in data_keywords)
    
    # Skip slide context if clearly a data question (not about the slide itself)
    skip_slide_context = is_data_question and not is_slide_question
    
    if skip_slide_context:
        print(f"🎯 Data-focused question detected - skipping slide context for speed")
    
    # Build conversation messages
    messages = []
    
    # Add conversation history if provided
    if conversation_history:
        for msg in conversation_history[-4:]:  # Last 4 messages for context
            messages.append({
                "role": msg['role'],
                "content": msg['content']
            })
    
    # Build current message content
    current_content = []
    
    # OPTIMIZATION: Use preprocessed data instead of image when available
    # This is 3-5x faster and more accurate
    # BUT skip entirely if this is a pure data question
    preprocessed_available = False
    
    if use_preprocessed and slide_number and not skip_slide_context:
        try:
            from backend_api.app import get_slide_context
            slide_context = get_slide_context(slide_number)
        except ImportError:
            print("⚠️ Could not import get_slide_context from app")
            slide_context = None
        
        if slide_context:
            preprocessed_available = True
            context_text = f"\n\n**Slide {slide_number} Content (Pre-analyzed):**\n\n"
            context_text += f"**Title:** {slide_context.get('title', 'N/A')}\n\n"
            context_text += f"**Summary:** {slide_context.get('summary', 'N/A')}\n\n"
            
            if slide_context.get('key_numbers'):
                context_text += f"**Key Metrics:**\n"
                for num in slide_context['key_numbers']:
                    context_text += f"  • {num.get('label')}: {num.get('value')} {num.get('unit', '')}\n"
                context_text += "\n"
            
            if slide_context.get('main_topics'):
                context_text += f"**Topics:** {', '.join(slide_context['main_topics'])}\n\n"
            
            if slide_context.get('time_period'):
                context_text += f"**Time Period:** {slide_context['time_period']}\n\n"
            
            if slide_context.get('charts'):
                context_text += f"**Charts on Slide:**\n"
                for chart in slide_context['charts']:
                    context_text += f"  • {chart.get('title', 'Untitled')}: {chart.get('description', 'No description')}\n"
                context_text += "\n"
            
            context_text += "**IMPORTANT:** Use the exact numbers from the preprocessed data above. Do NOT make up numbers or percentages that aren't shown. If you need additional data, use the DynamoDB query tools.\n"
            
            current_content.append({
                "type": "text",
                "text": context_text
            })
            
            print(f"✓ Using preprocessed context for slide {slide_number} (FAST MODE)")
    
    # Only add image if preprocessed data is NOT available AND we need slide context
    # This prevents redundant image analysis and speeds up responses
    if not preprocessed_available and image_base64 and not skip_slide_context:
        current_content.append({
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": "image/png",
                "data": image_base64
            }
        })
        print(f"⚠️ No preprocessed data - using image analysis (SLOW MODE)")
    
    # Add the question
    current_content.append({
        "type": "text",
        "text": question
    })
    
    messages.append({
        "role": "user",
        "content": current_content
    })
    
    # Call Claude with function calling
    print("🤖 Calling Claude Sonnet with tools...")
    
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 4096,
        "temperature": 0.7,
        "system": SYSTEM_PROMPT,
        "messages": messages,
        "tools": NOVARTIS_TOOLS
    }
    
    response = bedrock_runtime.invoke_model(
        modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
        body=json.dumps(request_body)
    )
    
    response_body = json.loads(response['body'].read())
    
    # Handle tool use
    tool_results = []
    chart_data = None
    stop_reason = response_body.get('stop_reason')
    
    if stop_reason == 'tool_use':
        print("🔧 Claude requested tool use")
        
        for content_block in response_body['content']:
            if content_block.get('type') == 'tool_use':
                tool_name = content_block['name']
                tool_input = content_block['input']
                tool_id = content_block['id']
                
                print(f"   Tool: {tool_name}")
                print(f"   Input: {json.dumps(tool_input, indent=2)}")
                
                # Execute tool
                tool_result = execute_tool(tool_name, tool_input)
                
                print(f"   Result: {tool_result.get('summary', 'No summary')}")
                
                # Generate chart data from first successful tool call
                # Only generate if we don't have a chart yet AND the question seems chart-appropriate
                if not chart_data and tool_result.get('success'):
                    # Check if question asks for visualization
                    question_lower = question.lower()
                    
                    # Strong chart indicators
                    wants_chart = any(word in question_lower for word in [
                        'show me', 'display', 'chart', 'graph', 'plot', 'visualize'
                    ])
                    
                    # Comparison/analysis questions - usually don't need charts
                    is_comparison = any(word in question_lower for word in [
                        'compare', 'compared', 'vs', 'versus', 'highest', 'lowest', 
                        'best', 'worst', 'top', 'bottom', 'which', 'what are', 
                        'identify', 'find', 'how does', 'look like'
                    ])
                    
                    # Questions about trends/forecasts are usually analytical, not visual
                    is_analytical = any(phrase in question_lower for phrase in [
                        'compared to', 'look like', 'how does', 'trend of'
                    ])
                    
                    # Only generate chart if:
                    # 1. Explicitly requested with "show me", "display", etc.
                    # 2. Simple single-product query without comparison words
                    should_generate = wants_chart and not (is_comparison or is_analytical)
                    
                    if should_generate:
                        chart_data = generate_chart_data(tool_name, tool_input, tool_result)
                        if chart_data:
                            print(f"   📊 Generated {chart_data['type']} chart: {chart_data['title']}")
                    else:
                        if is_comparison or is_analytical:
                            print(f"   ⏭️ Skipping chart - question is analytical/comparison")
                
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": json.dumps(tool_result)
                })
        
        # Send tool results back to Claude
        messages.append({
            "role": "assistant",
            "content": response_body['content']
        })
        
        messages.append({
            "role": "user",
            "content": tool_results
        })
        
        # Get final response
        print("🤖 Getting final response with tool results...")
        
        request_body['messages'] = messages
        
        response = bedrock_runtime.invoke_model(
            modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
            body=json.dumps(request_body)
        )
        
        response_body = json.loads(response['body'].read())
    
    # Extract answer
    answer = ""
    for content_block in response_body['content']:
        if content_block.get('type') == 'text':
            answer += content_block['text']
    
    print(f"✅ Generated answer ({len(answer)} chars)")
    
    # Handle empty response
    if not answer or len(answer) == 0:
        print("⚠️ Empty answer received from Claude, using fallback")
        answer = "I analyzed your question but encountered an issue generating the response. The data shows the portfolio is performing very close to budget targets. Please try rephrasing your question or ask about specific products."
    
    # Generate audio summary - ask Claude to create a concise spoken summary
    print("🎙️ Generating audio-friendly summary...")
    audio_summary_prompt = f"""Based on this analysis, create a brief executive summary suitable for text-to-speech audio. 

Requirements:
- Start with the KEY insight or answer (2-3 sentences)
- ALWAYS end with a follow-up suggestion or question the user might ask next
- NO tables, charts, or formatting
- NO markdown or special characters
- Conversational tone suitable for listening
- Maximum 60 words total

Analysis:
{answer[:1500]}

Audio Summary (include follow-up suggestion at the end):"""
    
    try:
        audio_request = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 250,
            "temperature": 0.5,
            "messages": [{
                "role": "user",
                "content": audio_summary_prompt
            }]
        }
        
        audio_response = bedrock_runtime.invoke_model(
            modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
            body=json.dumps(audio_request)
        )
        
        audio_response_body = json.loads(audio_response['body'].read())
        audio_summary = ""
        for content_block in audio_response_body['content']:
            if content_block.get('type') == 'text':
                audio_summary += content_block['text']
        
        # Clean up any remaining markdown or special chars
        audio_summary = audio_summary.replace('**', '').replace('*', '').replace('#', '').strip()
        print(f"✅ Audio summary generated ({len(audio_summary)} chars)")
        
    except Exception as e:
        print(f"⚠️ Audio summary generation failed: {e}")
        # Fallback to simple truncation
        sentences = answer.split('.')
        audio_summary = '. '.join(sentences[:2]) + '.'
    
    # chart_data was set during tool execution (if any tools were called)
    if chart_data:
        print(f"📊 Returning chart: {chart_data.get('type')} - {chart_data.get('title')}")
    
    return answer, chart_data, audio_summary

# Test function
if __name__ == '__main__':
    print("Testing Novartis Agent Handler")
    print("="*80)
    
    # Test question
    question = "What were Pluvicto sales in 2025?"
    
    answer, chart, audio = handle_question_with_agent(question, use_preprocessed=False)
    
    print("\nAnswer:")
    print(answer)
    
    print("\n" + "="*80)
    print("✅ Test complete")
