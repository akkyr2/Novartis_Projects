"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
Session middleware for enforcing session requirements on API endpoints.

This module provides decorators and utilities for validating session IDs
and attaching session data to Flask request contexts.
"""

import re
import logging
from functools import wraps
from typing import Optional
from flask import request, jsonify

from session_manager import SessionManager

logger = logging.getLogger(__name__)

# Initialize global session manager
session_manager = SessionManager(session_timeout_hours=24)


def extract_session_id() -> Optional[str]:
    """Extract session ID from request headers.
    
    Returns:
        Session ID from X-Session-ID header, or None if not present
    """
    return request.headers.get('X-Session-ID')


def validate_session_id(session_id: str) -> bool:
    """Validate session ID format (must be a valid UUID).
    
    Args:
        session_id: The session ID to validate
        
    Returns:
        True if session ID is a valid UUID, False otherwise
    """
    uuid_pattern = re.compile(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
        re.IGNORECASE
    )
    return bool(uuid_pattern.match(session_id))


def require_session_id(f):
    """Decorator to enforce session ID requirement on endpoints.
    
    This decorator:
    1. Extracts session ID from X-Session-ID header
    2. Validates session ID presence and format
    3. Gets or creates the session
    4. Attaches session data to request.session_data
    5. Returns appropriate error responses for invalid requests
    
    Usage:
        @app.route('/api/endpoint')
        @require_session_id
        def my_endpoint():
            session_data = request.session_data
            # ... use session data
    
    Args:
        f: The Flask route function to decorate
        
    Returns:
        Decorated function that enforces session requirements
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        session_id = extract_session_id()
        
        # Validate session ID presence
        if not session_id:
            logger.warning(f"Request to {request.path} missing session ID")
            return jsonify({
                'error': 'Session ID required',
                'message': 'All requests must include X-Session-ID header'
            }), 400
        
        # Validate session ID format
        if not validate_session_id(session_id):
            logger.warning(f"Invalid session ID format: {session_id}")
            return jsonify({
                'error': 'Invalid session ID format',
                'message': 'Session ID must be a valid UUID'
            }), 400
        
        # Get or create session
        session_data = session_manager.get_session(session_id)
        if not session_data:
            # Auto-create session if it doesn't exist
            session_data = session_manager.create_session(session_id)
            logger.info(f"Auto-created session for request: {session_id}")
        
        # Attach session data to request context
        request.session_data = session_data
        
        return f(*args, **kwargs)
    
    return decorated_function
