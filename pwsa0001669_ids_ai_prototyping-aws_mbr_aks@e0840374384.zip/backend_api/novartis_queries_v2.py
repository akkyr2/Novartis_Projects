#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Novartis DynamoDB Query Functions - V2 (Table-Aligned)

Properly aligned with SME guidance:
- One function per table
- Let DynamoDB do the filtering
- No Python aggregation
- Use relative indexes for time filtering
"""

import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
import json
import os

# AWS Configuration - use shared utility for consistent credential handling
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'utils', 'aws'))
from aws_utils import get_aws_resource

dynamodb = get_aws_resource('dynamodb')

# Table references
sales_table = dynamodb.Table('Novartis_Sales_Finance')
market_table = dynamodb.Table('Novartis_Market_Share')
doses_table = dynamodb.Table('Novartis_Doses')

def decimal_to_float(obj):
    """Convert Decimal to float for JSON serialization"""
    if isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_float(i) for i in obj]
    return obj

def query_sales_finance_table(filters=None):
    """
    Query SALES_FINANCE_BPC_corrected table
    
    This is the ONLY function needed for ALL sales questions:
    - Revenue, net sales, gross sales, revenue deductions
    - YTD, quarterly, monthly, YoY, MoM
    - Actual vs Budget vs OC
    - Single product or all products
    
    Args:
        filters: dict with optional filters:
            - products: list of product names (default: all)
            - forecast_types: list of forecast types (default: ['Actual'])
            - year: specific year (default: all)
            - start_date: start date (YYYY-MM-DD)
            - end_date: end date (YYYY-MM-DD)
            - year_rel_index: relative year (1000=current, 999=last year)
            - month_rel_index: relative month
            - cycle_rel_index: relative quarter
    
    Returns:
        list: All matching records with ALL columns
    """
    try:
        filters = filters or {}
        
        # Scan the table (in production, use GSI for better performance)
        response = sales_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'products' in filters:
            items = [i for i in items if i.get('brand') in filters['products']]
        
        if 'forecast_types' in filters:
            items = [i for i in items if i.get('forecast_type') in filters['forecast_types']]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying sales table: {e}")
        return []

def query_doses_table(filters=None):
    """
    Query FCT_DOSES_PLU_corrected table
    
    This is the ONLY function needed for ALL national-level dose questions:
    - TRX_shipped, TRX_injected, NBRX
    - Actual vs Budget vs OC
    - YTD, quarterly, monthly, YoY, MoM
    - Single product or all products
    
    Args:
        filters: dict with optional filters:
            - products: list of product names
            - metrics: list of metric types (TRX_shipped, TRX_injected, NBRX)
            - forecast_types: list of forecast types
            - year: specific year
            - start_date, end_date: date range
            - year_rel_index, month_rel_index, quarter_rel_index: relative time
    
    Returns:
        list: All matching records with ALL columns
    """
    try:
        filters = filters or {}
        
        # Scan the table
        response = doses_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'products' in filters:
            items = [i for i in items if i.get('brand') in filters['products']]
        
        if 'metrics' in filters:
            items = [i for i in items if i.get('metric') in filters['metrics']]
        
        if 'forecast_types' in filters:
            items = [i for i in items if i.get('forecast_type') in filters['forecast_types']]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'quarter_rel_index' in filters:
            items = [i for i in items if i.get('quarter_rel_index') == filters['quarter_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying doses table: {e}")
        return []

def query_market_share_table(filters=None):
    """
    Query FCT_MARKET_PLU_corrected table
    
    This is the ONLY function needed for ALL market share and competitor questions:
    - Market share trends
    - Competitor analysis
    - TRX and NBRX volumes and shares
    - All brands including competitors
    
    Args:
        filters: dict with optional filters:
            - brands: list of brand names (includes competitors)
            - year: specific year
            - start_date, end_date: date range
            - year_rel_index, month_rel_index, cycle_rel_index: relative time
    
    Returns:
        list: All matching records with ALL columns
    """
    try:
        filters = filters or {}
        
        # Scan the table
        response = market_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'brands' in filters:
            items = [i for i in items if i.get('brand') in filters['brands']]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying market share table: {e}")
        return []

# Test function
if __name__ == '__main__':
    print("Testing Table-Aligned Query Functions")
    print("="*80)
    
    # Test 1: Get all Pluvicto sales for 2025
    print("\n1. Pluvicto Sales 2025 (Actual):")
    sales = query_sales_finance_table({
        'products': ['Pluvicto'],
        'year': 2025,
        'forecast_types': ['Actual']
    })
    print(f"   Found {len(sales)} records")
    if sales:
        total = sum(s.get('net_sales', 0) for s in sales)
        print(f"   Total: ${total/1e6:.1f}M")
    
    # Test 2: Get Q1 2025 doses for all products
    print("\n2. Q1 2025 Doses (All Products):")
    doses = query_doses_table({
        'year': 2025,
        'quarter_rel_index': 1000,  # Current quarter
        'metrics': ['TRX_shipped'],
        'forecast_types': ['Actual']
    })
    print(f"   Found {len(doses)} records")
    
    # Test 3: Get market share for all brands
    print("\n3. Market Share All Brands 2025:")
    market = query_market_share_table({
        'year': 2025
    })
    print(f"   Found {len(market)} records")
    
    print("\n" + "="*80)
    print("✅ Tests complete")
