#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Configuration module for MBR Dashboard Backend API

Handles environment-specific configuration for both local development and AWS deployment.
"""

import os
import re
from typing import Optional, Dict, Any
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

class BasePathConfig:
    """Centralized base path configuration manager."""
    
    def __init__(self, base_path: Optional[str] = None):
        """Initialize base path configuration.
        
        Args:
            base_path: Optional base path override. If None, reads from environment.
        """
        self._base_path = self._resolve_base_path(base_path)
        self._validate_base_path()
    
    def _resolve_base_path(self, override: Optional[str] = None) -> str:
        """Resolve base path from various sources with priority order."""
        if override is not None:
            return override
        
        # Priority order: BASE_PATH -> empty string (frontend uses package.json homepage)
        base_path = (
            os.getenv('BASE_PATH') or 
            ''
        )
        
        # Normalize base path format
        if base_path:
            # Ensure starts with / but doesn't end with /
            base_path = base_path.strip()
            if not base_path.startswith('/'):
                base_path = f'/{base_path}'
            if base_path.endswith('/') and len(base_path) > 1:
                base_path = base_path.rstrip('/')
        
        return base_path
    
    def _validate_base_path(self) -> None:
        """Validate base path format and raise helpful errors."""
        if not self._base_path:
            return  # Empty base path is valid (root deployment)
        
        # Check format: must start with /, no trailing /, alphanumeric + hyphens/underscores
        if not re.match(r'^/[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_-]+)*$', self._base_path):
            raise ValueError(
                f"Invalid base path format: '{self._base_path}'. "
                f"Base path must start with '/', contain only alphanumeric characters, "
                f"hyphens, and underscores, and not end with '/'. "
                f"Examples: '/mbr', '/dashboard', '/novartis-analytics'"
            )
    
    @property
    def base_path(self) -> str:
        """Get the configured base path."""
        return self._base_path
    
    @property
    def api_prefix(self) -> str:
        """Get the API prefix with base path."""
        return f"{self._base_path}/api" if self._base_path else "/api"
    
    @property
    def static_prefix(self) -> str:
        """Get the static assets prefix with base path."""
        return f"{self._base_path}/static" if self._base_path else "/static"
    
    def create_url(self, path: str) -> str:
        """Create a URL with proper base path prefix.
        
        Args:
            path: The path to append to base path (with or without leading slash)
            
        Returns:
            Complete URL with base path prefix
        """
        # Normalize path
        clean_path = path.strip()
        if not clean_path.startswith('/'):
            clean_path = f'/{clean_path}'
        
        if self._base_path:
            return f"{self._base_path}{clean_path}"
        return clean_path
    
    def is_api_path(self, path: str) -> bool:
        """Check if a path is an API endpoint."""
        return path.startswith(self.api_prefix)
    
    def is_static_path(self, path: str) -> bool:
        """Check if a path is a static asset."""
        return path.startswith(self.static_prefix)


class Config:
    """Configuration class that adapts to different environments."""
    
    def __init__(self):
        self.environment = os.getenv('ENVIRONMENT', 'local')
        self.debug = os.getenv('DEBUG', 'false').lower() == 'true'
        
        # Base Path Configuration
        self.base_path_config = BasePathConfig()
        
        # AWS Configuration
        self.aws_profile = os.getenv('AWS_PROFILE', 'default')
        self.aws_region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')
        
        # Application Configuration
        self.port = int(os.getenv('PORT', 5000))
        self.host = os.getenv('HOST', '0.0.0.0')
        self.secret_key = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
        
        # CORS Configuration
        self.cors_origins = self._parse_cors_origins()
        
        # AWS Service Configuration
        self.bedrock_endpoint = os.getenv('BEDROCK_ENDPOINT')
        self.bedrock_model_id = os.getenv('BEDROCK_MODEL_ID', 'anthropic.claude-sonnet-4-20250514-v1:0')
        
        self.dynamodb_endpoint = os.getenv('DYNAMODB_ENDPOINT')
        # Novartis MBR tables (used for reference - actual queries use specific table names)
        self.dynamodb_tables = {
            'sales_finance': 'Novartis_Sales_Finance',
            'market_share': 'Novartis_Market_Share',
            'doses': 'Novartis_Doses',
            'calls': 'Novartis_Calls',
            'rome': 'Novartis_Rome'
        }
        
        self.polly_endpoint = os.getenv('POLLY_ENDPOINT')
        self.polly_voice_id = os.getenv('POLLY_VOICE_ID', 'Joanna')
        
        # Feature Flags
        self.enable_voice_controls = os.getenv('ENABLE_VOICE_CONTROLS', 'true').lower() == 'true'
        self.enable_audio_playback = os.getenv('ENABLE_AUDIO_PLAYBACK', 'true').lower() == 'true'
        self.enable_chart_generation = os.getenv('ENABLE_CHART_GENERATION', 'true').lower() == 'true'
        self.enable_preprocessing = os.getenv('ENABLE_PREPROCESSING', 'true').lower() == 'true'
        
        # Performance Configuration
        self.request_timeout = int(os.getenv('REQUEST_TIMEOUT', 30))
        self.max_upload_size = int(os.getenv('MAX_UPLOAD_SIZE', 50)) * 1024 * 1024  # Convert MB to bytes
        self.cache_ttl = int(os.getenv('CACHE_TTL', 3600))
        
        # Logging Configuration
        self.log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
        self.log_format = os.getenv('LOG_FORMAT', 'simple')
        
        # Development Configuration
        self.hot_reload = os.getenv('HOT_RELOAD', 'true').lower() == 'true'
        self.enable_docs = os.getenv('ENABLE_DOCS', 'true').lower() == 'true'
        self.mock_aws_services = os.getenv('MOCK_AWS_SERVICES', 'false').lower() == 'true'
        
    def _parse_cors_origins(self) -> list:
        """Parse CORS origins from environment variable."""
        cors_origins = os.getenv('CORS_ORIGINS', 'http://localhost:3000,http://127.0.0.1:3000')
        if cors_origins:
            return [origin.strip() for origin in cors_origins.split(',')]
        return ['*']  # Allow all origins if not specified
    
    @property
    def is_local_development(self) -> bool:
        """Check if running in local development mode."""
        return self.environment == 'local' and self.debug
    
    @property
    def is_aws_deployment(self) -> bool:
        """Check if running in AWS deployment."""
        # Check for container environment or explicit AWS deployment
        return (
            self.environment in ['aws-deployment', 'production', 'staging'] or
            os.path.exists('/app') or  # Docker container indicator
            os.getenv('AWS_EXECUTION_ENV') is not None or  # Lambda/ECS indicator
            os.getenv('ECS_CONTAINER_METADATA_URI') is not None  # ECS indicator
        )
    
    def get_aws_config(self) -> Dict[str, Any]:
        """Get AWS configuration for boto3 clients."""
        config = {
            'region_name': self.aws_region
        }
        
        # Add custom endpoints if specified (for local testing)
        if self.bedrock_endpoint:
            config['bedrock_endpoint_url'] = self.bedrock_endpoint
        if self.dynamodb_endpoint:
            config['dynamodb_endpoint_url'] = self.dynamodb_endpoint
        if self.polly_endpoint:
            config['polly_endpoint_url'] = self.polly_endpoint
            
        return config
    
    def get_flask_config(self) -> Dict[str, Any]:
        """Get Flask application configuration."""
        return {
            'DEBUG': self.debug,
            'SECRET_KEY': self.secret_key,
            'MAX_CONTENT_LENGTH': self.max_upload_size,
            'JSON_SORT_KEYS': False,
            'JSONIFY_PRETTYPRINT_REGULAR': self.debug
        }
    
    def print_config_summary(self):
        """Print configuration summary for debugging."""
        print(f"🔧 Configuration Summary:")
        print(f"  Environment: {self.environment}")
        print(f"  Debug Mode: {self.debug}")
        print(f"  Base Path: {self.base_path_config.base_path or '(root)'}")
        print(f"  API Prefix: {self.base_path_config.api_prefix}")
        print(f"  Static Prefix: {self.base_path_config.static_prefix}")
        print(f"  AWS Profile: {self.aws_profile}")
        print(f"  AWS Region: {self.aws_region}")
        print(f"  Port: {self.port}")
        print(f"  Host: {self.host}")
        print(f"  CORS Origins: {self.cors_origins}")
        print(f"  Bedrock Model: {self.bedrock_model_id}")
        print(f"  DynamoDB Tables: {', '.join(self.dynamodb_tables.values())}")
        print(f"  Polly Voice: {self.polly_voice_id}")
        
        if self.bedrock_endpoint or self.dynamodb_endpoint or self.polly_endpoint:
            print(f"  Custom Endpoints:")
            if self.bedrock_endpoint:
                print(f"    Bedrock: {self.bedrock_endpoint}")
            if self.dynamodb_endpoint:
                print(f"    DynamoDB: {self.dynamodb_endpoint}")
            if self.polly_endpoint:
                print(f"    Polly: {self.polly_endpoint}")

# Global configuration instance
config = Config()

# Convenience functions for backward compatibility
def get_aws_region() -> str:
    """Get AWS region."""
    return config.aws_region

def get_aws_profile() -> str:
    """Get AWS profile."""
    return config.aws_profile

def is_debug_mode() -> bool:
    """Check if debug mode is enabled."""
    return config.debug

def get_bedrock_model_id() -> str:
    """Get Bedrock model ID."""
    return config.bedrock_model_id

def get_dynamodb_tables() -> dict:
    """Get DynamoDB table names."""
    return config.dynamodb_tables

def get_polly_voice_id() -> str:
    """Get Polly voice ID."""
    return config.polly_voice_id