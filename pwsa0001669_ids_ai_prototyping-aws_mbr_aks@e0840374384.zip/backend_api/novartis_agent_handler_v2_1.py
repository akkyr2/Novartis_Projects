#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Novartis Agent Handler - V2 (Table-Aligned)

Properly aligned with SME TABLE_ROUTING_GUIDE:
- 3 tools (one per main table)
- Claude does the analysis/aggregation
- DynamoDB does the filtering
- Much faster and simpler
"""

import json
import boto3
from botocore.config import Config

from novartis_queries_v2_1 import (
    query_sales_finance_table,
    query_doses_table,
    query_market_share_table,
    query_calls_table,
    query_rome_table
)

# AWS clients
boto_config = Config(
    retries={'max_attempts': 3, 'mode': 'adaptive'},
    max_pool_connections=10
)

# Import shared Bedrock client to prevent connection leaks
from aws_clients import bedrock_runtime

# Define 3 tools - one per table (following SME guidance)
NOVARTIS_TOOLS = [
    {
        "name": "query_sales_finance_table",
        "description": """Query SALES_FINANCE_BPC_corrected table for ALL sales/revenue questions.
        
USE THIS FOR:
- Revenue, net sales, gross sales, revenue deductions
- YTD, quarterly, monthly performance
- Actual vs Budget vs OC comparisons
- Year-over-year, month-over-month analysis
- Single product or portfolio-wide

IMPORTANT: For comparisons, use ONE call with broad date range (e.g., start_date="2024-01-01", end_date="2025-03-31" for Q1 2024 vs Q1 2025)

RETURNS: All matching records with columns: brand, forecast_type, date, year, month, net_sales, gross_sales, revenue_deductions, year_rel_index, month_rel_index, cycle_rel_index

YOU analyze and aggregate the data - don't ask for pre-aggregated results.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "products": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"]},
                    "description": "Product names to filter (omit for all products)"
                },
                "forecast_types": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Actual", "Budget", "OC"]},
                    "description": "Forecast types (default: ['Actual'])"
                },
                "year": {
                    "type": "integer",
                    "description": "Specific year (2020-2028)"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    },
    {
        "name": "query_doses_table",
        "description": """Query FCT_DOSES_PLU_corrected table for ALL national-level dose questions.

USE THIS FOR:
- Shipped doses, injected doses, new patient (NBRX) metrics
- YTD, quarterly, monthly dose performance
- Actual vs Budget vs OC comparisons
- Year-over-year, month-over-month dose analysis

DEFAULT: Filter to Pluvicto UNLESS another product is explicitly mentioned.

IMPORTANT: For comparisons, use ONE call with broad date range covering all periods needed

RETURNS: All matching records with columns: brand, metric (TRX_shipped/TRX_injected/NBRX), forecast_type, date, year, month, value, year_rel_index, month_rel_index, quarter_rel_index

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "products": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"]},
                    "description": "Product names (omit for all)"
                },
                "metrics": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["TRX_shipped", "TRX_injected", "NBRX"]},
                    "description": "Dose metrics (omit for all)"
                },
                "forecast_types": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Actual", "Budget", "OC"]},
                    "description": "Forecast types (default: ['Actual'])"
                },
                "year": {
                    "type": "integer",
                    "description": "Specific year"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    },
    {
        "name": "query_market_share_table",
        "description": """Query FCT_MARKET_PLU_corrected table for ALL market share and competitor questions.

USE THIS FOR:
- Market share analysis (TRX_SHARE_R3M, NBRX_SHARE_R3M)
- Competitor analysis and rankings
- Market volumes (TRX_R3M, NBRX_R3M)
- All brands including competitors

DEFAULT: Filter to Pluvicto UNLESS competitors or other products are explicitly mentioned.

IMPORTANT: For comparisons, use ONE call with broad date range covering all periods needed

RETURNS: All matching records with columns: brand, date, year, month, TRX_R3M, TRX_SHARE_R3M, NBRX_R3M, NBRX_SHARE_R3M, year_rel_index, month_rel_index, cycle_rel_index

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "brands": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Brand names including competitors (omit for all brands)"
                },
                "year": {
                    "type": "integer",
                    "description": "Specific year"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    },
    {
        "name": "query_calls_table",
        "description": """Query FCT_CALLS table for ALL field activity and sales rep performance questions.

USE THIS FOR:
- Field activity analysis
- Sales rep performance tracking
- HCP reach and engagement metrics
- Call frequency and attainment analysis
- Team performance by geography (Nation and Region levels only)
- Demand generation insights

AVAILABLE GEOGRAPHY: Nation, Region (Northeast, Southeast, Midwest, West)
NOTE: Territory-level data not yet available

RETURNS: All matching records with columns: product, dim_geo_level, dim_geo_name, dim_time_period, dim_metric_type, CPD, cpd_goal, cpd_attainment, target_hcp_reach, total_target, percent_reached, call_frequency_actual, call_frequency_attainment, actual_calls, planned_calls, cycle_rel_index, call_date, year_quarter

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "products": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"]},
                    "description": "Product names (omit for all)"
                },
                "geo_level": {
                    "type": "string",
                    "enum": ["Nation", "Region"],
                    "description": "Geographic level"
                },
                "geo_name": {
                    "type": "string",
                    "description": "Specific geography name"
                },
                "metric_type": {
                    "type": "string",
                    "enum": ["hcp_reach", "cpd", "call_frequency_attainment", "total_calls"],
                    "description": "Metric type to filter"
                },
                "year_quarter": {
                    "type": "string",
                    "description": "Specific quarter (e.g., '2024-Q1')"
                },
                "cycle_rel_index": {
                    "type": "integer",
                    "description": "Relative cycle (1000=current, 999=last quarter)"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    },
    {
        "name": "query_rome_table",
        "description": """Query FCT_ROME_PLU table for ALL site-level activity and patient demand questions.

USE THIS FOR:
- Site activity analysis (active vs dormant sites)
- Patient-level demand tracking
- Geography-level demand (territory, area, region)
- Injection patterns and dose sequences
- NBRx tracking (new patient starts)
- Ordering behavior over time
- Customer-level analysis

DEFAULT: Filter to Pluvicto UNLESS another product is explicitly mentioned.

DO NOT USE FOR:
- Market share or competitor analysis (use query_market_share_table)

RETURNS: All matching records with columns: PRODUCT, DIM_Brand, dim_date, dim_customer_name, site_id, dim_site_type, dim_terr_name, dim_area_name, dim_region_name, dim_tier, active_dormant_flag, sales_order_number, patient_reference_number, dose_number, is_patients_first_dose, dim_order_status, dim_order_type, month_rel_index, year_rel_index, cycle_rel_index, year_quarter

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "products": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"]},
                    "description": "Product names (omit for all)"
                },
                "territories": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Territory names"
                },
                "regions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Region names"
                },
                "site_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Site IDs"
                },
                "active_dormant": {
                    "type": "string",
                    "enum": ["Active", "Dormant"],
                    "description": "Site activity status"
                },
                "order_status": {
                    "type": "string",
                    "description": "Order status filter"
                },
                "is_first_dose": {
                    "type": "boolean",
                    "description": "Filter for first dose orders"
                },
                "year_quarter": {
                    "type": "string",
                    "description": "Specific quarter (e.g., '2024-Q1')"
                },
                "cycle_rel_index": {
                    "type": "integer",
                    "description": "Relative cycle (1000=current, 999=last quarter)"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    }
]

SYSTEM_PROMPT = """You are an AI assistant for Novartis RLT Portfolio Monthly Business Review (MBR).

**CRITICAL - Data Architecture (from SME TABLE_ROUTING_GUIDE):**

You have access to 5 tables via 5 tools:
1. **SALES_FINANCE_BPC_corrected** → query_sales_finance_table
   - USE FOR: Revenue, sales, gross sales, revenue deductions
   - Products: Novartis portfolio only (Pluvicto, Lutathera, Xofigo, Novacure)
   
2. **FCT_DOSES_PLU_corrected** → query_doses_table
   - USE FOR: National-level doses (TRX_shipped, TRX_injected, NBRX)
   - Products: Novartis portfolio only
   
3. **FCT_MARKET_PLU_corrected** → query_market_share_table
   - USE FOR: Market share, competitors, market volumes
   - Brands: ALL including competitors

4. **FCT_CALLS** → query_calls_table
   - USE FOR: Field activity, sales rep performance, HCP reach, call frequency
   - Products: All Novartis promoted products
   - Geography: Nation and Region only (Territory not yet available)

5. **FCT_ROME_PLU** → query_rome_table
   - USE FOR: Site activity, patient demand, territory performance, injection patterns
   - Products: Novartis portfolio only
   - Geography: Territory, Area, Region, Site level
   - DO NOT use for market share or competitors

**TABLE ROUTING RULES (from SME):**
- Market share or competitors? → query_market_share_table (ALWAYS)
- Revenue or sales? → query_sales_finance_table
- Doses or prescriptions (national)? → query_doses_table
- Medical rep calls or HCP reach? → query_calls_table (ALWAYS)
- Sites, territories, or patient-level? → query_rome_table (ALWAYS)

**ONE QUESTION = ONE TABLE = ONE TOOL CALL**

**Your Job:**
1. Pick the correct table based on question type
2. Call the tool ONCE with appropriate filters
3. YOU do the analysis (YTD, quarterly, YoY, MoM, comparisons, trends)
4. The tool returns raw data - YOU aggregate, calculate, and analyze

**CRITICAL - Slide-Only Questions:**
- If question is ONLY about the slide content (summarize slide, what's on slide, describe slide, visual layout), DO NOT use tools
- Use the preprocessed slide context provided in the message, which includes:
  * Title and summary
  * Visual elements (count and description of each chart/figure)
  * Key metrics shown on the slide
- Answer directly from the slide information without querying DynamoDB
- Examples: "summarize the slide", "what's on this slide", "describe the current slide", "how many charts are there", "what figures do you see"
- For visual questions (how many charts, what type of charts), reference the "Visual Elements" section in the slide context

**CRITICAL - Comparison Queries:**
- For comparisons (Q1 2024 vs Q1 2025, YoY, etc.), use ONE tool call with broad date range
- Example: "Compare Q1 2024 to Q1 2025" → Use start_date="2024-01-01", end_date="2025-03-31"
- Example: "YoY comparison for 2024" → Use start_date="2023-01-01", end_date="2024-12-31"
- DO NOT make multiple tool calls for the same table - get all data at once and analyze

**CRITICAL - Default Product Rules:**
- **Market, ROME, Doses questions:** Default to Pluvicto UNLESS another product is explicitly mentioned
- **Sales, Calls questions:** May show all 4 products + portfolio total
- **Pluvicto is the flagship product** (largest by far) - when in doubt, assume Pluvicto
- Examples:
  - "What are the doses?" → Filter to Pluvicto only
  - "Show me site activity" → Filter to Pluvicto only
  - "What's the market share?" → Filter to Pluvicto only
  - "Compare all products" → Show all 4 products
  - "What are Lutathera doses?" → Filter to Lutathera only

**Product Name Fuzzy Matching:**
- "play victor", "plu victo" → Pluvicto
- "luther", "luta thera" → Lutathera
- "zo figo", "ex ofigo" → Xofigo
- "nova cure" → Novacure

**Forecast Types:**
- Actual: Historical data (2020-2025)
- Budget: Original annual plan
- OC: Latest forecast (2026-2028)
- For comparisons: Request both Actual and Budget in forecast_types array

**CRITICAL - Response Length Constraints:**
- Maximum response length: 1500 characters (excluding audio summary)
- Maximum tokens: 400 tokens
- Be concise and focused - executives want quick insights, not essays
- If you exceed this limit, you will be penalized

**Response Style:**
- Professional and concise
- Focus on business impact
- Provide actionable insights
- Use markdown tables for data (NOT ASCII art)
- CRITICAL: Do NOT create ASCII/text-based pie charts, bar charts, or visualizations
- CRITICAL: Do NOT output JSON chart data structures in your response
- CRITICAL: Do NOT create chart data objects like {"type": "pie", "data": [...]}
- The frontend will generate interactive charts automatically from tool results

**Chart Requests:**
- ALWAYS honor user's explicit chart type requests (pie, bar, line)
- If user asks for a pie chart, generate it - do NOT refuse or suggest alternatives
- If user asks for a bar chart, generate it as a bar chart
- If user asks for a line chart, generate it as a line chart
- The backend will automatically generate the chart data for the frontend
- DO NOT manually create chart JSON - just provide the data table and insights

**CRITICAL - Format for "Top X" Questions:**
When asked for "top 10 accounts", "top 5 territories", etc., use this format ONLY:

1. **Summary Table**: Show the top X items with key metrics (5-7 columns max)
2. **Key Insights**: 3-5 bullet points highlighting patterns or notable findings
3. **Audio Summary**: 2-3 sentences

DO NOT provide:
- ❌ Detailed profiles for each item
- ❌ Strategic recommendations sections
- ❌ Multiple analysis sections (geographic, tier mix, etc.)
- ❌ "Next steps" or "action items" sections
- ❌ Lengthy explanations for each row

**Example Format:**
```
## Top 10 Accounts by Q1 2025 Volume

| Rank | Account | Site ID | Region | Q1 Doses |
|------|---------|---------|--------|----------|
| 1 | West Medical Center | SITE011 | West | 3 |
| 2 | Southeast Medical | SITE004 | Southeast | 3 |
...

**Key Insights:**
- Top 2 accounts tied at 3 doses each
- 100% fulfillment rate for top performers
- Zero new patient starts in Q1 (all continuation therapy)
- Geographic concentration: West and Southeast dominate
```

Target length: 500-800 characters total

**CRITICAL - General Response Format:**
For all other questions (trends, comparisons, YoY, etc.):
1. **Direct Answer**: 1-2 sentences answering the question
2. **Data Table**: If showing multiple data points (max 10 rows)
3. **Key Insights**: 2-4 bullet points
4. **Audio Summary**: 2-3 sentences

Keep total response under 1000 characters.

**CRITICAL - NEVER OUTPUT THESE:**
❌ JSON objects like {"type": "bar", "data": [...]}
❌ Chart configuration code
❌ JavaScript/Python code snippets
❌ Data structure definitions
❌ Any code blocks with chart data

The backend automatically generates charts from your tool results. You only provide:
✅ Markdown tables
✅ Text insights
✅ Bullet points

**CRITICAL - Response Format:**
You MUST end every response with an audio summary section:

---AUDIO_SUMMARY---
[2-3 sentence executive summary suitable for text-to-speech. NO markdown, tables, or special characters. End with a follow-up suggestion. Maximum 60 words.]

**Data Accuracy:**
- Only use numbers from the data returned
- Do NOT invent or estimate values
- If data is missing, say so clearly"""

def generate_chart_data(tool_name, tool_input, tool_result, question):
    """Generate chart data from tool results for frontend visualization"""
    if not tool_result.get('success') or not tool_result.get('data'):
        return None
    
    try:
        data = tool_result['data']
        question_lower = question.lower()
        
        # Detect if user wants a chart
        wants_chart = any(word in question_lower for word in ['chart', 'graph', 'plot', 'show', 'visualize', 'pie', 'bar', 'line'])
        
        if not wants_chart:
            return None
        
        if tool_name == "query_sales_finance_table":
            # Determine chart type based on question and data
            # If single month data (4 products), default to pie chart for breakdown
            is_single_month = len(data) == 4 and len(set(r.get('month') for r in data)) == 1
            
            # Explicit chart type requests take priority
            explicit_bar = 'bar chart' in question_lower or 'bar graph' in question_lower
            explicit_line = 'line chart' in question_lower or 'line graph' in question_lower
            explicit_pie = 'pie chart' in question_lower or 'pie graph' in question_lower
            
            # Use pie chart if explicitly requested OR if implicit indicators suggest it (but not if bar/line explicitly requested)
            wants_pie = explicit_pie or (not explicit_bar and not explicit_line and ('mix' in question_lower or 'distribution' in question_lower or 'breakdown' in question_lower or is_single_month))
            
            if wants_pie:
                # Detect if user wants monthly breakdown (by month) vs product breakdown
                wants_monthly = any(phrase in question_lower for phrase in ['by month', 'monthly breakdown', 'month breakdown', 'each month', 'per month'])
                
                # Pie chart for product mix, quarterly distribution, or monthly breakdown
                if 'quarter' in question_lower or 'q1' in question_lower or 'q2' in question_lower:
                    # Group by quarter
                    quarterly_data = {}
                    for record in data:
                        quarter = f"Q{((record['month'] - 1) // 3) + 1}"
                        if quarter not in quarterly_data:
                            quarterly_data[quarter] = 0
                        quarterly_data[quarter] += record.get('net_sales', 0)
                    
                    chart_data = [{'label': q, 'value': round(v / 1e6, 1)} for q, v in sorted(quarterly_data.items())]
                    products = tool_input.get('products', ['All Products'])
                    year = tool_input.get('year', 'All Years')
                    
                    return {
                        'type': 'pie',
                        'title': f"{products[0] if len(products) == 1 else 'Portfolio'} Net Sales by Quarter - {year}",
                        'data': chart_data,
                        'xKey': 'label',
                        'yKey': 'value',
                        'yLabel': 'Sales ($M)'
                    }
                elif wants_monthly:
                    # Group by month for monthly breakdown
                    month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                                 'July', 'August', 'September', 'October', 'November', 'December']
                    monthly_data = {}
                    year_val = None
                    
                    for record in data:
                        month = int(record.get('month', 0))
                        year_val = int(record.get('year', 0))
                        month_label = month_names[month] if month < len(month_names) else f"Month {month}"
                        
                        if month_label not in monthly_data:
                            monthly_data[month_label] = 0
                        monthly_data[month_label] += record.get('net_sales', 0)
                    
                    # Sort by month order
                    month_order = {month_names[i]: i for i in range(1, 13)}
                    sorted_months = sorted(monthly_data.items(), key=lambda x: month_order.get(x[0], 99))
                    chart_data = [{'label': month, 'value': round(v / 1e6, 1)} for month, v in sorted_months]
                    
                    products = tool_input.get('products', ['All Products'])
                    product_name = products[0] if len(products) == 1 else 'Portfolio'
                    
                    return {
                        'type': 'pie',
                        'title': f"{product_name} Monthly Sales Distribution - {year_val}",
                        'data': chart_data,
                        'xKey': 'label',
                        'yKey': 'value',
                        'yLabel': 'Sales ($M)',
                        'source': 'SALES_FINANCE_BPC_corrected'
                    }
                else:
                    # Group by product
                    product_data = {}
                    for record in data:
                        product = record.get('brand', 'Unknown')
                        if product not in product_data:
                            product_data[product] = 0
                        product_data[product] += record.get('net_sales', 0)
                    
                    chart_data = [{'label': p, 'value': round(v / 1e6, 1)} for p, v in product_data.items()]
                    
                    # Extract actual date from data for title
                    if data and len(data) > 0:
                        first_record = data[0]
                        year = first_record.get('year', tool_input.get('year', 'All Years'))
                        month = first_record.get('month')
                        if month:
                            month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                                         'July', 'August', 'September', 'October', 'November', 'December']
                            title_date = f"{month_names[int(month)]} {int(year)}"
                        else:
                            title_date = str(int(year))
                    else:
                        title_date = tool_input.get('year', 'All Years')
                    
                    return {
                        'type': 'pie',
                        'title': f"Product Sales Mix - {title_date}",
                        'data': chart_data,
                        'xKey': 'label',
                        'yKey': 'value',
                        'yLabel': 'Sales ($M)',
                        'source': 'SALES_FINANCE_BPC_corrected'
                    }
            else:
                # Bar or Line chart for sales trend over time OR product comparison
                chart_type = 'bar' if 'bar' in question_lower else 'line'
                
                # Detect if user wants breakdown by product vs by month
                wants_by_product = any(phrase in question_lower for phrase in ['by product', 'by brand', 'each product', 'per product', 'product breakdown'])
                
                if wants_by_product:
                    # Group by product for product comparison
                    product_data = {}
                    year_val = None
                    
                    for record in data:
                        product = record.get('brand', 'Unknown')
                        year_val = int(record.get('year', 0))
                        
                        if product not in product_data:
                            product_data[product] = 0
                        product_data[product] += record.get('net_sales', 0)
                    
                    chart_data = [{'product': p, 'sales': round(v / 1e6, 1)} for p, v in sorted(product_data.items())]
                    
                    return {
                        'type': chart_type,
                        'title': f"Product Sales Comparison - {year_val}",
                        'data': chart_data,
                        'xKey': 'product',
                        'yKey': 'sales',
                        'yLabel': 'Net Sales ($M)',
                        'source': 'SALES_FINANCE_BPC_corrected'
                    }
                else:
                    # Detect if user wants comparison (actual vs budget, etc.)
                    wants_comparison = any(phrase in question_lower for phrase in ['vs', 'versus', 'compared to', 'actual vs budget', 'budget vs actual', 'actual and budget'])
                    forecast_types = tool_input.get('forecast_types', ['Actual'])
                    has_multiple_forecast_types = len(forecast_types) > 1 or wants_comparison
                    
                    month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                                 'July', 'August', 'September', 'October', 'November', 'December']
                    
                    if has_multiple_forecast_types:
                        # Multi-series chart: keep forecast types separate
                        series_data = {}  # {forecast_type: {month: value}}
                        year_val = None
                        
                        for record in data:
                            month = int(record.get('month', 0))
                            year_val = int(record.get('year', 0))
                            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
                            forecast_type = record.get('forecast_type', 'Actual')
                            
                            if forecast_type not in series_data:
                                series_data[forecast_type] = {}
                            if month_label not in series_data[forecast_type]:
                                series_data[forecast_type][month_label] = 0
                            series_data[forecast_type][month_label] += record['net_sales']
                        
                        # Convert to multi-series format
                        month_order = {month_names[i]: i for i in range(1, 13)}
                        all_months = sorted(set(month for series in series_data.values() for month in series.keys()), 
                                          key=lambda x: month_order.get(x, 99))
                        
                        chart_data = []
                        for month in all_months:
                            data_point = {'month': month}
                            for forecast_type, monthly_values in series_data.items():
                                data_point[forecast_type.lower()] = round(monthly_values.get(month, 0) / 1e6, 1)
                            chart_data.append(data_point)
                        
                        products = tool_input.get('products', ['All Products'])
                        product_name = products[0] if len(products) == 1 else 'Portfolio'
                        
                        # Create series keys for multi-line chart
                        series_keys = [ft.lower() for ft in series_data.keys()]
                        
                        return {
                            'type': chart_type,
                            'title': f"{product_name} Sales: {' vs '.join(series_data.keys())} - {year_val}",
                            'data': chart_data,
                            'xKey': 'month',
                            'seriesKeys': series_keys,  # Multiple y-axis keys for multi-series
                            'yLabel': 'Net Sales ($M)',
                            'source': 'SALES_FINANCE_BPC_corrected'
                        }
                    else:
                        # Single series: aggregate by month
                        monthly_data = {}
                        year_val = None
                        
                        for record in data:
                            month = int(record.get('month', 0))
                            year_val = int(record.get('year', 0))
                            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
                            
                            if month_label not in monthly_data:
                                monthly_data[month_label] = 0
                            monthly_data[month_label] += record['net_sales']
                        
                        # Sort by month order
                        month_order = {month_names[i]: i for i in range(1, 13)}
                        sorted_months = sorted(monthly_data.items(), key=lambda x: month_order.get(x[0], 99))
                        chart_data = [{'month': month, 'sales': round(v / 1e6, 1)} for month, v in sorted_months]
                        
                        products = tool_input.get('products', ['All Products'])
                        product_name = products[0] if len(products) == 1 else 'Portfolio'
                        
                        return {
                            'type': chart_type,
                            'title': f"{product_name} Monthly Sales - {year_val}",
                            'data': chart_data,
                            'xKey': 'month',
                            'yKey': 'sales',
                            'yLabel': 'Net Sales ($M)',
                            'source': 'SALES_FINANCE_BPC_corrected'
                        }
        
        elif tool_name == "query_market_share_table":
            # Line chart for market share trend
            # Aggregate by month (in case multiple brands)
            monthly_data = {}
            for record in data:
                month_key = f"{int(record['year'])}-{int(record['month']):02d}"
                if month_key not in monthly_data:
                    monthly_data[month_key] = []
                monthly_data[month_key].append(float(record.get('trx_share_r3m', 0)))
            
            # Average share for each month
            chart_data = [
                {'month': month, 'share': round(sum(shares) / len(shares), 1)}
                for month, shares in sorted(monthly_data.items())
            ]
            
            brands = tool_input.get('brands', ['All Brands'])
            year = tool_input.get('year', 'All Years')
            
            return {
                'type': 'line',
                'title': f"{brands[0] if len(brands) == 1 else 'Market'} TRX Share (R3M) - {year}",
                'data': chart_data,
                'xKey': 'month',
                'yKey': 'share',
                'yLabel': 'Market Share (%)',
                'source': 'FCT_MARKET_PLU_corrected'
            }
        
        elif tool_name == "query_doses_table":
            # Bar chart for dose metrics
            # Aggregate by month (in case multiple products or metrics)
            monthly_data = {}
            for record in data:
                month_key = f"{int(record['year'])}-{int(record['month']):02d}"
                if month_key not in monthly_data:
                    monthly_data[month_key] = 0
                monthly_data[month_key] += record.get('value', 0)
            
            # Convert to chart format and sort by date
            chart_data = [
                {'month': month, 'doses': round(float(doses))}
                for month, doses in sorted(monthly_data.items())
            ]
            
            products = tool_input.get('products', ['All Products'])
            metrics = tool_input.get('metrics', ['Doses'])
            year = tool_input.get('year', 'All Years')
            
            return {
                'type': 'bar',
                'title': f"{products[0] if len(products) == 1 else 'Portfolio'} {metrics[0]} - {year}",
                'data': chart_data,
                'xKey': 'month',
                'yKey': 'doses',
                'yLabel': 'Doses',
                'source': 'FCT_DOSES_PLU_corrected'
            }
        
        return None
    
    except Exception as e:
        print(f"⚠️ Chart generation error: {e}")
        return None

def execute_tool(tool_name, tool_input):
    """Execute a tool and return results"""
    try:
        print(f"🔧 Executing tool: {tool_name} with input: {tool_input}", flush=True)
        if tool_name == "query_sales_finance_table":
            results = query_sales_finance_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        elif tool_name == "query_doses_table":
            results = query_doses_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        elif tool_name == "query_market_share_table":
            results = query_market_share_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        elif tool_name == "query_calls_table":
            results = query_calls_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        elif tool_name == "query_rome_table":
            results = query_rome_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        else:
            return {"success": False, "error": f"Unknown tool: {tool_name}"}
    
    except Exception as e:
        return {"success": False, "error": str(e)}

def handle_question_with_agent(question, image_base64=None, conversation_history=None, slide_number=None, use_preprocessed=False):
    """
    Handle question using simplified table-aligned approach
    """
    print(f"\n{'='*80}", flush=True)
    print(f"🤖 AGENT V2 (TABLE-ALIGNED)", flush=True)
    print(f"{'='*80}", flush=True)
    print(f"Question: {question}", flush=True)
    
    # Build messages
    messages = []
    
    # Add conversation history (limit to last 2 exchanges for performance)
    if conversation_history:
        for msg in conversation_history[-2:]:
            messages.append({
                "role": msg['role'],
                "content": msg['content']
            })
    
    # Build current message
    current_content = []
    
    # Add preprocessed slide context if available
    if use_preprocessed and slide_number:
        try:
            from app import get_slide_context
            slide_context = get_slide_context(slide_number)
        except ImportError:
            print("⚠️ Could not import get_slide_context from app")
            slide_context = None
        
        if slide_context:
            context_text = f"\n\n**Slide {slide_number} Context:**\n"
            context_text += f"**Title:** {slide_context.get('title', 'N/A')}\n"
            context_text += f"**Summary:** {slide_context.get('summary', '')}\n"
            
            # Add visual elements information
            visual_elements = slide_context.get('visual_elements', {})
            if visual_elements:
                chart_count = visual_elements.get('count', 0)
                charts = visual_elements.get('charts', [])
                
                context_text += f"\n**Visual Elements:** This slide contains {chart_count} charts/figures:\n"
                for i, chart in enumerate(charts, 1):
                    chart_type = chart.get('type', 'unknown')
                    chart_title = chart.get('title', 'Untitled')
                    chart_desc = chart.get('description', '')
                    context_text += f"{i}. {chart_type.title()} Chart: \"{chart_title}\" - {chart_desc}\n"
            
            # Add key numbers if available
            key_numbers = slide_context.get('key_numbers', [])
            if key_numbers:
                context_text += f"\n**Key Metrics:** "
                metrics = [f"{num.get('label', '')}: {num.get('value', '')} {num.get('unit', '')}" 
                          for num in key_numbers[:3]]  # Top 3 metrics
                context_text += ", ".join(metrics) + "\n"
            
            current_content.append({"type": "text", "text": context_text})
    
    # Add question
    current_content.append({"type": "text", "text": question})
    
    messages.append({
        "role": "user",
        "content": current_content
    })
    
    # Call Claude
    print("🤖 Calling Claude with table-aligned tools...", flush=True)
    
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1024,  # Reduced from 4096 to enforce concise responses
        "temperature": 0.7,
        "system": SYSTEM_PROMPT,
        "messages": messages,
        "tools": NOVARTIS_TOOLS
    }
    
    try:
        print(f"🔧 Invoking Bedrock model: us.anthropic.claude-sonnet-4-5-20250929-v1:0", flush=True)
        response = bedrock_runtime.invoke_model(
            modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
            body=json.dumps(request_body)
        )
        print("✅ Bedrock call successful", flush=True)
    except Exception as bedrock_error:
        print(f"❌ Bedrock error: {str(bedrock_error)}", flush=True)
        import traceback
        print(f"Bedrock traceback: {traceback.format_exc()}", flush=True)
        raise
    
    response_body = json.loads(response['body'].read())
    
    # Handle tool use
    stop_reason = response_body.get('stop_reason')
    chart_data = None
    data_source = None
    
    # Map tool names to table names
    TOOL_TO_TABLE = {
        'query_sales_finance_table': 'SALES_FINANCE_BPC_corrected',
        'query_doses_table': 'FCT_DOSES_PLU_corrected',
        'query_market_share_table': 'FCT_MARKET_PLU_corrected',
        'query_calls_table': 'FCT_CALLS',
        'query_rome_table': 'FCT_ROME_PLU'
    }
    
    if stop_reason == 'tool_use':
        print("🔧 Claude requested tool use")
        
        tool_results = []
        for content_block in response_body['content']:
            if content_block.get('type') == 'tool_use':
                tool_name = content_block['name']
                tool_input = content_block['input']
                tool_id = content_block['id']
                
                # Track data source from first tool call
                if not data_source:
                    data_source = TOOL_TO_TABLE.get(tool_name, 'Unknown')
                
                print(f"   Tool: {tool_name}")
                print(f"   Filters: {json.dumps(tool_input, indent=2)}")
                
                # Execute tool
                tool_result = execute_tool(tool_name, tool_input)
                
                print(f"   Records returned: {tool_result.get('record_count', 0)}")
                
                # Generate chart from first successful tool call
                if not chart_data and tool_result.get('success'):
                    chart_data = generate_chart_data(tool_name, tool_input, tool_result, question)
                    if chart_data:
                        print(f"   📊 Generated {chart_data['type']} chart: {chart_data['title']}")
                
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": json.dumps(tool_result)
                })
        
        # Send tool results back to Claude
        messages.append({
            "role": "assistant",
            "content": response_body['content']
        })
        
        messages.append({
            "role": "user",
            "content": tool_results
        })
        
        # Get final response
        print("🤖 Getting final analysis from Claude...", flush=True)
        
        request_body['messages'] = messages
        
        try:
            print(f"🔧 Second Bedrock call with tool results", flush=True)
            response = bedrock_runtime.invoke_model(
                modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
                body=json.dumps(request_body)
            )
            print("✅ Second Bedrock call successful", flush=True)
        except Exception as bedrock_error:
            print(f"❌ Second Bedrock error: {str(bedrock_error)}", flush=True)
            import traceback
            print(f"Second Bedrock traceback: {traceback.format_exc()}", flush=True)
            raise
        
        response_body = json.loads(response['body'].read())
    
    # Extract answer
    full_response = ""
    for content_block in response_body['content']:
        if content_block.get('type') == 'text':
            full_response += content_block['text']
    
    print(f"✅ Generated response ({len(full_response)} chars)")
    
    # Extract audio summary from response
    print("🎙️ Extracting audio summary from response...")
    if "---AUDIO_SUMMARY---" in full_response:
        parts = full_response.split("---AUDIO_SUMMARY---")
        answer = parts[0].strip()
        audio_summary = parts[1].strip() if len(parts) > 1 else ""
        
        # Clean up any remaining markdown or special chars
        audio_summary = audio_summary.replace('**', '').replace('*', '').replace('#', '').strip()
        print(f"✅ Audio summary extracted ({len(audio_summary)} chars)")
    else:
        # Fallback if Claude didn't include the audio summary
        print("⚠️ No audio summary marker found, using fallback")
        answer = full_response
        sentences = answer.split('.')
        audio_summary = '. '.join(sentences[:2]) + '.'
    
    # Remove ASCII chart sections if present (Claude sometimes ignores instructions)
    if any(phrase in answer for phrase in ["📊 Pie Chart", "Pie Chart Visualization", "Portfolio Composition -", "Chart Visualization"]):
        print("⚠️ Removing ASCII chart artifacts from response...")
        # Find and remove the ASCII chart section and its title
        lines = answer.split('\n')
        filtered_lines = []
        skip_section = False
        for line in lines:
            # Detect ASCII chart section start
            if any(phrase in line for phrase in ["Pie Chart Visualization", "📊 Pie Chart", "Portfolio Composition -", "Chart Visualization"]):
                skip_section = True
                continue
            # Detect ASCII chart content (blocks of █ characters)
            if '████' in line or '███' in line or '██' in line:
                continue
            # End skip section when we hit a new heading or content
            if skip_section and (line.startswith('#') or line.startswith('**Key') or line.startswith('**📊') or (line.strip() and not line.startswith(' '))):
                skip_section = False
            if not skip_section:
                filtered_lines.append(line)
        answer = '\n'.join(filtered_lines).strip()
        print(f"✅ Cleaned response ({len(answer)} chars)")
    
    return answer, chart_data, audio_summary, data_source

# Test
if __name__ == '__main__':
    print("Testing Table-Aligned Agent Handler")
    answer, _, _ = handle_question_with_agent("What were Pluvicto sales in 2025?")
    print(f"\nAnswer: {answer[:200]}...")
