#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Slide Preprocessor - Extract structured data from slides ONCE

This runs when slides are uploaded and extracts:
- All text content
- Numbers and metrics
- Chart data
- Context and relationships

The extracted data is stored in JSON format and used for all subsequent queries,
eliminating the need to send images to the LLM on every question.
"""

import json
import boto3
from botocore.config import Config
import base64
import os
import sys
from pathlib import Path
import time

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import secure file handler
from secure_file_handler import SecureFileHandler

# AWS clients
boto_config = Config(
    retries={'max_attempts': 3, 'mode': 'adaptive'},
    max_pool_connections=10
)

# Import shared Bedrock client to prevent connection leaks
from aws_clients import bedrock_runtime

EXTRACTION_PROMPT = """Analyze this slide and extract key information in a CONCISE structured format.

Extract ONLY the most important information:
1. **Title**: Main title
2. **Summary**: 1-2 sentence overview of what this slide shows
3. **Key Numbers**: Top 3-5 most important metrics only
4. **Main Topics**: List of main topics/categories covered
5. **Time Period**: Date range or time period mentioned
6. **Visual Elements**: Count and describe charts/figures on the slide

Return as JSON with this structure:
{
  "title": "string",
  "summary": "Brief 1-2 sentence overview",
  "key_numbers": [
    {"label": "Total Enrollment", "value": 45000, "unit": "members"}
  ],
  "main_topics": ["enrollment", "quality measures", "care coordination"],
  "time_period": "Q4 2025",
  "visual_elements": {
    "count": 3,
    "charts": [
      {"type": "line", "title": "Sales Trend", "description": "Monthly sales 2024-2025"},
      {"type": "bar", "title": "Product Mix", "description": "Revenue by product"},
      {"type": "table", "title": "Key Metrics", "description": "YTD performance summary"}
    ]
  }
}

Be CONCISE - only extract the most critical information. Avoid long text blocks."""

def preprocess_slide(slide_path, slide_number):
    """
    Extract structured data from a single slide using Claude Sonnet vision model.
    
    Args:
        slide_path: Path to the slide image file
        slide_number: Slide number (for reference)
    
    Returns:
        dict: Structured data extracted from the slide
    """
    print(f"\n{'='*80}")
    print(f"📄 Processing Slide {slide_number}")
    print(f"{'='*80}")
    
    start_time = time.time()
    
    # Initialize secure file handler for slide directory
    slide_dir = os.path.dirname(slide_path)
    secure_handler = SecureFileHandler([slide_dir])
    
    # Load image securely
    filename = os.path.basename(slide_path)
    image_bytes = secure_handler.safe_read_file(filename, slide_dir, 'rb')
    image_base64 = base64.b64encode(image_bytes).decode('utf-8')
    
    # Call Claude Sonnet with vision
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 4096,
        "temperature": 0.3,  # Lower temperature for more consistent extraction
        "messages": [{
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/png",
                        "data": image_base64
                    }
                },
                {
                    "type": "text",
                    "text": EXTRACTION_PROMPT
                }
            ]
        }]
    }
    
    print("🤖 Calling Claude Sonnet vision model...")
    response = bedrock_runtime.invoke_model(
        modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
        body=json.dumps(request_body)
    )
    
    response_body = json.loads(response['body'].read())
    extracted_text = response_body['content'][0]['text']
    
    # Parse JSON from response
    try:
        # Handle markdown code blocks
        if '```json' in extracted_text:
            json_str = extracted_text.split('```json')[1].split('```')[0].strip()
        elif '```' in extracted_text:
            json_str = extracted_text.split('```')[1].split('```')[0].strip()
        else:
            json_str = extracted_text
        
        structured_data = json.loads(json_str)
    except Exception as e:
        print(f"⚠️ Error parsing JSON: {e}")
        print(f"Raw response: {extracted_text[:500]}...")
        # Fallback: store raw text
        structured_data = {
            "title": f"Slide {slide_number}",
            "raw_extraction": extracted_text,
            "error": str(e)
        }
    
    # Add metadata
    structured_data['slide_number'] = slide_number
    structured_data['extraction_timestamp'] = time.time()
    structured_data['processing_time'] = round(time.time() - start_time, 2)
    
    print(f"✅ Extraction complete in {structured_data['processing_time']}s")
    print(f"   Title: {structured_data.get('title', 'N/A')}")
    print(f"   Numbers extracted: {len(structured_data.get('numbers', []))}")
    print(f"   Charts extracted: {len(structured_data.get('charts', []))}")
    
    return structured_data

def pdf_to_images(pdf_path, output_dir):
    """
    Convert PDF to images using pdf2image library.
    
    Args:
        pdf_path: Path to PDF file
        output_dir: Directory to save images
    
    Returns:
        list: Paths to generated images
    """
    try:
        from pdf2image import convert_from_path
    except ImportError:
        print("❌ pdf2image not installed. Install with: pip install pdf2image")
        print("   Also requires poppler: brew install poppler (Mac) or apt-get install poppler-utils (Linux)")
        raise
    
    print(f"📄 Converting PDF to images...")
    print(f"   PDF: {pdf_path}")
    print(f"   Output: {output_dir}")
    
    # Create output directory
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    # Convert PDF to images
    images = convert_from_path(pdf_path, dpi=150)  # 150 DPI for good quality
    
    image_paths = []
    for i, image in enumerate(images, start=1):
        image_path = os.path.join(output_dir, f'slide_{i:02d}.png')
        image.save(image_path, 'PNG')
        image_paths.append(image_path)
        print(f"   ✓ Saved slide {i}")
    
    print(f"✅ Converted {len(images)} pages to images")
    return image_paths

def preprocess_slides(pdf_path, status_callback=None):
    """
    Main preprocessing function: PDF -> Images -> Extract Data
    
    Args:
        pdf_path: Path to PDF file
        status_callback: Optional callback function(current, total) for progress updates
    
    Returns:
        dict: Result with total_slides and data_file path
    """
    print(f"\n{'='*80}")
    print(f"🚀 SLIDE PREPROCESSING STARTED")
    print(f"{'='*80}")
    
    overall_start = time.time()
    
    # Step 1: Convert PDF to images
    slides_dir = os.path.join(os.path.dirname(pdf_path), 'slides')
    image_paths = pdf_to_images(pdf_path, slides_dir)
    
    # Step 2: Process each slide
    all_slides_data = []
    total_slides = len(image_paths)
    
    for idx, image_path in enumerate(image_paths, start=1):
        if status_callback:
            status_callback(idx, total_slides)
        
        try:
            slide_data = preprocess_slide(image_path, idx)
            all_slides_data.append(slide_data)
        except Exception as e:
            print(f"❌ Error processing slide {idx}: {e}")
            import traceback
            traceback.print_exc()
            all_slides_data.append({
                "slide_number": idx,
                "error": str(e),
                "extraction_timestamp": time.time()
            })
    
    # Step 3: Save to JSON
    output_file = os.path.join(os.path.dirname(pdf_path), 'preprocessed_slides.json')
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Use Path.write_text for secure file writing
    json_content = json.dumps(all_slides_data, indent=2)
    output_path.write_text(json_content, encoding='utf-8')
    
    total_time = round(time.time() - overall_start, 2)
    
    print(f"\n{'='*80}")
    print(f"✅ PREPROCESSING COMPLETE")
    print(f"{'='*80}")
    print(f"Total slides processed: {len(all_slides_data)}")
    print(f"Total time: {total_time}s")
    print(f"Average time per slide: {round(total_time / len(all_slides_data), 2)}s")
    print(f"Output saved to: {output_file}")
    print(f"{'='*80}\n")
    
    return {
        'total_slides': total_slides,
        'data_file': output_file,
        'slides_dir': slides_dir,
        'processing_time': total_time
    }

def preprocess_all_slides(slides_dir, output_file):
    """
    Preprocess all slides in a directory and save to JSON.
    
    Args:
        slides_dir: Directory containing slide images
        output_file: Path to save the preprocessed data JSON
    """
    print(f"\n{'='*80}")
    print(f"🚀 SLIDE PREPROCESSING STARTED")
    print(f"{'='*80}")
    print(f"Input directory: {slides_dir}")
    print(f"Output file: {output_file}")
    
    overall_start = time.time()
    
    # Find all slide images
    slides_path = Path(slides_dir)
    slide_files = sorted(slides_path.glob('slide_*.png'))
    
    print(f"\nFound {len(slide_files)} slides to process")
    
    # Process each slide
    all_slides_data = []
    
    for slide_file in slide_files:
        # Extract slide number from filename (e.g., slide_01.png -> 1)
        slide_number = int(slide_file.stem.split('_')[1])
        
        try:
            slide_data = preprocess_slide(str(slide_file), slide_number)
            all_slides_data.append(slide_data)
        except Exception as e:
            print(f"❌ Error processing slide {slide_number}: {e}")
            import traceback
            traceback.print_exc()
            # Add error entry
            all_slides_data.append({
                "slide_number": slide_number,
                "error": str(e),
                "extraction_timestamp": time.time()
            })
    
    # Save to JSON
    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Use Path.write_text for secure file writing
    json_content = json.dumps(all_slides_data, indent=2)
    output_path.write_text(json_content, encoding='utf-8')
    
    total_time = round(time.time() - overall_start, 2)
    
    print(f"\n{'='*80}")
    print(f"✅ PREPROCESSING COMPLETE")
    print(f"{'='*80}")
    print(f"Total slides processed: {len(all_slides_data)}")
    print(f"Total time: {total_time}s")
    print(f"Average time per slide: {round(total_time / len(all_slides_data), 2)}s")
    print(f"Output saved to: {output_file}")
    print(f"{'='*80}\n")
    
    return all_slides_data

def load_preprocessed_data(data_file):
    """Load preprocessed slide data from JSON file"""
    try:
        # Use Path.read_text for secure file reading
        data_path = Path(data_file)
        json_content = data_path.read_text(encoding='utf-8')
        return json.loads(json_content)
    except FileNotFoundError:
        print(f"⚠️ Preprocessed data file not found: {data_file}")
        return None
    except Exception as e:
        print(f"❌ Error loading preprocessed data: {e}")
        return None

def get_slide_data(slide_number, preprocessed_data):
    """Get preprocessed data for a specific slide"""
    if not preprocessed_data:
        return None
    
    for slide in preprocessed_data:
        if slide.get('slide_number') == slide_number:
            return slide
    
    return None

# CLI interface
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Preprocess slides to extract structured data')
    parser.add_argument('--slides-dir', default='data_sample/mbr_slides',
                       help='Directory containing slide images (to be generated)')
    parser.add_argument('--output', default='data_sample/preprocessed_slides.json',
                       help='Output JSON file for preprocessed data')
    
    args = parser.parse_args()
    
    # Run preprocessing
    preprocess_all_slides(args.slides_dir, args.output)
