#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Novartis DynamoDB Query Functions - V2 (Table-Aligned)

Properly aligned with SME guidance:
- One function per table
- Let DynamoDB do the filtering
- No Python aggregation
- Use relative indexes for time filtering
"""

import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
import json
import os

# AWS Configuration - use shared utility for consistent credential handling
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'utils', 'aws'))
from aws_utils import get_aws_resource

# Initialize DynamoDB resource
dynamodb = get_aws_resource('dynamodb')

# Table references
sales_table = dynamodb.Table('Novartis_Sales_Finance')
market_table = dynamodb.Table('Novartis_Market_Share')
doses_table = dynamodb.Table('Novartis_Doses')
calls_table = dynamodb.Table('Novartis_Calls')
rome_table = dynamodb.Table('Novartis_Rome')

def decimal_to_float(obj):
    """Convert Decimal to float for JSON serialization"""
    if isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_float(i) for i in obj]
    return obj

def query_sales_finance_table(filters=None):
    """
    Query SALES_FINANCE_BPC_corrected table
    
    This is the ONLY function needed for ALL sales questions:
    - Revenue, net sales, gross sales, revenue deductions
    - YTD, quarterly, monthly, YoY, MoM
    - Actual vs Budget vs OC
    - Single product or all products
    
    Args:
        filters: dict with optional filters:
            - products: list of product names (default: all)
            - forecast_types: list of forecast types (default: ['Actual'])
            - year: specific year (default: all)
            - start_date: start date (YYYY-MM-DD)
            - end_date: end date (YYYY-MM-DD)
            - year_rel_index: relative year (1000=current, 999=last year)
            - month_rel_index: relative month
            - cycle_rel_index: relative quarter
    
    Returns:
        list: All matching records with ALL columns
    """
    try:
        filters = filters or {}
        
        # Scan the table (in production, use GSI for better performance)
        response = sales_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'products' in filters:
            items = [i for i in items if i.get('brand') in filters['products']]
        
        if 'forecast_types' in filters:
            items = [i for i in items if i.get('forecast_type') in filters['forecast_types']]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying sales table: {e}")
        return []

def query_doses_table(filters=None):
    """
    Query FCT_DOSES_PLU_corrected table
    
    This is the ONLY function needed for ALL national-level dose questions:
    - TRX_shipped, TRX_injected, NBRX
    - Actual vs Budget vs OC
    - YTD, quarterly, monthly, YoY, MoM
    - Single product or all products
    
    Args:
        filters: dict with optional filters:
            - products: list of product names
            - metrics: list of metric types (TRX_shipped, TRX_injected, NBRX)
            - forecast_types: list of forecast types
            - year: specific year
            - start_date, end_date: date range
            - year_rel_index, month_rel_index, quarter_rel_index: relative time
    
    Returns:
        list: All matching records with ALL columns
    """
    try:
        filters = filters or {}
        
        # Scan the table
        response = doses_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'products' in filters:
            items = [i for i in items if i.get('brand') in filters['products']]
        
        if 'metrics' in filters:
            items = [i for i in items if i.get('metric') in filters['metrics']]
        
        if 'forecast_types' in filters:
            items = [i for i in items if i.get('forecast_type') in filters['forecast_types']]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'quarter_rel_index' in filters:
            items = [i for i in items if i.get('quarter_rel_index') == filters['quarter_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying doses table: {e}")
        return []

def query_market_share_table(filters=None):
    """
    Query FCT_MARKET_PLU_corrected table
    
    This is the ONLY function needed for ALL market share and competitor questions:
    - Market share trends
    - Competitor analysis
    - TRX and NBRX volumes and shares
    - All brands including competitors
    
    Args:
        filters: dict with optional filters:
            - brands: list of brand names (includes competitors)
            - year: specific year
            - start_date, end_date: date range
            - year_rel_index, month_rel_index, cycle_rel_index: relative time
    
    Returns:
        list: All matching records with ALL columns
    """
    try:
        filters = filters or {}
        
        # Scan the table
        response = market_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'brands' in filters:
            items = [i for i in items if i.get('brand') in filters['brands']]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying market share table: {e}")
        return []

# Test function
if __name__ == '__main__':
    print("Testing Table-Aligned Query Functions")
    print("="*80)
    
    # Test 1: Get all Pluvicto sales for 2025
    print("\n1. Pluvicto Sales 2025 (Actual):")
    sales = query_sales_finance_table({
        'products': ['Pluvicto'],
        'year': 2025,
        'forecast_types': ['Actual']
    })
    print(f"   Found {len(sales)} records")
    if sales:
        total = sum(s.get('net_sales', 0) for s in sales)
        print(f"   Total: ${total/1e6:.1f}M")
    
    # Test 2: Get Q1 2025 doses for all products
    print("\n2. Q1 2025 Doses (All Products):")
    doses = query_doses_table({
        'year': 2025,
        'quarter_rel_index': 1000,  # Current quarter
        'metrics': ['TRX_shipped'],
        'forecast_types': ['Actual']
    })
    print(f"   Found {len(doses)} records")
    
    # Test 3: Get market share for all brands
    print("\n3. Market Share All Brands 2025:")
    market = query_market_share_table({
        'year': 2025
    })
    print(f"   Found {len(market)} records")
    
    # Test 4: Get calls data for Q1 2024
    print("\n4. Calls Data Q1 2024:")
    calls = query_calls_table({
        'year_quarter': '2024-Q1',
        'products': ['Pluvicto']
    })
    print(f"   Found {len(calls)} records")
    
    # Test 5: Get Rome data for active sites
    print("\n5. Rome Data - Active Sites:")
    rome = query_rome_table({
        'active_dormant': 'Active',
        'products': ['Pluvicto']
    })
    print(f"   Found {len(rome)} records")
    
    print("\n" + "="*80)
    print("✅ Tests complete - 5 tables queried")


def query_calls_table(filters=None):
    """
    Query FCT_CALLS table for field activity and sales rep performance
    
    USE FOR:
    - Field activity analysis
    - Sales rep performance tracking
    - HCP reach and engagement metrics
    - Call frequency and attainment analysis
    - Team performance by geography
    
    Args:
        filters: dict with optional filters:
            - products: list of product names (default: all)
            - geo_level: 'Nation' or 'Region'
            - geo_name: specific geography name
            - metric_type: 'hcp_reach', 'cpd', 'call_frequency_attainment', 'total_calls'
            - year_quarter: specific quarter (e.g., '2024-Q1')
            - cycle_rel_index: relative cycle (1000=current, 999=last quarter)
            - start_date, end_date: date range (YYYY-MM-DD)
    
    Returns:
        list: All matching records with columns:
            product, dim_geo_level, dim_geo_name, dim_time_period, dim_metric_type,
            CPD, cpd_goal, cpd_attainment, target_hcp_reach, total_target, percent_reached,
            call_frequency_actual, call_frequency_attainment, actual_calls, planned_calls,
            cycle_rel_index, call_date, dim_date, year_quarter, etc.
    """
    try:
        filters = filters or {}
        
        # Scan the table
        response = calls_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'products' in filters:
            items = [i for i in items if i.get('product') in filters['products']]
        
        if 'geo_level' in filters:
            items = [i for i in items if i.get('dim_geo_level') == filters['geo_level']]
        
        if 'geo_name' in filters:
            items = [i for i in items if i.get('dim_geo_name') == filters['geo_name']]
        
        if 'metric_type' in filters:
            items = [i for i in items if i.get('dim_metric_type') == filters['metric_type']]
        
        if 'year_quarter' in filters:
            items = [i for i in items if i.get('year_quarter') == filters['year_quarter']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('dim_date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('dim_date') <= filters['end_date']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying calls table: {e}")
        return []

def query_rome_table(filters=None):
    """
    Query FCT_ROME_PLU table for site-level activity and patient demand
    
    USE FOR:
    - Site activity analysis (active vs dormant sites)
    - Patient-level demand tracking
    - Geography-level demand (territory, area, region)
    - Injection patterns and dose sequences
    - NBRx tracking (new patient starts)
    - Ordering behavior over time
    - Customer-level analysis
    
    DO NOT USE FOR:
    - Market share analysis (use query_market_share_table)
    - Competitor analysis (use query_market_share_table)
    
    Args:
        filters: dict with optional filters:
            - products: list of product names (default: all)
            - territories: list of territory names
            - regions: list of region names
            - site_ids: list of site IDs
            - active_dormant: 'Active' or 'Dormant'
            - order_status: order status filter
            - is_first_dose: True/False for first dose orders
            - year_quarter: specific quarter (e.g., '2024-Q1')
            - cycle_rel_index: relative cycle (1000=current, 999=last quarter)
            - start_date, end_date: date range (YYYY-MM-DD)
    
    Returns:
        list: All matching records with columns:
            PRODUCT, DIM_Brand, dim_date, dim_customer_name, site_id, dim_site_type,
            dim_terr_name, dim_area_name, dim_region_name, dim_tier, active_dormant_flag,
            sales_order_number, patient_reference_number, dose_number, is_patients_first_dose,
            dim_order_status, dim_order_type, month_rel_index, year_rel_index, cycle_rel_index,
            year_quarter, etc.
    """
    try:
        filters = filters or {}
        
        # Scan the table
        response = rome_table.scan()
        items = response.get('Items', [])
        
        # Apply filters
        if 'products' in filters:
            items = [i for i in items if i.get('PRODUCT') in filters['products']]
        
        if 'territories' in filters:
            items = [i for i in items if i.get('dim_terr_name') in filters['territories']]
        
        if 'regions' in filters:
            items = [i for i in items if i.get('dim_region_name') in filters['regions']]
        
        if 'site_ids' in filters:
            items = [i for i in items if i.get('site_id') in filters['site_ids']]
        
        if 'active_dormant' in filters:
            items = [i for i in items if i.get('active_dormant_flag') == filters['active_dormant']]
        
        if 'order_status' in filters:
            items = [i for i in items if i.get('dim_order_status') == filters['order_status']]
        
        if 'is_first_dose' in filters:
            first_dose_str = 'Yes' if filters['is_first_dose'] else 'No'
            items = [i for i in items if i.get('is_patients_first_dose') == first_dose_str]
        
        if 'year_quarter' in filters:
            items = [i for i in items if i.get('year_quarter') == filters['year_quarter']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('dim_date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('dim_date') <= filters['end_date']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying rome table: {e}")
        return []
