#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025

MBR Dashboard Backend API - Enhanced with Base Path Support

A Flask-based REST API that connects the React frontend to AWS services:
- Amazon Bedrock (Claude 3.5 Sonnet v2) for AI analysis
- Amazon DynamoDB for Novartis KPI data queries
- Amazon Polly Neural for text-to-speech synthesis

Enhanced Features:
- Configurable base path deployment (e.g., /mbr, /dashboard)
- Dynamic route registration based on configuration
- Proper SPA fallback handling for client-side routing

Endpoints:
    {BASE_PATH}/api/ask - Process questions about Novartis MBR slides
    {BASE_PATH}/api/synthesize - Convert text to speech using Polly
    {BASE_PATH}/api/health - Health check endpoint
    {BASE_PATH}/static/* - Static assets (CSS, JS, images)
    {BASE_PATH}/* - Frontend SPA routes

Author: AI Assistant + User
Date: December 2025
"""

from flask import Flask, request, jsonify, send_from_directory, redirect, url_for
from flask_cors import CORS
import boto3
from botocore.config import Config as BotoConfig
import json
import base64
import os
import sys
import time
import logging
import traceback
import re
from werkzeug.exceptions import NotFound

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import configuration
from backend_api.config import Config
from backend_api.novartis_agent_handler_v2_1 import handle_question_with_agent
from backend_api.aws_clients import bedrock_runtime, polly_client
from backend_api.slide_preprocessor import preprocess_slides

# Initialize configuration
config = Config()

# Configure logging
logging.basicConfig(
    level=getattr(logging, config.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s' if config.log_format == 'detailed' else '%(levelname)s: %(message)s'
)
logger = logging.getLogger(__name__)

# Print configuration summary
config.print_config_summary()

# Create Flask app - always serve frontend from the same app for consistency
app = Flask(__name__, static_folder='frontend', static_url_path='')

# Apply Flask configuration
app.config.update(config.get_flask_config())

# Get base path configuration from the config instance
base_path_config = config.base_path_config

# Enhanced route registration with base path support
class BasePathAwareRouting:
    """Enhanced routing system with base path awareness"""
    
    def __init__(self, app, base_path_config):
        self.app = app
        self.base_path_config = base_path_config
        self.registered_routes = []
        
    def register_api_route(self, endpoint, methods=['GET'], handler=None):
        """Register API route with base path prefix"""
        full_route = f"{self.base_path_config.api_prefix}/{endpoint.lstrip('/')}"
        
        if handler:
            self.app.add_url_rule(full_route, endpoint=f"api_{endpoint.replace('/', '_')}", 
                                view_func=handler, methods=methods)
            self.registered_routes.append(('API', full_route, methods))
            logger.info(f"Registered API route: {full_route} [{', '.join(methods)}]")
    
    def register_static_route(self, endpoint, handler=None):
        """Register static asset route with base path prefix"""
        full_route = f"{self.base_path_config.static_prefix}/{endpoint.lstrip('/')}"
        
        if handler:
            self.app.add_url_rule(full_route, endpoint=f"static_{endpoint.replace('/', '_')}", 
                                view_func=handler, methods=['GET'])
            self.registered_routes.append(('STATIC', full_route, ['GET']))
            logger.info(f"Registered static route: {full_route}")
    
    def register_spa_routes(self):
        """Register SPA routes with proper fallback handling"""
        base_path = self.base_path_config.base_path
        
        # Root route for the base path
        if base_path:
            # Base path root (e.g., /mbr)
            self.app.add_url_rule(base_path, endpoint='spa_root', 
                                view_func=self.serve_spa_root, methods=['GET'])
            self.registered_routes.append(('SPA', base_path, ['GET']))
            
            # Base path with trailing slash (e.g., /mbr/)
            self.app.add_url_rule(f"{base_path}/", endpoint='spa_root_slash', 
                                view_func=self.serve_spa_root, methods=['GET'])
            self.registered_routes.append(('SPA', f"{base_path}/", ['GET']))
            
            # SPA fallback for all other routes under base path
            self.app.add_url_rule(f"{base_path}/<path:path>", endpoint='spa_fallback', 
                                view_func=self.serve_spa_fallback, methods=['GET'])
            self.registered_routes.append(('SPA', f"{base_path}/<path:path>", ['GET']))
        else:
            # Root deployment - register root and fallback
            self.app.add_url_rule('/', endpoint='spa_root', 
                                view_func=self.serve_spa_root, methods=['GET'])
            self.registered_routes.append(('SPA', '/', ['GET']))
            
            # Fallback for all non-API, non-static routes
            self.app.add_url_rule('/<path:path>', endpoint='spa_fallback', 
                                view_func=self.serve_spa_fallback, methods=['GET'])
            self.registered_routes.append(('SPA', '/<path:path>', ['GET']))
        
        logger.info(f"Registered SPA routes for base path: {base_path or '(root)'}")
    
    def serve_spa_root(self):
        """Serve the React frontend index.html for root routes"""
        try:
            return send_from_directory(app.static_folder, 'index.html')
        except Exception as e:
            logger.error(f"Error serving SPA root: {str(e)}")
            return jsonify({
                'error': 'Frontend not available', 
                'message': 'Run: npm run build && cp -r frontend/build/* backend_api/frontend/'
            }), 404
    
    def serve_spa_fallback(self, path):
        """Handle SPA fallback for client-side routing"""
        # Reconstruct full path with base path for proper checking
        full_path = f"{self.base_path_config.base_path}/{path}" if self.base_path_config.base_path else f"/{path}"
        
        # Check if this is an API or static request that shouldn't fallback
        if (self.base_path_config.is_api_path(full_path) or 
            self.base_path_config.is_static_path(full_path) or
            path.startswith('api/') or path.startswith('static/')):
            # This should be handled by specific routes, return 404
            return jsonify({'error': f'Endpoint not found: {full_path}'}), 404
        
        # Check if it's a static file request (has file extension)
        if '.' in path.split('/')[-1]:
            try:
                # Try to serve as static file first
                return send_from_directory(app.static_folder, path)
            except Exception:
                # If static file not found, return 404 (don't fallback to SPA)
                return jsonify({'error': f'Static file not found: {path}'}), 404
        
        # For routes without extensions, serve SPA (React Router will handle)
        try:
            return send_from_directory(app.static_folder, 'index.html')
        except Exception as e:
            logger.error(f"Error serving SPA fallback for {path}: {str(e)}")
            return jsonify({
                'error': 'Frontend not available', 
                'message': 'Run: npm run build && cp -r frontend/build/* backend_api/frontend/'
            }), 404
    
    def print_registered_routes(self):
        """Print all registered routes for debugging"""
        logger.info("=== Registered Routes ===")
        for route_type, route, methods in self.registered_routes:
            logger.info(f"  {route_type}: {route} [{', '.join(methods)}]")
        logger.info("========================")

# Initialize enhanced routing
router = BasePathAwareRouting(app, base_path_config)

# Security middleware and headers
@app.after_request
def add_security_headers(response):
    """Add security headers to all responses"""
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' data: blob:"
    return response

@app.before_request
def validate_request_security():
    """Validate request for security issues"""
    # Log suspicious patterns in URLs and parameters
    suspicious_patterns = ['../', '..\\', '%2e%2e', '%2f', '%5c', '<script', 'javascript:', 'data:']
    
    request_url = request.url.lower()
    request_args = str(request.args).lower()
    
    for pattern in suspicious_patterns:
        if pattern in request_url or pattern in request_args:
            app.logger.warning(f"Suspicious request pattern detected: {pattern} from {request.remote_addr}")
            break

# Configure CORS with base path awareness
cors_origins = config.cors_origins.copy()

# Add base path aware origins for local development
if config.is_local_development:
    base_path = base_path_config.base_path
    local_origins = [
        f'http://localhost:5000{base_path}',
        f'http://127.0.0.1:5000{base_path}',
        'http://localhost:5000',
        'http://127.0.0.1:5000'
    ]
    cors_origins.extend(local_origins)

if config.is_local_development:
    CORS(app, origins=cors_origins)
else:
    # More restrictive CORS for production
    CORS(app, origins=cors_origins if cors_origins != ['*'] else False)

# AWS clients with retry configuration
boto_config = BotoConfig(
    retries={
        'max_attempts': 3,
        'mode': 'adaptive'
    },
    max_pool_connections=10,
    region_name=config.aws_region
)

# AWS clients are imported at the top

def invoke_bedrock_with_retry(request_body, max_retries=3, initial_delay=2):
    """Invoke Bedrock with exponential backoff retry logic"""
    for attempt in range(max_retries):
        try:
            response = bedrock_runtime.invoke_model(
                modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
                body=json.dumps(request_body)
            )
            return json.loads(response['body'].read())
        except Exception as e:
            if 'ServiceUnavailableException' in str(e) or 'ThrottlingException' in str(e):
                if attempt < max_retries - 1:
                    delay = initial_delay * (2 ** attempt)
                    print(f"⏳ Rate limited, retrying in {delay}s... (attempt {attempt + 1}/{max_retries})")
                    time.sleep(delay)
                else:
                    raise
            else:
                raise

# Route handlers (will be registered with base path awareness)

def ask_question():
    """Handle question from frontend using Novartis agent handler"""
    try:
        data = request.json
        question = data.get('question', '')
        slide_number = data.get('slideNumber', 1)
        conversation_history = data.get('conversationHistory', [])
        
        if not question:
            return jsonify({'error': 'No question provided'}), 400
        
        # Resolve follow-up questions using conversation context
        resolved_question = resolve_follow_up_question(question, conversation_history)
        
        # Use resolved question for processing
        if resolved_question != question:
            print(f"🔄 Resolved follow-up question:")
            print(f"   Original: {question}")
            print(f"   Resolved: {resolved_question}")
            question = resolved_question
        
        # Use Novartis agent-based handler
        start_time = time.time()
        timing = {}
        
        print(f"🤖 Using Novartis agent handler")
        print(f"   Question: {question}")
        
        # Load slide image and preprocessed data
        load_start = time.time()
        
        # Secure slide loading with path traversal protection
        from backend_api.secure_file_handler import SecureFileHandler, validate_slide_number
        
        try:
            # Validate slide number
            validated_slide_num = validate_slide_number(slide_number, max_slides=100)
            
            # Initialize secure file handler
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            allowed_dirs = [
                os.path.join(project_root, 'uploads', 'slides'),
                os.path.join(project_root, 'data_sample', 'slide_images')
            ]
            file_handler = SecureFileHandler(allowed_dirs)
            
            # Define filename
            filename = f'slide_{validated_slide_num:02d}.png'
            
            # Try uploaded slides first
            image_base64 = None
            slide_path = None
            
            try:
                uploads_dir = os.path.join(project_root, 'uploads', 'slides')
                image_bytes = file_handler.safe_read_file(filename, uploads_dir, 'rb')
                image_base64 = base64.b64encode(image_bytes).decode('utf-8')
                print(f"   ✓ Loaded slide from uploads: {uploads_dir}/{filename}")
            except (ValueError, FileNotFoundError):
                # Fallback to sample slides
                try:
                    sample_dir = os.path.join(project_root, 'data_sample', 'slide_images')
                    image_bytes = file_handler.safe_read_file(filename, sample_dir, 'rb')
                    image_base64 = base64.b64encode(image_bytes).decode('utf-8')
                    print(f"   ✓ Loaded slide from samples: {sample_dir}/{filename}")
                except (ValueError, FileNotFoundError):
                    print(f"   ✗ Slide {validated_slide_num} not found in any directory")
                    
        except ValueError as e:
            print(f"   ✗ Invalid slide number: {e}")
            image_base64 = None
        
        # Load preprocessed slide context
        slide_context = get_slide_context(slide_number)
        if slide_context:
            print(f"   ✓ Using preprocessed data for slide {slide_number}")
            print(f"     Title: {slide_context.get('title', 'N/A')}")
        
        timing['data_load'] = round(time.time() - load_start, 2)
        
        # Use Novartis agent-based handler with conversation history
        agent_start = time.time()
        answer, chart_data, audio_summary, data_source = handle_question_with_agent(
            question, 
            image_base64, 
            conversation_history,
            slide_number=slide_number,
            use_preprocessed=True  # Enable preprocessed data
        )
        timing['agent_processing'] = round(time.time() - agent_start, 2)
        
        timing['total'] = round(time.time() - start_time, 2)
        
        print(f"⏱️ Timing breakdown: {timing}")
        
        response = {
            'answer': answer,
            'audioSummary': audio_summary,  # Polly-friendly version
            'dataSource': data_source,  # DynamoDB table used
            'mode': 'novartis-agent',
            'timing': timing
        }
        
        if chart_data:
            response['chartData'] = chart_data
        
        print(f"📤 Sending response with timing: {response.get('timing')}")
        return jsonify(response)
        
    except Exception as e:
        error_msg = f"❌ Error in /api/ask: {str(e)}"
        print(error_msg, flush=True)  # Force flush to stdout
        logger.error(error_msg)
        logger.error(f"Traceback: {traceback.format_exc()}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def synthesize_speech():
    """Convert text to speech using Amazon Polly Neural"""
    try:
        data = request.json
        text = data.get('text', '')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        print(f"\n🔊 Synthesizing speech: {text[:100]}...")
        
        # Use Polly Neural for high-quality speech
        response = polly_client.synthesize_speech(
            Text=text,
            OutputFormat='mp3',
            VoiceId='Joanna',  # Neural voice
            Engine='neural'
        )
        
        # Get audio stream
        audio_stream = response['AudioStream'].read()
        
        # Convert to base64 for frontend
        audio_base64 = base64.b64encode(audio_stream).decode('utf-8')
        
        return jsonify({
            'audioData': audio_base64,
            'contentType': 'audio/mpeg'
        })
        
    except Exception as e:
        print(f"❌ Polly error: {e}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok', 
        'message': 'Novartis MBR Dashboard API is running',
        'basePath': base_path_config.base_path,
        'apiPrefix': base_path_config.api_prefix,
        'staticPrefix': base_path_config.static_prefix
    })

def preprocess_pdf():
    """
    Upload and preprocess PDF slides
    Extracts images and processes them with Vision Model
    """
    global preprocessing_status, preprocessed_slides_cache
    
    # Clear the cache so new preprocessing results are loaded
    preprocessed_slides_cache = None
    print("🔄 Cleared preprocessed slides cache")
    
    try:
        # Check if PDF file is present
        if 'pdf' not in request.files:
            return jsonify({'error': 'No PDF file provided'}), 400
        
        pdf_file = request.files['pdf']
        if pdf_file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not pdf_file.filename.endswith('.pdf'):
            return jsonify({'error': 'File must be a PDF'}), 400
        
        # Save PDF temporarily - use environment-aware path
        if config.is_aws_deployment:
            upload_dir = '/app/uploads'
        else:
            # Local development - use project root
            upload_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads')
        os.makedirs(upload_dir, exist_ok=True)
        
        pdf_path = os.path.join(upload_dir, 'presentation.pdf')
        pdf_file.save(pdf_path)
        
        # Update status
        preprocessing_status = {
            'stage': 'extracting',
            'progress': 0.2,
            'message': 'Extracting slides from PDF',
            'currentSlide': 0,
            'totalSlides': 0
        }
        
        # Use preprocessing function (imported at top)
        
        # Start preprocessing in background (for demo, we'll do it synchronously)
        print("🚀 Starting slide preprocessing...")
        
        # Run preprocessing
        result = preprocess_slides(pdf_path)
        
        # Check if result has total_slides (success case)
        if 'total_slides' in result:
            preprocessing_status = {
                'stage': 'complete',
                'progress': 1.0,
                'message': 'Preprocessing complete!',
                'currentSlide': result['total_slides'],
                'totalSlides': result['total_slides']
            }
            
            return jsonify({
                'message': 'PDF uploaded and preprocessing started',
                'status': 'success',
                'totalSlides': result['total_slides']
            })
        else:
            preprocessing_status = {
                'stage': 'error',
                'progress': 0,
                'message': 'Preprocessing failed',
                'currentSlide': 0,
                'totalSlides': 0
            }
            return jsonify({'error': 'Preprocessing failed'}), 500
            
    except Exception as e:
        print(f"❌ Preprocessing error: {str(e)}")
        preprocessing_status = {
            'stage': 'error',
            'progress': 0,
            'message': f'Upload failed: {str(e)}',
            'currentSlide': 0,
            'totalSlides': 0
        }
        return jsonify({'error': str(e)}), 500

def get_preprocessing_status():
    """Get current preprocessing status"""
    global preprocessing_status
    return jsonify(preprocessing_status)

def get_slide_image(slide_number):
    """Serve uploaded slide images with security protection"""
    try:
        from backend_api.secure_file_handler import SecureFileHandler, validate_slide_number
        
        # Validate slide number
        validated_slide_num = validate_slide_number(slide_number, max_slides=100)
        
        # Initialize secure file handler with environment-aware paths
        if config.is_aws_deployment:
            allowed_dirs = [
                '/app/uploads/slides',
                '/app/data_sample/slide_images'
            ]
            uploads_dir = '/app/uploads/slides'
            sample_dir = '/app/data_sample/slide_images'
        else:
            # Local development paths
            project_root = os.path.dirname(os.path.dirname(__file__))
            allowed_dirs = [
                os.path.join(project_root, 'uploads', 'slides'),
                os.path.join(project_root, 'data_sample', 'slide_images')
            ]
            uploads_dir = os.path.join(project_root, 'uploads', 'slides')
            sample_dir = os.path.join(project_root, 'data_sample', 'slide_images')
        
        file_handler = SecureFileHandler(allowed_dirs)
        filename = f'slide_{validated_slide_num:02d}.png'
        
        # Try uploaded slides first, then sample slides
        try:
            image_data = file_handler.safe_read_file(filename, uploads_dir, 'rb')
            image_data_b64 = base64.b64encode(image_data).decode('utf-8')
            return jsonify({'imageData': image_data_b64})
        except (ValueError, FileNotFoundError):
            # Fallback to sample slides
            try:
                image_data = file_handler.safe_read_file(filename, sample_dir, 'rb')
                image_data_b64 = base64.b64encode(image_data).decode('utf-8')
                return jsonify({'imageData': image_data_b64})
            except (ValueError, FileNotFoundError):
                return jsonify({'error': 'Slide not found'}), 404
                
    except ValueError as e:
        app.logger.warning(f"Invalid slide request: {str(e)}")
        return jsonify({'error': 'Invalid slide number'}), 400
    except Exception as e:
        app.logger.error(f"Error serving slide {slide_number}: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

# Enhanced static file handler with MIME types, caching, and fallback
def serve_static_file(path):
    """
    Serve static files (CSS, JS, images) from the frontend build directory
    with enhanced MIME type handling, caching headers, and fallback support.
    
    Requirements addressed:
    - 6.1: Serve CSS and JavaScript files with correct base path prefixes
    - 6.3: Handle asset requests with proper MIME types
    - 6.4: Provide fallback handling for missing assets
    - 6.5: Cache static assets appropriately for performance
    """
    try:
        # Security: prevent directory traversal
        if '..' in path or path.startswith('/'):
            logger.warning(f"Directory traversal attempt blocked: {path}")
            return jsonify({'error': 'Invalid file path'}), 400
        
        # Normalize path
        normalized_path = os.path.normpath(path)
        if normalized_path != path:
            logger.warning(f"Path normalization changed: {path} -> {normalized_path}")
            return jsonify({'error': 'Invalid file path'}), 400
        
        # Determine file extension and MIME type
        file_extension = os.path.splitext(path)[1].lower()
        mime_types = {
            '.css': 'text/css',
            '.js': 'application/javascript',
            '.json': 'application/json',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.gif': 'image/gif',
            '.svg': 'image/svg+xml',
            '.ico': 'image/x-icon',
            '.woff': 'font/woff',
            '.woff2': 'font/woff2',
            '.ttf': 'font/ttf',
            '.eot': 'application/vnd.ms-fontobject',
            '.map': 'application/json',  # Source maps
            '.txt': 'text/plain',
            '.xml': 'application/xml'
        }
        
        # Get MIME type or default to octet-stream
        mime_type = mime_types.get(file_extension, 'application/octet-stream')
        
        # Try to serve from the frontend static directory
        # Note: The route already includes /static prefix, so we serve directly from static folder
        static_dir = os.path.join(app.static_folder, 'static')
        file_path = os.path.join(static_dir, path)
        
        # Check if file exists
        if not os.path.exists(file_path):
            logger.warning(f"Static file not found: {path}")
            
            # Fallback handling for missing assets
            fallback_response = _handle_missing_static_asset(path, file_extension)
            if fallback_response:
                return fallback_response
            
            return jsonify({
                'error': f'Static file not found: {path}',
                'suggestion': 'Run: npm run build to regenerate static assets'
            }), 404
        
        # Create response with proper MIME type
        response = send_from_directory(static_dir, path, mimetype=mime_type)
        
        # Add caching headers for performance optimization
        _add_caching_headers(response, file_extension)
        
        # Add additional security headers for static assets
        response.headers['X-Content-Type-Options'] = 'nosniff'
        
        logger.debug(f"Served static file: {path} (MIME: {mime_type})")
        return response
        
    except Exception as e:
        logger.error(f"Error serving static file {path}: {str(e)}")
        return jsonify({
            'error': f'Static file error: {path}',
            'message': 'Internal server error while serving static asset'
        }), 500


def _handle_missing_static_asset(path, file_extension):
    """
    Handle missing static assets with appropriate fallbacks.
    
    Returns a fallback response or None if no fallback is available.
    """
    # For CSS files, provide a minimal fallback
    if file_extension == '.css':
        fallback_css = "/* Fallback CSS - original file not found */\nbody { font-family: Arial, sans-serif; }"
        response = app.response_class(
            fallback_css,
            mimetype='text/css',
            status=200
        )
        response.headers['X-Fallback'] = 'true'
        logger.info(f"Served fallback CSS for missing file: {path}")
        return response
    
    # For JavaScript files, provide a minimal fallback
    if file_extension == '.js':
        fallback_js = "/* Fallback JS - original file not found */\nconsole.warn('Static asset not found: " + path + "');"
        response = app.response_class(
            fallback_js,
            mimetype='application/javascript',
            status=200
        )
        response.headers['X-Fallback'] = 'true'
        logger.info(f"Served fallback JS for missing file: {path}")
        return response
    
    # For source maps, return empty map
    if file_extension == '.map':
        fallback_map = '{"version":3,"sources":[],"names":[],"mappings":"","file":"fallback.map"}'
        response = app.response_class(
            fallback_map,
            mimetype='application/json',
            status=200
        )
        response.headers['X-Fallback'] = 'true'
        logger.info(f"Served fallback source map for missing file: {path}")
        return response
    
    # No fallback available
    return None


def _add_caching_headers(response, file_extension):
    """
    Add appropriate caching headers based on file type for performance optimization.
    """
    # Different caching strategies based on file type
    if file_extension in ['.css', '.js']:
        # CSS and JS files - cache for 1 hour in dev, 1 day in production
        max_age = 3600 if config.is_local_development else 86400
        response.headers['Cache-Control'] = f'public, max-age={max_age}'
        # Skip ETag generation to avoid "direct passthrough mode" error
        
    elif file_extension in ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico']:
        # Images - cache for 1 day in dev, 1 week in production
        max_age = 86400 if config.is_local_development else 604800
        response.headers['Cache-Control'] = f'public, max-age={max_age}'
        
    elif file_extension in ['.woff', '.woff2', '.ttf', '.eot']:
        # Fonts - cache for 1 week in dev, 1 month in production
        max_age = 604800 if config.is_local_development else 2592000
        response.headers['Cache-Control'] = f'public, max-age={max_age}'
        
    elif file_extension == '.map':
        # Source maps - no caching in production, short cache in dev
        if config.is_local_development:
            response.headers['Cache-Control'] = 'public, max-age=300'  # 5 minutes
        else:
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            
    else:
        # Other files - moderate caching
        max_age = 1800 if config.is_local_development else 3600  # 30 min / 1 hour
        response.headers['Cache-Control'] = f'public, max-age={max_age}'
    
    # Add Vary header for better caching behavior
    response.headers['Vary'] = 'Accept-Encoding'


# Enhanced logo file handler with MIME types, caching, and fallback
def serve_logo_file(path):
    """
    Serve logo files from the frontend logos directory
    with enhanced MIME type handling, caching headers, and fallback support.
    
    Requirements addressed:
    - 6.1: Serve logos and images with correct base path prefixes
    - 6.3: Handle asset requests with proper MIME types
    - 6.4: Provide fallback handling for missing assets
    - 6.5: Cache static assets appropriately for performance
    """
    try:
        # Security: prevent directory traversal
        if '..' in path or path.startswith('/'):
            logger.warning(f"Directory traversal attempt blocked in logos: {path}")
            return jsonify({'error': 'Invalid file path'}), 400
        
        # Normalize path
        normalized_path = os.path.normpath(path)
        if normalized_path != path:
            logger.warning(f"Logo path normalization changed: {path} -> {normalized_path}")
            return jsonify({'error': 'Invalid file path'}), 400
        
        # Determine file extension and MIME type
        file_extension = os.path.splitext(path)[1].lower()
        image_mime_types = {
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.gif': 'image/gif',
            '.svg': 'image/svg+xml',
            '.ico': 'image/x-icon',
            '.webp': 'image/webp'
        }
        
        # Validate that this is an image file
        if file_extension not in image_mime_types:
            logger.warning(f"Invalid logo file type requested: {path}")
            return jsonify({'error': 'Invalid logo file type'}), 400
        
        mime_type = image_mime_types[file_extension]
        
        # Try to serve from the frontend logos directory
        logos_dir = os.path.join(app.static_folder, 'logos')
        file_path = os.path.join(logos_dir, path)
        
        # Check if file exists
        if not os.path.exists(file_path):
            logger.warning(f"Logo file not found: {path}")
            
            # Fallback handling for missing logos
            fallback_response = _handle_missing_logo(path, file_extension)
            if fallback_response:
                return fallback_response
            
            return jsonify({
                'error': f'Logo file not found: {path}',
                'available_logos': _list_available_logos()
            }), 404
        
        # Create response with proper MIME type
        response = send_from_directory(logos_dir, path, mimetype=mime_type)
        
        # Add caching headers for logos (cache longer since they change less frequently)
        max_age = 86400 if config.is_local_development else 604800  # 1 day / 1 week
        response.headers['Cache-Control'] = f'public, max-age={max_age}'
        response.headers['Vary'] = 'Accept-Encoding'
        
        # Add security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        
        logger.debug(f"Served logo file: {path} (MIME: {mime_type})")
        return response
        
    except Exception as e:
        logger.error(f"Error serving logo file {path}: {str(e)}")
        return jsonify({
            'error': f'Logo file error: {path}',
            'message': 'Internal server error while serving logo'
        }), 500


def _handle_missing_logo(path, file_extension):
    """
    Handle missing logo files with appropriate fallbacks.
    
    Returns a fallback response or None if no fallback is available.
    """
    # For PNG logos, try to find a fallback or provide a placeholder
    if file_extension == '.png':
        # Check for common fallback logos
        logos_dir = os.path.join(app.static_folder, 'logos')
        fallback_options = ['default.png', 'placeholder.png', 'logo.png']
        
        for fallback in fallback_options:
            fallback_path = os.path.join(logos_dir, fallback)
            if os.path.exists(fallback_path):
                logger.info(f"Using fallback logo {fallback} for missing {path}")
                response = send_from_directory(logos_dir, fallback, mimetype='image/png')
                response.headers['X-Fallback'] = 'true'
                response.headers['X-Original-Request'] = path
                return response
    
    # No fallback available
    return None


def _list_available_logos():
    """List available logo files for error messages."""
    try:
        logos_dir = os.path.join(app.static_folder, 'logos')
        if os.path.exists(logos_dir):
            logo_files = [f for f in os.listdir(logos_dir) 
                         if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.svg'))]
            return logo_files[:10]  # Limit to first 10 for brevity
    except Exception:
        pass
    return []

# Register all routes with base path awareness
router.register_api_route('ask', methods=['POST'], handler=ask_question)
router.register_api_route('synthesize', methods=['POST'], handler=synthesize_speech)
router.register_api_route('health', methods=['GET'], handler=health_check)
router.register_api_route('preprocess', methods=['POST'], handler=preprocess_pdf)
router.register_api_route('preprocess/status', methods=['GET'], handler=get_preprocessing_status)
router.register_api_route('slides/<int:slide_number>', methods=['GET'], handler=get_slide_image)

# Register static file routes for CSS, JS, and other assets
router.register_static_route('<path:path>', handler=serve_static_file)

# Register logo routes (logos are served at base path level, not under /static)
if base_path_config.base_path:
    # For base path deployments: /mbr/logos/file.png
    app.add_url_rule(f"{base_path_config.base_path}/logos/<path:path>", 
                     endpoint='logos', view_func=serve_logo_file, methods=['GET'])
    logger.info(f"Registered logo route: {base_path_config.base_path}/logos/<path:path>")
else:
    # For root deployments: /logos/file.png
    app.add_url_rule('/logos/<path:path>', 
                     endpoint='logos', view_func=serve_logo_file, methods=['GET'])
    logger.info("Registered logo route: /logos/<path:path>")

# Register SPA routes
router.register_spa_routes()

# Print all registered routes for debugging
router.print_registered_routes()

# Helper functions

def resolve_follow_up_question(question, conversation_history):
    """Resolve follow-up questions using conversation context"""
    q_lower = question.lower().strip()
    
    # Check if this is a simple confirmation (yes, ok, do it, etc.)
    confirmation_phrases = [
        'yes', 'yeah', 'yep', 'sure', 'ok', 'okay', 'do it', 'go ahead', 
        'please', 'that one', 'sounds good', 'perfect', 'exactly'
    ]
    
    # Check for exact match or if question starts with confirmation
    is_confirmation = (
        q_lower in confirmation_phrases or 
        any(q_lower.startswith(phrase + ' ') or q_lower.startswith(phrase + ',') for phrase in confirmation_phrases) or
        any(q_lower == phrase for phrase in confirmation_phrases)
    )
    
    # Handle confirmations - extract suggested question from last assistant message
    if is_confirmation and conversation_history:
        last_assistant_msg = None
        last_audio_summary = None
        for msg in reversed(conversation_history):
            if msg.get('role') == 'assistant':
                last_assistant_msg = msg.get('content', '')
                last_audio_summary = msg.get('audioSummary', '')
                break
        
        if last_assistant_msg or last_audio_summary:
            # Try extracting from audio summary first (where follow-up suggestions are)
            suggested_question = None
            if last_audio_summary:
                suggested_question = extract_suggested_question(last_audio_summary)
            
            # Fallback to main content if not found in audio summary
            if not suggested_question and last_assistant_msg:
                suggested_question = extract_suggested_question(last_assistant_msg)
            
            if suggested_question:
                print(f"🔄 Confirmation detected - using suggested question:")
                print(f"   User said: {question}")
                print(f"   Extracted: {suggested_question}")
                return suggested_question
    
    # Skip resolution for complete questions
    if len(question.split()) > 8:
        return question
    
    # Common follow-up patterns
    follow_up_patterns = [
        'what about', 'how about', 'and for', 'what for', 'show me',
        'can you', 'could you', 'tell me about', 'what are', 'how are',
        'compare', 'versus', 'vs', 'difference', 'between'
    ]
    
    is_follow_up = any(pattern in q_lower for pattern in follow_up_patterns)
    
    if is_follow_up and conversation_history:
        # Get the last user question for context
        last_user_question = None
        for msg in reversed(conversation_history):
            if msg.get('role') == 'user':
                last_user_question = msg.get('content', '')
                break
        
        if last_user_question:
            # Extract context from previous question
            context = extract_query_context(last_user_question)
            
            if context:
                # Build resolved question
                resolved = f"{question}"
                
                # Add product context if missing
                if context.get('product') and not any(p.lower() in q_lower for p in ['pluvicto', 'lutathera', 'xofigo', 'novacure']):
                    resolved = f"{question} for {context['product']}"
                
                # Add time context if missing
                if context.get('time_period') and not any(t in q_lower for t in ['2020', '2021', '2022', '2023', '2024', '2025']):
                    resolved = f"{resolved} in {context['time_period']}"
                
                return resolved
    
    return question

def extract_suggested_question(response_text):
    """Extract suggested follow-up questions from assistant response"""
    import re
    
    # Common patterns for suggested questions in responses
    patterns = [
        # Direct comparison suggestions
        r'(?:do you want to|would you like to|want to) compare (?:it|this) (?:vs|versus|with|to|against) (.+?)\?',
        r'compare (?:it|this) (?:vs|versus|with|to|against) (.+?)\?',
        
        # General suggestions
        r'Would you like to see (.+?)\?',
        r'Would you like to explore (.+?)\?',
        r'Would you like to (.+?)\?',
        r'Do you want to (.+?)\?',
        r'Want to (.+?)\?',
        r'Can I show you (.+?)\?',
        r'I can show you (.+?)(?:\?|\.)',
        r'How about (.+?)\?',
        r'What about (.+?)\?',
        r'Try asking: "(.+?)"',
        r'You could ask: "(.+?)"',
    ]
    
    # Try each pattern
    for pattern in patterns:
        matches = re.findall(pattern, response_text, re.IGNORECASE)
        if matches:
            # Return the first suggestion found
            suggestion = matches[0].strip()
            
            # Clean up the suggestion
            suggestion = suggestion.replace('**', '').replace('*', '').replace('?', '')
            
            # Handle comparison suggestions specially
            if 'compare' in pattern.lower():
                # Extract the comparison target (e.g., "2024 Jan", "January 2024")
                comparison_target = suggestion
                
                # Try to extract the original subject from the response
                # Look for patterns like "January 2025", "Jan 2025", etc.
                current_period_match = re.search(r'(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})', response_text, re.IGNORECASE)
                if not current_period_match:
                    current_period_match = re.search(r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4})', response_text, re.IGNORECASE)
                
                if current_period_match:
                    current_period = f"{current_period_match.group(1)} {current_period_match.group(2)}"
                    return f"compare {current_period} vs {comparison_target}"
                else:
                    return f"compare vs {comparison_target}"
            
            # If it's a fragment, make it a complete question
            if not suggestion.lower().startswith(('show', 'what', 'how', 'compare', 'analyze')):
                # Add "show me" prefix if it's just a description
                suggestion = f"show me {suggestion}"
            
            return suggestion
    
    # Look for bullet point suggestions (common in our responses)
    lines = response_text.split('\n')
    for line in lines:
        line = line.strip()
        # Look for lines that start with bullet points and contain question-like content
        if line.startswith(('-', '•', '*')) and any(word in line.lower() for word in ['breakdown', 'analysis', 'comparison', 'trend', 'vs', 'by', 'compare']):
            # Extract the suggestion
            suggestion = line.lstrip('-•* ').strip()
            suggestion = suggestion.replace('**', '').replace('*', '')
            
            # Make it a question if it isn't already
            if not suggestion.lower().startswith(('show', 'what', 'how', 'compare', 'analyze')):
                suggestion = f"show me {suggestion}"
            
            return suggestion
    
    return None

def extract_query_context(response_text):
    """Extract query context from assistant response"""
    context = {
        'product': None,
        'time_period': None,
        'metric_type': None
    }
    
    text_lower = response_text.lower()
    
    # Extract product
    products = ['pluvicto', 'lutathera', 'xofigo', 'novacure']
    for product in products:
        if product in text_lower:
            context['product'] = product.title()
            break
    
    # Extract time period
    year_match = re.search(r'\b(20\d{2})\b', response_text)
    if year_match:
        context['time_period'] = year_match.group(1)
    
    # Extract metric type
    if 'sales' in text_lower or 'revenue' in text_lower:
        context['metric_type'] = 'sales'
    elif 'dose' in text_lower or 'prescription' in text_lower:
        context['metric_type'] = 'doses'
    elif 'market share' in text_lower or 'share' in text_lower:
        context['metric_type'] = 'market_share'
    
    return context

# AWS clients with retry configuration
boto_config = BotoConfig(
    retries={
        'max_attempts': 3,
        'mode': 'adaptive'
    },
    max_pool_connections=10,
    region_name=config.aws_region
)

def invoke_bedrock_with_retry(request_body, max_retries=3, initial_delay=2):
    """Invoke Bedrock with exponential backoff retry logic"""
    for attempt in range(max_retries):
        try:
            response = bedrock_runtime.invoke_model(
                modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
                body=json.dumps(request_body)
            )
            return json.loads(response['body'].read())
        except Exception as e:
            if 'ServiceUnavailableException' in str(e) or 'ThrottlingException' in str(e):
                if attempt < max_retries - 1:
                    delay = initial_delay * (2 ** attempt)
                    print(f"⏳ Rate limited, retrying in {delay}s... (attempt {attempt + 1}/{max_retries})")
                    time.sleep(delay)
                else:
                    raise
            else:
                raise

# Preprocessed slides cache
preprocessed_slides_cache = None

# Global preprocessing status
preprocessing_status = {
    'stage': 'idle',
    'progress': 0,
    'message': 'Ready for PDF upload',
    'currentSlide': 0,
    'totalSlides': 0
}

def load_preprocessed_slides():
    """Load preprocessed slide data from JSON file with security protection"""
    from backend_api.secure_file_handler import SecureFileHandler
    global preprocessed_slides_cache
    
    if preprocessed_slides_cache is not None:
        return preprocessed_slides_cache
    
    # Define allowed directories for preprocessed data
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    allowed_dirs = [
        os.path.join(project_root, 'uploads'),
        os.path.join(project_root, 'data_sample')
    ]
    
    file_handler = SecureFileHandler(allowed_dirs)
    filename = 'preprocessed_slides.json'
    
    # Try each allowed directory
    for base_dir in allowed_dirs:
        try:
            file_content = file_handler.safe_read_file(filename, base_dir, 'r')
            preprocessed_slides_cache = json.loads(file_content)
            print(f"✅ Loaded {len(preprocessed_slides_cache)} preprocessed slides from {base_dir}/{filename}")
            return preprocessed_slides_cache
        except (ValueError, FileNotFoundError, json.JSONDecodeError) as e:
            continue
        except Exception as e:
            print(f"⚠️ Error loading preprocessed slides from {base_dir}: {e}")
            continue
    
    print(f"⚠️ No preprocessed slides found in allowed directories")
    return None

def get_slide_context(slide_number):
    """Get preprocessed context for a specific slide"""
    slides_data = load_preprocessed_slides()
    if slides_data:
        for slide in slides_data:
            if slide.get('slide_number') == slide_number:
                return slide
    return None

if __name__ == '__main__':
    logger.info(f"Starting MBR Dashboard Backend API")
    logger.info(f"Environment: {config.environment}")
    logger.info(f"Debug Mode: {config.debug}")
    logger.info(f"Port: {config.port}")
    
    app.run(
        host=config.host,
        port=config.port,
        debug=config.debug and config.hot_reload
    )

if __name__ == '__main__':
    logger.info(f"Starting MBR Dashboard Backend API with Base Path Support")
    logger.info(f"Environment: {config.environment}")
    logger.info(f"Debug Mode: {config.debug}")
    logger.info(f"Base Path: {base_path_config.base_path or '(root)'}")
    logger.info(f"API Prefix: {base_path_config.api_prefix}")
    logger.info(f"Static Prefix: {base_path_config.static_prefix}")
    logger.info(f"Port: {config.port}")
    logger.info(f"Host: {config.host}")
    
    app.run(
        host=config.host,
        port=config.port,
        debug=config.debug and config.hot_reload
    )