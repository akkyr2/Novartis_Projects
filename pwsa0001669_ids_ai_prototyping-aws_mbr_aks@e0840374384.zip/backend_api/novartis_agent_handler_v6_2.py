#!/usr/bin/env python3
"""
Novartis Agent Handler V6.2 - Chart and Time Period Fixes

This handler implements intelligent prompt routing:
- General Prompt: For Sales, Market, Doses, Calls questions
- Enhanced ROME Prompt: For ROME questions (17 sections of detailed guidance)
- Classifier: Routes questions to the correct prompt based on keywords

V6.2 Changes (from V6.1):
- Fixed chart values bug (pre-filter by metric type)
- Fixed time period inconsistency (explicit quarter mapping)
- Added 45-day rule to general prompt (Q4 2025 as current quarter)
- Fixed f-string formatting errors

V6.1 Changes:
- Smart chart generation (data-driven, not keyword-driven)
- Intelligent chart type selection (pie/bar/line based on data structure)
- Charts from aggregated data (helper tool results)

V6 Changes:
- Classifier-based routing (no prompt merging)
- Separate prompts for optimal performance
- All V6 tools (CALLS GSI5 + ROME 4 tables + helpers)
- Uses invoke_model API (Messages API) with Sonnet 4.5
- Production-ready for app.py integration
"""

import boto3
import json
from datetime import datetime, timedelta
from backend_api.novartis_queries_v6_2 import (
    query_sales_finance_table,
    query_market_share_table,
    query_doses_table,
    query_calls_table,
    query_rome_table,
    query_rome_new_patient_starts_aggregated,
    query_rome_new_patient_orders_aggregated,
    query_rome_all_orders_aggregated,
    query_rome_site_status_aggregated,
    deduplicate_and_sum,
    simple_sum,
    aggregate_by_dimensions  # NEW: Universal aggregation for Sales/Market/Doses
)
from backend_api.novartis_prompts_v6_2 import get_general_system_prompt, get_rome_system_prompt

# Initialize Bedrock client
bedrock_runtime = boto3.client('bedrock-runtime', region_name='us-east-1')

# ============================================================================
# SMART CHART GENERATION HELPERS (V6.1 Enhancement)
# ============================================================================

def should_generate_chart(data, tool_name, question):
    """
    Decide if chart should be generated based on:
    1. Explicit user request (keywords)
    2. Data structure (multiple points, time series, comparisons)
    3. Question intent (trend, comparison, ranking, breakdown)
    
    Returns:
        tuple: (should_generate: bool, reason: str)
    """
    question_lower = question.lower()
    
    # 1. EXPLICIT REQUEST - Always honor
    explicit_keywords = ['chart', 'graph', 'plot', 'visualize', 'pie', 'bar', 'line']
    if any(word in question_lower for word in explicit_keywords):
        return True, 'explicit_request'
    
    # 2. DATA STRUCTURE - Check if data is chart-worthy
    if not data or len(data) < 2:
        return False, 'insufficient_data'
    
    # 3. QUESTION INTENT - Detect patterns that benefit from visualization
    
    # Time series indicators
    time_keywords = ['trend', 'over time', 'monthly', 'quarterly', 'by month', 'by quarter', 
                     'ytd', 'year over year', 'yoy', 'mom', 'qoq']
    if any(kw in question_lower for kw in time_keywords):
        return True, 'time_series'
    
    # Comparison indicators
    comparison_keywords = ['compare', 'vs', 'versus', 'compared to', 'difference between',
                          'actual vs budget', 'budget vs actual']
    if any(kw in question_lower for kw in comparison_keywords):
        return True, 'comparison'
    
    # Breakdown/distribution indicators
    breakdown_keywords = ['breakdown', 'distribution', 'mix', 'by product', 'by brand',
                         'each product', 'per product', 'split', 'show me']
    if any(kw in question_lower for kw in breakdown_keywords):
        return True, 'breakdown'
    
    # Ranking indicators
    ranking_keywords = ['top', 'bottom', 'highest', 'lowest', 'best', 'worst',
                       'leading', 'ranking']
    if any(kw in question_lower for kw in ranking_keywords):
        return True, 'ranking'
    
    # Geographic indicators (for calls/rome)
    geo_keywords = ['by region', 'by territory', 'by area', 'by geography',
                   'regional', 'territorial']
    if any(kw in question_lower for kw in geo_keywords):
        return True, 'geographic'
    
    # 4. DATA CHARACTERISTICS - Auto-generate for rich datasets (5+ points)
    if len(data) >= 5:
        # Check if data has time dimension
        time_fields = ['month', 'quarter', 'year', 'date', 'dim_date', 'year_quarter']
        has_time = any(field in data[0] for field in time_fields if isinstance(data[0], dict))
        if has_time:
            unique_times = len(set(str(r.get('month', '') or r.get('quarter', '') or r.get('year_quarter', '')) 
                                 for r in data))
            if unique_times >= 3:
                return True, 'auto_time_series'
        
        # Check if data has multiple categories
        category_fields = ['brand', 'product', 'dim_geo_name', 'site_id', 'territory']
        has_categories = any(field in data[0] for field in category_fields if isinstance(data[0], dict))
        if has_categories:
            return True, 'auto_categorical'
    
    # Default: No chart
    return False, 'no_pattern_detected'


def determine_chart_type(data, question, tool_name, chart_reason):
    """
    Intelligently determine chart type based on:
    1. Explicit user request (highest priority)
    2. Data structure (time series, categories, etc.)
    3. Question intent (from chart_reason)
    
    Returns:
        str: 'pie', 'bar', or 'line'
    """
    question_lower = question.lower()
    
    # 1. EXPLICIT REQUEST - Always honor
    if 'pie chart' in question_lower or 'pie graph' in question_lower:
        return 'pie'
    if 'bar chart' in question_lower or 'bar graph' in question_lower:
        return 'bar'
    if 'line chart' in question_lower or 'line graph' in question_lower:
        return 'line'
    
    # 2. ANALYZE DATA STRUCTURE
    if not data or len(data) == 0:
        return 'bar'  # Default
    
    # Extract data characteristics
    first_record = data[0] if isinstance(data, list) else {}
    
    # Time fields
    time_fields = ['month', 'quarter', 'year', 'date', 'dim_date', 'year_quarter']
    has_time = any(field in first_record for field in time_fields)
    
    # Category fields
    category_fields = ['brand', 'product', 'forecast_type', 'dim_geo_name', 'site_id', 
                      'territory', 'site_type', 'ecosystem']
    has_categories = any(field in first_record for field in category_fields)
    
    # Count unique values
    if has_time:
        unique_times = len(set(str(r.get('month', '') or r.get('quarter', '') or 
                                  r.get('year_quarter', '')) for r in data))
    else:
        unique_times = 0
    
    if has_categories:
        # Find the primary category field
        primary_category = None
        for field in category_fields:
            if field in first_record:
                primary_category = field
                break
        unique_categories = len(set(str(r.get(primary_category, '')) for r in data)) if primary_category else 0
    else:
        unique_categories = 0
    
    # Check for multiple series (e.g., ACTUAL vs BUDGET)
    has_multiple_series = False
    if 'forecast_type' in first_record:
        unique_forecast_types = len(set(r.get('forecast_type', '') for r in data))
        has_multiple_series = unique_forecast_types > 1
    elif 'brand' in first_record or 'product' in first_record:
        brand_field = 'brand' if 'brand' in first_record else 'product'
        unique_brands = len(set(r.get(brand_field, '') for r in data))
        has_multiple_series = unique_brands > 1 and has_time
    
    # 3. DECISION LOGIC
    
    # PIE CHART: Single point in time + multiple categories
    if unique_times <= 1 and unique_categories >= 2:
        return 'pie'
    
    # LINE CHART: Time series (3+ time points)
    if unique_times >= 3:
        return 'line'  # Single or multi-series line
    
    # BAR CHART: Short time series (2 points) or comparisons
    if unique_times >= 2 and unique_times < 3:
        return 'bar'
    
    if unique_categories >= 2 and not has_time:
        return 'bar'
    
    # RANKING: Top/bottom questions
    if chart_reason == 'ranking':
        return 'bar'
    
    # GEOGRAPHIC: Regional/territorial comparisons
    if chart_reason == 'geographic':
        return 'bar'
    
    # DEFAULT: Bar chart (safest choice)
    return 'bar'


# ============================================================================
# CLASSIFIER FUNCTION
# ============================================================================

def classify_question(question):
    """
    Classify question as 'rome' or 'general' based on keywords
    
    Uses composite keyword approach to distinguish between CALLS and ROME
    when both use geography terms (territory, region, area)
    
    Returns:
        str: 'rome' or 'general'
    """
    question_lower = question.lower()
    
    # Strong ROME indicators (unique to ROME)
    strong_rome_keywords = [
        'site', 'sites', 'account', 'accounts', 'onboarded', 'dormant',
        'academic', 'community', 'urology', 'ecosystem',
        'new patient starts', 'new patient orders', 'new patient',
        'qtd shipped dose volume', 'shipped dose volume',
        'top 10 sites', 'top 10 accounts', 'site type',
        'treatment volume',  # Added for "Month with highest treatment volume"
        'new patient volume',  # Added for "Which month had the highest new patient volume?"
        'new patient order volume'  # Added for "Which month had the highest new patient order volume?"
    ]
    
    # Strong CALLS indicators (unique to CALLS)
    strong_calls_keywords = [
        'cpd', 'hcp reach', 'hcp reached', 'call frequency', 'calls per day',
        'calls per', 'attainment', 'target calls', 'call coverage'
    ]
    
    # Strong SALES indicators
    strong_sales_keywords = [
        'revenue', 'net sales', 'gross sales', 'forecast', 'actual vs'
    ]
    
    # Strong DOSES indicators (must be specific to avoid false positives)
    strong_doses_keywords = [
        'shipped doses ytd', 'doses shipped'
    ]
    
    # Strong MARKET indicators
    strong_market_keywords = [
        'market share', 'competitor', 'nbrx', 'trx'
    ]
    
    # Geography terms (shared between ROME and CALLS)
    geography_keywords = ['territory', 'territories', 'area', 'areas', 'region', 'regions']
    
    # Check for strong ROME indicators first
    for keyword in strong_rome_keywords:
        if keyword in question_lower:
            return 'rome'
    
    # Check for strong CALLS indicators
    for keyword in strong_calls_keywords:
        if keyword in question_lower:
            return 'general'
    
    # Check for strong SALES indicators
    for keyword in strong_sales_keywords:
        if keyword in question_lower:
            return 'general'
    
    # Check for strong DOSES indicators
    for keyword in strong_doses_keywords:
        if keyword in question_lower:
            return 'general'
    
    # Check for strong MARKET indicators
    for keyword in strong_market_keywords:
        if keyword in question_lower:
            return 'general'
    
    # Special case: "volume" + "territory/nation" without CALLS keywords = ROME
    # (e.g., "Which territories are performing below nation in volume growth?")
    if 'volume' in question_lower and any(geo in question_lower for geo in ['territory', 'nation', 'territories']):
        # But not if it's clearly CALLS-related
        if not any(kw in question_lower for kw in ['cpd', 'hcp', 'call', 'attainment']):
            return 'rome'
    
    # Special case: "uptake" + "doses" = ROME (not DOSES table)
    # (e.g., "What is the uptake after approval in total doses?")
    if 'uptake' in question_lower and 'dose' in question_lower:
        return 'rome'
    
    # Special case: "uptake" + "total doses" = ROME
    # (e.g., "What is the uptake after March 28, 2025 (pre-taxane mCRPC approval) in total doses?")
    if 'uptake' in question_lower and 'total doses' in question_lower:
        return 'rome'
    
    # Special case: "brands that drove" = ROME (site/account level analysis)
    # (e.g., "Brands that drove the volume")
    if 'brands' in question_lower and 'drove' in question_lower:
        return 'rome'
    
    # If question has geography terms but no strong indicators, default to general (CALLS)
    # This is safer because CALLS questions are more common with geography terms
    for keyword in geography_keywords:
        if keyword in question_lower:
            return 'general'
    
    # Default to general (safer for ambiguous cases)
    return 'general'


# ============================================================================
# TOOL DEFINITIONS
# ============================================================================

# General tools (for Sales, Market, Doses, Calls)
GENERAL_TOOLS = [
    {
        "name": "query_sales_finance_table",
        "description": """Query SALES_FINANCE_BPC_corrected table for ALL sales/revenue questions.
        
USE THIS FOR:
- Revenue, net sales, gross sales, revenue deductions
- YTD, quarterly, monthly performance
- Actual vs Budget vs OC comparisons
- Year-over-year, month-over-month analysis
- Single product or portfolio-wide

COLUMN GUIDE:
- NET_SALES: Net revenue after deductions - USE THIS for "net sales" or "revenue" questions
- GROSS_SALES: Gross revenue before deductions - USE THIS for "gross sales" or "gross revenue" questions
- REVENUE_DEDUCTIONS: Discounts, rebates, returns - USE THIS for "deductions" questions

IMPORTANT: For comparisons (actual vs budget), request BOTH forecast types: forecast_types=["ACTUALS", "BUDGET"]
IMPORTANT: For broad date ranges, use ONE call (e.g., start_date="2024-01-01", end_date="2025-03-31" for Q1 2024 vs Q1 2025)
IMPORTANT: Use forecast_types=["ACTUALS"] for actual data, ["BUDGET"] for budget, ["OC"] for operating case

RETURNS: All matching records with columns: brand, forecast_type, date, year, month, net_sales, gross_sales, revenue_deductions, year_rel_index, month_rel_index, cycle_rel_index

YOU analyze and aggregate the data - don't ask for pre-aggregated results.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query",
                    "properties": {
                        "products": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Product names (e.g., ['PLUVICTO'], ['LUTATHERA'])"
                        },
                        "forecast_types": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Forecast types (e.g., ['ACTUAL'], ['BUDGET'], ['ACTUAL', 'BUDGET'])"
                        },
                        "start_date": {
                            "type": "string",
                            "description": "Start date YYYY-MM-DD"
                        },
                        "end_date": {
                            "type": "string",
                            "description": "End date YYYY-MM-DD"
                        },
                        "year": {
                            "type": "integer",
                            "description": "Specific year (2020-2028)"
                        }
                    }
                }
            }
        }
    },
    {
        "name": "query_market_share_table",
        "description": """Query FCT_MARKET_PLU_corrected table for ALL market share and competitor questions.

USE THIS FOR:
- Market share analysis (use TRX_SHARE_R3M for total prescriptions share)
- New patient market share (use NBRX_SHARE_R3M for new prescriptions share)
- Competitor analysis and rankings
- Market volumes (TRX_R3M for total volume, NBRX_R3M for new patient volume)
- All brands including competitors

COLUMN GUIDE:
- TRX_SHARE_R3M: Total prescription market share % (rolling 3-month) - USE THIS for general market share questions
- NBRX_SHARE_R3M: New prescription market share % (rolling 3-month) - USE THIS for new patient share questions
- TRX_R3M: Total prescription volume (rolling 3-month)
- NBRX_R3M: New prescription volume (rolling 3-month)

DEFAULT: Filter to PLUVICTO UNLESS competitors or other products are explicitly mentioned.

IMPORTANT: For comparisons, use ONE call with broad date range covering all periods needed

RETURNS: All matching records with columns: brand, dim_date, year, month, TRX_R3M, TRX_SHARE_R3M, NBRX_R3M, NBRX_SHARE_R3M, year_rel_index, month_rel_index, cycle_rel_index, year_quarter

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query",
                    "properties": {
                        "brands": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Brand names (e.g., ['PLUVICTO'], ['LUTATHERA'])"
                        },
                        "start_date": {
                            "type": "string",
                            "description": "Start date YYYY-MM-DD"
                        },
                        "end_date": {
                            "type": "string",
                            "description": "End date YYYY-MM-DD"
                        },
                        "forecast_type": {
                            "type": "string",
                            "description": "ACTUAL (default) or BUDGET"
                        }
                    }
                }
            }
        }
    },
    {
        "name": "query_doses_table",
        "description": """Query FCT_DOSES_PLU_corrected table for ALL national-level dose questions.

USE THIS FOR:
- Shipped doses, injected doses, new patient (NBRX) metrics
- YTD, quarterly, monthly dose performance
- Actual vs Budget vs OC comparisons
- Year-over-year, month-over-month dose analysis

METRIC GUIDE:
- TRX_SHIPPED: Total doses shipped to sites - USE THIS for "shipped doses" questions
- TRX_INJECTED: Total doses injected/administered - USE THIS for "injected doses" or "administered doses" questions
- NBRX: New patient prescriptions - USE THIS for "new patient" or "new prescriptions" questions

DEFAULT: Filter to PLUVICTO UNLESS another product is explicitly mentioned.

IMPORTANT: For comparisons, use ONE call with broad date range covering all periods needed
IMPORTANT: Use forecast_types=["ACTUALS"] for actual data, ["BUDGET"] for budget, ["OC"] for operating case

RETURNS: All matching records with columns: brand, metric (TRX_SHIPPED/TRX_INJECTED/NBRX), forecast_type, date, year, month, value, year_rel_index, month_rel_index, quarter_rel_index

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query",
                    "properties": {
                        "products": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Product names (e.g., ['PLUVICTO'], ['LUTATHERA'])"
                        },
                        "metrics": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Metrics (e.g., ['TRX_SHIPPED'], ['TRX_INJECTED'], ['NBRX'])"
                        },
                        "forecast_types": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Forecast types (e.g., ['ACTUAL'], ['BUDGET'], ['ACTUAL', 'BUDGET'])"
                        },
                        "start_date": {
                            "type": "string",
                            "description": "Start date YYYY-MM-DD"
                        },
                        "end_date": {
                            "type": "string",
                            "description": "End date YYYY-MM-DD"
                        },
                        "year": {
                            "type": "integer",
                            "description": "Specific year"
                        }
                    }
                }
            }
        }
    },
    {
        "name": "query_calls_table",
        "description": """Query FCT_CALLS table for ALL field activity and sales rep performance questions.

USE THIS FOR:
- Field activity analysis
- Sales rep performance tracking
- HCP reach and engagement metrics
- Call frequency and attainment analysis
- Team performance by geography (Nation, Region, Area, Territory)
- Demand generation insights

AVAILABLE GEOGRAPHY: Nation, Region, Area, Territory
AVAILABLE TIERS: T1, T2, T3, NT, All Tiers Except NT, Top 2 Tiers, ALL
AVAILABLE METRICS: HCP_REACH, CPD, CALL_FREQUENCY_ATTAINMENT, TOTAL_CALLS

TIME PERIOD MAPPING (CRITICAL):

CURRENT DATE: January 2026 (22 days into Q1 2026)
CURRENT QUARTER FOR ANALYSIS: Q4 2025 (due to 45-day data lag rule)

For RELATIVE time periods:
- "current cycle" or "quarter to date" or "QTD" → time_period='QTD', cycle_rel_index=1000 (Q4 2025)
- "last 4 weeks" or "current 4 weeks" → time_period='C4W', cycle_rel_index=1000
- "last 13 weeks" → time_period='C13W', cycle_rel_index=1000
- "this week" or "weekly" → time_period='WEEK', cycle_rel_index=1000
- "previous quarter" or "last quarter" → time_period='PQ', cycle_rel_index=999 (Q3 2025)
- "2 quarters ago" → time_period='P2Q', cycle_rel_index=998 (Q2 2025)

For SPECIFIC quarter references (e.g., "Q2 2025", "Q4 2025"):
Calculate quarters back from Q4 2025 (current quarter for analysis):
- Q4 2025 = current quarter → cycle_rel_index=1000
- Q3 2025 = 1 quarter ago → cycle_rel_index=999
- Q2 2025 = 2 quarters ago → cycle_rel_index=998
- Q1 2025 = 3 quarters ago → cycle_rel_index=997

CRITICAL EXAMPLES:
- "Q2 2025" → year=2025, time_period='P2Q', cycle_rel_index=998
- "Q4 2025" or "current quarter" → year=2025, time_period='QTD', cycle_rel_index=1000
- "last quarter" (Q3 2025) → year=2025, time_period='PQ', cycle_rel_index=999

DEFAULT VALUES:
- If time period not specified: time_period='QTD', cycle_rel_index=1000 (Q4 2025)
- If geography not specified: geo_level='Nation'
- If product not specified: products=['Pluvicto']
- If year not specified: year=2025

IMPORTANT: Always include BOTH time_period AND cycle_rel_index for accurate filtering!
IMPORTANT: Always include tiers parameter (e.g., ['ALL'], ['Top 2 Tiers'], ['T1']) for GSI5 optimization!

RETURNS: All matching records with columns: product, dim_tier, dim_geo_level, dim_geo_name, dim_time_period, dim_metric_type, CPD, cpd_goal, cpd_attainment, target_hcp_reach, total_target, percent_reached, call_frequency_actual, call_frequency_attainment, actual_calls, planned_calls, cycle_rel_index, period_end_date, year_quarter

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Query filters - include products, year, tiers, geo_level, metric_type, time_period, cycle_rel_index",
                    "properties": {
                        "products": {
                            "type": "array",
                            "items": {"type": "string", "enum": ["PLUVICTO", "LUTATHERA", "XOFIGO", "NOVACURE"]},
                            "description": "Product names (default: ['Pluvicto'])"
                        },
                        "year": {
                            "type": "integer",
                            "description": "Specific year (default: 2025, uses GSI5 for fast queries)"
                        },
                        "tiers": {
                            "type": "array",
                            "items": {"type": "string", "enum": ["T1", "T2", "T3", "NT", "All Tiers Except NT", "Top 2 Tiers", "ALL"]},
                            "description": "Tier values (e.g., ['Top 2 Tiers'], ['ALL']) - REQUIRED for GSI5 optimization"
                        },
                        "geo_level": {
                            "type": "string",
                            "enum": ["Nation", "Region", "Area", "Territory"],
                            "description": "Geographic level (default: 'Nation')"
                        },
                        "geo_name": {
                            "type": "string",
                            "description": "Specific geography name (e.g., 'NORTHEAST', 'CENTRAL')"
                        },
                        "metric_type": {
                            "type": "string",
                            "enum": ["HCP_REACH", "CPD", "CALL_FREQUENCY_ATTAINMENT", "TOTAL_CALLS"],
                            "description": "Metric type - HCP_REACH for reach metrics, CPD for calls per day, CALL_FREQUENCY_ATTAINMENT for frequency, TOTAL_CALLS for call counts"
                        },
                        "time_period": {
                            "type": "string",
                            "enum": ["QTD", "C4W", "C13W", "WEEK", "CUM_WEEK", "ROLLING_4WEEK", "P4W", "PQ", "PQC4W", "PQC13W", "PQWEEK", "P2Q", "P2QC4W", "P2QC13W", "P2QWEEK"],
                            "description": "Time period type (default: 'QTD'). QTD=quarter to date, C4W=last 4 weeks, PQ=previous quarter, P2Q=2 quarters ago"
                        },
                        "cycle_rel_index": {
                            "type": "integer",
                            "enum": [1000, 999, 998],
                            "description": "Relative cycle index (default: 1000). 1000=current cycle, 999=previous cycle, 998=2 cycles ago"
                        }
                    }
                }
            }
        }
    },
    {
        "name": "query_rome_table",
        "description": "Query FCT_ROME_PLU table for site activity and patient data (V5 with 6 GSIs)",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query (product, site_id, start_date, end_date, etc.)"
                }
            }
        }
    }
]

# ROME-specific tools (4 aggregated tables + 2 helpers)
ROME_TOOLS = [
    {
        "name": "query_rome_new_patient_starts_aggregated",
        "description": "Query Rome_NewPatientStarts_Monthly_v6 for new patient starts (delivered doses only)",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query (year, quarter, month, site_type, territory, area, ecosystem, etc.)"
                }
            }
        }
    },
    {
        "name": "query_rome_new_patient_orders_aggregated",
        "description": "Query Rome_NewPatientOrders_Monthly_v6 for new patient orders (all statuses)",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query (year, quarter, month, site_type, territory, area, ecosystem, etc.)"
                }
            }
        }
    },
    {
        "name": "query_rome_all_orders_aggregated",
        "description": "Query Rome_AllOrders_Monthly_v6 for all orders by site and month",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query (year, quarter, month, site_id, territory, etc.)"
                }
            }
        }
    },
    {
        "name": "query_rome_site_status_aggregated",
        "description": "Query Rome_SiteStatus_Quarterly_v6 for site status (onboarded, dormant, etc.)",
        "input_schema": {
            "type": "object",
            "properties": {
                "filters": {
                    "type": "object",
                    "description": "Filters for the query (year, quarter, site_id, account_status, active_dormant, etc.)"
                }
            }
        }
    },
    {
        "name": "deduplicate_and_aggregate",
        "description": "Python helper: Deduplicate orders across dimensions and aggregate by dimension (for tables with order_list field)",
        "input_schema": {
            "type": "object",
            "properties": {
                "data_id": {
                    "type": "string",
                    "description": "Data ID from previous query result"
                },
                "group_by": {
                    "type": "string",
                    "description": "Field to group by (site_type, territory, month, etc.)"
                }
            },
            "required": ["data_id", "group_by"]
        }
    },
    {
        "name": "simple_aggregate",
        "description": "Python helper: Simple sum of pre-computed counts (for tables with count fields)",
        "input_schema": {
            "type": "object",
            "properties": {
                "data_id": {
                    "type": "string",
                    "description": "Data ID from previous query result"
                },
                "group_by": {
                    "type": "string",
                    "description": "Field to group by (site_id, territory, month, etc.)"
                },
                "count_field": {
                    "type": "string",
                    "description": "Count field to sum (unique_order_count, delivered_order_count, etc.)"
                }
            },
            "required": ["data_id", "group_by"]
        }
    },
    {
        "name": "aggregate_by_dimensions",
        "description": """Universal aggregation for Sales/Market/Doses data. 

CRITICAL: Call this immediately after querying Sales, Market, or Doses tables.

Parameters:
- data_id: Data ID from query (e.g., 'data_1')
- group_by: Array of fields to group by (e.g., ["year"], ["forecast_type"], ["product", "year"])
- sum_fields: Array of fields to sum (default: ["net_sales"])
- filters: Optional filters (e.g., {{"product": "PLUVICTO"}})

Common patterns:
- YTD by forecast: group_by=["forecast_type"]
- By product: group_by=["product"]
- By month: group_by=["month"]
- Total only: group_by=[]
- Multi-dimension: group_by=["year", "forecast_type"]""",
        "input_schema": {
            "type": "object",
            "properties": {
                "data_id": {
                    "type": "string",
                    "description": "Data ID from previous query result"
                },
                "group_by": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Fields to group by. Use [] for total only"
                },
                "sum_fields": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Numeric fields to sum. Default: ['net_sales']"
                },
                "filters": {
                    "type": "object",
                    "description": "Optional filters before aggregation"
                }
            },
            "required": ["data_id"]
        }
    }
]

# Combined tools (all 12 tools now - added aggregate_by_dimensions)
COMBINED_TOOLS = GENERAL_TOOLS + ROME_TOOLS


# ============================================================================
# CHART GENERATION FUNCTION
# ============================================================================

def generate_chart_data(tool_name, tool_input, tool_result, question):
    """Generate chart data from tool results for frontend visualization"""
    if not tool_result.get('success') or not tool_result.get('data'):
        print("   ⚠️ Chart generation skipped: No successful data")
        return None
    
    try:
        data = tool_result['data']
        
        print(f"   🔍 Chart detection for question: '{question}'")
        
        # NEW: Smart chart detection (data-driven)
        should_chart, reason = should_generate_chart(data, tool_name, question)
        
        if not should_chart:
            print(f"   ⚠️ Chart generation skipped: {reason}")
            return None
        
        print(f"   📊 Chart generation triggered: {reason}")
        
        # NEW: Intelligent chart type selection
        chart_type = determine_chart_type(data, question, tool_name, reason)
        print(f"   📊 Chart type selected: {chart_type}")
        
        # Route to appropriate generator (now passing chart_type)
        if tool_name == "query_sales_finance_table":
            return _generate_sales_chart(data, tool_input, question, chart_type)
        
        elif tool_name == "query_market_share_table":
            return _generate_market_chart(data, tool_input, question, chart_type)
        
        elif tool_name == "query_doses_table":
            return _generate_doses_chart(data, tool_input, question, chart_type)
        
        elif tool_name == "query_calls_table":
            return _generate_calls_chart(data, tool_input, question, chart_type)
        
        elif tool_name == "query_rome_table":
            return _generate_rome_chart(data, tool_input, question, chart_type)
        
        elif tool_name == "aggregated_result":
            return _generate_aggregated_chart(data, tool_input, question, chart_type)
        
        return None
    
    except Exception as e:
        print(f"⚠️ Chart generation error: {e}")
        return None


def _generate_aggregated_chart(data, tool_input, question, chart_type):
    """Generate chart for aggregated helper results"""
    
    if not data or len(data) < 2:
        return None
    
    group_by = tool_input.get('group_by', 'category')
    count_field = tool_input.get('count_field', 'value')
    question_lower = question.lower()
    
    # Format data for chart
    chart_data_list = [
        {
            'label': str(record.get('category', 'Unknown')),
            'value': float(record.get('value', 0))
        }
        for record in data
    ]
    
    # Sort by value descending for rankings
    if any(kw in question_lower for kw in ['top', 'highest', 'best', 'leading']):
        chart_data_list = sorted(chart_data_list, key=lambda x: x['value'], reverse=True)
    elif any(kw in question_lower for kw in ['bottom', 'lowest', 'worst']):
        chart_data_list = sorted(chart_data_list, key=lambda x: x['value'])
    
    # Limit to top 10 for rankings
    if len(chart_data_list) > 10 and any(kw in question_lower for kw in ['top', 'bottom', 'ranking']):
        chart_data_list = chart_data_list[:10]
    
    return {
        'type': chart_type,
        'title': f"Aggregated Results by {group_by.replace('_', ' ').title()}",
        'data': chart_data_list,
        'xKey': 'label',
        'yKey': 'value',
        'yLabel': count_field.replace('_', ' ').title(),
        'source': 'Aggregated Data'
    }


def _generate_sales_chart(data, tool_input, question, chart_type):
    """Generate chart for sales finance data - V6.2 with multi-year support"""
    
    import re
    question_lower = question.lower()
    month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                 'July', 'August', 'September', 'October', 'November', 'December']
    
    products = tool_input.get('products', ['All Products'])
    product_name = products[0] if len(products) == 1 else 'Portfolio'
    
    # DETECT WHICH METRIC TO CHART
    # Priority: gross_sales > revenue_deductions > net_sales (default)
    metric_field = 'net_sales'
    metric_label = 'Net Sales'
    
    if any(kw in question_lower for kw in ['gross sales', 'gross revenue', 'gross']):
        metric_field = 'gross_sales'
        metric_label = 'Gross Sales'
    elif any(kw in question_lower for kw in ['revenue deduction', 'deduction', 'rebate', 'discount']):
        metric_field = 'revenue_deductions'
        metric_label = 'Revenue Deductions'
    else:
        metric_field = 'net_sales'
        metric_label = 'Net Sales'
    
    # DETECT MULTI-YEAR COMPARISON
    # Extract all years mentioned in question (e.g., "2025 vs 2024", "2025 YTD compared to previous year")
    years_in_question = re.findall(r'\b(202[0-9])\b', question)
    unique_years = sorted(set(int(y) for y in years_in_question), reverse=True)  # [2025, 2024]
    
    # Check if data contains multiple years
    years_in_data = sorted(set(int(r.get('year', 0)) for r in data), reverse=True)
    
    # Multi-year comparison if:
    # 1. Question mentions multiple years OR
    # 2. Question mentions "previous year", "prior year", "yoy", "year over year" AND data has multiple years
    is_multi_year = (
        len(unique_years) >= 2 or 
        (any(phrase in question_lower for phrase in ['previous year', 'prior year', 'yoy', 'year over year', 'vs py']) 
         and len(years_in_data) >= 2)
    )
    
    # DETECT SPECIFIC MONTH QUESTION
    # Pattern: "Nov 2025", "November 2025", "Oct 2024", etc.
    specific_month_match = re.search(r'\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{4})\b', question_lower)
    
    # PIE CHART: Breakdown at single point in time
    if chart_type == 'pie':
        # Detect breakdown dimension
        wants_monthly = any(phrase in question_lower for phrase in ['by month', 'monthly breakdown', 'each month'])
        wants_quarterly = any(phrase in question_lower for phrase in ['by quarter', 'quarterly', 'q1', 'q2', 'q3', 'q4'])
        
        if wants_quarterly:
            # Group by quarter
            quarterly_data = {}
            for record in data:
                quarter = f"Q{((record['month'] - 1) // 3) + 1}"
                quarterly_data[quarter] = quarterly_data.get(quarter, 0) + record.get(metric_field, 0)
            
            chart_data = [{'label': q, 'value': round(v / 1e6, 1)} for q, v in sorted(quarterly_data.items())]
            year = tool_input.get('year', data[0].get('year', 'All Years'))
            
            return {
                'type': 'pie',
                'title': f"{product_name} {metric_label} by Quarter - {year}",
                'data': chart_data,
                'xKey': 'label',
                'yKey': 'value',
                'yLabel': f'{metric_label} ($M)',
                'source': 'SALES_FINANCE_BPC_corrected'
            }
        elif wants_monthly:
            # Group by month
            monthly_data = {}
            year_val = int(data[0].get('year', 0))
            
            for record in data:
                month = int(record.get('month', 0))
                month_label = month_names[month] if month < len(month_names) else f"Month {month}"
                monthly_data[month_label] = monthly_data.get(month_label, 0) + record.get(metric_field, 0)
            
            # Sort by month order
            month_order = {month_names[i]: i for i in range(1, 13)}
            sorted_months = sorted(monthly_data.items(), key=lambda x: month_order.get(x[0], 99))
            chart_data = [{'label': month, 'value': round(v / 1e6, 1)} for month, v in sorted_months]
            
            return {
                'type': 'pie',
                'title': f"{product_name} Monthly {metric_label} Distribution - {year_val}",
                'data': chart_data,
                'xKey': 'label',
                'yKey': 'value',
                'yLabel': f'{metric_label} ($M)',
                'source': 'SALES_FINANCE_BPC_corrected'
            }
        else:
            # Group by product (default for pie)
            product_data = {}
            for record in data:
                product = record.get('brand', 'Unknown')
                product_data[product] = product_data.get(product, 0) + record.get(metric_field, 0)
            
            chart_data = [{'label': p, 'value': round(v / 1e6, 1)} for p, v in product_data.items()]
            
            # Get date for title
            first_record = data[0]
            year = int(first_record.get('year', 0))
            month = first_record.get('month')
            title_date = f"{month_names[int(month)]} {year}" if month else str(year)
            
            return {
                'type': 'pie',
                'title': f"Product {metric_label} Mix - {title_date}",
                'data': chart_data,
                'xKey': 'label',
                'yKey': 'value',
                'yLabel': f'{metric_label} ($M)',
                'source': 'SALES_FINANCE_BPC_corrected'
            }
    
    # BAR/LINE CHART: Time series or comparisons
    else:
        # Detect if user wants product comparison vs time series
        wants_by_product = any(phrase in question_lower for phrase in ['by product', 'by brand', 'each product', 'per product'])
        
        if wants_by_product:
            # Group by product for product comparison
            product_data = {}
            year_val = int(data[0].get('year', 0))
            
            for record in data:
                product = record.get('brand', 'Unknown')
                product_data[product] = product_data.get(product, 0) + record.get(metric_field, 0)
            
            chart_data = [{'product': p, 'sales': round(v / 1e6, 1)} for p, v in sorted(product_data.items())]
            
            return {
                'type': chart_type,
                'title': f"Product {metric_label} Comparison - {year_val}",
                'data': chart_data,
                'xKey': 'product',
                'yKey': 'sales',
                'yLabel': f'{metric_label} ($M)',
                'source': 'SALES_FINANCE_BPC_corrected'
            }
        else:
            # Time series: check for multiple forecast types AND/OR multiple years
            forecast_types = tool_input.get('forecast_types', ['ACTUALS'])
            has_multiple_forecast_types = len(forecast_types) > 1 or len(set(r.get('forecast_type') for r in data)) > 1
            
            # SPECIFIC MONTH COMPARISON (e.g., "Nov 2025 vs Nov 2024") - Check FIRST
            if specific_month_match:
                # Extract month and year from question
                month_abbr = specific_month_match.group(1)[:3]
                primary_year = int(specific_month_match.group(2))
                
                # Map month abbreviation to number
                month_map = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
                           'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12}
                target_month = month_map.get(month_abbr)
                
                if target_month:
                    # Filter data to only the specific month across all years
                    filtered_data = [r for r in data if int(r.get('month', 0)) == target_month]
                    
                    if filtered_data:
                        # Group by year and forecast type
                        bar_data = []
                        for record in filtered_data:
                            year = int(record.get('year', 0))
                            forecast_type = record.get('forecast_type', 'Actual')
                            value = round(record.get(metric_field, 0) / 1e6, 1)
                            
                            bar_data.append({
                                'label': f"{month_names[target_month]} {year} {forecast_type}",
                                'value': value
                            })
                        
                        # Sort by year descending (most recent first)
                        bar_data.sort(key=lambda x: x['label'], reverse=True)
                        
                        return {
                            'type': 'bar',
                            'title': f"{product_name} {metric_label}: {month_names[target_month]} Comparison",
                            'data': bar_data,
                            'xKey': 'label',
                            'yKey': 'value',
                            'yLabel': f'{metric_label} ($M)',
                            'source': 'SALES_FINANCE_BPC_corrected'
                        }
            
            # MULTI-YEAR COMPARISON CHART (for YTD, quarterly, etc.)
            elif is_multi_year and len(years_in_data) >= 2:
                # Generate multi-year chart with separate series for each year+forecast_type combination
                series_data = {}
                
                for record in data:
                    month = int(record.get('month', 0))
                    month_label = month_names[month] if month < len(month_names) else f"Month {month}"
                    year = int(record.get('year', 0))
                    forecast_type = record.get('forecast_type', 'Actual')
                    
                    # Create series key: "2025 Actuals", "2024 Actuals", "2025 Budget", etc.
                    series_key = f"{year} {forecast_type}"
                    
                    if series_key not in series_data:
                        series_data[series_key] = {}
                    series_data[series_key][month_label] = series_data[series_key].get(month_label, 0) + record[metric_field]
                
                # Convert to multi-series format
                month_order = {month_names[i]: i for i in range(1, 13)}
                all_months = sorted(set(month for series in series_data.values() for month in series.keys()), 
                                  key=lambda x: month_order.get(x, 99))
                
                chart_data = []
                for month in all_months:
                    data_point = {'month': month}
                    for series_key, monthly_values in series_data.items():
                        # Convert series key to valid JSON key (lowercase, no spaces)
                        json_key = series_key.lower().replace(' ', '_')
                        data_point[json_key] = round(monthly_values.get(month, 0) / 1e6, 1)
                    chart_data.append(data_point)
                
                series_keys = [sk.lower().replace(' ', '_') for sk in series_data.keys()]
                
                # Create descriptive title
                year_range = f"{min(years_in_data)}-{max(years_in_data)}" if len(years_in_data) > 1 else str(years_in_data[0])
                
                return {
                    'type': chart_type,
                    'title': f"{product_name} {metric_label}: Multi-Year Comparison ({year_range})",
                    'data': chart_data,
                    'xKey': 'month',
                    'seriesKeys': series_keys,
                    'yLabel': f'{metric_label} ($M)',
                    'source': 'SALES_FINANCE_BPC_corrected'
                }
            
            # SINGLE YEAR, MULTI-FORECAST TYPE (ACTUAL vs BUDGET)
            elif has_multiple_forecast_types:
                # Multi-series chart (ACTUAL vs BUDGET) for single year
                series_data = {}
                
                # Determine primary year from question or data
                if unique_years:
                    primary_year = unique_years[0]  # Use first year mentioned in question
                else:
                    primary_year = years_in_data[0] if years_in_data else int(data[0].get('year', 0))
                
                # Filter data to primary year only
                year_filtered_data = [r for r in data if int(r.get('year', 0)) == primary_year]
                
                for record in year_filtered_data:
                    month = int(record.get('month', 0))
                    month_label = month_names[month] if month < len(month_names) else f"Month {month}"
                    forecast_type = record.get('forecast_type', 'Actual')
                    
                    if forecast_type not in series_data:
                        series_data[forecast_type] = {}
                    series_data[forecast_type][month_label] = series_data[forecast_type].get(month_label, 0) + record[metric_field]
                
                # Convert to multi-series format
                month_order = {month_names[i]: i for i in range(1, 13)}
                all_months = sorted(set(month for series in series_data.values() for month in series.keys()), 
                                  key=lambda x: month_order.get(x, 99))
                
                chart_data = []
                for month in all_months:
                    data_point = {'month': month}
                    for forecast_type, monthly_values in series_data.items():
                        data_point[forecast_type.lower()] = round(monthly_values.get(month, 0) / 1e6, 1)
                    chart_data.append(data_point)
                
                series_keys = [ft.lower() for ft in series_data.keys()]
                
                return {
                    'type': chart_type,
                    'title': f"{product_name} {metric_label}: {' vs '.join(series_data.keys())} - {primary_year}",
                    'data': chart_data,
                    'xKey': 'month',
                    'seriesKeys': series_keys,
                    'yLabel': f'{metric_label} ($M)',
                    'source': 'SALES_FINANCE_BPC_corrected'
                }
            else:
                # Single series time series (single year, single forecast type)
                monthly_data = {}
                
                # Determine primary year
                if unique_years:
                    primary_year = unique_years[0]
                else:
                    primary_year = years_in_data[0] if years_in_data else int(data[0].get('year', 0))
                
                # Filter to primary year
                year_filtered_data = [r for r in data if int(r.get('year', 0)) == primary_year]
                
                for record in year_filtered_data:
                    month = int(record.get('month', 0))
                    month_label = month_names[month] if month < len(month_names) else f"Month {month}"
                    monthly_data[month_label] = monthly_data.get(month_label, 0) + record[metric_field]
                
                # Sort by month order
                month_order = {month_names[i]: i for i in range(1, 13)}
                sorted_months = sorted(monthly_data.items(), key=lambda x: month_order.get(x[0], 99))
                chart_data = [{'month': month, 'sales': round(v / 1e6, 1)} for month, v in sorted_months]
                
                return {
                    'type': chart_type,
                    'title': f"{product_name} Monthly {metric_label} - {primary_year}",
                    'data': chart_data,
                    'xKey': 'month',
                    'yKey': 'sales',
                    'yLabel': f'{metric_label} ($M)',
                    'source': 'SALES_FINANCE_BPC_corrected'
                }


def _generate_market_chart(data, tool_input, question, chart_type):
    """Generate chart for market share data - V6.2 with multi-year support"""
    
    import re
    question_lower = question.lower()
    month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                 'July', 'August', 'September', 'October', 'November', 'December']
    
    # Market share is always time series (line chart preferred)
    brands = tool_input.get('brands', [])
    has_multiple_brands = len(brands) > 1 or len(set(r.get('brand') for r in data)) > 1
    
    # DETECT MULTI-YEAR COMPARISON
    years_in_question = re.findall(r'\b(202[0-9])\b', question)
    unique_years = sorted(set(int(y) for y in years_in_question), reverse=True)
    years_in_data = sorted(set(int(r.get('year', 0)) for r in data), reverse=True)
    
    is_multi_year = (
        len(unique_years) >= 2 or 
        (any(phrase in question_lower for phrase in ['previous year', 'prior year', 'yoy', 'year over year', 'vs py']) 
         and len(years_in_data) >= 2)
    )
    
    # DETECT SPECIFIC MONTH QUESTION
    specific_month_match = re.search(r'\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{4})\b', question_lower)
    
    # SPECIFIC MONTH COMPARISON (e.g., "Nov 2025 vs Nov 2024")
    if specific_month_match:
        month_abbr = specific_month_match.group(1)[:3]
        primary_year = int(specific_month_match.group(2))
        
        month_map = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
                   'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12}
        target_month = month_map.get(month_abbr)
        
        if target_month:
            filtered_data = [r for r in data if int(r.get('month', 0)) == target_month]
            
            if filtered_data:
                bar_data = []
                for record in filtered_data:
                    year = int(record.get('year', 0))
                    brand = record.get('brand', 'Unknown')
                    value = round(float(record.get('trx_share_r3m', 0)), 1)
                    
                    bar_data.append({
                        'label': f"{month_names[target_month]} {year} {brand}",
                        'value': value
                    })
                
                bar_data.sort(key=lambda x: x['label'], reverse=True)
                
                return {
                    'type': 'bar',
                    'title': f"Market Share: {month_names[target_month]} Comparison",
                    'data': bar_data,
                    'xKey': 'label',
                    'yKey': 'value',
                    'yLabel': 'Market Share (%)',
                    'source': 'FCT_MARKET_PLU_corrected'
                }
    
    # MULTI-YEAR COMPARISON
    if is_multi_year and len(years_in_data) >= 2 and has_multiple_brands:
        # Multi-year, multi-brand comparison
        series_data = {}
        
        for record in data:
            month = int(record.get('month', 0))
            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
            year = int(record.get('year', 0))
            brand = record.get('brand', 'Unknown')
            
            series_key = f"{year} {brand}"
            
            if series_key not in series_data:
                series_data[series_key] = {}
            series_data[series_key][month_label] = series_data[series_key].get(month_label, 0) + float(record.get('trx_share_r3m', 0))
        
        month_order = {month_names[i]: i for i in range(1, 13)}
        all_months = sorted(set(month for series in series_data.values() for month in series.keys()), 
                          key=lambda x: month_order.get(x, 99))
        
        chart_data = []
        for month in all_months:
            data_point = {'month': month}
            for series_key, monthly_values in series_data.items():
                json_key = series_key.lower().replace(' ', '_')
                data_point[json_key] = round(monthly_values.get(month, 0), 1)
            chart_data.append(data_point)
        
        series_keys = [sk.lower().replace(' ', '_') for sk in series_data.keys()]
        year_range = f"{min(years_in_data)}-{max(years_in_data)}" if len(years_in_data) > 1 else str(years_in_data[0])
        
        return {
            'type': chart_type,
            'title': f"Market Share: Multi-Year Comparison ({year_range})",
            'data': chart_data,
            'xKey': 'month',
            'seriesKeys': series_keys,
            'yLabel': 'Market Share (%)',
            'source': 'FCT_MARKET_PLU_corrected'
        }
    
    # MULTI-BRAND COMPARISON (single year)
    elif has_multiple_brands:
        # Multi-brand comparison for single year
        series_data = {}
        
        # Determine primary year
        if unique_years:
            primary_year = unique_years[0]
        else:
            primary_year = years_in_data[0] if years_in_data else int(data[0].get('year', 0))
        
        # Filter to primary year
        year_filtered_data = [r for r in data if int(r.get('year', 0)) == primary_year]
        
        for record in year_filtered_data:
            month = int(record.get('month', 0))
            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
            brand = record.get('brand', 'Unknown')
            
            if brand not in series_data:
                series_data[brand] = {}
            series_data[brand][month_label] = series_data[brand].get(month_label, 0) + float(record.get('trx_share_r3m', 0))
        
        month_order = {month_names[i]: i for i in range(1, 13)}
        all_months = sorted(set(month for series in series_data.values() for month in series.keys()), 
                          key=lambda x: month_order.get(x, 99))
        
        chart_data = []
        for month in all_months:
            data_point = {'month': month}
            for brand, monthly_values in series_data.items():
                data_point[brand.lower()] = round(monthly_values.get(month, 0), 1)
            chart_data.append(data_point)
        
        series_keys = [brand.lower() for brand in series_data.keys()]
        
        return {
            'type': chart_type,
            'title': f"Market Share Comparison: {' vs '.join(series_data.keys())} - {primary_year}",
            'data': chart_data,
            'xKey': 'month',
            'seriesKeys': series_keys,
            'yLabel': 'Market Share (%)',
            'source': 'FCT_MARKET_PLU_corrected'
        }
    
    # SINGLE BRAND TREND
    else:
        # Single brand trend
        monthly_data = {}
        
        # Determine primary year
        if unique_years:
            primary_year = unique_years[0]
        else:
            primary_year = years_in_data[0] if years_in_data else int(data[0].get('year', 0))
        
        # Filter to primary year
        year_filtered_data = [r for r in data if int(r.get('year', 0)) == primary_year]
        
        for record in year_filtered_data:
            month = int(record.get('month', 0))
            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
            monthly_data[month_label] = monthly_data.get(month_label, 0) + float(record.get('trx_share_r3m', 0))
        
        month_order = {month_names[i]: i for i in range(1, 13)}
        sorted_months = sorted(monthly_data.items(), key=lambda x: month_order.get(x[0], 99))
        chart_data = [{'month': month, 'share': round(share, 1)} for month, share in sorted_months]
        
        brand_name = brands[0] if len(brands) == 1 else 'Market'
        
        return {
            'type': chart_type,
            'title': f"{brand_name} TRX Share (R3M) - {primary_year}",
            'data': chart_data,
            'xKey': 'month',
            'yKey': 'share',
            'yLabel': 'Market Share (%)',
            'source': 'FCT_MARKET_PLU_corrected'
        }


def _generate_doses_chart(data, tool_input, question, chart_type):
    """Generate chart for doses data - V6.2 with multi-year support"""
    
    import re
    question_lower = question.lower()
    month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June', 
                 'July', 'August', 'September', 'October', 'November', 'December']
    
    forecast_types = tool_input.get('forecast_types', ['ACTUALS'])
    has_multiple_series = len(forecast_types) > 1 or len(set(r.get('forecast_type') for r in data)) > 1
    
    products = tool_input.get('products', ['All Products'])
    metrics = tool_input.get('metrics', ['Doses'])
    product_name = products[0] if len(products) == 1 else 'Portfolio'
    metric_name = metrics[0] if len(metrics) == 1 else 'Doses'
    
    # DETECT MULTI-YEAR COMPARISON
    years_in_question = re.findall(r'\b(202[0-9])\b', question)
    unique_years = sorted(set(int(y) for y in years_in_question), reverse=True)
    years_in_data = sorted(set(int(r.get('year', 0)) for r in data), reverse=True)
    
    is_multi_year = (
        len(unique_years) >= 2 or 
        (any(phrase in question_lower for phrase in ['previous year', 'prior year', 'yoy', 'year over year', 'vs py']) 
         and len(years_in_data) >= 2)
    )
    
    # DETECT SPECIFIC MONTH QUESTION
    specific_month_match = re.search(r'\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{4})\b', question_lower)
    
    # SPECIFIC MONTH COMPARISON (e.g., "Nov 2025 vs Nov 2024")
    if specific_month_match:
        month_abbr = specific_month_match.group(1)[:3]
        primary_year = int(specific_month_match.group(2))
        
        month_map = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
                   'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12}
        target_month = month_map.get(month_abbr)
        
        if target_month:
            filtered_data = [r for r in data if int(r.get('month', 0)) == target_month]
            
            if filtered_data:
                bar_data = []
                for record in filtered_data:
                    year = int(record.get('year', 0))
                    forecast_type = record.get('forecast_type', 'Actual')
                    value = round(record.get('value', 0))
                    
                    bar_data.append({
                        'label': f"{month_names[target_month]} {year} {forecast_type}",
                        'value': value
                    })
                
                bar_data.sort(key=lambda x: x['label'], reverse=True)
                
                return {
                    'type': 'bar',
                    'title': f"{product_name} {metric_name}: {month_names[target_month]} Comparison",
                    'data': bar_data,
                    'xKey': 'label',
                    'yKey': 'value',
                    'yLabel': 'Doses',
                    'source': 'FCT_DOSES_PLU_corrected'
                }
    
    # MULTI-YEAR COMPARISON
    if is_multi_year and len(years_in_data) >= 2 and has_multiple_series:
        # Multi-year, multi-forecast comparison
        series_data = {}
        
        for record in data:
            month = int(record.get('month', 0))
            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
            year = int(record.get('year', 0))
            forecast_type = record.get('forecast_type', 'Actual')
            
            series_key = f"{year} {forecast_type}"
            
            if series_key not in series_data:
                series_data[series_key] = {}
            series_data[series_key][month_label] = series_data[series_key].get(month_label, 0) + record.get('value', 0)
        
        month_order = {month_names[i]: i for i in range(1, 13)}
        all_months = sorted(set(month for series in series_data.values() for month in series.keys()), 
                          key=lambda x: month_order.get(x, 99))
        
        chart_data = []
        for month in all_months:
            data_point = {'month': month}
            for series_key, monthly_values in series_data.items():
                json_key = series_key.lower().replace(' ', '_')
                data_point[json_key] = round(monthly_values.get(month, 0))
            chart_data.append(data_point)
        
        series_keys = [sk.lower().replace(' ', '_') for sk in series_data.keys()]
        year_range = f"{min(years_in_data)}-{max(years_in_data)}" if len(years_in_data) > 1 else str(years_in_data[0])
        
        return {
            'type': chart_type,
            'title': f"{product_name} {metric_name}: Multi-Year Comparison ({year_range})",
            'data': chart_data,
            'xKey': 'month',
            'seriesKeys': series_keys,
            'yLabel': 'Doses',
            'source': 'FCT_DOSES_PLU_corrected'
        }
    
    # MULTI-FORECAST TYPE (single year)
    elif has_multiple_series:
        # Multi-series (ACTUAL vs BUDGET) for single year
        series_data = {}
        
        # Determine primary year
        if unique_years:
            primary_year = unique_years[0]
        else:
            primary_year = years_in_data[0] if years_in_data else int(data[0].get('year', 0))
        
        # Filter to primary year
        year_filtered_data = [r for r in data if int(r.get('year', 0)) == primary_year]
        
        for record in year_filtered_data:
            month = int(record.get('month', 0))
            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
            forecast_type = record.get('forecast_type', 'Actual')
            
            if forecast_type not in series_data:
                series_data[forecast_type] = {}
            series_data[forecast_type][month_label] = series_data[forecast_type].get(month_label, 0) + record.get('value', 0)
        
        month_order = {month_names[i]: i for i in range(1, 13)}
        all_months = sorted(set(month for series in series_data.values() for month in series.keys()), 
                          key=lambda x: month_order.get(x, 99))
        
        chart_data = []
        for month in all_months:
            data_point = {'month': month}
            for forecast_type, monthly_values in series_data.items():
                data_point[forecast_type.lower()] = round(monthly_values.get(month, 0))
            chart_data.append(data_point)
        
        series_keys = [ft.lower() for ft in series_data.keys()]
        
        return {
            'type': chart_type,
            'title': f"{product_name} {metric_name}: {' vs '.join(series_data.keys())} - {primary_year}",
            'data': chart_data,
            'xKey': 'month',
            'seriesKeys': series_keys,
            'yLabel': 'Doses',
            'source': 'FCT_DOSES_PLU_corrected'
        }
    
    # SINGLE SERIES (single year, single forecast type)
    else:
        # Single series
        monthly_data = {}
        
        # Determine primary year
        if unique_years:
            primary_year = unique_years[0]
        else:
            primary_year = years_in_data[0] if years_in_data else int(data[0].get('year', 0))
        
        # Filter to primary year
        year_filtered_data = [r for r in data if int(r.get('year', 0)) == primary_year]
        
        for record in year_filtered_data:
            month = int(record.get('month', 0))
            month_label = month_names[month] if month < len(month_names) else f"Month {month}"
            monthly_data[month_label] = monthly_data.get(month_label, 0) + record.get('value', 0)
        
        month_order = {month_names[i]: i for i in range(1, 13)}
        sorted_months = sorted(monthly_data.items(), key=lambda x: month_order.get(x[0], 99))
        chart_data = [{'month': month, 'doses': round(float(doses))} for month, doses in sorted_months]
        
        return {
            'type': chart_type,
            'title': f"{product_name} {metric_name} - {primary_year}",
            'data': chart_data,
            'xKey': 'month',
            'yKey': 'doses',
            'yLabel': 'Doses',
            'source': 'FCT_DOSES_PLU_corrected'
        }


def _generate_calls_chart(data, tool_input, question, chart_type):
    """Generate chart for calls metrics - Simplified V6.1"""
    
    # Always bar charts for calls
    question_lower = question.lower()
    quarters = set(r.get('year_quarter') for r in data if r.get('year_quarter'))
    geographies = set(r.get('dim_geo_name') for r in data if r.get('dim_geo_name'))
    
    products = tool_input.get('products', ['All Products'])
    product_name = products[0] if len(products) == 1 else 'Portfolio'
    
    # Detect which metric user asked about from filter or question
    filters = tool_input.get('filters', {})
    metric_type_filter = filters.get('metric_type') if isinstance(filters, dict) else None
    
    # Determine metric field and label based on question or filter
    if metric_type_filter == 'CPD' or 'cpd' in question_lower:
        metric_field = 'CPD'
        metric_label = 'CPD (Calls Per Day)'
        value_extractor = lambda r: float(r.get('CPD', 0))
    elif metric_type_filter == 'HCP_REACH' or 'hcp reach' in question_lower or 'reach' in question_lower:
        metric_field = 'HCP_REACH'
        metric_label = 'HCP Reach %'
        value_extractor = lambda r: float(r.get('percent_reached', 0))
    elif metric_type_filter == 'CALL_FREQUENCY_ATTAINMENT' or 'frequency' in question_lower or 'attainment' in question_lower:
        metric_field = 'CALL_FREQUENCY'
        metric_label = 'Call Frequency Attainment %'
        value_extractor = lambda r: float(r.get('call_frequency_attainment', 0))
    elif 'total calls' in question_lower or 'call count' in question_lower:
        metric_field = 'TOTAL_CALLS'
        metric_label = 'Total Calls'
        value_extractor = lambda r: float(r.get('actual_calls', 0))
    else:
        # Default to CPD if ambiguous
        metric_field = 'CPD'
        metric_label = 'CPD (Calls Per Day)'
        value_extractor = lambda r: float(r.get('CPD', 0))
    
    # CRITICAL FIX: Filter data to only the specific metric type FIRST
    # The CALLS table returns one record per geography per metric type
    # We must filter to ONLY the metric we care about before aggregating
    if metric_type_filter:
        filtered_data = [r for r in data if r.get('dim_metric_type') == metric_type_filter]
        if not filtered_data:
            # Fallback: if dim_metric_type field doesn't exist, use all data
            filtered_data = data
    else:
        filtered_data = data
    
    if len(quarters) > 1:
        # Quarterly comparison
        quarterly_data = {}
        for record in filtered_data:
            quarter = record.get('year_quarter', 'Unknown')
            if quarter not in quarterly_data:
                quarterly_data[quarter] = []
            quarterly_data[quarter].append(value_extractor(record))
        
        chart_data = [
            {'quarter': q, 'value': round(sum(values) / len(values), 1) if values else 0}
            for q, values in sorted(quarterly_data.items())
        ]
        
        return {
            'type': chart_type,
            'title': f"{product_name} {metric_label} by Quarter",
            'data': chart_data,
            'xKey': 'quarter',
            'yKey': 'value',
            'yLabel': metric_label,
            'source': 'FCT_CALLS'
        }
    elif len(geographies) > 1:
        # Geographic comparison - FIXED: Use pre-filtered data
        geo_data = {}
        for record in filtered_data:
            geo_name = record.get('dim_geo_name', 'Unknown')
            if geo_name not in geo_data:
                geo_data[geo_name] = []
            geo_data[geo_name].append(value_extractor(record))
        
        # Average if multiple records per geography (shouldn't happen with proper filtering)
        chart_data = [
            {'geography': geo, 'value': round(sum(values) / len(values), 1) if values else 0}
            for geo, values in sorted(geo_data.items())
        ]
        
        return {
            'type': chart_type,
            'title': f"{product_name} {metric_label} by Geography",
            'data': chart_data,
            'xKey': 'geography',
            'yKey': 'value',
            'yLabel': metric_label,
            'source': 'FCT_CALLS'
        }
    else:
        return None


def _generate_rome_chart(data, tool_input, question, chart_type):
    """Generate chart for Rome metrics - Simplified V6.1"""
    
    # Always bar charts for ROME
    question_lower = question.lower()
    wants_site_chart = any(word in question_lower for word in ['site', 'sites', 'account', 'accounts', 'customer', 'customers'])
    wants_region_chart = any(word in question_lower for word in ['region', 'regional', 'geography', 'geographic'])
    
    quarters = set(r.get('year_quarter') for r in data if r.get('year_quarter'))
    regions = set(r.get('dim_region_name') for r in data if r.get('dim_region_name'))
    sites = set(r.get('site_id') for r in data if r.get('site_id'))
    
    products = tool_input.get('products', ['All Products'])
    product_name = products[0] if len(products) == 1 else 'Portfolio'
    
    if wants_site_chart and len(sites) > 1:
        # Site comparison
        site_orders = {}
        site_names = {}
        for record in data:
            site = record.get('site_id', 'Unknown')
            site_name = record.get('dim_customer_name', site)
            order_num = record.get('sales_order_number', 'Unknown')
            
            if site not in site_orders:
                site_orders[site] = set()
                site_names[site] = site_name
            site_orders[site].add(order_num)
        
        chart_data = [
            {'site': site_names[site], 'orders': len(order_set)}
            for site, order_set in sorted(site_orders.items(), key=lambda x: len(x[1]), reverse=True)
        ][:10]  # Limit to top 10
        
        return {
            'type': chart_type,
            'title': f"{product_name} Top Sites by Order Volume",
            'data': chart_data,
            'xKey': 'site',
            'yKey': 'orders',
            'yLabel': 'Number of Orders',
            'source': 'FCT_ROME_PLU'
        }
    
    elif wants_region_chart and len(regions) > 1:
        # Region comparison
        region_orders = {}
        for record in data:
            region = record.get('dim_region_name', 'Unknown')
            order_num = record.get('sales_order_number', 'Unknown')
            
            if region not in region_orders:
                region_orders[region] = set()
            region_orders[region].add(order_num)
        
        chart_data = [
            {'region': r, 'orders': len(order_set)}
            for r, order_set in sorted(region_orders.items())
        ]
        
        return {
            'type': chart_type,
            'title': f"{product_name} Patient Orders by Region",
            'data': chart_data,
            'xKey': 'region',
            'yKey': 'orders',
            'yLabel': 'Number of Orders',
            'source': 'FCT_ROME_PLU'
        }
    
    elif len(quarters) > 1:
        # Quarterly trend
        quarterly_orders = {}
        for record in data:
            quarter = record.get('year_quarter', 'Unknown')
            order_num = record.get('sales_order_number', 'Unknown')
            
            if quarter not in quarterly_orders:
                quarterly_orders[quarter] = set()
            quarterly_orders[quarter].add(order_num)
        
        chart_data = [
            {'quarter': q, 'orders': len(order_set)}
            for q, order_set in sorted(quarterly_orders.items())
        ]
        
        return {
            'type': chart_type,
            'title': f"{product_name} Patient Orders by Quarter",
            'data': chart_data,
            'xKey': 'quarter',
            'yKey': 'orders',
            'yLabel': 'Number of Orders',
            'source': 'FCT_ROME_PLU'
        }
    else:
        return None


# ============================================================================
# TOOL EXECUTION MAPPING
# ============================================================================

TOOL_FUNCTIONS = {
    "query_sales_finance_table": query_sales_finance_table,
    "query_market_share_table": query_market_share_table,
    "query_doses_table": query_doses_table,
    "query_calls_table": query_calls_table,
    "query_rome_table": query_rome_table,
    "query_rome_new_patient_starts_aggregated": query_rome_new_patient_starts_aggregated,
    "query_rome_new_patient_orders_aggregated": query_rome_new_patient_orders_aggregated,
    "query_rome_all_orders_aggregated": query_rome_all_orders_aggregated,
    "query_rome_site_status_aggregated": query_rome_site_status_aggregated,
    "deduplicate_and_aggregate": deduplicate_and_sum,  # Map new name to existing function
    "simple_aggregate": simple_sum,  # Map new name to existing function
    "aggregate_by_dimensions": aggregate_by_dimensions  # NEW: Universal aggregation
}

# ============================================================================
# MAIN HANDLER FUNCTION
# ============================================================================

def handle_question_with_agent(question, image_base64=None, conversation_history=None, 
                               slide_number=None, use_preprocessed=False, slide_context=None,
                               return_tool_calls=False):
    """
    Handle question with classifier-based routing
    
    Args:
        question: User question
        image_base64: Optional slide image (not used in V6)
        conversation_history: Optional conversation history
        slide_number: Optional slide number
        use_preprocessed: Whether to use preprocessed slide data
        slide_context: Optional preprocessed slide context
        return_tool_calls: If True, return tool call information for debugging
        
    Returns:
        tuple: (answer, chart_data, audio_summary, data_source) OR
               (answer, chart_data, audio_summary, data_source, tool_calls) if return_tool_calls=True
    """
    # Data cache for large result sets (V6 optimization)
    data_cache = {}
    next_cache_id = 1
    
    # Track tool calls for debugging
    tool_calls_log = []
    
    # Step 1: Classify question
    question_type = classify_question(question)
    
    # Step 2: Select prompt and tools based on classification
    if question_type == 'rome':
        system_prompt = get_rome_system_prompt()  # Imported from novartis_prompts_v6
        tools = COMBINED_TOOLS  # ROME questions may need all tools
    else:
        system_prompt = get_general_system_prompt()  # Call function to get prompt with current date context
        tools = GENERAL_TOOLS
    
    print(f"\n{'='*80}")
    print(f"🤖 AGENT V6 FINAL - Classification: {question_type.upper()}")
    print(f"{'='*80}")
    print(f"Question: {question}")
    
    # Step 3: Build messages
    messages = []
    
    # Add conversation history (limit to last 2 exchanges)
    if conversation_history:
        for msg in conversation_history[-2:]:
            messages.append({
                "role": msg['role'],
                "content": msg['content']
            })
    
    # Build current message
    current_content = []
    
    # Add preprocessed slide context if available
    if use_preprocessed and slide_number and slide_context:
        context_text = f"\n\n**Slide {slide_number} Context:**\n"
        context_text += f"**Title:** {slide_context.get('title', 'N/A')}\n"
        context_text += f"**Summary:** {slide_context.get('summary', '')}\n"
        current_content.append({"type": "text", "text": context_text})
    
    # Add question
    current_content.append({"type": "text", "text": question})
    
    messages.append({
        "role": "user",
        "content": current_content
    })
    
    # Step 4: Call Claude with Messages API (with iteration loop for multi-step tool use)
    print(f"🤖 Calling Claude Sonnet 4.5 with {len(tools)} tools...")
    
    # Initialize chart_data and data_source before iteration loop
    chart_data = None
    data_source = None
    
    max_iterations = 15  # Increased to handle complex multi-step questions
    for iteration in range(max_iterations):
        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 8192,  # Increased from 4096 to handle complex multi-step analyses
            "temperature": 0,
            "system": system_prompt,
            "messages": messages,
            "tools": tools
        }
        
        try:
            response = bedrock_runtime.invoke_model(
                modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
                body=json.dumps(request_body)
            )
            if iteration == 0:
                print("✅ Bedrock call successful")
        except Exception as e:
            print(f"❌ Bedrock error: {str(e)}")
            raise
        
        response_body = json.loads(response['body'].read())
        
        # Handle tool use
        stop_reason = response_body.get('stop_reason')
        
        if stop_reason == 'end_turn':
            # Claude finished - extract final answer
            print(f"✅ Claude finished after {iteration + 1} iteration(s)")
            break
        elif stop_reason == 'tool_use':
            if iteration == 0:
                print("🔧 Claude requested tool use")
            else:
                print(f"🔧 Claude requested more tools (iteration {iteration + 1})")
            
            tool_results = []
            for content_block in response_body['content']:
                if content_block.get('type') == 'tool_use':
                    tool_name = content_block.get('name', 'UNKNOWN_TOOL')
                    tool_input = content_block['input']
                    tool_id = content_block['id']
                    
                    # DEBUG: Print raw content_block to see what Claude returned
                    if tool_name == 'UNKNOWN_TOOL' or '$' in tool_name:
                        print(f"   ⚠️ DEBUG - Raw content_block: {json.dumps(content_block, indent=2)}")
                    
                    print(f"   Tool: {tool_name}")
                    print(f"   Input: {json.dumps(tool_input, indent=2)}")
                    
                    # Track tool call
                    tool_call_start = datetime.now()
                    
                    # Execute tool
                    if tool_name in TOOL_FUNCTIONS:
                        try:
                            # Check if this is a helper tool that needs cached data
                            if tool_name in ['deduplicate_and_aggregate', 'simple_aggregate', 'aggregate_by_dimensions']:
                                # Helper tool - get data from cache
                                data_id = tool_input.get('data_id')
                                if data_id and data_id in data_cache:
                                    # Get cached data and call helper with correct parameter names
                                    cached_data = data_cache[data_id]
                                    
                                    if tool_name == 'deduplicate_and_aggregate':
                                        # Map 'group_by' to 'group_by_field' for the function
                                        results = deduplicate_and_sum(
                                            items=cached_data,
                                            group_by_field=tool_input.get('group_by'),  # Map parameter name
                                            count_field=tool_input.get('count_field', 'unique_order_count'),
                                            order_list_field=tool_input.get('order_list_field', 'order_list')
                                        )
                                    elif tool_name == 'simple_aggregate':
                                        # Map 'group_by' to 'group_by_field' for the function
                                        results = simple_sum(
                                            items=cached_data,
                                            group_by_field=tool_input.get('group_by'),  # Map parameter name
                                            count_field=tool_input.get('count_field', 'unique_order_count')
                                        )
                                    else:  # aggregate_by_dimensions
                                        # Parse JSON strings if needed
                                        group_by = tool_input.get('group_by', [])
                                        if isinstance(group_by, str):
                                            group_by = json.loads(group_by)
                                        
                                        sum_fields = tool_input.get('sum_fields', ['net_sales'])
                                        if isinstance(sum_fields, str):
                                            sum_fields = json.loads(sum_fields)
                                        
                                        filters = tool_input.get('filters')
                                        if isinstance(filters, str):
                                            filters = json.loads(filters)
                                        
                                        results = aggregate_by_dimensions(
                                            items=cached_data,
                                            group_by=group_by,
                                            sum_fields=sum_fields,
                                            filters=filters
                                        )
                                else:
                                    results = {"success": False, "error": f"Data ID '{data_id}' not found in cache"}
                            else:
                                # Regular query tool
                                results = TOOL_FUNCTIONS[tool_name](**tool_input)
                            
                            # Wrap results in standard format with caching for large datasets
                            # Handle different result types: list (query results), dict (aggregated results)
                            if isinstance(results, list):
                                total_records = len(results)
                            elif isinstance(results, dict):
                                total_records = len(results)  # Number of groups in aggregated result
                            else:
                                total_records = 0
                            
                            if isinstance(results, list) and total_records > 100:
                                # Large dataset - cache it and send reference
                                cache_id = f"data_{next_cache_id}"
                                next_cache_id += 1
                                data_cache[cache_id] = results
                                
                                result = {
                                    "success": True,
                                    "data_id": cache_id,
                                    "record_count": total_records,
                                    "message": f"Retrieved {total_records} records (stored as {cache_id}). Use aggregate_by_dimensions with data_id='{cache_id}' to aggregate Sales/Market/Doses data, or use deduplicate_and_aggregate/simple_aggregate for ROME data."
                                }
                                print(f"   ✅ Success: {total_records} records (cached as {cache_id})")
                            else:
                                    # Small dataset or already aggregated - send full data
                                if isinstance(results, dict) and not isinstance(results, list):
                                    # Already aggregated (dict result from helper)
                                    result = {
                                        "success": True,
                                        "aggregated_data": results,
                                        "group_count": total_records
                                    }
                                    print(f"   ✅ Success: {total_records} groups")
                                    
                                    # NEW V6.1: Generate chart from aggregated data
                                    if not chart_data and tool_name in ['deduplicate_and_aggregate', 'simple_aggregate', 'aggregate_by_dimensions']:
                                        # Convert aggregated dict to list format for chart generation
                                        aggregated_list = [
                                            {
                                                'category': key,
                                                'value': value,
                                                'group_by': tool_input.get('group_by')
                                            }
                                            for key, value in results.items()
                                        ]
                                        
                                        chart_result_for_chart = {
                                            "success": True,
                                            "data": aggregated_list
                                        }
                                        chart_data = generate_chart_data(
                                            tool_name='aggregated_result',
                                            tool_input=tool_input,
                                            tool_result=chart_result_for_chart,
                                            question=question
                                        )
                                        if chart_data:
                                            print(f"   📊 Generated {chart_data['type']} chart from aggregated data: {chart_data['title']}")
                                else:
                                    # Small dataset
                                    result = {
                                        "success": True,
                                        "data": results,
                                        "record_count": total_records
                                    }
                                    print(f"   ✅ Success: {total_records} records")
                            
                            # Generate chart from first successful tool call (for non-aggregated results)
                            if not chart_data and result.get('success') and result.get('data'):
                                chart_data = generate_chart_data(tool_name, tool_input, result, question)
                                if chart_data:
                                    print(f"   📊 Generated {chart_data['type']} chart: {chart_data['title']}")
                            
                            # Log tool call
                            tool_call_duration = (datetime.now() - tool_call_start).total_seconds() * 1000
                            tool_calls_log.append({
                                "tool_name": tool_name,
                                "tool_input": tool_input,
                                "success": True,
                                "duration_ms": tool_call_duration,
                                "record_count": total_records
                            })
                            
                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": tool_id,
                                "content": json.dumps(result) if result else json.dumps({"success": False, "error": "Empty result"})
                            })
                            
                            # DEBUG: Check if content is actually empty
                            if not json.dumps(result):
                                print(f"   ⚠️ WARNING: Empty tool result for {tool_name}")
                                print(f"   Result object: {result}")
                        except Exception as e:
                            print(f"   ❌ Error: {str(e)}")
                            import traceback
                            traceback.print_exc()
                            
                            # Log failed tool call
                            tool_call_duration = (datetime.now() - tool_call_start).total_seconds() * 1000
                            tool_calls_log.append({
                                "tool_name": tool_name,
                                "tool_input": tool_input,
                                "success": False,
                                "error": str(e),
                                "duration_ms": tool_call_duration
                            })
                            
                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": tool_id,
                                "content": json.dumps({"success": False, "error": str(e)})
                            })
                    else:
                        # Tool not found in TOOL_FUNCTIONS
                        print(f"   ❌ Error: Tool '{tool_name}' not found in TOOL_FUNCTIONS")
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_id,
                            "content": json.dumps({"success": False, "error": f"Tool '{tool_name}' not found"})
                        })
            
            # Send tool results back to Claude for next iteration
            messages.append({
                "role": "assistant",
                "content": response_body['content']
            })
            
            messages.append({
                "role": "user",
                "content": tool_results
            })
            
            # Continue to next iteration
            continue
        else:
            print(f"⚠️ Unexpected stop_reason: {stop_reason}")
            break
    
    # Extract final answer from last response
    # Note: chart_data and data_source are already set during tool execution
    
    # Extract answer
    full_response = ""
    for content_block in response_body['content']:
        if content_block.get('type') == 'text':
            full_response += content_block['text']
    
    print(f"✅ Generated response ({len(full_response)} chars)")
    
    # Extract audio summary
    if "---AUDIO_SUMMARY---" in full_response:
        parts = full_response.split("---AUDIO_SUMMARY---")
        answer = parts[0].strip()
        audio_summary = parts[1].strip() if len(parts) > 1 else ""
        audio_summary = audio_summary.replace('**', '').replace('*', '').replace('#', '').strip()
    else:
        answer = full_response
        sentences = answer.split('.')
        audio_summary = '. '.join(sentences[:2]) + '.' if len(sentences) >= 2 else answer
    
    if return_tool_calls:
        return answer, chart_data, audio_summary, data_source, tool_calls_log
    else:
        return answer, chart_data, audio_summary, data_source
