#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Novartis DynamoDB Query Functions - V6 (With Python Helper Functions)

V6 Changes (NEW):
- Exported helper functions (deduplicate_and_sum, simple_sum) for use as LLM tools
- These functions are now callable by the agent handler as tools
- Enables LLM to decide when to use deduplication vs simple aggregation
- Reduces token usage and improves reliability

V6 Changes:
- Calls table: Novartis_Calls_v6 with 7 GSIs (GSI1-3, GSI5-7)
- Rome table: Novartis_Rome_v6 with 6 GSIs (GSI1-6)
- Rome aggregated tables: HYBRID APPROACH for optimal performance
- SFastest query times for all common questions
- Other tables remain V3 (Sales, Market, Doses)

ROME AGGREGATED TABLES - HYBRID OPTIMIZATION:
==============================================
1. Rome_NewPatientStarts_Monthly:
   - Stores: unique_order_count + order_list (HYBRID)
   - Reason: Q1-Q4, Q8 aggregate across territories/areas (need deduplication)
   - Usage: Deduplicate order_list in Python for cross-dimension queries

2. Rome_NewPatientOrders_Monthly:
   - Stores: unique_order_count + order_list (HYBRID)
   - Reason: Q7 aggregates across territories (need deduplication)
   - Usage: Deduplicate order_list in Python for cross-dimension queries

3. Rome_AllOrders_Monthly:
   - Stores: unique_order_count, delivered_order_count (COUNTS ONLY)
   - Reason: Q5-Q6, Q9, Q14-Q16 aggregate by site (no cross-dimension issue)
   - Usage: Simple sum of counts (no deduplication needed)

4. Rome_SiteStatus_Quarterly:
   - Stores: unique_order_count, delivered_order_count (COUNTS ONLY)
   - Reason: Q10-Q13 don't need order counts (just site attributes)
   - Usage: Simple sum or site attribute filtering

PERFORMANCE IMPACT:
- Q1-Q4, Q7-Q8: Still fast (<2s), accurate with deduplication
- Q5-Q6, Q9, Q14-Q16: 75% faster (7-8s → <2s) with pre-computed counts
- Q10-Q13: Fastest (<0.5s) with ProjectionExpression
"""

import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
import json
import os

# AWS Configuration
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'utils', 'aws'))
from aws_utils import get_aws_resource

# Initialize DynamoDB resource
dynamodb = get_aws_resource('dynamodb')

# Table references - All V6_FINAL
sales_table = dynamodb.Table('Novartis_Sales_Finance_v6_final')
market_table = dynamodb.Table('Novartis_Market_Share_v6_final')
doses_table = dynamodb.Table('Novartis_Doses_v6_final')
calls_table = dynamodb.Table('Novartis_Calls_v6_final')
rome_table = dynamodb.Table('Novartis_Rome_v6_final')

def decimal_to_float(obj):
    """Convert Decimal to float for JSON serialization"""
    if isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_float(i) for i in obj]
    return obj

# ============================================================================
# HELPER FUNCTIONS FOR PRE-COMPUTED COUNTS OPTIMIZATION
# ============================================================================

# Month number to name mapping
MONTH_NAMES = {
    1: 'January', 2: 'February', 3: 'March', 4: 'April',
    5: 'May', 6: 'June', 7: 'July', 8: 'August',
    9: 'September', 10: 'October', 11: 'November', 12: 'December'
}

def deduplicate_and_sum(items, group_by_field, count_field='unique_order_count', order_list_field='order_list'):
    """
    Deduplicate orders across dimension combinations and sum counts.
    
    Used for tables with HYBRID approach (order_list + counts):
    - Rome_NewPatientStarts_Monthly (Q1-Q4, Q8)
    - Rome_NewPatientOrders_Monthly (Q7)
    
    Args:
        items: List of aggregated records
        group_by_field: Field to group by (e.g., 'site_type', 'month', 'area')
        count_field: Count field name (default: 'unique_order_count')
        order_list_field: Order list field name (default: 'order_list')
    
    Returns:
        dict: {group_value: unique_count}
    
    Example:
        # Q1: Academic vs Community split
        totals = deduplicate_and_sum(items, 'site_type')
        # Returns: {'ACADEMIC': 1234, 'COMMUNITY': 5678}
    """
    from collections import defaultdict
    
    # PHASE 1 FIX: Convert month numbers to month names if grouping by month
    if group_by_field == 'month':
        for item in items:
            month_num = int(float(item.get('month', 0)))
            item['month_name'] = MONTH_NAMES.get(month_num, 'UNKNOWN')
        group_by_field = 'month_name'
    
    # PHASE 3 FIX: Deduplicate across ALL records using set union
    # This ensures each order is counted only once even if it appears in multiple records
    groups = defaultdict(set)
    for item in items:
        group_value = item.get(group_by_field, 'UNKNOWN')
        order_list = item.get(order_list_field, [])
        groups[group_value].update(order_list)
    
    # Convert sets to counts
    return {k: len(v) for k, v in groups.items()}


def simple_sum(items, group_by_field, count_field='unique_order_count', filter_by=None):
    """
    Simple sum of pre-computed counts (no deduplication needed).
    
    Used for tables with COUNTS ONLY approach:
    - Rome_AllOrders_Monthly (Q5-Q6, Q9, Q14-Q16)
    - Rome_SiteStatus_Quarterly (Q10-Q13)
    
    Args:
        items: List of aggregated records
        group_by_field: Field to group by (e.g., 'site_type', 'month')
        count_field: Count field name (default: 'unique_order_count')
        filter_by: Optional dict of field:value pairs to filter by (e.g., {'month': 10})
    
    Returns:
        dict: {group_value: total_count}
    
    Example:
        # Q5: Academic vs Community split (delivered orders)
        totals = simple_sum(items, 'site_type', 'delivered_order_count')
        # Returns: {'ACADEMIC': 1234, 'COMMUNITY': 5678}
        
        # Q9: Top sites in October only
        totals = simple_sum(items, 'site_id', 'unique_order_count', filter_by={'month': 10})
    """
    from collections import defaultdict
    
    # PHASE 2 FIX: Apply filters if provided
    if filter_by:
        filtered_items = []
        for item in items:
            match = all(item.get(k) == v for k, v in filter_by.items())
            if match:
                filtered_items.append(item)
        items = filtered_items
    
    # PHASE 1 FIX: Convert month numbers to month names if grouping by month
    if group_by_field == 'month':
        for item in items:
            month_num = int(float(item.get('month', 0)))
            item['month_name'] = MONTH_NAMES.get(month_num, 'UNKNOWN')
        group_by_field = 'month_name'
    
    totals = defaultdict(int)
    for item in items:
        group_value = item.get(group_by_field, 'UNKNOWN')
        count = item.get(count_field, 0)
        totals[group_value] += count
    
    return dict(totals)


# ============================================================================
# UNIVERSAL AGGREGATION TOOL FOR SALES/MARKET/DOSES
# ============================================================================

def aggregate_by_dimensions(items, group_by=None, sum_fields=None, filters=None):
    """
    Universal aggregation tool for Sales, Market, and Doses data.
    
    This tool handles all aggregation patterns:
    - YTD calculations (group by year, forecast_type)
    - MoM trends (group by month)
    - YoY comparisons (group by year)
    - Quarterly analysis (group by quarter)
    - Product breakdowns (group by product)
    - Market share by brand (group by brand)
    
    Args:
        items: List of records from DynamoDB query
        group_by: List of fields to group by (e.g., ['product', 'year'])
                 If None or empty, aggregates all records into single total
        sum_fields: List of numeric fields to sum (default: ['net_sales'])
        filters: Optional dict to filter records before aggregation
                Example: {'product': 'PLUVICTO'} or {'product': '!PLUVICTO'} (exclude)
    
    Returns:
        dict: Aggregated results
              - If group_by is empty: {'total': {field1: sum1, field2: sum2}}
              - If group_by has 1 field: {value1: {field1: sum1}, value2: {field1: sum1}}
              - If group_by has 2+ fields: {(val1, val2): {field1: sum1}, ...}
    
    Examples:
        # YTD by forecast type
        aggregate_by_dimensions(items, group_by=['forecast_type'], sum_fields=['net_sales'])
        # Returns: {'ACTUALS': {'net_sales': 1838.1M}, 'BUDGET': {'net_sales': 1841.8M}}
        
        # MoM trend
        aggregate_by_dimensions(items, group_by=['month'], sum_fields=['net_sales'])
        # Returns: {1: {'net_sales': 158.9M}, 2: {'net_sales': 156.1M}, ...}
        
        # Product breakdown
        aggregate_by_dimensions(items, group_by=['product'], sum_fields=['net_sales'])
        # Returns: {'PLUVICTO': {'net_sales': 963.6M}, 'LUTATHERA': {...}, ...}
        
        # Total only (no grouping)
        aggregate_by_dimensions(items, sum_fields=['net_sales', 'gross_sales'])
        # Returns: {'total': {'net_sales': 1838.1M, 'gross_sales': 2100.5M}}
        
        # Filter to PLUVICTO only
        aggregate_by_dimensions(items, group_by=['year'], sum_fields=['net_sales'], 
                               filters={'product': 'PLUVICTO'})
    """
    from collections import defaultdict
    
    # Default parameters
    if group_by is None:
        group_by = []
    if sum_fields is None:
        sum_fields = ['net_sales']
    
    # Apply filters if provided
    if filters:
        filtered_items = []
        for item in items:
            include = True
            for field, value in filters.items():
                item_value = item.get(field)
                # Support exclusion with ! prefix
                if isinstance(value, str) and value.startswith('!'):
                    exclude_value = value[1:]
                    if item_value == exclude_value:
                        include = False
                        break
                else:
                    if item_value != value:
                        include = False
                        break
            if include:
                filtered_items.append(item)
        items = filtered_items
    
    # Initialize aggregation structure
    if len(group_by) == 0:
        # No grouping - single total
        totals = defaultdict(float)
        for item in items:
            for field in sum_fields:
                value = item.get(field, 0)
                if value is not None:
                    totals[field] += float(value)
        return {'total': dict(totals)}
    
    elif len(group_by) == 1:
        # Single dimension grouping
        field = group_by[0]
        aggregated = defaultdict(lambda: defaultdict(float))
        
        for item in items:
            key = item.get(field, 'UNKNOWN')
            # Convert month numbers to names for readability
            if field == 'month' and isinstance(key, (int, float)):
                key = MONTH_NAMES.get(int(key), f'Month {int(key)}')
            
            for sum_field in sum_fields:
                value = item.get(sum_field, 0)
                if value is not None:
                    aggregated[key][sum_field] += float(value)
        
        # Convert to regular dict
        return {k: dict(v) for k, v in aggregated.items()}
    
    else:
        # Multi-dimension grouping
        aggregated = defaultdict(lambda: defaultdict(float))
        
        for item in items:
            # Create composite key
            key_parts = []
            for field in group_by:
                value = item.get(field, 'UNKNOWN')
                # Convert month numbers to names
                if field == 'month' and isinstance(value, (int, float)):
                    value = MONTH_NAMES.get(int(value), f'Month {int(value)}')
                key_parts.append(value)
            key = tuple(key_parts)
            
            for sum_field in sum_fields:
                value = item.get(sum_field, 0)
                if value is not None:
                    aggregated[key][sum_field] += float(value)
        
        # Convert tuple keys to string keys for JSON serialization
        # Format: "2024|ACTUALS" instead of (2024, 'ACTUALS')
        return {'|'.join(str(k) for k in key): dict(v) for key, v in aggregated.items()}


# Month name mapping for readability
MONTH_NAMES = {
    1: 'January', 2: 'February', 3: 'March', 4: 'April',
    5: 'May', 6: 'June', 7: 'July', 8: 'August',
    9: 'September', 10: 'October', 11: 'November', 12: 'December'
}


# Copy Sales, Market, Doses, Rome functions from V4 (unchanged)
def query_sales_finance_table(filters=None):
    """Query SALES_FINANCE_BPC_corrected table - V6 (updated for v6 tables)"""
    try:
        filters = filters or {}
        items = []
        used_query = False
        
        products = filters.get('products', [])
        forecast_types = filters.get('forecast_types', [])
        
        if products and len(products) <= 5:
            used_query = True
            for product in products:
                product_upper = product.upper()
                pk_value = f"PRODUCT#{product_upper}"  # V6 uses PRODUCT# prefix
                
                response = sales_table.query(KeyConditionExpression=Key('PK').eq(pk_value))
                items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    response = sales_table.query(
                        KeyConditionExpression=Key('PK').eq(pk_value),
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                    items.extend(response.get('Items', []))
        else:
            response = sales_table.scan()
            items = response.get('Items', [])
            
            while 'LastEvaluatedKey' in response:
                response = sales_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                items.extend(response.get('Items', []))
        
        # Apply filters
        if 'products' in filters and not used_query:
            uppercase_products = [p.upper() for p in filters['products']]
            items = [i for i in items if i.get('product') in uppercase_products]
        
        if 'forecast_types' in filters:
            uppercase_forecast_types = [f.upper() for f in filters['forecast_types']]
            items = [i for i in items if i.get('forecast_type') in uppercase_forecast_types]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying sales table: {e}")
        return []

def query_doses_table(filters=None):
    """Query FCT_DOSES_PLU_corrected table - V3 (unchanged from V4)"""
    try:
        filters = filters or {}
        items = []
        used_query = False
        
        products = filters.get('products', [])
        metrics = filters.get('metrics', [])
        
        if products and metrics and len(products) <= 5 and len(metrics) <= 5:
            used_query = True
            for product in products:
                for metric in metrics:
                    product_upper = product.upper()
                    metric_upper = metric.upper()
                    pk_value = f"BRAND#{product_upper}#METRIC#{metric_upper}"
                    
                    response = doses_table.query(KeyConditionExpression=Key('PK').eq(pk_value))
                    items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        response = doses_table.query(
                            KeyConditionExpression=Key('PK').eq(pk_value),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                        items.extend(response.get('Items', []))
        else:
            response = doses_table.scan()
            items = response.get('Items', [])
            
            while 'LastEvaluatedKey' in response:
                response = doses_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                items.extend(response.get('Items', []))
        
        # Apply filters
        if 'products' in filters and not used_query:
            uppercase_products = [p.upper() for p in filters['products']]
            items = [i for i in items if i.get('brand') in uppercase_products]
        
        if 'metrics' in filters and not used_query:
            uppercase_metrics = [m.upper() for m in filters['metrics']]
            items = [i for i in items if i.get('metric') in uppercase_metrics]
        
        if 'forecast_types' in filters:
            uppercase_forecast_types = [f.upper() for f in filters['forecast_types']]
            items = [i for i in items if i.get('forecast_type') in uppercase_forecast_types]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'quarter_rel_index' in filters:
            items = [i for i in items if i.get('quarter_rel_index') == filters['quarter_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying doses table: {e}")
        return []

def query_market_share_table(filters=None):
    """Query FCT_MARKET_PLU_corrected table - V3 (unchanged from V4)"""
    try:
        filters = filters or {}
        items = []
        used_query = False
        
        brands = filters.get('brands', [])
        
        if brands and len(brands) <= 10:
            used_query = True
            for brand in brands:
                brand_upper = brand.upper()
                pk_value = f"BRAND#{brand_upper}"
                
                response = market_table.query(KeyConditionExpression=Key('PK').eq(pk_value))
                items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    response = market_table.query(
                        KeyConditionExpression=Key('PK').eq(pk_value),
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                    items.extend(response.get('Items', []))
        else:
            response = market_table.scan()
            items = response.get('Items', [])
            
            while 'LastEvaluatedKey' in response:
                response = market_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                items.extend(response.get('Items', []))
        
        # Apply filters
        if 'brands' in filters and not used_query:
            uppercase_brands = [b.upper() for b in filters['brands']]
            items = [i for i in items if i.get('brand') in uppercase_brands]
        
        if 'year' in filters:
            items = [i for i in items if i.get('year') == filters['year']]
        
        if 'start_date' in filters:
            items = [i for i in items if i.get('date') >= filters['start_date']]
        
        if 'end_date' in filters:
            items = [i for i in items if i.get('date') <= filters['end_date']]
        
        if 'year_rel_index' in filters:
            items = [i for i in items if i.get('year_rel_index') == filters['year_rel_index']]
        
        if 'month_rel_index' in filters:
            items = [i for i in items if i.get('month_rel_index') == filters['month_rel_index']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying market share table: {e}")
        return []

def query_calls_table(filters=None):
    """
    Query FCT_CALLS table - V5 with optimized GSI design
    
    V5 GSI Structure:
        GSI5PK: {PRODUCT}#{YEAR}#{TIER}#{GEO_LEVEL}#{METRIC_TYPE} (MOST IMPORTANT - 80% of queries)
        GSI5SK: {GEO_NAME}#{TIME_PERIOD}
        
        GSI6PK: {PRODUCT}#{GEO_LEVEL}#{GEO_NAME}#{METRIC_TYPE} (Geography-specific)
        GSI6SK: {YEAR}#{QUARTER}#{TIER}
        
        GSI7PK: {PRODUCT}#{TIER}#{METRIC_TYPE} (Tier-specific)
        GSI7SK: {YEAR}#{QUARTER}#{GEO_LEVEL}
        
        GSI1-3: Time-based, Product+Tier, Geography (legacy support)
    
    DEFAULTS (applied automatically):
        - product: 'Pluvicto' (if not specified)
        - year: 2025 (if not specified)
    
    Query Routing Logic:
        1. GSI5: Product + Year + Tier + GeoLevel + Metric (80% of queries, <1000 records)
        2. GSI6: Product + GeoLevel + GeoName + Metric (geography-specific)
        3. GSI7: Product + Tier + Metric (tier-specific)
        4. GSI2: Product + Tier (fallback)
        5. GSI1: Time-based (fallback)
    
    Returns:
        list: All matching records with sub-second performance
    """
    try:
        filters = filters or {}
        items = []
        
        # Apply defaults
        if 'products' not in filters or not filters['products']:
            filters['products'] = ['Pluvicto']
            print(f"   ℹ️  Applied default product: Pluvicto")
        
        if 'year' not in filters:
            filters['year'] = 2025
            print(f"   ℹ️  Applied default year: 2025")
        
        # Extract filter parameters
        has_product = bool(filters.get('products'))
        has_year = bool(filters.get('year'))
        has_tier = bool(filters.get('tiers'))
        has_geo_level = bool(filters.get('geo_level'))
        has_geo_name = bool(filters.get('geo_name'))
        has_metric = bool(filters.get('metric_type'))
        
        # PRIORITY 1: GSI5 (Product + Year + Tier + GeoLevel + Metric) - MOST SPECIFIC
        if has_product and has_year and has_tier and has_geo_level and has_metric:
            print(f"   ✅ Using GSI5 (Product+Year+Tier+GeoLevel+Metric) - FASTEST (<500ms)")
            items = _query_calls_gsi5(filters)
        
        # PRIORITY 2: GSI6 (Product + GeoLevel + GeoName + Metric) - Geography-specific
        elif has_product and has_geo_level and has_geo_name and has_metric:
            print(f"   ✅ Using GSI6 (Product+GeoLevel+GeoName+Metric) - FAST (<1s)")
            items = _query_calls_gsi6(filters)
        
        # PRIORITY 3: GSI7 (Product + Tier + Metric) - Tier-specific
        elif has_product and has_tier and has_metric:
            print(f"   ✅ Using GSI7 (Product+Tier+Metric) - FAST (<1s)")
            items = _query_calls_gsi7(filters)
        
        # PRIORITY 4: GSI2 (Product + Tier) - Fallback
        elif has_product and has_tier:
            print(f"   ⚠️  Using GSI2 (Product+Tier) - MEDIUM (1-3s)")
            items = _query_calls_gsi2(filters)
        
        # PRIORITY 5: GSI1 (Time-based) - Fallback
        elif has_year:
            print(f"   ⚠️  Using GSI1 (Time-based) - SLOW (5-10s)")
            items = _query_calls_gsi1(filters)
        
        # FALLBACK: SCAN (should never happen with defaults)
        else:
            print(f"   ❌ Using SCAN - VERY SLOW (>30s)")
            items = _query_calls_scan(filters)
        
        # Apply additional Python filters
        items = _apply_python_filters(items, filters)
        
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"Error querying calls table: {e}")
        return []

def _query_calls_gsi5(filters):
    """
    Query using GSI5: Product+Year+Tier+GeoLevel+Metric (MOST IMPORTANT)
    
    This handles 80% of queries with <1000 records returned.
    Example: "What is CPD by Region for All Tiers in 2020?"
    Returns only 688 records instead of 81,872.
    
    GSI5PK: {PRODUCT}#{YEAR}#{TIER}#{GEO_LEVEL}#{METRIC_TYPE}
    GSI5SK: {TIME_PERIOD}#{CYCLE_REL_INDEX}
    """
    items = []
    products = filters['products']
    year = filters['year']
    tiers = filters['tiers']
    geo_level = filters['geo_level'].upper()
    metric_type = filters['metric_type']
    
    # Get time_period and cycle_rel_index from filters (with defaults)
    time_period = filters.get('time_period', 'QTD').upper()
    cycle_rel_index = filters.get('cycle_rel_index', 1000)
    
    for product in products:
        for tier in tiers:
            product_upper = product.upper()
            gsi5pk = f"{product_upper}#{year}#{tier}#{geo_level}#{metric_type}"
            gsi5sk = f"{time_period}#{cycle_rel_index}"
            
            # Query with both PK and SK for exact filtering
            response = calls_table.query(
                IndexName='GSI5',
                KeyConditionExpression=Key('GSI5PK').eq(gsi5pk) & Key('GSI5SK').eq(gsi5sk)
            )
            items.extend(response.get('Items', []))
            
            while 'LastEvaluatedKey' in response:
                response = calls_table.query(
                    IndexName='GSI5',
                    KeyConditionExpression=Key('GSI5PK').eq(gsi5pk) & Key('GSI5SK').eq(gsi5sk),
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                items.extend(response.get('Items', []))
    
    return items


def _query_calls_gsi6(filters):
    """
    Query using GSI6: Product+GeoLevel+GeoName+Metric (Geography-specific)
    
    Example: "Show CPD for Central Region over time"
    """
    items = []
    products = filters['products']
    geo_level = filters['geo_level'].upper()
    geo_name = filters['geo_name'].upper()
    metric_type = filters['metric_type']
    
    for product in products:
        product_upper = product.upper()
        gsi6pk = f"{product_upper}#{geo_level}#{geo_name}#{metric_type}"
        
        response = calls_table.query(
            IndexName='GSI6',
            KeyConditionExpression=Key('GSI6PK').eq(gsi6pk)
        )
        items.extend(response.get('Items', []))
        
        while 'LastEvaluatedKey' in response:
            response = calls_table.query(
                IndexName='GSI6',
                KeyConditionExpression=Key('GSI6PK').eq(gsi6pk),
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))
    
    return items


def _query_calls_gsi7(filters):
    """
    Query using GSI7: Product+Tier+Metric (Tier-specific)
    
    Example: "Show CPD for T1 across all regions"
    """
    items = []
    products = filters['products']
    tiers = filters['tiers']
    metric_type = filters['metric_type']
    
    for product in products:
        for tier in tiers:
            product_upper = product.upper()
            gsi7pk = f"{product_upper}#{tier}#{metric_type}"
            
            response = calls_table.query(
                IndexName='GSI7',
                KeyConditionExpression=Key('GSI7PK').eq(gsi7pk)
            )
            items.extend(response.get('Items', []))
            
            while 'LastEvaluatedKey' in response:
                response = calls_table.query(
                    IndexName='GSI7',
                    KeyConditionExpression=Key('GSI7PK').eq(gsi7pk),
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                items.extend(response.get('Items', []))
    
    return items

def _query_calls_gsi1(filters):
    """Query using GSI1: Time-based queries (fallback)"""
    items = []
    year = filters['year']
    
    for month in range(1, 13):
        gsi1pk_value = f"DATE#{year}-{month:02d}"
        
        response = calls_table.query(
            IndexName='GSI1',
            KeyConditionExpression=Key('GSI1PK').eq(gsi1pk_value)
        )
        items.extend(response.get('Items', []))
        
        while 'LastEvaluatedKey' in response:
            response = calls_table.query(
                IndexName='GSI1',
                KeyConditionExpression=Key('GSI1PK').eq(gsi1pk_value),
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))
    
    return items


def _query_calls_gsi2(filters):
    """Query using GSI2: Product + Tier queries (fallback)"""
    items = []
    products = filters['products']
    tiers = filters.get('tiers', ['All Tiers Except NT'])
    
    for product in products:
        for tier in tiers:
            product_upper = product.upper()
            gsi2pk = f"{product_upper}#{tier}"
            
            response = calls_table.query(
                IndexName='GSI2',
                KeyConditionExpression=Key('GSI2PK').eq(gsi2pk)
            )
            items.extend(response.get('Items', []))
            
            while 'LastEvaluatedKey' in response:
                response = calls_table.query(
                    IndexName='GSI2',
                    KeyConditionExpression=Key('GSI2PK').eq(gsi2pk),
                    ExclusiveStartKey=response['LastEvaluatedKey']
                )
                items.extend(response.get('Items', []))
    
    return items


def _query_calls_scan(filters):
    """Fallback: Full table scan (should never happen with defaults)"""
    items = []
    response = calls_table.scan()
    items = response.get('Items', [])
    
    while 'LastEvaluatedKey' in response:
        response = calls_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response.get('Items', []))
    
    return items


def _apply_python_filters(items, filters):
    """Apply additional filters in Python after GSI query"""
    
    if 'products' in filters:
        uppercase_products = [p.upper() for p in filters['products']]
        items = [i for i in items if i.get('product') in uppercase_products]
    
    if 'tiers' in filters:
        items = [i for i in items if i.get('dim_tier') in filters['tiers']]
    
    if 'geo_level' in filters:
        items = [i for i in items if i.get('dim_geo_level') == filters['geo_level'].upper()]
    
    if 'geo_name' in filters:
        items = [i for i in items if i.get('dim_geo_name') == filters['geo_name'].upper()]
    
    if 'metric_type' in filters:
        items = [i for i in items if i.get('dim_metric_type') == filters['metric_type']]
    
    if 'time_period' in filters:
        items = [i for i in items if i.get('dim_time_period') == filters['time_period'].upper()]
    
    if 'year_quarter' in filters:
        items = [i for i in items if i.get('year_quarter') == filters['year_quarter']]
    
    if 'cycle_rel_index' in filters:
        items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
    
    if 'start_date' in filters:
        items = [i for i in items if i.get('period_end_date') >= filters['start_date']]
    
    if 'end_date' in filters:
        items = [i for i in items if i.get('period_end_date') <= filters['end_date']]
    
    return items

def query_rome_table(filters=None):
    """
    Query FCT_ROME_PLU table - V5 (Optimized with 6 GSIs)
    
    GSI Strategy:
    - GSI1: DATE#{YYYY-MM} → Monthly queries
    - GSI2: SITE#{SITE_ID} → Site-based queries
    - GSI3: {GEO_LEVEL}#{GEO_NAME} → Geography queries
    - GSI4: {SITE_TYPE}#{IS_FIRST_DOSE} → New patient starts
    - GSI5: {ORDER_STATUS}#{GEO_LEVEL}#{GEO_NAME} → Shipped doses by territory
    - GSI6: {ACCOUNT_STATUS}#{ACTIVE_DORMANT_FLAG} → Onboarded/dormant sites
    
    Performance: 95%+ faster than V3 (30-60s → <2s)
    """
    try:
        filters = filters or {}
        items = []
        used_gsi = None
        
        # Extract common filters
        products = filters.get('products', [])
        year = filters.get('year')
        years = filters.get('years')  # NEW: Array of years for parallel queries
        month = filters.get('month')
        territories = filters.get('territories', [])
        regions = filters.get('regions', [])
        areas = filters.get('areas', [])
        site_ids = filters.get('site_ids', [])
        site_type = filters.get('site_type')
        is_first_dose = filters.get('is_first_dose')
        order_status = filters.get('order_status')
        account_status = filters.get('account_status')
        active_dormant = filters.get('active_dormant')
        
        # Handle multi-year queries with parallelization
        if years and len(years) > 1:
            print(f"   🔄 Parallel query for {len(years)} years: {years}")
            
            from concurrent.futures import ThreadPoolExecutor, as_completed
            
            # Create a copy of filters for each year
            def query_single_year(y):
                year_filters = filters.copy()
                year_filters['year'] = y
                year_filters.pop('years', None)  # Remove years array
                return query_rome_table(year_filters)
            
            # Execute queries in parallel
            with ThreadPoolExecutor(max_workers=len(years)) as executor:
                future_to_year = {executor.submit(query_single_year, y): y for y in years}
                
                for future in as_completed(future_to_year):
                    year_results = future.result()
                    items.extend(year_results)
            
            print(f"   ✅ Parallel queries returned {len(items)} total records")
            return decimal_to_float(items)
        
        # If years array with single year, convert to year parameter
        if years and len(years) == 1:
            year = years[0]
        
        # GSI4: Site Type + First Dose (NEW PATIENT STARTS)
        # Best for: Q1, Q4, Q8, Q17 - new patient starts by site type
        # ALSO USED FOR: Year-only queries with is_first_dose (faster than GSI1's 12 queries)
        if (site_type and is_first_dose is not None) or (year and is_first_dose is not None and not month and not site_type):
            used_gsi = 'GSI4'
            first_dose_str = 'TRUE' if is_first_dose else 'FALSE'
            
            # Handle site_type as array or single value
            # If no site_type provided, query both ACADEMIC and COMMUNITY
            if site_type:
                site_types = site_type if isinstance(site_type, list) else [site_type]
            else:
                site_types = ['ACADEMIC', 'COMMUNITY']
                print(f"   ℹ️  No site_type provided, querying both ACADEMIC and COMMUNITY")
            
            print(f"   🔍 Using GSI4 (Site Type + First Dose): {site_types} + {first_dose_str}")
            
            # Build FilterExpression for additional filters
            filter_expr = None
            
            # Add product filter
            if products:
                filter_expr = Attr('PRODUCT').is_in([p.upper() for p in products])
            
            # Add order_status filter
            if order_status:
                status_filter = Attr('dim_order_status').eq(order_status)
                filter_expr = status_filter if filter_expr is None else filter_expr & status_filter
            
            for st in site_types:
                gsi4pk_value = f"{st}#{first_dose_str}"
                
                # Use SK to filter by year if provided (GSI4SK: {YEAR_QUARTER}#{ECOSYSTEM})
                if year:
                    if filter_expr:
                        response = rome_table.query(
                            IndexName='GSI4',
                            KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value) & Key('GSI4SK').begins_with(str(year)),
                            FilterExpression=filter_expr
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI4',
                            KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value) & Key('GSI4SK').begins_with(str(year))
                        )
                else:
                    if filter_expr:
                        response = rome_table.query(
                            IndexName='GSI4',
                            KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value),
                            FilterExpression=filter_expr
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI4',
                            KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value)
                        )
                
                items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    if year:
                        if filter_expr:
                            response = rome_table.query(
                                IndexName='GSI4',
                                KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value) & Key('GSI4SK').begins_with(str(year)),
                                FilterExpression=filter_expr,
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                        else:
                            response = rome_table.query(
                                IndexName='GSI4',
                                KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value) & Key('GSI4SK').begins_with(str(year)),
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                    else:
                        if filter_expr:
                            response = rome_table.query(
                                IndexName='GSI4',
                                KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value),
                                FilterExpression=filter_expr,
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                        else:
                            response = rome_table.query(
                                IndexName='GSI4',
                                KeyConditionExpression=Key('GSI4PK').eq(gsi4pk_value),
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                    items.extend(response.get('Items', []))
        
        # GSI6: Account Status + Active/Dormant (ONBOARDED/DORMANT SITES - FIXED)
        # Best for: Q10, Q11, Q12, Q13 - site status analysis
        # FIXED: Now has year in SK for better performance (50% faster)
        # GSI6SK: {YEAR}#{SITE_TYPE}#{ECOSYSTEM}#{TIER}
        elif account_status or active_dormant:
            used_gsi = 'GSI6'
            
            # GSI6PK requires both account_status AND active_dormant
            # If only one is provided, query all combinations
            if account_status and active_dormant:
                gsi6pk_value = f"{account_status}#{active_dormant}"
                print(f"   🔍 Using GSI6 (Account Status + Active/Dormant): {gsi6pk_value}")
                
                # Use SK to filter by year if provided (GSI6SK: {YEAR}#{SITE_TYPE})
                if year:
                    response = rome_table.query(
                        IndexName='GSI6',
                        KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value) & Key('GSI6SK').begins_with(str(year))
                    )
                else:
                    response = rome_table.query(
                        IndexName='GSI6',
                        KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value)
                    )
                
                items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    if year:
                        response = rome_table.query(
                            IndexName='GSI6',
                            KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value) & Key('GSI6SK').begins_with(str(year)),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI6',
                            KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    items.extend(response.get('Items', []))
            
            elif account_status:
                print(f"   🔍 Using GSI6 (Account Status): {account_status}")
                
                for dormant_flag in ['ACTIVE', 'DORMANT']:
                    gsi6pk_value = f"{account_status}#{dormant_flag}"
                    
                    if year:
                        response = rome_table.query(
                            IndexName='GSI6',
                            KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value) & Key('GSI6SK').begins_with(str(year))
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI6',
                            KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value)
                        )
                    
                    items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        if year:
                            response = rome_table.query(
                                IndexName='GSI6',
                                KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value) & Key('GSI6SK').begins_with(str(year)),
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                        else:
                            response = rome_table.query(
                                IndexName='GSI6',
                                KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value),
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                        items.extend(response.get('Items', []))
            
            else:
                print(f"   🔍 Using GSI6 (Dormant Flag): {active_dormant}")
                
                for acct_status in ['ONBOARDED', 'NOT ONBOARDED']:
                    gsi6pk_value = f"{acct_status}#{active_dormant}"
                    
                    if year:
                        response = rome_table.query(
                            IndexName='GSI6',
                            KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value) & Key('GSI6SK').begins_with(str(year))
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI6',
                            KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value)
                        )
                    
                    items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        if year:
                            response = rome_table.query(
                                IndexName='GSI6',
                                KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value) & Key('GSI6SK').begins_with(str(year)),
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                        else:
                            response = rome_table.query(
                                IndexName='GSI6',
                                KeyConditionExpression=Key('GSI6PK').eq(gsi6pk_value),
                                ExclusiveStartKey=response['LastEvaluatedKey']
                            )
                        items.extend(response.get('Items', []))
            
            if not year:
                print(f"   ⚠️  WARNING: No year provided, GSI6 will return ALL data (slow)")
                print(f"   💡 TIP: Always provide 'year' parameter for 50% faster queries")
        
        # GSI5: Order Status + Geography (SHIPPED DOSES BY TERRITORY)
        # Best for: Q14, Q15, Q16 - shipped dose volume by territory
        elif order_status and (territories or regions or areas):
            used_gsi = 'GSI5'
            
            # Determine geography level and names
            if territories:
                geo_level = 'TERRITORY'
                geo_names = territories
            elif areas:
                geo_level = 'AREA'
                geo_names = areas
            elif regions:
                geo_level = 'REGION'
                geo_names = regions
            else:
                geo_names = []
            
            print(f"   🔍 Using GSI5 (Order Status + Geography): {order_status}#{geo_level}")
            
            for geo_name in geo_names:
                gsi5pk_value = f"{order_status}#{geo_level}#{geo_name}"
                
                # Use SK to filter by year if provided (GSI5SK: {YEAR_QUARTER}#{SITE_ID})
                if year:
                    response = rome_table.query(
                        IndexName='GSI5',
                        KeyConditionExpression=Key('GSI5PK').eq(gsi5pk_value) & Key('GSI5SK').begins_with(str(year))
                    )
                else:
                    response = rome_table.query(
                        IndexName='GSI5',
                        KeyConditionExpression=Key('GSI5PK').eq(gsi5pk_value)
                    )
                
                items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    if year:
                        response = rome_table.query(
                            IndexName='GSI5',
                            KeyConditionExpression=Key('GSI5PK').eq(gsi5pk_value) & Key('GSI5SK').begins_with(str(year)),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI5',
                            KeyConditionExpression=Key('GSI5PK').eq(gsi5pk_value),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    items.extend(response.get('Items', []))
        
        # GSI3: Geography-based queries (TERRITORY/AREA/REGION PERFORMANCE)
        # Best for: Q3, Q7, Q14 - territory/area performance
        elif territories or regions or areas:
            used_gsi = 'GSI3'
            
            # Determine geography level and names
            if territories:
                geo_level = 'TERRITORY'
                geo_names = territories
            elif areas:
                geo_level = 'AREA'
                geo_names = areas
            elif regions:
                geo_level = 'REGION'
                geo_names = regions
            else:
                geo_names = []
            
            print(f"   🔍 Using GSI3 (Geography): {geo_level}")
            
            for geo_name in geo_names:
                gsi3pk_value = f"{geo_level}#{geo_name}"
                
                # Use SK to filter by year if provided (GSI3SK: {YEAR_QUARTER}#{SITE_TYPE})
                if year:
                    response = rome_table.query(
                        IndexName='GSI3',
                        KeyConditionExpression=Key('GSI3PK').eq(gsi3pk_value) & Key('GSI3SK').begins_with(str(year))
                    )
                else:
                    response = rome_table.query(
                        IndexName='GSI3',
                        KeyConditionExpression=Key('GSI3PK').eq(gsi3pk_value)
                    )
                
                items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    if year:
                        response = rome_table.query(
                            IndexName='GSI3',
                            KeyConditionExpression=Key('GSI3PK').eq(gsi3pk_value) & Key('GSI3SK').begins_with(str(year)),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI3',
                            KeyConditionExpression=Key('GSI3PK').eq(gsi3pk_value),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    items.extend(response.get('Items', []))
        
        # GSI2: Site-based queries (TOP SITES, SITE VOLUME)
        # Best for: Q9, Q15 - site volume analysis
        elif site_ids and len(site_ids) <= 20:
            used_gsi = 'GSI2'
            print(f"   🔍 Using GSI2 (Site IDs): {len(site_ids)} sites")
            
            for site_id in site_ids:
                gsi2pk_value = f"SITE#{site_id}"
                
                # Use SK to filter by year if provided (GSI2SK: {YEAR_QUARTER}#{ORDER_STATUS})
                if year:
                    response = rome_table.query(
                        IndexName='GSI2',
                        KeyConditionExpression=Key('GSI2PK').eq(gsi2pk_value) & Key('GSI2SK').begins_with(str(year))
                    )
                else:
                    response = rome_table.query(
                        IndexName='GSI2',
                        KeyConditionExpression=Key('GSI2PK').eq(gsi2pk_value)
                    )
                
                items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    if year:
                        response = rome_table.query(
                            IndexName='GSI2',
                            KeyConditionExpression=Key('GSI2PK').eq(gsi2pk_value) & Key('GSI2SK').begins_with(str(year)),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    else:
                        response = rome_table.query(
                            IndexName='GSI2',
                            KeyConditionExpression=Key('GSI2PK').eq(gsi2pk_value),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                    items.extend(response.get('Items', []))
        
        # GSI1: Time-based queries (MONTHLY VOLUME)
        # Best for: Q2, Q4, Q6 - monthly volume queries
        # NOTE: For year-only queries, prefer GSI4 and aggregate in Python (faster than 12 separate queries)
        elif year and month:
            used_gsi = 'GSI1'
            gsi1pk_value = f"DATE#{year}-{month:02d}"
            
            print(f"   🔍 Using GSI1 (Monthly): {gsi1pk_value}")
            
            # Build FilterExpression
            filter_expr = None
            if products:
                filter_expr = Attr('PRODUCT').is_in([p.upper() for p in products])
            if is_first_dose is not None:
                first_dose_str = 'TRUE' if is_first_dose else 'FALSE'
                dose_filter = Attr('is_patients_first_dose').eq(first_dose_str)
                filter_expr = dose_filter if filter_expr is None else filter_expr & dose_filter
            if order_status:
                status_filter = Attr('dim_order_status').eq(order_status)
                filter_expr = status_filter if filter_expr is None else filter_expr & status_filter
            
            if filter_expr:
                response = rome_table.query(
                    IndexName='GSI1',
                    KeyConditionExpression=Key('GSI1PK').eq(gsi1pk_value),
                    FilterExpression=filter_expr
                )
            else:
                response = rome_table.query(
                    IndexName='GSI1',
                    KeyConditionExpression=Key('GSI1PK').eq(gsi1pk_value)
                )
            
            items.extend(response.get('Items', []))
            
            while 'LastEvaluatedKey' in response:
                if filter_expr:
                    response = rome_table.query(
                        IndexName='GSI1',
                        KeyConditionExpression=Key('GSI1PK').eq(gsi1pk_value),
                        FilterExpression=filter_expr,
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                else:
                    response = rome_table.query(
                        IndexName='GSI1',
                        KeyConditionExpression=Key('GSI1PK').eq(gsi1pk_value),
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                items.extend(response.get('Items', []))
        
        # Primary Key: Product + Site (SPECIFIC PRODUCT-SITE QUERIES)
        elif products and site_ids and len(products) <= 5 and len(site_ids) <= 10:
            used_gsi = 'PK'
            print(f"   🔍 Using Primary Key (Product + Site): {len(products)} products, {len(site_ids)} sites")
            
            for product in products:
                for site_id in site_ids:
                    pk_value = f"{product.upper()}#{site_id}"
                    
                    response = rome_table.query(
                        KeyConditionExpression=Key('PK').eq(pk_value)
                    )
                    items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        response = rome_table.query(
                            KeyConditionExpression=Key('PK').eq(pk_value),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                        items.extend(response.get('Items', []))
        
        # Fallback: Full table scan (avoid if possible)
        else:
            print(f"   ⚠️  Using full table scan (no GSI matched)")
            response = rome_table.scan()
            items = response.get('Items', [])
            
            while 'LastEvaluatedKey' in response:
                response = rome_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
                items.extend(response.get('Items', []))
        
        # Apply post-query filters
        if products and used_gsi not in ['PK']:
            uppercase_products = [p.upper() for p in products]
            items = [i for i in items if i.get('PRODUCT') in uppercase_products]
        
        if territories and used_gsi not in ['GSI3', 'GSI5']:
            items = [i for i in items if i.get('dim_terr_name') in territories]
        
        if regions and used_gsi not in ['GSI3', 'GSI5']:
            items = [i for i in items if i.get('dim_region_name') in regions]
        
        if areas and used_gsi not in ['GSI3', 'GSI5']:
            items = [i for i in items if i.get('dim_area_name') in areas]
        
        if site_ids and used_gsi not in ['PK', 'GSI2']:
            items = [i for i in items if i.get('site_id') in site_ids]
        
        if active_dormant and used_gsi != 'GSI6':
            filter_value = active_dormant.upper()
            items = [i for i in items if i.get('active_dormant_flag') == filter_value]
        
        if order_status and used_gsi != 'GSI5':
            items = [i for i in items if i.get('dim_order_status') == order_status]
        
        if is_first_dose is not None and used_gsi != 'GSI4':
            first_dose_str = 'TRUE' if is_first_dose else 'FALSE'
            items = [i for i in items if i.get('is_patients_first_dose') == first_dose_str]
        
        if 'year_quarter' in filters:
            items = [i for i in items if i.get('year_quarter') == filters['year_quarter']]
        
        if 'cycle_rel_index' in filters:
            items = [i for i in items if i.get('cycle_rel_index') == filters['cycle_rel_index']]
        
        if 'start_date' in filters:
            start_date = filters['start_date']
            items = [i for i in items if i.get('dim_date', '')[:10] >= start_date]
        
        if 'end_date' in filters:
            end_date = filters['end_date']
            items = [i for i in items if i.get('dim_date', '')[:10] <= end_date]
        
        if 'dim_ecosystem' in filters:
            items = [i for i in items if i.get('dim_ecosystem') == filters['dim_ecosystem']]
        
        if 'dim_tier' in filters:
            items = [i for i in items if i.get('dim_tier') == filters['dim_tier']]
        
        if 'dim_order_type' in filters:
            items = [i for i in items if i.get('dim_order_type') == filters['dim_order_type']]
        
        # Suppress print during testing - uncomment for debugging
        # print(f"   ✅ Rome V5 query returned {len(items)} records using {used_gsi or 'SCAN'}")
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"❌ Error querying Rome V5 table: {e}")
        import traceback
        traceback.print_exc()
        return []


# Test function
if __name__ == '__main__':
    print("Testing V5 Query Functions with Optimized GSIs")
    print("="*80)
    
    # Test 1: Calls query using GSI5 (should be FAST)
    print("\n1. Calls per day by Region for all Tiers in 2020 (GSI5):")
    calls = query_calls_table({
        'products': ['Pluvicto'],
        'year': 2020,
        'tiers': ['All Tiers Except NT'],
        'geo_level': 'Region',
        'metric_type': 'CPD'
    })
    print(f"   Found {len(calls)} records")
    
    # Test 2: Sales query
    print("\n2. Pluvicto Sales 2025 (Actual):")
    sales = query_sales_finance_table({
        'products': ['PLUVICTO'],
        'year': 2025,
        'forecast_types': ['ACTUAL']
    })
    print(f"   Found {len(sales)} records")
    
    print("\n" + "="*80)
    print("✅ V5 Tests complete")


# ============================================================================
# AGGREGATED ROME TABLES - Fast Queries for 17 Rome Questions
# ============================================================================

def query_rome_new_patient_starts_aggregated(filters):
    """
    Query Rome_NewPatientStarts_Monthly aggregated table
    
    Used for examples like: Q1, Q2, Q3, Q4, Q8, Q17 (new patient start questions)
    
    Performance: <1s (pre-aggregated data)
    
    Filters:
    - products: List of products (default: ['PLUVICTO'])
    - year: Year filter (enables GSI1)
    - years: Array of years for multi-year queries
    - month: Month filter (1-12)
    - quarter: Quarter filter (Q1, Q2, Q3, Q4)
    - site_type: Site type filter (ACADEMIC, COMMUNITY)
    - territory: Territory name
    - area: Area name
    - region: Region name
    - ecosystem: Ecosystem filter (1A, 1B, 2A, 2B, 3)
    - tier: Tier filter (T1, T2, T3, NT)
    """
    try:
        table = dynamodb.Table('Rome_NewPatientStarts_Monthly_v6_final')
        
        # Default product to PLUVICTO
        products = filters.get('products', ['PLUVICTO'])
        
        all_items = []
        
        # Handle multi-year queries
        years = filters.get('years', [filters.get('year')] if filters.get('year') else [])
        
        for product in products:
            if years:
                # Query by year using GSI1 for fast filtering
                for year in years:
                    response = table.query(
                        IndexName='GSI1',
                        KeyConditionExpression=Key('GSI1PK').eq(f"YEAR#{year}")
                    )
                    all_items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        response = table.query(
                            IndexName='GSI1',
                            KeyConditionExpression=Key('GSI1PK').eq(f"YEAR#{year}"),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                        all_items.extend(response.get('Items', []))
            else:
                # Query by product (all years)
                response = table.query(
                    KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}")
                )
                all_items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    response = table.query(
                        KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}"),
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                    all_items.extend(response.get('Items', []))
        
        # Apply filters
        items = all_items
        
        if 'month' in filters:
            items = [i for i in items if i.get('month') == filters['month']]
        
        if 'quarter' in filters:
            items = [i for i in items if i.get('quarter') == filters['quarter']]
        
        if 'site_type' in filters:
            site_types = filters['site_type'] if isinstance(filters['site_type'], list) else [filters['site_type']]
            items = [i for i in items if i.get('site_type') in site_types]
        
        if 'territory' in filters:
            items = [i for i in items if i.get('territory') == filters['territory']]
        
        if 'area' in filters:
            items = [i for i in items if i.get('area') == filters['area']]
        
        if 'region' in filters:
            items = [i for i in items if i.get('region') == filters['region']]
        
        if 'ecosystem' in filters:
            items = [i for i in items if i.get('ecosystem') == filters['ecosystem']]
        
        if 'tier' in filters:
            items = [i for i in items if i.get('tier') == filters['tier']]
        
        # Suppress print during testing - uncomment for debugging
        # print(f"   ✅ NewPatientStarts aggregated query returned {len(items)} records")
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"❌ Error querying NewPatientStarts aggregated table: {e}")
        import traceback
        traceback.print_exc()
        return []


def query_rome_new_patient_orders_aggregated(filters):
    """
    Query Rome_NewPatientOrders_Monthly aggregated table
    
    Used for examples like: Q6, Q7 (new patient orders including open/cancelled)
    
    Performance: <1s (pre-aggregated data)
    
    Filters:
    - products: List of products (default: ['PLUVICTO'])
    - year: Year filter (enables GSI1)
    - years: Array of years for multi-year queries
    - month: Month filter (1-12)
    - quarter: Quarter filter (Q1, Q2, Q3, Q4)
    - site_type: Site type filter (ACADEMIC, COMMUNITY)
    - territory: Territory name
    - area: Area name
    - region: Region name
    - ecosystem: Ecosystem filter (1A, 1B, 2A, 2B, 3)
    - tier: Tier filter (T1, T2, T3, NT)
    """
    try:
        table = dynamodb.Table('Rome_NewPatientOrders_Monthly_v6_final')
        
        # Default product to PLUVICTO
        products = filters.get('products', ['PLUVICTO'])
        
        all_items = []
        
        # Handle multi-year queries
        years = filters.get('years', [filters.get('year')] if filters.get('year') else [])
        
        for product in products:
            if years:
                # Query by year using GSI1 for fast filtering
                for year in years:
                    response = table.query(
                        IndexName='GSI1',
                        KeyConditionExpression=Key('GSI1PK').eq(f"YEAR#{year}")
                    )
                    all_items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        response = table.query(
                            IndexName='GSI1',
                            KeyConditionExpression=Key('GSI1PK').eq(f"YEAR#{year}"),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                        all_items.extend(response.get('Items', []))
            else:
                # Query by product (all years)
                response = table.query(
                    KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}")
                )
                all_items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    response = table.query(
                        KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}"),
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                    all_items.extend(response.get('Items', []))
        
        # Apply filters
        items = all_items
        
        if 'month' in filters:
            items = [i for i in items if i.get('month') == filters['month']]
        
        if 'quarter' in filters:
            items = [i for i in items if i.get('quarter') == filters['quarter']]
        
        if 'site_type' in filters:
            site_types = filters['site_type'] if isinstance(filters['site_type'], list) else [filters['site_type']]
            items = [i for i in items if i.get('site_type') in site_types]
        
        if 'territory' in filters:
            items = [i for i in items if i.get('territory') == filters['territory']]
        
        if 'area' in filters:
            items = [i for i in items if i.get('area') == filters['area']]
        
        if 'region' in filters:
            items = [i for i in items if i.get('region') == filters['region']]
        
        if 'ecosystem' in filters:
            items = [i for i in items if i.get('ecosystem') == filters['ecosystem']]
        
        if 'tier' in filters:
            items = [i for i in items if i.get('tier') == filters['tier']]
        
        # Suppress print during testing - uncomment for debugging
        # print(f"   ✅ NewPatientOrders aggregated query returned {len(items)} records")
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"❌ Error querying NewPatientOrders aggregated table: {e}")
        import traceback
        traceback.print_exc()
        return []


def query_rome_all_orders_aggregated(filters):
    """
    Query Rome_AllOrders_Monthly aggregated table
    
    Used for examples like: Q5, Q6, Q7, Q9, Q14, Q15, Q16 (all orders questions)
    
    Performance: <1s (pre-aggregated data)
    
    Filters:
    - products: List of products (default: ['PLUVICTO'])
    - year: Year filter (enables GSI1)
    - years: Array of years for multi-year queries
    - month: Month filter (1-12)
    - quarter: Quarter filter (Q1, Q2, Q3, Q4)
    - site_id: Site ID filter
    - site_type: Site type filter (ACADEMIC, COMMUNITY)
    - territory: Territory name
    - area: Area name
    - region: Region name
    - ecosystem: Ecosystem filter (1A, 1B, 2A, 2B, 3)
    - tier: Tier filter (T1, T2, T3, NT)
    """
    try:
        table = dynamodb.Table('Rome_AllOrders_Monthly_v6_final')
        
        # Default product to PLUVICTO
        products = filters.get('products', ['PLUVICTO'])
        
        all_items = []
        
        # Handle multi-year queries
        years = filters.get('years', [filters.get('year')] if filters.get('year') else [])
        
        for product in products:
            if years:
                # Query by year using GSI1 for fast filtering
                for year in years:
                    response = table.query(
                        IndexName='GSI1',
                        KeyConditionExpression=Key('GSI1PK').eq(f"YEAR#{year}")
                    )
                    all_items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        response = table.query(
                            IndexName='GSI1',
                            KeyConditionExpression=Key('GSI1PK').eq(f"YEAR#{year}"),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                        all_items.extend(response.get('Items', []))
            else:
                # Query by product (all years)
                response = table.query(
                    KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}")
                )
                all_items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    response = table.query(
                        KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}"),
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                    all_items.extend(response.get('Items', []))
        
        # Apply filters
        items = all_items
        
        if 'month' in filters:
            items = [i for i in items if i.get('month') == filters['month']]
        
        if 'quarter' in filters:
            items = [i for i in items if i.get('quarter') == filters['quarter']]
        
        if 'site_id' in filters:
            site_ids = filters['site_id'] if isinstance(filters['site_id'], list) else [filters['site_id']]
            items = [i for i in items if i.get('site_id') in site_ids]
        
        if 'site_type' in filters:
            site_types = filters['site_type'] if isinstance(filters['site_type'], list) else [filters['site_type']]
            items = [i for i in items if i.get('site_type') in site_types]
        
        if 'territory' in filters:
            items = [i for i in items if i.get('territory') == filters['territory']]
        
        if 'area' in filters:
            items = [i for i in items if i.get('area') == filters['area']]
        
        if 'region' in filters:
            items = [i for i in items if i.get('region') == filters['region']]
        
        if 'ecosystem' in filters:
            items = [i for i in items if i.get('ecosystem') == filters['ecosystem']]
        
        if 'tier' in filters:
            items = [i for i in items if i.get('tier') == filters['tier']]
        
        # Suppress print during testing - uncomment for debugging
        # print(f"   ✅ AllOrders aggregated query returned {len(items)} records")
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"❌ Error querying AllOrders aggregated table: {e}")
        import traceback
        traceback.print_exc()
        return []


def query_rome_site_status_aggregated(filters):
    """
    Query Rome_SiteStatus_Quarterly aggregated table
    
    Used for examples like: Q10, Q11, Q12, Q13 (site status questions)
    
    Performance: <1s (pre-aggregated data)
    
    Filters:
    - products: List of products (default: ['PLUVICTO'])
    - year: Year filter (enables GSI1)
    - years: Array of years for multi-year queries
    - quarter: Quarter filter (Q1, Q2, Q3, Q4)
    - site_id: Site ID filter
    - site_type: Site type filter (ACADEMIC, COMMUNITY)
    - account_status: Account status (ONBOARDED, NOT ONBOARDED)
    - active_dormant: Activity status (ACTIVE, DORMANT)
    - ecosystem: Ecosystem filter (1A, 1B, 2A, 2B, 3)
    - tier: Tier filter (T1, T2, T3, NT)
    """
    try:
        table = dynamodb.Table('Rome_SiteStatus_Quarterly_v6_final')
        
        # Default product to PLUVICTO
        products = filters.get('products', ['PLUVICTO'])
        
        all_items = []
        
        # Handle multi-year queries
        years = filters.get('years', [filters.get('year')] if filters.get('year') else [])
        
        for product in products:
            if years:
                # Query by year using GSI2 for fast filtering
                for year in years:
                    response = table.query(
                        IndexName='GSI2',
                        KeyConditionExpression=Key('GSI2PK').eq(f"YEAR#{year}")
                    )
                    all_items.extend(response.get('Items', []))
                    
                    while 'LastEvaluatedKey' in response:
                        response = table.query(
                            IndexName='GSI2',
                            KeyConditionExpression=Key('GSI2PK').eq(f"YEAR#{year}"),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                        )
                        all_items.extend(response.get('Items', []))
            else:
                # Query by product (all years)
                response = table.query(
                    KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}")
                )
                all_items.extend(response.get('Items', []))
                
                while 'LastEvaluatedKey' in response:
                    response = table.query(
                        KeyConditionExpression=Key('PK').eq(f"PRODUCT#{product}"),
                        ExclusiveStartKey=response['LastEvaluatedKey']
                    )
                    all_items.extend(response.get('Items', []))
        
        # Apply filters
        items = all_items
        
        if 'quarter' in filters:
            items = [i for i in items if i.get('quarter') == filters['quarter']]
        
        if 'site_id' in filters:
            site_ids = filters['site_id'] if isinstance(filters['site_id'], list) else [filters['site_id']]
            items = [i for i in items if i.get('site_id') in site_ids]
        
        if 'site_type' in filters:
            site_types = filters['site_type'] if isinstance(filters['site_type'], list) else [filters['site_type']]
            items = [i for i in items if i.get('site_type') in site_types]
        
        if 'account_status' in filters:
            items = [i for i in items if i.get('account_status') == filters['account_status']]
        
        if 'active_dormant' in filters:
            items = [i for i in items if i.get('active_dormant') == filters['active_dormant']]
        
        if 'ecosystem' in filters:
            items = [i for i in items if i.get('ecosystem') == filters['ecosystem']]
        
        if 'tier' in filters:
            items = [i for i in items if i.get('tier') == filters['tier']]
        
        # Suppress print during testing - uncomment for debugging
        # print(f"   ✅ SiteStatus aggregated query returned {len(items)} records")
        return decimal_to_float(items)
    
    except Exception as e:
        print(f"❌ Error querying SiteStatus aggregated table: {e}")
        import traceback
        traceback.print_exc()
        return []
