#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Novartis Agent Handler - V2 (Table-Aligned)

Properly aligned with SME TABLE_ROUTING_GUIDE:
- 3 tools (one per main table)
- Claude does the analysis/aggregation
- DynamoDB does the filtering
- Much faster and simpler
"""

import json
import boto3
from botocore.config import Config

from backend_api.novartis_queries_v2 import (
    query_sales_finance_table,
    query_doses_table,
    query_market_share_table
)

# AWS clients
boto_config = Config(
    retries={'max_attempts': 3, 'mode': 'adaptive'},
    max_pool_connections=10
)

bedrock_runtime = boto3.client(
    'bedrock-runtime',
    region_name='us-east-1',
    config=boto_config
)

# Define 3 tools - one per table (following SME guidance)
NOVARTIS_TOOLS = [
    {
        "name": "query_sales_finance_table",
        "description": """Query SALES_FINANCE_BPC_corrected table for ALL sales/revenue questions.
        
USE THIS FOR:
- Revenue, net sales, gross sales, revenue deductions
- YTD, quarterly, monthly performance
- Actual vs Budget vs OC comparisons
- Year-over-year, month-over-month analysis
- Single product or portfolio-wide

RETURNS: All matching records with columns: brand, forecast_type, date, year, month, net_sales, gross_sales, revenue_deductions, year_rel_index, month_rel_index, cycle_rel_index

YOU analyze and aggregate the data - don't ask for pre-aggregated results.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "products": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"]},
                    "description": "Product names to filter (omit for all products)"
                },
                "forecast_types": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Actual", "Budget", "OC"]},
                    "description": "Forecast types (default: ['Actual'])"
                },
                "year": {
                    "type": "integer",
                    "description": "Specific year (2020-2028)"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    },
    {
        "name": "query_doses_table",
        "description": """Query FCT_DOSES_PLU_corrected table for ALL national-level dose questions.

USE THIS FOR:
- Shipped doses, injected doses, new patient (NBRX) metrics
- YTD, quarterly, monthly dose performance
- Actual vs Budget vs OC comparisons
- Year-over-year, month-over-month dose analysis
- Single product or all products

RETURNS: All matching records with columns: brand, metric (TRX_shipped/TRX_injected/NBRX), forecast_type, date, year, month, value, year_rel_index, month_rel_index, quarter_rel_index

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "products": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Pluvicto", "Lutathera", "Xofigo", "Novacure"]},
                    "description": "Product names (omit for all)"
                },
                "metrics": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["TRX_shipped", "TRX_injected", "NBRX"]},
                    "description": "Dose metrics (omit for all)"
                },
                "forecast_types": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Actual", "Budget", "OC"]},
                    "description": "Forecast types (default: ['Actual'])"
                },
                "year": {
                    "type": "integer",
                    "description": "Specific year"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    },
    {
        "name": "query_market_share_table",
        "description": """Query FCT_MARKET_PLU_corrected table for ALL market share and competitor questions.

USE THIS FOR:
- Market share analysis (TRX_SHARE_R3M, NBRX_SHARE_R3M)
- Competitor analysis and rankings
- Market volumes (TRX_R3M, NBRX_R3M)
- All brands including competitors

RETURNS: All matching records with columns: brand, date, year, month, TRX_R3M, TRX_SHARE_R3M, NBRX_R3M, NBRX_SHARE_R3M, year_rel_index, month_rel_index, cycle_rel_index

YOU analyze and aggregate the data.""",
        "input_schema": {
            "type": "object",
            "properties": {
                "brands": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Brand names including competitors (omit for all brands)"
                },
                "year": {
                    "type": "integer",
                    "description": "Specific year"
                },
                "start_date": {
                    "type": "string",
                    "description": "Start date YYYY-MM-DD"
                },
                "end_date": {
                    "type": "string",
                    "description": "End date YYYY-MM-DD"
                }
            }
        }
    }
]

SYSTEM_PROMPT = """You are an AI assistant for Novartis RLT Portfolio Monthly Business Review (MBR).

**CRITICAL - Data Architecture (from SME TABLE_ROUTING_GUIDE):**

You have access to 3 tables via 3 tools:
1. **SALES_FINANCE_BPC_corrected** → query_sales_finance_table
   - USE FOR: Revenue, sales, gross sales, revenue deductions
   - Products: Novartis portfolio only (Pluvicto, Lutathera, Xofigo, Novacure)
   
2. **FCT_DOSES_PLU_corrected** → query_doses_table
   - USE FOR: National-level doses (TRX_shipped, TRX_injected, NBRX)
   - Products: Novartis portfolio only
   
3. **FCT_MARKET_PLU_corrected** → query_market_share_table
   - USE FOR: Market share, competitors, market volumes
   - Brands: ALL including competitors

**TABLE ROUTING RULES (from SME):**
- Market share or competitors? → query_market_share_table (ALWAYS)
- Revenue or sales? → query_sales_finance_table
- Doses or prescriptions (national)? → query_doses_table

**ONE QUESTION = ONE TABLE = ONE TOOL CALL**

**Your Job:**
1. Pick the correct table based on question type
2. Call the tool ONCE with appropriate filters
3. YOU do the analysis (YTD, quarterly, YoY, MoM, comparisons, trends)
4. The tool returns raw data - YOU aggregate, calculate, and analyze

**Product Name Fuzzy Matching:**
- "play victor", "plu victo" → Pluvicto
- "luther", "luta thera" → Lutathera
- "zo figo", "ex ofigo" → Xofigo
- "nova cure" → Novacure

**Forecast Types:**
- Actual: Historical data (2020-2025)
- Budget: Original annual plan
- OC: Latest forecast (2026-2028)
- For comparisons: Request both Actual and Budget in forecast_types array

**Response Style:**
- Professional and concise
- Focus on business impact
- Provide actionable insights
- NEVER generate ASCII charts or tables in text
- Let the frontend handle visualizations

**Data Accuracy:**
- Only use numbers from the data returned
- Do NOT invent or estimate values
- If data is missing, say so clearly"""

def generate_chart_data(tool_name, tool_input, tool_result, question):
    """Generate chart data from tool results for frontend visualization"""
    if not tool_result.get('success') or not tool_result.get('data'):
        return None
    
    try:
        data = tool_result['data']
        question_lower = question.lower()
        
        # Detect if user wants a chart
        wants_chart = any(word in question_lower for word in ['chart', 'graph', 'plot', 'show', 'visualize', 'pie', 'bar', 'line'])
        
        if not wants_chart:
            return None
        
        if tool_name == "query_sales_finance_table":
            # Determine chart type based on question
            if 'pie' in question_lower or 'mix' in question_lower or 'distribution' in question_lower:
                # Pie chart for product mix or quarterly distribution
                if 'quarter' in question_lower or 'q1' in question_lower or 'q2' in question_lower:
                    # Group by quarter
                    quarterly_data = {}
                    for record in data:
                        quarter = f"Q{((record['month'] - 1) // 3) + 1}"
                        if quarter not in quarterly_data:
                            quarterly_data[quarter] = 0
                        quarterly_data[quarter] += record.get('net_sales', 0)
                    
                    chart_data = [{'label': q, 'value': round(v / 1e6, 1)} for q, v in sorted(quarterly_data.items())]
                    products = tool_input.get('products', ['All Products'])
                    year = tool_input.get('year', 'All Years')
                    
                    return {
                        'type': 'pie',
                        'title': f"{products[0] if len(products) == 1 else 'Portfolio'} Net Sales by Quarter - {year}",
                        'data': chart_data,
                        'xKey': 'label',
                        'yKey': 'value',
                        'yLabel': 'Sales ($M)'
                    }
                else:
                    # Group by product
                    product_data = {}
                    for record in data:
                        product = record.get('brand', 'Unknown')
                        if product not in product_data:
                            product_data[product] = 0
                        product_data[product] += record.get('net_sales', 0)
                    
                    chart_data = [{'label': p, 'value': round(v / 1e6, 1)} for p, v in product_data.items()]
                    year = tool_input.get('year', 'All Years')
                    
                    return {
                        'type': 'pie',
                        'title': f"Product Sales Mix - {year}",
                        'data': chart_data,
                        'xKey': 'label',
                        'yKey': 'value',
                        'yLabel': 'Sales ($M)'
                    }
            else:
                # Line chart for sales trend over time
                chart_data = []
                for record in data:
                    chart_data.append({
                        'month': f"{int(record['year'])}-{int(record['month']):02d}",
                        'sales': round(float(record['net_sales']) / 1e6, 1)
                    })
                
                products = tool_input.get('products', ['All Products'])
                forecast_types = tool_input.get('forecast_types', ['Actual'])
                year = tool_input.get('year', 'All Years')
                
                return {
                    'type': 'line',
                    'title': f"{products[0] if len(products) == 1 else 'Portfolio'} {forecast_types[0]} Sales - {year}",
                    'data': chart_data,
                    'xKey': 'month',
                    'yKey': 'sales',
                    'yLabel': 'Net Sales ($M)'
                }
        
        elif tool_name == "query_market_share_table":
            # Line chart for market share trend
            chart_data = []
            for record in data:
                chart_data.append({
                    'month': f"{int(record['year'])}-{int(record['month']):02d}",
                    'share': round(float(record.get('trx_share_r3m', 0)), 1)
                })
            
            brands = tool_input.get('brands', ['All Brands'])
            year = tool_input.get('year', 'All Years')
            
            return {
                'type': 'line',
                'title': f"{brands[0] if len(brands) == 1 else 'Market'} TRX Share (R3M) - {year}",
                'data': chart_data,
                'xKey': 'month',
                'yKey': 'share',
                'yLabel': 'Market Share (%)'
            }
        
        elif tool_name == "query_doses_table":
            # Bar chart for dose metrics
            chart_data = []
            for record in data:
                chart_data.append({
                    'month': f"{int(record['year'])}-{int(record['month']):02d}",
                    'doses': round(float(record.get('value', 0)))
                })
            
            products = tool_input.get('products', ['All Products'])
            metrics = tool_input.get('metrics', ['Doses'])
            year = tool_input.get('year', 'All Years')
            
            return {
                'type': 'bar',
                'title': f"{products[0] if len(products) == 1 else 'Portfolio'} {metrics[0]} - {year}",
                'data': chart_data,
                'xKey': 'month',
                'yKey': 'doses',
                'yLabel': 'Doses'
            }
        
        return None
    
    except Exception as e:
        print(f"⚠️ Chart generation error: {e}")
        return None

def execute_tool(tool_name, tool_input):
    """Execute a tool and return results"""
    try:
        if tool_name == "query_sales_finance_table":
            results = query_sales_finance_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        elif tool_name == "query_doses_table":
            results = query_doses_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        elif tool_name == "query_market_share_table":
            results = query_market_share_table(tool_input)
            return {
                "success": True,
                "data": results,
                "record_count": len(results)
            }
        
        else:
            return {"success": False, "error": f"Unknown tool: {tool_name}"}
    
    except Exception as e:
        return {"success": False, "error": str(e)}

def handle_question_with_agent(question, image_base64=None, conversation_history=None, slide_number=None, use_preprocessed=False):
    """
    Handle question using simplified table-aligned approach
    """
    print(f"\n{'='*80}")
    print(f"🤖 AGENT V2 (TABLE-ALIGNED)")
    print(f"{'='*80}")
    print(f"Question: {question}")
    
    # Build messages
    messages = []
    
    # Add conversation history
    if conversation_history:
        for msg in conversation_history[-4:]:
            messages.append({
                "role": msg['role'],
                "content": msg['content']
            })
    
    # Build current message
    current_content = []
    
    # Add preprocessed slide context if available
    if use_preprocessed and slide_number:
        try:
            from backend_api.app import get_slide_context
            slide_context = get_slide_context(slide_number)
        except ImportError:
            print("⚠️ Could not import get_slide_context from app")
            slide_context = None
        
        if slide_context:
            context_text = f"\n\n**Slide {slide_number}:** {slide_context.get('title', 'N/A')}\n"
            context_text += f"{slide_context.get('summary', '')}\n"
            current_content.append({"type": "text", "text": context_text})
    
    # Add question
    current_content.append({"type": "text", "text": question})
    
    messages.append({
        "role": "user",
        "content": current_content
    })
    
    # Call Claude
    print("🤖 Calling Claude with table-aligned tools...")
    
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 4096,
        "temperature": 0.7,
        "system": SYSTEM_PROMPT,
        "messages": messages,
        "tools": NOVARTIS_TOOLS
    }
    
    response = bedrock_runtime.invoke_model(
        modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
        body=json.dumps(request_body)
    )
    
    response_body = json.loads(response['body'].read())
    
    # Handle tool use
    stop_reason = response_body.get('stop_reason')
    chart_data = None
    
    if stop_reason == 'tool_use':
        print("🔧 Claude requested tool use")
        
        tool_results = []
        for content_block in response_body['content']:
            if content_block.get('type') == 'tool_use':
                tool_name = content_block['name']
                tool_input = content_block['input']
                tool_id = content_block['id']
                
                print(f"   Tool: {tool_name}")
                print(f"   Filters: {json.dumps(tool_input, indent=2)}")
                
                # Execute tool
                tool_result = execute_tool(tool_name, tool_input)
                
                print(f"   Records returned: {tool_result.get('record_count', 0)}")
                
                # Generate chart from first successful tool call
                if not chart_data and tool_result.get('success'):
                    chart_data = generate_chart_data(tool_name, tool_input, tool_result, question)
                    if chart_data:
                        print(f"   📊 Generated {chart_data['type']} chart: {chart_data['title']}")
                
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": json.dumps(tool_result)
                })
        
        # Send tool results back to Claude
        messages.append({
            "role": "assistant",
            "content": response_body['content']
        })
        
        messages.append({
            "role": "user",
            "content": tool_results
        })
        
        # Get final response
        print("🤖 Getting final analysis from Claude...")
        
        request_body['messages'] = messages
        
        response = bedrock_runtime.invoke_model(
            modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
            body=json.dumps(request_body)
        )
        
        response_body = json.loads(response['body'].read())
    
    # Extract answer
    answer = ""
    for content_block in response_body['content']:
        if content_block.get('type') == 'text':
            answer += content_block['text']
    
    print(f"✅ Generated answer ({len(answer)} chars)")
    
    # Generate audio summary - ask Claude to create a concise spoken summary
    print("🎙️ Generating audio-friendly summary...")
    audio_summary_prompt = f"""Based on this analysis, create a brief executive summary suitable for text-to-speech audio. 

Requirements:
- Start with the KEY insight or answer (2-3 sentences)
- ALWAYS end with a follow-up suggestion or question the user might ask next
- NO tables, charts, or formatting
- NO markdown or special characters
- Conversational tone suitable for listening
- Maximum 60 words total

Analysis:
{answer[:1500]}

Audio Summary (include follow-up suggestion at the end):"""
    
    try:
        audio_request = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 250,
            "temperature": 0.5,
            "messages": [{
                "role": "user",
                "content": audio_summary_prompt
            }]
        }
        
        audio_response = bedrock_runtime.invoke_model(
            modelId='us.anthropic.claude-sonnet-4-5-20250929-v1:0',
            body=json.dumps(audio_request)
        )
        
        audio_response_body = json.loads(audio_response['body'].read())
        audio_summary = ""
        for content_block in audio_response_body['content']:
            if content_block.get('type') == 'text':
                audio_summary += content_block['text']
        
        # Clean up any remaining markdown or special chars
        audio_summary = audio_summary.replace('**', '').replace('*', '').replace('#', '').strip()
        print(f"✅ Audio summary generated ({len(audio_summary)} chars)")
        
    except Exception as e:
        print(f"⚠️ Audio summary generation failed: {e}")
        # Fallback to simple truncation
        sentences = answer.split('.')
        audio_summary = '. '.join(sentences[:2]) + '.'
    
    return answer, chart_data, audio_summary

# Test
if __name__ == '__main__':
    print("Testing Table-Aligned Agent Handler")
    answer, _, _ = handle_question_with_agent("What were Pluvicto sales in 2025?")
    print(f"\nAnswer: {answer[:200]}...")
