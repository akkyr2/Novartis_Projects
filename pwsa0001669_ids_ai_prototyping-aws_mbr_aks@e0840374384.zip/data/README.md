# Data Directory

This directory contains all data files and documentation for the Novartis MBR Dashboard.

## Directory Structure

### `data_samples/`
Final CSV data files and presentation materials

**CSV Files (5 tables):**
- `SALES_FINANCE_BPC_corrected.csv` - Financial performance data
- `FCT_MARKET_PLU_corrected.csv` - Market share and competitor data
- `FCT_DOSES_PLU_corrected.csv` - Dose shipment data
- `FCT_CALLS_expanded.csv` - Field force activity data (2020-2025)
- `FCT_ROME_PLU_expanded.csv` - Site-level order data (2020-2025)

**Presentation Materials:**
- `Novartis_MBR_December_2025.pdf` - MBR presentation deck
- `Novartis_MBR_slide_Ash.pdf` - Sample slide (PDF)
- `Novartis_MBR_slide_Ash.pptx` - Sample slide (PowerPoint)
- `Novartis_MBR_slide_Ash.jpeg` - Sample slide (Image)

### `data_docs/`
Data documentation and analysis

- `DATA_CATALOGUE.md` - Complete data schema documentation
- `TABLE_ROUTING_GUIDE.md` - Guide for routing queries to correct tables
- `CORRECTED_TABLES_SUMMARY.md` - Summary of data corrections applied
- `DATA_QUALITY_ANALYSIS.md` - Data quality assessment
- `DATA_EXPANSION_SUMMARY.md` - Summary of data expansion (2020-2025)
- `DATA_ALIGNMENT_ANALYSIS.md` - Data alignment analysis
- `SESSION_SUMMARY.md` - Development session notes

## Data Pipeline

1. **Raw Data** → Original CSV files from business systems
2. **Corrections** → Applied via `utils/data_generation/generate_corrected_tables.py`
3. **Expansion** → Generated via `utils/data_generation/generate_*_expanded.py`
4. **Upload** → Loaded to DynamoDB via `utils/data_management/upload_to_dynamodb.py`

## Usage

To load data into DynamoDB:

```bash
# Create tables
python utils/data_management/create_dynamodb_tables.py

# Upload all data
python utils/data_management/load_all_tables.py
```

## Data Coverage

- **Time Range:** 2020-2025 (6 years actual data)
- **Forecast:** 2026-2028 (3 years, Sales and Doses only)
- **Total Records:** ~30,000+ across all tables
- **Granularity:** Monthly (aggregated by Claude for quarterly/yearly)
