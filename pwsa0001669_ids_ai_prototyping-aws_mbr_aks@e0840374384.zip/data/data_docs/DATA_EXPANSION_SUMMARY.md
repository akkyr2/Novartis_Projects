# Data Expansion Summary - FCT_CALLS and FCT_ROME_PLU

## Overview
Expanded FCT_CALLS and FCT_ROME_PLU datasets from 2024-only to full 2020-2025 coverage to align with other tables.

**Date Created:** December 9, 2025

---

## Expansion Details

### FCT_CALLS_expanded.csv

**Original (corrected):**
- Rows: 180
- Time Coverage: 3 quarters (Q1-Q3 2024)
- Dates: March 1, May 30, August 28, 2024

**Expanded:**
- ✅ Rows: **1,920** (10.7x increase)
- ✅ Time Coverage: **6 years, 24 quarters** (2020-2025)
- ✅ Date Range: **Q1 2020 - Q4 2025**
- ✅ Products: 4 (Pluvicto, Lutathera, Xofigo, Novacure)
- ✅ Geographic Levels: 2 (Nation, Region)
- ✅ Regions: 4 (Northeast, Southeast, Midwest, West)
- ✅ Metric Types: 4 (hcp_reach, cpd, call_frequency_attainment, total_calls)

**Growth Patterns:**
- Pluvicto: 15% annual growth
- Lutathera: 8% annual growth
- Xofigo: 5% annual decline
- Novacure: 12% annual growth

**Relative Indexing:**
- cycle_rel_index: 1000 (Q4 2025) down to 977 (Q1 2020)
- Proper backward counting from current quarter

---

### FCT_ROME_PLU_expanded.csv

**Original (corrected):**
- Rows: 217
- Time Coverage: 9 months (Jan-Sep 2024)
- Dates: 2024-01-01 through 2024-08-28

**Expanded:**
- ✅ Rows: **2,951** (13.6x increase)
- ✅ Time Coverage: **6 years, 72 months** (2020-2025)
- ✅ Date Range: **Jan 2020 - Dec 2025**
- ✅ Products: 4 (Pluvicto, Lutathera, Xofigo, Novacure)
- ✅ Sites: 12 (3 per region)
- ✅ Patients: 915 unique patients
- ✅ Regions: 4 (Northeast, Southeast, Midwest, West)
- ✅ Orders: 2,951 total orders

**Order Distribution:**
- Delivered: 1,661 (56%)
- Shipped: 738 (25%)
- Open: 412 (14%)
- Cancelled: 140 (5%)

**Patient Metrics:**
- First dose orders: 914 (31%)
- Active sites: 2,811 (95%)
- Dose sequences: 1-6

**Growth Patterns:**
- Pluvicto: 20% annual growth (15 orders/month base)
- Lutathera: 10% annual growth (12 orders/month base)
- Xofigo: 8% annual decline (8 orders/month base)
- Novacure: 15% annual growth (10 orders/month base)

**Relative Indexing:**
- month_rel_index: 1000 (Dec 2025) down to 928 (Jan 2020)
- year_rel_index: 1000 (2025) down to 995 (2020)
- cycle_rel_index: 1000 (Q4 2025) down to 977 (Q1 2020)

---

## Alignment with Other Tables

### Date Range Comparison

| Table | Actual Data | Forecast Data | Total Years |
|-------|-------------|---------------|-------------|
| SALES_FINANCE_BPC | 2020-2025 | 2026-2028 (Budget/OC) | 9 years |
| FCT_DOSES_PLU | 2020-2025 | 2026-2028 (Budget/OC) | 9 years |
| FCT_MARKET_PLU | 2020-2028 | N/A (Actual only) | 9 years |
| **FCT_CALLS** ⭐ | **2020-2025** | **N/A (Actual only)** | **6 years** |
| **FCT_ROME_PLU** ⭐ | **2020-2025** | **N/A (Actual only)** | **6 years** |

### Why 2020-2025 Only?

✅ **Correct Decision:**
- FCT_CALLS and FCT_ROME_PLU track **actual operational data**
- No Budget or OC forecast types (unlike Sales/Doses)
- Aligns with "Actual" period of other tables
- Future years (2026-2028) don't make sense for operational actuals

❌ **Would be Wrong:**
- Generating 2026-2028 data for calls/orders
- These are observed actuals, not financial forecasts
- Can't have "actual" field activity or orders in the future

---

## Data Quality

### FCT_CALLS_expanded

✅ **Complete Schema:**
- All 39 columns present
- Proper relative indexing (cycle_rel_index)
- Realistic KPI values with growth patterns
- Sub-national geography (Nation + 4 Regions)
- All 4 metric types covered

✅ **Business Logic:**
- CPD attainment varies realistically (90-110%)
- HCP reach percentages realistic (75-85%)
- Call frequency attainment varies by product
- Planned vs actual calls show realistic variance

✅ **Temporal Coverage:**
- Quarterly data (4 quarters per year)
- 24 total quarters (2020-2025)
- Proper quarter-end dates

### FCT_ROME_PLU_expanded

✅ **Complete Schema:**
- All 41 columns present
- Proper relative indexing (month/year/cycle)
- Realistic order distribution
- Site-level granularity maintained

✅ **Business Logic:**
- 31% first dose orders (realistic NBRx rate)
- 95% active sites (healthy site base)
- Dose sequences 1-6 (realistic treatment patterns)
- Order status distribution realistic

✅ **Temporal Coverage:**
- Monthly data (12 months per year)
- 72 total months (2020-2025)
- Month-end dates

---

## Files Generated

### Data Files
1. **data_sample/Real_data/FCT_CALLS_expanded.csv**
   - 1,920 rows
   - 39 columns
   - 2020-2025 coverage

2. **data_sample/Real_data/FCT_ROME_PLU_expanded.csv**
   - 2,951 rows
   - 41 columns
   - 2020-2025 coverage

### Generation Scripts
1. **scripts/generate_calls_expanded.py**
   - Generates quarterly call data
   - Realistic growth patterns
   - Proper relative indexing

2. **scripts/generate_rome_expanded.py**
   - Generates monthly order data
   - Patient journey tracking
   - Site activity patterns

---

## Next Steps

### To Use Expanded Data

1. **Upload to DynamoDB:**
   ```bash
   # Create Novartis_Calls table
   python scripts/upload_to_dynamodb.py \
     --table Novartis_Calls \
     --csv data_sample/Real_data/FCT_CALLS_expanded.csv
   
   # Create Novartis_Rome table
   python scripts/upload_to_dynamodb.py \
     --table Novartis_Rome \
     --csv data_sample/Real_data/FCT_ROME_PLU_expanded.csv
   ```

2. **Update app.py to use V2.1:**
   ```python
   from backend_api.novartis_agent_handler_v2_1 import handle_question_with_agent
   ```

3. **Test with expanded date ranges:**
   - "Show me Pluvicto call activity from 2020 to 2025"
   - "What's the site activation trend over the past 5 years?"
   - "Compare HCP reach in 2020 vs 2025"

---

## Testing Recommendations

### FCT_CALLS Tests
```
1. "How many HCPs did we reach in 2020 vs 2025?"
2. "Show me CPD trends for Pluvicto from 2020 to 2025"
3. "What's the call frequency attainment by year?"
4. "Compare regional call activity across all years"
```

### FCT_ROME_PLU Tests
```
1. "How many first dose orders from 2020 to 2025?"
2. "Show me site activation trends over 5 years"
3. "What's the patient demand growth by region?"
4. "Compare order volumes 2020 vs 2025"
```

---

## Statistics

### Data Volume Increase

| Metric | FCT_CALLS | FCT_ROME_PLU |
|--------|-----------|--------------|
| Original Rows | 180 | 217 |
| Expanded Rows | 1,920 | 2,951 |
| Increase | 10.7x | 13.6x |
| Original Coverage | 3 quarters | 9 months |
| Expanded Coverage | 24 quarters | 72 months |
| Time Span | 6 years | 6 years |

### Coverage Completeness

✅ **FCT_CALLS:**
- 4 products × 5 geo levels × 4 metric types × 24 quarters = 1,920 records ✓

✅ **FCT_ROME_PLU:**
- ~10 orders/month × 4 products × 72 months = ~2,880 records ✓
- Actual: 2,951 (includes growth patterns)

---

## Summary

✅ **Expansion Complete:**
- FCT_CALLS: 180 → 1,920 rows (2020-2025)
- FCT_ROME_PLU: 217 → 2,951 rows (2020-2025)

✅ **Alignment Achieved:**
- Matches "Actual" period of other tables
- No inappropriate future forecasts
- Proper relative indexing

✅ **Quality Maintained:**
- Realistic growth patterns
- Proper business logic
- Complete schemas

✅ **Ready for V2.1:**
- Upload to DynamoDB
- Test with V2.1 architecture
- Full 6-year historical analysis

**Status:** Data expansion complete, ready for DynamoDB upload! 🎉
