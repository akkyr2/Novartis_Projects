# Table Routing Guide - SME Instructions for LLM Query Generation

## Overview
This guide helps route user questions to the correct table(s) based on the question intent and required granularity.

---

## Table Selection Decision Tree

```
User Question
    │
    ├─ About MARKET SHARE or COMPETITORS? 
    │   └─ YES → FCT_MARKET_PLU_corrected (ALWAYS)
    │
    ├─ About REVENUE or SALES PERFORMANCE?
    │   └─ YES → SALES_FINANCE_BPC_corrected
    │
    ├─ About DOSES or PRESCRIPTIONS at NATIONAL level?
    │   └─ YES → FCT_DOSES_PLU_corrected
    │
    ├─ About MEDICAL REP CALLS or ACTIVITIES?
    │   └─ YES → FCT_CALLS
    │
    └─ About SITES, TERRITORIES, or DETAILED GEOGRAPHY?
        └─ YES → FCT_ROME_PLU
```

---

## 1. SALES_FINANCE_BPC_corrected

### When to Use
✅ **USE for**:
- Sales performance analysis
- Revenue trends (net sales, gross sales)
- Budget vs Actual comparisons
- Brand-level sales analysis
- Time-based sales analysis (monthly, quarterly, yearly)

❌ **DO NOT USE for**:
- Market share analysis
- Competitor analysis
- Competitor revenue (only Novartis products)

### Key Characteristics
- **Granularity**: Aggregated sales data
- **Products**: Novartis portfolio only (Pluvicto, Lutathera, Xofigo, Novacure)
- **Metrics**: Net sales, gross sales, revenue deductions (in $)
- **Forecast Types**: Actual, Budget, OC (dim_forecast)
- **Time Dimensions**: dim_date, month_rel_index, year_rel_index, cycle_rel_index
- **Frequency**: Monthly or weekly (data_frequency)

### Key Columns
- **PRODUCT**: Product code
- **DIM_Brand**: Brand identifier
- **DIM_forecast**: Actual, Budget, OC
- **dim_date**: Calendar date
- **net_sales**: Net sales amount ($)
- **gross_sales**: Gross sales amount ($)
- **revenue_deductions**: Deductions ($)
- **source**: Unique identifier for each record
- **data_frequency**: Weekly or monthly

### Important Rules
- When nullable columns are used in grouping or output, **EXCLUDE null values** from both grouping and displayed results
- Use for performance analysis and planning
- Join with supporting dimension tables for deeper insights

### Example Questions
- "What's our revenue this quarter?"
- "Show me Pluvicto sales vs budget"
- "What's the net sales trend for 2024?"
- "Compare actual vs budget for all products"

---

## 2. FCT_DOSES_PLU_corrected

### When to Use
✅ **USE for**:
- National-level dose/prescription metrics
- TRX (total prescriptions) analysis
- NBRX (new patient) analysis
- Shipped vs injected dose comparison
- Time-only granularity (month, quarter, year)

❌ **DO NOT USE for**:
- Site-level analysis
- Territory/geography drill-downs
- Customer-level analysis
- Account-level analysis
- Patient-level analysis

### Key Characteristics
- **Granularity**: National level ONLY (no site, territory, customer, account)
- **Products**: Novartis RLT products
- **Metrics**: TRX_shipped, TRX_injected, NBRX
- **Forecast Types**: Actual, Budget, OC (dim_forecast)
- **Time Dimensions**: dim_date, month_rel_index, year_rel_index, quarter_rel_index

### Key Columns
- **PRODUCT**: Product code
- **DIM_Brand**: Brand identifier
- **dim_forecast**: Actual, Budget, OC
- **metric**: TRX_shipped, TRX_injected, NBRX
- **value**: Metric value (use directly for national totals)
- **dim_date**: Calendar date
- **month_rel_index, year_rel_index, quarter_rel_index**: Time indexes

### Important Rules
- **ONLY for national-level questions** with time granularity
- **NO drill-downs** by site, geography, customer, site, or patient
- Use **value** column directly for national-level results and forecasts
- Forecast types distinguish between Actual, Budget, and OC

### Example Questions
- "What's the total shipped doses nationally?"
- "Show me NBRX trend over time"
- "Compare shipped vs injected doses"
- "What's the national forecast for TRX?"

---

## 3. FCT_MARKET_PLU_corrected

### When to Use
✅ **ALWAYS USE for**:
- Market share analysis
- Competitor analysis
- Competitor performance tracking
- Line of therapy information
- Market trends and dynamics
- Competitive landscape

❌ **DO NOT USE for**:
- Novartis-only analysis (use SALES or DOSES instead)
- Site/territory level (only national)

### Key Characteristics
- **Granularity**: National level, monthly
- **Products**: Pluvicto + ALL competitors
- **Metrics**: TRX_R3M, NBRX_R3M, TRX_SHARE_R3M, NBRX_SHARE_R3M
- **Time Period**: Rolling 3 months (R3M)
- **Source**: Manual file maintained by Pluvicto brand analysis team

### Why This Table Exists
- **FCT_ROME_PLU** (shipment data) only captures Novartis RLT products
- **No competitor shipment data** available
- **Claims data** used to understand overall market trends
- **Competitor share** crucial for understanding Pluvicto performance
- **Market events** like competitor launches affect Pluvicto

### Key Columns
- **PRODUCT**: Market basket (always "Pluvicto" for this market)
- **DIM_Brand**: Pluvicto, Lutathera, Xofigo, Competitor_A, Competitor_B, etc.
- **Class**: Detailed product class (pluvicto, xofigo, arpi, taxane, chemo)
- **class_aggregated**: Aggregated class grouping
- **TRX_R3M**: Total demand volume (rolling 3 months)
- **TRX_SHARE_R3M**: Total demand market share %
- **NBRX_R3M**: New patient demand volume (rolling 3 months)
- **NBRX_SHARE_R3M**: New patient demand market share %
- **dim_date**: Calendar date (monthly)
- **month_rel_index, year_rel_index, cycle_rel_index**: Time indexes

### Important Rules
- **ALWAYS use for market share or competitor questions**
- Competitor information available **monthly at national level only**
- Can show share by **individual product** or **aggregated class**
- R3M (rolling 3 months) data aligns with MBR report
- Calculate overall R3M market volume and corresponding shares

### Example Questions
- "What's our market share vs Lutathera?"
- "Show me competitor trends"
- "How is Pluvicto performing vs the market?"
- "What's the new patient share for all products?"
- "Compare TRX share across all competitors"

---

## 4. FCT_CALLS

### Data Source & Purpose
The main source for field activity information comes from **Veeva CRM calls logging system**, processed and formatted for consumption by AI tools in MBR as FCT_CALLS. The table is aligned to calls reporting at Novartis by sourcing from the provisioning layer in **FIELD_CEE_KPI_2WK_LAG** source table, which is the database location used at the foundation of the FCT_CALLS consumption table.

### Business Context
Sales calls have a **tangible impact on the bottom line and sales** as the main demand generation tool at Novartis's disposal. Talking to HCPs to promote the value and awareness of the latest drugs available on the market can improve patient outcomes. Whether sales reps are meeting their goals of reaching HCPs can provide insight into explaining the performance of the brand as a whole.

### When to Use
✅ **USE for**:
- Field activity analysis
- Sales rep performance tracking
- HCP reach and engagement metrics
- Call frequency and attainment analysis
- Call planning effectiveness
- Team performance by geography
- Demand generation insights

❌ **DO NOT USE for**:
- Market share analysis (use FCT_MARKET_PLU_corrected)
- Revenue/sales figures (use SALES_FINANCE_BPC_corrected)
- Patient-level demand (use FCT_ROME_PLU)

### Key Characteristics
- **Granularity**: Sub-national level with geography details
- **Products**: All focused products currently promoted by Novartis (beyond just Pluvicto)
- **Time Coverage**: 3 cycles of history
- **Source System**: Veeva CRM via FIELD_CEE_KPI_2WK_LAG
- **Dimensions**: Time periods, Tiers groupings, call methods, call focuses, teams, cycle, product

### Key Metrics & KPIs
This source contains all key calls reporting KPIs needed by field leadership for commercial sales teams:
- **Total calls**: Number of HCP interactions
- **HCPs reached**: Unique healthcare providers contacted
- **Call per day**: Daily call productivity
- **Call frequency attainment**: Meeting call frequency targets
- **Call planned information**: Planned vs actual calls

### Key Columns
- **Geography fields**: Territory, area, region (sub-national level)
- **Time dimensions**: Date, cycle, time period groupings
- **Call characteristics**: Call method, call focus, call type
- **Team information**: Sales team, rep identifiers
- **Product**: Product being promoted
- **Tier groupings**: HCP tier classifications
- **Metrics**: Call counts, HCP reach, frequency attainment
- **Date grouping columns**: For easy filtering and aggregation
- **Metric filters**: To segment different call types
- **Timestamps**: For temporal analysis

### Important Rules
- Contains **all Novartis promoted products**, not just Pluvicto
- **Sub-national geography** available for drill-downs
- Use for understanding **demand generation activities**
- Link call activity to sales performance for correlation analysis
- 3 cycles of historical data available

### Example Questions
- "How many HCPs did our reps reach this month?"
- "What's the call frequency attainment by territory?"
- "Show me calls per day trend for the sales team"
- "Which territories have the highest call activity?"
- "Are we meeting our call planning goals?"
- "Compare call activity across different products"
- "What's the relationship between calls and sales performance?"

---

## 5. FCT_ROME_PLU

### Data Source & Purpose
The **order demand fact table** (also called FCT_ROME_PLU) captures comprehensive order and demand-level data across territories, sites, customers, and time periods. This is the most granular table for analyzing actual ordering behavior and site-level activity.

### Business Context
This table provides the foundation for understanding **how sites order products, patient-level demand patterns, and geographic performance**. It enables analysis of site activation, dormancy, injection patterns, and NBRx tracking at the most detailed level.

### When to Use
✅ **USE for**:
- Site activity analysis
- Patient-level demand (patient_reference_number)
- Geography-level demand (sub-national)
- Territory and area performance
- Injection patterns (dose_number)
- Ordering behavior over time
- Identifying dormant or active sites (active_dormant_flag)
- Tracking NBRx activity (through sales_order_number)
- Evaluating performance across quartiles and top sites
- Customer-level analysis
- Site type and ecosystem segmentation

❌ **DO NOT USE for**:
- **Market share analysis** (use FCT_MARKET_PLU_corrected instead)
- **Competitor-related analysis** (use FCT_MARKET_PLU_corrected instead)
- National-level aggregates only (use FCT_DOSES_PLU_corrected for simpler queries)

### Key Characteristics
- **Granularity**: Most detailed - site, customer, patient, order level
- **Products**: Novartis RLT products only (no competitor data)
- **Geography**: Full sub-national detail (territory, area, site)
- **Source**: Order demand system (ROME)
- **Temporal Coverage**: Historical order and demand data

### Key Identifiers
- **Product**: Product codes (%product)
- **Calendar dates**: date field
- **Site-level details**: site_id, dim_customer_name, site_org_id
- **Geographic**: TERR_ID, DIM_territory_name, area_id
- **Patient**: patient_reference_number
- **Order**: sales_order_number

### Temporal Dimensions
- **DIM_date**: Calendar date
- **month, quarter, year**: Standard time groupings
- **Indexed fields**: monthRel, quarterRel, yearRel (relative indexes)

### Geographic Segmentation
- **TERR_ID**: Territory identifier
- **DIM_territory_name**: Territory name
- **area_id**: Area identifier
- **Delivery location fields**: delivery_address, delivery_city (may not be included due to PII)

### Order Characteristics
- **DIM_order_type**: Type of order
- **DIM_order_status**: Order status
- **is_patients_first_dose**: Flag for first dose orders

### Demand Metrics
- **sales_order_number**: Count distinct for demand volume
- **Filters**: DIM_order_status, DIM_order_type, is_patients_first_dose

### Additional Attributes
- **DIM_tier**: Site tier classification
- **dim_site_type**: Type of site (hospital, clinic, etc.)
- **dim_ecosystem**: Ecosystem classification
- **dim_system_name**: System name
- **dim_account_status**: Account status
- **active_dormant_flag**: Site activity status
- **dose_number**: Injection sequence number

### Use Cases
1. **Site Activity Analysis**: Identify active vs dormant sites
2. **Patient-Level Demand**: Track individual patient journeys via patient_reference_number
3. **Geography Performance**: Analyze demand by territory, area, site
4. **Injection Patterns**: Understand dose sequences and treatment patterns
5. **NBRx Tracking**: Identify new patient starts through sales_order_number
6. **Ordering Behavior**: Analyze order frequency, timing, and patterns
7. **Segmentation**: Performance across quartiles, top sites, site types
8. **Lifecycle Analysis**: Track site activation, growth, and dormancy

### Important Rules
- **DO NOT use for market share or competitor analysis** - this only contains Novartis products
- Most granular table - use when site, customer, or patient-level detail is needed
- For national aggregates without geography drill-down, prefer FCT_DOSES_PLU_corrected
- Contains PII considerations - delivery address fields may be excluded

### Example Questions
- "Which sites are dormant this quarter?"
- "Show me patient demand by territory"
- "What's the average dose number per patient?"
- "Which customers have the highest order volume?"
- "Identify top performing sites by quartile"
- "What's the NBRx trend by site type?"
- "Show me ordering patterns across territories"
- "Which sites have first-dose orders this month?"

---

## AI-DIM-Calendar (Dimension Table)

### Purpose
All tables with time information set up for consumption by AI MBR have a **date key field** available to allow for connection to the calendar table **AI-DIM-Calendar**. This way various date grouping columns can be maintained centrally in one location instead of recreating the same information in multiple places.

### Benefits
- **Centralized date logic**: Common date groupings maintained in one place
- **Flexibility**: Greater flexibility in the scope of questions answerable by the AI tool
- **Business calendar**: Key dates defined by the business can be maintained centrally
- **Consistency**: Ensures consistent date calculations across all fact tables

### Available Groupings
Even if not directly available in the fact data, this table allows grouping by:
- **Week**: Week number, week start/end dates
- **Month**: Month number, month name, month start/end dates
- **Quarter**: Quarter number, quarter start/end dates
- **Year**: Calendar year, fiscal year
- **Business periods**: Cycles, reporting periods
- **Special dates**: Holidays, business milestones, key events

### Join Pattern
All fact tables can join to AI-DIM-Calendar using their date key field (typically `dim_date` or `date`):

```sql
FROM FCT_TABLE
JOIN AI-DIM-Calendar ON FCT_TABLE.dim_date = AI-DIM-Calendar.date
```

### Note
Although no sample data is currently available for AI-DIM-Calendar, this dimension table is referenced in SME notes and should be considered when designing queries that require flexible date groupings.

---

## Query Routing Examples

### Example 1: "What's our revenue this quarter?"
**Route to**: SALES_FINANCE_BPC_corrected
**Reason**: Revenue/sales performance question
**Filters**: 
- dim_forecast = 'Actual'
- Filter by current quarter using cycle_rel_index

### Example 2: "What's our market share vs competitors?"
**Route to**: FCT_MARKET_PLU_corrected
**Reason**: Market share + competitors mentioned
**Filters**:
- Use TRX_SHARE_R3M or NBRX_SHARE_R3M
- Group by DIM_Brand

### Example 3: "Show me national dose shipments"
**Route to**: FCT_DOSES_PLU_corrected
**Reason**: National-level doses, no geography drill-down
**Filters**:
- metric = 'TRX_shipped'
- Use value column

### Example 4: "Compare Pluvicto sales to budget"
**Route to**: SALES_FINANCE_BPC_corrected
**Reason**: Sales performance, budget comparison
**Filters**:
- PRODUCT = 'Pluvicto'
- dim_forecast IN ('Actual', 'Budget')

### Example 5: "How are competitors doing in the market?"
**Route to**: FCT_MARKET_PLU_corrected
**Reason**: Competitor analysis
**Filters**:
- DIM_Brand != 'Pluvicto' (or include all for comparison)
- Use TRX_R3M or TRX_SHARE_R3M

### Example 6: "What's the new patient trend?"
**Route to**: 
- **National level**: FCT_DOSES_PLU_corrected (metric = 'NBRX')
- **With competitors**: FCT_MARKET_PLU_corrected (NBRX_R3M, NBRX_SHARE_R3M)

### Example 7: "How many HCPs did our reps reach this quarter?"
**Route to**: FCT_CALLS
**Reason**: Field activity and HCP reach metrics
**Filters**:
- Filter by current quarter
- Aggregate HCPs reached

### Example 8: "Which sites are dormant?"
**Route to**: FCT_ROME_PLU
**Reason**: Site-level activity analysis
**Filters**:
- active_dormant_flag = 'Dormant'
- Group by site_id, dim_customer_name

### Example 9: "Show me patient demand by territory"
**Route to**: FCT_ROME_PLU
**Reason**: Geographic and patient-level demand
**Filters**:
- Group by TERR_ID, DIM_territory_name
- Count distinct patient_reference_number

---

## Multi-Table Queries

Some questions may require joining multiple tables:

### Revenue vs Market Share
**Question**: "Show me revenue and market share trends"
**Tables**: 
1. SALES_FINANCE_BPC_corrected (revenue)
2. FCT_MARKET_PLU_corrected (market share)
**Join on**: PRODUCT, DIM_Brand, dim_date

### Doses vs Market Volume
**Question**: "Compare our doses to total market demand"
**Tables**:
1. FCT_DOSES_PLU_corrected (our doses)
2. FCT_MARKET_PLU_corrected (market volume)
**Join on**: PRODUCT, dim_date

### Call Activity vs Sales Performance
**Question**: "Does call frequency correlate with sales?"
**Tables**:
1. FCT_CALLS (call activity)
2. SALES_FINANCE_BPC_corrected (sales)
**Join on**: PRODUCT, geography, time period

### Site Orders vs Call Activity
**Question**: "Which territories have high calls but low orders?"
**Tables**:
1. FCT_CALLS (call metrics by territory)
2. FCT_ROME_PLU (order demand by territory)
**Join on**: Territory, time period

---

## Critical Rules Summary

### 1. Market Share / Competitors
- **ALWAYS** → FCT_MARKET_PLU_corrected
- No exceptions

### 2. Revenue / Sales
- **ALWAYS** → SALES_FINANCE_BPC_corrected
- Never for competitors

### 3. National Doses
- **ONLY** → FCT_DOSES_PLU_corrected
- No geography drill-downs

### 4. Medical Rep Activities
- **ALWAYS** → FCT_CALLS
- Call frequency, rep performance, HCP reach
- Sub-national geography available

### 5. Site/Patient/Order Details
- **ALWAYS** → FCT_ROME_PLU
- Site, territory, customer, patient-level analysis
- **DO NOT use for market share or competitors**
- Most granular table for demand analysis

### 6. Null Handling
- **EXCLUDE** null values from grouping and output

### 7. Forecast Types
- **Actual**: Recorded values (2020-2025)
- **Budget**: First forecast of year
- **OC**: Latest forecast (2026-2028)
- Default: Use OC if available, else Budget

### 8. Relative Indexes
- **1000** = Current period (Dec 2025)
- **999** = 1 period ago
- **998** = 2 periods ago
- Use for time-based filtering

---

## SME Source Document

This guide is based on the "Identify Table Query" instructions provided by Subject Matter Experts (SME) for guiding LLMs to convert natural language questions into correct table queries.

**Last Updated**: December 7, 2025
**Version**: 1.1 (Added FCT_CALLS, FCT_ROME_PLU, and AI-DIM-Calendar details)
