# Corrected Tables Summary

## Overview
Created corrected versions of FCT_CALLS and FCT_ROME_PLU tables based on SME notes with complete schema and proper data structure.

**Date Created**: December 7, 2025

---

## 1. FCT_CALLS_corrected

### Summary
- **Rows**: 180
- **Columns**: 39 (added 12 new columns from SME requirements)
- **Products**: Pluvicto, Lutathera, Xofigo (all MohammadFarma promoted products)
- **Time Coverage**: 3 cycles (Q1-Q3 2024)
- **Geographic Levels**: Nation, Region
- **Metric Types**: hcp_reach, cpd, call_frequency_attainment, total_calls

### New Columns Added (12 total)

| Column Name | Description | Data Type |
|-------------|-------------|-----------|
| **cycle_rel_index** | Relative cycle index (1000=current, 999=last quarter) | Integer |
| **call_date** | Date of call corresponding to the time period | Date |
| **period_start_date** | Start date of time period | Date |
| **period_end_date** | End date of time period | Date |
| **total_week_mth** | Total weeks in month | Integer |
| **working_day** | Total working days | Integer |
| **prorated_planned_calls** | Planned calls adjusted to time period and cycle week | Integer |
| **prorated_call_frequency_goal** | Call frequency goal adjusted to time period | Numeric |
| **prorated_hcp_reach_goal** | HCP reach goal adjusted to time period | Integer |
| **reporting_week_date** | Latest week of calls available | Date |
| **incentive_start_date** | Cycle start date | Date |
| **last_altered** | Timestamp of latest source refresh | Timestamp |

### Key Features
- **Source System**: FIELD_CEE_KPI_2WK_LAG (Veeva CRM)
- **Relative Indexing**: cycle_rel_index uses 1000-based system (1000, 999, 998)
- **Sub-national Geography**: Nation and Region levels included
- **Multiple Products**: All MohammadFarma promoted products (not just Pluvicto)
- **Comprehensive KPIs**: HCP reach, CPD, call frequency, total calls

### Business Context
- Field activity data from Veeva CRM calls logging system
- Main demand generation tool for MohammadFarma
- Tracks sales rep performance and HCP engagement
- Links call activity to sales performance
- 3 cycles of historical data

---

## 2. FCT_ROME_PLU_corrected

### Summary
- **Rows**: 217
- **Columns**: 41 (complete schema per SME notes)
- **Products**: Pluvicto, Lutathera, Xofigo
- **Sites**: 11 unique sites across 4 regions
- **Patients**: 36 unique patients
- **Orders**: 217 total orders
- **Time Coverage**: 9 months (Jan-Sep 2024)

### Complete Schema (41 columns)

#### Product & Brand
- PRODUCT, DIM_Brand

#### Date & Time
- dim_date, month_rel_index, year_rel_index, cycle_rel_index, year_quarter

#### Customer & Site
- dim_customer_name, site_id, dim_site_type, dim_tier, dim_system_name
- active_dormant_flag, dim_account_status, dim_ecosystem

#### Geography
- dim_terr_name, dim_area_name, dim_region_name
- terr_id, area_id, region_id
- state, country

#### Order Details
- sales_order_number, dim_order_status, dim_order_type, dim_order_group
- order_status_customer

#### Patient & Treatment
- patient_reference_number, treatment_id, dose_number, is_patients_first_dose
- insurance_provider

#### Physicians
- referring_physician, ordering_physician

#### Cancellation
- cancellation_date, cancellation_unused_dose_reason, cancellation_unused_dose_other_reason

#### Delivery (PII Redacted)
- delivery_address, delivery_address_city, delivery_address_zip

### Key Features
- **Most Granular Table**: Site, customer, patient, order level detail
- **Relative Indexing**: month_rel_index, year_rel_index, cycle_rel_index (1000-based)
- **Geographic Hierarchy**: Region → Area → Territory → Site
- **Order Lifecycle**: Open, Shipped, Delivered, Cancelled
- **Patient Journey**: Tracks dose sequences (1-6) and first dose flags
- **Site Activity**: Active/Dormant flag for site status tracking
- **PII Protection**: Delivery addresses redacted

### Business Context
- Order demand fact table from ROME system
- Captures comprehensive order and demand-level data
- Enables site activity analysis and patient-level demand tracking
- Supports geographic performance analysis
- Tracks injection patterns and NBRx activity
- **DO NOT use for market share or competitor analysis** (MohammadFarma products only)

---

## Data Quality

### FCT_CALLS_corrected
✅ All 39 columns present (27 original + 12 new)
✅ Proper relative indexing (1000, 999, 998)
✅ Multiple products (Pluvicto, Lutathera, Xofigo)
✅ Sub-national geography (Nation, Region)
✅ All metric types included
✅ Proper date ranges and time periods

### FCT_ROME_PLU_corrected
✅ All 41 columns present per SME schema
✅ Proper relative indexing (1000-based system)
✅ Complete geographic hierarchy
✅ Realistic order distribution
✅ Patient journey tracking (dose sequences)
✅ Active/Dormant site flags
✅ PII protection (addresses redacted)

---

## Integration with Existing Tables

### Joins with Other Tables

#### FCT_CALLS_corrected
- **SALES_FINANCE_BPC_corrected**: Join on product, geography, time period
- **FCT_ROME_PLU_corrected**: Join on territory, time period
- **AI-DIM-Calendar**: Join on dim_date for flexible date groupings

#### FCT_ROME_PLU_corrected
- **FCT_DOSES_PLU_corrected**: Join on product, dim_date (national vs site-level)
- **FCT_CALLS_corrected**: Join on territory, time period
- **SALES_FINANCE_BPC_corrected**: Join on product, time period
- **AI-DIM-Calendar**: Join on dim_date for flexible date groupings

---

## Use Cases

### FCT_CALLS_corrected
1. **Field Activity Analysis**: Track HCP reach and call frequency
2. **Rep Performance**: Monitor CPD and call attainment
3. **Geographic Performance**: Analyze by nation, region
4. **Demand Generation**: Link calls to sales outcomes
5. **Goal Tracking**: Compare actual vs planned calls

### FCT_ROME_PLU_corrected
1. **Site Activity**: Identify active vs dormant sites
2. **Patient Demand**: Track patient-level ordering patterns
3. **Geographic Analysis**: Performance by region, area, territory
4. **Injection Patterns**: Analyze dose sequences
5. **NBRx Tracking**: Identify new patient starts
6. **Order Management**: Monitor order lifecycle and status
7. **Site Segmentation**: Analyze by tier, type, ecosystem

---

## Files Generated

1. **FCT_CALLS_corrected.csv** - 180 rows, 39 columns
2. **FCT_ROME_PLU_corrected.csv** - 217 rows, 41 columns
3. **generate_corrected_tables.py** - Generation script for FCT_CALLS
4. **generate_rome_corrected.py** - Generation script for FCT_ROME_PLU

---

## Next Steps

1. ✅ Update DATA_CATALOGUE.md to reflect corrected tables
2. ✅ Update TABLE_ROUTING_GUIDE.md with corrected table names
3. ⏭️ Test agent-based queries with corrected tables
4. ⏭️ Validate data quality and business rules
5. ⏭️ Integrate with preprocessing system

---

**Version**: 1.0
**Last Updated**: December 7, 2025
**Status**: ✅ Complete
