# Data Alignment Analysis - Real vs Generated

## Comparison: Real Dataset Specs vs Our Implementation

---

## 1. SALES_FINANCE_BPC

### Real Dataset Specs:
- **Type:** Actuals and forecasts (net sales, gross sales, RDs)
- **Temporality:** Monthly
- **Market Basket:** Novartis products only, no competitors
- **Geography:** National only

### Our Implementation: ✅ ALIGNED
- ✅ Type: Actuals, Budget, OC (net_sales, gross_sales, revenue_deductions)
- ✅ Temporality: Monthly
- ✅ Market Basket: 4 Novartis products (Pluvicto, Lutathera, Xofigo, Novacure)
- ✅ Geography: National only
- ✅ Date Range: 2020-2025 (Actual), 2026-2028 (Forecast)

**Status:** ✅ Fully aligned

---

## 2. FCT_DOSES_PLU (National_doses)

### Real Dataset Specs:
- **Type:** Actuals and forecasts (shipped doses, injected doses/TRx, new patients/NBRx)
- **Temporality:** Monthly
- **Market Basket:** **Pluvicto only**, no competitors
- **Geography:** National only

### Our Implementation: ⚠️ PARTIALLY ALIGNED
- ✅ Type: Actuals, Budget, OC (TRX_shipped, TRX_injected, NBRX)
- ✅ Temporality: Monthly
- ❌ Market Basket: **4 products** (Pluvicto, Lutathera, Xofigo, Novacure)
- ✅ Geography: National only
- ✅ Date Range: 2020-2025 (Actual), 2026-2028 (Forecast)

**Issue:** We have all 4 products, but real data is **Pluvicto only**

**Impact:** 
- Our data has extra products that shouldn't exist
- Need to filter to Pluvicto only or regenerate

---

## 3. FCT_ROME_PLU

### Real Dataset Specs:
- **Type:** Actuals of Pluvicto shipment orders (status, order number, order type, customer info, patient info)
- **Temporality:** Monthly
- **Market Basket:** **Pluvicto only**, no competitors
- **Geography:** Sub-national (territories, states, region, zip)

### Our Implementation: ⚠️ PARTIALLY ALIGNED
- ✅ Type: Actuals (order status, sales_order_number, order type, site info, patient info)
- ✅ Temporality: Monthly
- ❌ Market Basket: **4 products** (Pluvicto, Lutathera, Xofigo, Novacure)
- ✅ Geography: Sub-national (territory, area, region, state)
- ✅ Date Range: 2020-2025 (Actual only)
- ⚠️ Missing: ZIP codes

**Issues:**
- We have all 4 products, but real data is **Pluvicto only**
- Missing ZIP code level geography

**Impact:**
- Extra products that shouldn't exist
- Need ZIP codes for full geographic granularity

---

## 4. FCT_MARKET_PLU

### Real Dataset Specs:
- **Type:** Claims data (line of therapy, indication, new patient flags)
- **Temporality:** Monthly
- **Market Basket:** **Pluvicto and competitors**
- **Geography:** Sub-national (territory, region, zip, state)

### Our Implementation: ⚠️ PARTIALLY ALIGNED
- ✅ Type: Market data (TRX_R3M, TRX_SHARE_R3M, NBRX_R3M, NBRX_SHARE_R3M)
- ✅ Temporality: Monthly
- ✅ Market Basket: Pluvicto + competitors (Competitor_A, B, C)
- ✅ Geography: Has region data
- ❌ Missing: Line of therapy, indication, territory, zip, state
- ✅ Date Range: 2020-2028 (Actual only)

**Issues:**
- Missing clinical dimensions (line of therapy, indication)
- Missing geographic granularity (territory, zip, state)
- Only has region level

**Impact:**
- Cannot answer therapy line questions
- Cannot answer indication-specific questions
- Limited geographic drill-down

---

## 5. FCT_CALLS

### Real Dataset Specs:
- **Type:** Pre-calculated metrics (total calls, HCP reach, CPD, call frequency attainment, call plan info)
- **Temporality:** **Weekly**
- **Market Basket:** Novartis products only, no competitors
- **Geography:** Sub-national (territory, region, zip, state)

### Our Implementation: ⚠️ PARTIALLY ALIGNED
- ✅ Type: Metrics (actual_calls, target_hcp_reach, CPD, call_frequency_attainment, planned_calls)
- ❌ Temporality: **Quarterly** (should be weekly)
- ✅ Market Basket: 4 Novartis products
- ⚠️ Geography: Nation + Region (missing territory, zip, state)
- ✅ Date Range: 2020-2025 (Actual only)

**Issues:**
- Wrong temporality: Quarterly instead of Weekly
- Missing geographic levels: territory, zip, state
- Only has Nation and Region

**Impact:**
- Cannot answer weekly call questions
- Limited geographic drill-down
- Less granular than real data

---

## Critical Business Rules (From Your Input)

### Default Product Assumptions:
1. **Market, ROME, Doses:** Default to **Pluvicto** if no product specified
2. **Sales, Calls:** May show all 4 products + total

### Our Implementation:
- ❌ Not enforced in SYSTEM_PROMPT
- ❌ Claude doesn't know to default to Pluvicto
- ❌ May return all products when should focus on Pluvicto

**Action Needed:** Update SYSTEM_PROMPT with default product rules

---

## Summary Table

| Table | Temporality | Market Basket | Geography | Status |
|-------|-------------|---------------|-----------|--------|
| **Sales Finance** | ✅ Monthly | ✅ Novartis only | ✅ National | ✅ Aligned |
| **Doses** | ✅ Monthly | ❌ Should be Pluvicto only | ✅ National | ⚠️ Fix needed |
| **ROME** | ✅ Monthly | ❌ Should be Pluvicto only | ⚠️ Missing ZIP | ⚠️ Fix needed |
| **Market** | ✅ Monthly | ✅ Pluvicto + competitors | ⚠️ Missing levels | ⚠️ Enhancement needed |
| **Calls** | ❌ Should be Weekly | ✅ Novartis only | ⚠️ Missing levels | ⚠️ Fix needed |

---

## Priority Fixes

### HIGH PRIORITY (Data Accuracy)

1. **Doses Table - Pluvicto Only** ⚠️
   - Current: 4 products
   - Should be: Pluvicto only
   - Action: Filter or regenerate

2. **ROME Table - Pluvicto Only** ⚠️
   - Current: 4 products
   - Should be: Pluvicto only
   - Action: Filter or regenerate

3. **Calls Table - Weekly Temporality** ⚠️
   - Current: Quarterly
   - Should be: Weekly
   - Action: Regenerate with weekly data

4. **Default Product Rules** ⚠️
   - Current: No defaults
   - Should be: Pluvicto default for Market/ROME/Doses
   - Action: Update SYSTEM_PROMPT

### MEDIUM PRIORITY (Enhanced Functionality)

5. **ROME - Add ZIP Codes**
   - Current: Territory, Area, Region, State
   - Missing: ZIP codes
   - Action: Add ZIP field to data

6. **Calls - Add Territory/ZIP/State**
   - Current: Nation, Region
   - Missing: Territory, ZIP, State
   - Action: Enhance geographic granularity

7. **Market - Add Clinical Dimensions**
   - Current: Basic market share
   - Missing: Line of therapy, indication
   - Action: Add clinical fields

8. **Market - Add Territory/ZIP/State**
   - Current: Region only
   - Missing: Territory, ZIP, State
   - Action: Enhance geographic granularity

---

## Recommendations

### Immediate Actions:

1. **Filter Doses to Pluvicto Only**
   ```python
   # In query_doses_table, default to Pluvicto
   if 'products' not in filters:
       filters['products'] = ['Pluvicto']
   ```

2. **Filter ROME to Pluvicto Only**
   ```python
   # In query_rome_table, default to Pluvicto
   if 'products' not in filters:
       filters['products'] = ['Pluvicto']
   ```

3. **Update SYSTEM_PROMPT**
   ```
   **Default Product Rules:**
   - Market, ROME, Doses questions: Default to Pluvicto if no product specified
   - Sales, Calls questions: May show all 4 products + portfolio total
   - Pluvicto is the flagship product (largest by far)
   ```

4. **Regenerate Calls with Weekly Data**
   - Change from quarterly to weekly
   - Add 52 weeks per year instead of 4 quarters

### Future Enhancements:

5. Add ZIP codes to ROME and Calls
6. Add Territory/State to Calls and Market
7. Add Line of Therapy and Indication to Market
8. Enhance geographic drill-down capabilities

---

## Impact Assessment

### What Works Now:
- ✅ Sales questions (fully aligned)
- ✅ Basic market share questions
- ✅ Basic calls questions (wrong temporality but functional)
- ✅ Basic ROME questions (wrong products but functional)

### What Needs Fixing:
- ❌ Doses queries return wrong products
- ❌ ROME queries return wrong products
- ❌ Calls queries use wrong time granularity
- ❌ No default product logic
- ❌ Limited geographic drill-down

### Risk Level:
- **HIGH:** Doses and ROME returning wrong products
- **MEDIUM:** Calls using quarterly instead of weekly
- **LOW:** Missing geographic granularity (can be added later)

---

## Next Steps

1. **Quick Fix (30 min):**
   - Add default product filters to Doses and ROME queries
   - Update SYSTEM_PROMPT with default rules

2. **Data Regeneration (2-3 hours):**
   - Regenerate Calls with weekly data
   - Filter Doses to Pluvicto only
   - Filter ROME to Pluvicto only

3. **Enhancement (Future):**
   - Add ZIP codes
   - Add clinical dimensions
   - Add full geographic hierarchy

Would you like me to implement the quick fixes now?
