# Data Quality Analysis - Core Executive Tables

## Summary

| Issue Type | Count | Severity |
|------------|-------|----------|
| ✅ Good | 8 | - |
| ⚠️ Issues Found | 12 | Medium-High |
| ❌ Critical Issues | 3 | High |

---

## 1. SALES_FINANCE_BPC (104 rows × 14 columns)

### ✅ What's Good
- Complete data (no nulls)
- 24 months of data (2023-01 to 2024-12)
- Multiple products (Pluvicto, Lutathera, Xofigo, Novacure)
- Both Actual and Forecast data

### ❌ CRITICAL ISSUES

#### Issue 1: Wrong Relative Index Values
**Problem**: Relative indexes use 1, 2, 3, 4 instead of 100, 999, 998, 997
```
Current:  month_rel_index: 1-12, year_rel_index: 1-2, cycle_rel_index: 1-4
Expected: month_rel_index: 100, 999, 998..., year_rel_index: 100, 999, cycle_rel_index: 100, 999, 998, 997
```
**Impact**: HIGH - Queries using relative index logic will fail
**Fix**: Recalculate all relative indexes using the 100/999/998 system

#### Issue 2: Missing "Budget" and "OC" Forecast Types
**Problem**: Only has "Actual" and "Forecast"
```
Current:  ['Actual', 'Forecast']
Expected: ['Actual', 'Budget', 'OC']
```
**Impact**: MEDIUM - Cannot distinguish between Budget (first forecast) and OC (latest forecast)
**Fix**: Rename "Forecast" to "Budget" or "OC" based on data source

### ⚠️ WARNINGS

#### Warning 1: Multiple Products in Financial Table
**Observation**: Has 4 products (Pluvicto, Lutathera, Xofigo, Novacure)
**Question**: Should SALES_FINANCE_BPC include competitor products?
- If YES: This is correct
- If NO: Should only have Pluvicto (MohammadFarma product)

**Recommendation**: Clarify if this is:
- MohammadFarma portfolio (multiple products owned)
- OR only Pluvicto with competitors for comparison

---

## 2. FCT_MARKET_PLU (66 rows × 11 columns)

### ✅ What's Good
- Complete data (no nulls)
- Multiple competitors (Lutathera, Xofigo, Competitor A/B, Other)
- Market share data (TRX_R3M, TRX_SHARE_R3M)
- Class segmentation (pluvicto, xofigo, arpi, taxane, chemo)

### ❌ CRITICAL ISSUES

#### Issue 1: Missing NBRX Columns
**Problem**: Missing new patient demand metrics
```
Current:  11 columns (TRX_R3M, TRX_SHARE_R3M only)
Expected: 13 columns (+ NBRX_R3M, NBRX_SHARE_R3M)
```
**Impact**: HIGH - Cannot track new patient acquisition
**Fix**: Add NBRX_R3M and NBRX_SHARE_R3M columns

#### Issue 2: Wrong Relative Index Values
**Problem**: Same as SALES table - uses 1, 2, 3 instead of 100, 999, 998
```
Current:  month_rel_index: 1-11, year_rel_index: 2, cycle_rel_index: 1-4
Expected: month_rel_index: 100, 999, 998..., year_rel_index: 100, cycle_rel_index: 100, 999, 998, 997
```
**Impact**: HIGH - Queries using relative index logic will fail
**Fix**: Recalculate all relative indexes

#### Issue 3: Date Range Mismatch
**Problem**: Only covers 2024 (11 months), while SALES covers 2023-2024 (24 months)
```
SALES:  2023-01-01 to 2024-12-01 (24 months)
MARKET: 2024-01-01 to 2024-11-01 (11 months)
```
**Impact**: MEDIUM - Cannot compare market share trends with revenue for 2023
**Fix**: Extend market data back to 2023-01-01

### ⚠️ WARNINGS

#### Warning 1: PRODUCT Column Always "Pluvicto"
**Observation**: PRODUCT column only has "Pluvicto", but DIM_Brand has 6 values
**Question**: Is this correct?
- PRODUCT = Market basket category (always "Pluvicto" market)
- DIM_Brand = Individual brands within that market

**Recommendation**: Verify this is intentional. If PRODUCT should vary, add other product categories.

---

## 3. FCT_DOSES_PLU (104 rows × 9 columns)

### ✅ What's Good
- Complete data (no nulls)
- 24 months of data (2023-01 to 2024-12) - matches SALES
- Multiple products (Pluvicto, Lutathera, Xofigo, Novacure)
- Both Actual and Target (forecast) data

### ❌ CRITICAL ISSUES

#### Issue 1: Wrong Relative Index Values
**Problem**: Same as other tables - uses 1, 2, 3 instead of 100, 999, 998
```
Current:  month_rel_index: 1-12, year_rel_index: 1-2, quarter_rel_index: 1-4
Expected: month_rel_index: 100, 999, 998..., year_rel_index: 100, 999, quarter_rel_index: 100, 999, 998, 997
```
**Impact**: HIGH - Queries using relative index logic will fail
**Fix**: Recalculate all relative indexes

#### Issue 2: Missing Metric Types
**Problem**: Only has "shipped_doses" metric
```
Current:  ['shipped_doses']
Expected: ['shipped_doses', 'TRX_shipped', 'TRX_injected', 'NBRX']
```
**Impact**: HIGH - Cannot track injected doses or new patient metrics
**Fix**: Add rows for TRX_injected and NBRX metrics

#### Issue 3: Forecast Type Mismatch
**Problem**: Uses "Target" instead of "Budget" or "OC"
```
SALES:  ['Actual', 'Forecast']
DOSES:  ['Actual', 'Target']
Expected: ['Actual', 'Budget', 'OC']
```
**Impact**: MEDIUM - Inconsistent terminology across tables
**Fix**: Standardize to ['Actual', 'Budget', 'OC']

---

## Cross-Table Issues

### Issue 1: Date Range Inconsistency
```
SALES:  2023-01-01 to 2024-12-01 (24 months) ✅
MARKET: 2024-01-01 to 2024-11-01 (11 months) ❌
DOSES:  2023-01-01 to 2024-12-01 (24 months) ✅
```
**Fix**: Extend MARKET data to match SALES/DOSES range

### Issue 2: Product Consistency
```
SALES:  4 products (Pluvicto, Lutathera, Xofigo, Novacure)
MARKET: 1 product in PRODUCT column, 6 brands in DIM_Brand
DOSES:  4 products (Pluvicto, Lutathera, Xofigo, Novacure)
```
**Question**: Should MARKET.PRODUCT also have 4 products?

### Issue 3: Relative Index System Not Implemented
**All 3 tables** use sequential numbering (1, 2, 3...) instead of the documented system (100, 999, 998...)
**Impact**: HIGH - Core business rule not implemented
**Fix**: Recalculate all relative indexes across all tables

---

## Required Fixes (Priority Order)

### 🔴 CRITICAL (Must Fix)
1. **Recalculate all relative indexes** (month/year/cycle) to use 100/999/998 system
2. **Add NBRX columns to FCT_MARKET_PLU** (NBRX_R3M, NBRX_SHARE_R3M)
3. **Add metric types to FCT_DOSES_PLU** (TRX_injected, NBRX)
4. **Extend FCT_MARKET_PLU date range** to 2023-01-01 (match other tables)

### 🟡 HIGH (Should Fix)
5. **Standardize forecast types** across all tables (Actual/Budget/OC)
6. **Clarify product strategy** - Which products are MohammadFarma vs competitors?
7. **Add missing forecast type "OC"** to SALES and DOSES

### 🟢 MEDIUM (Nice to Have)
8. **Verify PRODUCT vs DIM_Brand logic** in MARKET table
9. **Add more data rows** (currently only 11-24 months, could extend to 36+ months)
10. **Add more competitors** to MARKET table if needed

---

## Data Completeness Score

| Table | Completeness | Issues |
|-------|--------------|--------|
| SALES_FINANCE_BPC | 75% | Missing OC forecast, wrong indexes |
| FCT_MARKET_PLU | 60% | Missing NBRX columns, short date range, wrong indexes |
| FCT_DOSES_PLU | 70% | Missing metric types, wrong indexes |

**Overall**: 68% complete - Needs significant fixes before production use

---

## Recommendations

### Immediate Actions
1. Fix relative index calculations (affects all queries)
2. Add missing NBRX columns to MARKET table
3. Extend MARKET date range to 2023
4. Add TRX_injected and NBRX metrics to DOSES table

### Before Loading to DynamoDB
5. Standardize forecast types (Actual/Budget/OC)
6. Clarify and document product strategy
7. Validate all data ranges and values

### For Production
8. Expand to 36+ months of data
9. Add more granular data (weekly if available)
10. Include confidence intervals for forecasts

---

**Analysis Date**: December 6, 2025
**Analyst**: AI Assistant
**Status**: Ready for fixes
