# MohammadFarma Data Catalogue
## Complete Data Schema Documentation

**Purpose**: C-level Monthly Business Review (MBR) Dashboard
**Company**: MohammadFarma
**Product**: Pluvicto (Radiopharmaceutical)
**Last Updated**: December 6, 2025

---

## Table Overview

| Table Name | Purpose | Row Count | Use Case |
|------------|---------|-----------|----------|
| SALES_FINANCE_BPC | Aggregated sales forecast data | 105 | Performance analysis and planning |
| FCT_MARKET_PLU | Monthly market volumes | 67 | Pluvicto and competitor brands tracking |
| FCT_DOSES_PLU | Dose shipments over time | 105 | Supply chain and demand fulfillment |
| FCT_CALLS | Field activity information | 47 | Sales force effectiveness |
| FCT_ROME_PLU | Order and demand level data | 25 | Across territories, sites, customers and time periods |

---

## 1. SALES_FINANCE_BPC (Financial Performance & Planning)

**Purpose**: Aggregated sales forecast data for performance analysis and planning

### Columns (14 total)

| # | Column Name | Data Type | Description |
|---|-------------|-----------|-------------|
| 1 | **PRODUCT** | String | Product name within market basket (MohammadFarma brand and competitors). Use to retrieve volume or share of specific drug/product |
| 2 | **DIM_Brand** | String | MohammadFarma product name |
| 3 | **DIM_forecast** | String | Forecast type (always needs to be used)<br>• **Actual**: Actual recorded value<br>• **Budget**: First forecast of the year (also called "Target")<br>• **OC**: Latest forecast when available for second half<br>• **Default**: Use OC if available, otherwise Budget |
| 4 | **dim_date** | Date | Month of sales |
| 5 | **net_sales** | Numeric | Net sales in $ |
| 6 | **gross_sales** | Numeric | Gross sales in $ |
| 7 | **revenue_deductions** | Numeric | Revenue deductions in $ |
| 8 | **source** | String | Unique identifier for use case of each set of rows (e.g., "BPC_SALES") |
| 9 | **data_frequency** | String | Shows if data is monthly or weekly |
| 10 | **month_rel_index** | Integer | Relative month index |
| 11 | **year_rel_index** | Integer | Relative year index |
| 12 | **cycle_rel_index** | Integer | Index field for cycle (quarter) |
| 13 | **year_quarter** | String | Year and quarter (e.g., "2023-Q1") |
| 14 | **last_altered** | Timestamp | Timestamp of latest source refresh |

---

## 2. FCT_MARKET_PLU (Market Intelligence)

**Purpose**: Captures monthly market volumes for Pluvicto and competitor brands

### Columns (13 total)

| # | Column Name | Data Type | Description | Status |
|---|-------------|-----------|-------------|--------|
| 1 | **PRODUCT** | String | Product name within market basket (MohammadFarma brand and competitors). Use to retrieve volume or share of specific drug/product | ✅ |
| 2 | **DIM_Brand** | String | MohammadFarma product name | ✅ |
| 3 | **Class** | String | Class of each product with others detailed | ✅ |
| 4 | **class_aggregated** | String | Class of each product with others aggregated | ✅ |
| 5 | **dim_date** | Date | Month of sales | ✅ |
| 6 | **TRX_R3M** | Numeric | Total demand (total injected doses, total infused doses) volume in rolling three months for Pluvicto and market competitors for all lines of therapies | ✅ |
| 7 | **TRX_SHARE_R3M** | Numeric | Share (market share/contribution) in rolling three months for all line therapies | ✅ |
| 8 | **NBRX_R3M** | Numeric | New demand (new patient, new patient start or new patient orders) volume in rolling three months for Pluvicto and market competitors for all lines of therapies | ⚠️ TO ADD |
| 9 | **NBRX_SHARE_R3M** | Numeric | New demand share in rolling three months for Pluvicto and market competitors for all lines of therapies | ⚠️ TO ADD |
| 10 | **month_rel_index** | Integer | Relative month index | ✅ |
| 11 | **year_rel_index** | Integer | Relative year index | ✅ |
| 12 | **cycle_rel_index** | Integer | Index field for cycle (quarter) | ✅ |
| 13 | **year_quarter** | String | Year and quarter (e.g., "2024-Q1") | ✅ |

**Note**: Current synthetic data missing NBRX_R3M and NBRX_SHARE_R3M columns (to be added)

---

## 3. FCT_DOSES_PLU (Supply & Demand)

**Purpose**: Product doses shipped over time

### Columns (9 total)

| # | Column Name | Data Type | Description |
|---|-------------|-----------|-------------|
| 1 | **PRODUCT** | String | Product name within market basket (MohammadFarma brand and competitors) |
| 2 | **DIM_Brand** | String | MohammadFarma product name |
| 3 | **dim_date** | Date | Month of sales |
| 4 | **dim_forecast** | String | Forecast type (always needs to be used)<br>• **Actual**: Actual recorded value<br>• **Budget**: First forecast of the year (also called "Target")<br>• **OC**: Latest forecast when available for second half<br>• **Default**: Use OC if available, otherwise Budget |
| 5 | **value** | Numeric | Value at national level. Should always be used for shipped doses, injected doses or NBRX at national level as well as forecast queries |
| 6 | **metric** | String | Indicates the metric type. Could be:<br>• NBRX<br>• TRX shipped<br>• TRX injected |
| 7 | **month_rel_index** | Integer | Relative month index |
| 8 | **year_rel_index** | Integer | Relative year index |
| 9 | **quarter_rel_index** | Integer | Index field for cycle (quarter) |

---

## 4. FCT_CALLS (Field Force Activity)

**Purpose**: Source of field activity information

### Columns (39 total: 27 existing + 12 to add)

| # | Column Name | Description | Status |
|---|-------------|-------------|--------|
| 1 | **product** | Product name within market basket | ✅ |
| 2 | **source** | Unique identifier for use case of each set of rows | ✅ |
| 3 | **dim_tier** | Healthcare professional tier or tier program | ✅ |
| 4 | **dim_brand** | MohammadFarma product name | ✅ |
| 5 | **dim_time_period** | Type of time period aggregation, always needs to be selected. If time period not provided in question, choose quarter to date (QTD) | ✅ |
| 6 | **dim_metric_type** | Metric type identifier used to select appropriate KPI calculation. Choose value that matches question (e.g., calls per day, HCP reach, call frequency, total calls). This field should always be filtered explicitly to align with KPI being reported | ✅ |
| 7 | **dim_geo_level** | Distinguishing between geographical levels: nation, region, area, territory. If level not defined in question, choose nation | ✅ |
| 8 | **dim_geo_name** | Name of geography in the correspondent geography level | ✅ |
| 9 | **dim_ic_cycle** | Cycle name | ✅ |
| 10 | **CPD** | Average call per day per rep | ✅ |
| 11 | **cpd_goal** | Call per day goal | ✅ |
| 12 | **cpd_attainment** | Call per day attainment | ✅ |
| 13 | **target_hcp_reach** | Total number of healthcare professional reaches (received calls) | ✅ |
| 14 | **total_target** | Total number of healthcare professionals targeted | ✅ |
| 15 | **percent_reached** | % of healthcare professionals reached | ✅ |
| 16 | **hcp_not_reached** | Number of healthcare professionals not reached | ✅ |
| 17 | **call_frequency_actual** | Actual call frequency | ✅ |
| 18 | **call_frequency_attainment** | Call frequency attainment | ✅ |
| 19 | **actual_calls** | Total volume of calls | ✅ |
| 20 | **week_month_num** | Week number in month | ✅ |
| 21 | **geo_id** | Unique identifier of geography | ✅ |
| 22 | **therapeutic_area** | Therapeutic area | ✅ |
| 23 | **sub_therapeutic_area** | Sub therapeutic area | ✅ |
| 24 | **zero_call_day** | Number of days with no calls | ✅ |
| 25 | **planned_calls** | Total of planned calls | ✅ |
| 26 | **year_quarter** | Year and quarter (e.g., 2024-Q1) | ✅ |
| 27 | **dim_date** | Date | ✅ |
| 28 | **cycle_rel_index** | Index field for cycle (quarter). 100=current, 999=last quarter | ⚠️ TO ADD |
| 29 | **call_date** | Date of call correspondent to the time period | ⚠️ TO ADD |
| 30 | **period_start_date** | Start date of time period | ⚠️ TO ADD |
| 31 | **period_end_date** | End date of time period | ⚠️ TO ADD |
| 32 | **total_week_mth** | Total weeks in month | ⚠️ TO ADD |
| 33 | **working_day** | Total working days | ⚠️ TO ADD |
| 34 | **prorated_planned_calls** | Planned calls adjusted to time period and cycle week | ⚠️ TO ADD |
| 35 | **prorated_call_frequency_goal** | Call frequency goal adjusted to time period and cycle week | ⚠️ TO ADD |
| 36 | **prorated_hcp_reach_goal** | HCP reach goal adjusted to time period and cycle week | ⚠️ TO ADD |
| 37 | **reporting_week_date** | Latest week of calls available | ⚠️ TO ADD |
| 38 | **incentive_start_date** | Cycle start date | ⚠️ TO ADD |
| 39 | **last_altered** | Timestamp of latest source refresh | ⚠️ TO ADD |

---

## 5. FCT_ROME_PLU (Order Management)

**Purpose**: Order and demand level data across territories, sites, customers and time periods

**Note**: Contains PII data - some columns removed for privacy

### Columns (41 total - no additional columns to add per privacy requirements)

| # | Column Name | Description |
|---|-------------|-------------|
| 1 | **PRODUCT** | Product name within market basket |
| 2 | **DIM_Brand** | MohammadFarma product name |
| 3 | **dim_date** | Date |
| 4 | **dim_customer_name** | Name of customer |
| 5 | **dim_order_status** | Order status used to calculate doses, patients, volume, total demand, new demand or injection related questions |
| 6 | **dim_order_type** | Identifies commercial vs non-commercial PRD orders |
| 7 | **dim_order_group** | Identifies either an order is for prefilled syringes or for vial-based products |
| 8 | **dim_ecosystem** | Ecosystem type (e.g., Integrated, Independent) |
| 9 | **dim_account_status** | Account status (e.g., Onboarded, Pending) |
| 10 | **dim_site_type** | Type of site (e.g., Academic, Community, Hospital) |
| 11 | **dim_terr_name** | Territory name |
| 12 | **dim_area_name** | Area name |
| 13 | **dim_region_name** | Region name |
| 14 | **dim_tier** | Tier classification |
| 15 | **dim_system_name** | System name |
| 16 | **month_rel_index** | Relative month index (100=current, 999=last month) |
| 17 | **year_rel_index** | Relative year index (100=current, 999=last year) |
| 18 | **cycle_rel_index** | Relative cycle/quarter index (100=current, 999=last quarter) |
| 19 | **year_quarter** | Year and quarter (e.g., 2024-Q1) |
| 20 | **sales_order_number** | Sales order number |
| 21 | **treatment_id** | Treatment ID |
| 22 | **insurance_provider** | Insurance provider name |
| 23 | **patient_reference_number** | Patient reference number |
| 24 | **cancellation_date** | Date of order cancellation |
| 25 | **cancellation_unused_dose_reason** | Reason for unused dose cancellation |
| 26 | **cancellation_unused_dose_other_reason** | Other reason for unused dose cancellation |
| 27 | **referring_physician** | Referring physician name |
| 28 | **ordering_physician** | Ordering physician name |
| 29 | **site_id** | Site identifier |
| 30 | **active_dormant_flag** | Active or dormant status flag |
| 31 | **dose_number** | Dose number in treatment sequence |
| 32 | **is_patients_first_dose** | Flag indicating if this is patient's first dose (Yes/No) |
| 33 | **order_status_customer** | Customer-facing order status |
| 34 | **delivery_address** | Delivery street address |
| 35 | **delivery_address_city** | Delivery city |
| 36 | **delivery_address_zip** | Delivery ZIP code |
| 37 | **state** | State |
| 38 | **country** | Country |
| 39 | **terr_id** | Territory ID |
| 40 | **area_id** | Area ID |
| 41 | **region_id** | Region ID |

---

## Common Dimensions Across Tables

### Shared Columns

| Column Name | Tables | Description |
|-------------|--------|-------------|
| **PRODUCT** | All | Product name within market basket |
| **DIM_Brand** | All | MohammadFarma product name |
| **dim_date** | All | Date dimension (monthly) |
| **month_rel_index** | All except CALLS | Relative month index<br>• **100** = Current month<br>• **999** = Last month (1 month ago)<br>• **998** = 2 months ago<br>• Counts backwards from 100 |
| **year_rel_index** | All except CALLS | Relative year index<br>• **100** = Current year<br>• **999** = Last year (1 year ago)<br>• **998** = 2 years ago<br>• Counts backwards from 100 |
| **cycle_rel_index** / **quarter_rel_index** | All except CALLS | Relative quarter/cycle index<br>• **100** = Current quarter<br>• **999** = Last quarter (1 quarter ago)<br>• **998** = 2 quarters ago<br>• Counts backwards from 100 |
| **year_quarter** | All | Year and quarter (e.g., "2024-Q1") |
| **DIM_forecast** | SALES, DOSES | Forecast type (Actual/Budget/OC) |

---

## Data Quality Notes

### Missing Columns (To Be Added to Synthetic Data)

1. **FCT_MARKET_PLU** (2 columns):
   - NBRX_R3M (column 8)
   - NBRX_SHARE_R3M (column 9)

2. **FCT_CALLS** (12 columns):
   - cycle_rel_index
   - call_date
   - period_start_date
   - period_end_date
   - total_week_mth
   - working_day
   - prorated_planned_calls
   - prorated_call_frequency_goal
   - prorated_hcp_reach_goal
   - reporting_week_date
   - incentive_start_date
   - last_altered

**Total Missing Columns**: 14 across 2 tables

---

## Business Rules

### Relative Index Logic (month_rel_index, year_rel_index, cycle_rel_index)
**Indexing System**: Counts backwards from 100
- **100** = Current period (current month/year/quarter)
- **999** = 1 period ago (last month/year/quarter)
- **998** = 2 periods ago
- **997** = 3 periods ago
- And so on...

**Examples**:
- If today is December 2024:
  - `year_rel_index = 100` → 2024 (current year)
  - `year_rel_index = 999` → 2023 (last year)
  - `year_rel_index = 998` → 2022 (2 years ago)
  - `month_rel_index = 100` → December 2024
  - `month_rel_index = 999` → November 2024
  - `cycle_rel_index = 100` → Q4 2024
  - `cycle_rel_index = 999` → Q3 2024

### Forecast Type Logic (DIM_forecast)
When a question asks for "forecast" without specifying type:
1. Use **OC** (Operating Case) if available
2. Otherwise use **Budget**
3. **Actual** is always for recorded values only

### Metric Types (FCT_DOSES_PLU)
- **NBRX**: New patient demand
- **TRX shipped**: Total shipped doses
- **TRX injected**: Total injected doses

### Market Metrics (FCT_MARKET_PLU)
- **TRX**: Total demand (all patients)
- **NBRX**: New patient demand only
- **R3M**: Rolling 3 months
- **SHARE**: Market share percentage

---

## Use Cases for C-Level MBR

### Financial Performance
- Revenue trends (actual vs budget vs OC)
- Gross to net analysis
- Quarterly performance

### Market Position
- Market share trends
- Competitive analysis (Pluvicto vs Lutathera)
- New patient acquisition

### Operational Metrics
- Dose shipments vs demand
- Order pipeline by geography
- Field force effectiveness

### Geographic Analysis
- Territory/Area/Region performance
- Site-level analysis
- State/country breakdowns

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2025-12-06 | Initial data catalogue creation |

---

**Document Owner**: MohammadFarma Data Team
**Contact**: [To be added]
**Review Frequency**: Monthly
