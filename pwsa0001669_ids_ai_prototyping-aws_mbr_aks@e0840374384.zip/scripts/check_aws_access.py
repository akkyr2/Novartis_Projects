#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Check AWS access and permissions for all required services
"""

import boto3
import csv
from botocore.exceptions import ClientError, NoCredentialsError

# Load credentials from CSV (handle BOM)
with open('isenguard_access/mbabakme-cli_accessKeys.csv', 'r', encoding='utf-8-sig') as f:
    reader = csv.DictReader(f)
    creds = next(reader)
    ACCESS_KEY = creds['Access key ID'].strip()
    SECRET_KEY = creds['Secret access key'].strip()

# Create session with credentials
session = boto3.Session(
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name='us-east-1'  # Default region
)

print("=" * 80)
print("AWS ACCESS VERIFICATION")
print("=" * 80)

# Services we need for MBR Dashboard
services_to_check = {
    'sts': 'AWS Security Token Service (Identity)',
    'dynamodb': 'DynamoDB (KPI Storage)',
    's3': 'S3 (File Storage)',
    'lambda': 'Lambda (Compute)',
    'apigateway': 'API Gateway (WebSocket)',
    'transcribe': 'Transcribe (Speech-to-Text)',
    'polly': 'Polly (Text-to-Speech)',
    'bedrock': 'Bedrock (LLM)',
    'bedrock-runtime': 'Bedrock Runtime (LLM Inference)',
    'opensearch': 'OpenSearch (Vector Search)',
    'secretsmanager': 'Secrets Manager',
    'cloudformation': 'CloudFormation (IaC)',
    'iam': 'IAM (Permissions)'
}

results = {}

# 1. Check identity
print("\n1. CHECKING IDENTITY")
print("-" * 80)
try:
    sts = session.client('sts')
    identity = sts.get_caller_identity()
    print(f"✅ Account ID: {identity['Account']}")
    print(f"✅ User ARN: {identity['Arn']}")
    print(f"✅ User ID: {identity['UserId']}")
    results['identity'] = True
except Exception as e:
    print(f"❌ Failed to get identity: {e}")
    results['identity'] = False

# 2. Check each service
print("\n2. CHECKING SERVICE ACCESS")
print("-" * 80)

for service, description in services_to_check.items():
    try:
        client = session.client(service)
        
        # Try a simple read operation for each service
        if service == 'sts':
            client.get_caller_identity()
        elif service == 'dynamodb':
            client.list_tables(Limit=1)
        elif service == 's3':
            client.list_buckets()
        elif service == 'lambda':
            client.list_functions(MaxItems=1)
        elif service == 'apigateway':
            client.get_rest_apis(limit=1)
        elif service == 'transcribe':
            client.list_transcription_jobs(MaxResults=1)
        elif service == 'polly':
            client.describe_voices(LanguageCode='en-US')
        elif service == 'bedrock':
            client.list_foundation_models()
        elif service == 'bedrock-runtime':
            # Just check if we can create the client
            pass
        elif service == 'opensearch':
            client.list_domain_names()
        elif service == 'secretsmanager':
            client.list_secrets(MaxResults=1)
        elif service == 'cloudformation':
            client.list_stacks(MaxResults=1)
        elif service == 'iam':
            client.list_roles(MaxItems=1)
        
        print(f"✅ {description}")
        results[service] = True
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'AccessDenied' or error_code == 'UnauthorizedOperation':
            print(f"❌ {description} - Access Denied")
        else:
            print(f"⚠️  {description} - {error_code}")
        results[service] = False
    except Exception as e:
        print(f"⚠️  {description} - {str(e)[:50]}")
        results[service] = False

# 3. Check available regions
print("\n3. CHECKING AVAILABLE REGIONS")
print("-" * 80)
try:
    ec2 = session.client('ec2', region_name='us-east-1')
    regions = ec2.describe_regions()
    region_names = [r['RegionName'] for r in regions['Regions']]
    print(f"✅ Available regions: {len(region_names)}")
    print(f"   Recommended: us-east-1, us-west-2")
    results['regions'] = True
except Exception as e:
    print(f"❌ Failed to list regions: {e}")
    results['regions'] = False

# 4. Check Bedrock models
print("\n4. CHECKING BEDROCK MODELS")
print("-" * 80)
if results.get('bedrock', False):
    try:
        bedrock = session.client('bedrock', region_name='us-east-1')
        models = bedrock.list_foundation_models()
        
        # Look for Claude models
        claude_models = [m for m in models['modelSummaries'] 
                        if 'claude' in m['modelId'].lower()]
        
        if claude_models:
            print(f"✅ Found {len(claude_models)} Claude models")
            for model in claude_models[:3]:
                print(f"   • {model['modelId']}")
        else:
            print("⚠️  No Claude models found")
            
        results['bedrock_models'] = True
    except Exception as e:
        print(f"❌ Failed to list Bedrock models: {e}")
        results['bedrock_models'] = False
else:
    print("⚠️  Skipped (no Bedrock access)")
    results['bedrock_models'] = False

# Summary
print("\n" + "=" * 80)
print("SUMMARY")
print("=" * 80)

total = len(results)
passed = sum(1 for v in results.values() if v)
failed = total - passed

print(f"\nTotal Checks: {total}")
print(f"✅ Passed: {passed}")
print(f"❌ Failed: {failed}")

if failed == 0:
    print("\n🎉 All services accessible! Ready to build the MBR Dashboard.")
else:
    print("\n⚠️  Some services are not accessible. You may need to:")
    print("   1. Request additional permissions in Isengard")
    print("   2. Use a different AWS account")
    print("   3. Adjust the architecture to use available services")

print("\nCritical Services for MBR Dashboard:")
critical = ['dynamodb', 's3', 'lambda', 'bedrock', 'bedrock-runtime', 'transcribe', 'polly']
critical_status = all(results.get(svc, False) for svc in critical)
if critical_status:
    print("✅ All critical services are accessible")
else:
    print("❌ Some critical services are missing:")
    for svc in critical:
        if not results.get(svc, False):
            print(f"   • {services_to_check[svc]}")

print("=" * 80)
