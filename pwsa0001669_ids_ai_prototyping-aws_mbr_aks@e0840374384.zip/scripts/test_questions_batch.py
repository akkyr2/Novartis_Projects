#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Automated testing script for MBR Dashboard - Batch Runner
Reads questions from SAMPLE_QUESTIONS.md and runs in batches
"""

import requests
import json
import time
import csv
import re
from datetime import datetime

# Backend API endpoint
API_URL = "http://localhost:5000/api/ask"

def parse_questions_from_md(filename='SAMPLE_QUESTIONS.md'):
    """Parse questions from the markdown file"""
    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    questions = []
    
    # Find all question blocks (questions 6-60)
    pattern = r'\*\*(\d+)\.\s+([^\*]+)\*\*\s+\*\*Question:\*\*\s+"([^"]+)"'
    matches = re.findall(pattern, content)
    
    for match in matches:
        q_id = int(match[0])
        if q_id >= 6:  # Only questions 6 and above
            questions.append({
                'id': q_id,
                'title': match[1].strip(),
                'question': match[2].strip()
            })
    
    return sorted(questions, key=lambda x: x['id'])

def calculate_difficulty(question):
    """Calculate question difficulty (1-5)"""
    difficulty = 1
    q_lower = question.lower()
    
    if 'compare' in q_lower or 'versus' in q_lower:
        difficulty += 1
    if 'confidence interval' in q_lower:
        difficulty += 1
    if 'trend' in q_lower or 'over time' in q_lower:
        difficulty += 1
    if 'projection' in q_lower or 'forecast' in q_lower:
        difficulty += 1
    if 'which' in q_lower or 'fastest' in q_lower or 'lowest' in q_lower or 'highest' in q_lower:
        difficulty += 1
    
    return min(difficulty, 5)

def categorize_question(question):
    """Categorize question by data type"""
    q_lower = question.lower()
    categories = []
    
    if 'enrollment' in q_lower:
        categories.append('Enrollment')
    if any(c in q_lower for c in ['county', 'counties', 'los angeles', 'orange', 'san diego']):
        categories.append('County')
    if any(y in q_lower for y in ['projection', 'forecast', '2026', '2027', '2028']):
        categories.append('Projection')
    if 'trend' in q_lower or 'over time' in q_lower or 'growth' in q_lower:
        categories.append('Time-Series')
    if 'plan' in q_lower:
        categories.append('Plan')
    if 'chart' in q_lower or 'graph' in q_lower:
        categories.append('Visualization')
    if 'compare' in q_lower:
        categories.append('Comparison')
    if 'demographic' in q_lower or 'age' in q_lower or 'gender' in q_lower:
        categories.append('Demographics')
    if 'quality' in q_lower or 'hedis' in q_lower or 'star' in q_lower:
        categories.append('Quality')
    if 'care' in q_lower or 'coordination' in q_lower:
        categories.append('Care-Coordination')
    if 'behavioral' in q_lower or 'mental' in q_lower:
        categories.append('Behavioral-Health')
    if 'grievance' in q_lower or 'appeal' in q_lower:
        categories.append('Grievances')
    if 'confidence' in q_lower and 'interval' in q_lower:
        categories.append('Confidence-Interval')
    
    return '|'.join(categories) if categories else 'General'

def evaluate_answer_quality(question, answer, has_chart):
    """Evaluate answer quality and generate confidence score with reasoning"""
    score = 0
    reasons = []
    
    q_lower = question.lower()
    a_lower = answer.lower()
    
    # CRITICAL: Check for failure indicators first
    failure_phrases = [
        "don't have", "not available", "don't see", "not displayed",
        "would need", "i'll need", "could you provide", "please navigate",
        "not shown", "cannot find", "unable to", "doesn't show"
    ]
    
    has_failure_phrase = any(phrase in a_lower for phrase in failure_phrases)
    
    if has_failure_phrase:
        score = 15  # Very low score for "data not available" responses
        reasons.append("[X] Data not available / Cannot answer")
        return score, '; '.join(reasons)
    
    # If we get here, the AI attempted to answer
    score = 50  # Base score for attempting to answer
    reasons.append("[+] Attempted to answer")
    
    # Check for specific data indicators
    has_numbers = bool(re.search(r'\d{1,3}(,\d{3})*', answer))  # Look for formatted numbers
    if has_numbers:
        score += 20
        reasons.append("[+] Contains numerical data")
    else:
        reasons.append("[!] No specific numbers")
    
    # Check for relevant keywords
    if 'enrollment' in q_lower and 'enrollment' in a_lower:
        score += 5
        reasons.append("[+] Keyword: enrollment")
    if 'county' in q_lower and 'county' in a_lower:
        score += 5
        reasons.append("[+] Keyword: county")
    if 'projection' in q_lower and ('projection' in a_lower or 'projected' in a_lower):
        score += 5
        reasons.append("[+] Keyword: projection")
    
    # Chart evaluation
    expects_chart = any(word in q_lower for word in ['chart', 'show me', 'display', 'graph', 'pie', 'bar', 'line'])
    
    if expects_chart:
        if has_chart:
            score += 15
            reasons.append("[+] Chart generated")
        else:
            score -= 15
            reasons.append("[X] Missing expected chart")
    else:
        # Simple "what is" or "which" questions shouldn't have charts
        if has_chart:
            score -= 5
            reasons.append("[!] Unexpected chart")
        else:
            score += 5
            reasons.append("[+] No chart (correct)")
    
    # Confidence interval check
    if 'confidence interval' in q_lower or 'confidence' in q_lower:
        if 'confidence' in a_lower and ('interval' in a_lower or 'bound' in a_lower or 'range' in a_lower):
            score += 10
            reasons.append("[+] Confidence interval provided")
        else:
            score -= 10
            reasons.append("[X] Missing confidence interval")
    
    # Comparison check
    if 'compare' in q_lower or 'versus' in q_lower or 'vs' in q_lower:
        # Look for multiple entities being compared
        entity_count = a_lower.count('county') + a_lower.count('plan') + a_lower.count('members')
        if entity_count >= 2:
            score += 10
            reasons.append("[+] Comparison provided")
        else:
            score -= 10
            reasons.append("[X] Incomplete comparison")
    
    # "Which" questions need to identify a specific answer
    if q_lower.startswith('which'):
        # Should have a definitive answer
        if any(word in a_lower for word in ['highest', 'lowest', 'best', 'most', 'least']):
            score += 10
            reasons.append("[+] Definitive answer to 'which' question")
        else:
            score -= 10
            reasons.append("❌ No definitive answer to 'which' question")
    
    score = max(0, min(100, score))  # Clamp to 0-100
    
    return score, '; '.join(reasons)

def test_question(question_data, slide_number=1):
    """Test a single question"""
    print(f"\n{'='*80}")
    print(f"Question #{question_data['id']}: {question_data['title']}")
    print(f"Q: {question_data['question']}")
    print(f"{'='*80}")
    
    result = {
        'question_id': question_data['id'],
        'question_title': question_data['title'],
        'question': question_data['question'],
        'data_type': categorize_question(question_data['question']),
        'difficulty': calculate_difficulty(question_data['question']),
        'answer': '',
        'has_chart': False,
        'chart_type': '',
        'response_time': 0.0,
        'confidence_score': 0.0,
        'pass_fail': 'FAIL',
        'reason': '',
        'error': ''
    }
    
    payload = {
        "question": question_data["question"],
        "slideNumber": slide_number,
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        start_time = time.time()
        response = requests.post(API_URL, json=payload, timeout=60)
        response_time = time.time() - start_time
        result['response_time'] = round(response_time, 2)
        
        if response.status_code != 200:
            result['error'] = f"HTTP {response.status_code}"
            print(f"❌ FAILED: {result['error']}")
            return result
        
        data = response.json()
        answer = data.get('answer', '')
        chart_data = data.get('chartData')
        
        result['answer'] = answer
        result['has_chart'] = chart_data is not None
        if chart_data:
            result['chart_type'] = chart_data.get('type', '')
        
        # Evaluate answer quality
        confidence_score, reason = evaluate_answer_quality(
            question_data['question'], 
            answer, 
            result['has_chart']
        )
        
        result['confidence_score'] = confidence_score
        result['reason'] = reason
        result['pass_fail'] = 'PASS' if confidence_score >= 60 else 'FAIL'
        
        if result['pass_fail'] == 'PASS':
            print(f"✅ PASS ({result['response_time']}s, Score: {confidence_score}%)")
        else:
            print(f"❌ FAIL ({result['response_time']}s, Score: {confidence_score}%)")
        
        print(f"   Answer: {answer[:150]}...")
        if result['has_chart']:
            print(f"   Chart: {result['chart_type']}")
        print(f"   Reason: {reason}")
        
        return result
            
    except requests.exceptions.Timeout:
        result['error'] = "Request timeout (60s)"
        print(f"❌ TIMEOUT")
        return result
    except Exception as e:
        result['error'] = str(e)
        print(f"❌ ERROR: {result['error'][:100]}")
        return result

def run_batch(questions, batch_num, total_batches):
    """Run a batch of questions"""
    print("\n" + "=" * 80)
    print(f"🧪 BATCH {batch_num}/{total_batches}")
    print("=" * 80)
    print(f"Questions: {questions[0]['id']} - {questions[-1]['id']}")
    print(f"Count: {len(questions)}")
    print("=" * 80)
    
    results = []
    
    for i, question in enumerate(questions, 1):
        print(f"\n[{i}/{len(questions)}] ", end='')
        result = test_question(question)
        results.append(result)
        
        # Delay between questions
        if i < len(questions):
            time.sleep(2)
    
    return results

def save_results(all_results, filename):
    """Save results to CSV"""
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = [
            'question_id', 'question_title', 'question', 'data_type', 'difficulty',
            'answer', 'has_chart', 'chart_type', 'response_time', 
            'confidence_score', 'pass_fail', 'reason', 'error'
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_results)
    
    print(f"\n✅ Results saved to: {filename}")

def print_summary(all_results):
    """Print test summary"""
    passed = sum(1 for r in all_results if r['pass_fail'] == 'PASS')
    failed = sum(1 for r in all_results if r['pass_fail'] == 'FAIL')
    total = len(all_results)
    
    print("\n" + "=" * 80)
    print("📊 FINAL SUMMARY")
    print("=" * 80)
    print(f"Total Questions: {total}")
    print(f"✅ Passed: {passed} ({passed/total*100:.1f}%)")
    print(f"❌ Failed: {failed} ({failed/total*100:.1f}%)")
    
    if all_results:
        avg_time = sum(r['response_time'] for r in all_results) / len(all_results)
        print(f"⏱️  Avg Response Time: {avg_time:.2f}s")
    
    # Category breakdown
    category_stats = {}
    for result in all_results:
        for cat in result['data_type'].split('|'):
            if cat not in category_stats:
                category_stats[cat] = {'passed': 0, 'failed': 0}
            if result['pass_fail'] == 'PASS':
                category_stats[cat]['passed'] += 1
            else:
                category_stats[cat]['failed'] += 1
    
    print("\n📂 BY CATEGORY:")
    print("-" * 80)
    for cat, stats in sorted(category_stats.items()):
        total_cat = stats['passed'] + stats['failed']
        pass_rate = (stats['passed'] / total_cat * 100) if total_cat > 0 else 0
        print(f"{cat:25} | {stats['passed']:2}/{total_cat:2} ({pass_rate:5.1f}%)")
    
    print("=" * 80)

def main():
    print("=" * 80)
    print("🧪 MBR Dashboard Comprehensive Testing")
    print("=" * 80)
    
    # Check backend
    try:
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        if response.status_code != 200:
            print("❌ Backend not responding. Start backend first.")
            return
    except:
        print("❌ Cannot connect to backend. Start backend first.")
        return
    
    # Parse questions
    print("\n📖 Parsing questions from SAMPLE_QUESTIONS.md...")
    questions = parse_questions_from_md()
    print(f"✅ Found {len(questions)} questions (IDs: {questions[0]['id']}-{questions[-1]['id']})")
    
    # Split into 3 batches
    batch_size = len(questions) // 3
    batches = [
        questions[:batch_size],
        questions[batch_size:batch_size*2],
        questions[batch_size*2:]
    ]
    
    print(f"\n📦 Split into 3 batches:")
    for i, batch in enumerate(batches, 1):
        print(f"   Batch {i}: Questions {batch[0]['id']}-{batch[-1]['id']} ({len(batch)} questions)")
    
    all_results = []
    
    # Run batches
    for i, batch in enumerate(batches, 1):
        batch_results = run_batch(batch, i, 3)
        all_results.extend(batch_results)
        
        # Wait between batches (except after last batch)
        if i < 3:
            print(f"\n⏸️  Waiting 60 seconds before batch {i+1}...")
            time.sleep(60)
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"test_results_complete_{timestamp}.csv"
    save_results(all_results, filename)
    
    # Print summary
    print_summary(all_results)

if __name__ == '__main__':
    main()
