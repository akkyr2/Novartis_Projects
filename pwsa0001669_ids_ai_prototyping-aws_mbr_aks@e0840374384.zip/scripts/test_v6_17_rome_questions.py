#!/usr/bin/env python3
"""
Test V6 Agent Handler with 17 ROME Questions - End-to-End

Tests the V6 Final handler with only the 17 ROME questions to compare with
the working v6_workflow_test_results.json

Features:
- Uses novartis_agent_handler_v6_final (with classifier routing)
- Uses novartis_prompts_v6 (separated prompts)
- Uses novartis_queries_v6_final (all 11 tools)
- Captures tool calls and timing
- Saves results to JSON for comparison

Output:
- v6_17_rome_questions_results.json (full results)
"""

import sys
import os
import json
import time
from datetime import datetime

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, project_root)

from backend_api.novartis_agent_handler_v6_final import handle_question_with_agent, classify_question

# ============================================================================
# 17 ROME QUESTIONS (Exact same as working test)
# ============================================================================

ROME_QUESTIONS = [
    {
        "id": "Q1",
        "question": "What is the split between academic vs community setting accounts in new patient starts?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q2",
        "question": "Which month had the highest new patient volume?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q3",
        "question": "Which area is showing the biggest decline in new patient starts?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q4",
        "question": "Whats the uptake post pre-taxane mCRPC indication approval in new patients starts?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q5",
        "question": "What is the split between academic vs community setting accounts in new patient orders?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q6",
        "question": "Which month had the highest new patient order volume?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q7",
        "question": "Which territory is showing the biggest decline in new patient orders?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q8",
        "question": "What % of new patients are coming from Urology sites/community urologists, and how has that evolved over time?",
        "expected_helper": "deduplicate_and_aggregate"
    },
    {
        "id": "Q9",
        "question": "Show me top 10 sites by volume",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q10",
        "question": "Sites that have not onboarded",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q11",
        "question": "Sites that have onboarded",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q12",
        "question": "How many sites have onboarded vs not onboarded?",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q13",
        "question": "How many dormant sites do we have and how does that compare to last quarter?",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q14",
        "question": "Which territories are performing below nation in volume (total shipped doses) growth?",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q15",
        "question": "Show me Top 10 accounts based on QTD shipped dose volume",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q16",
        "question": "Whats the uptake post pre-taxane mCRPC indication approval in total doses?",
        "expected_helper": "simple_aggregate"
    },
    {
        "id": "Q17",
        "question": "What is the contribution od each Ecosystem in new patient orders?",
        "expected_helper": "deduplicate_and_aggregate"
    }
]

# ============================================================================
# TEST EXECUTION
# ============================================================================

def main():
    """Run all 17 ROME questions through v6_final handler"""
    
    print("="*100)
    print("Testing V6 Final Handler - 17 ROME Questions")
    print("="*100)
    print()
    print(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Handler: novartis_agent_handler_v6_final")
    print(f"Questions: {len(ROME_QUESTIONS)}")
    print()
    
    results = []
    
    for i, q_data in enumerate(ROME_QUESTIONS, 1):
        qid = q_data['id']
        question = q_data['question']
        
        print(f"\n{'='*100}")
        print(f"Question {i}/17 [{qid}]")
        print(f"{'='*100}")
        print(f"Q: {question}")
        
        # Verify classification
        classification = classify_question(question)
        print(f"✅ Classification: {classification} (correct)" if classification == 'rome' else f"❌ Classification: {classification} (expected rome)")
        
        # Execute question
        print(f"\n🤖 Executing V6 Final Handler...")
        start_time = time.time()
        
        try:
            answer, chart_data, audio_summary, data_source, tool_calls = handle_question_with_agent(
                question, 
                return_tool_calls=True
            )
            
            execution_time = time.time() - start_time
            
            # Extract tool names
            tool_names = [tc['tool_name'] for tc in tool_calls if tc.get('success')]
            tool_call_count = len(tool_calls)
            
            # Check if expected helper was used
            expected_helper = q_data['expected_helper']
            helper_used = expected_helper in tool_names
            any_helper_used = any(tool in tool_names for tool in ['deduplicate_and_aggregate', 'simple_aggregate'])
            
            success = bool(answer and len(answer) > 0)
            
            print(f"\n✅ Completed in {execution_time:.1f}s")
            print(f"   Tools used: {' → '.join(tool_names)}")
            print(f"   Tool calls: {tool_call_count}")
            print(f"   Answer length: {len(answer)} chars")
            
            # Store result
            results.append({
                "question_id": qid,
                "question": question,
                "success": success,
                "analysis": {
                    "success": success,
                    "tool_names": tool_names,
                    "helper_used": helper_used,
                    "any_helper_used": any_helper_used,
                    "expected_helper": expected_helper,
                    "workflow_complete": success,
                    "final_answer": answer,
                    "tool_call_count": tool_call_count
                },
                "timing": [{"tool": tc['tool_name'], "duration_ms": tc['duration_ms']} for tc in tool_calls],
                "execution_time": execution_time
            })
            
        except Exception as e:
            print(f"\n❌ Error: {str(e)}")
            import traceback
            traceback.print_exc()
            
            results.append({
                "question_id": qid,
                "question": question,
                "success": False,
                "error": str(e),
                "execution_time": time.time() - start_time
            })
    
    # Save results
    output_file = 'v6_17_rome_questions_results.json'
    
    output_data = {
        "test_date": datetime.now().isoformat(),
        "model": "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        "handler": "novartis_agent_handler_v6_final",
        "total_questions": len(ROME_QUESTIONS),
        "passed": sum(1 for r in results if r.get('success')),
        "failed": sum(1 for r in results if not r.get('success')),
        "results": results
    }
    
    with open(output_file, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"\n\n{'='*100}")
    print("SUMMARY")
    print(f"{'='*100}")
    print(f"\nTotal: {len(ROME_QUESTIONS)}")
    print(f"✅ Passed: {output_data['passed']}")
    print(f"❌ Failed: {output_data['failed']}")
    print(f"\n📄 Results saved to: {output_file}")
    print(f"\n{'='*100}\n")

if __name__ == '__main__':
    main()
