#!/usr/bin/env python3
"""
Test V6 Agent Handler with 11 CALLS Questions - End-to-End

Tests the V6 Final handler with only the 11 CALLS questions to verify
field activity and HCP reach functionality.

Features:
- Uses novartis_agent_handler_v6_final (with classifier routing)
- Uses novartis_prompts_v6 (separated prompts)
- Uses novartis_queries_v6_final (all 11 tools)
- Captures tool calls and timing
- Prints full LLM answers
- Saves results to JSON for comparison

Output:
- v6_11_calls_questions_results.json (full results)
"""

import sys
import os
import json
import time
from datetime import datetime

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, project_root)

from backend_api.novartis_agent_handler_v6_final import handle_question_with_agent, classify_question

# ============================================================================
# 11 CALLS QUESTIONS (from ACCURACY_TEST_REPORT.md + V5_TEST_RESULTS.md)
# ============================================================================

CALLS_QUESTIONS = [
    {
        "id": "C1",
        "question": "What is calls per day by Region for all Tiers?",
        "expected_classification": "general"
    },
    {
        "id": "C2",
        "question": "What is the average number of calls per day per Rep for All Tiers including goal and attainment?",
        "expected_classification": "general"
    },
    {
        "id": "C3",
        "question": "What are the top 5 territories by HCPs reached for top 2 tiers?",
        "expected_classification": "general"
    },
    {
        "id": "C4",
        "question": "What is the calls per day (CPD) by Region for all Tiers in 2025?",
        "expected_classification": "general"
    },
    {
        "id": "C5",
        "question": "Show me HCP reach by Territory for T1 in Q3 2025",
        "expected_classification": "general"
    },
    {
        "id": "C6",
        "question": "What is the call frequency attainment by Area for Top 2 Tiers in 2025?",
        "expected_classification": "general"
    },
    {
        "id": "C7",
        "question": "Show total calls by Region for all Tiers in Q4 2025",
        "expected_classification": "general"
    },
    {
        "id": "C8",
        "question": "What is CPD by Territory for T2 in the last 4 weeks of 2025?",
        "expected_classification": "general"
    },
    {
        "id": "C9",
        "question": "Show HCP reach by Area for T3 in 2025",
        "expected_classification": "general"
    },
    {
        "id": "C10",
        "question": "What is call frequency attainment by Region for NT tier in Q2 2025?",
        "expected_classification": "general"
    },
    {
        "id": "C11",
        "question": "Show me total calls by Territory for all Tiers in 2025",
        "expected_classification": "general"
    }
]

# ============================================================================
# TEST EXECUTION
# ============================================================================

def main():
    """Run all 11 CALLS questions through v6_final handler"""
    
    print("="*100)
    print("Testing V6 Final Handler - 11 CALLS Questions")
    print("="*100)
    print()
    print(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Handler: novartis_agent_handler_v6_final")
    print(f"Questions: {len(CALLS_QUESTIONS)}")
    print()
    
    results = []
    
    for i, q_data in enumerate(CALLS_QUESTIONS, 1):
        qid = q_data['id']
        question = q_data['question']
        expected_classification = q_data['expected_classification']
        
        print(f"\n{'='*100}")
        print(f"Question {i}/11 [{qid}]")
        print(f"{'='*100}")
        print(f"Q: {question}")
        
        # Verify classification
        classification = classify_question(question)
        classification_correct = classification == expected_classification
        
        if classification_correct:
            print(f"✅ Classification: {classification} (correct)")
        else:
            print(f"❌ Classification: {classification} (expected {expected_classification})")
        
        # Execute question
        print(f"\n🤖 Executing V6 Final Handler...")
        start_time = time.time()
        
        try:
            answer, chart_data, audio_summary, data_source, tool_calls = handle_question_with_agent(
                question, 
                return_tool_calls=True
            )
            
            execution_time = time.time() - start_time
            
            # Extract tool names
            tool_names = [tc['tool_name'] for tc in tool_calls if tc.get('success')]
            tool_call_count = len(tool_calls)
            
            success = bool(answer and len(answer) > 0)
            
            print(f"\n✅ Completed in {execution_time:.1f}s")
            print(f"   Tools used: {' → '.join(tool_names)}")
            print(f"   Tool calls: {tool_call_count}")
            print(f"   Answer length: {len(answer)} chars")
            
            # Print full LLM answer
            print(f"\n{'─'*100}")
            print("📝 FULL LLM ANSWER:")
            print(f"{'─'*100}")
            print(answer)
            print(f"{'─'*100}")
            
            # Store result
            results.append({
                "question_id": qid,
                "question": question,
                "success": success,
                "classification": classification,
                "classification_correct": classification_correct,
                "answer": answer,
                "chart_data": chart_data,
                "audio_summary": audio_summary,
                "data_source": data_source,
                "tool_calls": tool_calls,
                "tool_names": tool_names,
                "tool_call_count": tool_call_count,
                "execution_time": execution_time
            })
            
        except Exception as e:
            print(f"\n❌ Error: {str(e)}")
            import traceback
            traceback.print_exc()
            
            results.append({
                "question_id": qid,
                "question": question,
                "success": False,
                "classification": classification,
                "classification_correct": classification_correct,
                "error": str(e),
                "execution_time": time.time() - start_time
            })
    
    # Save results
    output_file = 'v6_11_calls_questions_results.json'
    
    output_data = {
        "test_date": datetime.now().isoformat(),
        "model": "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        "handler": "novartis_agent_handler_v6_final",
        "total_questions": len(CALLS_QUESTIONS),
        "passed": sum(1 for r in results if r.get('success')),
        "failed": sum(1 for r in results if not r.get('success')),
        "classification_correct": sum(1 for r in results if r.get('classification_correct')),
        "results": results
    }
    
    with open(output_file, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"\n\n{'='*100}")
    print("SUMMARY")
    print(f"{'='*100}")
    print(f"\nTotal: {len(CALLS_QUESTIONS)}")
    print(f"✅ Passed: {output_data['passed']}")
    print(f"❌ Failed: {output_data['failed']}")
    print(f"🎯 Classification Correct: {output_data['classification_correct']}/{len(CALLS_QUESTIONS)}")
    print(f"\n📄 Results saved to: {output_file}")
    print(f"\n{'='*100}\n")

if __name__ == '__main__':
    main()
