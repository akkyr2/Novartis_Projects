#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Test previously failed questions one by one
"""

import requests
import time

API_URL = "http://localhost:5000/api/ask"

failed_questions = [
    ("County Bar Chart", "Show me enrollment by county as a bar chart"),
    ("Lowest County", "Which county has the lowest enrollment?"),
    ("LA Percentage", "What percentage of total enrollment is in Los Angeles County?"),
    ("Top 5 Counties", "Show me the top 5 counties by enrollment"),
    ("2026 Confidence Interval", "What is the confidence interval for 2026 projections?"),
    ("Projected vs Actual", "Show me projected vs actual enrollment trends"),
    ("San Diego 2027", "What is San Diego County's projected enrollment for 2027?"),
    ("Highest Growth County", "Which county is projected to have the highest growth?"),
    ("San Bernardino Dec 2027", "What's the projected enrollment for San Bernardino County in December 2027?"),
    ("Gender Breakdown", "Show me enrollment by gender"),
    ("HEDIS Scores", "What are the current HEDIS scores?"),
    ("Star Ratings", "What is the star rating for each plan?"),
    ("Quality Improvement", "How have quality measures improved over time?"),
    ("Care Plan Completion", "What is the care plan completion rate?"),
    ("HRA Completion", "How many members have completed health risk assessments?"),
    ("ICP Rate", "What's the ICP completion rate?"),
    ("BH Utilization", "What is the behavioral health service utilization rate?"),
    ("Mental Health Metrics", "Show me mental health metrics"),
    ("BH Service Members", "How many members are receiving behavioral health services?"),
    ("Substance Abuse Rates", "What are the substance abuse treatment rates?"),
    ("Grievances Filed", "How many grievances were filed this year?"),
    ("Resolution Rate", "What is the grievance resolution rate?"),
    ("Resolution Time", "How long does it take to resolve grievances on average?"),
    ("Most Grievances", "Which plan has the most grievances?"),
]

def evaluate_answer(question, answer, has_chart):
    """Simple evaluation"""
    failure_phrases = [
        "don't have", "not available", "don't see", "not displayed",
        "would need", "i'll need", "could you provide", "please navigate",
        "not shown", "cannot find", "unable to", "doesn't show"
    ]
    
    has_failure = any(phrase in answer.lower() for phrase in failure_phrases)
    has_numbers = any(char.isdigit() for char in answer)
    
    if has_failure:
        return 15, "[X] Data not available"
    elif has_numbers:
        return 85, "[+] Contains data"
    else:
        return 50, "[!] Vague answer"

print("=" * 80)
print("🧪 Testing Previously Failed Questions")
print("=" * 80)

for i, (title, question) in enumerate(failed_questions, 1):
    print(f"\n[{i}/24] {title}")
    print(f"Q: {question}")
    print("-" * 80)
    
    try:
        response = requests.post(API_URL, json={
            "question": question,
            "slideNumber": 1
        }, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            answer = data.get('answer', '')
            has_chart = data.get('chartData') is not None
            chart_type = data.get('chartData', {}).get('type', '') if has_chart else ''
            
            score, reason = evaluate_answer(question, answer, has_chart)
            status = "✅ PASS" if score >= 60 else "❌ FAIL"
            
            print(f"{status} (Score: {score}%)")
            print(f"Answer: {answer[:200]}...")
            if has_chart:
                print(f"Chart: {chart_type}")
            print(f"Reason: {reason}")
        else:
            print(f"❌ HTTP Error: {response.status_code}")
    
    except Exception as e:
        print(f"❌ Error: {e}")
    
    time.sleep(1)  # Rate limiting

print("\n" + "=" * 80)
print("✅ Testing Complete")
print("=" * 80)
