#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Test V2 Architecture with Sample Questions
"""

import sys
import time
sys.path.insert(0, 'backend_api')

from novartis_agent_handler_v2 import handle_question_with_agent

# Test questions from the requirements
test_questions = [
    "What is my net sales year-to-date for 2025?",
    "What were quarterly targets for shipped doses missed in 2025?",
    "What is the average market share of Pluvicto in 2024?",
    "Compare Pluvicto sales 2024 vs 2025",
    "Which month has highest new patient volume in 2025?"
]

print("="*80)
print("TESTING V2 ARCHITECTURE")
print("="*80)

for i, question in enumerate(test_questions, 1):
    print(f"\n{'='*80}")
    print(f"TEST {i}: {question}")
    print(f"{'='*80}")
    
    start_time = time.time()
    
    try:
        answer, chart, audio = handle_question_with_agent(question, use_preprocessed=False)
        
        elapsed = time.time() - start_time
        
        print(f"\n⏱️  Time: {elapsed:.2f}s")
        print(f"\n📝 Answer Preview:")
        print(answer[:500] if answer else "No answer")
        print("...")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

print(f"\n{'='*80}")
print("✅ All tests complete")
print(f"{'='*80}")
