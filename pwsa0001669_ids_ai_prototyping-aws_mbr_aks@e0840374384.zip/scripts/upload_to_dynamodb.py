#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Upload CSV data to DynamoDB tables
"""

import boto3
import pandas as pd
import argparse
from decimal import Decimal
import time

def convert_to_dynamodb_format(value):
    """Convert pandas values to DynamoDB compatible format"""
    if pd.isna(value):
        return None
    elif isinstance(value, (int, float)):
        return Decimal(str(value))
    elif isinstance(value, bool):
        return value
    else:
        return str(value)

def upload_csv_to_dynamodb(csv_file, table_name, batch_size=25):
    """Upload CSV data to DynamoDB table"""
    
    print(f"\n{'='*80}")
    print(f"Uploading {csv_file} to {table_name}")
    print(f"{'='*80}\n")
    
    # Read CSV
    print(f"📖 Reading CSV file...")
    df = pd.read_csv(csv_file)
    print(f"   Found {len(df)} records with {len(df.columns)} columns")
    
    # Connect to DynamoDB
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    
    # Check if table exists
    try:
        table = dynamodb.Table(table_name)
        table.load()
        print(f"✅ Table '{table_name}' exists")
    except:
        print(f"❌ Table '{table_name}' does not exist. Creating...")
        
        # Create table with simple key schema
        dynamodb_client = boto3.client('dynamodb', region_name='us-east-1')
        
        # Determine key schema based on table
        if 'Calls' in table_name:
            key_schema = [
                {'AttributeName': 'PK', 'KeyType': 'HASH'},
                {'AttributeName': 'SK', 'KeyType': 'RANGE'}
            ]
            attribute_definitions = [
                {'AttributeName': 'PK', 'AttributeType': 'S'},
                {'AttributeName': 'SK', 'AttributeType': 'S'}
            ]
        else:  # Rome
            key_schema = [
                {'AttributeName': 'PK', 'KeyType': 'HASH'},
                {'AttributeName': 'SK', 'KeyType': 'RANGE'}
            ]
            attribute_definitions = [
                {'AttributeName': 'PK', 'AttributeType': 'S'},
                {'AttributeName': 'SK', 'AttributeType': 'S'}
            ]
        
        dynamodb_client.create_table(
            TableName=table_name,
            KeySchema=key_schema,
            AttributeDefinitions=attribute_definitions,
            BillingMode='PAY_PER_REQUEST'
        )
        
        print(f"⏳ Waiting for table to be created...")
        waiter = dynamodb_client.get_waiter('table_exists')
        waiter.wait(TableName=table_name)
        
        table = dynamodb.Table(table_name)
        print(f"✅ Table '{table_name}' created successfully")
    
    # Upload data in batches
    print(f"\n📤 Uploading data in batches of {batch_size}...")
    
    total_uploaded = 0
    failed = 0
    
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i+batch_size]
        
        with table.batch_writer() as writer:
            for idx, row in batch.iterrows():
                try:
                    # Convert row to DynamoDB item
                    item = {}
                    for col in df.columns:
                        value = convert_to_dynamodb_format(row[col])
                        if value is not None:
                            item[col] = value
                    
                    # Add PK and SK for DynamoDB
                    if 'Calls' in table_name:
                        # PK: product#geo_level#geo_name
                        # SK: year_quarter#metric_type
                        item['PK'] = f"{item.get('product', 'UNKNOWN')}#{item.get('dim_geo_level', 'UNKNOWN')}#{item.get('dim_geo_name', 'UNKNOWN')}"
                        item['SK'] = f"{item.get('year_quarter', 'UNKNOWN')}#{item.get('dim_metric_type', 'UNKNOWN')}"
                    else:  # Rome
                        # PK: PRODUCT#site_id
                        # SK: dim_date#sales_order_number
                        item['PK'] = f"{item.get('PRODUCT', 'UNKNOWN')}#{item.get('site_id', 'UNKNOWN')}"
                        item['SK'] = f"{item.get('dim_date', 'UNKNOWN')}#{item.get('sales_order_number', 'UNKNOWN')}"
                    
                    writer.put_item(Item=item)
                    total_uploaded += 1
                    
                    if total_uploaded % 100 == 0:
                        print(f"   Uploaded {total_uploaded}/{len(df)} records...")
                
                except Exception as e:
                    print(f"   ⚠️ Failed to upload record {idx}: {e}")
                    failed += 1
        
        # Small delay between batches to avoid throttling
        if i + batch_size < len(df):
            time.sleep(0.1)
    
    print(f"\n{'='*80}")
    print(f"✅ Upload Complete!")
    print(f"{'='*80}")
    print(f"Total records: {len(df)}")
    print(f"Successfully uploaded: {total_uploaded}")
    print(f"Failed: {failed}")
    print(f"Table: {table_name}")
    print(f"{'='*80}\n")
    
    return total_uploaded, failed

def main():
    parser = argparse.ArgumentParser(description='Upload CSV data to DynamoDB')
    parser.add_argument('--csv', required=True, help='Path to CSV file')
    parser.add_argument('--table', required=True, help='DynamoDB table name')
    parser.add_argument('--batch-size', type=int, default=25, help='Batch size for uploads')
    
    args = parser.parse_args()
    
    upload_csv_to_dynamodb(args.csv, args.table, args.batch_size)

if __name__ == '__main__':
    main()
