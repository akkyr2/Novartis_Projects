#!/bin/bash

# VPC Testing Setup Script for MBR Dashboard
# Creates an EC2 instance in your private subnet for testing the private ALB

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Load environment variables from .env file if it exists
if [ -f ".env" ]; then
    echo -e "${BLUE}📄 Loading configuration from .env file...${NC}"
    export $(grep -v '^#' .env | xargs)
fi

# Configuration
REGION=${AWS_DEFAULT_REGION:-us-east-1}
VPC_ID=${VPC_ID:-vpc-03a98d0cf83bd3675}
PRIVATE_SUBNET_ID=$(echo ${PRIVATE_SUBNET_IDS} | cut -d',' -f1)

# ALB DNS - Get from CloudFormation stack or set manually
# To get the correct URL, run: aws cloudformation describe-stacks --stack-name MbrDashboardStack --region us-east-1 --profile YOUR_PROFILE --query 'Stacks[0].Outputs[?OutputKey==`ApplicationUrl`].OutputValue' --output text
ALB_DNS=${ALB_DNS:-""}

# Auto-detect ALB DNS if not provided
if [ -z "$ALB_DNS" ]; then
    echo -e "${YELLOW}🔍 Auto-detecting ALB DNS from CloudFormation stack...${NC}"
    ALB_URL=$(aws cloudformation describe-stacks \
        --stack-name MbrDashboardStack \
        --region ${REGION} \
        --query 'Stacks[0].Outputs[?OutputKey==`ApplicationUrl`].OutputValue' \
        --output text 2>/dev/null || echo "")
    
    if [ ! -z "$ALB_URL" ]; then
        # Extract DNS name from URL (remove http://)
        ALB_DNS=$(echo $ALB_URL | sed 's|http://||')
        echo -e "${GREEN}✅ Found ALB DNS: ${ALB_DNS}${NC}"
    else
        echo -e "${RED}❌ Could not auto-detect ALB DNS from CloudFormation stack${NC}"
        echo -e "${YELLOW}💡 Please set ALB_DNS environment variable or update the script${NC}"
        echo -e "${YELLOW}   Example: export ALB_DNS=\"internal-mbr-dashboard-alb-XXXXXXXXX.us-east-1.elb.amazonaws.com\"${NC}"
        exit 1
    fi
fi

echo -e "${BLUE}🚀 Setting up VPC testing environment...${NC}"
echo -e "${BLUE}Region: ${REGION}${NC}"
echo -e "${BLUE}VPC: ${VPC_ID}${NC}"
echo -e "${BLUE}Private Subnet: ${PRIVATE_SUBNET_ID}${NC}"
echo -e "${BLUE}ALB DNS: ${ALB_DNS}${NC}"

# Function to check if AWS CLI is configured
check_aws_config() {
    echo -e "${YELLOW}🔍 Checking AWS configuration...${NC}"
    
    CALLER_IDENTITY=$(aws sts get-caller-identity 2>/dev/null)
    if [ $? -ne 0 ]; then
        echo -e "${RED}❌ AWS CLI not configured or no valid credentials found${NC}"
        exit 1
    fi
    
    AWS_ACCOUNT_ID=$(echo $CALLER_IDENTITY | jq -r '.Account' 2>/dev/null || echo "unknown")
    echo -e "${GREEN}✅ AWS credentials configured${NC}"
    echo -e "${BLUE}  Account ID: ${AWS_ACCOUNT_ID}${NC}"
}

# Function to get the latest Amazon Linux 2 AMI
get_latest_ami() {
    echo -e "${YELLOW}🔍 Getting latest Amazon Linux 2 AMI...${NC}"
    
    AMI_ID=$(aws ec2 describe-images \
        --owners amazon \
        --filters \
            "Name=name,Values=amzn2-ami-hvm-*-x86_64-gp2" \
            "Name=state,Values=available" \
        --query 'Images | sort_by(@, &CreationDate) | [-1].ImageId' \
        --output text \
        --region ${REGION})
    
    if [ -z "$AMI_ID" ] || [ "$AMI_ID" = "None" ]; then
        echo -e "${RED}❌ Could not find Amazon Linux 2 AMI${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ Found AMI: ${AMI_ID}${NC}"
}

# Function to create or get security group
setup_security_group() {
    echo -e "${YELLOW}🔒 Setting up security group...${NC}"
    
    # Check if security group already exists
    SG_ID=$(aws ec2 describe-security-groups \
        --filters "Name=group-name,Values=mbr-test-sg" "Name=vpc-id,Values=${VPC_ID}" \
        --query 'SecurityGroups[0].GroupId' \
        --output text \
        --region ${REGION} 2>/dev/null || echo "None")
    
    if [ "$SG_ID" = "None" ]; then
        echo -e "${BLUE}  Creating new security group...${NC}"
        
        SG_ID=$(aws ec2 create-security-group \
            --group-name mbr-test-sg \
            --description "Security group for MBR Dashboard testing" \
            --vpc-id ${VPC_ID} \
            --query 'GroupId' \
            --output text \
            --region ${REGION})
        
        # Allow outbound HTTPS for Session Manager and package updates
        aws ec2 authorize-security-group-egress \
            --group-id ${SG_ID} \
            --protocol tcp \
            --port 443 \
            --cidr 0.0.0.0/0 \
            --region ${REGION}
        
        # Allow outbound HTTP for testing ALB
        aws ec2 authorize-security-group-egress \
            --group-id ${SG_ID} \
            --protocol tcp \
            --port 80 \
            --cidr 10.0.0.0/8 \
            --region ${REGION}
        
        echo -e "${GREEN}✅ Created security group: ${SG_ID}${NC}"
    else
        echo -e "${GREEN}✅ Using existing security group: ${SG_ID}${NC}"
    fi
}

# Function to create or get IAM role for Session Manager
setup_iam_role() {
    echo -e "${YELLOW}🔑 Setting up IAM role for Session Manager...${NC}"
    
    # Check if role exists
    ROLE_EXISTS=$(aws iam get-role --role-name MBR-Test-SSM-Role --region ${REGION} 2>/dev/null || echo "false")
    
    if [ "$ROLE_EXISTS" = "false" ]; then
        echo -e "${BLUE}  Creating IAM role...${NC}"
        
        # Create trust policy
        cat > /tmp/trust-policy.json << EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "ec2.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}
EOF
        
        # Create role
        aws iam create-role \
            --role-name MBR-Test-SSM-Role \
            --assume-role-policy-document file:///tmp/trust-policy.json \
            --region ${REGION}
        
        # Attach Session Manager policy
        aws iam attach-role-policy \
            --role-name MBR-Test-SSM-Role \
            --policy-arn arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore \
            --region ${REGION}
        
        # Create instance profile
        aws iam create-instance-profile \
            --instance-profile-name MBR-Test-SSM-Profile \
            --region ${REGION}
        
        # Add role to instance profile
        aws iam add-role-to-instance-profile \
            --instance-profile-name MBR-Test-SSM-Profile \
            --role-name MBR-Test-SSM-Role \
            --region ${REGION}
        
        echo -e "${GREEN}✅ Created IAM role and instance profile${NC}"
        echo -e "${YELLOW}⏳ Waiting 10 seconds for IAM propagation...${NC}"
        sleep 10
    else
        echo -e "${GREEN}✅ Using existing IAM role${NC}"
    fi
    
    rm -f /tmp/trust-policy.json
}

# Function to launch test instance
launch_test_instance() {
    echo -e "${YELLOW}🚀 Launching test instance...${NC}"
    
    # Check if instance already exists
    EXISTING_INSTANCE=$(aws ec2 describe-instances \
        --filters \
            "Name=tag:Name,Values=MBR-Test-Instance" \
            "Name=instance-state-name,Values=running,pending" \
        --query 'Reservations[0].Instances[0].InstanceId' \
        --output text \
        --region ${REGION} 2>/dev/null || echo "None")
    
    if [ "$EXISTING_INSTANCE" != "None" ]; then
        echo -e "${GREEN}✅ Using existing test instance: ${EXISTING_INSTANCE}${NC}"
        INSTANCE_ID=$EXISTING_INSTANCE
    else
        # Create user data script with dynamic ALB DNS
        cat > /tmp/user-data.sh << EOF
#!/bin/bash
yum update -y
yum install -y curl jq

# Create test script
cat > /home/ec2-user/test-mbr.sh << 'TESTEOF'
#!/bin/bash
ALB_DNS="${ALB_DNS}"

echo "🧪 Testing MBR Dashboard API Endpoints..."
echo "ALB DNS: $ALB_DNS"
echo "=========================================="
echo ""

echo "1. Testing health endpoint..."
curl -s -w "\nStatus: %{http_code}\n" http://$ALB_DNS/api/health
echo ""

echo "2. Testing main application frontend..."
curl -s -w "\nStatus: %{http_code}\n" http://$ALB_DNS/ | head -20
echo ""

echo "3. Testing /api/ask endpoint (POST)..."
curl -s -X POST \
  -H "Content-Type: application/json" \
  -d '{"question":"What is the sales breakdown by product in Jan 2025?","slideNumber":1}' \
  -w "\nStatus: %{http_code}\n" \
  http://$ALB_DNS/api/ask | head -10
echo ""

echo "4. Testing preprocessing status endpoint..."
curl -s -w "\nStatus: %{http_code}\n" http://$ALB_DNS/api/preprocess/status
echo ""

echo "5. Testing slide image endpoint..."
curl -s -w "\nStatus: %{http_code}\n" http://$ALB_DNS/api/slides/1 | head -5
echo ""

echo "6. Testing synthesize endpoint (POST)..."
curl -s -X POST \
  -H "Content-Type: application/json" \
  -d '{"text":"Hello, this is a test"}' \
  -w "\nStatus: %{http_code}\n" \
  http://$ALB_DNS/api/synthesize | head -5
echo ""

echo "7. Testing static files..."
echo "CSS file:"
curl -s -I -w "Status: %{http_code}\n" http://$ALB_DNS/static/css/main.d403e09d.css | head -3
echo ""
echo "JS file:"
curl -s -I -w "Status: %{http_code}\n" http://$ALB_DNS/static/js/main.43347fd8.js | head -3
echo ""

echo "✅ API Testing complete!"
echo "=========================================="
TESTEOF

chmod +x /home/ec2-user/test-mbr.sh
chown ec2-user:ec2-user /home/ec2-user/test-mbr.sh
EOF
        
        # Launch instance
        INSTANCE_ID=$(aws ec2 run-instances \
            --image-id ${AMI_ID} \
            --instance-type t3.micro \
            --subnet-id ${PRIVATE_SUBNET_ID} \
            --security-group-ids ${SG_ID} \
            --iam-instance-profile Name=MBR-Test-SSM-Profile \
            --user-data file:///tmp/user-data.sh \
            --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=MBR-Test-Instance},{Key=Purpose,Value=MBR-Testing}]' \
            --query 'Instances[0].InstanceId' \
            --output text \
            --region ${REGION})
        
        echo -e "${GREEN}✅ Launched test instance: ${INSTANCE_ID}${NC}"
        
        rm -f /tmp/user-data.sh
    fi
    
    # Wait for instance to be running
    echo -e "${YELLOW}⏳ Waiting for instance to be running...${NC}"
    aws ec2 wait instance-running --instance-ids ${INSTANCE_ID} --region ${REGION}
    
    # Wait for Session Manager to be ready
    echo -e "${YELLOW}⏳ Waiting for Session Manager to be ready (this may take 2-3 minutes)...${NC}"
    local attempts=0
    local max_attempts=18  # 3 minutes with 10-second intervals
    
    while [ $attempts -lt $max_attempts ]; do
        SSM_STATUS=$(aws ssm describe-instance-information \
            --filters "Key=InstanceIds,Values=${INSTANCE_ID}" \
            --query 'InstanceInformationList[0].PingStatus' \
            --output text \
            --region ${REGION} 2>/dev/null || echo "None")
        
        if [ "$SSM_STATUS" = "Online" ]; then
            echo -e "${GREEN}✅ Session Manager is ready${NC}"
            break
        fi
        
        echo -e "${BLUE}  Attempt $((attempts + 1))/${max_attempts}: SSM Status = ${SSM_STATUS}${NC}"
        sleep 10
        ((attempts++))
    done
    
    if [ $attempts -eq $max_attempts ]; then
        echo -e "${YELLOW}⚠️  Session Manager may not be fully ready yet. You can try connecting in a few minutes.${NC}"
    fi
}

# Function to run automated tests via SSM
run_automated_tests() {
    echo -e "${YELLOW}🧪 Running automated tests via SSM...${NC}"
    
    # Test 1: Health endpoint
    echo -e "${BLUE}1. Testing health endpoint...${NC}"
    HEALTH_RESULT=$(aws ssm send-command \
        --instance-ids ${INSTANCE_ID} \
        --document-name "AWS-RunShellScript" \
        --parameters 'commands=["curl -s -w \"\\nStatus: %{http_code}\\n\" http://'${ALB_DNS}'/api/health"]' \
        --region ${REGION} \
        --query 'Command.CommandId' \
        --output text)
    
    # Wait for command to complete
    sleep 5
    
    # Get health test result
    HEALTH_OUTPUT=$(aws ssm get-command-invocation \
        --command-id ${HEALTH_RESULT} \
        --instance-id ${INSTANCE_ID} \
        --region ${REGION} \
        --query 'StandardOutputContent' \
        --output text 2>/dev/null || echo "Command still running...")
    
    echo -e "${GREEN}Health endpoint result:${NC}"
    echo "$HEALTH_OUTPUT"
    echo ""
    
    # Test 2: Main application frontend
    echo -e "${BLUE}2. Testing main application frontend...${NC}"
    APP_RESULT=$(aws ssm send-command \
        --instance-ids ${INSTANCE_ID} \
        --document-name "AWS-RunShellScript" \
        --parameters 'commands=["curl -s -w \"\\nStatus: %{http_code}\\n\" http://'${ALB_DNS}'/ | head -10"]' \
        --region ${REGION} \
        --query 'Command.CommandId' \
        --output text)
    
    # Wait for command to complete
    sleep 5
    
    # Get app test result
    APP_OUTPUT=$(aws ssm get-command-invocation \
        --command-id ${APP_RESULT} \
        --instance-id ${INSTANCE_ID} \
        --region ${REGION} \
        --query 'StandardOutputContent' \
        --output text 2>/dev/null || echo "Command still running...")
    
    echo -e "${GREEN}Main application result:${NC}"
    echo "$APP_OUTPUT"
    echo ""
    
    # Test 3: Ask API endpoint (POST)
    echo -e "${BLUE}3. Testing /api/ask endpoint...${NC}"
    ASK_RESULT=$(aws ssm send-command \
        --instance-ids ${INSTANCE_ID} \
        --document-name "AWS-RunShellScript" \
        --parameters 'commands=["curl -s -X POST -H \"Content-Type: application/json\" -d \"{\\\"question\\\":\\\"What is the sales breakdown by product in Jan 2025?\\\",\\\"slideNumber\\\":1}\" -w \"\\nStatus: %{http_code}\\n\" http://'${ALB_DNS}'/api/ask"]' \
        --region ${REGION} \
        --query 'Command.CommandId' \
        --output text)
    
    # Wait for command to complete
    sleep 8
    
    # Get ask test result
    ASK_OUTPUT=$(aws ssm get-command-invocation \
        --command-id ${ASK_RESULT} \
        --instance-id ${INSTANCE_ID} \
        --region ${REGION} \
        --query 'StandardOutputContent' \
        --output text 2>/dev/null || echo "Command still running...")
    
    echo -e "${GREEN}Ask API endpoint result:${NC}"
    echo "$ASK_OUTPUT"
    echo ""
}

# Function to cleanup test instance
cleanup_test_instance() {
    echo -e "${YELLOW}🧹 Cleaning up test instance...${NC}"
    
    # Terminate the instance
    echo -e "${BLUE}  Terminating instance ${INSTANCE_ID}...${NC}"
    aws ec2 terminate-instances --instance-ids ${INSTANCE_ID} --region ${REGION} >/dev/null
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Instance ${INSTANCE_ID} termination initiated${NC}"
        
        # Wait for termination to complete
        echo -e "${YELLOW}⏳ Waiting for instance to terminate...${NC}"
        aws ec2 wait instance-terminated --instance-ids ${INSTANCE_ID} --region ${REGION}
        echo -e "${GREEN}✅ Instance terminated successfully${NC}"
    else
        echo -e "${RED}❌ Failed to terminate instance${NC}"
    fi
}

# Function to display test results and cleanup
show_results_and_cleanup() {
    echo -e "\n${GREEN}🎉 VPC testing completed!${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}📋 Test Results Summary:${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    echo -e "\n${GREEN}📝 Instance Details (before cleanup):${NC}"
    echo -e "• Instance ID: ${INSTANCE_ID}"
    echo -e "• Region: ${REGION}"
    echo -e "• VPC: ${VPC_ID}"
    echo -e "• Subnet: ${PRIVATE_SUBNET_ID}"
    echo -e "• Security Group: ${SG_ID}"
    echo -e "• ALB DNS: ${ALB_DNS}"
    
    echo -e "\n${YELLOW}🌐 If you need browser access before cleanup:${NC}"
    echo -e "aws ssm start-session \\"
    echo -e "    --target ${INSTANCE_ID} \\"
    echo -e "    --document-name AWS-StartPortForwardingSessionToRemoteHost \\"
    echo -e "    --parameters '{\"host\":[\"${ALB_DNS}\"],\"portNumber\":[\"80\"],\"localPortNumber\":[\"8080\"]}' \\"
    echo -e "    --region ${REGION}"
    echo -e ""
    echo -e "Then open: http://localhost:8080"
    
    # Automatic cleanup
    cleanup_test_instance
    
    echo -e "\n${GREEN}✅ Testing and cleanup completed!${NC}"
    echo -e "${BLUE}Your MBR Dashboard is working correctly on the private ALB.${NC}"
}

# Main execution
main() {
    check_aws_config
    get_latest_ami
    setup_security_group
    setup_iam_role
    launch_test_instance
    run_automated_tests
    show_results_and_cleanup
}

# Handle script interruption
trap 'echo -e "\n${RED}❌ Setup interrupted${NC}"; exit 1' INT TERM

# Run main function
main "$@"