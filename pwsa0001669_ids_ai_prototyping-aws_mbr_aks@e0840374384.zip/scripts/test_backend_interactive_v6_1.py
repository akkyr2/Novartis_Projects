#!/usr/bin/env python3
"""
Interactive Backend Testing - V6.1 (Enhanced Charts)

This script allows you to ask questions directly to the backend and see:
1. Full LLM response (exactly as frontend sees it)
2. Audio summary for Polly
3. Chart data (if any) - NOW WITH SMART CHART GENERATION!
4. Performance metrics

V6.1 Changes:
- Smart chart generation (data-driven, not keyword-driven)
- Intelligent chart type selection
- Charts from aggregated data

Usage:
    python test_backend_interactive_v6_1.py
    
Then type your questions and press Enter.
Type 'exit' or 'quit' to stop.
"""

import sys
import os

# Add backend_api to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend_api'))

from novartis_agent_handler_v6_1 import handle_question_with_agent
import json
from datetime import datetime


def print_separator(char="=", length=80):
    """Print a separator line"""
    print(char * length)


def print_section(title):
    """Print a section header"""
    print(f"\n{title}")
    print("-" * len(title))


def format_chart_data(chart_data):
    """Format chart data for display"""
    if not chart_data:
        return "No chart data"
    
    output = []
    output.append(f"Chart Type: {chart_data.get('type', 'unknown')}")
    output.append(f"Title: {chart_data.get('title', 'N/A')}")
    
    if 'data' in chart_data:
        data = chart_data['data']
        if isinstance(data, list) and len(data) > 0:
            output.append(f"\nData Points: {len(data)}")
            output.append("\nSample Data (first 5 rows):")
            for i, row in enumerate(data[:5]):
                output.append(f"  {i+1}. {row}")
        else:
            output.append(f"\nData: {data}")
    
    return "\n".join(output)


def main():
    print_separator()
    print("NOVARTIS MBR - INTERACTIVE BACKEND TESTING (V6.1 - ENHANCED CHARTS)")
    print_separator()
    print("\n🎨 V6.1 Chart Enhancements Active:")
    print("  ✓ Smart chart generation (data-driven)")
    print("  ✓ Intelligent chart type selection")
    print("  ✓ Charts from aggregated data")
    print("\nBackend ready!")
    print("\nYou can now ask questions!")
    print("Type 'exit' or 'quit' to stop")
    print("Type 'clear' to clear conversation history")
    print_separator()
    
    # Conversation history
    conversation_history = []
    
    while True:
        # Get user input
        print("\n👤 Your Question:")
        user_input = input("> ").strip()
        
        if not user_input:
            continue
        
        # Check for exit commands
        if user_input.lower() in ['exit', 'quit', 'q']:
            print("\n👋 Goodbye!")
            break
        
        # Check for clear command
        if user_input.lower() == 'clear':
            conversation_history = []
            print("✓ Conversation history cleared")
            continue
        
        # Process the question
        print(f"\n⏳ Processing...")
        start_time = datetime.now()
        
        try:
            # Call the agent handler function
            result = handle_question_with_agent(
                question=user_input,
                conversation_history=conversation_history
            )
            
            # Unpack the tuple response
            answer, chart_data, audio_summary, data_source = result
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            # Update conversation history
            conversation_history.append({
                "role": "user",
                "content": user_input
            })
            conversation_history.append({
                "role": "assistant",
                "content": answer
            })
            
            # Display results
            print_separator("=")
            print("✨ RESPONSE (V6.1)")
            print_separator("=")
            
            # 1. Main Answer (Full LLM Response)
            print_section("📝 FULL LLM ANSWER")
            print(answer if answer else 'No answer provided')
            
            # 2. Audio Summary (for Polly)
            if audio_summary:
                print_section("🔈 AUDIO SUMMARY (for Polly)")
                print(audio_summary)
            
            # 3. Chart Data (V6.1 Enhanced)
            if chart_data:
                print_section("📊 CHART DATA (V6.1 SMART GENERATION)")
                print(format_chart_data(chart_data))
            else:
                print_section("📊 CHART DATA")
                print("No chart generated")
            
            # 4. Performance Metrics
            print_section("⏱️ PERFORMANCE")
            print(f"Total Time: {duration:.2f}s")
            
            # 5. Data Source
            if data_source:
                print_section("🔍 DATA SOURCE")
                print(f"Source: {data_source}")
            
            print_separator("=")
            
        except Exception as e:
            print(f"\n❌ Error: {str(e)}")
            import traceback
            print("\nFull traceback:")
            traceback.print_exc()
            print_separator("=")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
