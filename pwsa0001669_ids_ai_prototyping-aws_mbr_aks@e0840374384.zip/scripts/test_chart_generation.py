#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Test chart generation in V2
"""

from backend_api.novartis_agent_handler_v2 import handle_question_with_agent

print("Testing Chart Generation in V2")
print("="*80)

# Test with a question that asks for a chart
question = "Show me a pie chart of Pluvicto sales by quarter in 2025"

print(f"\nQuestion: {question}")
print("\nCalling agent handler...")

answer, chart_data, audio_summary = handle_question_with_agent(question)

print("\n" + "="*80)
print("RESULTS")
print("="*80)

print(f"\n📝 Answer ({len(answer)} chars):")
print(answer[:400] + "..." if len(answer) > 400 else answer)

if chart_data:
    print(f"\n📊 Chart Data:")
    print(f"   Type: {chart_data.get('type')}")
    print(f"   Title: {chart_data.get('title')}")
    print(f"   Data points: {len(chart_data.get('data', []))}")
    print(f"   Keys: x={chart_data.get('xKey')}, y={chart_data.get('yKey')}")
    print("\n✅ Chart generated successfully!")
else:
    print("\n❌ No chart data generated")

print(f"\n🎙️ Audio Summary ({len(audio_summary)} chars):")
print(audio_summary)
