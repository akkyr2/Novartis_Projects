#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Automated testing script for MBR Dashboard
Tests all questions from SAMPLE_QUESTIONS.md against the backend API
Generates detailed CSV with scoring and analysis
"""

import requests
import json
import time
import csv
from datetime import datetime

# Backend API endpoint
API_URL = "http://localhost:5000/api/ask"

# Test questions with expected answer criteria
test_questions = [
    # General Enrollment Questions
    {
        "id": 6,
        "question": "What is the current total enrollment across all plans?",
        "expected_keywords": ["105,645", "total", "plans"],
        "should_have_chart": False,
        "category": "General Enrollment"
    },
    {
        "id": 7,
        "question": "Show me enrollment trends for all plans",
        "expected_keywords": ["2020", "2025", "trend"],
        "should_have_chart": True,
        "category": "General Enrollment"
    },
    {
        "id": 8,
        "question": "Which plan has the highest enrollment?",
        "expected_keywords": ["Blue Shield", "14,031"],
        "should_have_chart": False,
        "category": "General Enrollment"
    },
    {
        "id": 9,
        "question": "What are the top 3 plans by enrollment?",
        "expected_keywords": ["Blue Shield", "SCFHP", "L.A. Care"],
        "should_have_chart": True,
        "category": "General Enrollment"
    },
    {
        "id": 10,
        "question": "Show me all plans enrollment as a pie chart",
        "expected_keywords": ["pie", "plans", "105,645"],
        "should_have_chart": True,
        "category": "General Enrollment"
    },
    {
        "id": 11,
        "question": "Compare enrollment between Anthem and Health Net",
        "expected_keywords": ["Anthem", "Health Net", "7,824", "7,740"],
        "should_have_chart": True,
        "category": "General Enrollment"
    },
    {
        "id": 12,
        "question": "What's the enrollment growth rate?",
        "expected_keywords": ["growth", "rate", "annual", "%"],
        "should_have_chart": True,
        "category": "General Enrollment"
    },
    
    # County-Specific Questions
    {
        "id": 13,
        "question": "What is the current enrollment in Orange County?",
        "expected_keywords": ["Orange", "13,972"],
        "should_have_chart": False,
        "category": "County-Specific"
    },
    {
        "id": 14,
        "question": "Show me enrollment by county as a bar chart",
        "expected_keywords": ["county", "bar", "Los Angeles"],
        "should_have_chart": True,
        "category": "County-Specific"
    },
    {
        "id": 15,
        "question": "Which county has the lowest enrollment?",
        "expected_keywords": ["county", "lowest", "Santa Clara", "San Mateo"],
        "should_have_chart": False,
        "category": "County-Specific"
    },
    {
        "id": 16,
        "question": "Compare Los Angeles and San Diego county enrollment",
        "expected_keywords": ["Los Angeles", "San Diego", "county"],
        "should_have_chart": True,
        "category": "County-Specific"
    },
    {
        "id": 17,
        "question": "What percentage of total enrollment is in Los Angeles County?",
        "expected_keywords": ["Los Angeles", "%", "percentage"],
        "should_have_chart": False,
        "category": "County-Specific"
    },
    
    # Projection Questions - General
    {
        "id": 20,
        "question": "What is the projected enrollment for 2027?",
        "expected_keywords": ["2027", "1,312,912", "projected"],
        "should_have_chart": False,
        "category": "Projections"
    },
    {
        "id": 21,
        "question": "Show me enrollment projections for the next 3 years",
        "expected_keywords": ["2026", "2027", "2028", "projection"],
        "should_have_chart": True,
        "category": "Projections"
    },
    {
        "id": 22,
        "question": "What's the projected growth from 2026 to 2028?",
        "expected_keywords": ["2026", "2028", "growth", "%"],
        "should_have_chart": False,
        "category": "Projections"
    },
    
    # Projection Questions - County Specific
    {
        "id": 26,
        "question": "What is San Diego County's projected enrollment for 2027?",
        "expected_keywords": ["San Diego", "2027", "projected"],
        "should_have_chart": False,
        "category": "County Projections"
    },
    {
        "id": 27,
        "question": "Show me Orange County projections with confidence intervals",
        "expected_keywords": ["Orange", "confidence", "interval", "projection"],
        "should_have_chart": True,
        "category": "County Projections"
    },
    {
        "id": 28,
        "question": "Compare projected enrollment across all counties for 2026",
        "expected_keywords": ["county", "2026", "projected"],
        "should_have_chart": True,
        "category": "County Projections"
    },
    {
        "id": 30,
        "question": "Show me Riverside County projections as a line chart",
        "expected_keywords": ["Riverside", "projection", "line"],
        "should_have_chart": True,
        "category": "County Projections"
    },
    
    # Projection Questions - Monthly
    {
        "id": 32,
        "question": "Show me projected enrollment for January 2027 by county",
        "expected_keywords": ["January", "2027", "county", "projected"],
        "should_have_chart": True,
        "category": "Monthly Projections"
    },
    {
        "id": 33,
        "question": "What is the projected enrollment for March 2028?",
        "expected_keywords": ["March", "2028", "projected"],
        "should_have_chart": False,
        "category": "Monthly Projections"
    },
    {
        "id": 35,
        "question": "Show me monthly projections for 2026 as a line chart",
        "expected_keywords": ["monthly", "2026", "projection", "line"],
        "should_have_chart": True,
        "category": "Monthly Projections"
    },
    
    # Demographics Questions
    {
        "id": 37,
        "question": "What is the age distribution of members?",
        "expected_keywords": ["age", "distribution"],
        "should_have_chart": False,
        "category": "Demographics"
    },
    {
        "id": 38,
        "question": "Show me enrollment by gender",
        "expected_keywords": ["gender", "male", "female"],
        "should_have_chart": True,
        "category": "Demographics"
    },
    {
        "id": 39,
        "question": "What percentage of members are over 65?",
        "expected_keywords": ["65", "%", "percentage"],
        "should_have_chart": False,
        "category": "Demographics"
    },
    
    # Quality Measures Questions
    {
        "id": 42,
        "question": "What are the current HEDIS scores?",
        "expected_keywords": ["HEDIS", "score"],
        "should_have_chart": False,
        "category": "Quality Measures"
    },
    {
        "id": 43,
        "question": "Show me quality measure trends",
        "expected_keywords": ["quality", "trend"],
        "should_have_chart": True,
        "category": "Quality Measures"
    },
    {
        "id": 44,
        "question": "What is the star rating for each plan?",
        "expected_keywords": ["star", "rating", "plan"],
        "should_have_chart": False,
        "category": "Quality Measures"
    },
    
    # Care Coordination Questions
    {
        "id": 47,
        "question": "What is the care plan completion rate?",
        "expected_keywords": ["care plan", "completion", "rate", "%"],
        "should_have_chart": False,
        "category": "Care Coordination"
    },
    {
        "id": 48,
        "question": "Show me care coordination metrics",
        "expected_keywords": ["care coordination", "metric"],
        "should_have_chart": False,
        "category": "Care Coordination"
    },
    {
        "id": 49,
        "question": "How many members have completed health risk assessments?",
        "expected_keywords": ["health risk assessment", "HRA", "member"],
        "should_have_chart": False,
        "category": "Care Coordination"
    },
    
    # Behavioral Health Questions
    {
        "id": 52,
        "question": "What is the behavioral health service utilization rate?",
        "expected_keywords": ["behavioral health", "utilization", "rate"],
        "should_have_chart": False,
        "category": "Behavioral Health"
    },
    {
        "id": 53,
        "question": "Show me mental health metrics",
        "expected_keywords": ["mental health", "metric"],
        "should_have_chart": False,
        "category": "Behavioral Health"
    },
    
    # Grievances & Appeals Questions
    {
        "id": 56,
        "question": "How many grievances were filed this year?",
        "expected_keywords": ["grievance", "filed", "2025"],
        "should_have_chart": False,
        "category": "Grievances & Appeals"
    },
    {
        "id": 57,
        "question": "What is the grievance resolution rate?",
        "expected_keywords": ["grievance", "resolution", "rate", "%"],
        "should_have_chart": False,
        "category": "Grievances & Appeals"
    },
    {
        "id": 58,
        "question": "Show me appeals trends over time",
        "expected_keywords": ["appeal", "trend", "time"],
        "should_have_chart": True,
        "category": "Grievances & Appeals"
    },
    
    # Comparison Questions
    {
        "id": 61,
        "question": "Compare all plans side by side",
        "expected_keywords": ["plan", "compare"],
        "should_have_chart": True,
        "category": "Comparisons"
    },
    {
        "id": 62,
        "question": "Show me year-over-year enrollment changes",
        "expected_keywords": ["year", "enrollment", "change"],
        "should_have_chart": True,
        "category": "Comparisons"
    },
    {
        "id": 63,
        "question": "Which county has the fastest growth?",
        "expected_keywords": ["county", "growth", "fastest"],
        "should_have_chart": False,
        "category": "Comparisons"
    },
    {
        "id": 64,
        "question": "Compare 2025 actual vs 2026 projected enrollment",
        "expected_keywords": ["2025", "2026", "compare", "actual", "projected"],
        "should_have_chart": True,
        "category": "Comparisons"
    },
    
    # Time-Based Questions
    {
        "id": 66,
        "question": "Show me enrollment trends from 2020 to 2025",
        "expected_keywords": ["2020", "2025", "trend", "enrollment"],
        "should_have_chart": True,
        "category": "Time-Based"
    },
    {
        "id": 67,
        "question": "What was enrollment in September 2022?",
        "expected_keywords": ["September", "2022", "enrollment"],
        "should_have_chart": False,
        "category": "Time-Based"
    },
    {
        "id": 68,
        "question": "How has enrollment changed since 2020?",
        "expected_keywords": ["2020", "change", "enrollment"],
        "should_have_chart": True,
        "category": "Time-Based"
    },
    
    # Specific Date Questions
    {
        "id": 71,
        "question": "What was the enrollment on December 1, 2025?",
        "expected_keywords": ["December", "2025", "enrollment", "105,645"],
        "should_have_chart": False,
        "category": "Specific Date"
    },
    {
        "id": 73,
        "question": "What are the projections for the end of 2027?",
        "expected_keywords": ["2027", "projection", "end", "December"],
        "should_have_chart": False,
        "category": "Specific Date"
    },
    
    # Chart-Specific Requests
    {
        "id": 75,
        "question": "Show me a bar chart of all plans",
        "expected_keywords": ["bar", "chart", "plan"],
        "should_have_chart": True,
        "category": "Chart Requests"
    },
    {
        "id": 76,
        "question": "Create a line graph of enrollment trends",
        "expected_keywords": ["line", "graph", "enrollment", "trend"],
        "should_have_chart": True,
        "category": "Chart Requests"
    },
    {
        "id": 77,
        "question": "Display county enrollment as a pie chart",
        "expected_keywords": ["pie", "chart", "county", "enrollment"],
        "should_have_chart": True,
        "category": "Chart Requests"
    },
    
    # Confidence Interval Questions
    {
        "id": 80,
        "question": "What is the confidence interval for Los Angeles projections?",
        "expected_keywords": ["confidence", "interval", "Los Angeles", "projection"],
        "should_have_chart": False,
        "category": "Confidence Intervals"
    },
    {
        "id": 81,
        "question": "Show me upper and lower bounds for 2026 projections",
        "expected_keywords": ["upper", "lower", "bound", "2026", "projection"],
        "should_have_chart": True,
        "category": "Confidence Intervals"
    },
    
    # Multi-County Questions
    {
        "id": 84,
        "question": "Compare Los Angeles, Orange, and San Diego counties",
        "expected_keywords": ["Los Angeles", "Orange", "San Diego", "compare"],
        "should_have_chart": True,
        "category": "Multi-County"
    },
    {
        "id": 86,
        "question": "What's the combined enrollment for LA and Orange counties?",
        "expected_keywords": ["Los Angeles", "Orange", "combined", "enrollment"],
        "should_have_chart": False,
        "category": "Multi-County"
    },
    
    # Plan-Specific Questions
    {
        "id": 88,
        "question": "Tell me about Anthem's enrollment",
        "expected_keywords": ["Anthem", "enrollment", "7,824"],
        "should_have_chart": False,
        "category": "Plan-Specific"
    },
    {
        "id": 89,
        "question": "What is Health Net's market share?",
        "expected_keywords": ["Health Net", "market share", "%"],
        "should_have_chart": False,
        "category": "Plan-Specific"
    },
    
    # Aggregate Questions
    {
        "id": 92,
        "question": "What is the total projected enrollment across all counties for 2026?",
        "expected_keywords": ["total", "projected", "2026", "county"],
        "should_have_chart": False,
        "category": "Aggregate"
    },
    {
        "id": 93,
        "question": "Show me average monthly enrollment",
        "expected_keywords": ["average", "monthly", "enrollment"],
        "should_have_chart": True,
        "category": "Aggregate"
    },
]

def calculate_difficulty(question_data):
    """Calculate question difficulty (1-5, 5 being hardest)"""
    difficulty = 1
    question_lower = question_data['question'].lower()
    
    # Increase difficulty for specific features
    if 'compare' in question_lower or 'versus' in question_lower:
        difficulty += 1
    if 'confidence interval' in question_lower or 'upper' in question_lower or 'lower' in question_lower:
        difficulty += 1
    if 'trend' in question_lower or 'over time' in question_lower or 'historical' in question_lower:
        difficulty += 1
    if 'projection' in question_lower or 'forecast' in question_lower:
        difficulty += 1
    if 'which' in question_lower or 'fastest' in question_lower or 'lowest' in question_lower or 'highest' in question_lower:
        difficulty += 1
    if len(question_data['expected_keywords']) > 4:
        difficulty += 1
    
    return min(difficulty, 5)

def categorize_question(question_data):
    """Categorize question by data type"""
    question_lower = question_data['question'].lower()
    categories = []
    
    if 'enrollment' in question_lower:
        categories.append('Enrollment')
    if any(county in question_lower for county in ['county', 'counties', 'los angeles', 'orange', 'san diego', 'riverside']):
        categories.append('County')
    if 'projection' in question_lower or 'forecast' in question_lower or '2026' in question_lower or '2027' in question_lower or '2028' in question_lower:
        categories.append('Projection')
    if 'trend' in question_lower or 'over time' in question_lower or 'historical' in question_lower or 'growth' in question_lower:
        categories.append('Time-Series')
    if 'plan' in question_lower and 'plans' in question_lower:
        categories.append('Plan-Comparison')
    if 'chart' in question_lower or 'graph' in question_lower or 'pie' in question_lower or 'bar' in question_lower or 'line' in question_lower:
        categories.append('Visualization')
    if 'compare' in question_lower or 'versus' in question_lower or 'vs' in question_lower:
        categories.append('Comparison')
    if 'demographic' in question_lower or 'age' in question_lower or 'gender' in question_lower:
        categories.append('Demographics')
    if 'quality' in question_lower or 'hedis' in question_lower or 'star' in question_lower:
        categories.append('Quality')
    if 'care' in question_lower or 'coordination' in question_lower:
        categories.append('Care-Coordination')
    if 'behavioral' in question_lower or 'mental' in question_lower:
        categories.append('Behavioral-Health')
    if 'grievance' in question_lower or 'appeal' in question_lower:
        categories.append('Grievances')
    if 'confidence' in question_lower and 'interval' in question_lower:
        categories.append('Confidence-Interval')
    
    return '|'.join(categories) if categories else 'General'

def test_question(question_data, slide_number=1):
    """Test a single question against the API and return detailed results"""
    print(f"\n{'='*80}")
    print(f"Test #{question_data['id']}: {question_data['category']}")
    print(f"Question: {question_data['question']}")
    print(f"{'='*80}")
    
    result = {
        'question_id': question_data['id'],
        'question': question_data['question'],
        'category': question_data['category'],
        'data_type': categorize_question(question_data),
        'difficulty': calculate_difficulty(question_data),
        'answer': '',
        'keywords_found': 0,
        'keywords_total': len(question_data['expected_keywords']),
        'chart_correct': False,
        'confidence_score': 0.0,
        'pass_fail': 'FAIL',
        'reason': '',
        'found_keywords': '',
        'missing_keywords': '',
        'has_chart': False,
        'chart_type': '',
        'response_time': 0.0
    }
    
    payload = {
        "question": question_data["question"],
        "slideNumber": slide_number,
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        start_time = time.time()
        response = requests.post(API_URL, json=payload, timeout=60)
        response_time = time.time() - start_time
        result['response_time'] = round(response_time, 2)
        
        if response.status_code != 200:
            result['reason'] = f"HTTP {response.status_code}"
            print(f"❌ FAILED: {result['reason']}")
            return result
        
        data = response.json()
        answer = data.get('answer', '')
        chart_data = data.get('chartData')
        
        result['answer'] = answer
        result['has_chart'] = chart_data is not None
        if chart_data:
            result['chart_type'] = chart_data.get('type', '')
        
        print(f"\n📝 Answer: {answer[:200]}...")
        
        # Check for expected keywords
        found_keywords = []
        missing_keywords = []
        for keyword in question_data['expected_keywords']:
            # Normalize for comparison
            answer_normalized = answer.lower().replace(',', '')
            keyword_normalized = keyword.lower().replace(',', '')
            
            if keyword_normalized in answer_normalized:
                found_keywords.append(keyword)
            else:
                missing_keywords.append(keyword)
        
        result['keywords_found'] = len(found_keywords)
        result['found_keywords'] = ', '.join(found_keywords)
        result['missing_keywords'] = ', '.join(missing_keywords)
        
        # Check chart presence
        chart_ok = result['has_chart'] == question_data['should_have_chart']
        result['chart_correct'] = chart_ok
        
        # Calculate confidence score (0-100)
        keyword_score = (len(found_keywords) / len(question_data['expected_keywords'])) * 70 if question_data['expected_keywords'] else 70
        chart_score = 30 if chart_ok else 0
        result['confidence_score'] = round(keyword_score + chart_score, 1)
        
        # Determine pass/fail (>= 60% confidence)
        if result['confidence_score'] >= 60:
            result['pass_fail'] = 'PASS'
            print(f"✅ PASSED (Score: {result['confidence_score']}%)")
        else:
            result['pass_fail'] = 'FAIL'
            print(f"❌ FAILED (Score: {result['confidence_score']}%)")
        
        # Generate reason
        reasons = []
        if len(found_keywords) == len(question_data['expected_keywords']):
            reasons.append("All keywords found")
        elif len(found_keywords) > 0:
            reasons.append(f"{len(found_keywords)}/{len(question_data['expected_keywords'])} keywords found")
        else:
            reasons.append("No keywords found")
        
        if chart_ok:
            reasons.append("Chart correct")
        else:
            if question_data['should_have_chart'] and not result['has_chart']:
                reasons.append("Missing expected chart")
            elif not question_data['should_have_chart'] and result['has_chart']:
                reasons.append("Unexpected chart generated")
        
        result['reason'] = '; '.join(reasons)
        
        print(f"   Score: {result['confidence_score']}%")
        print(f"   Keywords: {result['keywords_found']}/{result['keywords_total']}")
        if result['has_chart']:
            print(f"   Chart: {result['chart_type']}")
        
        return result
            
    except requests.exceptions.Timeout:
        result['reason'] = "Request timeout"
        print(f"❌ FAILED: {result['reason']}")
        return result
    except Exception as e:
        result['reason'] = f"Error: {str(e)}"
        print(f"❌ FAILED: {result['reason']}")
        return result

def main():
    print("=" * 80)
    print("🧪 MBR Dashboard Automated Testing")
    print("=" * 80)
    print(f"Testing {len(test_questions)} questions...")
    print(f"API Endpoint: {API_URL}")
    print("=" * 80)
    
    # Check if backend is running
    try:
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        if response.status_code != 200:
            print("❌ Backend is not responding. Please start the backend first.")
            return
    except:
        print("❌ Cannot connect to backend. Please start the backend first.")
        return
    
    all_results = []
    passed_count = 0
    failed_count = 0
    
    for question_data in test_questions:
        result = test_question(question_data)
        all_results.append(result)
        
        if result['pass_fail'] == 'PASS':
            passed_count += 1
        else:
            failed_count += 1
        
        # Small delay between requests
        time.sleep(2)
    
    # Save results to CSV
    csv_filename = f"test_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = [
            'question_id', 'question', 'category', 'data_type', 'difficulty',
            'pass_fail', 'confidence_score', 'reason',
            'keywords_found', 'keywords_total', 'found_keywords', 'missing_keywords',
            'chart_correct', 'has_chart', 'chart_type',
            'response_time', 'answer'
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_results)
    
    print(f"\n✅ Results saved to: {csv_filename}")
    
    # Calculate statistics
    total_score = sum(r['confidence_score'] for r in all_results)
    avg_score = total_score / len(all_results) if all_results else 0
    
    # Category analysis
    category_stats = {}
    for result in all_results:
        cat = result['category']
        if cat not in category_stats:
            category_stats[cat] = {'passed': 0, 'failed': 0, 'total': 0, 'avg_score': 0}
        category_stats[cat]['total'] += 1
        category_stats[cat]['avg_score'] += result['confidence_score']
        if result['pass_fail'] == 'PASS':
            category_stats[cat]['passed'] += 1
        else:
            category_stats[cat]['failed'] += 1
    
    for cat in category_stats:
        category_stats[cat]['avg_score'] /= category_stats[cat]['total']
    
    # Data type analysis
    data_type_stats = {}
    for result in all_results:
        for dtype in result['data_type'].split('|'):
            if dtype not in data_type_stats:
                data_type_stats[dtype] = {'passed': 0, 'failed': 0, 'total': 0, 'avg_score': 0}
            data_type_stats[dtype]['total'] += 1
            data_type_stats[dtype]['avg_score'] += result['confidence_score']
            if result['pass_fail'] == 'PASS':
                data_type_stats[dtype]['passed'] += 1
            else:
                data_type_stats[dtype]['failed'] += 1
    
    for dtype in data_type_stats:
        data_type_stats[dtype]['avg_score'] /= data_type_stats[dtype]['total']
    
    # Print summary
    print("\n" + "=" * 80)
    print("📊 TEST SUMMARY")
    print("=" * 80)
    print(f"Total Tests: {len(all_results)}")
    print(f"✅ Passed: {passed_count} ({passed_count/len(all_results)*100:.1f}%)")
    print(f"❌ Failed: {failed_count} ({failed_count/len(all_results)*100:.1f}%)")
    print(f"📈 Average Confidence Score: {avg_score:.1f}%")
    print("=" * 80)
    
    # Category breakdown
    print("\n📂 RESULTS BY CATEGORY:")
    print("-" * 80)
    for cat, stats in sorted(category_stats.items(), key=lambda x: x[1]['avg_score'], reverse=True):
        pass_rate = (stats['passed'] / stats['total'] * 100) if stats['total'] > 0 else 0
        print(f"{cat:30} | Pass: {stats['passed']:2}/{stats['total']:2} ({pass_rate:5.1f}%) | Avg Score: {stats['avg_score']:5.1f}%")
    
    # Data type breakdown
    print("\n🏷️  RESULTS BY DATA TYPE:")
    print("-" * 80)
    for dtype, stats in sorted(data_type_stats.items(), key=lambda x: x[1]['avg_score'], reverse=True):
        pass_rate = (stats['passed'] / stats['total'] * 100) if stats['total'] > 0 else 0
        print(f"{dtype:30} | Pass: {stats['passed']:2}/{stats['total']:2} ({pass_rate:5.1f}%) | Avg Score: {stats['avg_score']:5.1f}%")
    
    # Difficulty analysis
    print("\n⚡ RESULTS BY DIFFICULTY:")
    print("-" * 80)
    difficulty_stats = {}
    for result in all_results:
        diff = result['difficulty']
        if diff not in difficulty_stats:
            difficulty_stats[diff] = {'passed': 0, 'failed': 0, 'total': 0, 'avg_score': 0}
        difficulty_stats[diff]['total'] += 1
        difficulty_stats[diff]['avg_score'] += result['confidence_score']
        if result['pass_fail'] == 'PASS':
            difficulty_stats[diff]['passed'] += 1
        else:
            difficulty_stats[diff]['failed'] += 1
    
    for diff in sorted(difficulty_stats.keys()):
        stats = difficulty_stats[diff]
        stats['avg_score'] /= stats['total']
        pass_rate = (stats['passed'] / stats['total'] * 100) if stats['total'] > 0 else 0
        print(f"Difficulty {diff}/5:              | Pass: {stats['passed']:2}/{stats['total']:2} ({pass_rate:5.1f}%) | Avg Score: {stats['avg_score']:5.1f}%")
    
    print("\n" + "=" * 80)
    if failed_count == 0:
        print("🎉 ALL TESTS PASSED! The app is ready.")
    else:
        print(f"⚠️  {failed_count} tests need attention.")
    print("=" * 80)

if __name__ == '__main__':
    main()
