#!/usr/bin/env python3
"""Fix forecast types in generated CSV files: 'Latest Estimate' -> 'OC' and add OC to doses"""

import pandas as pd
import numpy as np

print("Fixing forecast types...")

# Fix SALES file
print("\n1. Fixing SALES_FINANCE_BPC_corrected_new.csv...")
df_sales = pd.read_csv('SALES_FINANCE_BPC_corrected_new.csv')
df_sales['DIM_forecast'] = df_sales['DIM_forecast'].replace('Latest Estimate', 'OC')
df_sales.to_csv('SALES_FINANCE_BPC_corrected_new.csv', index=False)
print(f"   ✅ Fixed {len(df_sales)} rows")
print(f"   Forecast types: {df_sales['DIM_forecast'].value_counts().to_dict()}")

# Fix DOSES file - add OC forecast type
print("\n2. Fixing FCT_DOSES_PLU_corrected_new.csv...")
df_doses = pd.read_csv('FCT_DOSES_PLU_corrected_new.csv')

# Create OC records by copying Budget and adjusting values slightly
df_oc = df_doses[df_doses['dim_forecast'] == 'Budget'].copy()
df_oc['dim_forecast'] = 'OC'
# Adjust OC values to be between Budget and Actual
df_oc['value'] = df_oc['value'] * (1 + (0.02 * (2 * np.random.random(len(df_oc)) - 1)))

# Combine all forecast types
df_doses_complete = pd.concat([df_doses, df_oc], ignore_index=True)
df_doses_complete = df_doses_complete.sort_values(['PRODUCT', 'dim_date', 'metric', 'dim_forecast'])
df_doses_complete.to_csv('FCT_DOSES_PLU_corrected_new.csv', index=False)
print(f"   ✅ Fixed {len(df_doses_complete)} rows (was {len(df_doses)})")
print(f"   Forecast types: {df_doses_complete['dim_forecast'].value_counts().to_dict()}")

print("\n✅ All forecast types fixed!")
