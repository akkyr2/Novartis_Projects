#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Quick test to verify audio summary generation with follow-up questions
"""

from backend_api.novartis_agent_handler_v2 import handle_question_with_agent

print("Testing Audio Summary Generation")
print("="*80)

# Test with a simple question
question = "What were Pluvicto sales in Q1 2025?"

print(f"\nQuestion: {question}")
print("\nCalling agent handler...")

answer, chart_data, audio_summary = handle_question_with_agent(question)

print("\n" + "="*80)
print("RESULTS")
print("="*80)

print(f"\n📝 Full Answer ({len(answer)} chars):")
print(answer[:300] + "..." if len(answer) > 300 else answer)

print(f"\n🎙️ Audio Summary ({len(audio_summary)} chars):")
print(audio_summary)

print("\n" + "="*80)
print("✅ Test complete!")
print("="*80)

# Check if audio summary has follow-up suggestion
if "?" in audio_summary or "next" in audio_summary.lower() or "also" in audio_summary.lower():
    print("✅ Audio summary includes follow-up suggestion!")
else:
    print("⚠️ Audio summary might be missing follow-up suggestion")
