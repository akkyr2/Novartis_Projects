#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Test V2.1 with Rome and Calls tables
"""

from backend_api.novartis_agent_handler_v2_1 import handle_question_with_agent
import time

print("="*80)
print("Testing V2.1 Architecture (5 Tables)")
print("="*80)

# Test 1: Calls question
print("\n1. Testing FCT_CALLS table...")
print("   Question: How many HCPs did we reach in Q1 2024?")
start = time.time()
answer, chart, audio = handle_question_with_agent("How many HCPs did we reach in Q1 2024?")
elapsed = time.time() - start
print(f"\n   ✅ Response time: {elapsed:.1f}s")
print(f"   Answer preview: {answer[:200]}...")
if chart:
    print(f"   Chart: {chart.get('type')} - {chart.get('title')}")

# Test 2: Rome question
print("\n2. Testing FCT_ROME_PLU table...")
print("   Question: Which sites are active for Pluvicto?")
start = time.time()
answer, chart, audio = handle_question_with_agent("Which sites are active for Pluvicto?")
elapsed = time.time() - start
print(f"\n   ✅ Response time: {elapsed:.1f}s")
print(f"   Answer preview: {answer[:200]}...")
if chart:
    print(f"   Chart: {chart.get('type')} - {chart.get('title')}")

# Test 3: Historical calls question
print("\n3. Testing historical data (2020-2025)...")
print("   Question: Show me HCP reach trends from 2020 to 2025")
start = time.time()
answer, chart, audio = handle_question_with_agent("Show me HCP reach trends from 2020 to 2025")
elapsed = time.time() - start
print(f"\n   ✅ Response time: {elapsed:.1f}s")
print(f"   Answer preview: {answer[:200]}...")
if chart:
    print(f"   Chart: {chart.get('type')} - {chart.get('title')}")

print("\n" + "="*80)
print("✅ V2.1 Testing Complete!")
print("="*80)
