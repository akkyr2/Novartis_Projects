#!/usr/bin/env python3
"""
Test V6 Agent Handler with 5 MARKET Questions - End-to-End

Tests the V6 Final handler with only the 5 MARKET questions to verify
market share and competitor analysis functionality.

Features:
- Uses novartis_agent_handler_v6_final (with classifier routing)
- Uses novartis_prompts_v6 (separated prompts)
- Uses novartis_queries_v6_final (all 11 tools)
- Captures tool calls and timing
- Prints full LLM answers
- Saves results to JSON for comparison

Output:
- v6_5_market_questions_results.json (full results)
"""

import sys
import os
import json
import time
from datetime import datetime

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, project_root)

from backend_api.novartis_agent_handler_v6_final import handle_question_with_agent, classify_question

# ============================================================================
# 5 MARKET QUESTIONS (from ACCURACY_TEST_REPORT.md)
# ============================================================================

MARKET_QUESTIONS = [
    {
        "id": "M1",
        "question": "What is the average market share of Pluvicto in 2024?",
        "expected_classification": "general"
    },
    {
        "id": "M2",
        "question": "Analyze market share trends by specific brands",
        "expected_classification": "general"
    },
    {
        "id": "M3",
        "question": "What is my MoM growth or decline in terms of market share for all lines of therapy?",
        "expected_classification": "general"
    },
    {
        "id": "M4",
        "question": "Which brand is Pluvicto's biggest competitor?",
        "expected_classification": "general"
    },
    {
        "id": "M5",
        "question": "How much share have we gained this year across all lines?",
        "expected_classification": "general"
    }
]

# ============================================================================
# TEST EXECUTION
# ============================================================================

def main():
    """Run all 5 MARKET questions through v6_final handler"""
    
    print("="*100)
    print("Testing V6 Final Handler - 5 MARKET Questions")
    print("="*100)
    print()
    print(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Handler: novartis_agent_handler_v6_final")
    print(f"Questions: {len(MARKET_QUESTIONS)}")
    print()
    
    results = []
    
    for i, q_data in enumerate(MARKET_QUESTIONS, 1):
        qid = q_data['id']
        question = q_data['question']
        expected_classification = q_data['expected_classification']
        
        print(f"\n{'='*100}")
        print(f"Question {i}/5 [{qid}]")
        print(f"{'='*100}")
        print(f"Q: {question}")
        
        # Verify classification
        classification = classify_question(question)
        classification_correct = classification == expected_classification
        
        if classification_correct:
            print(f"✅ Classification: {classification} (correct)")
        else:
            print(f"❌ Classification: {classification} (expected {expected_classification})")
        
        # Execute question
        print(f"\n🤖 Executing V6 Final Handler...")
        start_time = time.time()
        
        try:
            answer, chart_data, audio_summary, data_source, tool_calls = handle_question_with_agent(
                question, 
                return_tool_calls=True
            )
            
            execution_time = time.time() - start_time
            
            # Extract tool names
            tool_names = [tc['tool_name'] for tc in tool_calls if tc.get('success')]
            tool_call_count = len(tool_calls)
            
            success = bool(answer and len(answer) > 0)
            
            print(f"\n✅ Completed in {execution_time:.1f}s")
            print(f"   Tools used: {' → '.join(tool_names)}")
            print(f"   Tool calls: {tool_call_count}")
            print(f"   Answer length: {len(answer)} chars")
            
            # Print full LLM answer
            print(f"\n{'─'*100}")
            print("📝 FULL LLM ANSWER:")
            print(f"{'─'*100}")
            print(answer)
            print(f"{'─'*100}")
            
            # Store result
            results.append({
                "question_id": qid,
                "question": question,
                "success": success,
                "classification": classification,
                "classification_correct": classification_correct,
                "answer": answer,
                "chart_data": chart_data,
                "audio_summary": audio_summary,
                "data_source": data_source,
                "tool_calls": tool_calls,
                "tool_names": tool_names,
                "tool_call_count": tool_call_count,
                "execution_time": execution_time
            })
            
        except Exception as e:
            print(f"\n❌ Error: {str(e)}")
            import traceback
            traceback.print_exc()
            
            results.append({
                "question_id": qid,
                "question": question,
                "success": False,
                "classification": classification,
                "classification_correct": classification_correct,
                "error": str(e),
                "execution_time": time.time() - start_time
            })
    
    # Save results
    output_file = 'v6_5_market_questions_results.json'
    
    output_data = {
        "test_date": datetime.now().isoformat(),
        "model": "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        "handler": "novartis_agent_handler_v6_final",
        "total_questions": len(MARKET_QUESTIONS),
        "passed": sum(1 for r in results if r.get('success')),
        "failed": sum(1 for r in results if not r.get('success')),
        "classification_correct": sum(1 for r in results if r.get('classification_correct')),
        "results": results
    }
    
    with open(output_file, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"\n\n{'='*100}")
    print("SUMMARY")
    print(f"{'='*100}")
    print(f"\nTotal: {len(MARKET_QUESTIONS)}")
    print(f"✅ Passed: {output_data['passed']}")
    print(f"❌ Failed: {output_data['failed']}")
    print(f"🎯 Classification Correct: {output_data['classification_correct']}/{len(MARKET_QUESTIONS)}")
    print(f"\n📄 Results saved to: {output_file}")
    print(f"\n{'='*100}\n")

if __name__ == '__main__':
    main()
