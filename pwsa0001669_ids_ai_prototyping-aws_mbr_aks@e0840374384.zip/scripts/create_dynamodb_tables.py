"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Create DynamoDB Tables from CSV Files
Loads Novartis MBR data into DynamoDB for querying
"""

import boto3
import pandas as pd
import json
from decimal import Decimal
from datetime import datetime
import time

# DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

def convert_to_dynamodb_format(value):
    """Convert pandas values to DynamoDB compatible format"""
    if pd.isna(value):
        return None
    elif isinstance(value, (int, float)):
        return Decimal(str(value))
    elif isinstance(value, datetime):
        return value.isoformat()
    elif isinstance(value, pd.Timestamp):
        return value.isoformat()
    else:
        return str(value)

def create_sales_table():
    """Create and populate Sales Finance table"""
    table_name = 'Novartis_Sales_Finance'
    
    print(f"\n{'='*80}")
    print(f"Creating table: {table_name}")
    print(f"{'='*80}")
    
    # Delete table if exists
    try:
        table = dynamodb.Table(table_name)
        table.delete()
        print(f"Deleting existing table...")
        time.sleep(10)  # Wait for deletion
    except:
        pass
    
    # Create table
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'PK', 'KeyType': 'HASH'},  # Partition key
            {'AttributeName': 'SK', 'KeyType': 'RANGE'}  # Sort key
        ],
        AttributeDefinitions=[
            {'AttributeName': 'PK', 'AttributeType': 'S'},
            {'AttributeName': 'SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'},
                'ProvisionedThroughput': {
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            }
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        }
    )
    
    # Wait for table to be created
    print("Waiting for table to be created...")
    table.wait_until_exists()
    print("✓ Table created")
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data_sample/Real_data/SALES_FINANCE_BPC_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                # Primary Key: PRODUCT#ProductName#FORECAST#ForecastType
                'PK': f"PRODUCT#{row['DIM_Brand']}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{row['DIM_forecast']}",
                
                # GSI1: Query by date and forecast type
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"PRODUCT#{row['DIM_Brand']}#FORECAST#{row['DIM_forecast']}",
                
                # Attributes
                'product': str(row['PRODUCT']),
                'brand': str(row['DIM_Brand']),
                'forecast_type': str(row['DIM_forecast']),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'net_sales': convert_to_dynamodb_format(row['net_sales']),
                'gross_sales': convert_to_dynamodb_format(row['gross_sales']),
                'revenue_deductions': convert_to_dynamodb_format(row['revenue_deductions']),
                'source': str(row['source']),
                'data_frequency': str(row['data_frequency']),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'year_quarter': str(row['year_quarter']),
                'last_altered': str(row['last_altered']),
                'entity_type': 'SALES'
            }
            
            # Remove None values
            item = {k: v for k, v in item.items() if v is not None}
            
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def create_market_table():
    """Create and populate Market Share table"""
    table_name = 'Novartis_Market_Share'
    
    print(f"\n{'='*80}")
    print(f"Creating table: {table_name}")
    print(f"{'='*80}")
    
    # Delete table if exists
    try:
        table = dynamodb.Table(table_name)
        table.delete()
        print(f"Deleting existing table...")
        time.sleep(10)
    except:
        pass
    
    # Create table
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'PK', 'KeyType': 'HASH'},
            {'AttributeName': 'SK', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'PK', 'AttributeType': 'S'},
            {'AttributeName': 'SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'},
                'ProvisionedThroughput': {
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            }
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        }
    )
    
    print("Waiting for table to be created...")
    table.wait_until_exists()
    print("✓ Table created")
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data_sample/Real_data/FCT_MARKET_PLU_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                'PK': f"BRAND#{row['DIM_Brand']}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}",
                
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{row['DIM_Brand']}",
                
                'brand': str(row['DIM_Brand']),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'trx_r3m': convert_to_dynamodb_format(row.get('TRX_R3M')),
                'trx_share_r3m': convert_to_dynamodb_format(row['TRX_SHARE_R3M']),
                'nbrx_r3m': convert_to_dynamodb_format(row.get('NBRX_R3M')),
                'nbrx_share_r3m': convert_to_dynamodb_format(row['NBRX_SHARE_R3M']),
                'product': str(row.get('PRODUCT', '')),
                'class': str(row.get('Class', '')),
                'class_aggregated': str(row.get('class_aggregated', '')),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'cycle_rel_index': int(row['cycle_rel_index']),
                'year_quarter': str(row['year_quarter']),
                'entity_type': 'MARKET_SHARE'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def create_doses_table():
    """Create and populate Doses table"""
    table_name = 'Novartis_Doses'
    
    print(f"\n{'='*80}")
    print(f"Creating table: {table_name}")
    print(f"{'='*80}")
    
    # Delete table if exists
    try:
        table = dynamodb.Table(table_name)
        table.delete()
        print(f"Deleting existing table...")
        time.sleep(10)
    except:
        pass
    
    # Create table
    table = dynamodb.create_table(
        TableName=table_name,
        KeySchema=[
            {'AttributeName': 'PK', 'KeyType': 'HASH'},
            {'AttributeName': 'SK', 'KeyType': 'RANGE'}
        ],
        AttributeDefinitions=[
            {'AttributeName': 'PK', 'AttributeType': 'S'},
            {'AttributeName': 'SK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1PK', 'AttributeType': 'S'},
            {'AttributeName': 'GSI1SK', 'AttributeType': 'S'},
        ],
        GlobalSecondaryIndexes=[
            {
                'IndexName': 'GSI1',
                'KeySchema': [
                    {'AttributeName': 'GSI1PK', 'KeyType': 'HASH'},
                    {'AttributeName': 'GSI1SK', 'KeyType': 'RANGE'}
                ],
                'Projection': {'ProjectionType': 'ALL'},
                'ProvisionedThroughput': {
                    'ReadCapacityUnits': 5,
                    'WriteCapacityUnits': 5
                }
            }
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        }
    )
    
    print("Waiting for table to be created...")
    table.wait_until_exists()
    print("✓ Table created")
    
    # Load CSV data
    print("Loading CSV data...")
    df = pd.read_csv('data_sample/Real_data/FCT_DOSES_PLU_corrected.csv')
    df['dim_date'] = pd.to_datetime(df['dim_date'])
    
    print(f"Total records to insert: {len(df)}")
    
    # Insert data
    with table.batch_writer() as batch:
        for idx, row in df.iterrows():
            item = {
                'PK': f"BRAND#{row['DIM_Brand']}#METRIC#{row['metric']}",
                'SK': f"DATE#{row['dim_date'].strftime('%Y-%m-%d')}#FORECAST#{row['dim_forecast']}",
                
                'GSI1PK': f"DATE#{row['dim_date'].strftime('%Y-%m')}",
                'GSI1SK': f"BRAND#{row['DIM_Brand']}#METRIC#{row['metric']}#FORECAST#{row['dim_forecast']}",
                
                'brand': str(row['DIM_Brand']),
                'metric': str(row['metric']),
                'forecast_type': str(row['dim_forecast']),
                'date': row['dim_date'].strftime('%Y-%m-%d'),
                'year': int(row['dim_date'].year),
                'month': int(row['dim_date'].month),
                'quarter': f"{row['dim_date'].year}-Q{row['dim_date'].quarter}",
                'value': convert_to_dynamodb_format(row['value']),
                'product': str(row.get('PRODUCT', '')),
                'month_rel_index': int(row['month_rel_index']),
                'year_rel_index': int(row['year_rel_index']),
                'quarter_rel_index': int(row.get('quarter_rel_index', 0)),
                'entity_type': 'DOSES'
            }
            
            item = {k: v for k, v in item.items() if v is not None}
            batch.put_item(Item=item)
            
            if (idx + 1) % 100 == 0:
                print(f"  Inserted {idx + 1} records...")
    
    print(f"✓ Inserted {len(df)} records into {table_name}")
    return table

def verify_tables():
    """Verify table creation and data"""
    print(f"\n{'='*80}")
    print("VERIFICATION")
    print(f"{'='*80}")
    
    tables = [
        'Novartis_Sales_Finance',
        'Novartis_Market_Share',
        'Novartis_Doses'
    ]
    
    for table_name in tables:
        table = dynamodb.Table(table_name)
        count = table.item_count
        print(f"✓ {table_name}: {count} items")

def main():
    """Main execution"""
    print("="*80)
    print("NOVARTIS MBR - DYNAMODB TABLE CREATION")
    print("="*80)
    print(f"Region: us-east-1")
    print(f"Timestamp: {datetime.now().isoformat()}")
    
    try:
        # Create tables
        create_sales_table()
        create_market_table()
        create_doses_table()
        
        # Verify
        time.sleep(5)  # Wait for eventual consistency
        verify_tables()
        
        print(f"\n{'='*80}")
        print("✅ ALL TABLES CREATED SUCCESSFULLY")
        print(f"{'='*80}")
        
        print("\nTable Access Patterns:")
        print("-"*80)
        print("1. Query by Product and Date Range:")
        print("   PK = PRODUCT#Pluvicto")
        print("   SK begins_with DATE#2025")
        print()
        print("2. Query by Date (all products):")
        print("   GSI1PK = DATE#2025-12")
        print("   GSI1SK begins_with PRODUCT#")
        print()
        print("3. Query Market Share by Brand:")
        print("   PK = BRAND#Pluvicto")
        print("   SK between DATE#2024-01-01 and DATE#2025-12-31")
        print()
        print("4. Query Doses by Brand and Metric:")
        print("   PK = BRAND#Pluvicto#METRIC#TRX_shipped")
        print("   SK begins_with DATE#2025")
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        raise

if __name__ == '__main__':
    main()
