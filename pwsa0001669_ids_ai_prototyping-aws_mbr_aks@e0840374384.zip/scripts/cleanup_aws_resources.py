#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
AWS Resource Cleanup Script
Checks for resources that might be costing money and provides options to delete them.
"""

import boto3
import csv
import sys

# Load credentials
with open('isenguard_access/mbabakme-cli_accessKeys.csv', 'r', encoding='utf-8-sig') as f:
    reader = csv.DictReader(f)
    creds = next(reader)
    ACCESS_KEY = creds['Access key ID'].strip()
    SECRET_KEY = creds['Secret access key'].strip()

# AWS clients
dynamodb = boto3.client(
    'dynamodb',
    region_name='us-east-1',
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY
)

s3 = boto3.client(
    's3',
    region_name='us-east-1',
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY
)

print("=" * 80)
print("AWS RESOURCE COST CHECKER")
print("=" * 80)
print()

# Check DynamoDB tables
print("1. CHECKING DYNAMODB TABLES")
print("-" * 80)
try:
    tables = dynamodb.list_tables()
    mbr_tables = [t for t in tables['TableNames'] if 'cmc-kpi-data' in t.lower() or 'mbr' in t.lower()]
    
    if mbr_tables:
        print(f"Found {len(mbr_tables)} table(s):")
        for table in mbr_tables:
            # Get table details
            details = dynamodb.describe_table(TableName=table)
            item_count = details['Table']['ItemCount']
            size_bytes = details['Table']['TableSizeBytes']
            size_mb = size_bytes / (1024 * 1024)
            billing = details['Table']['BillingModeSummary']['BillingMode']
            
            print(f"  • {table}")
            print(f"    - Items: {item_count:,}")
            print(f"    - Size: {size_mb:.2f} MB")
            print(f"    - Billing: {billing}")
            
            if billing == 'PAY_PER_REQUEST':
                print(f"    - Cost: ~$1.25 per million reads, ~$1.25 per million writes")
                print(f"    - Storage: ~$0.25 per GB/month")
                print(f"    - Estimated: ~$0.01-0.10/month (very low usage)")
            else:
                print(f"    - Cost: Provisioned capacity (check AWS console)")
    else:
        print("  ✅ No MBR-related DynamoDB tables found")
except Exception as e:
    print(f"  ⚠️  Error checking DynamoDB: {e}")

print()

# Check S3 buckets
print("2. CHECKING S3 BUCKETS")
print("-" * 80)
try:
    buckets = s3.list_buckets()
    mbr_buckets = [b for b in buckets['Buckets'] if 'mbr' in b['Name'].lower() or 'cmc' in b['Name'].lower()]
    
    if mbr_buckets:
        print(f"Found {len(mbr_buckets)} bucket(s):")
        for bucket in mbr_buckets:
            print(f"  • {bucket['Name']}")
            print(f"    - Created: {bucket['CreationDate']}")
            print(f"    - Cost: ~$0.023 per GB/month + requests")
    else:
        print("  ✅ No MBR-related S3 buckets found")
except Exception as e:
    print(f"  ⚠️  Error checking S3: {e}")

print()

# Bedrock and Polly are pay-per-use (no ongoing costs when not in use)
print("3. BEDROCK & POLLY")
print("-" * 80)
print("  ℹ️  Bedrock and Polly are pay-per-use services")
print("  ℹ️  No cost when not actively making API calls")
print("  ℹ️  Since local servers are stopped, no ongoing costs")

print()
print("=" * 80)
print("COST SUMMARY")
print("=" * 80)
print()
print("Current estimated monthly costs:")
print("  • DynamoDB (on-demand): ~$0.01-0.10/month")
print("  • S3 (if used): ~$0.01-0.05/month")
print("  • Bedrock: $0 (only when used)")
print("  • Polly: $0 (only when used)")
print()
print("  TOTAL: ~$0.02-0.15/month (essentially free)")
print()
print("=" * 80)
print()

# Ask if user wants to delete resources
print("OPTIONS:")
print()
print("1. KEEP EVERYTHING (Recommended)")
print("   - Costs are negligible (~$0.02-0.15/month)")
print("   - Can restart demo anytime")
print("   - Data preserved")
print()
print("2. DELETE DYNAMODB TABLE")
print("   - Saves ~$0.01-0.10/month")
print("   - Will need to reload data to use again")
print()
print("3. DELETE EVERYTHING")
print("   - Saves ~$0.02-0.15/month")
print("   - Will need to recreate all resources")
print()

choice = input("Enter choice (1/2/3) or 'q' to quit: ").strip()

if choice == '2':
    confirm = input("Delete DynamoDB table 'cmc-kpi-data'? (yes/no): ").strip().lower()
    if confirm == 'yes':
        try:
            dynamodb.delete_table(TableName='cmc-kpi-data')
            print("✅ DynamoDB table deleted")
        except Exception as e:
            print(f"❌ Error deleting table: {e}")
    else:
        print("Cancelled")

elif choice == '3':
    confirm = input("Delete ALL resources? This cannot be undone. (yes/no): ").strip().lower()
    if confirm == 'yes':
        # Delete DynamoDB
        try:
            dynamodb.delete_table(TableName='cmc-kpi-data')
            print("✅ DynamoDB table deleted")
        except Exception as e:
            print(f"⚠️  DynamoDB: {e}")
        
        # Delete S3 buckets
        for bucket in mbr_buckets:
            try:
                # Empty bucket first
                bucket_name = bucket['Name']
                objects = s3.list_objects_v2(Bucket=bucket_name)
                if 'Contents' in objects:
                    for obj in objects['Contents']:
                        s3.delete_object(Bucket=bucket_name, Key=obj['Key'])
                s3.delete_bucket(Bucket=bucket_name)
                print(f"✅ S3 bucket {bucket_name} deleted")
            except Exception as e:
                print(f"⚠️  S3: {e}")
        
        print("✅ All resources deleted")
    else:
        print("Cancelled")

else:
    print("✅ Keeping all resources (recommended)")
    print()
    print("To restart the demo later:")
    print("  1. python backend_api/app.py")
    print("  2. cd frontend && npm start")
    print("  3. Open http://localhost:3000")

print()
print("=" * 80)
print("DONE")
print("=" * 80)
