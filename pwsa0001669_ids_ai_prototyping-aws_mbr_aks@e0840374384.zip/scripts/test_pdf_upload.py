#!/usr/bin/env python3
"""
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
"""

"""
Test PDF Upload Endpoint
"""
import requests
import time

# Test file
pdf_path = 'data_sample/Novartis_MBR_December_2025.pdf'

print("="*80)
print("Testing PDF Upload Endpoint")
print("="*80)

# Step 1: Upload PDF
print("\n1. Uploading PDF...")
with open(pdf_path, 'rb') as f:
    files = {'pdf': ('presentation.pdf', f, 'application/pdf')}
    response = requests.post('http://localhost:5000/api/preprocess', files=files)

if response.status_code == 200:
    print("✅ Upload successful!")
    print(f"   Response: {response.json()}")
else:
    print(f"❌ Upload failed: {response.status_code}")
    print(f"   Error: {response.text}")
    exit(1)

# Step 2: Poll status
print("\n2. Polling preprocessing status...")
for i in range(30):  # Poll for up to 30 seconds
    time.sleep(1)
    response = requests.get('http://localhost:5000/api/preprocess/status')
    
    if response.status_code == 200:
        status = response.json()
        stage = status.get('stage', 'unknown')
        progress = status.get('progress', 0) * 100
        message = status.get('message', '')
        
        print(f"   [{i+1}s] {stage.upper()}: {progress:.0f}% - {message}")
        
        if stage == 'complete':
            print("\n✅ Preprocessing complete!")
            break
        elif stage == 'error':
            print(f"\n❌ Preprocessing failed: {message}")
            break
    else:
        print(f"   ❌ Status check failed: {response.status_code}")

print("\n" + "="*80)
print("Test Complete")
print("="*80)
