<!--
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
-->

# MBR Dashboard - Quick Start Guide

Get the MBR Dashboard running in 2 minutes!

## 📋 Prerequisites

Before starting, ensure you have the following installed and configured:

### Required Software
- **Python 3.8+** - [Download Python](https://www.python.org/downloads/)
- **Node.js 16+** - [Download Node.js](https://nodejs.org/)
- **Docker** - [Install Docker](https://docs.docker.com/get-docker/)
- **AWS CLI v2** - [Install AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)

### AWS Configuration

#### 1. Install AWS CLI
Choose the installation method for your operating system:

**Option 1: Package Managers**
```bash
# macOS (Homebrew)
brew install awscli

# Linux (apt)
sudo apt install awscli

# Linux (yum)
sudo yum install awscli

# Windows (Chocolatey)
choco install awscli
```

**Option 2: Official Installers**
- **Windows**: Download MSI installer from [AWS CLI Install Guide](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)
- **macOS**: Download PKG installer from [AWS CLI Install Guide](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)
- **Linux**: Download and run the installer script from [AWS CLI Install Guide](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)

#### 2. Configure AWS Profile
Configure AWS credentials with appropriate permissions:

```bash
# Option 1: Configure default profile
aws configure

# Option 2: Configure a named profile (recommended)
aws configure --profile your-profile-name

# Set the profile for all AWS commands in this session
export AWS_PROFILE=your-profile-name
```

**Required Information:**
- AWS Access Key ID
- AWS Secret Access Key  
- Default region (e.g., `us-east-1`)
- Default output format (recommend `json`)

**Profile Management:**
- **Recommended**: Use a named profile and export `AWS_PROFILE`
- **Alternative**: Use `AWS_PROFILE=profile-name` before each command
- **Default**: Configure default profile with `aws configure`

#### 3. Required AWS Permissions
Your AWS profile needs permissions for:
- **EC2**: Create/manage instances, security groups, load balancers
- **ECS**: Create/manage clusters, services, tasks
- **DynamoDB**: Create/manage tables and data
- **S3**: Create/manage buckets and objects
- **IAM**: Create/manage roles and policies
- **CloudFormation**: Deploy infrastructure stacks
- **ECR**: Push/pull Docker images

#### 4. Verify AWS Access
```bash
# Test your AWS configuration
aws sts get-caller-identity

# Should return your account ID, user ARN, and user ID
```

### Environment Setup
```bash
cd mbr-dashboard

# Verify all prerequisites
python --version    # Should be 3.8+
node --version      # Should be 16+
docker --version    # Should be installed
aws --version       # Should be v2.x
```

## 🚀 Option 1: Local Development (Recommended for Testing)

### Super Quick Start
```bash
# One command setup and start
./dev.sh setup && ./dev.sh dev
```

### Manual Setup (if you prefer step-by-step)
```bash
# 1. Setup everything
./dev.sh setup

# 2. Start development server (RECOMMENDED - separate ports)
./dev.sh dev
```

**Development Modes:**
- **`./dev.sh dev`** - Development mode (RECOMMENDED)
  - Frontend: http://localhost:3000 (with hot reload)
  - Backend: http://localhost:5000 (API only)
  - Best for development, microphone works perfectly
  
- **`./dev.sh start`** - Production mode
  - Single port: http://localhost:5000
  - Frontend served from Flask
  - Best for production-like testing

### 📊 Setup DynamoDB Tables and Data (Required for Data Queries)
For local development, you need to create DynamoDB tables and populate them with sample data:

```bash
# Create all 5 tables and load sample Novartis data
python utils/data_management/load_all_tables.py --region us-east-1
```

**What this does:**
- Creates 5 local DynamoDB tables(if they dont exist): Sales Finance, Market Share, Doses, Calls, and Rome
- Populates tables with sample data from CSV files (uses expanded files for Calls/Rome, corrected files for others)
- Enables the AI agent to answer questions about sales performance, market trends, patient data, etc.

**Note:** This step is essential for the application to provide meaningful responses to business questions.

### Access Your Application

**Development Mode** (`./dev.sh dev`):
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **API Health**: http://localhost:5000/api/health

**Production Mode** (`./dev.sh start`):
- **Application**: http://localhost:5000
- **API Health**: http://localhost:5000/api/health

**All features**: Upload PDFs, ask questions, get AI responses with voice controls

## ☁️ Option 2: AWS Deployment 

> **⚠️ DISCLAIMER: This is sample code for reference only and serves as a starting point for deploying MBR prototype. This is NOT meant to be the full deployed solution, but rather a helper/aid for faster development and testing. Flask application is deployed to ECS Fargate on a private load balancer. To make the applicatiohn accessible, it needs to be integrated with DNS and appropriate authentication mechanisms. The code and infrastructure needs to be hardened, reviewed, and properly configured for deployment. This includes but is not limited to: front-end authentication/authorization, DNS setup, security groups, IAM policies, encryption, monitoring, backup strategies, compliance requirements, scalability considerations, and proper DevOps practices.**

**Note:** Ensure you've completed all [Prerequisites](#📋-prerequisites) above before proceeding.

### Simple AWS Deployment

#### Basic Deployment (Private Load Balancer)
```bash
# Set your AWS profile (replace with your actual profile name)
export AWS_PROFILE=your-profile-name

# Deploy with private ALB (recommended for internal use)
./deploy.sh
```

**Alternative: One-time profile usage**
```bash
# Use profile for single command (without setting environment variable)
AWS_PROFILE=your-profile-name ./deploy.sh
```

**What gets deployed:**
- **Private Application Load Balancer** (internal VPC access only)
- **ECS Fargate** service running the application container
- **ECR Repository** for Docker images
- **DynamoDB Tables** for data storage
- **CloudWatch Logs** for monitoring
- **Basic Security Groups** with minimal required access

**Infrastructure Components:**
- Uses your default VPC with private subnets (required)
- HTTP-only (port 80) - no HTTPS/SSL
- No authentication - direct application access
- Private ALB accessible only within VPC
- Single Fargate task (can be scaled manually)

**Requirements:**
- VPC must have private subnets (deployment will fail if only public subnets exist)
- For security, public subnets are never used

### 📝 Environment Configuration (Optional)

For custom VPC/subnet configuration, create a `.env` file:

```bash
# Copy the example configuration file
cp .env.example.aws .env

# Edit the .env file with your specific settings
nano .env  # or use your preferred editor
```

**Available Configuration Options:**
```bash
# AWS Configuration
AWS_DEFAULT_REGION=us-east-1

# Optional: Custom VPC Configuration
# If not specified, uses default VPC and subnets
VPC_ID=vpc-xxxxxxxxx
PRIVATE_SUBNET_IDS=subnet-xxxxxxxx,subnet-yyyyyyyy
PUBLIC_SUBNET_IDS=subnet-aaaaaaaa,subnet-bbbbbbbb
```

**When to use .env file:**
- ✅ **Custom VPC**: You want to deploy to a specific VPC
- ✅ **Custom Subnets**: You have specific private/public subnets to use
- ✅ **Different Region**: You want to deploy to a region other than us-east-1
- ❌ **Default Setup**: Leave .env file uncreated to use defaults

**Note:** The deployment script automatically loads `.env` if it exists, otherwise uses sensible defaults.

**Access Requirements:**
Since the ALB is private, you'll need to access it from within the VPC:
- From an EC2 instance in the same VPC
- Through a VPN connection to the VPC
- Via AWS Systems Manager Session Manager
- From a bastion host (if you have one)

### 🧪 Test Your AWS Deployment

After deployment, verify everything is working with the automated testing script.

#### Step 1: Get Your ALB URL (Optional - Auto-detected)

The testing script will automatically detect your ALB URL from the CloudFormation stack. If you need to get it manually or troubleshoot:

```bash
# Get the ALB URL from your deployed stack
AWS_PROFILE=your-profile-name aws cloudformation describe-stacks \
    --stack-name MbrDashboardStack \
    --region us-east-1 \
    --query 'Stacks[0].Outputs[?OutputKey==`ApplicationUrl`].OutputValue' \
    --output text

# Example output: http://internal-mbr-dashboard-alb-1887640493.us-east-1.elb.amazonaws.com
```

#### Step 2: Run the Test Script

```bash
# Option 1: Auto-detection (Recommended)
# The script will automatically find your ALB URL
AWS_PROFILE=your-profile-name ./scripts/setup-vpc-testing.sh

# Option 2: Manual ALB URL (if auto-detection fails)
# Set the ALB DNS manually if needed
export ALB_DNS="internal-mbr-dashboard-alb-XXXXXXXXX.us-east-1.elb.amazonaws.com"
AWS_PROFILE=your-profile-name ./scripts/setup-vpc-testing.sh

# Option 3: One-time manual override
ALB_DNS="your-alb-dns-here" AWS_PROFILE=your-profile-name ./scripts/setup-vpc-testing.sh
```

**What the test does:**
- ✅ Creates a temporary EC2 instance in your private subnet
- ✅ Tests health endpoint (`/api/health`)
- ✅ Tests main application (React frontend)
- ✅ Tests API endpoints (`/api/ask`)
- ✅ Automatically cleans up the test instance

**Expected Results:**
- Health endpoint: Status 200 ✓
- Main application: React app loads ✓
- API endpoints: Status 200 ✓
- Static files: Status 200 ✓


### 📊 Populate DynamoDB Tables (Required for Data Queries)
After successful deployment, populate the DynamoDB tables with sample data:

```bash
# Load sample Novartis data into DynamoDB tables
# (Uses the same AWS_PROFILE if set above)
python utils/data_management/load_all_tables.py --region us-east-1
```

**What this does:**
- Creates sample data for Novartis Sales, Market Share, Doses, Calls, and Rome
- Populates 5 DynamoDB tables from CSV files with correct data structure
- Enables the AI agent to answer questions about sales performance, market trends, etc.

**Note:** This step is essential for the application to provide meaningful responses to business questions.

### 🧹 Cleanup AWS Resources

When you're done testing or want to remove all AWS resources to avoid ongoing costs:

```bash
# Complete cleanup - removes ALL AWS resources
./cleanup.sh
```

**⚠️ WARNING: This action is irreversible!**

**What gets deleted:**
- **All DynamoDB Tables** and their data (Sales, Market Share, Doses, Calls, Rome)
- **ECS Cluster & Service** (stops all running tasks)
- **Application Load Balancer** and Target Groups
- **ECR Repository** and all Docker images
- **IAM Roles & Policies** created for the application
- **Security Groups** and networking components
- **CloudWatch Log Groups** and all logs
- **Local Docker images** (cleanup)

**Safety Features:**
- Requires typing "yes" to confirm deletion
- Shows clear warnings before proceeding
- Cannot be accidentally triggered

**Cost Savings:**
After cleanup, you'll have **zero ongoing AWS costs** from this deployment.

**When to use cleanup:**
- ✅ **Done testing**: You've finished evaluating the application
- ✅ **Fresh start**: You want to redeploy from scratch
- ✅ **Cost control**: You want to avoid any ongoing charges
- ❌ **Temporary pause**: Use ECS service scaling instead

**Alternative: Pause without deletion**
If you want to temporarily stop costs without losing data:
```bash
# Scale ECS service to 0 (stops compute costs, keeps data)
aws ecs update-service --cluster mbr-dashboard-cluster --service mbr-dashboard-service --desired-count 0 --region us-east-1

# Scale back up when needed
aws ecs update-service --cluster mbr-dashboard-cluster --service mbr-dashboard-service --desired-count 1 --region us-east-1
```

## 📚 Full Documentation

See [README.md](README.md) for complete documentation including:
- Detailed prerequisites
- Configuration options
- Security settings
- Monitoring and troubleshooting
- Contributing guidelines