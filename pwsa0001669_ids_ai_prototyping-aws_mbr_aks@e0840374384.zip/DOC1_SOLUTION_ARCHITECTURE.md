<!--
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
-->

# MBR Dashboard - Solution Architecture & Technology Decisions

**Document Version:** 1.0  
**Date:** December 12, 2025  
**System Version:** V2.2.1  
**Author:** AI Development Team

---

## 1. Executive Summary

The MBR Dashboard is a conversational AI-powered analytics platform that enables natural language interaction with Monthly Business Review (MBR) data. The solution combines modern web technologies, AWS AI services, and intelligent architecture patterns to deliver fast, accurate, and user-friendly data exploration.

**Key Capabilities:**
- Natural language queries with voice and text input
- Real-time chart generation (pie, line, bar, multi-series)
- Intelligent follow-up question suggestions
- 70% faster response times through preprocessing (7-15s vs 24-27s)
- Complete MBR data coverage across 5 business dimensions

**Technology Philosophy:**
The architecture prioritizes simplicity, performance, and maintainability over complexity. We chose proven, lightweight technologies that deliver production-grade results without unnecessary overhead. Every technology decision was made to optimize for speed, cost-efficiency, and developer productivity.

**Performance Evolution:**
- V1.0: 30-50 seconds (baseline)
- V2.0: 13-15 seconds (50-70% improvement)
- V2.1: 17-20 seconds (complete data coverage)
- V2.2: 7-15 seconds (slide: 7s, data: 15s, 70% improvement with preprocessing)

---

## 2. Solution Components

### 2.1 Frontend Architecture

**Technology Stack:**
- **Framework:** React 18 with TypeScript
- **Build Tool:** Vite (fast development and production builds)
- **Charting:** Recharts (React-native charting library)
- **Voice Input:** Web Speech API (browser-native)
- **Styling:** CSS3 with custom QuickSuite-inspired theme

**Key Features:**

1. **Conversational Interface**
   - Chat-based UI with message history
   - Support for text and voice input
   - Real-time response streaming
   - Follow-up question suggestions

2. **Chart Visualization**
   - Dynamic chart rendering with Recharts
   - Support for pie, line, bar, and multi-series charts
   - Responsive design with tooltips and legends
   - Automatic chart type selection based on data

3. **Voice Controls**
   - Browser-native Web Speech API
   - Real-time transcription display
   - Visual feedback during recording
   - Automatic question submission

4. **PDF Upload & Slide Navigation**
   - PDF upload with automatic slide extraction
   - Slide-by-slide navigation
   - Slide preview with zoom controls
   - Context-aware questioning

**Component Structure:**
```
frontend/src/
├── App.tsx                    # Main application with state management
├── components/
│   ├── AIPanel.tsx           # Chat interface and message display
│   ├── ChartDisplay.tsx      # Recharts visualization component
│   ├── VoiceControls.tsx     # Web Speech API integration
│   ├── PDFUpload.tsx         # PDF handling and slide extraction
│   └── SlideViewer.tsx       # Slide navigation and display
└── App.css                   # QuickSuite purple theme
```

### 2.2 Backend Architecture

**Technology Stack:**
- **Framework:** Flask (Python 3.9+)
- **AI/ML:** AWS Bedrock (Claude Sonnet 4.5)
- **Text-to-Speech:** Amazon Polly
- **Database:** DynamoDB (5 tables)
- **Connection Pooling:** Centralized AWS client management

**Key Features:**

1. **Agentic AI System**
   - Custom agent with 5 table-aligned tools
   - Intelligent query routing and optimization
   - Multi-step reasoning with tool orchestration
   - Context-aware response generation

2. **Preprocessing System**
   - One-time slide data extraction during upload
   - Structured JSON storage for fast retrieval
   - 70% faster response times (7-10s vs 24-27s)
   - Automatic fallback to image processing

3. **Chart Generation**
   - Python-based chart data generation
   - Keyword detection (chart, graph, plot, pie, bar, line)
   - Support for single and multi-series charts
   - Automatic chart type selection

4. **Audio Summary Generation**
   - Claude-generated concise summaries (60 words)
   - Intelligent follow-up question suggestions
   - Amazon Polly text-to-speech conversion
   - Optimized for natural speech patterns

**API Structure:**
```
backend_api/
├── app.py                              # Flask API with CORS
├── novartis_agent_handler_v2_1.py     # Agent with 5 tools
├── novartis_queries_v2_1.py           # DynamoDB query functions
├── aws_clients.py                      # Connection pooling
├── slide_preprocessor.py               # Preprocessing engine
└── utils/
    ├── chart_generator.py              # Chart data generation
    └── audio_summary.py                # Polly integration
```

### 2.3 Conversational Technology

**Speech-to-Text:**
- **Technology:** Web Speech API (browser-native)
- **Rationale:** Zero latency, no AWS costs, instant transcription
- **Implementation:** JavaScript SpeechRecognition API
- **Features:** Real-time transcription, automatic language detection

**Text-to-Speech:**
- **Technology:** Amazon Polly
- **Voice:** Joanna (US English, Neural)
- **Rationale:** High-quality neural voices, AWS integration
- **Implementation:** Polly SynthesizeSpeech API with MP3 output

**Summary Generation:**

- **Technology:** Claude Sonnet 4.5 (AWS Bedrock)
- **Approach:** Dedicated prompt for concise 60-word summaries
- **Features:** Context-aware, includes follow-up questions
- **Optimization:** Single LLM call, fast generation

**Conversation Flow:**
```
User Input (Voice/Text)
    ↓
Web Speech API (if voice) → Transcription
    ↓
Flask API (/api/ask)
    ↓
Agent Handler (Claude Sonnet 4.5)
    ↓
Tool Execution (DynamoDB queries)
    ↓
Chart Generation (Python)
    ↓
Response Generation (Claude)
    ↓
Audio Summary (Claude → Polly)
    ↓
Frontend Display (Text + Chart + Audio)
```

### 2.4 AI/ML Components

**Primary Model: Claude Sonnet 4.5 (AWS Bedrock)**
- **Use Cases:** Question analysis, tool orchestration, response generation, audio summaries
- **Rationale:** Best-in-class reasoning, function calling, vision capabilities
- **Performance:** 3-5s per LLM call, 2-3 iterations typical
- **Cost:** $3 per million input tokens, $15 per million output tokens

**Vision Model: Claude Sonnet 4.5 Vision**
- **Use Cases:** Slide preprocessing, image analysis
- **Rationale:** Accurate text extraction, chart understanding
- **Performance:** 8-9s per slide (one-time during upload)
- **Cost:** Higher than text-only, but amortized over many queries

**Agent Architecture:**
- **Type:** Custom agent with function calling
- **Tools:** 5 table-aligned tools (Sales, Doses, Market Share, Calls, Rome)
- **Routing:** Intelligent tool selection based on question keywords
- **Optimization:** Parallel tool calling, smart context management

### 2.5 Data Layer

**Database: Amazon DynamoDB**
- **Tables:** 5 tables covering complete MBR data
- **Schema:** Partition key (product/region), sort key (date)
- **Indexes:** GSI for efficient querying by different dimensions
- **Performance:** Single-digit millisecond latency

**Table Structure:**


1. **Novartis_Sales_Finance** (2020-2028)
   - Net sales, gross sales, revenue deductions
   - Monthly and quarterly aggregations
   - Actual (2020-2025) + Forecast (2026-2028)

2. **Novartis_Doses** (2020-2028)
   - National dose metrics by product
   - Monthly and quarterly aggregations
   - Actual (2020-2025) + Forecast (2026-2028)

3. **Novartis_Market_Share** (2020-2028)
   - TRX and NBRX market share
   - Competitor analysis
   - Actual data only

4. **Novartis_Calls** (2020-2025)
   - Field activity metrics
   - HCP reach and engagement
   - Actual data only (1,920 rows)

5. **Novartis_Rome** (2020-2025)
   - Site activation and patient demand
   - Regional performance metrics
   - Actual data only (2,951 rows)

**Data Volume:**
- Total records: ~7,000 rows across 5 tables
- Time range: 2020-2028 (6 years actual + 3 years forecast)
- Update frequency: Monthly

### 2.6 Preprocessing System

**Purpose:** Extract structured data from slides once during upload to eliminate repeated vision model calls.

**Architecture:**
```
PDF Upload
    ↓
Slide Extraction (pdf2image)
    ↓
Preprocessing (Claude Vision)
    ↓
Structured JSON Storage
    ↓
Fast Text-Only Queries (70% faster)
```

**Data Extracted:**
- Title and brief summary
- Top 5 key metrics with values
- Main topics and categories
- Time period information

**Performance Impact:**
- Before: 24-27s per query (vision model every time)
- After: 7-10s per query (text-only LLM calls)
- Improvement: 70% faster response times

**Storage:**
- Format: JSON file (preprocessed_slides.json)
- Size: ~213KB for 36 slides
- Location: data_sample/ directory

### 2.7 Conversation Memory & Context Management

**Purpose:** Enable natural follow-up conversations by maintaining short-term context and intelligently resolving confirmations and references.

**Current Implementation: Short-Term Memory (Last 2-3 Exchanges)**

**Architecture:**
```
User Question
    ↓
Frontend: Passes last 6 messages (3 exchanges)
    ↓
Backend: resolve_follow_up_question()
    ↓
Check if confirmation ("yes", "ok", "do it")
    ↓
If YES: Extract suggested question from last response
    ↓
If NO: Check for follow-up indicators ("same chart", "instead of")
    ↓
Resolved Question → Agent Handler
    ↓
Agent: Uses last 4 messages for context
```

**Key Features:**

1. **Confirmation Detection**
   - Recognizes: "yes", "yeah", "ok", "sure", "do it", "go ahead", "perfect"
   - Extracts suggested question from last assistant message
   - Prioritizes audio summary (where follow-up suggestions are)
   - Automatically executes the suggested question

2. **Follow-Up Question Resolution**
   - Detects: "same chart", "same graph", "instead of", "what about"
   - Extracts context from last response (time period, data type, chart type)
   - Resolves references to construct complete question
   - Example: "same chart for 2027" → "Show me enrollment by county as a pie chart for October 2027"

3. **Context Window**
   - Frontend: Last 6 messages (3 user + 3 assistant exchanges)
   - Backend: Last 4 messages for agent context
   - Includes audioSummary in conversation history
   - Lightweight, no database storage

**Implementation Details:**

```python
# app.py - Follow-up resolution
def resolve_follow_up_question(question, conversation_history):
    # 1. Check for confirmation
    if is_confirmation(question):
        # Extract from audio summary first
        suggested = extract_from_audio_summary(conversation_history[-1])
        if suggested:
            return suggested
    
    # 2. Check for follow-up indicators
    if has_follow_up_indicators(question):
        # Extract context from last response
        context = extract_query_context(conversation_history[-1])
        # Resolve references
        return resolve_with_context(question, context)
    
    return question

# novartis_agent_handler_v2_1.py - Context usage
def handle_question_with_agent(question, conversation_history=None):
    messages = []
    
    # Add conversation history (last 4 messages)
    if conversation_history:
        for msg in conversation_history[-4:]:
            messages.append({
                "role": msg['role'],
                "content": msg['content']
            })
    
    # Add current question
    messages.append({"role": "user", "content": question})
```

**Example Conversation Flow:**

```
User: "Show me Pluvicto sales in January 2025"
AI: "Pluvicto generated $88M in January 2025. 
     Would you like to compare it vs January 2024?"
     [audioSummary contains the suggestion]

User: "yes"
     ↓
Backend detects confirmation
     ↓
Extracts "compare it vs January 2024" from audioSummary
     ↓
Resolves to: "Compare Pluvicto sales January 2025 vs January 2024"
     ↓
Executes comparison automatically
```

**Benefits:**
- Natural conversation flow
- No need to repeat context
- Intelligent confirmation handling
- Lightweight (no database needed)
- Fast resolution (<10ms)

**Limitations (Current):**
- No long-term memory (session-based only)
- No conversation persistence across sessions
- Limited to last 2-3 exchanges
- No user preference learning
- No cross-session insights

**Future Enhancement: Long-Term Memory**

**Proposed Architecture:**
```
Short-Term Memory (Current)          Long-Term Memory (Future)
─────────────────────────            ────────────────────────
Last 2-3 exchanges                   DynamoDB Table: Conversations
In-memory (browser)                  - user_id (partition key)
No persistence                       - session_id (sort key)
                                     - timestamp
                                     - conversation_history
                                     - user_preferences
                                     - frequently_asked_questions
                                     
                                     DynamoDB Table: UserPreferences
                                     - user_id (partition key)
                                     - preferred_chart_types
                                     - favorite_products
                                     - common_time_periods
                                     - interaction_patterns
```

**Long-Term Memory Use Cases:**

1. **Session Persistence**
   - Resume conversations across sessions
   - "Continue where we left off"
   - Access previous analyses
   - Review historical questions

2. **User Preference Learning**
   - Remember preferred chart types
   - Default to user's favorite products
   - Learn common time periods
   - Personalize responses

3. **Cross-Session Insights**
   - "You asked about this last week"
   - "This is different from last month's data"
   - Trend analysis across sessions
   - Proactive insights

4. **Conversation Search**
   - "What did we discuss about Q1 sales?"
   - Search previous conversations
   - Retrieve past analyses
   - Export conversation history

**Implementation Approach (Future):**

**Phase 1: Conversation Persistence (2-3 weeks)**
```python
# Store conversation after each exchange
def save_conversation(user_id, session_id, messages):
    dynamodb.put_item(
        TableName='Conversations',
        Item={
            'user_id': user_id,
            'session_id': session_id,
            'timestamp': datetime.now().isoformat(),
            'messages': messages,
            'ttl': int(time.time()) + 30*24*60*60  # 30 days
        }
    )

# Load conversation on session start
def load_conversation(user_id, session_id):
    response = dynamodb.get_item(
        TableName='Conversations',
        Key={'user_id': user_id, 'session_id': session_id}
    )
    return response.get('Item', {}).get('messages', [])
```

**Phase 2: User Preference Learning (1-2 months)**
```python
# Track user preferences
def update_user_preferences(user_id, interaction):
    # Analyze interaction patterns
    if 'chart' in interaction:
        increment_preference(user_id, 'chart_types', interaction['chart_type'])
    if 'product' in interaction:
        increment_preference(user_id, 'products', interaction['product'])
    
# Apply preferences to queries
def apply_user_preferences(user_id, question):
    prefs = get_user_preferences(user_id)
    if not has_explicit_chart_type(question):
        question += f" as {prefs['preferred_chart_type']}"
    return question
```

**Phase 3: Semantic Search (2-3 months)**
```python
# Embed conversations for semantic search
def embed_conversation(conversation):
    # Use Bedrock Titan Embeddings
    embedding = bedrock.invoke_model(
        modelId='amazon.titan-embed-text-v1',
        body=json.dumps({'inputText': conversation})
    )
    return embedding

# Search previous conversations
def search_conversations(user_id, query):
    query_embedding = embed_conversation(query)
    # Use vector similarity search
    similar_conversations = vector_search(query_embedding)
    return similar_conversations
```

**Cost Considerations:**

**Current (No Long-Term Memory):**
- Storage: $0 (in-memory only)
- Queries: $0 (no database reads)
- Total: $0/month

**With Long-Term Memory:**
- DynamoDB Storage: ~$0.25/GB/month
  - 1000 conversations × 10KB = 10MB = $0.0025/month
- DynamoDB Reads: $0.25 per million reads
  - 1000 session loads = $0.00025
- Embeddings (if semantic search): $0.0001 per 1000 tokens
  - 1000 conversations × 500 tokens = $0.05/month
- Total: ~$0.05-0.10/month per user

**Privacy & Compliance:**
- Conversation data contains business metrics (not PII)
- 30-day TTL for automatic cleanup
- User-controlled deletion
- Encryption at rest (DynamoDB default)
- Access control via IAM

**Recommendation:**
- **Current approach is sufficient** for MVP and initial deployment
- Short-term memory handles 90% of use cases
- Long-term memory is a **nice-to-have enhancement** for power users
- Implement only if user feedback indicates need
- Start with Phase 1 (persistence) before advanced features

### 2.8 Text-to-Query Strategy & Data Accuracy

**Purpose:** Ensure accurate data retrieval and correct aggregation from natural language questions, handling temporal granularity (monthly data → quarterly/yearly aggregations).

**Core Philosophy: "Claude Analyzes, DynamoDB Filters"**

The system follows a clear division of responsibilities:
- **DynamoDB:** Filters data at database level (fast, efficient)
- **Claude:** Analyzes and aggregates results (intelligent, flexible)
- **No Python Aggregation:** Eliminated for simplicity and performance

**Architecture Flow:**

```
User Question: "What were Pluvicto Q1 2025 sales?"
    ↓
Claude Agent: Analyzes question
    ↓
Tool Selection: query_sales_finance_table
    ↓
Parameter Extraction:
    - products: ["Pluvicto"]
    - start_date: "2025-01-01"
    - end_date: "2025-03-31"
    - forecast_types: ["Actual"]
    ↓
DynamoDB Query: Returns ALL monthly records (Jan, Feb, Mar)
    ↓
Claude Analysis: Sums monthly data → Q1 total
    ↓
Response: "Pluvicto Q1 2025 sales were $251M"
```

**Key Design Decisions:**

**1. Table-Aligned Tools (ONE Question = ONE Table = ONE Tool Call)**

Each tool maps to exactly one DynamoDB table:

| Tool | Table | Use Cases |
|------|-------|-----------|
| query_sales_finance_table | Novartis_Sales_Finance | Revenue, net sales, gross sales, deductions |
| query_doses_table | Novartis_Doses | TRX_shipped, TRX_injected, NBRX |
| query_market_share_table | Novartis_Market_Share | Market share, competitors, volumes |
| query_calls_table | Novartis_Calls | Field activity, HCP reach, call frequency |
| query_rome_table | Novartis_Rome | Site activation, patient demand, territories |

**Benefits:**
- Clear routing logic (no ambiguity)
- Single tool call per question (fast)
- Complete data in one query (no multiple calls)
- Better LLM reasoning (focused tool descriptions)

**2. Broad Date Range Strategy**

**Problem:** Monthly data needs quarterly/yearly aggregation

**Solution:** Query broad date range, let Claude aggregate

```python
# ✅ CORRECT: Broad date range
{
    "start_date": "2025-01-01",
    "end_date": "2025-03-31",  # Gets all 3 months
    "products": ["Pluvicto"]
}
# Returns: Jan, Feb, Mar records
# Claude sums: $88M + $81M + $82M = $251M

# ❌ WRONG: Pre-aggregated request
{
    "quarter": "Q1",  # Not supported
    "year": 2025
}
```

**Why This Works:**
- Data granularity: Monthly (finest level)
- Query returns: All monthly records in range
- Claude aggregates: Sums/averages as needed
- Flexible: Works for any time period (week, month, quarter, year, YTD)

**3. Relative Index Filtering (Fast Time Comparisons)**

**Problem:** String date comparisons are slow

**Solution:** Pre-calculated integer indexes in data

```python
# Data structure includes relative indexes
{
    "date": "2025-01-01",
    "year_rel_index": 1000,      # Current year
    "month_rel_index": 1000,     # Current month
    "cycle_rel_index": 1000,     # Current quarter
}

# Previous periods
{
    "date": "2024-10-01",
    "year_rel_index": 999,       # Last year
    "month_rel_index": 997,      # 3 months ago
    "cycle_rel_index": 999,      # Last quarter
}

# Fast integer comparison (not string parsing)
filters = {"year_rel_index": 1000}  # Current year only
```

**Benefits:**
- Integer comparisons (faster than string parsing)
- Pre-calculated (no runtime computation)
- Consistent across all tables
- Easy to understand (1000 = current, 999 = previous)

**4. Default Product Logic (Accuracy for Single-Product Questions)**

**Problem:** "What were sales in Q1?" - Which product?

**Solution:** Default to Pluvicto (primary product)

```python
# Tool description includes:
"DEFAULT: Filter to Pluvicto UNLESS another product is explicitly mentioned."

# Claude interprets:
"What were sales in Q1?" → products: ["Pluvicto"]
"What were Lutathera sales in Q1?" → products: ["Lutathera"]
"What were total sales in Q1?" → products: ["Pluvicto", "Lutathera", "Xofigo", "Novacure"]
```

**Benefits:**
- More accurate responses (assumes primary product)
- Reduces data retrieval (smaller result sets)
- Matches user intent (most questions are about Pluvicto)
- Explicit override available (user can specify other products)

**5. Forecast Type Handling (Actual vs Budget vs OC)**

**Data Structure:**
```python
# Each record has forecast_type field
{
    "brand": "Pluvicto",
    "date": "2025-01-01",
    "forecast_type": "Actual",  # or "Budget" or "OC"
    "net_sales": 88000000
}
```

**Query Strategy:**
```python
# Default to Actual
filters = {"forecast_types": ["Actual"]}

# Comparison questions
"Actual vs Budget" → filters = {"forecast_types": ["Actual", "Budget"]}

# Claude receives both types and compares
```

**Multi-Series Chart Support:**
- Detects "vs", "versus", "compared to" keywords
- Keeps forecast types separate (not aggregated)
- Returns data with `seriesKeys: ['actual', 'budget']`
- Frontend renders multiple lines/bars with different colors

**Data Accuracy Safeguards:**

**1. DynamoDB Filtering (Database-Level Accuracy)**

```python
# Filters applied at database level
def query_sales_finance_table(filters=None):
    response = sales_table.scan()
    items = response.get('Items', [])
    
    # Apply filters (database-level)
    if 'products' in filters:
        items = [i for i in items if i.get('brand') in filters['products']]
    
    if 'forecast_types' in filters:
        items = [i for i in items if i.get('forecast_type') in filters['forecast_types']]
    
    if 'start_date' in filters:
        items = [i for i in items if i.get('date') >= filters['start_date']]
    
    if 'end_date' in filters:
        items = [i for i in items if i.get('date') <= filters['end_date']]
    
    return items  # Returns ALL columns, ALL matching records
```

**Benefits:**
- Precise filtering (no data leakage)
- Complete records (all columns returned)
- No data loss (no pre-aggregation)
- Transparent (Claude sees raw data)

**2. Claude Aggregation (Intelligent Analysis)**

**Why Claude Does Aggregation:**
- Better at understanding context ("Q1" = Jan + Feb + Mar)
- Handles edge cases (partial months, fiscal years)
- Flexible aggregation (sum, average, min, max, count)
- Natural language output (explains calculations)

**Example:**
```
Question: "What were Pluvicto Q1 2025 sales?"

Data returned from DynamoDB:
[
    {"date": "2025-01-01", "net_sales": 88000000},
    {"date": "2025-02-01", "net_sales": 81000000},
    {"date": "2025-03-01", "net_sales": 82000000}
]

Claude's analysis:
"Pluvicto generated $251 million in net sales during Q1 2025, 
with January leading at $88 million, followed by steady 
performance around $81-82 million in February and March."

Calculation: $88M + $81M + $82M = $251M ✅
```

**3. Tool Description Clarity (Prevents Misuse)**

Each tool description explicitly states:
- What questions it handles
- What data it returns
- What Claude should do with the data
- Default behaviors

```python
"description": """Query SALES_FINANCE_BPC_corrected table for ALL sales/revenue questions.

USE THIS FOR:
- Revenue, net sales, gross sales, revenue deductions
- YTD, quarterly, monthly performance
- Actual vs Budget vs OC comparisons

IMPORTANT: For comparisons, use ONE call with broad date range

RETURNS: All matching records with ALL columns

YOU analyze and aggregate the data - don't ask for pre-aggregated results."""
```

**4. Validation & Error Handling**

```python
# Decimal to float conversion (JSON serialization)
def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    # Recursive for nested structures
    return obj

# Error handling
try:
    items = query_sales_finance_table(filters)
    return decimal_to_float(items)
except Exception as e:
    print(f"Error querying sales table: {e}")
    return []  # Empty result, not error
```

**Temporal Aggregation Examples:**

**Monthly → Quarterly:**
```
Question: "Q1 2025 sales"
Query: start_date="2025-01-01", end_date="2025-03-31"
Returns: 3 monthly records
Claude: Sums → Q1 total
```

**Monthly → Yearly:**
```
Question: "2024 sales"
Query: start_date="2024-01-01", end_date="2024-12-31"
Returns: 12 monthly records
Claude: Sums → Annual total
```

**Monthly → YTD:**
```
Question: "YTD 2025 sales"
Query: start_date="2025-01-01", end_date="2025-03-31" (current date)
Returns: 3 monthly records (Jan-Mar)
Claude: Sums → YTD total
```

**Monthly → Custom Period:**
```
Question: "Sales from February to April 2025"
Query: start_date="2025-02-01", end_date="2025-04-30"
Returns: 3 monthly records (Feb, Mar, Apr)
Claude: Sums → Custom period total
```

**Comparison Queries:**

**Year-over-Year:**
```
Question: "Compare Q1 2025 vs Q1 2024"
Query: start_date="2024-01-01", end_date="2025-03-31"
Returns: 6 monthly records (Q1 2024 + Q1 2025)
Claude: Groups by year, sums each quarter, compares
```

**Month-over-Month:**
```
Question: "Compare January vs February 2025"
Query: start_date="2025-01-01", end_date="2025-02-28"
Returns: 2 monthly records
Claude: Compares directly (no aggregation needed)
```

**Actual vs Budget:**
```
Question: "Compare Q1 2025 actual vs budget"
Query: 
    start_date="2025-01-01", 
    end_date="2025-03-31",
    forecast_types=["Actual", "Budget"]
Returns: 6 records (3 months × 2 forecast types)
Claude: Groups by forecast_type, sums each, compares
```

**Quality Assurance:**

**1. Tool Selection Accuracy**
- Clear tool descriptions prevent wrong table selection
- One tool per table eliminates ambiguity
- Claude's reasoning is logged for debugging

**2. Parameter Extraction Accuracy**
- Structured input schemas enforce correct parameters
- Date format validation (YYYY-MM-DD)
- Enum constraints for products, forecast types

**3. Data Completeness**
- All columns returned (no selective fields)
- All matching records returned (no pagination issues)
- No data transformation (raw data to Claude)

**4. Aggregation Accuracy**
- Claude shows calculations in response
- User can verify math
- Transparent methodology

**Performance Impact:**

**V1.0 (Python Aggregation):**
- Query: 100ms
- Python aggregation: 500-1000ms
- Total: 600-1100ms

**V2.0+ (Claude Aggregation):**
- Query: 100ms
- Claude analysis: 0ms (part of LLM inference)
- Total: 100ms (6-10x faster)

**Benefits:**
- Faster queries (no Python processing)
- Simpler code (no aggregation logic)
- More flexible (Claude handles edge cases)
- Better explanations (Claude explains calculations)

---

## 3. Major AWS Services

### 3.1 Amazon Bedrock

**Service Overview:**
Fully managed service for foundation models with enterprise security and privacy.

**Usage in Solution:**

- **Model:** Claude Sonnet 4.5 (anthropic.claude-sonnet-4-20250514-v1:0)
- **API:** Converse API with tool use
- **Features:** Function calling, vision, streaming
- **Region:** us-east-1

**Why Bedrock:**
- Enterprise-grade security and compliance
- No data retention by model providers
- Integrated with AWS IAM and VPC
- Pay-per-use pricing (no infrastructure management)
- Access to latest Claude models

**Connection Pooling:**
```python
# aws_clients.py - Centralized client management
bedrock_runtime = boto3.client('bedrock-runtime', region_name='us-east-1')

# Reused across all requests
# Prevents connection leaks and improves performance
```

### 3.2 Amazon Polly

**Service Overview:**
Text-to-speech service with neural voices for natural-sounding speech.

**Usage in Solution:**
- **Voice:** Joanna (US English, Neural)
- **Output Format:** MP3 (compressed audio)
- **API:** SynthesizeSpeech
- **Region:** us-east-1

**Why Polly:**
- High-quality neural voices (most natural-sounding)
- Fast synthesis (1-2 seconds for 60-word summaries)
- Cost-effective ($4 per million characters for neural)
- Seamless AWS integration

**Implementation:**
```python
response = polly_client.synthesize_speech(
    Text=audio_summary,
    OutputFormat='mp3',
    VoiceId='Joanna',
    Engine='neural'
)
```

### 3.3 Amazon DynamoDB

**Service Overview:**
Fully managed NoSQL database with single-digit millisecond performance.

**Usage in Solution:**
- **Tables:** 5 tables (Sales, Doses, Market Share, Calls, Rome)
- **Capacity Mode:** On-demand (auto-scaling)
- **Queries:** Partition key + sort key for efficient retrieval
- **Region:** us-east-1

**Why DynamoDB:**
- Predictable single-digit millisecond latency
- Automatic scaling (no capacity planning)
- Fully managed (no server maintenance)
- Cost-effective for read-heavy workloads
- Native AWS integration

**Query Pattern:**

```python
# Efficient query with partition key + filters
response = dynamodb.query(
    TableName='Novartis_Sales_Finance',
    KeyConditionExpression='product = :product AND date BETWEEN :start AND :end',
    FilterExpression='period_type = :period_type'
)
```

### 3.4 Amazon S3 (Implicit)

**Usage in Solution:**
- PDF storage (uploaded presentation files)
- Slide image storage (extracted PNG images from PDFs)
- Preprocessed data storage (JSON files with structured slide content)

**Current Implementation (Development):**
- All files stored locally in filesystem
- Location: `uploads/` directory
- Includes: PDFs, extracted slide images, and `preprocessed_slides.json` files

**Production Recommendation:**
- Migrate to S3 for cloud-based deployment
- Store all uploaded PDFs, extracted images, and preprocessed JSON files in S3 buckets
- Enable versioning for backup and recovery

**Why S3:**
- Unlimited storage capacity
- High durability (99.999999999%)
- Cost-effective ($0.023 per GB/month)
- Native integration with other AWS services (Lambda, Bedrock, DynamoDB)
- Automatic scaling and high availability

**Migration Path:**
- Replace local file operations with boto3 S3 client calls
- Update `app.py` upload endpoints to use `s3.put_object()`
- Update `slide_preprocessor.py` to read/write from S3
- Configure bucket policies and IAM roles for secure access

---

## 4. Technology Decision Rationale

### 4.1 Why Web Speech API (Not Amazon Transcribe)

**Decision:** Use browser-native Web Speech API for speech-to-text.

**Rationale:**

1. **Zero Latency**
   - Transcription happens in real-time in the browser
   - No network round-trip to AWS
   - Instant feedback to users

2. **Zero Cost**
   - Browser-native API (no AWS charges)
   - Transcribe costs $0.024 per minute
   - Significant savings for high-volume usage

3. **Simplicity**
   - No audio streaming infrastructure needed
   - No WebSocket or HTTP/2 setup
   - 20 lines of JavaScript vs complex AWS integration

4. **Privacy**
   - Audio never leaves the user's browser
   - No audio data stored or transmitted
   - Better compliance posture

5. **User Experience**
   - Instant transcription display
   - No buffering or delays
   - Works offline (browser-dependent)

**Trade-offs Accepted:**
- Browser compatibility (works in Chrome, Edge, Safari)
- Accuracy slightly lower than Transcribe for noisy environments
- No custom vocabulary or speaker identification

**When Transcribe Would Be Better:**
- Multi-speaker conversations
- Noisy environments requiring noise cancellation
- Custom medical/technical vocabulary
- Batch transcription of recorded audio

**Conclusion:** For our use case (single user, quiet environment, real-time interaction), Web Speech API is the optimal choice.

### 4.2 Why Custom Agent (Not Bedrock Agents)

**Decision:** Build custom agent with function calling instead of using AWS Bedrock Agents.

**Rationale:**


1. **Full Control**
   - Complete control over tool execution logic
   - Custom error handling and retry mechanisms
   - Ability to optimize tool calling patterns
   - No black-box behavior

2. **Performance Optimization**
   - Direct DynamoDB queries (no Lambda overhead)
   - Custom chart generation (Python-based, instant)
   - Smart context management (preprocessing integration)
   - Parallel tool calling optimization

3. **Simplicity**
   - Single Python file (novartis_agent_handler_v2_1.py)
   - No Lambda functions to deploy
   - No API Gateway configuration
   - Easier debugging and testing

4. **Cost Efficiency**
   - No Lambda invocation costs
   - No API Gateway costs
   - Only Bedrock LLM costs
   - ~50% cheaper than Bedrock Agents

5. **Flexibility**
   - Easy to add new tools
   - Custom preprocessing integration
   - Chart filtering and optimization
   - Smart routing logic

**Trade-offs Accepted:**
- Manual implementation of agent loop
- No built-in guardrails (implemented custom)
- No automatic prompt optimization
- More code to maintain

**When Bedrock Agents Would Be Better:**
- Need for built-in guardrails and safety
- Multiple teams sharing agent infrastructure
- Requirement for AWS-managed orchestration
- Complex multi-agent workflows

**Conclusion:** For our focused use case with specific performance requirements, a custom agent provides better control and efficiency.

### 4.3 Why DynamoDB (Not Snowflake)

**Decision:** Use Amazon DynamoDB instead of Snowflake for data storage.

**Rationale:**

1. **Performance**
   - Single-digit millisecond latency (vs seconds for Snowflake)
   - No cold start delays
   - Consistent performance regardless of query complexity
   - Critical for real-time conversational experience

2. **Cost**
   - On-demand pricing: $1.25 per million reads
   - No warehouse compute costs
   - No idle time charges
   - ~90% cheaper for our workload

3. **Simplicity**
   - No warehouse management
   - No query optimization needed
   - No connection pooling complexity
   - Fully managed service

4. **Data Volume**
   - ~7,000 rows total (small dataset)
   - Snowflake optimized for billions of rows
   - DynamoDB perfect for this scale
   - No need for data warehouse features

5. **Integration**
   - Native AWS SDK integration
   - Same IAM roles and policies
   - No VPC peering or network setup
   - Seamless with Bedrock and Polly

**Trade-offs Accepted:**
- No SQL (NoSQL query patterns)
- No complex joins (denormalized data)
- No OLAP features (not needed)
- Limited analytics capabilities

**When Snowflake Would Be Better:**
- Billions of rows requiring complex analytics
- Need for SQL and BI tool integration
- Complex joins across many tables
- Data warehouse and ETL requirements
- Historical data archival and compliance

**Conclusion:** For our small, read-heavy dataset with real-time requirements, DynamoDB is the optimal choice.

### 4.4 Why Recharts (Not Amazon QuickSight)

**Decision:** Use Recharts (React charting library) instead of Amazon QuickSight.

**Rationale:**


1. **Integration**
   - Native React components (seamless integration)
   - No iframe embedding or external URLs
   - Full control over styling and behavior
   - Consistent with application UI

2. **Performance**
   - Client-side rendering (instant)
   - No server-side chart generation
   - No network latency
   - Smooth animations and interactions

3. **Cost**
   - Free and open-source
   - QuickSight costs $9-18 per user/month
   - No per-session charges
   - Significant savings for multiple users

4. **Flexibility**
   - Custom chart types and styling
   - Dynamic data updates
   - Interactive tooltips and legends
   - Full TypeScript support

5. **Simplicity**
   - npm install recharts (one command)
   - No AWS service configuration
   - No embedding authentication
   - Easier development and testing

**Trade-offs Accepted:**
- No built-in BI features (not needed)
- No dashboard builder UI (not needed)
- No data source connectors (we have DynamoDB)
- Limited to programmatic chart generation

**When QuickSight Would Be Better:**
- Need for self-service BI dashboards
- Non-technical users creating reports
- Complex dashboard sharing and permissions
- Integration with multiple data sources
- Enterprise BI requirements

**Conclusion:** For programmatic chart generation in a conversational interface, Recharts is the perfect fit.

### 4.5 Why Not QuickSuite

**Decision:** Build custom solution instead of using QuickSuite.

**Rationale:**

1. **Customization Requirements**
   - Need for specific conversational interface
   - Custom preprocessing and optimization
   - Unique voice interaction patterns
   - Tailored to MBR data structure

2. **Performance Optimization**
   - Custom agent with table-aligned tools
   - Preprocessing system for 70% speed improvement
   - Smart routing and context management
   - Optimized for our specific use case

3. **Learning and Control**
   - Full understanding of system behavior
   - Ability to debug and optimize
   - No dependency on external team
   - Complete control over roadmap

4. **Cost Efficiency**
   - No QuickSuite licensing costs
   - Direct AWS service usage
   - Optimized for our workload
   - Better cost predictability

**Trade-offs Accepted:**
- More development effort
- No built-in features from QuickSuite
- Manual implementation of best practices
- Longer initial development time

**When QuickSuite Would Be Better:**
- Need for rapid prototyping
- Standard BI dashboard requirements
- Multiple data sources and connectors
- Enterprise-wide deployment
- Requirement for pre-built templates

**Conclusion:** Our specific requirements (conversational AI, voice interaction, custom preprocessing) justify a custom solution.

### 4.6 Why Not Strands

**Decision:** Build custom solution instead of using Strands.

**Rationale:**


1. **Simplicity**
   - Strands is complex orchestration framework
   - Our use case is straightforward (single agent, 5 tools)
   - No need for multi-agent coordination
   - Direct Bedrock API is simpler

2. **Performance**
   - Direct API calls are faster
   - No orchestration overhead
   - Custom optimization possible
   - Better control over latency

3. **Flexibility**
   - Custom preprocessing integration
   - Tailored chart generation
   - Specific audio summary logic
   - No framework constraints

4. **Learning Curve**
   - Strands requires significant learning
   - Direct Bedrock API is well-documented
   - Easier onboarding for new developers
   - Better long-term maintainability

**Trade-offs Accepted:**
- No built-in orchestration features
- Manual agent loop implementation
- No framework-level optimizations
- More code to maintain

**When Strands Would Be Better:**
- Complex multi-agent workflows
- Need for sophisticated orchestration
- Multiple LLM providers
- Advanced routing and fallback logic
- Enterprise-scale agent deployments

**Conclusion:** For our single-agent use case, direct Bedrock API provides better simplicity and performance.

---

## 5. Architecture Patterns

### 5.1 Table-Aligned Tools Pattern

**Pattern:** One tool per database table for optimal query performance.

**Implementation:**
```python
tools = [
    {
        "name": "query_sales_finance",
        "description": "Query Novartis_Sales_Finance table for revenue data",
        "input_schema": {...}
    },
    {
        "name": "query_doses",
        "description": "Query Novartis_Doses table for dose metrics",
        "input_schema": {...}
    },
    # ... 3 more tools
]
```

**Benefits:**
- Clear tool-to-table mapping
- Efficient query routing
- Reduced tool selection confusion
- Better LLM reasoning

**Evolution:**
- V1.0: Single tool querying all tables (slow, complex)
- V2.0: 3 table-aligned tools (50-70% faster)
- V2.1: 5 table-aligned tools (complete coverage)

### 5.2 Preprocessing Pattern

**Pattern:** Extract structured data once, query many times.

**Flow:**
```
Upload (One-Time)          Query (Every Time)
─────────────────          ──────────────────
PDF → Slides               Question
  ↓                           ↓
Vision Model               Load JSON (instant)
  ↓                           ↓
Structured JSON            Text-Only LLM
  ↓                           ↓
Save to Disk               Fast Response (7-10s)
```

**Benefits:**
- 70% faster response times
- Lower AWS costs (fewer vision calls)
- Better user experience
- Scalable to more users

### 5.3 Connection Pooling Pattern

**Pattern:** Centralized AWS client management to prevent connection leaks.

**Implementation:**
```python
# aws_clients.py
bedrock_runtime = boto3.client('bedrock-runtime', region_name='us-east-1')
polly_client = boto3.client('polly', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

# Reused across all requests
```

**Benefits:**
- Prevents connection leaks
- Reduces connection overhead
- Better resource utilization
- Improved stability

### 5.4 Smart Routing Pattern

**Pattern:** Detect question type and skip unnecessary processing.

**Implementation:**

```python
# Slide-focused questions
if any(keyword in question.lower() for keyword in ['slide', 'this', 'here']):
    context = load_preprocessed_data(slide_number)
    
# Data-focused questions
elif any(keyword in question.lower() for keyword in ['enrollment', 'trend', 'projection']):
    context = None  # Skip slide context for speed
```

**Benefits:**
- 40% faster for data-only questions
- Reduced token usage
- Better performance
- Smarter resource utilization

### 5.5 Chart Filtering Pattern

**Pattern:** Generate multiple charts, filter to best one.

**Implementation:**
```python
# Agent may generate multiple charts
charts = extract_all_charts_from_response(response)

# Filter out invalid charts (all zeros)
valid_charts = [c for c in charts if has_real_data(c)]

# Keep most detailed chart
best_chart = max(valid_charts, key=lambda c: len(c['data']))
```

**Benefits:**
- Eliminates duplicate charts
- Removes invalid visualizations
- Better user experience
- Consistent quality

### 5.6 Performance Optimization Summary

**Overview:** The system achieved 70% performance improvement (30-50s → 7-20s) through 12 strategic optimizations implemented across V2.0, V2.1, and V2.2.

**Complete Optimization List:**

| # | Optimization | Impact | Version | Details |
|---|--------------|--------|---------|---------|
| 1 | **Table-Aligned Architecture** | 50-70% faster | V2.0 | ONE question = ONE table = ONE tool call (see Section 5.1) |
| 2 | **Eliminated Python Aggregation** | Significant | V2.0 | Claude analyzes, DynamoDB filters - better division of labor |
| 3 | **Python-Based Chart Generation** | 30-40s saved | V2.0 | Instant chart creation, no extra Claude call |
| 4 | **Slide Preprocessing & Caching** | 70% faster | V2.2 | One-time extraction, text-only queries (see Section 5.2) |
| 5 | **DynamoDB Filtering** | Moderate | V2.0 | Filter at database level, reduced data transfer |
| 6 | **Connection Pooling** | Stability | V2.2 | Prevents leaks, singleton pattern (see Section 5.3) |
| 7 | **Simplified Tool Descriptions** | Minor | V2.0 | Faster tool selection, reduced token processing |
| 8 | **Relative Index Filtering** | Minor | V2.0 | Integer comparisons (1000=current, 999=last quarter) |
| 9 | **Removed Transformations** | Minor | V2.0 | Only Decimal→float conversion, simple data structure |
| 10 | **Default Product Logic** | Moderate | V2.1 | Default to Pluvicto, reduces data retrieval |
| 11 | **Optimized Audio Summary** | 2-3s | V2.0 | Single Claude call, concurrent with user reading |
| 12 | **Smart Question Routing** | 40% faster | V2.2 | Skips slide context for data queries (see Section 5.4) |

**Key Optimizations Explained:**

**#2 - Eliminated Python Aggregation:**
- V1.0: Retrieved all data, aggregated in Python, slow
- V2.0: DynamoDB filters data, Claude analyzes results
- Benefit: Better performance, simpler code, leverages each component's strengths

**#3 - Python-Based Chart Generation:**
- V1.0: Asked Claude to generate chart JSON (30-40s extra)
- V2.0: Python function generates charts from tool results (<0.1s)
- Benefit: Instant charts, no extra LLM call, consistent format

**#5 - DynamoDB Filtering:**
```python
# Filter at database level
FilterExpression='period_type = :actual AND product = :pluvicto'
# Returns only relevant data, not entire table
```

**#7 - Simplified Tool Descriptions:**
- Before: Verbose descriptions with examples (200+ tokens)
- After: Concise descriptions (50-80 tokens)
- Benefit: Faster tool selection, reduced prompt size

**#8 - Relative Index Filtering:**
```python
# Pre-calculated integer indexes in data
relative_index = 1000  # Current period
relative_index = 999   # Last quarter
relative_index = 996   # Same quarter last year

# Fast integer comparison vs string date parsing
```

**#9 - Removed Unnecessary Transformations:**
- Only essential transformation: Decimal → float (for JSON serialization)
- No complex data restructuring
- Keep original data structure from DynamoDB

**#10 - Default Product Logic:**
```python
# If no product specified, default to Pluvicto
if not product:
    product = 'Pluvicto'
# Reduces data retrieval, more accurate for single-product questions
```

**#11 - Optimized Audio Summary:**
- Single dedicated Claude call (not part of main conversation)
- Concurrent execution while user reads response
- 60-word limit for natural speech
- Always includes follow-up questions

**Performance Impact by Version:**

```
V1.0 (Baseline):
- 10 fragmented tools
- Python aggregation
- Claude-based chart generation
- No preprocessing
- Response time: 30-50s

V2.0 (Optimizations #1-3, #5, #7-9, #11):
- 3 table-aligned tools
- DynamoDB filtering
- Python chart generation
- Response time: 13-15s (50-70% faster)

V2.1 (Optimization #10):
- 5 table-aligned tools
- Default product logic
- Complete data coverage
- Response time: 17-20s (slight increase due to more data)

V2.2 (Optimizations #4, #6, #12):
- Preprocessing system
- Connection pooling
- Smart routing
- Response time: 7-10s for slide questions (70% faster)
- Response time: 8-10s for data questions (65% faster)
```

**Cumulative Impact:**

| Metric | V1.0 | V2.2 | Improvement |
|--------|------|------|-------------|
| Slide questions | 30-50s | 7s | 75-85% faster |
| Data questions | 30-50s | 13-15s | 50-70% faster |
| Complex queries | 40-60s | 15-20s | 50-67% faster |
| Chart generation | 30-40s | <0.1s | 99.7% faster |
| Tool calls per query | 2-5 | 1 | 50-80% reduction |
| AWS costs per query | $0.025 | $0.015 | 40% reduction |

**Remaining Bottleneck:**
- LLM inference time (6-8s for slide questions, 12-14s for data questions)
- Inherent to agentic approach with Claude Sonnet 4.5
- Data questions require tool calls and additional LLM iterations
- Can be improved with provisioned throughput (2-3x faster, expensive)
- Or response caching (instant for repeated questions)

---

## 6. Performance Characteristics

### 6.1 Response Time Breakdown

**V2.2 with Preprocessing (Current):**

**Slide Questions (7 seconds):**
```
Total: ~7 seconds

Breakdown:
- Slide data loading: 0.0s (instant from preprocessed JSON)
- LLM call (single iteration): 5-6s
- Chart generation: 0.0s (Python-based)
- Audio summary: 1-2s (Claude + Polly)
```

**Data Questions (13-15 seconds):**
```
Total: ~13-15 seconds

Breakdown:
- LLM calls: 12-14s (2-3 iterations with tool calls)
- Tool execution: 0.2-0.5s (DynamoDB queries)
- Chart generation: 0.0s (Python-based)
- Audio summary: 1-2s (Claude + Polly)
```

**Bottleneck Analysis:**
- 85-90% of time: LLM inference (Claude Sonnet 4.5)
- Data questions take longer due to multiple tool calls and reasoning steps
- 10-15% of time: Audio summary generation
- <5% of time: Database queries and chart generation

**Optimization Opportunities:**
- Provisioned throughput (2-3x faster LLM, expensive)
- Response caching (instant for repeated questions)
- Streaming responses (perceived speed improvement)

### 6.2 Throughput

**Current Capacity:**
- Concurrent users: 10-20 (limited by Bedrock quotas)
- Requests per minute: 60 (Bedrock default quota)
- Average response time: 7-15 seconds (slide: 7s, data: 13-15s)

**Scaling Options:**
- Request quota increase (up to 1000 RPM)
- Provisioned throughput (dedicated capacity)
- Multi-region deployment (geographic distribution)

### 6.3 Cost Analysis

**Per Query Cost (Estimated):**
```
LLM calls (Claude Sonnet 4.5):
- Input: ~2,000 tokens × $3/M = $0.006
- Output: ~500 tokens × $15/M = $0.0075
- Total LLM: ~$0.014

Audio summary:
- Polly: 60 words × $4/M chars = $0.0002

DynamoDB:
- Reads: 1-2 queries × $1.25/M = $0.000002

Total per query: ~$0.015 (1.5 cents)
```

**Monthly Cost (1000 queries):**
- LLM: $14
- Polly: $0.20
- DynamoDB: $0.002
- Total: ~$15/month

**Cost Optimization:**
- Preprocessing reduces vision model costs by 70%
- Connection pooling reduces overhead
- Smart routing reduces unnecessary LLM calls

### 6.4 Reliability

**Availability:**
- Backend: 99.9% (Flask on EC2/ECS)
- Bedrock: 99.9% (AWS SLA)
- DynamoDB: 99.99% (AWS SLA)
- Overall: 99.8% (cascading dependencies)

**Error Handling:**
- Automatic retry with exponential backoff
- Fallback to image processing if preprocessing fails
- Graceful degradation (skip audio if Polly fails)
- User-friendly error messages

**Monitoring:**
- CloudWatch metrics for API latency
- DynamoDB query performance
- Bedrock throttling and errors
- Custom application logs

---

## 7. Security & Compliance

### 7.1 Authentication & Authorization

**Current Implementation:**
- No authentication (internal tool)
- CORS enabled for frontend-backend communication
- AWS IAM roles for service access

**Production Recommendations:**
- Add Cognito authentication
- Implement role-based access control
- Enable API key authentication
- Add request rate limiting

### 7.2 Data Security

**Data at Rest:**
- DynamoDB: Encrypted with AWS-managed keys
- S3: Server-side encryption enabled
- Preprocessed data: Stored in application directory (consider encryption)

**Data in Transit:**
- HTTPS for all API calls
- TLS 1.2+ for AWS service communication
- Secure WebSocket for streaming (if implemented)

**Data Privacy:**
- No PII in MBR data
- Audio never stored (Web Speech API)
- Conversation history in browser only (not persisted)

### 7.3 Compliance

**AWS Services Used:**
- Bedrock: No data retention, enterprise-grade security
- DynamoDB: HIPAA eligible, SOC compliant
- Polly: HIPAA eligible, SOC compliant

**Best Practices:**
- Least privilege IAM policies
- VPC isolation (if deployed on EC2)
- CloudTrail logging enabled
- Regular security audits

---

## 8. Deployment Architecture

### 8.1 Local Development

**Setup:**
- Development mode with separate ports (3000 for frontend, 5000 for backend)
- Hot reload for rapid development
- Local DynamoDB tables for testing
- AWS credentials via mwinit/Isengard

**Command:**
```bash
./dev.sh dev  # Recommended for development
```

**Benefits:**
- Microphone/Web Speech API works reliably
- Fast iteration with hot reload
- Easy debugging with separate logs
- No build step required

### 8.2 AWS Deployment (ECS Fargate)

**Infrastructure Components:**
- **ECS Fargate**: Serverless container orchestration
- **Application Load Balancer (ALB)**: Private, internal-only access
- **ECR**: Docker image repository
- **DynamoDB**: Production data tables
- **CloudWatch**: Logging and monitoring
- **VPC**: Private subnets for security

**Deployment Method:**
- AWS CDK (Infrastructure as Code)
- Automated via `deploy.sh` script
- Single command deployment
- Automatic resource provisioning

**Architecture Decisions:**

1. **Why ECS Fargate (Not Lambda)**
   - Flask application requires persistent runtime
   - Bedrock API calls can exceed Lambda timeout
   - Easier debugging and logging
   - No cold start issues
   - Better for stateful applications

2. **Why Private ALB (Not Public)**
   - Internal use only (no public internet exposure)
   - VPC-based access control
   - Requires VPN or bastion host
   - Enhanced security posture
   - Compliance with enterprise policies

3. **Why CDK (Not CloudFormation)**
   - Type-safe infrastructure code
   - Reusable constructs
   - Better developer experience
   - Automatic dependency management
   - Easier to maintain and update

**Deployment Process:**
```bash
# 1. Set AWS profile
export AWS_PROFILE=your-profile

# 2. Deploy infrastructure
./deploy.sh

# 3. Load sample data
python utils/data_management/load_all_tables.py --region us-east-1

# 4. Test deployment
./scripts/setup-vpc-testing.sh
```

**Testing:**
- Automated VPC testing script
- Creates temporary EC2 instance in private subnet
- Tests health endpoint, frontend, and API
- Automatic cleanup after testing

**Cleanup:**
```bash
./cleanup.sh  # Removes all AWS resources
```

### 8.3 Production Considerations

**Scalability:**
- ECS service can scale horizontally (multiple tasks)
- ALB distributes traffic across tasks
- DynamoDB auto-scales with demand
- Bedrock handles concurrent requests

**Monitoring:**
- CloudWatch Logs for application logs
- CloudWatch Metrics for performance
- ALB access logs for traffic analysis
- Custom metrics for business KPIs

**Security:**
- IAM roles with least privilege
- VPC isolation (private subnets only)
- Security groups restrict access
- Encryption at rest (DynamoDB)
- Encryption in transit (HTTPS)

**Cost Optimization:**
- Fargate Spot for non-production
- DynamoDB on-demand pricing
- Bedrock pay-per-use model
- No idle infrastructure costs

**High Availability:**
- Multi-AZ deployment
- ALB health checks
- Automatic task replacement
- DynamoDB replication

---

## 9. Future Enhancements

### 9.1 Short-Term (Next Quarter)

1. **Response Caching**
   - Cache common questions and answers
   - Instant responses for repeated queries
   - Redis or DynamoDB-based cache
   - 90% faster for cached queries

2. **Streaming Responses**
   - Stream LLM output token-by-token
   - Perceived speed improvement
   - Better user experience
   - No actual latency reduction

3. **Multi-Language Support**
   - Spanish, French, German translations
   - Polly voices for each language
   - Internationalization (i18n) framework

4. **Advanced Charts**
   - Stacked bar charts
   - Area charts
   - Combo charts (line + bar)
   - Custom color themes

### 9.2 Medium-Term (Next 6 Months)

1. **Provisioned Throughput**
   - Dedicated Bedrock capacity
   - 2-3x faster LLM inference
   - Predictable performance
   - Higher cost but better UX

2. **Multi-User Support**
   - User authentication (Cognito)
   - Conversation history persistence
   - User preferences and settings
   - Role-based access control

3. **Advanced Analytics**
   - Trend analysis and forecasting
   - Anomaly detection
   - What-if scenario modeling
   - Comparative analysis

4. **Mobile App**
   - React Native mobile app
   - Offline mode with cached data
   - Push notifications
   - Mobile-optimized UI

### 9.3 Long-Term (Next Year)

1. **Multi-Agent System**
   - Specialized agents for different domains
   - Agent orchestration with Strands
   - Parallel query execution
   - Advanced reasoning capabilities

2. **Real-Time Data Integration**
   - Live data feeds from source systems
   - Streaming data ingestion
   - Real-time dashboard updates
   - Event-driven architecture

3. **Advanced AI Features**
   - Predictive analytics with ML models
   - Automated insight generation
   - Proactive recommendations
   - Sentiment analysis

4. **Enterprise Features**
   - Multi-tenancy support
   - Advanced security and compliance
   - Audit logging and reporting
   - Integration with enterprise systems

---

## Conclusion

The MBR Dashboard represents a thoughtful balance of simplicity, performance, and functionality. Every technology decision was made with clear rationale, prioritizing:

1. **Performance:** 70% faster through preprocessing and optimization
2. **Cost Efficiency:** Minimal AWS costs through smart architecture
3. **Simplicity:** Lightweight stack, easy to maintain
4. **User Experience:** Fast, intuitive, conversational interface

The solution demonstrates that production-grade AI applications don't require complex frameworks or expensive infrastructure. With the right architecture patterns and technology choices, we achieved:

- Sub-10-second response times
- $0.015 per query cost
- 99.8% availability
- Complete MBR data coverage

This architecture is production-ready and scalable, with clear paths for future enhancements as requirements evolve.

---

**Document End**
