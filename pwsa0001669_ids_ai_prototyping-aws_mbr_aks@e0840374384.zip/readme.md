<!--
Copyright © Amazon.com and Affiliates: This deliverable is considered Developed Content as defined in the AWS Service Terms and the SOW between the parties dated Sep 30, 2025
-->

# MBR Dashboard - AI-Powered Analytics

**Intelligent Executive Monthly Business Review Dashboard**  
Built with Claude Sonnet 4.5 Agent Architecture

---

## 🚀 Quick Start

**📖 For detailed setup instructions, see [QUICK_START.md](QUICK_START.md)**

### Local Development (2 minutes)
```bash
# One command setup and start (RECOMMENDED)
./dev.sh setup && ./dev.sh dev

# Load sample data into DynamoDB
python utils/data_management/load_all_tables.py --region us-east-1
```

**Access:**
- **Development Mode**: http://localhost:3000 (frontend) + http://localhost:5000 (API)
- **Production Mode**: `./dev.sh start` → http://localhost:5000

### AWS Deployment
```bash
# Set your AWS profile
export AWS_PROFILE=your-profile-name

# Deploy to AWS (ECS Fargate + Private ALB)
./deploy.sh

# Load sample data
python utils/data_management/load_all_tables.py --region us-east-1
```

**See [QUICK_START.md](QUICK_START.md) for:**
- Prerequisites and AWS CLI setup
- Detailed deployment options
- Testing and verification steps
- Cleanup instructions

---

## 📁 Project Structure

```
├── backend_api/              # Flask API + Agent Logic
│   ├── app.py               # Main API server (PRODUCTION)
│   ├── config.py            # Configuration management
│   ├── aws_clients.py       # Centralized AWS clients
│   ├── novartis_agent_handler_v2_1.py  # Agent with 5 tools (PRODUCTION)
│   ├── novartis_queries_v2_1.py        # DynamoDB queries (PRODUCTION)
│   └── slide_preprocessor.py           # Slide preprocessing engine
├── frontend/                 # React + TypeScript UI
│   └── src/
│       ├── App.tsx          # Main application
│       └── components/      # React components
├── utils/                    # Utility scripts (organized)
│   ├── aws/                 # AWS credential management
│   ├── data_generation/     # Data generation scripts (7 files)
│   └── data_management/     # Data loaders (2 files)
├── data/                     # Production data (organized)
│   ├── data_docs/           # Data documentation (7 .md files)
│   └── data_samples/        # Final CSV files + presentations
├── scripts/                  # Test & diagnostic scripts
├── docs/                     # Documentation
└── uploads/                  # Temporary file storage
```

---

## 🤖 How It Works

Uses **Claude Sonnet 4.5** with function calling to:
1. Understand natural language questions
2. Query DynamoDB for relevant data
3. Analyze trends and patterns
4. Generate comprehensive responses with charts
5. Synthesize audio via Amazon Polly

---

## 💬 Example Questions

- "What's our revenue this quarter?"
- "Show me market share vs competitors"
- "What's the national dose shipment trend?"
- "How many HCPs did our reps reach this month?"
- "Which sites are dormant?"

**See `docs/SAMPLE_QUESTIONS.md` for more examples**

---

## 📊 Available Data (2020-2028)

- Sales & Financial Performance (SALES_FINANCE_BPC_corrected)
- Market Share & Competitors (FCT_MARKET_PLU_corrected)
- National Dose Metrics (FCT_DOSES_PLU_corrected)
- Field Activity & HCP Reach (FCT_CALLS)
- Site Orders & Patient Demand (FCT_ROME_PLU)

**Source:** CSV files in `data/data_samples/`  
**Documentation:** See `data/data_docs/` for detailed data guides

---

## 🎨 Features

- 🎙️ Voice input/output (Web Speech API + Amazon Polly)
- 📈 Intelligent chart generation (multi-series support)
- 🔄 Follow-up question support with conversation history
- 🧠 Agent-based reasoning (5 table-aligned tools)
- 📄 PDF slide upload with preprocessing
- 📊 Slide-aware context for visual questions
- 📱 Responsive design with QuickSuite purple theme

---

## 🔧 Configuration

### Backend
- **Model:** Claude Sonnet 4.5 (via AWS Bedrock)
- **Database:** DynamoDB (5 tables, us-east-1)
- **TTS:** Amazon Polly Neural
- **Port:** 5000
- **Architecture:** Flask REST API with agent-based function calling

### Frontend
- **Framework:** React 18 + TypeScript
- **Build Tool:** Vite
- **Charting:** Recharts
- **Port:** 3000

### AWS Credentials
See `docs/ISENGUARD_SETUP.md` for detailed setup instructions.  
Supports: ECS task role, AWS Profile with isengardcli, CSV credentials

---

## 📈 Performance

- Response Time: 7-10 seconds (with preprocessing)
- Cost per Request: $0.02-0.05
- Handles complex analytical questions
- Connection pooling prevents resource leaks
- Preprocessing eliminates repeated image analysis

---

## 🚀 Deployment

**Current Architecture:** Flask backend + React frontend  
**Deployment Target:** AWS ECS/Fargate with Private ALB  
**Not Lambda:** Uses long-running Flask server with connection pooling

**📖 Complete deployment guide:** [QUICK_START.md](QUICK_START.md)

**Quick Deploy:**
```bash
export AWS_PROFILE=your-profile-name
./deploy.sh
```

**Includes:**
- CDK infrastructure as code
- Automated testing script
- Cleanup script for resource removal
- Environment configuration options

---

## 📝 API Endpoints

- `POST /api/ask` - Ask questions (with agent mode, conversation history, slide context)
- `POST /api/synthesize` - Text-to-speech conversion (Amazon Polly)
- `POST /api/preprocess` - Upload and preprocess PDF slides
- `GET /api/health` - Health check

---

## 🛡️ Security

- AWS credentials via isengardcli (temporary credentials)
- CORS configured for local development
- Add authentication for production deployment
- Use HTTPS in production
- Implement rate limiting for production

---

## 📚 Documentation

- **DOC1_SOLUTION_ARCHITECTURE.md** - System architecture and design
- **DOC2_CODE_REFERENCE.md** - Complete code reference (v1.2)
- **QUICK_START.md** - Quick start guide
- **docs/ISENGUARD_SETUP.md** - AWS credential setup
- **docs/SAMPLE_QUESTIONS.md** - Example queries
- **data/data_docs/** - Data documentation and guides

---

*Version 2.2.1 - Production Ready*  
*Last Updated: December 16, 2025*
